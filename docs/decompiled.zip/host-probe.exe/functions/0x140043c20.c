// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::string::String)>>::extend_desugared::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,alloc[246c2e7857c81348]::string::String>>,host_probe[b94139f9089eb1d8]::emblem::message::{closure#1}>>
// address: 0x140043c20
// body: available
// range: 0x140043c20-0x140043c5a inclusive
// range: 0x140043c60-0x140043d7a inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u64,
   alloc[246c2e7857c81348]::string::String)>>::extend_desugared::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,
   alloc[246c2e7857c81348]::string::String>>,
   host_probe[b94139f9089eb1d8]::emblem::message::{closure#1}>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::string::String)>>::extend_desugared
::
<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,alloc[246c2e7857c81348]::string::String>>,host_probe[b94139f9089eb1d8]::emblem::message::_closure_1_>>
          (longlong *param_1,longlong *param_2)

{
  undefined1 auVar1 [16];
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  int iVar5;
  uint uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  uint uVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  ulonglong uVar13;
  undefined1 (*pauVar14) [16];
  ushort uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  longlong local_58;
  undefined8 local_50;
  undefined8 local_48;
  
  uVar17 = param_2[5];
  if (uVar17 != 0) {
    uVar13 = param_2[4];
    lVar12 = *param_2;
    pauVar14 = (undefined1 (*) [16])param_2[1];
    uVar9 = (uint)*(ushort *)(param_2 + 3);
    do {
      uVar17 = uVar17 - 1;
      param_2[5] = uVar17;
      if (uVar13 == 0) {
        return;
      }
      if ((short)uVar9 == 0) {
        do {
          auVar1 = *pauVar14;
          lVar12 = lVar12 + -0x200;
          pauVar14 = pauVar14 + 1;
          uVar15 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) | (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1
                    | (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                   (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar9 = (uint)uVar15;
        } while (uVar15 == 0);
        param_2[1] = (longlong)pauVar14;
        *param_2 = lVar12;
      }
      iVar5 = 0;
      for (uVar6 = uVar9; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
        iVar5 = iVar5 + 1;
      }
      uVar9 = uVar9 - 1 & uVar9;
      *(short *)(param_2 + 3) = (short)uVar9;
      lVar11 = lVar12 - (ulonglong)(uint)(iVar5 << 5);
      uVar13 = uVar13 - 1;
      param_2[4] = uVar13;
      uVar3 = *(undefined8 *)(lVar11 + -0x20);
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (&local_58,lVar11 + -0x18);
      uVar8 = local_48;
      uVar7 = local_50;
      lVar11 = local_58;
      if (local_58 == -1) {
        return;
      }
      lVar4 = param_1[2];
      if (lVar4 == *param_1) {
        uVar16 = uVar13;
        if (uVar17 < uVar13) {
          uVar16 = uVar17;
        }
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar4,uVar16 + 1,8,0x20);
      }
      lVar2 = param_1[1];
      lVar10 = lVar4 * 0x20;
      *(undefined8 *)(lVar2 + lVar10) = uVar3;
      *(longlong *)(lVar2 + 8 + lVar10) = lVar11;
      *(undefined8 *)(lVar2 + 0x10 + lVar10) = uVar7;
      *(undefined8 *)(lVar2 + 0x18 + lVar10) = uVar8;
      param_1[2] = lVar4 + 1;
    } while (uVar17 != 0);
  }
  return;
}

