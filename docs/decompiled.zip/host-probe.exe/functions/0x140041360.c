// rea decompile_all
// name: <core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Values<u64,host_probe[b94139f9089eb1d8]::net::Route>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::next
// address: 0x140041360
// body: available
// range: 0x140041360-0x14004140a inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Values<u64,
   host_probe[b94139f9089eb1d8]::net::Route>> as
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::next */

void __rustcall
<core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Values<u64,host_probe[b94139f9089eb1d8]::net::Route>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
::next(undefined8 *param_1,longlong *param_2)

{
  undefined8 *puVar1;
  undefined1 auVar2 [16];
  uint uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  longlong lVar11;
  longlong lVar12;
  ushort uVar13;
  uint uVar14;
  undefined1 (*pauVar15) [16];
  
  if (param_2[4] != 0) {
    uVar13 = *(ushort *)(param_2 + 3);
    lVar11 = *param_2;
    if (uVar13 == 0) {
      pauVar15 = (undefined1 (*) [16])param_2[1];
      do {
        auVar2 = *pauVar15;
        lVar11 = lVar11 + -0x500;
        pauVar15 = pauVar15 + 1;
        uVar13 = ((ushort)(SUB161(auVar2 >> 7,0) & 1) | (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
                  (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                  (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                  (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                  (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                  (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                  (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                  (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                  (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                  (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                  (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                  (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                  (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                  (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
                 (ushort)(byte)(auVar2[0xf] >> 7) << 0xf) ^ 0xffff;
      } while (uVar13 == 0);
      param_2[1] = (longlong)pauVar15;
      *param_2 = lVar11;
    }
    *(ushort *)(param_2 + 3) = uVar13 - 1 & uVar13;
    param_2[4] = param_2[4] + -1;
    uVar3 = 0;
    for (uVar14 = (uint)uVar13; (uVar14 & 1) == 0; uVar14 = uVar14 >> 1 | 0x80000000) {
      uVar3 = uVar3 + 1;
    }
    lVar12 = (ulonglong)uVar3 * -0x50;
    param_1[8] = *(undefined8 *)(lVar11 + -8 + lVar12);
    puVar1 = (undefined8 *)(lVar11 + -0x48 + lVar12);
    uVar4 = *puVar1;
    uVar5 = puVar1[1];
    puVar1 = (undefined8 *)(lVar11 + -0x38 + lVar12);
    uVar6 = *puVar1;
    uVar7 = puVar1[1];
    puVar1 = (undefined8 *)(lVar11 + -0x28 + lVar12);
    uVar8 = *puVar1;
    uVar9 = puVar1[1];
    puVar1 = (undefined8 *)(lVar11 + -0x18 + lVar12);
    uVar10 = puVar1[1];
    param_1[6] = *puVar1;
    param_1[7] = uVar10;
    param_1[4] = uVar8;
    param_1[5] = uVar9;
    param_1[2] = uVar6;
    param_1[3] = uVar7;
    *param_1 = uVar4;
    param_1[1] = uVar5;
    return;
  }
  *(undefined4 *)(param_1 + 1) = 0xffffffff;
  return;
}

