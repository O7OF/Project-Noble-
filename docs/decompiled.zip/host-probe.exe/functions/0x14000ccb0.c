// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::census::arm::{closure#0}
// address: 0x14000ccb0
// body: available
// range: 0x14000ccb0-0x14000ce51 inclusive
// range: 0x14000ce60-0x14000cec4 inclusive
// range: 0x14000ced0-0x14000cf4c inclusive
// range: 0x14000cf50-0x14000d119 inclusive
// range: 0x14000d120-0x14000d186 inclusive
// range: 0x14000d190-0x14000d1e3 inclusive
// range: 0x14000d1f0-0x14000d2af inclusive
// range: 0x14000d2b5-0x14000d398 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000d182 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000d2ab to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::census::arm::{closure#0} */

void __rustcall host_probe[b94139f9089eb1d8]::census::arm::_closure_0_(void)

{
  char *pcVar1;
  code *pcVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined *puVar9;
  byte bVar10;
  char cVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  ulonglong *puVar14;
  longlong lVar15;
  ulonglong uVar16;
  ulonglong *puVar17;
  ushort uVar18;
  DWORD dwTlsIndex;
  ulonglong uVar19;
  ulonglong uVar20;
  longlong lVar21;
  ulonglong uVar22;
  uint uVar23;
  ulonglong uVar24;
  bool bVar25;
  undefined1 auVar26 [16];
  undefined1 auVar27 [16];
  undefined1 auVar28 [16];
  undefined1 unaff_XMM6_Ba;
  undefined1 unaff_XMM6_Bb;
  undefined1 unaff_XMM6_Bc;
  undefined1 unaff_XMM6_Bd;
  undefined1 unaff_XMM6_Be;
  undefined1 unaff_XMM6_Bf;
  undefined1 unaff_XMM6_Bg;
  undefined1 unaff_XMM6_Bh;
  undefined1 unaff_XMM6_Bi;
  undefined1 unaff_XMM6_Bj;
  undefined1 unaff_XMM6_Bk;
  undefined1 unaff_XMM6_Bl;
  undefined1 unaff_XMM6_Bm;
  undefined1 unaff_XMM6_Bn;
  undefined1 unaff_XMM6_Bo;
  undefined1 unaff_XMM6_Bp;
  undefined1 local_111;
  longlong local_110;
  ulonglong *local_108;
  undefined1 local_100 [4];
  undefined4 local_fc;
  undefined1 (*local_f8) [16];
  undefined1 (*pauStack_f0) [16];
  undefined4 *local_e8;
  code *local_e0;
  ulonglong *local_d8;
  code *local_d0;
  undefined **local_c8;
  undefined8 *local_c0;
  longlong local_b8;
  ulonglong *local_b0;
  longlong local_a8;
  ulonglong local_a0;
  undefined *local_98;
  ulonglong uStack_90;
  undefined8 local_88;
  longlong lStack_80;
  ulonglong local_78;
  ulonglong uStack_70;
  undefined *local_68;
  undefined8 local_60;
  
  puVar9 = 
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
  ;
  if (*(longlong *)
       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
      != 0) {
    std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
  }
  if (*(int *)(puVar9 + 0x18) == 0) {
    dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                           (
                           __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                           );
    puVar12 = TlsGetValue(dwTlsIndex);
  }
  else {
    dwTlsIndex = *(int *)(puVar9 + 0x18) - 1;
    puVar12 = TlsGetValue(dwTlsIndex);
  }
  if (puVar12 < (ulonglong *)0x2) {
    puVar12 = (ulonglong *)
              <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
              ::try_initialize::
              <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                        (dwTlsIndex,puVar12,0);
  }
  if (puVar12 == (ulonglong *)0x0) {
    std[3bf9d48a0c3997f0]::thread::local::panic_access_error
              (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  local_78 = *puVar12;
  uStack_70 = puVar12[1];
  *puVar12 = *puVar12 + 1;
  local_88 = 0;
  lStack_80 = 0;
  local_98 = &DAT_1406a0540;
  uStack_90 = 0;
  iVar5 = -(uint)(CONCAT13(unaff_XMM6_Bd,
                           CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))) ==
                 CONCAT13(unaff_XMM6_Bd,
                          CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))));
  iVar6 = -(uint)(CONCAT13(unaff_XMM6_Bh,
                           CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))) ==
                 CONCAT13(unaff_XMM6_Bh,
                          CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))));
  iVar7 = -(uint)(CONCAT13(unaff_XMM6_Bl,
                           CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))) ==
                 CONCAT13(unaff_XMM6_Bl,
                          CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))));
  iVar8 = -(uint)(CONCAT13(unaff_XMM6_Bp,
                           CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))) ==
                 CONCAT13(unaff_XMM6_Bp,
                          CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))));
  do {
    std[3bf9d48a0c3997f0]::thread::functions::sleep(10,0);
    LOCK();
    bVar25 = HITS == '\0';
    if (bVar25) {
      HITS = '\x01';
    }
    UNLOCK();
    if (!bVar25) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&HITS);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar10 = 0;
    }
    else {
      bVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar10 = bVar10 ^ 1;
    }
    if (DAT_1407f6af9 != '\0') {
      local_f8 = (undefined1 (*) [16])&HITS;
      uVar13 = (ulonglong)pauStack_f0 >> 8;
      pauStack_f0 = (undefined1 (*) [16])CONCAT71((int7)uVar13,bVar10);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_f8,
                 &
                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0e10
                 ,&PTR_s_src_census_rs_1406a07f0);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    if (DAT_1407f6b00 == (undefined1 (*) [16])0x0) {
      local_110 = 0;
      puVar12 = (ulonglong *)&DAT_00000008;
      lVar15 = 0;
    }
    else {
      local_e8 = (undefined4 *)(*DAT_1407f6b00 + DAT_1407f6b08 + 1);
      auVar26 = *DAT_1407f6b00;
      pauStack_f0 = DAT_1407f6b00 + 1;
      uVar13 = (ulonglong)local_e0 >> 0x10;
      local_e0 = (code *)CONCAT62((int6)uVar13,
                                  ~((ushort)(SUB161(auVar26 >> 7,0) & 1) |
                                    (ushort)(SUB161(auVar26 >> 0xf,0) & 1) << 1 |
                                    (ushort)(SUB161(auVar26 >> 0x17,0) & 1) << 2 |
                                    (ushort)(SUB161(auVar26 >> 0x1f,0) & 1) << 3 |
                                    (ushort)(SUB161(auVar26 >> 0x27,0) & 1) << 4 |
                                    (ushort)(SUB161(auVar26 >> 0x2f,0) & 1) << 5 |
                                    (ushort)(SUB161(auVar26 >> 0x37,0) & 1) << 6 |
                                    (ushort)(SUB161(auVar26 >> 0x3f,0) & 1) << 7 |
                                    (ushort)(SUB161(auVar26 >> 0x47,0) & 1) << 8 |
                                    (ushort)(SUB161(auVar26 >> 0x4f,0) & 1) << 9 |
                                    (ushort)(SUB161(auVar26 >> 0x57,0) & 1) << 10 |
                                    (ushort)(SUB161(auVar26 >> 0x5f,0) & 1) << 0xb |
                                    (ushort)(SUB161(auVar26 >> 0x67,0) & 1) << 0xc |
                                    (ushort)(SUB161(auVar26 >> 0x6f,0) & 1) << 0xd |
                                    (ushort)(SUB161(auVar26 >> 0x77,0) & 1) << 0xe |
                                   (ushort)(byte)(auVar26[0xf] >> 7) << 0xf));
      local_f8 = DAT_1407f6b00;
      local_d8 = DAT_1407f6b18;
      <alloc[246c2e7857c81348]::vec::Vec<((u32,u32),(u64,u8))>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<((u32,u32),(u64,u8)),core[505b25137b8ba7f]::iter::adapters::map::Map<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<(u32,u32),(u64,u8)>,host_probe[b94139f9089eb1d8]::census::arm::{closure#0}::{closure#0}::{closure#0}>>>
      ::from_iter(&local_b8);
      puVar12 = local_b0;
      lVar15 = local_a8;
      local_110 = local_b8;
    }
    local_108 = puVar12;
    if (((bVar10 == 0) &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0')
       ) {
      DAT_1407f6af9 = '\x01';
    }
    cVar11 = HITS;
    LOCK();
    HITS = '\0';
    UNLOCK();
    if (cVar11 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&HITS);
    }
    puVar17 = local_108;
    if (lVar15 != 0) {
      puVar14 = local_108;
      puVar12 = local_108;
      do {
        local_e8 = (undefined4 *)puVar14[2];
        local_f8 = (undefined1 (*) [16])*puVar14;
        pauStack_f0 = (undefined1 (*) [16])puVar14[1];
        if (lStack_80 != 0) {
          uVar13 = *puVar14;
          uVar22 = uStack_70 ^ 0x646f72616e646f6d;
          uVar16 = uVar13 ^ uStack_70 ^ 0x7465646279746573;
          uVar19 = (local_78 ^ 0x736f6d6570736575) + uVar22;
          uVar20 = (local_78 ^ 0x6c7967656e657261) + uVar16;
          uVar22 = (uVar22 << 0xd | uVar22 >> 0x33) ^ uVar19;
          uVar16 = (uVar16 << 0x10 | uVar16 >> 0x30) ^ uVar20;
          uVar20 = uVar20 + uVar22;
          uVar19 = (uVar19 << 0x20 | uVar19 >> 0x20) + uVar16;
          uVar22 = (uVar22 << 0x11 | uVar22 >> 0x2f) ^ uVar20;
          uVar16 = uVar19 ^ 0x800000000000000 ^ (uVar16 << 0x15 | uVar16 >> 0x2b);
          uVar24 = (uVar13 ^ uVar19) + uVar22;
          uVar19 = (uVar20 << 0x20 | uVar20 >> 0x20) + uVar16;
          uVar20 = (uVar22 << 0xd | uVar22 >> 0x33) ^ uVar24;
          uVar16 = (uVar16 << 0x10 | uVar16 >> 0x30) ^ uVar19;
          uVar19 = uVar19 + uVar20;
          uVar22 = (uVar24 << 0x20 | uVar24 >> 0x20) + uVar16;
          uVar20 = (uVar20 << 0x11 | uVar20 >> 0x2f) ^ uVar19;
          uVar16 = (uVar16 << 0x15 | uVar16 >> 0x2b) ^ uVar22;
          uVar22 = (uVar22 ^ 0x800000000000000) + uVar20;
          uVar19 = ((uVar19 << 0x20 | uVar19 >> 0x20) ^ 0xff) + uVar16;
          uVar20 = (uVar20 << 0xd | uVar20 >> 0x33) ^ uVar22;
          uVar16 = (uVar16 << 0x10 | uVar16 >> 0x30) ^ uVar19;
          uVar19 = uVar19 + uVar20;
          uVar22 = (uVar22 << 0x20 | uVar22 >> 0x20) + uVar16;
          uVar20 = (uVar20 << 0x11 | uVar20 >> 0x2f) ^ uVar19;
          uVar16 = (uVar16 << 0x15 | uVar16 >> 0x2b) ^ uVar22;
          uVar22 = uVar22 + uVar20;
          uVar19 = (uVar19 << 0x20 | uVar19 >> 0x20) + uVar16;
          uVar20 = (uVar20 << 0xd | uVar20 >> 0x33) ^ uVar22;
          uVar16 = (uVar16 << 0x10 | uVar16 >> 0x30) ^ uVar19;
          uVar19 = uVar19 + uVar20;
          uVar22 = (uVar22 << 0x20 | uVar22 >> 0x20) + uVar16;
          uVar20 = (uVar20 << 0x11 | uVar20 >> 0x2f) ^ uVar19;
          uVar16 = (uVar16 << 0x15 | uVar16 >> 0x2b) ^ uVar22;
          uVar19 = (uVar19 << 0x20 | uVar19 >> 0x20) + uVar16;
          uVar20 = (uVar20 << 0xd | uVar20 >> 0x33) ^ uVar22 + uVar20;
          uVar16 = (uVar16 << 0x10 | uVar16 >> 0x30) ^ uVar19;
          uVar19 = uVar19 + uVar20;
          uVar16 = (uVar19 << 0x20 | uVar19 >> 0x20) ^ uVar19 ^
                   (uVar16 << 0x15 | uVar16 >> 0x2b) ^ (uVar20 << 0x11 | uVar20 >> 0x2f);
          bVar10 = (byte)(uVar16 >> 0x39);
          auVar26 = ZEXT216(CONCAT11(bVar10,bVar10));
          auVar26 = pshuflw(auVar26,auVar26,0);
          lVar21 = 0;
          while( true ) {
            uVar16 = uVar16 & uStack_90;
            pcVar1 = local_98 + uVar16;
            auVar28[0] = -(*pcVar1 == auVar26[0]);
            auVar28[1] = -(pcVar1[1] == auVar26[1]);
            auVar28[2] = -(pcVar1[2] == auVar26[2]);
            auVar28[3] = -(pcVar1[3] == auVar26[3]);
            auVar28[4] = -(pcVar1[4] == auVar26[4]);
            auVar28[5] = -(pcVar1[5] == auVar26[5]);
            auVar28[6] = -(pcVar1[6] == auVar26[6]);
            auVar28[7] = -(pcVar1[7] == auVar26[7]);
            auVar28[8] = -(pcVar1[8] == auVar26[0]);
            auVar28[9] = -(pcVar1[9] == auVar26[1]);
            auVar28[10] = -(pcVar1[10] == auVar26[2]);
            auVar28[0xb] = -(pcVar1[0xb] == auVar26[3]);
            auVar28[0xc] = -(pcVar1[0xc] == auVar26[4]);
            auVar28[0xd] = -(pcVar1[0xd] == auVar26[5]);
            auVar28[0xe] = -(pcVar1[0xe] == auVar26[6]);
            auVar28[0xf] = -(pcVar1[0xf] == auVar26[7]);
            uVar18 = (ushort)(SUB161(auVar28 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar28 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar28 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar28 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar28 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar28 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar28 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar28 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar28 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar28 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar28 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar28 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar28 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar28 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar28 >> 0x77,0) & 1) << 0xe |
                     (ushort)(auVar28[0xf] >> 7) << 0xf;
            uVar23 = (uint)uVar18;
            while (uVar18 != 0) {
              uVar3 = 0;
              for (uVar4 = uVar23; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
                uVar3 = uVar3 + 1;
              }
              uVar19 = uVar3 + uVar16 & uStack_90;
              if ((*(int *)(local_98 + uVar19 * -0x10 + -0x10) == (int)uVar13) &&
                 (*(int *)(local_98 + uVar19 * -0x10 + -0xc) == (int)(uVar13 >> 0x20)))
              goto joined_r0x00014000cf5d;
              uVar18 = (ushort)(uVar23 - 1) & (ushort)uVar23;
              uVar23 = CONCAT22((short)(uVar23 - 1 >> 0x10),uVar18);
            }
            auVar27[0] = -(*pcVar1 == (char)iVar5);
            auVar27[1] = -(pcVar1[1] == (char)((uint)iVar5 >> 8));
            auVar27[2] = -(pcVar1[2] == (char)((uint)iVar5 >> 0x10));
            auVar27[3] = -(pcVar1[3] == (char)((uint)iVar5 >> 0x18));
            auVar27[4] = -(pcVar1[4] == (char)iVar6);
            auVar27[5] = -(pcVar1[5] == (char)((uint)iVar6 >> 8));
            auVar27[6] = -(pcVar1[6] == (char)((uint)iVar6 >> 0x10));
            auVar27[7] = -(pcVar1[7] == (char)((uint)iVar6 >> 0x18));
            auVar27[8] = -(pcVar1[8] == (char)iVar7);
            auVar27[9] = -(pcVar1[9] == (char)((uint)iVar7 >> 8));
            auVar27[10] = -(pcVar1[10] == (char)((uint)iVar7 >> 0x10));
            auVar27[0xb] = -(pcVar1[0xb] == (char)((uint)iVar7 >> 0x18));
            auVar27[0xc] = -(pcVar1[0xc] == (char)iVar8);
            auVar27[0xd] = -(pcVar1[0xd] == (char)((uint)iVar8 >> 8));
            auVar27[0xe] = -(pcVar1[0xe] == (char)((uint)iVar8 >> 0x10));
            auVar27[0xf] = -(pcVar1[0xf] == (char)((uint)iVar8 >> 0x18));
            if ((((((((((((((((SUB161(auVar27 >> 7,0) & 1) != 0 ||
                             (SUB161(auVar27 >> 0xf,0) & 1) != 0) ||
                            (SUB161(auVar27 >> 0x17,0) & 1) != 0) ||
                           (SUB161(auVar27 >> 0x1f,0) & 1) != 0) ||
                          (SUB161(auVar27 >> 0x27,0) & 1) != 0) ||
                         (SUB161(auVar27 >> 0x2f,0) & 1) != 0) ||
                        (SUB161(auVar27 >> 0x37,0) & 1) != 0) ||
                       (SUB161(auVar27 >> 0x3f,0) & 1) != 0) || (SUB161(auVar27 >> 0x47,0) & 1) != 0
                      ) || (SUB161(auVar27 >> 0x4f,0) & 1) != 0) ||
                    (SUB161(auVar27 >> 0x57,0) & 1) != 0) || (SUB161(auVar27 >> 0x5f,0) & 1) != 0)
                  || (SUB161(auVar27 >> 0x67,0) & 1) != 0) || (SUB161(auVar27 >> 0x6f,0) & 1) != 0)
                || (SUB161(auVar27 >> 0x77,0) & 1) != 0) || auVar27[0xf] < '\0') break;
            uVar16 = uVar16 + lVar21 + 0x10;
            lVar21 = lVar21 + 0x10;
          }
        }
        puVar12[2] = (ulonglong)local_e8;
        *puVar12 = (ulonglong)local_f8;
        puVar12[1] = (ulonglong)pauStack_f0;
        puVar12 = puVar12 + 3;
joined_r0x00014000cf5d:
        puVar14 = puVar14 + 3;
      } while (puVar14 != local_108 + lVar15 * 3);
    }
    uVar13 = (longlong)puVar12 - (longlong)local_108;
    if (0x2f < uVar13) {
      lVar15 = (uVar13 >> 3) * -0x5555555555555555;
      if (uVar13 < 0x1f8) {
        core[505b25137b8ba7f]::slice::sort::shared::smallsort::insertion_sort_shift_left::
        <((u32,u32),(u64,u8)),<((u32,u32),(u64,u8))as_core[505b25137b8ba7f]::cmp::PartialOrd>::lt>
                  (local_108,lVar15,1,&local_111);
      }
      else {
        core[505b25137b8ba7f]::slice::sort::stable::driftsort_main::
        <((u32,u32),(u64,u8)),<((u32,u32),(u64,u8))as_core[505b25137b8ba7f]::cmp::PartialOrd>::lt,alloc[246c2e7857c81348]::vec::Vec<((u32,u32),(u64,u8))>>
                  (local_108,lVar15,&local_111);
      }
    }
    for (; puVar12 != puVar17; puVar17 = puVar17 + 3) {
      local_100 = *(undefined1 (*) [4])puVar17;
      local_fc = *(undefined4 *)((longlong)puVar17 + 4);
      local_a0 = puVar17[1];
      uVar13 = puVar17[2];
      <hashbrown[ad6d4a1843b2832d]::map::HashMap<(u32,u32),u64,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
      ::insert(&local_98);
      if ((char)uVar13 == '\x02') {
        local_60 = 1;
        local_68 = &DAT_1406a0809;
      }
      else {
        local_60 = 2;
        local_68 = &DAT_1406a080a;
        if ((char)uVar13 == '\x01') {
          local_60 = 1;
          local_68 = &DAT_1406a0808;
        }
      }
      pauStack_f0 = (undefined1 (*) [16])<u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_e8 = &local_fc;
      local_e0 = <u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_d8 = &local_a0;
      local_d0 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      local_c8 = &local_68;
      local_c0 = &<&str_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      local_f8 = (undefined1 (*) [16])local_100;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_b8,&DAT_1406a080c,&local_f8);
      puVar14 = local_b0;
      lVar15 = local_b8;
      host::log(local_b0);
      if (lVar15 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar14,lVar15,1);
        return;
      }
    }
    if (local_110 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(local_108,local_110 * 0x18,8);
      return;
    }
  } while( true );
}

