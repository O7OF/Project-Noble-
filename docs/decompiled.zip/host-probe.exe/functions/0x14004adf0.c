// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#0}>,host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#1}>>,host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#2}>>>::from_iter
// address: 0x14004adf0
// body: available
// range: 0x14004adf0-0x14004b0d6 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#0}>,
   host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#1}>>,
   host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#2}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#0}>,host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#1}>>,host_probe[b94139f9089eb1d8]::trace::gs_failure::{closure#2}>>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  ulonglong uVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  longlong lVar8;
  code *pcVar9;
  undefined4 *puVar10;
  longlong lVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  longlong local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  longlong *local_80;
  longlong *local_78;
  longlong local_70;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  longlong *local_50;
  code *local_48;
  
  if (param_2[4] != 0) {
    uVar2 = param_2[2];
    uVar13 = param_2[1];
    if (uVar13 < uVar2) {
      lVar11 = param_2[4] + -1;
      plVar3 = (longlong *)*param_2;
      plVar4 = (longlong *)param_2[3];
      lVar5 = *plVar4;
      puVar12 = (ulonglong *)(uVar13 * 8 + *plVar3);
      do {
        uVar13 = uVar13 + 1;
        uVar6 = *puVar12;
        if (uVar6 < lVar5 + 0x980000U && lVar5 + 0x1000U < uVar6) {
          plVar7 = (longlong *)param_2[5];
          local_b0 = uVar6 - *plVar7;
          local_98 = &local_b0;
          uStack_90 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
          alloc[246c2e7857c81348]::fmt::format::format_inner(&local_68,&DAT_1406a3da0,&local_98);
          if (CONCAT44(uStack_64,local_68) != -1) {
            local_80 = plVar7;
            local_78 = plVar3;
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            puVar10 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
            if (puVar10 == (undefined4 *)0x0) {
              alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
              pcVar9 = (code *)invalidInstructionException();
              (*pcVar9)();
            }
            *(undefined8 *)(puVar10 + 4) = local_58;
            *puVar10 = local_68;
            puVar10[1] = uStack_64;
            puVar10[2] = uStack_60;
            puVar10[3] = uStack_5c;
            local_b0 = 4;
            local_a0 = 1;
            local_a8 = puVar10;
            if (lVar11 == 0) goto LAB_14004b07c;
            goto LAB_14004af63;
          }
          break;
        }
        puVar12 = puVar12 + 1;
      } while (uVar13 != uVar2);
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
LAB_14004af63:
  lVar5 = local_a0;
  if (uVar2 <= uVar13) {
LAB_14004b07c:
    param_1[2] = local_a0;
    *param_1 = local_b0;
    param_1[1] = (longlong)local_a8;
    return param_1;
  }
  lVar11 = lVar11 + -1;
  lVar8 = *plVar4;
  puVar12 = (ulonglong *)(uVar13 * 8 + *local_78);
  while( true ) {
    uVar13 = uVar13 + 1;
    uVar6 = *puVar12;
    if (uVar6 < lVar8 + 0x980000U && lVar8 + 0x1000U < uVar6) break;
    puVar12 = puVar12 + 1;
    if (uVar13 == uVar2) goto LAB_14004b07c;
  }
  local_70 = uVar6 - *local_80;
  local_50 = &local_70;
  local_48 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_98,&DAT_1406a3da0,&local_50);
  if (local_98 == (longlong *)0xffffffffffffffff) goto LAB_14004b07c;
  if (lVar5 == local_b0) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_b0,lVar5,1,8,0x18);
    puVar10 = local_a8;
  }
  *(undefined8 *)(puVar10 + lVar5 * 6 + 4) = local_88;
  puVar1 = puVar10 + lVar5 * 6;
  *puVar1 = (undefined4)local_98;
  puVar1[1] = local_98._4_4_;
  puVar1[2] = (undefined4)uStack_90;
  puVar1[3] = uStack_90._4_4_;
  local_a0 = lVar5 + 1;
  if (lVar11 == 0) goto LAB_14004b07c;
  goto LAB_14004af63;
}

