// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::m64_member::install
// address: 0x140016a80
// body: available
// range: 0x140016a80-0x1400179c3 inclusive
// range: 0x1400179d0-0x140017a0b inclusive
// range: 0x140017a0e-0x140017d78 inclusive
// range: 0x140017d7e-0x140017f13 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140016c77 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140016d0d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140016d9c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140016f1f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400171c1 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140017372 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140017392 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400173ad to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400173c8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400173de to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140017626 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400179f0 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::m64_member::install */

undefined8 * __rustcall
host_probe[b94139f9089eb1d8]::m64_member::install(undefined8 *param_1,longlong param_2)

{
  code *pcVar1;
  undefined4 *puVar2;
  undefined8 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined8 *puVar13;
  longlong lVar14;
  undefined8 local_168;
  undefined8 uStack_160;
  undefined8 local_158;
  undefined4 *local_150;
  undefined *local_148;
  undefined8 local_140;
  undefined4 local_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 *local_128;
  longlong local_120;
  longlong local_118;
  longlong local_110;
  char *local_108;
  undefined8 local_100;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined4 *local_e8;
  undefined4 *local_d8;
  undefined4 local_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 *local_c0;
  undefined4 *local_b8;
  undefined4 *local_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined4 *local_98;
  undefined4 *local_88;
  undefined4 *local_80;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 uStack_6c;
  undefined8 local_68;
  undefined8 local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined1 local_44;
  
  local_108 = "m64 member";
  local_100 = 10;
  local_120 = 0;
  local_118 = 8;
  local_110 = 0;
  local_70 = 0x40e0;
  with_bounds(&local_168,param_2,0x3968ee,&DAT_1406a176f,0x21,&DAT_1406a1790,1);
  puVar4 = local_150;
  puVar9 = local_158;
  puVar8 = uStack_160;
  puVar2 = local_158;
  puVar5 = uStack_160;
  if ((int)local_168 == 1) goto joined_r0x0001400173ef;
  local_168 = (undefined4 *)&DAT_1406a1720;
  uStack_160 = (undefined4 *)0x3;
  local_150 = (undefined4 *)&DAT_00000004;
  local_148 = &DAT_1406a1723;
  local_140 = 0x1f;
  local_158 = &local_70;
  <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_138,&local_168,3);
  puVar2 = (undefined4 *)CONCAT44(uStack_12c,uStack_130);
  detour(&local_d0,&local_120,param_2,0x3968ee,puVar9,puVar4,puVar2,local_128,0x39690f);
  if (CONCAT44(uStack_cc,local_d0) == -1) {
    if (CONCAT44(uStack_134,local_138) != 0) {
      puVar13 = (undefined8 *)
                __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar2,CONCAT44(uStack_134,local_138),1);
      return puVar13;
    }
    local_168 = (undefined4 *)&DAT_1406a17a3;
    uStack_160 = (undefined4 *)0x4;
    local_158 = (undefined4 *)&DAT_1406a17a7;
    local_150 = (undefined4 *)0x7;
    <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_138,&local_168,2);
    uVar3 = CONCAT44(uStack_12c,uStack_130);
    <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
              (&local_120,0x3969ad,&DAT_1406a1798,0xb,uVar3,local_128);
    if (CONCAT44(uStack_134,local_138) != 0) {
      puVar13 = (undefined8 *)
                __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar3,CONCAT44(uStack_134,local_138),1);
      return puVar13;
    }
    local_168 = (undefined4 *)&DAT_1406a17b9;
    uStack_160 = (undefined4 *)&DAT_00000004;
    local_158 = (undefined4 *)&DAT_1406a17a7;
    local_150 = (undefined4 *)&DAT_00000007;
    <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_138,&local_168,2);
    uVar3 = CONCAT44(uStack_12c,uStack_130);
    <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
              (&local_120,0x3969ba,&DAT_1406a17ae,0xb,uVar3,local_128);
    if (CONCAT44(uStack_134,local_138) != 0) {
      puVar13 = (undefined8 *)
                __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar3,CONCAT44(uStack_134,local_138),1);
      return puVar13;
    }
    with_bounds(&local_168,param_2,0x3969c5,&DAT_1406a17bd,0x30,&DAT_1406a17f0,2);
    puVar5 = local_150;
    if ((int)local_168 != 1) {
      local_d8 = local_158;
      local_b0 = uStack_160;
      local_168 = (undefined4 *)&DAT_1406a1660;
      uStack_160 = (undefined4 *)&DAT_00000016;
      local_150 = (undefined4 *)&DAT_00000004;
      local_148 = &DAT_1406a1676;
      local_140 = 0x1a;
      local_158 = &local_70;
      <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_138,&local_168,3);
      puVar2 = local_d8;
      puVar4 = (undefined4 *)CONCAT44(uStack_12c,uStack_130);
      detour(&local_d0,&local_120,param_2,0x3969c5,local_d8,puVar5,puVar4,local_128,0x3969f5);
      if (CONCAT44(uStack_cc,local_d0) == -1) {
        if (CONCAT44(uStack_134,local_138) != 0) {
          puVar13 = (undefined8 *)
                    __rustc[9d087a5ab36ea756]::__rust_dealloc
                              (puVar4,CONCAT44(uStack_134,local_138),1);
          return puVar13;
        }
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x396a0b,&DAT_1406a1800,3,&DAT_1406a1803,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x396a37,&DAT_1406a1806,3,&DAT_1406a1809,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x396b82,&DAT_1406a180c,4,&DAT_1406a1810,4);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x396b86,&DAT_1406a1806,3,&DAT_1406a1809,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x396c9d,&DAT_1406a1800,3,&DAT_1406a1803,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x396ca2,&DAT_1406a1806,3,&DAT_1406a1809,3);
        with_bounds(&local_168,param_2,0x396ba7,&DAT_1406a1814,0x18,&DAT_1406a1830,1);
        puVar10 = local_150;
        puVar4 = local_158;
        puVar2 = local_d8;
        puVar11 = uStack_160;
        puVar12 = local_158;
        puVar5 = local_b0;
        if ((int)local_168 == 1) goto joined_r0x0001400173bd;
        local_b8 = uStack_160;
        local_168 = (undefined4 *)&DAT_1406a1720;
        uStack_160 = (undefined4 *)0x3;
        local_150 = (undefined4 *)&DAT_00000004;
        local_148 = &DAT_1406a1742;
        local_140 = 0x16;
        local_158 = &local_70;
        <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_138,&local_168,3);
        puVar5 = (undefined4 *)CONCAT44(uStack_12c,uStack_130);
        detour(&local_d0,&local_120,param_2,0x396ba7,puVar4,puVar10,puVar5,local_128,0x396bbf);
        if (CONCAT44(uStack_cc,local_d0) == -1) {
          if (CONCAT44(uStack_134,local_138) != 0) {
            puVar13 = (undefined8 *)
                      __rustc[9d087a5ab36ea756]::__rust_dealloc
                                (puVar5,CONCAT44(uStack_134,local_138),1);
            return puVar13;
          }
          <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                    (&local_120,0x396be0,&DAT_1406a1838,10,&DAT_1406a1842,10);
          <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                    (&local_120,0x396bf5,&DAT_1406a184c,3,&DAT_1406a184f,3);
          with_bounds(&local_168,param_2,0x396c61,&DAT_1406a1852,0x2a,&DAT_1406a1880,2);
          puVar5 = local_150;
          puVar10 = uStack_160;
          puVar11 = local_158;
          puVar12 = local_150;
          puVar2 = local_d8;
          puVar7 = local_b8;
          if ((int)local_168 == 1) goto joined_r0x0001400173a2;
          local_80 = local_158;
          local_88 = uStack_160;
          local_168 = (undefined4 *)&DAT_1406a1690;
          uStack_160 = (undefined4 *)&DAT_00000014;
          local_150 = (undefined4 *)&DAT_00000004;
          local_148 = &DAT_1406a16a4;
          local_140 = 0x17;
          local_158 = &local_70;
          <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_138,&local_168,3);
          uVar3 = CONCAT44(uStack_12c,uStack_130);
          detour(&local_f8,&local_120,param_2,0x396c61,local_80,puVar5,uVar3,local_128,0x396c8b);
          puVar6 = local_88;
          puVar5 = local_80;
          if (CONCAT44(uStack_134,local_138) != 0) {
            puVar13 = (undefined8 *)
                      __rustc[9d087a5ab36ea756]::__rust_dealloc
                                (uVar3,CONCAT44(uStack_134,local_138),1);
            return puVar13;
          }
        }
        else {
          local_f8 = (undefined4 *)CONCAT44(uStack_cc,local_d0);
          uStack_f0 = (undefined4 *)CONCAT44(uStack_c4,uStack_c8);
          local_e8 = local_c0;
          puVar6 = (undefined4 *)CONCAT44(uStack_134,local_138);
        }
        puVar10 = local_f8;
        puVar11 = uStack_f0;
        puVar12 = local_e8;
        puVar2 = local_d8;
        puVar7 = local_b8;
        if (puVar6 != (undefined4 *)0x0) {
          puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(puVar5,puVar6,1);
          return puVar13;
        }
      }
      else {
        local_f8 = (undefined4 *)CONCAT44(uStack_cc,local_d0);
        uStack_f0 = (undefined4 *)CONCAT44(uStack_c4,uStack_c8);
        puVar10 = local_f8;
        puVar11 = uStack_f0;
        puVar12 = local_c0;
        puVar7 = (undefined4 *)CONCAT44(uStack_134,local_138);
      }
joined_r0x0001400173a2:
      local_e8 = puVar12;
      uStack_f0 = puVar11;
      local_f8 = puVar10;
      puVar11 = local_f8;
      puVar12 = uStack_f0;
      puVar10 = local_e8;
      puVar5 = local_b0;
      if (puVar7 != (undefined4 *)0x0) {
        puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(puVar4,puVar7,1);
        return puVar13;
      }
      goto joined_r0x0001400173bd;
    }
    local_f8 = uStack_160;
    uStack_f0 = local_158;
    local_e8 = local_150;
  }
  else {
    local_f8 = (undefined4 *)CONCAT44(uStack_cc,local_d0);
    uStack_f0 = (undefined4 *)CONCAT44(uStack_c4,uStack_c8);
    puVar11 = local_f8;
    puVar12 = uStack_f0;
    puVar10 = local_c0;
    puVar5 = (undefined4 *)CONCAT44(uStack_134,local_138);
joined_r0x0001400173bd:
    local_e8 = puVar10;
    uStack_f0 = puVar12;
    local_f8 = puVar11;
    if (puVar5 != (undefined4 *)0x0) {
      puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(puVar2,puVar5,1);
      return puVar13;
    }
  }
  puVar2 = uStack_f0;
  puVar4 = local_e8;
  puVar5 = local_f8;
  if (puVar8 != (undefined4 *)0x0) {
    puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(puVar9,puVar8,1);
    return puVar13;
  }
joined_r0x0001400173ef:
  local_e8 = puVar4;
  local_f8 = puVar5;
  uStack_f0 = puVar2;
  if (puVar5 == (undefined4 *)0xffffffffffffffff) {
    detour(&local_168,&local_120,param_2,0x39df1c,&DAT_1406a1943,0xb,&DAT_1406a194e,0x12,0x39df27);
    if (local_168 == (undefined4 *)0xffffffffffffffff) {
      detour(&local_138,&local_120,param_2,0x39df3d,&DAT_1406a1960,0xd,&DAT_1406a196d,0xe,0x39df4a);
    }
    else {
      local_128 = local_158;
      local_138 = (int)local_168;
      uStack_134 = local_168._4_4_;
      uStack_130 = (undefined4)uStack_160;
      uStack_12c = uStack_160._4_4_;
    }
    if (CONCAT44(uStack_134,local_138) == -1) {
      local_74 = 0x40b0;
      local_168 = (undefined4 *)&DAT_1406a18fe;
      uStack_160 = (undefined4 *)0x3;
      local_150 = (undefined4 *)&DAT_00000004;
      local_148 = &DAT_1406a1901;
      local_140 = 4;
      local_158 = &local_74;
      <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_70,&local_168,3);
      detour(&local_168,&local_120,param_2,0x39e841,&DAT_1406a1905,6,local_68,local_60,0x39e847);
      if ((local_168 == (undefined4 *)0xffffffffffffffff) &&
         (detour(&local_168,&local_120,param_2,0x39e860,&DAT_1406a1905,6,local_68,local_60,0x39e866)
         , local_168 == (undefined4 *)0xffffffffffffffff)) {
        local_168 = (undefined4 *)&DAT_1406a190b;
        uStack_160 = (undefined4 *)0x3;
        local_150 = (undefined4 *)&DAT_00000004;
        local_148 = &DAT_1406a18ac;
        local_140 = 3;
        local_158 = &local_74;
        <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_f8,&local_168,3);
        puVar2 = uStack_f0;
        detour(&local_168,&local_120,param_2,0x39e880,&DAT_1406a190e,7,uStack_f0,local_e8,0x39e887);
        if (local_168 == (undefined4 *)0xffffffffffffffff) {
          <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                    (&local_120,0x39e88e,&DAT_1406a1915,4,&DAT_1406a1919,4);
          with_bounds(&local_168,param_2,0x39e8a7,&DAT_1406a191d,3,&DAT_1406a1920,1);
          puVar8 = local_158;
          puVar5 = uStack_160;
          if ((int)local_168 == 1) {
            local_a8 = uStack_160;
            uStack_a0 = local_158;
            local_98 = local_150;
          }
          else {
            if (local_150 < (undefined4 *)0x3) {
              core[505b25137b8ba7f]::panicking::panic_bounds_check
                        (2,local_150,&PTR_s_src_m64_member_rs_1406a1928);
                    /* WARNING: Does not return */
              pcVar1 = (code *)invalidInstructionException();
              (*pcVar1)();
            }
            if (*(char *)((longlong)local_158 + 2) != '@') {
              <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                        (&local_120,0x39e8a7,local_158,local_150,&DAT_1406a1940,3);
            }
            local_58 = 0xf2c4b8b;
            uStack_54 = 0x2173d1a3;
            uStack_50 = 0x8310438b;
            uStack_4c = 0x574fff8;
            local_48 = 0x72c1a30f;
            local_44 = 3;
            local_168 = (undefined4 *)&DAT_1406a1758;
            uStack_160 = (undefined4 *)0x3;
            local_150 = (undefined4 *)0x4;
            local_148 = &DAT_1406a175b;
            local_140 = 0x14;
            local_158 = &local_74;
            <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_d0,&local_168,3);
            hook::far_jump(&local_138,param_2 + 0x39e8cc);
            local_158 = (undefined4 *)CONCAT44(uStack_134,local_138);
            local_168 = (undefined4 *)CONCAT44(uStack_12c,uStack_130);
            local_150 = (undefined4 *)((longlong)local_128 + (longlong)local_168);
            uStack_160 = local_168;
            <alloc[246c2e7857c81348]::vec::Vec<u8>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<u8,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<u8>>>
            ::spec_extend(&local_d0,&local_168);
            hook::far_jump(&local_138,param_2 + 0x39e8e0);
            local_158 = (undefined4 *)CONCAT44(uStack_134,local_138);
            local_168 = (undefined4 *)CONCAT44(uStack_12c,uStack_130);
            local_150 = (undefined4 *)((longlong)local_128 + (longlong)local_168);
            uStack_160 = local_168;
            <alloc[246c2e7857c81348]::vec::Vec<u8>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<u8,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<u8>>>
            ::spec_extend(&local_d0,&local_168);
            detour(&local_a8,&local_120,param_2,0x39e8b7,&local_58,0x15,
                   CONCAT44(uStack_c4,uStack_c8),local_c0,0x39e8cf);
            if (CONCAT44(uStack_cc,local_d0) != 0) {
              puVar13 = (undefined8 *)
                        __rustc[9d087a5ab36ea756]::__rust_dealloc
                                  (CONCAT44(uStack_c4,uStack_c8),CONCAT44(uStack_cc,local_d0),1);
              return puVar13;
            }
            if (puVar5 != (undefined4 *)0x0) {
              puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(puVar8,puVar5,1);
              return puVar13;
            }
          }
        }
        else {
          local_98 = local_158;
          local_a8 = local_168;
          uStack_a0 = uStack_160;
        }
        if (local_f8 != (undefined4 *)0x0) {
          puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(puVar2,local_f8,1);
          return puVar13;
        }
      }
      else {
        local_98 = local_158;
        local_a8 = local_168;
        uStack_a0 = uStack_160;
      }
      if (CONCAT44(uStack_6c,local_70) != 0) {
        puVar13 = (undefined8 *)
                  __rustc[9d087a5ab36ea756]::__rust_dealloc(local_68,CONCAT44(uStack_6c,local_70),1)
        ;
        return puVar13;
      }
      if (local_a8 == (undefined4 *)0xffffffffffffffff) {
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426c0a,&DAT_1406a1890,3,&DAT_1406a1893,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426c13,&DAT_1406a1896,3,&DAT_1406a1899,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426c16,&DAT_1406a189c,4,&DAT_1406a18a0,4);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426c1a,&DAT_1406a18a4,4,&DAT_1406a18a8,4);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426eb2,&DAT_1406a1890,3,&DAT_1406a1893,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426eb7,&DAT_1406a189c,4,&DAT_1406a18a0,4);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426ebb,&DAT_1406a18cb,3,&DAT_1406a18ce,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426ec5,&DAT_1406a18a4,4,&DAT_1406a18a8,4);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426f31,&DAT_1406a1890,3,&DAT_1406a1893,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426f36,&DAT_1406a189c,4,&DAT_1406a18a0,4);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426f3a,&DAT_1406a18cb,3,&DAT_1406a18ce,3);
        <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                  (&local_120,0x426f44,&DAT_1406a18a4,4,&DAT_1406a18a8,4);
        detour(&local_168,&local_120,param_2,0x426c2a,&DAT_1406a18bc,6,&DAT_1406a18c2,9,0x426c30);
        if (((local_168 == (undefined4 *)0xffffffffffffffff) &&
            (detour(&local_168,&local_120,param_2,0x426ed2,&DAT_1406a18bc,6,&DAT_1406a18c2,9,
                    0x426ed8), local_168 == (undefined4 *)0xffffffffffffffff)) &&
           (detour(&local_168,&local_120,param_2,0x426f51,&DAT_1406a18bc,6,&DAT_1406a18c2,9,0x426f57
                  ), local_168 == (undefined4 *)0xffffffffffffffff)) {
          <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                    (&local_120,0x42736d,&DAT_1406a18ac,3,&DAT_1406a18af,3);
          <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                    (&local_120,0x4273b0,&DAT_1406a18b2,5,&DAT_1406a18b7,5);
          <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                    (&local_120,0x4274a5,&DAT_1406a18ac,3,&DAT_1406a18af,3);
          <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                    (&local_120,0x4274c8,&DAT_1406a18ac,3,&DAT_1406a18af,3);
          <host_probe[b94139f9089eb1d8]::p64::Batch>::apply(&local_168,&local_120,param_2);
          if (local_168 == (undefined4 *)0xffffffffffffffff) {
            memberx::WIDE_0_llvm_10439611301029776152 = 1;
            memberx::LARGEST_MESSAGE_0_llvm_10439611301029776152 = 0;
            memberx::OVERSIZE = 0;
            host::log("m64 member: host membership send over 64 machines (u64 full/delta masks), builder and applier machine tests 64-bit, machine/leader/host indices 6 bits on the wire, memberx at 64 machines with packed entries"
                      ,0xce);
            *param_1 = 0xffffffffffffffff;
            core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::p64::Batch>
                      (&local_120);
            return param_1;
          }
          param_1[2] = local_158;
          *(int *)param_1 = (int)local_168;
          *(undefined4 *)((longlong)param_1 + 4) = local_168._4_4_;
          *(undefined4 *)(param_1 + 1) = (undefined4)uStack_160;
          *(undefined4 *)((longlong)param_1 + 0xc) = uStack_160._4_4_;
        }
        else {
          *(undefined4 *)(param_1 + 1) = (undefined4)uStack_160;
          *(undefined4 *)((longlong)param_1 + 0xc) = uStack_160._4_4_;
          *(undefined4 *)(param_1 + 2) = (undefined4)local_158;
          *(undefined4 *)((longlong)param_1 + 0x14) = local_158._4_4_;
          *param_1 = local_168;
        }
      }
      else {
        param_1[2] = local_98;
        *(undefined4 *)param_1 = (undefined4)local_a8;
        *(undefined4 *)((longlong)param_1 + 4) = local_a8._4_4_;
        *(undefined4 *)(param_1 + 1) = (undefined4)uStack_a0;
        *(undefined4 *)((longlong)param_1 + 0xc) = uStack_a0._4_4_;
      }
    }
    else {
      param_1[2] = local_128;
      *(undefined4 *)param_1 = local_138;
      *(undefined4 *)((longlong)param_1 + 4) = uStack_134;
      *(undefined4 *)(param_1 + 1) = uStack_130;
      *(undefined4 *)((longlong)param_1 + 0xc) = uStack_12c;
    }
  }
  else {
    param_1[2] = local_e8;
    local_f8._0_4_ = SUB84(puVar5,0);
    local_f8._4_4_ = (undefined4)((ulonglong)puVar5 >> 0x20);
    uStack_f0._0_4_ = SUB84(puVar2,0);
    uStack_f0._4_4_ = (undefined4)((ulonglong)puVar2 >> 0x20);
    *(undefined4 *)param_1 = (undefined4)local_f8;
    *(undefined4 *)((longlong)param_1 + 4) = local_f8._4_4_;
    *(undefined4 *)(param_1 + 1) = (undefined4)uStack_f0;
    *(undefined4 *)((longlong)param_1 + 0xc) = uStack_f0._4_4_;
  }
  if (local_110 != 0) {
    puVar13 = (undefined8 *)(local_118 + 0x28);
    lVar14 = local_110;
    do {
      if (puVar13[-5] != 0) {
        puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(puVar13[-4],puVar13[-5],1)
        ;
        return puVar13;
      }
      if (puVar13[-1] != 0) {
        puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar13,puVar13[-1],1);
        return puVar13;
      }
      puVar13 = puVar13 + 7;
      lVar14 = lVar14 + -1;
    } while (lVar14 != 0);
  }
  if (local_120 == 0) {
    return param_1;
  }
  puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(local_118,local_120 * 0x38,8);
  return puVar13;
}

