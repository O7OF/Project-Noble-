// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::star_wrap
// address: 0x14003b750
// body: available
// range: 0x14003b750-0x14003b8a5 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::star_wrap */

void __rustcall
host_probe[b94139f9089eb1d8]::net::star_wrap
          (ulonglong *param_1,undefined8 param_2,void *param_3,ulonglong param_4,byte param_5)

{
  ulonglong uVar1;
  code *pcVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong local_48;
  undefined8 *puStack_40;
  longlong local_38;
  
  uVar1 = param_4 + 0x10;
  uVar3 = param_4 + 0x28;
  if ((param_5 & 1) == 0) {
    uVar3 = uVar1;
  }
  if (0x4e4 < uVar3) {
    param_1[1] = uVar3;
    *param_1 = 0xffffffffffffffff;
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  puStack_40 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(uVar1,1);
  if (puStack_40 == (undefined8 *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar1);
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  *puStack_40 = 0x31445254532d5252;
  local_38 = 8;
  lVar4 = 8;
  local_48 = uVar1;
  if (((uint)uVar1 & 0x7f8) == 8) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_48,8,8,1,1);
    lVar4 = local_38;
  }
  *(undefined8 *)((longlong)puStack_40 + lVar4) = param_2;
  lVar4 = lVar4 + 8;
  local_38 = lVar4;
  if (local_48 - lVar4 < param_4) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_48,lVar4,param_4,1,1);
  }
  else if (param_4 == 0) goto LAB_14003b80f;
  lVar4 = local_38;
  memcpy((void *)((longlong)puStack_40 + local_38),param_3,param_4);
LAB_14003b80f:
  param_1[2] = lVar4 + param_4;
  *param_1 = local_48;
  param_1[1] = (ulonglong)puStack_40;
  return;
}

