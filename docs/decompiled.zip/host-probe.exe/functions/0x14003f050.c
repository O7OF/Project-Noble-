// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<host_probe[b94139f9089eb1d8]::fileshare::Job,<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::fileshare::Job>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::chain::Chain<core[505b25137b8ba7f]::iter::sources::once::Once<host_probe[b94139f9089eb1d8]::fileshare::Job>,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<host_probe[b94139f9089eb1d8]::fileshare::Job>>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),host_probe[b94139f9089eb1d8]::fileshare::Job)>>::call_mut
// address: 0x14003f050
// body: available
// range: 0x14003f050-0x14003f09f inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut 
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<host_probe[b94139f9089eb1d8]::fileshare::Job,
   <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::fileshare::Job>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::chain::Chain<core[505b25137b8ba7f]::iter::sources::once::Once<host_probe[b94139f9089eb1d8]::fileshare::Job>,
   alloc[246c2e7857c81348]::vec::into_iter::IntoIter<host_probe[b94139f9089eb1d8]::fileshare::Job>>>::{closure#0}>::{closure#0}
   as core[505b25137b8ba7f]::ops::function::FnMut<((),
   host_probe[b94139f9089eb1d8]::fileshare::Job)>>::call_mut */

void __rustcall
<&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<host_probe[b94139f9089eb1d8]::fileshare::Job,<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::fileshare::Job>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::chain::Chain<core[505b25137b8ba7f]::iter::sources::once::Once<host_probe[b94139f9089eb1d8]::fileshare::Job>,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<host_probe[b94139f9089eb1d8]::fileshare::Job>>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),host_probe[b94139f9089eb1d8]::fileshare::Job)>>
::call_mut(longlong *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  longlong lVar12;
  
  lVar2 = *param_1;
  lVar3 = *(longlong *)(lVar2 + 8);
  lVar4 = *(longlong *)(lVar2 + 0x10);
  lVar12 = lVar3 * 0x58;
  *(undefined8 *)(lVar4 + 0x50 + lVar12) = param_2[10];
  uVar5 = param_2[9];
  puVar1 = (undefined8 *)(lVar4 + 0x40 + lVar12);
  *puVar1 = param_2[8];
  puVar1[1] = uVar5;
  uVar5 = *param_2;
  uVar6 = param_2[1];
  uVar7 = param_2[2];
  uVar8 = param_2[3];
  uVar9 = param_2[4];
  uVar10 = param_2[5];
  uVar11 = param_2[7];
  puVar1 = (undefined8 *)(lVar4 + 0x30 + lVar12);
  *puVar1 = param_2[6];
  puVar1[1] = uVar11;
  puVar1 = (undefined8 *)(lVar4 + 0x20 + lVar12);
  *puVar1 = uVar9;
  puVar1[1] = uVar10;
  puVar1 = (undefined8 *)(lVar4 + 0x10 + lVar12);
  *puVar1 = uVar7;
  puVar1[1] = uVar8;
  *(undefined8 *)(lVar4 + lVar12) = uVar5;
  ((undefined8 *)(lVar4 + lVar12))[1] = uVar6;
  *(longlong *)(lVar2 + 8) = lVar3 + 1;
  return;
}

