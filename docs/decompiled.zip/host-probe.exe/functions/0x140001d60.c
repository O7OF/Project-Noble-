// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>>::slice_ranges::<core[505b25137b8ba7f]::ops::range::Range<usize>>
// address: 0x140001d60
// body: available
// range: 0x140001d60-0x140001e06 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,
   u64, core[505b25137b8ba7f]::net::socket_addr::SocketAddr, alloc[246c2e7857c81348]::vec::Vec<u8>,
   host_probe[b94139f9089eb1d8]::netstats::Kind)>>::slice_ranges::<core[505b25137b8ba7f]::ops::range::Range<usize>>
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>>
::slice_ranges::<core[505b25137b8ba7f]::ops::range::Range<usize>>
          (longlong *param_1,ulonglong *param_2,ulonglong param_3,ulonglong param_4,
          ulonglong param_5)

{
  ulonglong uVar1;
  code *pcVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  undefined **ppuVar7;
  
  if (param_5 < param_4) {
    ppuVar7 = &anon_553b4e5fea14f94d7b140aed25da7182_928_llvm_1181841624220042269;
    param_3 = 0;
  }
  else {
    uVar6 = param_4 - param_3;
    if (param_3 <= param_4) {
      if (uVar6 == 0) {
        param_1[2] = 0;
        param_1[3] = 0;
        *param_1 = 0;
        param_1[1] = 0;
        return param_1;
      }
      uVar1 = *param_2;
      uVar3 = 0;
      if (uVar1 <= param_3 + param_2[2]) {
        uVar3 = uVar1;
      }
      lVar5 = (param_3 + param_2[2]) - uVar3;
      *param_1 = lVar5;
      lVar4 = uVar6 - (uVar1 - lVar5);
      if (uVar1 - lVar5 <= uVar6 && lVar4 != 0) {
        param_1[1] = uVar1;
        param_1[2] = 0;
        param_1[3] = lVar4;
        return param_1;
      }
      param_1[1] = lVar5 + uVar6;
      param_1[2] = 0;
      param_1[3] = 0;
      return param_1;
    }
    ppuVar7 = &anon_553b4e5fea14f94d7b140aed25da7182_929_llvm_1181841624220042269;
  }
  core[505b25137b8ba7f]::slice::index::slice_index_fail(param_3,param_4,param_5,ppuVar7);
                    /* WARNING: Does not return */
  pcVar2 = (code *)invalidInstructionException();
  (*pcVar2)();
}

