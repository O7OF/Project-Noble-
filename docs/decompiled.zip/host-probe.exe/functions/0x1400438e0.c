// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<&str>,host_probe[b94139f9089eb1d8]::announce::prepare::{closure#6}>>
// address: 0x1400438e0
// body: available
// range: 0x1400438e0-0x140043971 inclusive
// range: 0x140043980-0x140043a0f inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<&str>,
   host_probe[b94139f9089eb1d8]::announce::prepare::{closure#6}>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::
<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<&str>,host_probe[b94139f9089eb1d8]::announce::prepare::_closure_6_>>
          (longlong *param_1,undefined8 *param_2,undefined8 *param_3)

{
  void *_Src;
  code *pcVar1;
  void *_Dst;
  undefined8 uVar2;
  undefined8 *puVar3;
  longlong lVar4;
  void *unaff_R12;
  ulonglong uVar5;
  
  uVar5 = (ulonglong)((longlong)param_3 - (longlong)param_2) >> 4;
  lVar4 = param_1[2];
  if ((ulonglong)(*param_1 - lVar4) < uVar5) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar4,uVar5,8,0x18);
    lVar4 = param_1[2];
  }
  if (param_2 == param_3) {
LAB_1400439bb:
    param_1[2] = lVar4;
    return;
  }
  if ((longlong)param_2[1] < 0) {
    uVar2 = 0;
  }
  else {
    puVar3 = (undefined8 *)(param_1[1] + lVar4 * 0x18 + 0x10);
    unaff_R12 = (void *)param_2[1];
    do {
      uVar5 = uVar5 - 1;
      if (unaff_R12 == (void *)0x0) {
        _Dst = (void *)0x1;
      }
      else {
        _Src = (void *)*param_2;
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        _Dst = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(unaff_R12,1);
        if (_Dst == (void *)0x0) {
          uVar2 = 1;
          goto LAB_1400439ae;
        }
        memcpy(_Dst,_Src,(size_t)unaff_R12);
      }
      puVar3[-2] = unaff_R12;
      puVar3[-1] = _Dst;
      *puVar3 = unaff_R12;
      if (uVar5 == 0) {
        lVar4 = lVar4 + 1;
        goto LAB_1400439bb;
      }
      unaff_R12 = (void *)param_2[3];
      param_2 = param_2 + 2;
      puVar3 = puVar3 + 3;
      lVar4 = lVar4 + 1;
    } while (-1 < (longlong)unaff_R12);
    uVar2 = 0;
    unaff_R12 = _Dst;
  }
LAB_1400439ae:
  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar2,unaff_R12);
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

