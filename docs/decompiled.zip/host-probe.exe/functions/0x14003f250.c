// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::flatten::FlatMap<core[505b25137b8ba7f]::slice::iter::Iter<u32>,[u8;4usize],host_probe[b94139f9089eb1d8]::host::armory::find_all::{closure#0}>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),u8)>>::call_mut
// address: 0x14003f250
// body: available
// range: 0x14003f250-0x14003f266 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,
   <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::flatten::FlatMap<core[505b25137b8ba7f]::slice::iter::Iter<u32>,
   [u8; 4usize],
   host_probe[b94139f9089eb1d8]::host::armory::find_all::{closure#0}>>::{closure#0}>::{closure#0} as
   core[505b25137b8ba7f]::ops::function::FnMut<((), u8)>>::call_mut */

void __rustcall
<&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::flatten::FlatMap<core[505b25137b8ba7f]::slice::iter::Iter<u32>,[u8;4usize],host_probe[b94139f9089eb1d8]::host::armory::find_all::{closure#0}>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),u8)>>
::call_mut(longlong *param_1,undefined1 param_2)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = *param_1;
  lVar2 = *(longlong *)(lVar1 + 8);
  *(undefined1 *)(*(longlong *)(lVar1 + 0x10) + lVar2) = param_2;
  *(longlong *)(lVar1 + 8) = lVar2 + 1;
  return;
}

