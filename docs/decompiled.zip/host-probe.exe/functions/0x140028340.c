// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::record
// address: 0x140028340
// body: available
// range: 0x140028340-0x1400287f2 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::record */

bool __rustcall
host_probe[b94139f9089eb1d8]::net::record(longlong param_1,ulonglong param_2,uint param_3)

{
  char *pcVar1;
  code *pcVar2;
  uint uVar3;
  byte bVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  ulonglong uVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong lVar11;
  ulonglong uVar12;
  undefined1 (*pauVar13) [16];
  DWORD dwTlsIndex;
  undefined1 (*pauVar14) [16];
  ushort uVar15;
  byte bVar16;
  bool bVar17;
  byte bVar18;
  undefined1 auVar19 [16];
  undefined1 auVar20 [16];
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  undefined1 local_68 [16];
  undefined8 local_58;
  longlong local_48;
  
  LOCK();
  bVar17 = SEEN == '\0';
  if (bVar17) {
    SEEN = '\x01';
  }
  UNLOCK();
  local_48 = param_1;
  if (!bVar17) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&SEEN);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar4 = 0;
    plVar9 = (longlong *)
             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
    ;
    pauVar14 = DAT_1407f00a8;
  }
  else {
    bVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar4 = bVar4 ^ 1;
    plVar9 = (longlong *)
             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
    ;
    pauVar14 = DAT_1407f00a8;
  }
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
       = (undefined *)plVar9;
  DAT_1407f00a8 = pauVar14;
  if (DAT_1407f00a1 != '\0') {
    local_68[8] = bVar4;
    local_68._0_8_ = &SEEN;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,local_68,
               &anon_d5c34e88a06ee720b116585eb143da4b_134_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2818);
LAB_1400287f1:
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  if (pauVar14 == (undefined1 (*) [16])0x0) {
    if (*plVar9 != 0) {
      std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
    }
    if ((int)plVar9[3] == 0) {
      dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                             (
                             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                             );
      plVar9 = TlsGetValue(dwTlsIndex);
    }
    else {
      dwTlsIndex = (int)plVar9[3] - 1;
      plVar9 = TlsGetValue(dwTlsIndex);
    }
    if (plVar9 < (longlong *)0x2) {
      plVar9 = (longlong *)
               <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
               ::try_initialize::
               <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                         (dwTlsIndex,plVar9,0);
    }
    if (plVar9 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
      goto LAB_1400287f1;
    }
    _DAT_1407f00c8 = *plVar9;
    lRam00000001407f00d0 = plVar9[1];
    *plVar9 = *plVar9 + 1;
    DAT_1407f00b8 = 0;
    DAT_1407f00c0 = 0;
    DAT_1407f00a8 = (undefined1 (*) [16])&DAT_1406a0540;
    DAT_1407f00b0 = 0;
    pauVar14 = (undefined1 (*) [16])&DAT_1406a0540;
  }
  else if (0x3ff < DAT_1407f00c0) {
    uVar8 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
            ::hash_one::<&usize>(&DAT_1407f00c8,&local_48);
    bVar16 = (byte)(uVar8 >> 0x39);
    auVar19 = ZEXT216(CONCAT11(bVar16,bVar16));
    auVar19 = pshuflw(auVar19,auVar19,0);
    lVar11 = 0;
    while( true ) {
      uVar8 = uVar8 & DAT_1407f00b0;
      pcVar1 = *pauVar14 + uVar8;
      auVar22[0] = -(*pcVar1 == auVar19[0]);
      auVar22[1] = -(pcVar1[1] == auVar19[1]);
      auVar22[2] = -(pcVar1[2] == auVar19[2]);
      auVar22[3] = -(pcVar1[3] == auVar19[3]);
      auVar22[4] = -(pcVar1[4] == auVar19[4]);
      auVar22[5] = -(pcVar1[5] == auVar19[5]);
      auVar22[6] = -(pcVar1[6] == auVar19[6]);
      auVar22[7] = -(pcVar1[7] == auVar19[7]);
      auVar22[8] = -(pcVar1[8] == auVar19[0]);
      auVar22[9] = -(pcVar1[9] == auVar19[1]);
      auVar22[10] = -(pcVar1[10] == auVar19[2]);
      auVar22[0xb] = -(pcVar1[0xb] == auVar19[3]);
      auVar22[0xc] = -(pcVar1[0xc] == auVar19[4]);
      auVar22[0xd] = -(pcVar1[0xd] == auVar19[5]);
      auVar22[0xe] = -(pcVar1[0xe] == auVar19[6]);
      auVar22[0xf] = -(pcVar1[0xf] == auVar19[7]);
      uVar15 = (ushort)(SUB161(auVar22 >> 7,0) & 1) | (ushort)(SUB161(auVar22 >> 0xf,0) & 1) << 1 |
               (ushort)(SUB161(auVar22 >> 0x17,0) & 1) << 2 |
               (ushort)(SUB161(auVar22 >> 0x1f,0) & 1) << 3 |
               (ushort)(SUB161(auVar22 >> 0x27,0) & 1) << 4 |
               (ushort)(SUB161(auVar22 >> 0x2f,0) & 1) << 5 |
               (ushort)(SUB161(auVar22 >> 0x37,0) & 1) << 6 |
               (ushort)(SUB161(auVar22 >> 0x3f,0) & 1) << 7 |
               (ushort)(SUB161(auVar22 >> 0x47,0) & 1) << 8 |
               (ushort)(SUB161(auVar22 >> 0x4f,0) & 1) << 9 |
               (ushort)(SUB161(auVar22 >> 0x57,0) & 1) << 10 |
               (ushort)(SUB161(auVar22 >> 0x5f,0) & 1) << 0xb |
               (ushort)(SUB161(auVar22 >> 0x67,0) & 1) << 0xc |
               (ushort)(SUB161(auVar22 >> 0x6f,0) & 1) << 0xd |
               (ushort)(SUB161(auVar22 >> 0x77,0) & 1) << 0xe | (ushort)(auVar22[0xf] >> 7) << 0xf;
      uVar6 = (uint)uVar15;
      while (uVar15 != 0) {
        uVar7 = 0;
        for (uVar3 = uVar6; (uVar3 & 1) == 0; uVar3 = uVar3 >> 1 | 0x80000000) {
          uVar7 = uVar7 + 1;
        }
        if (param_1 == *(longlong *)pauVar14[(uVar7 + uVar8 & DAT_1407f00b0) * -2 + -2])
        goto LAB_1400284cb;
        uVar15 = (ushort)(uVar6 - 1) & (ushort)uVar6;
        uVar6 = CONCAT22((short)(uVar6 - 1 >> 0x10),uVar15);
      }
      auVar20[0] = -(*pcVar1 == -1);
      auVar20[1] = -(pcVar1[1] == -1);
      auVar20[2] = -(pcVar1[2] == -1);
      auVar20[3] = -(pcVar1[3] == -1);
      auVar20[4] = -(pcVar1[4] == -1);
      auVar20[5] = -(pcVar1[5] == -1);
      auVar20[6] = -(pcVar1[6] == -1);
      auVar20[7] = -(pcVar1[7] == -1);
      auVar20[8] = -(pcVar1[8] == -1);
      auVar20[9] = -(pcVar1[9] == -1);
      auVar20[10] = -(pcVar1[10] == -1);
      auVar20[0xb] = -(pcVar1[0xb] == -1);
      auVar20[0xc] = -(pcVar1[0xc] == -1);
      auVar20[0xd] = -(pcVar1[0xd] == -1);
      auVar20[0xe] = -(pcVar1[0xe] == -1);
      auVar20[0xf] = -(pcVar1[0xf] == -1);
      if ((((((((((((((((SUB161(auVar20 >> 7,0) & 1) != 0 || (SUB161(auVar20 >> 0xf,0) & 1) != 0) ||
                      (SUB161(auVar20 >> 0x17,0) & 1) != 0) || (SUB161(auVar20 >> 0x1f,0) & 1) != 0)
                    || (SUB161(auVar20 >> 0x27,0) & 1) != 0) || (SUB161(auVar20 >> 0x2f,0) & 1) != 0
                   ) || (SUB161(auVar20 >> 0x37,0) & 1) != 0) ||
                 (SUB161(auVar20 >> 0x3f,0) & 1) != 0) || (SUB161(auVar20 >> 0x47,0) & 1) != 0) ||
               (SUB161(auVar20 >> 0x4f,0) & 1) != 0) || (SUB161(auVar20 >> 0x57,0) & 1) != 0) ||
             (SUB161(auVar20 >> 0x5f,0) & 1) != 0) || (SUB161(auVar20 >> 0x67,0) & 1) != 0) ||
           (SUB161(auVar20 >> 0x6f,0) & 1) != 0) || (SUB161(auVar20 >> 0x77,0) & 1) != 0) ||
          auVar20[0xf] < '\0') break;
      uVar8 = uVar8 + lVar11 + 0x10;
      lVar11 = lVar11 + 0x10;
    }
    if (((bVar4 == 0) &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar5 == '\0'))
    {
      DAT_1407f00a1 = '\x01';
    }
    bVar17 = false;
    goto LAB_140028698;
  }
LAB_1400284cb:
  uVar8 = DAT_1407f00b0;
  local_68._0_8_ = param_1;
  uVar10 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
           ::hash_one::<&usize>(&DAT_1407f00c8,local_68);
  bVar16 = (byte)(uVar10 >> 0x38);
  bVar18 = bVar16 >> 1;
  auVar19 = ZEXT216(CONCAT11(bVar18,bVar18));
  auVar19 = pshuflw(auVar19,auVar19,0);
  lVar11 = 0;
  uVar12 = uVar10;
  while( true ) {
    uVar12 = uVar12 & uVar8;
    pcVar1 = *pauVar14 + uVar12;
    auVar23[0] = -(*pcVar1 == auVar19[0]);
    auVar23[1] = -(pcVar1[1] == auVar19[1]);
    auVar23[2] = -(pcVar1[2] == auVar19[2]);
    auVar23[3] = -(pcVar1[3] == auVar19[3]);
    auVar23[4] = -(pcVar1[4] == auVar19[4]);
    auVar23[5] = -(pcVar1[5] == auVar19[5]);
    auVar23[6] = -(pcVar1[6] == auVar19[6]);
    auVar23[7] = -(pcVar1[7] == auVar19[7]);
    auVar23[8] = -(pcVar1[8] == auVar19[0]);
    auVar23[9] = -(pcVar1[9] == auVar19[1]);
    auVar23[10] = -(pcVar1[10] == auVar19[2]);
    auVar23[0xb] = -(pcVar1[0xb] == auVar19[3]);
    auVar23[0xc] = -(pcVar1[0xc] == auVar19[4]);
    auVar23[0xd] = -(pcVar1[0xd] == auVar19[5]);
    auVar23[0xe] = -(pcVar1[0xe] == auVar19[6]);
    auVar23[0xf] = -(pcVar1[0xf] == auVar19[7]);
    uVar15 = (ushort)(SUB161(auVar23 >> 7,0) & 1) | (ushort)(SUB161(auVar23 >> 0xf,0) & 1) << 1 |
             (ushort)(SUB161(auVar23 >> 0x17,0) & 1) << 2 |
             (ushort)(SUB161(auVar23 >> 0x1f,0) & 1) << 3 |
             (ushort)(SUB161(auVar23 >> 0x27,0) & 1) << 4 |
             (ushort)(SUB161(auVar23 >> 0x2f,0) & 1) << 5 |
             (ushort)(SUB161(auVar23 >> 0x37,0) & 1) << 6 |
             (ushort)(SUB161(auVar23 >> 0x3f,0) & 1) << 7 |
             (ushort)(SUB161(auVar23 >> 0x47,0) & 1) << 8 |
             (ushort)(SUB161(auVar23 >> 0x4f,0) & 1) << 9 |
             (ushort)(SUB161(auVar23 >> 0x57,0) & 1) << 10 |
             (ushort)(SUB161(auVar23 >> 0x5f,0) & 1) << 0xb |
             (ushort)(SUB161(auVar23 >> 0x67,0) & 1) << 0xc |
             (ushort)(SUB161(auVar23 >> 0x6f,0) & 1) << 0xd |
             (ushort)(SUB161(auVar23 >> 0x77,0) & 1) << 0xe | (ushort)(auVar23[0xf] >> 7) << 0xf;
    uVar6 = (uint)uVar15;
    while (uVar15 != 0) {
      uVar7 = 0;
      for (uVar3 = uVar6; (uVar3 & 1) == 0; uVar3 = uVar3 >> 1 | 0x80000000) {
        uVar7 = uVar7 + 1;
      }
      pauVar13 = pauVar14 + (uVar7 + uVar12 & uVar8) * -2;
      if (*(longlong *)pauVar13[-2] == param_1) goto LAB_140028613;
      uVar15 = (ushort)(uVar6 - 1) & (ushort)uVar6;
      uVar6 = CONCAT22((short)(uVar6 - 1 >> 0x10),uVar15);
    }
    auVar21[0] = -(*pcVar1 == -1);
    auVar21[1] = -(pcVar1[1] == -1);
    auVar21[2] = -(pcVar1[2] == -1);
    auVar21[3] = -(pcVar1[3] == -1);
    auVar21[4] = -(pcVar1[4] == -1);
    auVar21[5] = -(pcVar1[5] == -1);
    auVar21[6] = -(pcVar1[6] == -1);
    auVar21[7] = -(pcVar1[7] == -1);
    auVar21[8] = -(pcVar1[8] == -1);
    auVar21[9] = -(pcVar1[9] == -1);
    auVar21[10] = -(pcVar1[10] == -1);
    auVar21[0xb] = -(pcVar1[0xb] == -1);
    auVar21[0xc] = -(pcVar1[0xc] == -1);
    auVar21[0xd] = -(pcVar1[0xd] == -1);
    auVar21[0xe] = -(pcVar1[0xe] == -1);
    auVar21[0xf] = -(pcVar1[0xf] == -1);
    if ((((((((((((((((SUB161(auVar21 >> 7,0) & 1) != 0 || (SUB161(auVar21 >> 0xf,0) & 1) != 0) ||
                    (SUB161(auVar21 >> 0x17,0) & 1) != 0) || (SUB161(auVar21 >> 0x1f,0) & 1) != 0)
                  || (SUB161(auVar21 >> 0x27,0) & 1) != 0) || (SUB161(auVar21 >> 0x2f,0) & 1) != 0)
                || (SUB161(auVar21 >> 0x37,0) & 1) != 0) || (SUB161(auVar21 >> 0x3f,0) & 1) != 0) ||
              (SUB161(auVar21 >> 0x47,0) & 1) != 0) || (SUB161(auVar21 >> 0x4f,0) & 1) != 0) ||
            (SUB161(auVar21 >> 0x57,0) & 1) != 0) || (SUB161(auVar21 >> 0x5f,0) & 1) != 0) ||
          (SUB161(auVar21 >> 0x67,0) & 1) != 0) || (SUB161(auVar21 >> 0x6f,0) & 1) != 0) ||
        (SUB161(auVar21 >> 0x77,0) & 1) != 0) || auVar21[0xf] < '\0') break;
    uVar12 = uVar12 + lVar11 + 0x10;
    lVar11 = lVar11 + 0x10;
  }
  if (DAT_1407f00b8 == 0) {
    <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,(u64,usize,u64))>>::reserve_rehash::
    <hashbrown[ad6d4a1843b2832d]::map::make_hasher<u64,(u64,usize,u64),std[3bf9d48a0c3997f0]::hash::random::RandomState>::_closure_0_>
              (&DAT_1407f00a8,1,&DAT_1407f00c8);
    pauVar14 = DAT_1407f00a8;
    uVar8 = DAT_1407f00b0;
  }
  local_68 = (undefined1  [16])0x0;
  local_58 = 0;
  uVar10 = uVar10 & uVar8;
  auVar19 = *(undefined1 (*) [16])(*pauVar14 + uVar10);
  uVar15 = (ushort)(SUB161(auVar19 >> 7,0) & 1) | (ushort)(SUB161(auVar19 >> 0xf,0) & 1) << 1 |
           (ushort)(SUB161(auVar19 >> 0x17,0) & 1) << 2 |
           (ushort)(SUB161(auVar19 >> 0x1f,0) & 1) << 3 |
           (ushort)(SUB161(auVar19 >> 0x27,0) & 1) << 4 |
           (ushort)(SUB161(auVar19 >> 0x2f,0) & 1) << 5 |
           (ushort)(SUB161(auVar19 >> 0x37,0) & 1) << 6 |
           (ushort)(SUB161(auVar19 >> 0x3f,0) & 1) << 7 |
           (ushort)(SUB161(auVar19 >> 0x47,0) & 1) << 8 |
           (ushort)(SUB161(auVar19 >> 0x4f,0) & 1) << 9 |
           (ushort)(SUB161(auVar19 >> 0x57,0) & 1) << 10 |
           (ushort)(SUB161(auVar19 >> 0x5f,0) & 1) << 0xb |
           (ushort)(SUB161(auVar19 >> 0x67,0) & 1) << 0xc |
           (ushort)(SUB161(auVar19 >> 0x6f,0) & 1) << 0xd |
           (ushort)(SUB161(auVar19 >> 0x77,0) & 1) << 0xe | (ushort)(byte)(auVar19[0xf] >> 7) << 0xf
  ;
  uVar6 = (uint)uVar15;
  if (uVar15 == 0) {
    lVar11 = 0x10;
    do {
      uVar10 = uVar10 + lVar11 & uVar8;
      auVar19 = *(undefined1 (*) [16])(*pauVar14 + uVar10);
      lVar11 = lVar11 + 0x10;
      uVar6 = (uint)(ushort)((ushort)(SUB161(auVar19 >> 7,0) & 1) |
                             (ushort)(SUB161(auVar19 >> 0xf,0) & 1) << 1 |
                             (ushort)(SUB161(auVar19 >> 0x17,0) & 1) << 2 |
                             (ushort)(SUB161(auVar19 >> 0x1f,0) & 1) << 3 |
                             (ushort)(SUB161(auVar19 >> 0x27,0) & 1) << 4 |
                             (ushort)(SUB161(auVar19 >> 0x2f,0) & 1) << 5 |
                             (ushort)(SUB161(auVar19 >> 0x37,0) & 1) << 6 |
                             (ushort)(SUB161(auVar19 >> 0x3f,0) & 1) << 7 |
                             (ushort)(SUB161(auVar19 >> 0x47,0) & 1) << 8 |
                             (ushort)(SUB161(auVar19 >> 0x4f,0) & 1) << 9 |
                             (ushort)(SUB161(auVar19 >> 0x57,0) & 1) << 10 |
                             (ushort)(SUB161(auVar19 >> 0x5f,0) & 1) << 0xb |
                             (ushort)(SUB161(auVar19 >> 0x67,0) & 1) << 0xc |
                             (ushort)(SUB161(auVar19 >> 0x6f,0) & 1) << 0xd |
                             (ushort)(SUB161(auVar19 >> 0x77,0) & 1) << 0xe |
                            (ushort)(byte)(auVar19[0xf] >> 7) << 0xf);
    } while (uVar6 == 0);
  }
  uVar7 = 0;
  for (; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
    uVar7 = uVar7 + 1;
  }
  uVar12 = uVar7 + uVar10 & uVar8;
  bVar18 = (*pauVar14)[uVar12];
  if (-1 < (char)bVar18) {
    auVar19 = *pauVar14;
    uVar6 = 0;
    for (uVar7 = (uint)(ushort)((ushort)(SUB161(auVar19 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar19 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar19 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar19 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar19 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar19 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar19 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar19 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar19 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar19 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar19 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar19 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar19 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar19 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar19 >> 0x77,0) & 1) << 0xe |
                               (ushort)(byte)(auVar19[0xf] >> 7) << 0xf); (uVar7 & 1) == 0;
        uVar7 = uVar7 >> 1 | 0x80000000) {
      uVar6 = uVar6 + 1;
    }
    uVar12 = (ulonglong)uVar6;
    bVar18 = (*pauVar14)[uVar12];
  }
  bVar16 = bVar16 >> 1;
  (*pauVar14)[uVar12] = bVar16;
  pauVar14[1][uVar12 - 0x10 & uVar8] = bVar16;
  pauVar13 = pauVar14 + uVar12 * -2;
  *(longlong *)pauVar13[-2] = param_1;
  *(undefined8 *)(pauVar14[uVar12 * -2 + -2] + 8) = 0;
  *(undefined8 *)((longlong)(pauVar14[uVar12 * -2 + -2] + 8) + 8) = 0;
  *(undefined8 *)(pauVar13[-1] + 8) = 0;
  DAT_1407f00b8 = DAT_1407f00b8 - (ulonglong)(bVar18 & 1);
  DAT_1407f00c0 = DAT_1407f00c0 + 1;
LAB_140028613:
  uVar8 = (ulonglong)((param_3 & 0xff) << 4) | 0xffffffffffffffe8;
  uVar12 = *(longlong *)(*pauVar13 + uVar8) + 1;
  *(ulonglong *)(*pauVar13 + uVar8) = uVar12;
  uVar8 = *(ulonglong *)pauVar13[-1];
  if (*(ulonglong *)pauVar13[-1] < param_2) {
    uVar8 = param_2;
  }
  *(ulonglong *)pauVar13[-1] = uVar8;
  bVar17 = uVar12 < 9;
  if (((bVar4 == 0) &&
      ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
       0x7fffffffffffffff) != 0)) &&
     (cVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar5 == '\0')) {
    DAT_1407f00a1 = '\x01';
  }
LAB_140028698:
  cVar5 = SEEN;
  LOCK();
  SEEN = 0;
  UNLOCK();
  if (cVar5 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&SEEN);
  }
  return bVar17;
}

