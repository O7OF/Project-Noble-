// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::configure
// address: 0x1400388b0
// body: available
// range: 0x1400388b0-0x1400388fa inclusive
// range: 0x140038900-0x140038a56 inclusive
// range: 0x140038a60-0x140038ccc inclusive
// range: 0x140038cd2-0x140038ced inclusive
// range: 0x140038cf0-0x140038e64 inclusive
// range: 0x140038e70-0x14003a251 inclusive
// range: 0x14003a260-0x14003a4a6 inclusive
// range: 0x14003a4b0-0x14003abcc inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140038ae3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140038cc8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140039b85 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140039bbb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140039c8a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003a0ec to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003a185 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003a1bb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003a235 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003a2a3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003a73f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003a757 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::configure */

void __rustcall host_probe[b94139f9089eb1d8]::net::configure(longlong param_1,ulonglong param_2)

{
  char ******ppppppcVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  code *pcVar6;
  longlong lVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  undefined *puVar10;
  undefined *puVar11;
  undefined1 uVar12;
  char cVar13;
  byte bVar14;
  int iVar15;
  longlong lVar16;
  longlong *plVar17;
  char *pcVar18;
  ulonglong uVar19;
  char *******pppppppcVar20;
  char *pcVar21;
  ulonglong uVar22;
  uint uVar23;
  ulonglong uVar24;
  char *pcVar25;
  ulonglong uVar26;
  char *pcVar27;
  longlong *plVar28;
  longlong lVar29;
  char *******pppppppcVar30;
  char *******pppppppcVar31;
  DWORD DVar32;
  int iVar33;
  ulonglong uVar34;
  longlong lVar35;
  char *******pppppppcVar36;
  undefined8 *puVar37;
  bool bVar38;
  undefined4 uVar39;
  undefined8 uVar40;
  undefined1 local_461;
  ulonglong local_460;
  undefined8 local_458;
  undefined8 uStack_450;
  undefined8 local_448;
  undefined8 uStack_440;
  undefined8 local_438;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_424;
  ulonglong local_420;
  undefined4 local_414;
  undefined8 local_410;
  undefined4 uStack_408;
  undefined2 uStack_404;
  undefined2 uStack_402;
  undefined6 uStack_400;
  undefined2 uStack_3fa;
  undefined6 uStack_3f8;
  undefined2 uStack_3f2;
  undefined6 uStack_3f0;
  undefined8 local_3e8;
  undefined8 uStack_3e0;
  undefined8 local_3d8;
  undefined8 uStack_3d0;
  undefined8 local_3c8;
  undefined8 uStack_3c0;
  char cStack_3b8;
  undefined2 uStack_3b7;
  undefined1 uStack_3b5;
  undefined1 uStack_3b4;
  undefined2 uStack_3b3;
  undefined1 uStack_3b1;
  undefined8 uStack_3b0;
  byte local_3a8;
  char cStack_3a7;
  undefined6 uStack_3a6;
  char *****pppppcStack_3a0;
  char *****local_398;
  char *****pppppcStack_390;
  char *****local_388;
  char *****pppppcStack_380;
  char *****local_378;
  char *****local_338;
  undefined2 local_330;
  undefined8 local_32e;
  undefined8 uStack_326;
  undefined8 local_31e;
  undefined6 uStack_316;
  undefined2 uStack_310;
  undefined6 uStack_30e;
  longlong local_308;
  longlong lStack_300;
  undefined2 local_2f8;
  undefined8 local_2f0;
  undefined8 local_2e8;
  undefined8 local_2e0;
  undefined8 uStack_2d8;
  char ******local_2d0;
  char ******ppppppcStack_2c8;
  undefined8 *local_2c0;
  longlong lStack_2b8;
  undefined8 local_2b0;
  undefined8 uStack_2a8;
  undefined8 local_2a0;
  ulonglong local_298;
  undefined1 local_290;
  char local_28f;
  undefined4 local_28e;
  undefined2 local_28a;
  undefined4 local_280;
  undefined4 uStack_27c;
  undefined4 uStack_278;
  undefined4 uStack_274;
  longlong lStack_270;
  undefined8 local_268;
  undefined8 uStack_260;
  longlong local_258;
  ulonglong local_250;
  char ******local_248;
  char *****local_240;
  ulonglong local_238;
  ulonglong local_230;
  undefined8 local_220;
  longlong local_218;
  undefined8 local_210;
  char *****local_200;
  undefined8 local_1f8;
  undefined8 uStack_1f0;
  undefined8 uStack_1e8;
  undefined8 uStack_1e0;
  undefined8 local_1d8;
  undefined8 uStack_1d0;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined8 uStack_1c0;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined1 uStack_1b0;
  undefined7 uStack_1af;
  int local_1a8;
  undefined4 uStack_1a4;
  undefined1 uStack_1a0;
  undefined7 uStack_19f;
  undefined1 local_198;
  undefined7 uStack_197;
  undefined8 uStack_190;
  char *****local_188;
  undefined8 local_180;
  undefined8 uStack_178;
  undefined4 local_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined8 local_160;
  undefined8 local_158;
  byte local_150;
  byte local_14f;
  undefined1 local_14e;
  char local_9f;
  undefined4 local_9e;
  undefined2 local_9a;
  char ******local_98;
  undefined8 *puStack_90;
  longlong local_88;
  undefined8 uStack_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  
  if (param_2 == 0) {
    return;
  }
  lVar7 = param_2 * 0x18;
  lVar29 = 0;
  lVar16 = 0;
  while ((*(longlong *)(param_1 + 0x10 + lVar16) != 10 ||
         (plVar17 = *(longlong **)(param_1 + 8 + lVar16),
         (short)plVar17[1] != 0x666c || *plVar17 != 0x65732d74656e2d2d))) {
    lVar29 = lVar29 + 1;
    lVar16 = lVar16 + 0x18;
    if (lVar7 == lVar16) {
      return;
    }
  }
  if (param_2 <= lVar29 + 1U) {
    return;
  }
  lVar29 = *(longlong *)(param_1 + 0x20 + lVar16);
  uVar26 = *(ulonglong *)(param_1 + 0x28 + lVar16);
  local_420 = param_2;
  parse_endpoint(&local_3e8,lVar29,uVar26);
  lVar16 = CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0);
  if (lVar16 == -1) {
    return;
  }
  local_240 = (char *****)CONCAT44(local_3e8._4_4_,(undefined4)local_3e8);
  uVar34 = CONCAT44(local_3d8._4_4_,(undefined4)local_3d8);
  uVar40 = CONCAT44(uStack_3d0._4_4_,(undefined4)uStack_3d0);
  uVar22 = 0;
  local_460 = uVar34;
  do {
    uVar19 = lVar29 + uVar22;
    if (uVar26 - uVar22 < 0x10) {
      if (uVar26 == uVar22) break;
      uVar24 = 0;
      while (*(char *)(uVar19 + uVar24) != '@') {
        uVar24 = uVar24 + 1;
        if (uVar26 - uVar22 == uVar24) goto LAB_140038a49;
      }
    }
    else {
      uVar34 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned
                         (CONCAT71((int7)(uVar34 >> 8),0x40));
      uVar24 = uVar19;
      if ((uVar34 & 1) == 0) break;
    }
    uVar19 = uVar24 + uVar22 + 1;
    uVar34 = uVar24 + uVar22;
    if ((uVar34 < uVar26) && (*(char *)(lVar29 + uVar34) == '@')) {
      if (uVar26 - uVar19 < 0x10) {
        if (uVar26 != uVar19) {
          lVar35 = 0;
          goto LAB_140038a23;
        }
      }
      else {
        uVar26 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned
                           (CONCAT71((int7)(uVar34 >> 8),0x3a),lVar29 + uVar19);
        if ((uVar26 & 1) != 0) goto LAB_140038b05;
      }
      break;
    }
    uVar22 = uVar19;
  } while (uVar19 <= uVar26);
  goto LAB_140038a49;
LAB_140038e04:
  uVar34 = OOB_SIZE_0;
  if (0xfffffffffffffff < uVar19) goto LAB_140038e55;
  uVar24 = uVar19 * 0x10;
  bVar14 = pcVar18[lVar29 + uVar22];
  uVar23 = bVar14 - 0x30;
  if (0x39 < bVar14) {
    uVar23 = (bVar14 - 0x41 & 0xffffffdf) + 10;
  }
  uVar19 = uVar23 + uVar24;
  if ((CARRY8((ulonglong)uVar23,uVar24) || 0xf < uVar23) ||
     (lVar29 = lVar29 + 1, uVar34 = uVar19, lVar29 == -uVar22 + uVar26)) goto LAB_140038e55;
  goto LAB_140038e04;
  while( true ) {
    uVar19 = (ulonglong)uVar23 | uVar19 << 4;
    lVar29 = lVar29 + 1;
    uVar34 = uVar19;
    if (lVar29 == -uVar22 + uVar26) break;
LAB_140038dad:
    bVar14 = pcVar18[lVar29 + uVar22];
    uVar23 = bVar14 - 0x30;
    if (0x39 < bVar14) {
      uVar23 = (bVar14 - 0x41 & 0xffffffdf) + 10;
    }
    uVar34 = OOB_SIZE_0;
    if (0xf < uVar23) break;
  }
  goto LAB_140038e55;
  while( true ) {
    local_3c8 = (char *******)(pcVar25 + (longlong)pppppppcVar36 + 1);
    pppppppcVar36 = (char *******)(pcVar25 + (longlong)pppppppcVar36);
    if ((pppppppcVar36 < pppppppcVar31) &&
       (*(char *)((longlong)pppppppcVar36 + lVar29) == cStack_3b8)) {
      uVar26 = (longlong)pppppppcVar36 - (longlong)local_3e8;
      pppppppcVar31 = local_3c8;
      goto LAB_14003903d;
    }
    pppppppcVar36 = local_3c8;
    if (pppppppcVar31 < local_3c8) break;
LAB_140038f93:
    pcVar18 = (char *)((longlong)pppppppcVar36 + lVar29);
    local_3c8 = pppppppcVar31;
    if (&DAT_0000000f < (char *)((longlong)pppppppcVar31 - (longlong)pppppppcVar36)) {
      local_3c8 = pppppppcVar36;
      uVar26 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(0x2c);
      pcVar25 = pcVar18;
      local_3c8 = pppppppcVar31;
      if ((uVar26 & 1) == 0) break;
    }
    else {
      if (pppppppcVar31 == pppppppcVar36) break;
      pcVar25 = (char *)0x0;
      while (pcVar18[(longlong)pcVar25] != ',') {
        pcVar25 = pcVar25 + 1;
        if ((char *)((longlong)pppppppcVar31 - (longlong)pppppppcVar36) == pcVar25)
        goto LAB_14003900f;
      }
    }
  }
LAB_14003900f:
  cStack_3a7 = '\x01';
  uVar26 = (longlong)uStack_3e0 - (longlong)local_3e8;
  pppppppcVar31 = local_3e8;
  if ((uVar26 != 0 | local_3a8) != 1) {
LAB_14003ab8f:
    if (CONCAT44(uStack_27c,local_280) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (CONCAT44(uStack_274,uStack_278),CONCAT44(uStack_27c,local_280) << 3,8);
      return;
    }
LAB_14003abb3:
    core[505b25137b8ba7f]::panicking::panic_fmt
              ("--net-sim wants <loss %>,<delay ms>[,<jitter ms>[,<burst>]]",0x77,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a3188);
    goto LAB_14003abcb;
  }
LAB_14003903d:
  pcVar18 = (char *)((longlong)local_3e8 + lVar29);
  local_3e8 = pppppppcVar31;
  pcVar25 = (char *)::<str>::trim_matches::<<char>::is_whitespace>(pcVar18);
  pppppppcVar36 = uStack_3c0;
  pppppppcVar31 = uStack_3d0;
  pcVar18 = pcVar25;
  if (uVar26 == 0) {
LAB_14003906b:
    bVar38 = true;
  }
  else {
    if (uVar26 == 1) {
      cVar13 = *pcVar25;
      if ((cVar13 == '+') || (cVar13 == '-')) goto LAB_14003906b;
    }
    else {
      cVar13 = *pcVar25;
    }
    uVar34 = (ulonglong)(cVar13 == '+');
    if (uVar26 - uVar34 < 0x11) {
      if (uVar26 == uVar34) {
        bVar38 = false;
        pcVar18 = (char *)0x0;
      }
      else {
        pcVar18 = (char *)0x0;
        lVar29 = 0;
        do {
          bVar38 = 9 < (byte)pcVar25[lVar29 + uVar34] - 0x30;
          if (bVar38) break;
          pcVar18 = (char *)((ulonglong)((byte)pcVar25[lVar29 + uVar34] - 0x30) +
                            (longlong)pcVar18 * 10);
          lVar29 = lVar29 + 1;
        } while (lVar29 != uVar26 + -uVar34);
      }
    }
    else {
      pcVar18 = (char *)0x0;
      lVar29 = 0;
      do {
        auVar3._8_8_ = 0;
        auVar3._0_8_ = pcVar18;
        pcVar18 = SUB168(auVar3 * ZEXT816(10),0);
        if (SUB168(auVar3 * ZEXT816(10),8) != 0) goto LAB_14003906b;
        uVar23 = (byte)pcVar25[lVar29 + uVar34] - 0x30;
        bVar38 = CARRY8((ulonglong)pcVar18,(ulonglong)uVar23);
        pcVar18 = pcVar18 + uVar23;
        if ((9 < uVar23) || (bVar38)) goto LAB_14003906b;
        lVar29 = lVar29 + 1;
        bVar38 = false;
      } while (lVar29 != uVar26 + -uVar34);
    }
  }
  if (cStack_3a7 != '\0') goto LAB_14003ab8f;
  lVar29 = CONCAT44(local_3d8._4_4_,(undefined4)local_3d8);
  if (local_3c8 <= uStack_3c0 && uStack_3c0 <= uStack_3d0) {
    pppppppcVar20 = (char *******)(ulonglong)(byte)uStack_3b0;
    cVar13 = *(char *)((longlong)pppppppcVar20 + (longlong)&uStack_3c0 + 7);
    pppppppcVar30 = local_3c8;
    do {
      pcVar25 = (char *)((longlong)pppppppcVar30 + lVar29);
      if (&DAT_0000000f < (char *)((longlong)pppppppcVar36 - (longlong)pppppppcVar30)) {
        uVar26 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(cVar13);
        pcVar27 = pcVar25;
        local_3c8 = pppppppcVar36;
        if ((uVar26 & 1) == 0) break;
      }
      else {
        local_3c8 = pppppppcVar36;
        if (pppppppcVar36 == pppppppcVar30) break;
        pcVar27 = (char *)0x0;
        while (pcVar25[(longlong)pcVar27] != cVar13) {
          pcVar27 = pcVar27 + 1;
          if ((char *)((longlong)pppppppcVar36 - (longlong)pppppppcVar30) == pcVar27)
          goto LAB_14003916e;
        }
      }
      pppppppcVar30 = (char *******)((char *)((longlong)pppppppcVar30 + (longlong)pcVar27) + 1);
      local_3c8 = pppppppcVar30;
      if (pppppppcVar30 <= pppppppcVar31 && pppppppcVar20 <= pppppppcVar30) {
        iVar33 = memcmp((char *)((longlong)pppppppcVar30 + (lVar29 - (longlong)pppppppcVar20)),
                        &cStack_3b8,(size_t)pppppppcVar20);
        if (iVar33 == 0) {
          pcVar25 = (char *)((longlong)pppppppcVar30 +
                            (-(longlong)local_3e8 - (longlong)pppppppcVar20));
          goto LAB_14003919e;
        }
      }
    } while (pppppppcVar30 <= pppppppcVar36);
  }
LAB_14003916e:
  cStack_3a7 = '\x01';
  pcVar25 = (char *)((longlong)uStack_3e0 - (longlong)local_3e8);
  pppppppcVar30 = local_3e8;
  if (pcVar25 == (char *)0x0 && local_3a8 == 0) goto LAB_14003ab8f;
LAB_14003919e:
  pcVar27 = (char *)((longlong)local_3e8 + lVar29);
  local_3e8 = pppppppcVar30;
  pcVar27 = (char *)::<str>::trim_matches::<<char>::is_whitespace>(pcVar27);
  pppppppcVar36 = uStack_3c0;
  pppppppcVar31 = uStack_3d0;
  if (pcVar25 == (char *)0x1) {
    cVar13 = *pcVar27;
    if ((cVar13 != '+') && (cVar13 != '-')) goto LAB_1400391d9;
    goto LAB_14003ab8f;
  }
  if (pcVar25 == (char *)0x0) goto LAB_14003ab8f;
  cVar13 = *pcVar27;
LAB_1400391d9:
  pcVar21 = (char *)(ulonglong)(cVar13 == '+');
  if ((ulonglong)((longlong)pcVar25 - (longlong)pcVar21) < 0x11) {
    if (pcVar25 == pcVar21) {
      uVar26 = 0;
    }
    else {
      uVar26 = 0;
      lVar29 = 0;
      do {
        if (9 < (byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30) goto LAB_14003ab8f;
        uVar26 = (ulonglong)((byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30) + uVar26 * 10;
        lVar29 = lVar29 + 1;
      } while (lVar29 != -(longlong)pcVar21 + (longlong)pcVar25);
    }
  }
  else {
    uVar26 = 0;
    lVar29 = 0;
    do {
      auVar2._8_8_ = 0;
      auVar2._0_8_ = uVar26;
      uVar34 = SUB168(auVar2 * ZEXT816(10),0);
      if (SUB168(auVar2 * ZEXT816(10),8) != 0) goto LAB_14003ab8f;
      uVar23 = (byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30;
      uVar26 = uVar34 + uVar23;
      if ((9 < uVar23) || (CARRY8(uVar34,(ulonglong)uVar23))) goto LAB_14003ab8f;
      lVar29 = lVar29 + 1;
    } while (lVar29 != -(longlong)pcVar21 + (longlong)pcVar25);
  }
  if (bVar38) goto LAB_14003ab8f;
  if (cStack_3a7 == '\0') {
    lVar29 = CONCAT44(local_3d8._4_4_,(undefined4)local_3d8);
    if (local_3c8 <= uStack_3c0 && uStack_3c0 <= uStack_3d0) {
      pppppppcVar20 = (char *******)(ulonglong)(byte)uStack_3b0;
      cVar13 = *(char *)((longlong)pppppppcVar20 + (longlong)&uStack_3c0 + 7);
      pppppppcVar30 = local_3c8;
      do {
        pcVar25 = (char *)((longlong)pppppppcVar30 + lVar29);
        if (&DAT_0000000f < (char *)((longlong)pppppppcVar36 - (longlong)pppppppcVar30)) {
          uVar34 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(cVar13);
          pcVar27 = pcVar25;
          local_3c8 = pppppppcVar36;
          if ((uVar34 & 1) == 0) break;
        }
        else {
          local_3c8 = pppppppcVar36;
          if (pppppppcVar36 == pppppppcVar30) break;
          pcVar27 = (char *)0x0;
          while (pcVar25[(longlong)pcVar27] != cVar13) {
            pcVar27 = pcVar27 + 1;
            if ((char *)((longlong)pppppppcVar36 - (longlong)pppppppcVar30) == pcVar27)
            goto LAB_140039443;
          }
        }
        pppppppcVar30 = (char *******)((char *)((longlong)pppppppcVar30 + (longlong)pcVar27) + 1);
        local_3c8 = pppppppcVar30;
        if (pppppppcVar30 <= pppppppcVar31 && pppppppcVar20 <= pppppppcVar30) {
          iVar33 = memcmp((char *)((longlong)pppppppcVar30 + (lVar29 - (longlong)pppppppcVar20)),
                          &cStack_3b8,(size_t)pppppppcVar20);
          if (iVar33 == 0) {
            pcVar25 = (char *)((longlong)pppppppcVar30 +
                              (-(longlong)local_3e8 - (longlong)pppppppcVar20));
            goto LAB_140039471;
          }
        }
      } while (pppppppcVar30 <= pppppppcVar36);
    }
LAB_140039443:
    cStack_3a7 = '\x01';
    pcVar25 = (char *)((longlong)uStack_3e0 - (longlong)local_3e8);
    pppppppcVar30 = local_3e8;
    if ((pcVar25 != (char *)0x0 | local_3a8) != 1) goto LAB_140039514;
LAB_140039471:
    pcVar27 = (char *)((longlong)local_3e8 + lVar29);
    local_3e8 = pppppppcVar30;
    pcVar27 = (char *)::<str>::trim_matches::<<char>::is_whitespace>(pcVar27);
    if (pcVar25 == (char *)0x1) {
      cVar13 = *pcVar27;
      if ((cVar13 != '+') && (cVar13 != '-')) goto LAB_1400394bb;
      goto LAB_14003ab8f;
    }
    if (pcVar25 == (char *)0x0) goto LAB_14003ab8f;
    cVar13 = *pcVar27;
LAB_1400394bb:
    pcVar21 = (char *)(ulonglong)(cVar13 == '+');
    pppppppcVar31 = local_3c8;
    pppppppcVar36 = uStack_3c0;
    if ((ulonglong)((longlong)pcVar25 - (longlong)pcVar21) < 0x11) {
      if (pcVar25 == pcVar21) goto LAB_140039514;
      uVar34 = 0;
      lVar29 = 0;
      do {
        if (9 < (byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30) goto LAB_14003ab8f;
        uVar34 = (ulonglong)((byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30) + uVar34 * 10;
        lVar29 = lVar29 + 1;
      } while (lVar29 != -(longlong)pcVar21 + (longlong)pcVar25);
    }
    else {
      uVar34 = 0;
      lVar29 = 0;
      do {
        auVar4._8_8_ = 0;
        auVar4._0_8_ = uVar34;
        uVar22 = SUB168(auVar4 * ZEXT816(10),0);
        if (SUB168(auVar4 * ZEXT816(10),8) != 0) goto LAB_14003ab8f;
        uVar23 = (byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30;
        uVar34 = uVar22 + uVar23;
        if ((9 < uVar23) || (CARRY8(uVar22,(ulonglong)uVar23))) goto LAB_14003ab8f;
        lVar29 = lVar29 + 1;
      } while (lVar29 != -(longlong)pcVar21 + (longlong)pcVar25);
    }
  }
  else {
LAB_140039514:
    uVar34 = 0;
    pppppppcVar31 = local_3c8;
    pppppppcVar36 = uStack_3c0;
  }
  iVar33 = 1;
  local_3c8 = pppppppcVar31;
  uStack_3c0 = pppppppcVar36;
  if (cStack_3a7 == '\0') {
    local_250 = uVar34;
    lVar29 = CONCAT44(local_3d8._4_4_,(undefined4)local_3d8);
    local_248 = (char ******)uStack_3d0;
    if (pppppppcVar31 <= pppppppcVar36 && pppppppcVar36 <= uStack_3d0) {
      pppppppcVar30 = (char *******)(ulonglong)(byte)uStack_3b0;
      cVar13 = *(char *)((longlong)pppppppcVar30 + (longlong)&uStack_3c0 + 7);
      do {
        pcVar25 = (char *)((longlong)pppppppcVar31 + lVar29);
        if (&DAT_0000000f < (char *)((longlong)pppppppcVar36 - (longlong)pppppppcVar31)) {
          uVar34 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(cVar13);
          pcVar27 = pcVar25;
          local_3c8 = pppppppcVar36;
          if ((uVar34 & 1) == 0) break;
        }
        else {
          local_3c8 = pppppppcVar36;
          if (pppppppcVar36 == pppppppcVar31) break;
          pcVar27 = (char *)0x0;
          while (pcVar25[(longlong)pcVar27] != cVar13) {
            pcVar27 = pcVar27 + 1;
            if ((char *)((longlong)pppppppcVar36 - (longlong)pppppppcVar31) == pcVar27)
            goto LAB_140039642;
          }
        }
        pppppppcVar31 = (char *******)((char *)((longlong)pppppppcVar31 + (longlong)pcVar27) + 1);
        local_3c8 = pppppppcVar31;
        if (pppppppcVar31 <= local_248 && pppppppcVar30 <= pppppppcVar31) {
          iVar15 = memcmp((char *)((longlong)pppppppcVar31 + (lVar29 - (longlong)pppppppcVar30)),
                          &cStack_3b8,(size_t)pppppppcVar30);
          if (iVar15 == 0) {
            pcVar25 = (char *)((longlong)pppppppcVar31 +
                              (-(longlong)local_3e8 - (longlong)pppppppcVar30));
            goto LAB_140039675;
          }
        }
      } while (pppppppcVar31 <= pppppppcVar36);
    }
LAB_140039642:
    cStack_3a7 = '\x01';
    pcVar25 = (char *)((longlong)uStack_3e0 - (longlong)local_3e8);
    uVar34 = local_250;
    pppppppcVar31 = local_3e8;
    if (pcVar25 != (char *)0x0 || local_3a8 != 0) {
LAB_140039675:
      uVar34 = local_250;
      pcVar27 = (char *)((longlong)local_3e8 + lVar29);
      local_3e8 = pppppppcVar31;
      pcVar27 = (char *)::<str>::trim_matches::<<char>::is_whitespace>(pcVar27);
      pppppppcVar31 = uStack_3c0;
      if (pcVar25 == (char *)0x1) {
        cVar13 = *pcVar27;
        if ((cVar13 != '+') && (cVar13 != '-')) goto LAB_140039707;
      }
      else if (pcVar25 != (char *)0x0) {
        cVar13 = *pcVar27;
LAB_140039707:
        pcVar21 = (char *)(ulonglong)(cVar13 == '+');
        if ((ulonglong)((longlong)pcVar25 - (longlong)pcVar21) < 0x11) {
          if (pcVar25 == pcVar21) {
            uVar22 = 0;
          }
          else {
            uVar22 = 0;
            lVar29 = 0;
            do {
              if (9 < (byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30) goto LAB_14003ab8f;
              uVar22 = (ulonglong)((byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30) + uVar22 * 10
              ;
              lVar29 = lVar29 + 1;
            } while (lVar29 != -(longlong)pcVar21 + (longlong)pcVar25);
          }
        }
        else {
          uVar22 = 0;
          lVar29 = 0;
          do {
            auVar5._8_8_ = 0;
            auVar5._0_8_ = uVar22;
            uVar19 = SUB168(auVar5 * ZEXT816(10),0);
            if (SUB168(auVar5 * ZEXT816(10),8) != 0) goto LAB_14003ab8f;
            uVar23 = (byte)pcVar27[(longlong)(pcVar21 + lVar29)] - 0x30;
            uVar22 = uVar19 + uVar23;
            if ((9 < uVar23) || (CARRY8(uVar19,(ulonglong)uVar23))) goto LAB_14003ab8f;
            lVar29 = lVar29 + 1;
          } while (lVar29 != -(longlong)pcVar21 + (longlong)pcVar25);
        }
        iVar33 = (int)uVar22 + (uint)(uVar22 == 0);
        if (cStack_3a7 == '\0') {
          lVar29 = CONCAT44(local_3d8._4_4_,(undefined4)local_3d8);
          if (local_3c8 <= uStack_3c0 && uStack_3c0 <= uStack_3d0) {
            pppppppcVar20 = (char *******)(ulonglong)(byte)uStack_3b0;
            cVar13 = *(char *)((longlong)pppppppcVar20 + (longlong)&uStack_3c0 + 7);
            pppppppcVar30 = uStack_3d0;
            pppppppcVar36 = local_3c8;
            local_248 = (char ******)uStack_3d0;
            do {
              pcVar25 = (char *)((longlong)pppppppcVar36 + lVar29);
              if (&DAT_0000000f < (char *)((longlong)pppppppcVar31 - (longlong)pppppppcVar36)) {
                uVar34 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(cVar13);
                pcVar27 = pcVar25;
                local_3c8 = pppppppcVar31;
                if ((uVar34 & 1) == 0) break;
              }
              else {
                local_3c8 = pppppppcVar31;
                if (pppppppcVar31 == pppppppcVar36) break;
                pcVar27 = (char *)0x0;
                while (pcVar25[(longlong)pcVar27] != cVar13) {
                  pcVar27 = pcVar27 + 1;
                  if ((char *)((longlong)pppppppcVar31 - (longlong)pppppppcVar36) == pcVar27)
                  goto LAB_1400398d3;
                }
              }
              pppppppcVar36 =
                   (char *******)((char *)((longlong)pppppppcVar36 + (longlong)pcVar27) + 1);
              local_3c8 = pppppppcVar36;
              if (pppppppcVar36 <= pppppppcVar30 && pppppppcVar20 <= pppppppcVar36) {
                iVar15 = memcmp((char *)((longlong)pppppppcVar36 +
                                        (lVar29 - (longlong)pppppppcVar20)),&cStack_3b8,
                                (size_t)pppppppcVar20);
                pppppppcVar30 = (char *******)local_248;
                if (iVar15 == 0) {
                  pcVar25 = (char *)((longlong)pppppppcVar36 +
                                    (-(longlong)local_3e8 - (longlong)pppppppcVar20));
                  goto LAB_14003ab7d;
                }
              }
            } while (pppppppcVar36 <= pppppppcVar31);
          }
LAB_1400398d3:
          cStack_3a7 = '\x01';
          pcVar25 = (char *)((longlong)uStack_3e0 - (longlong)local_3e8);
          pppppppcVar36 = local_3e8;
          if ((local_3a8 != 0) || (uVar34 = local_250, uStack_3e0 != local_3e8)) {
LAB_14003ab7d:
            pcVar18 = (char *)((longlong)local_3e8 + lVar29);
            local_3e8 = pppppppcVar36;
            ::<str>::trim_matches::<<char>::is_whitespace>(pcVar18,pcVar25);
            goto LAB_14003ab8f;
          }
        }
        goto LAB_140039910;
      }
      goto LAB_14003ab8f;
    }
  }
LAB_140039910:
  if (&DAT_00000064 < pcVar18) goto LAB_14003ab8f;
  puVar10 = (undefined *)CONCAT44(uStack_27c,local_280);
  if (puVar10 == (undefined *)0xffffffffffffffff) goto LAB_14003abb3;
  uVar22 = uVar34 / 1000;
  uVar34 = uVar34 % 1000;
  local_1a8 = (int)uVar34 * 1000000;
  uStack_1c0 = (char ******)(uVar26 / 1000);
  uVar26 = uVar26 % 1000;
  iStack_1b8 = (int)uVar26 * 1000000;
  uStack_1f0 = CONCAT44(uStack_274,uStack_278);
  uStack_1e8 = lStack_270;
  uStack_1e0 = 0;
  local_1d8 = 8;
  uStack_1d0 = 0;
  uStack_1c8 = 0;
  uStack_1c4 = 0;
  uStack_1b0 = (undefined1)uVar22;
  uStack_1af = (undefined7)(uVar22 >> 8);
  uStack_1a0 = (undefined1)((ulonglong)local_200 ^ 0x9e3779b97f4a7c15);
  uStack_19f = (undefined7)(((ulonglong)local_200 ^ 0x9e3779b97f4a7c15) >> 8);
  local_198 = 0;
  uStack_197 = 0;
  uStack_190 = (char ******)CONCAT44(iVar33,(int)pcVar18);
  local_188 = (char *****)((ulonglong)local_188 & 0xffffffff00000000);
  local_238 = uVar26 + (longlong)uStack_1c0 * 1000;
  local_230 = (ulonglong)CARRY8(uVar26,(longlong)uStack_1c0 * 1000);
  local_268 = uVar34 + uVar22 * 1000;
  uStack_260 = (ulonglong)CARRY8(uVar34,uVar22 * 1000);
  local_1f8 = puVar10;
  if (lStack_270 == 0) {
    local_458 = (char *******)0x0;
    uStack_450 = (undefined **)0x1;
    local_448 = (undefined8 *)0x0;
  }
  else {
    local_458 = (char *******)&local_1f8;
    uStack_450 = (undefined **)
                 <alloc[246c2e7857c81348]::vec::Vec<u64>as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_3e8,&DAT_1406a2eb0,&local_458);
    local_458 = local_3e8;
    uStack_450 = (undefined **)uStack_3e0;
    local_448 = (undefined8 *)CONCAT44(local_3d8._4_4_,(undefined4)local_3d8);
  }
  local_3e8 = (char *******)&uStack_190;
  local_3d8 = (char *)((longlong)&uStack_190 + 4);
  uStack_3e0._0_4_ = 0x4068fc20;
  uStack_3e0._4_4_ = 1;
  uStack_3d0._0_4_ = 0x4068fc20;
  uStack_3d0._4_4_ = 1;
  local_3c8 = (char *******)&local_238;
  uStack_3c0._0_4_ = 0x40688b80;
  uStack_3c0._4_4_ = 1;
  cStack_3b8 = (char)&local_268;
  uStack_3b7 = (undefined2)((ulonglong)&local_268 >> 8);
  uStack_3b5 = (undefined1)((ulonglong)&local_268 >> 0x18);
  uStack_3b4 = (undefined1)((ulonglong)&local_268 >> 0x20);
  uStack_3b3 = (undefined2)((ulonglong)&local_268 >> 0x28);
  uStack_3b1 = (undefined1)((ulonglong)&local_268 >> 0x38);
  uStack_3b0._0_4_ = 0x40688b80;
  uStack_3b0._4_4_ = 1;
  local_3a8 = (byte)&local_458;
  cStack_3a7 = (char)((ulonglong)&local_458 >> 8);
  uStack_3a6 = (undefined6)((ulonglong)&local_458 >> 0x10);
  pppppcStack_3a0 =
       (char *****)
       &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_410,&DAT_1406a2ec1,&local_3e8);
  if (local_458 != (char *******)0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_450,local_458,1);
    return;
  }
  lVar29 = CONCAT26(local_410._6_2_,CONCAT24(local_410._4_2_,(undefined4)local_410));
  uVar40 = CONCAT26(uStack_402,CONCAT24(uStack_404,uStack_408));
  host::log(uVar40,CONCAT26(uStack_3fa,uStack_400));
  if (lVar29 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar40,lVar29,1);
    return;
  }
  local_378 = local_188;
  local_388 = (char *****)CONCAT71(uStack_197,local_198);
  pppppcStack_380 = (char *****)uStack_190;
  local_398 = (char *****)CONCAT44(uStack_1a4,local_1a8);
  pppppcStack_390 = (char *****)CONCAT71(uStack_19f,uStack_1a0);
  pppppcStack_3a0 = (char *****)CONCAT71(uStack_1af,uStack_1b0);
  local_3a8 = (byte)iStack_1b8;
  cStack_3a7 = (char)((uint)iStack_1b8 >> 8);
  uStack_3a6 = (undefined6)(CONCAT44(uStack_1b4,iStack_1b8) >> 0x10);
  cStack_3b8 = (char)uStack_1c8;
  uStack_3b7 = (undefined2)((uint)uStack_1c8 >> 8);
  uStack_3b5 = (undefined1)((uint)uStack_1c8 >> 0x18);
  uStack_3b4 = (undefined1)uStack_1c4;
  uStack_3b3 = (undefined2)((uint)uStack_1c4 >> 8);
  uStack_3b1 = (undefined1)((uint)uStack_1c4 >> 0x18);
  local_3c8._0_4_ = (undefined4)local_1d8;
  local_3c8._4_4_ = local_1d8._4_4_;
  uStack_3c0._0_4_ = (undefined4)uStack_1d0;
  uStack_3c0._4_4_ = uStack_1d0._4_4_;
  local_3d8._0_4_ = (undefined4)uStack_1e8;
  local_3d8._4_4_ = uStack_1e8._4_4_;
  uStack_3d0._0_4_ = (undefined4)uStack_1e0;
  uStack_3d0._4_4_ = uStack_1e0._4_4_;
  local_3e8._0_4_ = (undefined4)local_1f8;
  local_3e8._4_4_ = local_1f8._4_4_;
  uStack_3e0._0_4_ = (uint)uStack_1f0;
  uStack_3e0._4_4_ = uStack_1f0._4_4_;
  uStack_3b0 = uStack_1c0;
  <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
  ::lock(&local_458,&IMPAIR);
  pppppppcVar31 = (char *******)uStack_450;
  cVar13 = (char)local_448;
  if ((int)local_458 == 1) {
    local_410._0_4_ = SUB84(uStack_450,0);
    local_410._4_2_ = (undefined2)((ulonglong)uStack_450 >> 0x20);
    local_410._6_2_ = (undefined2)((ulonglong)uStack_450 >> 0x30);
    uStack_408 = CONCAT31(uStack_408._1_3_,(char)local_448);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_410,
               &anon_d5c34e88a06ee720b116585eb143da4b_138_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2f10);
    goto LAB_14003abcb;
  }
  pppppppcVar36 = (char *******)(uStack_450 + 1);
  ppppppcVar1 = (char ******)uStack_450[1];
  if (ppppppcVar1 != (char ******)0xffffffffffffffff) {
    if (ppppppcVar1 != (char ******)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_450[2],(longlong)ppppppcVar1 << 3,8);
      return;
    }
    core[505b25137b8ba7f]::ptr::drop_glue::
    <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>>
              (uStack_450 + 4);
  }
  pppppppcVar31[0xf] = (char ******)local_378;
  pppppppcVar31[0xd] = (char ******)local_388;
  pppppppcVar31[0xe] = (char ******)pppppcStack_380;
  pppppppcVar31[0xb] = (char ******)local_398;
  pppppppcVar31[0xc] = (char ******)pppppcStack_390;
  pppppppcVar31[9] = (char ******)CONCAT62(uStack_3a6,CONCAT11(cStack_3a7,local_3a8));
  pppppppcVar31[10] = (char ******)pppppcStack_3a0;
  *(uint *)(pppppppcVar31 + 7) = CONCAT13(uStack_3b5,CONCAT21(uStack_3b7,cStack_3b8));
  *(uint *)((longlong)pppppppcVar31 + 0x3c) = CONCAT13(uStack_3b1,CONCAT21(uStack_3b3,uStack_3b4));
  pppppppcVar31[8] = uStack_3b0;
  *(undefined4 *)(pppppppcVar31 + 5) = (undefined4)local_3c8;
  *(undefined4 *)((longlong)pppppppcVar31 + 0x2c) = local_3c8._4_4_;
  *(undefined4 *)(pppppppcVar31 + 6) = (undefined4)uStack_3c0;
  *(undefined4 *)((longlong)pppppppcVar31 + 0x34) = uStack_3c0._4_4_;
  *(undefined4 *)(pppppppcVar31 + 3) = (undefined4)local_3d8;
  *(undefined4 *)((longlong)pppppppcVar31 + 0x1c) = local_3d8._4_4_;
  *(undefined4 *)(pppppppcVar31 + 4) = (undefined4)uStack_3d0;
  *(undefined4 *)((longlong)pppppppcVar31 + 0x24) = uStack_3d0._4_4_;
  *(undefined4 *)pppppppcVar36 = (undefined4)local_3e8;
  *(undefined4 *)((longlong)pppppppcVar31 + 0xc) = local_3e8._4_4_;
  *(uint *)(pppppppcVar31 + 2) = (uint)uStack_3e0;
  *(undefined4 *)((longlong)pppppppcVar31 + 0x14) = uStack_3e0._4_4_;
  if ((cVar13 == '\0') &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar13 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar13 == '\0') {
      *(char *)((longlong)pppppppcVar31 + 1) = '\x01';
    }
  }
  LOCK();
  cVar13 = *(char *)pppppppcVar31;
  *(char *)pppppppcVar31 = '\0';
  UNLOCK();
  if (cVar13 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pppppppcVar31);
  }
  goto LAB_140039d25;
  while (lVar35 = lVar35 + 1, (~uVar22 + uVar26) - uVar24 != lVar35) {
LAB_140038a23:
    if (*(char *)(lVar29 + uVar19 + lVar35) == ':') goto LAB_140038b05;
  }
LAB_140038a49:
  lVar29 = 0;
  do {
    if ((*(longlong *)(param_1 + 0x10 + lVar29) == 9) &&
       (plVar17 = *(longlong **)(param_1 + 8 + lVar29),
       (char)plVar17[1] == 'n' && *plVar17 == 0x616c2d74656e2d2d)) {
      ::<str>::replacen::<&str>(&local_3e8,local_460,uVar40,&DAT_1406a2ea0,9,&DAT_1406a2ea9,7,1);
      if (lVar16 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_460,lVar16,1);
        return;
      }
      lVar16 = CONCAT44(local_3e8._4_4_,(undefined4)local_3e8);
      local_460 = CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0);
      uVar40 = CONCAT44(local_3d8._4_4_,(undefined4)local_3d8);
      break;
    }
    lVar29 = lVar29 + 0x18;
  } while (lVar7 != lVar29);
LAB_140038b05:
  uVar26 = local_460;
  reach_directory[4b72b9694f6c3c08]::lan::local_bind(&local_218,local_460,uVar40);
  puVar10 = 
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
  ;
  uVar39 = (undefined4)uVar26;
  if (*(longlong *)
       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
      != 0) {
    std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
  }
  if (*(int *)(puVar10 + 0x18) == 0) {
    DVar32 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                       (
                       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                       );
    plVar17 = TlsGetValue(DVar32);
  }
  else {
    DVar32 = *(int *)(puVar10 + 0x18) - 1;
    plVar17 = TlsGetValue(DVar32);
  }
  if (plVar17 < (longlong *)0x2) {
    plVar28 = plVar17;
    plVar17 = (longlong *)
              <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
              ::try_initialize::
              <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                        (DVar32,plVar17,0);
    uVar39 = SUB84(plVar28,0);
  }
  if (plVar17 == (longlong *)0x0) {
    std[3bf9d48a0c3997f0]::thread::local::panic_access_error
              (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
    goto LAB_14003abcb;
  }
  local_78 = (undefined4)*plVar17;
  uStack_74 = *(undefined4 *)((longlong)plVar17 + 4);
  uStack_70 = (undefined4)plVar17[1];
  uStack_6c = *(undefined4 *)((longlong)plVar17 + 0xc);
  *plVar17 = *plVar17 + 1;
  local_88 = 0;
  uStack_80 = 0;
  local_98 = (char ******)&DAT_1406a0540;
  puStack_90 = (undefined8 *)0x0;
  local_220 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  uVar34 = 1;
  lVar29 = 0;
  uVar26 = local_420;
  local_414 = uVar39;
  do {
    if (((*(longlong *)(param_1 + 0x10 + lVar29) == 10) &&
        (plVar17 = *(longlong **)(param_1 + 8 + lVar29),
        (short)plVar17[1] == 0x7265 && *plVar17 == 0x65702d74656e2d2d)) && (uVar34 < uVar26)) {
      parse_endpoint(&local_410,*(undefined8 *)(param_1 + 0x20 + lVar29),
                     *(undefined8 *)(param_1 + 0x28 + lVar29));
      lVar35 = CONCAT26(uStack_402,CONCAT24(uStack_404,uStack_408));
      if (lVar35 != -1) {
        uVar40 = CONCAT26(local_410._6_2_,CONCAT24(local_410._4_2_,(undefined4)local_410));
        uVar9 = CONCAT26(uStack_3fa,uStack_400);
        <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::str::traits::FromStr>
        ::from_str(&local_458,uVar9,CONCAT26(uStack_3f2,uStack_3f8));
        if ((short)local_458 != 2) {
          local_3c8._0_4_ = (undefined4)local_448;
          local_3c8._4_4_ = local_448._4_4_;
          uStack_3c0._0_4_ = (undefined4)uStack_440;
          uStack_3c0._4_4_ = uStack_440._4_4_;
          local_3d8._0_4_ = (int)local_458;
          local_3d8._4_4_ = local_458._4_4_;
          uStack_3d0._0_4_ = (undefined4)uStack_450;
          uStack_3d0._4_4_ = uStack_450._4_4_;
          cStack_3b8 = '\0';
          local_3e8._0_4_ = (undefined4)local_220;
          local_3e8._4_4_ = (undefined4)((ulonglong)local_220 >> 0x20);
          uStack_3e0._0_4_ = local_414;
          <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
          ::insert(&local_1f8,&local_98,uVar40,&local_3e8);
        }
        uVar26 = local_420;
        if (lVar35 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar9,lVar35,1);
          return;
        }
      }
    }
    lVar29 = lVar29 + 0x18;
    uVar34 = uVar34 + 1;
  } while (lVar7 != lVar29);
  lVar29 = 0;
  lVar35 = 0;
  do {
    uVar34 = OOB_SIZE_0;
    if ((*(longlong *)(param_1 + 0x10 + lVar29) == 0xe) &&
       (plVar17 = *(longlong **)(param_1 + 8 + lVar29),
       *(longlong *)((longlong)plVar17 + 6) == 0x657a69732d626f6f && *plVar17 == 0x6f6f2d74656e2d2d)
       ) {
      if (uVar26 <= lVar35 + 1U) break;
      uVar26 = *(ulonglong *)(param_1 + 0x28 + lVar29);
      pcVar18 = (char *)::<str>::trim_start_matches::<&str>
                                  (*(undefined8 *)(param_1 + 0x20 + lVar29),uVar26,
                                   &
                                   anon_d5c34e88a06ee720b116585eb143da4b_38_llvm_14435704873730135342
                                   ,2);
      uVar34 = OOB_SIZE_0;
      if (uVar26 == 0) break;
      if (uVar26 == 1) {
        cVar13 = *pcVar18;
        if ((cVar13 == '+') || (cVar13 == '-')) break;
      }
      else {
        cVar13 = *pcVar18;
      }
      uVar22 = (ulonglong)(cVar13 == '+');
      if (0x10 < uVar26 - uVar22) {
        lVar29 = 0;
        uVar19 = 0;
        goto LAB_140038e04;
      }
      if (uVar26 != uVar22) {
        lVar29 = 0;
        uVar19 = 0;
        goto LAB_140038dad;
      }
      uVar34 = 0;
      break;
    }
    lVar35 = lVar35 + 1;
    lVar29 = lVar29 + 0x18;
  } while (lVar7 != lVar29);
LAB_140038e55:
  OOB_SIZE_0 = uVar34;
  lVar29 = 0;
  lVar35 = 0;
  do {
    if ((*(longlong *)(param_1 + 0x10 + lVar35) == 9) &&
       (plVar17 = *(longlong **)(param_1 + 8 + lVar35),
       (char)plVar17[1] == 'm' && *plVar17 == 0x69732d74656e2d2d)) {
      uStack_1c0 = (char ******)CONCAT44(uStack_1c0._4_4_,(undefined4)uStack_1c0);
      uStack_3b0 = (char ******)CONCAT44(uStack_3b0._4_4_,(undefined4)uStack_3b0);
      if (1U - lVar29 < local_420) {
        local_3e8._0_4_ = (undefined4)param_1;
        local_3e8._4_4_ = (undefined4)((ulonglong)param_1 >> 0x20);
        uStack_3e0 = (char *******)(param_1 + lVar7);
        local_3d8._0_4_ = 0;
        local_3d8._4_4_ = 0;
        local_3c8._0_4_ = (undefined4)local_420;
        local_3c8._4_4_ = (undefined4)(local_420 >> 0x20);
        uStack_3d0._0_4_ = (undefined4)local_3e8;
        uStack_3d0._4_4_ = local_3e8._4_4_;
        <alloc[246c2e7857c81348]::vec::Vec<u64>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<u64,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::slice::iter::Iter<alloc[246c2e7857c81348]::string::String>>,host_probe[b94139f9089eb1d8]::net::configure::{closure#10}>,host_probe[b94139f9089eb1d8]::net::configure::{closure#11}>,host_probe[b94139f9089eb1d8]::net::configure::{closure#12}>>>
        ::from_iter(&local_280);
        lVar29 = *(longlong *)(lVar35 + 0x20 + param_1);
        pppppppcVar31 = *(char ********)(lVar35 + 0x28 + param_1);
        local_3e8._0_4_ = 0;
        local_3e8._4_4_ = 0;
        local_3d8._0_4_ = (undefined4)lVar29;
        local_3d8._4_4_ = (undefined4)((ulonglong)lVar29 >> 0x20);
        cStack_3b8 = ',';
        uStack_3b7 = 0;
        uStack_3b5 = 0;
        uStack_3b4 = 0x2c;
        uStack_3b3 = 0;
        uStack_3b1 = 0;
        uStack_3b0._0_4_ = CONCAT31(uStack_3b0._1_3_,1);
        local_3a8 = 1;
        cStack_3a7 = '\0';
        local_200 = local_240;
        pppppppcVar36 = (char *******)0x0;
        uStack_3e0 = pppppppcVar31;
        uStack_3d0 = pppppppcVar31;
        uStack_3c0 = pppppppcVar31;
        goto LAB_140038f93;
      }
      break;
    }
    lVar35 = lVar35 + 0x18;
    lVar29 = lVar29 + -1;
  } while (lVar7 != lVar35);
LAB_140039d25:
  LOCK();
  bVar38 = PREBOUND == '\0';
  if (bVar38) {
    PREBOUND = '\x01';
  }
  UNLOCK();
  if (!bVar38) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&PREBOUND);
  }
  puVar10 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar14 = 0;
    uVar26 = DAT_1406997c0;
  }
  else {
    bVar14 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar14 = bVar14 ^ 1;
    uVar26 = DAT_1406997c0;
  }
  if (DAT_1406997b9 != '\0') {
    local_3e8._0_4_ = 0x406997b8;
    local_3e8._4_4_ = 1;
    uStack_3e0._1_3_ = (undefined3)((uint)uStack_3e0 >> 8);
    uStack_3e0._0_4_ = CONCAT31(uStack_3e0._1_3_,bVar14);
    DAT_1406997c0 = uVar26;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_3e8,
               &anon_d5c34e88a06ee720b116585eb143da4b_143_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2f28);
    goto LAB_14003abcb;
  }
  DAT_1406997c0 = 0xffffffffffffffff;
  if (uVar26 == 0xffffffffffffffff) {
    lVar29 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::bind::
             <&alloc[246c2e7857c81348]::string::String>(&local_218);
    if (lVar29 == 1) {
      local_3e8._0_4_ = (undefined4)uVar26;
      local_3e8._4_4_ = (undefined4)(uVar26 >> 0x20);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("cannot bind UDP port",0x14,&local_3e8,
                 &PTR_<core[505b25137b8ba7f]::io::error::Error>_1406a0d90,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2f58);
      goto LAB_14003abcb;
    }
  }
  local_238 = uVar26;
  if ((bVar14 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) {
    cVar13 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar13 == '\0') {
      DAT_1406997b9 = '\x01';
    }
  }
  cVar13 = PREBOUND;
  LOCK();
  PREBOUND = '\0';
  UNLOCK();
  if (cVar13 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&PREBOUND);
  }
  uVar34 = <std[3bf9d48a0c3997f0]::net::tcp::TcpStream>::set_read_timeout(&local_238);
  uStack_3e0 = (char *******)CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0);
  if (((uVar34 != 0) &&
      (uStack_3e0 = (char *******)CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0),
      1 < ((uint)uVar34 & 3) - 2)) &&
     (uStack_3e0 = (char *******)CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0), (uVar34 & 3) != 0)) {
    uStack_3e0 = (char *******)(uVar34 - 1);
    local_3e8._0_4_ = CONCAT31(local_3e8._1_3_,3);
    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&uStack_3e0);
  }
  lVar29 = <std[3bf9d48a0c3997f0]::net::tcp::TcpStream>::set_nonblocking(&local_238,1);
  if (lVar29 != 0) {
    local_3e8._0_4_ = (undefined4)lVar29;
    local_3e8._4_4_ = (undefined4)((ulonglong)lVar29 >> 0x20);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("cannot make socket non-blocking",0x1f,&local_3e8,
               &PTR_<core[505b25137b8ba7f]::io::error::Error>_1406a0d90,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2f90);
    goto LAB_14003abcb;
  }
  LOCK();
  bVar38 = PENDING_RELAY_PEERS == '\0';
  if (bVar38) {
    PENDING_RELAY_PEERS = '\x01';
  }
  UNLOCK();
  if (!bVar38) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&PENDING_RELAY_PEERS);
  }
  if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) == 0) {
    bVar14 = 0;
    lVar29 = DAT_140699648;
    pppppppcVar31 = uStack_3e0;
  }
  else {
    bVar14 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar14 = bVar14 ^ 1;
    lVar29 = DAT_140699648;
    pppppppcVar31 = uStack_3e0;
  }
  uStack_3e0._4_4_ = (undefined4)((ulonglong)pppppppcVar31 >> 0x20);
  if (DAT_140699631 != '\0') {
    local_3e8._0_4_ = 0x40699630;
    local_3e8._4_4_ = 1;
    uStack_3e0._1_3_ = (undefined3)((ulonglong)pppppppcVar31 >> 8);
    uStack_3e0._0_4_ = CONCAT31(uStack_3e0._1_3_,bVar14);
    DAT_140699648 = lVar29;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_3e8,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1070
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2fa8);
    goto LAB_14003abcb;
  }
  DAT_140699648 = 0;
  pppppppcVar36 = (char *******)(DAT_140699640 + lVar29 * 7);
  local_448 = &DAT_140699638;
  local_438 = 0;
  uStack_450 = (undefined **)pppppppcVar36;
  uStack_440 = lVar29;
  if (lVar29 != 0) {
    puVar37 = DAT_140699640;
    do {
      local_3c8._0_4_ = *(undefined4 *)(puVar37 + 2);
      local_3c8._4_4_ = *(undefined4 *)((longlong)puVar37 + 0x14);
      uStack_3c0._0_4_ = *(undefined4 *)(puVar37 + 3);
      uStack_3c0._4_4_ = *(undefined4 *)((longlong)puVar37 + 0x1c);
      local_3d8._0_4_ = (undefined4)*puVar37;
      local_3d8._4_4_ = (undefined4)((ulonglong)*puVar37 >> 0x20);
      uStack_3d0._0_4_ = (undefined4)puVar37[1];
      uStack_3d0._4_4_ = (undefined4)((ulonglong)puVar37[1] >> 0x20);
      cStack_3b8 = '\x01';
      uVar39 = *(undefined4 *)(puVar37 + 5);
      uVar8 = *(undefined4 *)((longlong)puVar37 + 0x2c);
      uStack_3b7 = (undefined2)uVar39;
      uStack_3b5 = (undefined1)((uint)uVar39 >> 0x10);
      uStack_3b4 = (undefined1)((uint)uVar39 >> 0x18);
      uStack_3b3 = (undefined2)uVar8;
      uStack_3b1 = (undefined1)((uint)uVar8 >> 0x10);
      uStack_3b0._1_3_ = (undefined3)*(undefined4 *)(puVar37 + 6);
      uStack_3b0._0_4_ = CONCAT31(uStack_3b0._1_3_,(char)((uint)uVar8 >> 0x18));
      uStack_3b0._5_3_ = (undefined3)*(undefined4 *)((longlong)puVar37 + 0x34);
      uStack_3b0._4_4_ =
           CONCAT31(uStack_3b0._5_3_,(char)((uint)*(undefined4 *)(puVar37 + 6) >> 0x18));
      local_3a8 = (byte)((uint)*(undefined4 *)((longlong)puVar37 + 0x34) >> 0x18);
      local_3e8._0_4_ = (undefined4)local_220;
      local_3e8._4_4_ = (undefined4)((ulonglong)local_220 >> 0x20);
      uStack_3e0._0_4_ = local_414;
      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
      ::insert(&local_1f8,&local_98,puVar37[4],&local_3e8);
      pppppppcVar31 = (char *******)CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0);
      pppppppcVar30 = (char *******)(puVar37 + 7);
      puVar37 = puVar37 + 7;
    } while (pppppppcVar30 != pppppppcVar36);
  }
  uStack_3e0 = pppppppcVar31;
  if ((bVar14 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar13 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar13 == '\0') {
      DAT_140699631 = '\x01';
    }
  }
  uVar34 = local_420;
  puVar10 = 
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
  ;
  cVar13 = PENDING_RELAY_PEERS;
  LOCK();
  PENDING_RELAY_PEERS = '\0';
  UNLOCK();
  if (cVar13 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&PENDING_RELAY_PEERS);
  }
  <std[3bf9d48a0c3997f0]::net::tcp::TcpStream>::local_addr(&local_1f8,&local_238);
  <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
            (&local_280,&local_218);
  if ((short)local_1f8 == 2) {
    local_258 = lStack_270;
    local_268 = CONCAT44(uStack_27c,local_280);
    uStack_260 = CONCAT44(uStack_274,uStack_278);
    if ((1 < ((uint)uStack_1f0 & 3) - 2) && ((uStack_1f0 & 3) != 0)) {
      uStack_3e0 = (char *******)(uStack_1f0 - 1);
      local_3e8._0_4_ = CONCAT31(local_3e8._1_3_,3);
      <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
      drop(&uStack_3e0);
    }
  }
  else {
    local_3d8._0_4_ = (undefined4)uStack_1e8;
    local_3d8._4_4_ = uStack_1e8._4_4_;
    uStack_3d0._0_4_ = (undefined4)uStack_1e0;
    uStack_3d0._4_4_ = uStack_1e0._4_4_;
    local_3e8._0_4_ = (undefined4)local_1f8;
    local_3e8._4_4_ = local_1f8._4_4_;
    uStack_3e0._0_4_ = (uint)uStack_1f0;
    uStack_3e0._4_4_ = uStack_1f0._4_4_;
    local_410._0_4_ = 0;
    local_410._4_2_ = 0;
    local_410._6_2_ = 0;
    uStack_408 = 1;
    uStack_404 = 0;
    uStack_402 = 0;
    uStack_400 = 0;
    uStack_3fa = 0;
    local_448 = (undefined8 *)0x60000020;
    local_458 = (char *******)&local_410;
    uStack_450 = &PTR_<alloc[246c2e7857c81348]::string::String>_1406a3830;
    cVar13 = <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::fmt::Display>
             ::fmt(&local_3e8,&local_458);
    if (cVar13 != '\0') {
      core[505b25137b8ba7f]::result::unwrap_failed
                ("a Display implementation returned an error unexpectedly",0x37,&local_461,
                 &DAT_1406a1170,&PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
      goto LAB_14003abcb;
    }
    local_258 = CONCAT26(uStack_3fa,uStack_400);
    local_268 = CONCAT44(CONCAT22(local_410._6_2_,local_410._4_2_),(undefined4)local_410);
    uStack_260 = CONCAT44(CONCAT22(uStack_402,uStack_404),uStack_408);
    if (CONCAT44(uStack_27c,local_280) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (CONCAT44(uStack_274,uStack_278),CONCAT44(uStack_27c,local_280),1);
      return;
    }
  }
  local_3e8 = (char *******)&local_240;
  uStack_3e0._0_4_ = 0x4068f030;
  uStack_3e0._4_4_ = 1;
  local_3d8 = (char *)&local_268;
  uStack_3d0._0_4_ = 0x40041f60;
  uStack_3d0._4_4_ = 1;
  local_3c8 = &local_98;
  uStack_3c0._0_4_ = 0x4029a070;
  uStack_3c0._4_4_ = 1;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_1f8,&DAT_1406a2fc0,&local_3e8);
  uVar22 = uStack_1f0;
  puVar11 = local_1f8;
  if (local_268 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_260,local_268,1);
    return;
  }
  host::log(uStack_1f0,uStack_1e8);
  if (puVar11 != (undefined *)0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar22,puVar11,1);
    return;
  }
  uVar39 = std[3bf9d48a0c3997f0]::env::var::inner(&local_3e8,"RR_NET_MESH");
  if (local_3e8 == (char *******)0xfffffffffffffffe) {
    lVar29 = CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0);
    bVar38 = lVar29 != -1;
    if (((lVar29 == -1) || (CONCAT44(uStack_3d0._4_4_,(undefined4)uStack_3d0) != 1)) ||
       (bVar38 = true, *local_3d8 != '1')) goto LAB_14003a243;
    bVar14 = 0;
LAB_14003a298:
    if (lVar29 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar39,lVar29,1);
      return;
    }
  }
  else {
    if ((local_3e8 != (char *******)0xffffffffffffffff) && (local_3e8 != (char *******)0x0)) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0),local_3e8,1);
      return;
    }
    lVar29 = -1;
    bVar38 = false;
LAB_14003a243:
    lVar35 = 0;
    do {
      if ((*(longlong *)(param_1 + 0x10 + lVar35) == 10) &&
         (plVar17 = *(longlong **)(param_1 + 8 + lVar35),
         (short)plVar17[1] == 0x6873 && *plVar17 == 0x656d2d74656e2d2d)) {
        bVar14 = 0;
        goto LAB_14003a294;
      }
      lVar35 = lVar35 + 0x18;
    } while (lVar7 != lVar35);
    bVar14 = 1;
LAB_14003a294:
    if (bVar38) goto LAB_14003a298;
  }
  pcVar18 = 
  "net: star off (RR_NET_MESH=1 / --net-mesh): guests connect to each other and see each other\'s IP addresses"
  ;
  if (bVar14 != 0) {
    pcVar18 = 
    "net: star on (host-only routing, the default); a guest that does not negotiate it reaches the host only"
    ;
  }
  host::log(pcVar18,(bVar14 ^ 1) * '\x03' + 'g');
  <reach_directory[4b72b9694f6c3c08]::lobby_profile::Profile>::from_args(&local_1f8,param_1,uVar34);
  if (local_1f8 == (undefined *)0xffffffffffffffff) {
    uVar12 = (undefined1)uStack_1f0;
    uStack_430 = local_78;
    uStack_42c = uStack_74;
    uStack_428 = uStack_70;
    uStack_424 = uStack_6c;
    uStack_440 = local_88;
    local_438 = uStack_80;
    uStack_450 = (undefined **)local_98;
    local_448 = puStack_90;
    local_458 = (char *******)((ulonglong)local_458 & 0xffffffffffff0000);
    if (*(longlong *)puVar10 != 0) {
      std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
    }
    if (*(int *)(puVar10 + 0x18) == 0) {
      DVar32 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                         (
                         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                         );
      plVar17 = TlsGetValue(DVar32);
    }
    else {
      DVar32 = *(int *)(puVar10 + 0x18) - 1;
      plVar17 = TlsGetValue(DVar32);
    }
    if (plVar17 < (longlong *)0x2) {
      plVar17 = (longlong *)
                <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                ::try_initialize::
                <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                          (DVar32,plVar17,0);
    }
    if (plVar17 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
    }
    else {
      uStack_1e8 = 0;
      uStack_1e0 = 0;
      local_1f8 = &DAT_1406a0540;
      uStack_1f0 = 0;
      local_1d8 = *plVar17;
      uStack_1d0 = plVar17[1];
      *plVar17 = *plVar17 + 1;
      if (*(longlong *)puVar10 != 0) {
        std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
      }
      if (*(int *)(puVar10 + 0x18) == 0) {
        DVar32 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                           (
                           __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                           );
        plVar17 = TlsGetValue(DVar32);
      }
      else {
        DVar32 = *(int *)(puVar10 + 0x18) - 1;
        plVar17 = TlsGetValue(DVar32);
      }
      pppppppcVar31 = local_3e8;
      if (plVar17 < (longlong *)0x2) {
        plVar17 = (longlong *)
                  <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                  ::try_initialize::
                  <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                            (DVar32,plVar17,0);
        pppppppcVar31 = local_3e8;
      }
      local_3e8._0_4_ = SUB84(pppppppcVar31,0);
      if (plVar17 == (longlong *)0x0) {
        local_3e8 = pppppppcVar31;
        std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                  (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
      }
      else {
        uStack_1a0 = (undefined1)local_1d8;
        uStack_3c0._0_4_ = (undefined4)((ulonglong)local_1d8 >> 8);
        uStack_3c0._7_1_ = (undefined1)uStack_1d0;
        uStack_3c0._4_4_ = CONCAT13(uStack_3c0._7_1_,(int3)((ulonglong)local_1d8 >> 0x28));
        cStack_3b8 = (char)((ulonglong)uStack_1d0 >> 8);
        uStack_3b7 = (undefined2)((ulonglong)uStack_1d0 >> 0x10);
        uStack_3b5 = (undefined1)((ulonglong)uStack_1d0 >> 0x20);
        uStack_3b4 = (undefined1)((ulonglong)uStack_1d0 >> 0x28);
        uStack_3b3 = (undefined2)((ulonglong)uStack_1d0 >> 0x30);
        uStack_1b0 = (undefined1)uStack_1e8;
        uStack_3d0._0_4_ = (undefined4)((ulonglong)uStack_1e8 >> 8);
        uStack_3d0._7_1_ = (undefined1)uStack_1e0;
        uStack_3d0._4_4_ = CONCAT13(uStack_3d0._7_1_,(int3)((ulonglong)uStack_1e8 >> 0x28));
        local_3c8._0_4_ = (undefined4)((ulonglong)uStack_1e0 >> 8);
        local_3c8._4_3_ = (undefined3)((ulonglong)uStack_1e0 >> 0x28);
        local_3c8._4_4_ = CONCAT13(uStack_1a0,local_3c8._4_3_);
        local_3e8._4_3_ = (undefined3)((ulonglong)pppppppcVar31 >> 0x20);
        local_3e8._7_1_ = SUB81(local_1f8,0);
        uStack_3e0._0_4_ = (uint)((ulonglong)local_1f8 >> 8);
        uStack_3e0._4_3_ = (undefined3)((ulonglong)local_1f8 >> 0x28);
        uStack_3e0._7_1_ = (undefined1)uStack_1f0;
        local_3d8._0_4_ = (undefined4)(uStack_1f0 >> 8);
        local_3d8._4_3_ = (undefined3)(uStack_1f0 >> 0x28);
        local_3d8._4_4_ = CONCAT13(uStack_1b0,local_3d8._4_3_);
        uStack_1c4 = (undefined4)(CONCAT44(local_3e8._4_4_,(undefined4)local_3e8) >> 0x18);
        uStack_1c0._0_4_ = SUB84(local_1f8,0);
        uStack_1c0._4_4_ = (undefined4)(CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0) >> 0x18);
        iStack_1b8 = (int)uStack_1f0;
        uStack_1b4 = (undefined4)(CONCAT44(local_3d8._4_4_,(undefined4)local_3d8) >> 0x18);
        uStack_1af = (undefined7)CONCAT44(uStack_3d0._4_4_,(undefined4)uStack_3d0);
        local_1a8 = (int)uStack_1e0;
        uStack_1a4 = (undefined4)(CONCAT44(local_3c8._4_4_,(undefined4)local_3c8) >> 0x18);
        uStack_19f = (undefined7)CONCAT44(uStack_3c0._4_4_,(undefined4)uStack_3c0);
        uStack_197 = (undefined7)((ulonglong)uStack_1d0 >> 8);
        local_1f8 = (undefined *)((ulonglong)local_1f8 & 0xffffffffffff0000);
        uStack_1e8 = CONCAT44(uStack_1e8._4_4_,0xffffffff);
        local_1d8 = CONCAT44(local_1d8._4_4_,0xffffffff);
        uStack_1c8 = CONCAT31((int3)pppppppcVar31,2);
        local_180 = 0;
        uStack_178 = 0;
        uStack_190 = (char ******)&DAT_1406a0540;
        local_188 = (char *****)0x0;
        local_170 = (undefined4)*plVar17;
        uStack_16c = *(undefined4 *)((longlong)plVar17 + 4);
        uStack_168 = (undefined4)plVar17[1];
        uStack_164 = *(undefined4 *)((longlong)plVar17 + 0xc);
        *plVar17 = *plVar17 + 1;
        local_160 = 0;
        local_158 = 1;
        local_14e = 0;
        lVar29 = 0;
        do {
          if ((*(longlong *)(param_1 + 0x10 + lVar29) == 10) &&
             (plVar17 = *(longlong **)(param_1 + 8 + lVar29),
             (short)plVar17[1] == 0x7473 && *plVar17 == 0x6575672d73612d2d)) {
            cVar13 = '\x01';
            goto LAB_14003a4e2;
          }
          lVar29 = lVar29 + 0x18;
        } while (lVar7 != lVar29);
        cVar13 = '\0';
LAB_14003a4e2:
        local_198 = uStack_3c0._7_1_;
        local_150 = bVar14;
        local_14f = bVar14;
        if (*(longlong *)puVar10 != 0) {
          std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
        }
        if (*(int *)(puVar10 + 0x18) == 0) {
          DVar32 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                             (
                             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                             );
          plVar17 = TlsGetValue(DVar32);
        }
        else {
          DVar32 = *(int *)(puVar10 + 0x18) - 1;
          plVar17 = TlsGetValue(DVar32);
        }
        if (plVar17 < (longlong *)0x2) {
          plVar17 = (longlong *)
                    <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                    ::try_initialize::
                    <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                              (DVar32,plVar17,0);
        }
        if (plVar17 == (longlong *)0x0) {
          std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                    (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
        }
        else {
          uStack_3fa = 0;
          uStack_3f8 = 0;
          uStack_3f2 = 0;
          uStack_3f0 = 0;
          local_410._6_2_ = 0x540;
          uStack_408 = 0x1406a;
          uStack_404 = 0;
          uStack_402 = 0;
          uStack_400 = 0;
          lVar7 = *plVar17;
          lVar29 = plVar17[1];
          *plVar17 = *plVar17 + 1;
          uStack_30e = 0;
          local_32e = CONCAT26(0x540,CONCAT24(local_410._4_2_,(undefined4)local_410));
          uStack_326 = 0x1406a;
          local_31e = 0;
          uStack_316 = 0;
          uStack_310 = 0;
          uStack_2a8 = CONCAT44(uStack_42c,uStack_430);
          local_2d0 = (char ******)local_458;
          ppppppcStack_2c8 = (char ******)uStack_450;
          local_2c0 = local_448;
          lStack_2b8 = uStack_440;
          local_2b0 = local_438;
          local_2a0 = CONCAT44(uStack_424,uStack_428);
          memcpy(&local_3e8,&local_1f8,0xb0);
          local_338 = local_240;
          local_330 = 0;
          local_2f8 = 0;
          local_2f0 = 0;
          local_2e8 = 4;
          local_2e0 = 0;
          uStack_2d8 = 0;
          local_290 = uVar12;
          local_308 = lVar7;
          lStack_300 = lVar29;
          local_298 = uVar26;
          local_28f = cVar13;
          if (DAT_140699990 != 0) {
            <std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<host_probe[b94139f9089eb1d8]::net::Transport>>
            ::initialize::
            <<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<host_probe[b94139f9089eb1d8]::net::Transport>>::get_or_init<<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<host_probe[b94139f9089eb1d8]::net::Transport>>::try_insert::_closure_0_>::_closure_0_,_>
                      (&TRANSPORT,&local_3e8);
          }
          cVar13 = local_28f;
          if (local_28f != '\x02') {
            memcpy(&local_1f8,&local_3e8,0x159);
            local_9e = local_28e;
            local_9a = local_28a;
            local_9f = cVar13;
            core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::net::Transport>
                      (&local_1f8);
          }
          netstats::start();
          local_1f8 = (undefined *)0xffffffffffffffff;
          uVar40 = 0;
          std[3bf9d48a0c3997f0]::thread::lifecycle::spawn_unchecked::
          <host_probe[b94139f9089eb1d8]::net::watch_host,()>(&local_3e8,&local_1f8,0);
          plVar17 = (longlong *)CONCAT44(local_3e8._4_4_,(undefined4)local_3e8);
          if (plVar17 != (longlong *)0x0) {
            CloseHandle((HANDLE)CONCAT44(local_3d8._4_4_,(undefined4)local_3d8));
            LOCK();
            *plVar17 = *plVar17 + -1;
            UNLOCK();
            if (*plVar17 == 0) {
              <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::thread::thread::Inner,std[3bf9d48a0c3997f0]::alloc::System>>
              ::drop_slow(&local_3e8);
            }
            plVar17 = (longlong *)CONCAT44(uStack_3e0._4_4_,(uint)uStack_3e0);
            LOCK();
            *plVar17 = *plVar17 + -1;
            UNLOCK();
            if (*plVar17 == 0) {
              <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::thread::lifecycle::Packet<()>>>
              ::drop_slow(&uStack_3e0);
            }
            if (local_218 == 0) {
              if (lVar16 == 0) {
                return;
              }
              __rustc[9d087a5ab36ea756]::__rust_dealloc(local_460,lVar16,1);
              return;
            }
            __rustc[9d087a5ab36ea756]::__rust_dealloc(local_210,local_218,1);
            return;
          }
          local_3e8._0_4_ = (uint)uStack_3e0;
          local_3e8._4_4_ = uStack_3e0._4_4_;
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("failed to spawn thread",0x16,&local_3e8,
                     &PTR_<core[505b25137b8ba7f]::io::error::Error>_1406a0d90,
                     &PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a3130,uVar40);
        }
      }
    }
  }
  else {
    local_3d8._0_4_ = (undefined4)uStack_1e8;
    local_3d8._4_4_ = (undefined4)((ulonglong)uStack_1e8 >> 0x20);
    local_3e8._0_4_ = (undefined4)local_1f8;
    local_3e8._4_4_ = local_1f8._4_4_;
    uStack_3e0._0_4_ = (uint)uStack_1f0;
    uStack_3e0._4_4_ = uStack_1f0._4_4_;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("validated lobby profile",0x17,&local_3e8,
               &anon_165b4b943f29486583e4a83847221390_93_llvm_16945119018599968161,
               &anon_165b4b943f29486583e4a83847221390_194_llvm_16945119018599968161);
  }
LAB_14003abcb:
                    /* WARNING: Does not return */
  pcVar6 = (code *)invalidInstructionException();
  (*pcVar6)();
}

