// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>::push_back_mut
// address: 0x140015630
// body: available
// range: 0x140015630-0x1400156ac inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>::push_back_mut
    */

longlong __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>
::push_back_mut(ulonglong *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  ulonglong uVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  
  uVar11 = *param_1;
  uVar9 = param_1[3];
  if (uVar9 == uVar11) {
    grow(param_1);
    uVar11 = *param_1;
    uVar9 = param_1[3];
  }
  param_1[3] = uVar9 + 1;
  uVar12 = 0;
  if (uVar11 <= uVar9 + param_1[2]) {
    uVar12 = uVar11;
  }
  lVar10 = (uVar9 + param_1[2]) - uVar12;
  uVar11 = param_1[1];
  *(undefined8 *)(uVar11 + 0x40 + lVar10 * 0x48) = param_2[8];
  uVar2 = *param_2;
  uVar3 = param_2[1];
  uVar4 = param_2[2];
  uVar5 = param_2[3];
  uVar6 = param_2[4];
  uVar7 = param_2[5];
  uVar8 = param_2[7];
  puVar1 = (undefined8 *)(uVar11 + 0x30 + lVar10 * 0x48);
  *puVar1 = param_2[6];
  puVar1[1] = uVar8;
  puVar1 = (undefined8 *)(uVar11 + 0x20 + lVar10 * 0x48);
  *puVar1 = uVar6;
  puVar1[1] = uVar7;
  puVar1 = (undefined8 *)(uVar11 + 0x10 + lVar10 * 0x48);
  *puVar1 = uVar4;
  puVar1[1] = uVar5;
  puVar1 = (undefined8 *)(uVar11 + lVar10 * 0x48);
  *puVar1 = uVar2;
  puVar1[1] = uVar3;
  return uVar11 + lVar10 * 0x48;
}

