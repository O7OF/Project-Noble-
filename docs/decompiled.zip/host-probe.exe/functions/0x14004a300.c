// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::vec::Vec<u8>,core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>>::from_iter
// address: 0x14004a300
// body: available
// range: 0x14004a300-0x14004a548 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::vec::Vec<u8>,
   core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,
   2usize>>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::vec::Vec<u8>,core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  code *pcVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong local_d8;
  longlong *plStack_d0;
  longlong local_c8;
  longlong local_c0;
  longlong local_b8;
  longlong lStack_b0;
  longlong local_a8;
  longlong lStack_a0;
  longlong local_98;
  longlong alStack_90 [3];
  int local_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  longlong local_68;
  longlong lStack_60;
  longlong local_58;
  longlong lStack_50;
  longlong local_48;
  
  if ((int)*param_2 == 1) {
    lVar6 = param_2[1];
    lVar8 = param_2[2];
    if (lVar8 != lVar6) {
      plVar7 = param_2 + lVar6 * 3 + 5;
      do {
        lVar1 = plVar7[-2];
        lVar6 = lVar6 + 1;
        if (lVar1 != -1) {
          lVar8 = lVar6;
          if (lVar1 != -2) {
            param_2[1] = lVar6;
            lVar6 = plVar7[-1];
            lVar8 = *plVar7;
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            plVar7 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
            if (plVar7 == (longlong *)0x0) {
              alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
              pcVar4 = (code *)invalidInstructionException();
              (*pcVar4)();
            }
            *plVar7 = lVar1;
            plVar7[1] = lVar6;
            plVar7[2] = lVar8;
            local_d8 = 4;
            local_c8 = 1;
            local_b8 = *param_2;
            lVar6 = param_2[1];
            lVar8 = param_2[2];
            local_48 = param_2[0xe];
            local_58 = param_2[0xc];
            lStack_50 = param_2[0xd];
            local_68 = param_2[10];
            lStack_60 = param_2[0xb];
            local_78 = (int)param_2[8];
            iStack_74 = *(int *)((longlong)param_2 + 0x44);
            iStack_70 = (int)param_2[9];
            iStack_6c = *(int *)((longlong)param_2 + 0x4c);
            alStack_90[1] = param_2[6];
            alStack_90[2] = param_2[7];
            local_98 = param_2[4];
            alStack_90[0] = param_2[5];
            lStack_a0 = param_2[3];
            plStack_d0 = plVar7;
            lVar1 = lVar6;
            local_a8 = lVar8;
            if ((local_b8 != 1) || (lVar8 == lVar6)) goto LAB_14004a518;
            lStack_b0 = lVar6;
            goto LAB_14004a470;
          }
          break;
        }
        plVar7 = plVar7 + 3;
      } while (lVar8 != lVar6);
      param_2[1] = lVar8;
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  core[505b25137b8ba7f]::ptr::drop_glue::
  <core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>
            (param_2);
  return param_1;
LAB_14004a470:
  lVar5 = local_c8;
  plVar9 = alStack_90 + lVar6 * 3;
  lVar10 = lVar6;
  while (lVar2 = plVar9[-2], lVar1 = lVar8, lVar2 == -1) {
    lVar10 = lVar10 + 1;
    plVar9 = plVar9 + 3;
    if (lVar8 == lVar10) goto LAB_14004a518;
  }
  if (lVar2 == -2) {
    lVar1 = lVar10 + 1;
    goto LAB_14004a518;
  }
  local_c0 = plVar9[-1];
  lVar3 = *plVar9;
  if (local_c8 == local_d8) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_d8,local_c8,1,8,0x18);
    plVar7 = plStack_d0;
  }
  lVar6 = lVar10 + 1;
  plVar7[lVar5 * 3] = lVar2;
  plVar7[lVar5 * 3 + 1] = local_c0;
  plVar7[lVar5 * 3 + 2] = lVar3;
  local_c8 = lVar5 + 1;
  if (lVar8 + -1 == lVar10) {
LAB_14004a518:
    lStack_b0 = lVar1;
    core[505b25137b8ba7f]::ptr::drop_glue::
    <core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>
              (&local_b8);
    param_1[2] = local_c8;
    *param_1 = local_d8;
    param_1[1] = (longlong)plStack_d0;
    return param_1;
  }
  goto LAB_14004a470;
}

