// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::vote_to_host
// address: 0x1400247e0
// body: available
// range: 0x1400247e0-0x140024ae2 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::vote_to_host */

void __rustcall
host_probe[b94139f9089eb1d8]::net::vote_to_host(undefined8 param_1,undefined8 param_2)

{
  char *pcVar1;
  undefined1 *puVar2;
  code *pcVar3;
  uint uVar4;
  uint uVar5;
  undefined *puVar6;
  byte bVar7;
  char cVar8;
  ulonglong uVar9;
  ushort uVar10;
  int iVar11;
  longlong lVar12;
  uint uVar13;
  longlong lVar14;
  bool bVar15;
  byte bVar16;
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined1 auVar19 [16];
  undefined1 *local_c8;
  undefined1 *local_c0;
  int local_b8;
  undefined8 local_b4;
  undefined8 uStack_ac;
  undefined8 local_a4;
  undefined8 uStack_9c;
  undefined8 local_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 local_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  
  puVar2 = HOST_ID_0_llvm_14435704873730135342;
  if (((DAT_140699990 == 0) && (HOST_ID_0_llvm_14435704873730135342 != (undefined1 *)0x0)) &&
     (IS_HOST_0_llvm_14435704873730135342 == '\0')) {
    local_c8 = HOST_ID_0_llvm_14435704873730135342;
    LOCK();
    bVar15 = DAT_140699948 == '\0';
    if (bVar15) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar15) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    puVar6 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar7 = 0;
    }
    else {
      bVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar7 = bVar7 ^ 1;
    }
    if (DAT_140699949 != '\0') {
      local_c0 = &DAT_140699948;
      uVar13 = (uint)local_b8 >> 8;
      local_b8 = CONCAT31((int3)uVar13,bVar7);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_c0,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0740);
                    /* WARNING: Does not return */
      pcVar3 = (code *)invalidInstructionException();
      (*pcVar3)();
    }
    iVar11 = -1;
    if (DAT_140699968 != 0) {
      uVar9 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
              ::hash_one::<&usize>(&DAT_140699970,&local_c8);
      bVar16 = (byte)(uVar9 >> 0x39);
      auVar17 = ZEXT216(CONCAT11(bVar16,bVar16));
      auVar17 = pshuflw(auVar17,auVar17,0);
      lVar12 = 0;
      while( true ) {
        uVar9 = uVar9 & DAT_140699958;
        pcVar1 = (char *)(DAT_140699950 + uVar9);
        auVar19[0] = -(*pcVar1 == auVar17[0]);
        auVar19[1] = -(pcVar1[1] == auVar17[1]);
        auVar19[2] = -(pcVar1[2] == auVar17[2]);
        auVar19[3] = -(pcVar1[3] == auVar17[3]);
        auVar19[4] = -(pcVar1[4] == auVar17[4]);
        auVar19[5] = -(pcVar1[5] == auVar17[5]);
        auVar19[6] = -(pcVar1[6] == auVar17[6]);
        auVar19[7] = -(pcVar1[7] == auVar17[7]);
        auVar19[8] = -(pcVar1[8] == auVar17[0]);
        auVar19[9] = -(pcVar1[9] == auVar17[1]);
        auVar19[10] = -(pcVar1[10] == auVar17[2]);
        auVar19[0xb] = -(pcVar1[0xb] == auVar17[3]);
        auVar19[0xc] = -(pcVar1[0xc] == auVar17[4]);
        auVar19[0xd] = -(pcVar1[0xd] == auVar17[5]);
        auVar19[0xe] = -(pcVar1[0xe] == auVar17[6]);
        auVar19[0xf] = -(pcVar1[0xf] == auVar17[7]);
        uVar10 = (ushort)(SUB161(auVar19 >> 7,0) & 1) | (ushort)(SUB161(auVar19 >> 0xf,0) & 1) << 1
                 | (ushort)(SUB161(auVar19 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar19 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar19 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar19 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar19 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar19 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar19 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar19 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar19 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar19 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar19 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar19 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar19 >> 0x77,0) & 1) << 0xe | (ushort)(auVar19[0xf] >> 7) << 0xf
        ;
        uVar13 = (uint)uVar10;
        while (uVar10 != 0) {
          uVar4 = 0;
          for (uVar5 = uVar13; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
            uVar4 = uVar4 + 1;
          }
          lVar14 = (uVar4 + uVar9 & DAT_140699958) * -0x50;
          if (puVar2 == *(undefined1 **)(DAT_140699950 + -0x50 + lVar14)) {
            lVar14 = DAT_140699950 + lVar14;
            puVar2 = *(undefined1 **)(lVar14 + -0x48);
            iVar11 = *(int *)(lVar14 + -0x40);
            uStack_44 = *(undefined8 *)(lVar14 + -8);
            uStack_48 = (undefined4)((ulonglong)*(undefined8 *)(lVar14 + -0x10) >> 0x20);
            uStack_58 = *(undefined8 *)(lVar14 + -0x1c);
            uStack_50 = (undefined4)*(undefined8 *)(lVar14 + -0x14);
            local_4c = (undefined4)((ulonglong)*(undefined8 *)(lVar14 + -0x14) >> 0x20);
            local_68 = *(undefined8 *)(lVar14 + -0x2c);
            uStack_60 = *(undefined8 *)(lVar14 + -0x24);
            local_78 = *(undefined8 *)(lVar14 + -0x3c);
            uStack_70 = *(undefined8 *)(lVar14 + -0x34);
            goto joined_r0x000140024964;
          }
          uVar10 = (ushort)(uVar13 - 1) & (ushort)uVar13;
          uVar13 = CONCAT22((short)(uVar13 - 1 >> 0x10),uVar10);
        }
        auVar18[0] = -(*pcVar1 == -1);
        auVar18[1] = -(pcVar1[1] == -1);
        auVar18[2] = -(pcVar1[2] == -1);
        auVar18[3] = -(pcVar1[3] == -1);
        auVar18[4] = -(pcVar1[4] == -1);
        auVar18[5] = -(pcVar1[5] == -1);
        auVar18[6] = -(pcVar1[6] == -1);
        auVar18[7] = -(pcVar1[7] == -1);
        auVar18[8] = -(pcVar1[8] == -1);
        auVar18[9] = -(pcVar1[9] == -1);
        auVar18[10] = -(pcVar1[10] == -1);
        auVar18[0xb] = -(pcVar1[0xb] == -1);
        auVar18[0xc] = -(pcVar1[0xc] == -1);
        auVar18[0xd] = -(pcVar1[0xd] == -1);
        auVar18[0xe] = -(pcVar1[0xe] == -1);
        auVar18[0xf] = -(pcVar1[0xf] == -1);
        if ((((((((((((((((SUB161(auVar18 >> 7,0) & 1) != 0 || (SUB161(auVar18 >> 0xf,0) & 1) != 0)
                        || (SUB161(auVar18 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar18 >> 0x1f,0) & 1) != 0) || (SUB161(auVar18 >> 0x27,0) & 1) != 0
                      ) || (SUB161(auVar18 >> 0x2f,0) & 1) != 0) ||
                    (SUB161(auVar18 >> 0x37,0) & 1) != 0) || (SUB161(auVar18 >> 0x3f,0) & 1) != 0)
                  || (SUB161(auVar18 >> 0x47,0) & 1) != 0) || (SUB161(auVar18 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar18 >> 0x57,0) & 1) != 0) || (SUB161(auVar18 >> 0x5f,0) & 1) != 0) ||
              (SUB161(auVar18 >> 0x67,0) & 1) != 0) || (SUB161(auVar18 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar18 >> 0x77,0) & 1) != 0) || auVar18[0xf] < '\0') break;
        uVar9 = uVar9 + lVar12 + 0x10;
        lVar12 = lVar12 + 0x10;
      }
    }
joined_r0x000140024964:
    if (((bVar7 == 0) && ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) != 0)) &&
       (cVar8 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar8 == '\0'))
    {
      DAT_140699949 = '\x01';
    }
    cVar8 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    local_b4 = local_78;
    uStack_ac = uStack_70;
    local_a4 = local_68;
    uStack_9c = uStack_60;
    local_94 = uStack_58;
    uStack_8c = uStack_50;
    uStack_88 = local_4c;
    uStack_84 = uStack_48;
    uStack_80 = uStack_44;
    if (cVar8 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
      local_b4 = local_78;
      uStack_ac = uStack_70;
      local_a4 = local_68;
      uStack_9c = uStack_60;
      local_94 = uStack_58;
      uStack_8c = uStack_50;
      uStack_88 = local_4c;
      uStack_84 = uStack_48;
      uStack_80 = uStack_44;
    }
    if (iVar11 != -1) {
      local_c0 = puVar2;
      local_b8 = iVar11;
      local_78 = local_b4;
      uStack_70 = uStack_ac;
      local_68 = local_a4;
      uStack_60 = uStack_9c;
      uStack_58 = local_94;
      uStack_50 = uStack_8c;
      local_4c = uStack_88;
      uStack_48 = uStack_84;
      uStack_44 = uStack_80;
      send_route_kind(&TRANSPORT,&local_c0,param_1,param_2,1);
    }
  }
  return;
}

