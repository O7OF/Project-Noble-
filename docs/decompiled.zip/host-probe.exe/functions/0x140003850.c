// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::string::String)>>
// address: 0x140003850
// body: available
// range: 0x140003850-0x1400038ac inclusive
// range: 0x1400038b0-0x1400038cf inclusive
// range: 0x1400038d2-0x140003923 inclusive
// range: 0x140003930-0x140003954 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400038cb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400038fa to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003950 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,
   alloc[246c2e7857c81348]::string::String)>> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::string::String)>>
          (ulonglong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  ulonglong uVar8;
  undefined8 *puVar9;
  ulonglong uVar10;
  
  uVar1 = *param_1;
  uVar2 = param_1[3];
  if (uVar2 == 0) {
    uVar6 = param_1[1];
  }
  else {
    uVar6 = param_1[1];
    uVar3 = param_1[2];
    uVar4 = uVar1;
    if (uVar3 < uVar1) {
      uVar4 = 0;
    }
    lVar7 = uVar3 - uVar4;
    uVar10 = uVar1 - lVar7;
    uVar5 = uVar2 - uVar10;
    if (uVar2 < uVar10) {
      uVar5 = 0;
    }
    uVar8 = lVar7 + uVar2;
    if (uVar2 >= uVar10 && uVar2 - uVar10 != 0) {
      uVar8 = uVar1;
    }
    lVar7 = uVar8 - lVar7;
    if (lVar7 != 0) {
      puVar9 = (undefined8 *)(uVar6 + uVar3 * 0x20 + uVar4 * -0x20 + 0x10);
      do {
        if (puVar9[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar9,puVar9[-1],1);
          return;
        }
        puVar9 = puVar9 + 4;
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
    }
    if (uVar10 < uVar2) {
      puVar9 = (undefined8 *)(uVar6 + 0x10);
      do {
        if (puVar9[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar9,puVar9[-1],1);
          return;
        }
        puVar9 = puVar9 + 4;
        uVar5 = uVar5 - 1;
      } while (uVar5 != 0);
    }
  }
  if (uVar1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar6,uVar1 << 5,8);
    return;
  }
  return;
}

