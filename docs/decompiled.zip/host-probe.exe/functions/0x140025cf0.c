// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::introduce_direct
// address: 0x140025cf0
// body: available
// range: 0x140025cf0-0x140026084 inclusive
// range: 0x140026090-0x14002614b inclusive
// range: 0x140026150-0x14002650c inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140025efe to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::introduce_direct */

undefined8 * __rustcall
host_probe[b94139f9089eb1d8]::net::introduce_direct
          (undefined8 *param_1,undefined8 param_2,ushort *param_3,undefined8 param_4)

{
  ushort uVar1;
  code *pcVar2;
  undefined8 uVar3;
  undefined1 *puVar4;
  char cVar5;
  int iVar6;
  ulonglong uVar7;
  undefined8 *puVar8;
  undefined8 uVar9;
  ulonglong uVar10;
  char *pcVar11;
  uint uVar12;
  undefined8 *******pppppppuVar13;
  undefined **ppuVar14;
  longlong lVar15;
  undefined8 *******_Size;
  undefined1 auVar16 [16];
  undefined **ppuVar17;
  undefined1 local_191;
  uint local_190;
  ushort local_18c;
  ushort local_18a;
  undefined8 *******local_188;
  undefined1 *puStack_180;
  undefined8 local_178;
  undefined8 *******local_170;
  undefined2 local_168;
  undefined2 uStack_166;
  ushort uStack_164;
  undefined2 uStack_162;
  undefined2 uStack_160;
  undefined6 uStack_15e;
  undefined2 uStack_158;
  undefined8 local_148;
  ushort uStack_140;
  undefined6 uStack_13e;
  undefined2 local_138;
  undefined6 uStack_136;
  undefined2 uStack_130;
  undefined2 uStack_12e;
  int iStack_12c;
  int iStack_128;
  ushort local_124;
  longlong local_120;
  undefined8 *******local_118;
  longlong local_110;
  undefined8 *local_108;
  int local_fc;
  longlong local_f8;
  longlong local_f0;
  ushort *local_e8;
  undefined8 *******local_e0;
  undefined8 *local_d8;
  undefined **ppuStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  local_118 = (undefined8 *******)__rustc[9d087a5ab36ea756]::__rust_alloc(8,1);
  if (local_118 == (undefined8 *******)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(1,8);
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  local_120 = 8;
  *local_118 = (undefined8 ******)0x31305249442d5252;
  local_110 = 8;
  <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
  <alloc[246c2e7857c81348]::alloc::Global>(&local_120,8,8,1,1);
  local_170 = local_118;
  *(undefined8 *)((longlong)local_118 + local_110) = param_4;
  lVar15 = local_110 + 8;
  local_d8 = (undefined8 *)0x0;
  local_110 = lVar15;
  iVar6 = getrandom[e4e332955b4b3e9c]::imp::getrandom_inner(&local_d8);
  puVar8 = local_d8;
  if (iVar6 != 0) {
    local_148 = (undefined8 *******)CONCAT44(local_148._4_4_,iVar6);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("OS random number generator unavailable",0x26,&local_148,
               &anon_77b31ca45fa0b8bad65e4e218c556f8d_120_llvm_4406972151671265263,
               &anon_77b31ca45fa0b8bad65e4e218c556f8d_4_llvm_4406972151671265263);
    goto LAB_14002650b;
  }
  if ((ulonglong)(local_120 - lVar15) < 8) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_120,lVar15,8,1,1);
    local_170 = local_118;
    lVar15 = local_110;
  }
  *(undefined8 **)((longlong)local_170 + lVar15) = puVar8;
  pppppppuVar13 = (undefined8 *******)0x0;
  uVar7 = <std[3bf9d48a0c3997f0]::net::tcp::TcpStream>::set_read_timeout(param_2,0,250000000);
  if (uVar7 != 0) {
    local_168 = (undefined2)uVar7;
    uStack_166 = (undefined2)(uVar7 >> 0x10);
    uStack_164 = (ushort)(uVar7 >> 0x20);
    uStack_162 = (undefined2)(uVar7 >> 0x30);
    local_148 = (undefined8 *******)0x0;
    uStack_140 = 1;
    uStack_13e = 0;
    local_138 = 0;
    uStack_136 = 0;
    local_c8 = 0x60000020;
    local_d8 = &local_148;
    ppuStack_d0 = &PTR_<alloc[246c2e7857c81348]::string::String>_1406a3830;
    cVar5 = <core[505b25137b8ba7f]::io::error::Error_as_core[505b25137b8ba7f]::fmt::Display>::fmt
                      (&local_168,&local_d8);
    if (cVar5 != '\0') {
      core[505b25137b8ba7f]::result::unwrap_failed
                ("a Display implementation returned an error unexpectedly",0x37,&local_191,
                 &DAT_1406a1170,&PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
      goto LAB_14002650b;
    }
    local_178 = CONCAT62(uStack_136,local_138);
    puStack_180 = (undefined1 *)CONCAT62(uStack_13e,uStack_140);
    local_188 = local_148;
    if ((1 < ((uint)uVar7 & 3) - 2) && ((uVar7 & 3) != 0)) {
      ppuStack_d0 = (undefined **)(uVar7 - 1);
      local_d8 = (undefined8 *)CONCAT71(local_d8._1_7_,3);
      <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
      drop(&ppuStack_d0);
    }
    param_1[2] = local_178;
    *param_1 = local_188;
    param_1[1] = puStack_180;
    goto joined_r0x0001400263fd;
  }
  uVar9 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  ppuVar17 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2310;
  uVar7 = <std[3bf9d48a0c3997f0]::time::Instant_as_core[505b25137b8ba7f]::ops::arith::Add<core[505b25137b8ba7f]::time::Duration>>
          ::add(uVar9);
  uVar12 = (uint)pppppppuVar13;
  local_68 = 0;
  uStack_60 = 0;
  local_78 = 0;
  uStack_70 = 0;
  local_88 = 0;
  uStack_80 = 0;
  local_98 = 0;
  uStack_90 = 0;
  local_a8 = 0;
  uStack_a0 = 0;
  local_b8 = 0;
  uStack_b0 = 0;
  local_c8 = 0;
  uStack_c0 = 0;
  local_d8 = (undefined8 *)0x0;
  ppuStack_d0 = (undefined **)0x0;
  uVar1 = *param_3;
  local_190 = uVar12;
  local_108 = param_1;
  if (uVar1 == 2) {
    uVar10 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    if (uVar10 == uVar7) {
      if (uVar12 < local_190) {
LAB_14002628a:
        ppuVar14 = &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
        goto LAB_140026326;
      }
    }
    else if (uVar10 < uVar7) goto LAB_14002628a;
LAB_140026296:
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    pcVar11 = (char *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x53,1);
    if (pcVar11 == (char *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x53);
      goto LAB_14002650b;
    }
    builtin_strncpy(pcVar11,
                    "host did not answer the direct join; use the Server Browser for hole punching/relay"
                    ,0x53);
    *local_108 = 0x53;
    local_108[1] = pcVar11;
    local_108[2] = 0x53;
    param_1 = local_108;
  }
  else {
    ppuVar14 = *(undefined ***)(param_3 + 4);
    if (uVar1 != 0xffff) {
      _Size = (undefined8 *******)(lVar15 + 8);
      local_e8 = param_3 + 8;
      local_18a = param_3[3];
      local_fc = *(int *)(param_3 + 1);
      local_18c = param_3[0xe];
      uVar9 = *(undefined8 *)(param_3 + 10);
      local_f0 = *(longlong *)(param_3 + 6);
      local_f8 = *(longlong *)(param_3 + 2);
      local_e0 = (undefined8 *******)ppuVar14;
LAB_140026070:
      do {
        while( true ) {
          uVar12 = (uint)pppppppuVar13;
          uVar10 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
          if (uVar10 == uVar7) {
            if (local_190 <= uVar12) goto LAB_140026296;
          }
          else if (uVar7 <= uVar10) goto LAB_140026296;
          local_148 = (undefined8 *******)
                      CONCAT26(param_3[3],CONCAT42(*(undefined4 *)(param_3 + 1),uVar1));
          uStack_140 = (ushort)local_e0;
          uStack_13e = (undefined6)((ulonglong)local_e0 >> 0x10);
          uVar3 = *(undefined8 *)(local_e8 + 4);
          local_138 = (undefined2)*(undefined8 *)local_e8;
          uStack_136 = (undefined6)((ulonglong)*(undefined8 *)local_e8 >> 0x10);
          uStack_130 = (undefined2)uVar3;
          uStack_12e = (undefined2)((ulonglong)uVar3 >> 0x10);
          iStack_12c = (int)((ulonglong)uVar3 >> 0x20);
          ppuVar14 = (undefined **)local_170;
          lVar15 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                             (param_2,local_170,_Size,&local_148,ppuVar17);
          if (lVar15 == 1) goto LAB_140026326;
          <std[3bf9d48a0c3997f0]::net::udp::UdpSocket>::recv_from(&local_148,param_2,&local_d8,0x80)
          ;
          if (uStack_140 != 2) break;
          uVar12 = ((uint)local_148 & 3) - 2;
          pppppppuVar13 = (undefined8 *******)(ulonglong)uVar12;
          if ((1 < uVar12) && (((ulonglong)local_148 & 3) != 0)) {
            puStack_180 = (undefined1 *)((longlong)local_148 + -1);
            local_188 = (undefined8 *******)CONCAT71(local_188._1_7_,3);
            <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
            ::drop(&puStack_180);
          }
        }
        uStack_158 = uStack_12e;
        local_168 = (undefined2)uStack_13e;
        uStack_166 = (undefined2)((uint6)uStack_13e >> 0x10);
        uStack_164 = (ushort)((uint6)uStack_13e >> 0x20);
        uStack_162 = local_138;
        uStack_160 = (undefined2)uStack_136;
        uStack_15e = (undefined6)(CONCAT26(uStack_130,uStack_136) >> 0x10);
        pppppppuVar13 = local_148;
      } while (uStack_140 != uVar1);
      if ((uVar1 & 1) == 0) {
        if ((uStack_164 != local_18a) || ((int)uStack_13e != local_fc)) goto LAB_140026070;
      }
      else {
        if (local_124 != local_18c) goto LAB_140026070;
        auVar16._0_4_ = -(uint)(iStack_12c == (int)uVar9);
        iVar6 = -(uint)(iStack_128 == (int)((ulonglong)uVar9 >> 0x20));
        auVar16._4_4_ = auVar16._0_4_;
        auVar16._8_4_ = iVar6;
        auVar16._12_4_ = iVar6;
        uVar12 = movmskpd((uint)local_18c,auVar16);
        if ((((uVar12 & 1) == 0) || ((byte)((byte)uVar12 >> 1) == 0)) ||
           (CONCAT26(uStack_12e,uStack_15e) != local_f0 ||
            CONCAT26(uStack_160,CONCAT24(local_138,(int)((uint6)uStack_13e >> 0x10))) != local_f8))
        goto LAB_140026070;
      }
      if (&DAT_00000080 < local_148) {
        core[505b25137b8ba7f]::slice::index::slice_index_fail
                  (0,local_148,0x80,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2380)
        ;
        goto LAB_14002650b;
      }
      if ((local_148 != _Size) ||
         (pppppppuVar13 = local_170, iVar6 = memcmp(&local_d8,local_170,(size_t)_Size), iVar6 != 0))
      goto LAB_140026070;
      lVar15 = <std[3bf9d48a0c3997f0]::net::tcp::TcpStream>::set_read_timeout(param_2);
      param_1 = local_108;
      if (lVar15 == 0) {
        *local_108 = 0xffffffffffffffff;
      }
      else {
        introduce_direct::_closure_2_(&local_188,lVar15);
        param_1[2] = local_178;
        *param_1 = local_188;
        param_1[1] = puStack_180;
      }
      goto joined_r0x0001400263fd;
    }
    uVar10 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    if (uVar10 == uVar7) {
      if (local_190 <= uVar12) goto LAB_140026296;
    }
    else if (uVar7 <= uVar10) goto LAB_140026296;
LAB_140026326:
    local_168 = SUB82(ppuVar14,0);
    uStack_166 = (undefined2)((ulonglong)ppuVar14 >> 0x10);
    uStack_164 = (ushort)((ulonglong)ppuVar14 >> 0x20);
    uStack_162 = (undefined2)((ulonglong)ppuVar14 >> 0x30);
    local_188 = (undefined8 *******)0x0;
    puStack_180 = (undefined1 *)0x1;
    local_178 = 0;
    local_138 = 0x20;
    uStack_136 = 0x6000;
    local_148 = &local_188;
    uStack_140 = 0x3830;
    uStack_13e = 0x1406a;
    cVar5 = <core[505b25137b8ba7f]::io::error::Error_as_core[505b25137b8ba7f]::fmt::Display>::fmt
                      (&local_168,&local_148);
    param_1 = local_108;
    uVar9 = local_178;
    puVar4 = puStack_180;
    pppppppuVar13 = local_188;
    if (cVar5 != '\0') {
      core[505b25137b8ba7f]::result::unwrap_failed
                ("a Display implementation returned an error unexpectedly",0x37,&local_191,
                 &DAT_1406a1170,&PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
LAB_14002650b:
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    if ((1 < ((uint)ppuVar14 & 3) - 2) && (((ulonglong)ppuVar14 & 3) != 0)) {
      uStack_140 = (ushort)(undefined1 *)((longlong)ppuVar14 + -1);
      uStack_13e = (undefined6)((ulonglong)((longlong)ppuVar14 + -1) >> 0x10);
      local_148 = (undefined8 *******)CONCAT71(local_148._1_7_,3);
      <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
      drop(&uStack_140);
    }
    *param_1 = pppppppuVar13;
    param_1[1] = puVar4;
    param_1[2] = uVar9;
  }
joined_r0x0001400263fd:
  if (local_120 == 0) {
    return param_1;
  }
  puVar8 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(local_170,local_120,1);
  return puVar8;
}

