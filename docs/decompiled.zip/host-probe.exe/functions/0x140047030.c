// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u32,[u8;15usize])>>::resize
// address: 0x140047030
// body: available
// range: 0x140047030-0x140047184 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u32, [u8; 15usize])>>::resize */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u32,[u8;15usize])>>::resize
          (longlong *param_1,ulonglong param_2,undefined4 *param_3)

{
  undefined1 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  undefined4 *puVar8;
  ulonglong uVar9;
  
  uVar5 = param_1[2];
  uVar6 = param_2 - uVar5;
  if (uVar5 <= param_2 && uVar6 != 0) {
    uVar2 = *param_3;
    uVar1 = *(undefined1 *)((longlong)param_3 + 0x13);
    uVar4 = uVar5;
    if (*param_1 - uVar5 < uVar6) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(param_1,uVar5,uVar6,4,0x14);
      uVar4 = param_1[2];
    }
    puVar7 = (undefined8 *)(param_3 + 1);
    puVar8 = (undefined4 *)(uVar4 * 0x14 + param_1[1]);
    if (1 < uVar6) {
      uVar9 = (ulonglong)((uint)(param_2 + ~uVar5) & 3);
      if (uVar6 - 2 < 3) goto LAB_140047100;
      uVar5 = param_2 + ~uVar5 & 0xfffffffffffffffc;
      do {
        *puVar8 = uVar2;
        uVar3 = *(undefined8 *)((longlong)param_3 + 0xb);
        *(undefined8 *)(puVar8 + 1) = *puVar7;
        *(undefined8 *)((longlong)puVar8 + 0xb) = uVar3;
        puVar8[5] = uVar2;
        uVar3 = *(undefined8 *)((longlong)param_3 + 0xb);
        *(undefined8 *)(puVar8 + 6) = *puVar7;
        *(undefined8 *)((longlong)puVar8 + 0x1f) = uVar3;
        puVar8[10] = uVar2;
        uVar3 = *(undefined8 *)((longlong)param_3 + 0xb);
        *(undefined8 *)(puVar8 + 0xb) = *puVar7;
        *(undefined8 *)((longlong)puVar8 + 0x33) = uVar3;
        puVar8[0xf] = uVar2;
        uVar3 = *(undefined8 *)((longlong)param_3 + 0xb);
        *(undefined8 *)(puVar8 + 0x10) = *puVar7;
        *(undefined8 *)((longlong)puVar8 + 0x47) = uVar3;
        puVar8 = puVar8 + 0x14;
        uVar5 = uVar5 - 4;
      } while (uVar5 != 0);
      for (; uVar9 != 0; uVar9 = uVar9 - 1) {
LAB_140047100:
        *puVar8 = uVar2;
        uVar3 = *(undefined8 *)((longlong)param_3 + 0xb);
        *(undefined8 *)(puVar8 + 1) = *puVar7;
        *(undefined8 *)((longlong)puVar8 + 0xb) = uVar3;
        puVar8 = puVar8 + 5;
      }
      uVar4 = (uVar4 + uVar6) - 1;
    }
    *puVar8 = uVar2;
    uVar3 = *(undefined8 *)((longlong)param_3 + 0xb);
    *(undefined8 *)(puVar8 + 1) = *puVar7;
    *(undefined8 *)((longlong)puVar8 + 0xb) = uVar3;
    *(undefined1 *)((longlong)puVar8 + 0x13) = uVar1;
    param_2 = uVar4 + 1;
  }
  param_1[2] = param_2;
  return;
}

