// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::map::Map<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>>
// address: 0x1400449a0
// body: available
// range: 0x1400449a0-0x140044a0d inclusive
// range: 0x140044a10-0x140044a69 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140044a59 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::map::Map<alloc[246c2e7857c81348]::string::String,
   serde_json[7404bcab4dc139c7]::value::Value>>> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::map::Map<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>>
          (longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  ulonglong local_70 [3];
  longlong local_58;
  ulonglong local_50;
  undefined8 local_48;
  longlong local_40;
  longlong local_38;
  longlong local_30;
  
  plVar1 = (longlong *)param_1[1];
  lVar4 = param_1[2];
  if (lVar4 != 0) {
    plVar3 = plVar1;
    do {
      lVar4 = lVar4 + -1;
      lVar2 = *plVar3;
      if (lVar2 == 0) {
        local_30 = 0;
      }
      else {
        local_58 = plVar3[1];
        local_30 = plVar3[2];
        local_70[1] = 0;
        local_48 = 0;
        local_70[2] = lVar2;
        local_40 = lVar2;
        local_38 = local_58;
      }
      local_70[0] = (ulonglong)(lVar2 != 0);
      local_50 = local_70[0];
      <alloc[246c2e7857c81348]::collections::btree::map::IntoIter<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                (local_70);
      plVar3 = plVar3 + 3;
    } while (lVar4 != 0);
  }
  if (*param_1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar1,*param_1 * 0x18,8);
    return;
  }
  return;
}

