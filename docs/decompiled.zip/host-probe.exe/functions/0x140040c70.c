// rea decompile_all
// name: <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_core[505b25137b8ba7f]::clone::Clone>::clone
// address: 0x140040c70
// body: available
// range: 0x140040c70-0x140040deb inclusive
// range: 0x140040e07-0x140040eb0 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg as core[505b25137b8ba7f]::clone::Clone>::clone
    */

void __rustcall
<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_core[505b25137b8ba7f]::clone::Clone>::clone
          (undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 local_e8;
  undefined8 local_e0;
  undefined8 uStack_d8;
  undefined8 local_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 local_b0;
  undefined8 uStack_a8;
  undefined8 local_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  
                    /* WARNING (jumptable): Sanity check requires truncation of jumptable */
                    /* WARNING: Could not find normalized switch variable to match jumptable */
  switch(*param_2) {
  case 0:
    uVar3 = *(undefined4 *)(param_2 + 4);
    uVar1 = param_2[1];
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (param_1 + 8,param_2 + 8);
    *(undefined4 *)(param_1 + 4) = uVar3;
    param_1[1] = uVar1;
    *param_1 = 0;
    break;
  case 1:
    uVar5 = *(undefined8 *)(param_2 + 0x10);
    uVar6 = *(undefined8 *)(param_2 + 0x18);
    uVar4 = *(undefined8 *)(param_2 + 4);
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_f8,param_2 + 0x20);
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_e0,param_2 + 0x38);
    uVar1 = param_2[1];
    uVar2 = param_2[2];
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_98,param_2 + 0x50);
    *(undefined8 *)(param_1 + 0x10) = uVar5;
    *(undefined8 *)(param_1 + 0x18) = uVar6;
    *(undefined8 *)(param_1 + 4) = uVar4;
    *(undefined8 *)(param_1 + 0x20) = local_f8;
    *(undefined8 *)(param_1 + 0x28) = uStack_f0;
    *(undefined8 *)(param_1 + 0x30) = local_e8;
    *(undefined8 *)(param_1 + 0x38) = local_e0;
    *(undefined8 *)(param_1 + 0x40) = uStack_d8;
    *(undefined8 *)(param_1 + 0x48) = local_d0;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    *(undefined8 *)(param_1 + 0x50) = local_98;
    *(undefined8 *)(param_1 + 0x58) = uStack_90;
    *(undefined8 *)(param_1 + 0x60) = local_88;
    *param_1 = 1;
    break;
  case 2:
    *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    *param_1 = 2;
    break;
  case 3:
    uVar3 = *(undefined4 *)(param_2 + 4);
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (param_1 + 8,param_2 + 8);
    *(undefined4 *)(param_1 + 4) = uVar3;
    *param_1 = 3;
    break;
  case 4:
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_c8,param_2 + 8);
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_b0,param_2 + 0x20);
    uVar4 = *(undefined8 *)(param_2 + 0x68);
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_f8,param_2 + 0x38);
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_e0,param_2 + 0x50);
    *(undefined8 *)(param_1 + 0x58) = uStack_d8;
    *(undefined8 *)(param_1 + 0x60) = local_d0;
    *(undefined8 *)(param_1 + 0x48) = local_e8;
    *(undefined8 *)(param_1 + 0x50) = local_e0;
    *(undefined8 *)(param_1 + 0x38) = local_f8;
    *(undefined8 *)(param_1 + 0x40) = uStack_f0;
    *(undefined8 *)(param_1 + 0x28) = uStack_a8;
    *(undefined8 *)(param_1 + 0x30) = local_a0;
    *(undefined8 *)(param_1 + 0x18) = local_b8;
    *(undefined8 *)(param_1 + 0x20) = local_b0;
    *(undefined8 *)(param_1 + 8) = local_c8;
    *(undefined8 *)(param_1 + 0x10) = uStack_c0;
    *(undefined8 *)(param_1 + 0x68) = uVar4;
    *param_1 = 4;
  }
  return;
}

