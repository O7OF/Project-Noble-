// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::m64_member::with_bounds
// address: 0x140016440
// body: available
// range: 0x140016440-0x140016576 inclusive
// range: 0x140016578-0x1400165a7 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140016572 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::m64_member::with_bounds */

void __rustcall
host_probe[b94139f9089eb1d8]::m64_member::with_bounds
          (undefined8 *param_1,longlong param_2,longlong param_3,void *param_4,size_t param_5,
          ulonglong *param_6,longlong param_7)

{
  code *pcVar1;
  void *_Dst;
  ulonglong uVar2;
  char local_79;
  longlong local_78;
  longlong *local_70;
  code *local_68;
  char *local_60;
  code *local_58;
  undefined4 local_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 local_40;
  
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  _Dst = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(param_5,1);
  if (_Dst == (void *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(1,param_5);
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  memcpy(_Dst,param_4,param_5);
  uVar2 = *param_6;
  local_79 = *(char *)(uVar2 + param_2 + param_3);
  if ((local_79 != ' ') && (local_79 != '@')) {
LAB_140016503:
    local_78 = uVar2 + param_3;
    local_70 = &local_78;
    local_68 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    local_60 = &local_79;
    local_58 = <u8_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_50,&DAT_1406a16bb,&local_70);
    param_1[3] = local_40;
    *(undefined4 *)(param_1 + 1) = local_50;
    *(undefined4 *)((longlong)param_1 + 0xc) = uStack_4c;
    *(undefined4 *)(param_1 + 2) = uStack_48;
    *(undefined4 *)((longlong)param_1 + 0x14) = uStack_44;
    *param_1 = 1;
    __rustc[9d087a5ab36ea756]::__rust_dealloc(_Dst,param_5,1);
    return;
  }
  if (param_5 <= uVar2) {
LAB_140016597:
    core[505b25137b8ba7f]::panicking::panic_bounds_check
              (uVar2,param_5,&PTR_s_src_m64_member_rs_1406a1708);
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  *(char *)((longlong)_Dst + uVar2) = local_79;
  if (param_7 != 1) {
    uVar2 = param_6[1];
    local_79 = *(char *)(param_2 + param_3 + uVar2);
    if ((local_79 != '@') && (local_79 != ' ')) goto LAB_140016503;
    if (param_5 <= uVar2) goto LAB_140016597;
    *(char *)((longlong)_Dst + uVar2) = local_79;
  }
  param_1[1] = param_5;
  param_1[2] = _Dst;
  param_1[3] = param_5;
  *param_1 = 0;
  return;
}

