// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet
// address: 0x14003dc30
// body: available
// range: 0x14003dc30-0x14003dea5 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003dcfe to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet */

void __rustcall
host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet(undefined4 *param_1,undefined8 param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined1 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  longlong lVar10;
  undefined1 *puVar11;
  char cVar12;
  undefined8 *puVar13;
  uint uVar14;
  longlong lVar15;
  ulonglong uVar16;
  undefined1 *puVar17;
  undefined1 *puVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  undefined1 *puVar21;
  undefined1 local_79;
  undefined8 local_78;
  undefined8 uStack_70;
  longlong local_68;
  longlong local_60;
  undefined1 *local_58;
  ulonglong local_50;
  longlong *local_48;
  undefined **local_40;
  undefined8 local_38;
  
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(8,1);
  if (puVar13 == (undefined8 *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(1,8);
LAB_14003dea4:
                    /* WARNING: Does not return */
    pcVar4 = (code *)invalidInstructionException();
    (*pcVar4)();
  }
  local_78 = 8;
  *puVar13 = 0x32544148432d5252;
  local_68 = 8;
  local_60 = 0;
  local_58 = (undefined1 *)0x1;
  local_50 = 0;
  local_38 = 0x60000020;
  local_48 = &local_60;
  local_40 = &PTR_<alloc[246c2e7857c81348]::string::String>_1406a3830;
  uStack_70 = puVar13;
  cVar12 = <serde_json[7404bcab4dc139c7]::value::Value_as_core[505b25137b8ba7f]::fmt::Display>::fmt
                     (param_2,&local_48);
  uVar16 = local_50;
  puVar11 = local_58;
  lVar10 = local_60;
  if (cVar12 != '\0') {
    core[505b25137b8ba7f]::result::unwrap_failed
              ("a Display implementation returned an error unexpectedly",0x37,&local_79,
               &DAT_1406a1170,&PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
    goto LAB_14003dea4;
  }
  lVar15 = 8;
  if (local_50 == 0) goto LAB_14003dce8;
  <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
  <alloc[246c2e7857c81348]::alloc::Global>(&local_78,8,local_50,1,1);
  puVar17 = puVar11;
  lVar15 = local_68;
  if ((7 < uVar16) &&
     ((ulonglong)((longlong)puVar11 - (local_68 + (longlong)uStack_70)) < 0xffffffffffffffe1)) {
    if (uVar16 < 0x20) {
      uVar19 = 0;
    }
    else {
      uVar19 = uVar16 & 0xffffffffffffffe0;
      lVar15 = local_68 + uVar19;
      uVar20 = 0;
      do {
        puVar1 = (undefined4 *)(puVar11 + uVar20);
        uVar5 = puVar1[1];
        uVar6 = puVar1[2];
        uVar7 = puVar1[3];
        uVar8 = *(undefined8 *)(puVar11 + uVar20 + 0x10);
        uVar9 = *(undefined8 *)((longlong)(puVar11 + uVar20 + 0x10) + 8);
        puVar2 = (undefined4 *)((longlong)uStack_70 + uVar20 + local_68);
        *puVar2 = *puVar1;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar13 = (undefined8 *)((longlong)uStack_70 + uVar20 + local_68 + 0x10);
        *puVar13 = uVar8;
        puVar13[1] = uVar9;
        uVar20 = uVar20 + 0x20;
      } while (uVar19 != uVar20);
      if (uVar16 == uVar19) goto LAB_14003dce8;
      puVar17 = puVar11 + uVar19;
      if ((uVar16 & 0x18) == 0) goto LAB_14003dda0;
    }
    uVar20 = uVar16 & 0xfffffffffffffff8;
    lVar15 = local_68 + uVar20;
    puVar17 = puVar11 + uVar20;
    do {
      *(undefined8 *)(local_68 + (longlong)uStack_70 + uVar19) = *(undefined8 *)(puVar11 + uVar19);
      uVar19 = uVar19 + 8;
    } while (uVar20 != uVar19);
    if (uVar16 == uVar20) goto LAB_14003dce8;
  }
LAB_14003dda0:
  puVar21 = puVar11 + uVar16;
  uVar14 = (int)puVar21 - (int)puVar17 & 3;
  uVar16 = (ulonglong)uVar14;
  puVar18 = puVar17;
  if (uVar14 != 0) {
    do {
      uVar3 = *puVar18;
      puVar18 = puVar18 + 1;
      *(undefined1 *)((longlong)uStack_70 + lVar15) = uVar3;
      lVar15 = lVar15 + 1;
      uVar16 = uVar16 - 1;
    } while (uVar16 != 0);
  }
  if ((ulonglong)((longlong)puVar17 - (longlong)puVar21) < 0xfffffffffffffffd) {
    do {
      *(undefined1 *)((longlong)uStack_70 + lVar15) = *puVar18;
      *(undefined1 *)((longlong)uStack_70 + lVar15 + 1) = puVar18[1];
      *(undefined1 *)((longlong)uStack_70 + lVar15 + 2) = puVar18[2];
      *(undefined1 *)((longlong)uStack_70 + lVar15 + 3) = puVar18[3];
      lVar15 = lVar15 + 4;
      puVar18 = puVar18 + 4;
    } while (puVar18 != puVar21);
  }
LAB_14003dce8:
  local_68 = lVar15;
  if (lVar10 == 0) {
    *(longlong *)(param_1 + 4) = lVar15;
    *param_1 = (undefined4)local_78;
    param_1[1] = local_78._4_4_;
    param_1[2] = (undefined4)uStack_70;
    param_1[3] = uStack_70._4_4_;
    core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(param_2);
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar11,lVar10,1);
  return;
}

