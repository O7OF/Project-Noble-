// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::vec::Vec<(usize,&[u8],alloc[246c2e7857c81348]::vec::Vec<u8>)>>
// address: 0x140003110
// body: available
// range: 0x140003110-0x14000312e inclusive
// range: 0x140003130-0x14000314f inclusive
// range: 0x140003152-0x140003182 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000314b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003174 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::vec::Vec<(usize, &[u8],
   alloc[246c2e7857c81348]::vec::Vec<u8>)>> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<alloc[246c2e7857c81348]::vec::Vec<(usize,&[u8],alloc[246c2e7857c81348]::vec::Vec<u8>)>>
          (longlong *param_1)

{
  longlong lVar1;
  undefined8 *puVar2;
  
  lVar1 = param_1[2];
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)(param_1[1] + 0x20);
    do {
      if (puVar2[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar2,puVar2[-1],1);
        return;
      }
      puVar2 = puVar2 + 6;
      lVar1 = lVar1 + -1;
    } while (lVar1 != 0);
  }
  if (*param_1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],*param_1 * 0x30,8);
    return;
  }
  return;
}

