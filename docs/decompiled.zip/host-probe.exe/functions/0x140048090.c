// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<[u8;32usize]>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<[u8;32usize],core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,host_probe[b94139f9089eb1d8]::aiwave::parse_digest>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
// address: 0x140048090
// body: available
// range: 0x140048090-0x1400481bc inclusive
// range: 0x1400481c0-0x1400482cf inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<[u8; 32usize]> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<[u8; 32usize],
   core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,
   host_probe[b94139f9089eb1d8]::aiwave::parse_digest>,
   core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<[u8;32usize]>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<[u8;32usize],core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,host_probe[b94139f9089eb1d8]::aiwave::parse_digest>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  undefined8 *puVar8;
  longlong lVar9;
  undefined1 local_141;
  longlong local_140;
  undefined8 *puStack_138;
  longlong local_130;
  undefined4 local_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 local_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined1 uStack_108;
  undefined4 local_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined1 uStack_d8;
  undefined7 uStack_d7;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  
  <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,host_probe[b94139f9089eb1d8]::aiwave::parse_digest>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::try_fold::
  <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,host_probe[b94139f9089eb1d8]::aiwave::parse_digest>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<[u8_32usize],core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>>>
            (&local_f8,param_2 + 1,&local_141,*param_2);
  if ((char)local_f8 != '\x02') {
    local_118 = (undefined4)CONCAT43(uStack_e4,uStack_e8._1_3_);
    uStack_114 = (undefined4)
                 (CONCAT17((undefined1)uStack_e0,CONCAT43(uStack_e4,uStack_e8._1_3_)) >> 0x20);
    uStack_110 = (undefined4)CONCAT43(uStack_dc,uStack_e0._1_3_);
    uStack_10c = (undefined4)(CONCAT17(uStack_d8,CONCAT43(uStack_dc,uStack_e0._1_3_)) >> 0x20);
    local_128 = (undefined4)CONCAT43(uStack_f4,local_f8._1_3_);
    uStack_124 = (undefined4)
                 (CONCAT17((undefined1)uStack_f0,CONCAT43(uStack_f4,local_f8._1_3_)) >> 0x20);
    uStack_120 = (undefined4)CONCAT43(uStack_ec,uStack_f0._1_3_);
    uStack_11c = (undefined4)
                 (CONCAT17((undefined1)uStack_e8,CONCAT43(uStack_ec,uStack_f0._1_3_)) >> 0x20);
    if ((char)local_f8 == '\x01') {
      local_98 = local_118;
      uStack_94 = uStack_114;
      uStack_90 = uStack_110;
      uStack_8c = uStack_10c;
      local_a8 = local_128;
      uStack_a4 = uStack_124;
      uStack_a0 = uStack_120;
      uStack_9c = uStack_11c;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      puVar8 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x80,1);
      if (puVar8 == (undefined8 *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x80);
                    /* WARNING: Does not return */
        pcVar2 = (code *)invalidInstructionException();
        (*pcVar2)();
      }
      puVar8[2] = CONCAT44(uStack_94,local_98);
      puVar8[3] = CONCAT44(uStack_8c,uStack_90);
      *puVar8 = CONCAT44(uStack_a4,local_a8);
      puVar8[1] = CONCAT44(uStack_9c,uStack_a0);
      local_140 = 4;
      local_130 = 1;
      local_b8 = param_2[8];
      uStack_b0 = param_2[9];
      local_f8 = *(undefined4 *)param_2;
      uStack_f4 = *(undefined4 *)((longlong)param_2 + 4);
      uStack_f0 = *(undefined4 *)(param_2 + 1);
      uStack_ec = *(undefined4 *)((longlong)param_2 + 0xc);
      uStack_e8 = *(undefined4 *)(param_2 + 2);
      uStack_e4 = *(undefined4 *)((longlong)param_2 + 0x14);
      uStack_e0 = *(undefined4 *)(param_2 + 3);
      uStack_dc = *(undefined4 *)((longlong)param_2 + 0x1c);
      uStack_d0 = param_2[5];
      local_c8 = param_2[6];
      uStack_c0 = param_2[7];
      uStack_d8 = (undefined1)param_2[4];
      uStack_d7 = (undefined7)((ulonglong)param_2[4] >> 8);
      lVar9 = 0;
      puStack_138 = puVar8;
      while( true ) {
        lVar7 = local_130;
        <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,host_probe[b94139f9089eb1d8]::aiwave::parse_digest>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
        ::try_fold::
        <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,host_probe[b94139f9089eb1d8]::aiwave::parse_digest>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<[u8_32usize],core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<[u8_32usize]>>>
                  (&local_128,&uStack_f0,&local_141,CONCAT44(uStack_f4,local_f8));
        if ((char)local_128 == '\x02') break;
        uVar3 = CONCAT17((undefined1)uStack_120,CONCAT43(uStack_124,local_128._1_3_));
        uVar4 = CONCAT17((undefined1)local_118,CONCAT43(uStack_11c,uStack_120._1_3_));
        uVar5 = CONCAT17((undefined1)uStack_110,CONCAT43(uStack_114,local_118._1_3_));
        uVar6 = CONCAT17(uStack_108,CONCAT43(uStack_10c,uStack_110._1_3_));
        if ((char)local_128 != '\x01') break;
        local_68._0_4_ = (undefined4)CONCAT43(uStack_124,local_128._1_3_);
        local_88 = (undefined4)local_68;
        local_68._4_4_ = (undefined4)((ulonglong)uVar3 >> 0x20);
        uStack_84 = local_68._4_4_;
        uStack_60._0_4_ = (undefined4)CONCAT43(uStack_11c,uStack_120._1_3_);
        uStack_80 = (undefined4)uStack_60;
        uStack_60._4_4_ = (undefined4)((ulonglong)uVar4 >> 0x20);
        uStack_7c = uStack_60._4_4_;
        local_58._0_4_ = (undefined4)CONCAT43(uStack_114,local_118._1_3_);
        local_78 = (undefined4)local_58;
        local_58._4_4_ = (undefined4)((ulonglong)uVar5 >> 0x20);
        uStack_74 = local_58._4_4_;
        uStack_50._0_4_ = (undefined4)CONCAT43(uStack_10c,uStack_110._1_3_);
        uStack_70 = (undefined4)uStack_50;
        uStack_50._4_4_ = (undefined4)((ulonglong)uVar6 >> 0x20);
        uStack_6c = uStack_50._4_4_;
        local_68 = uVar3;
        uStack_60 = uVar4;
        local_58 = uVar5;
        uStack_50 = uVar6;
        if (lVar7 == local_140) {
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>(&local_140,lVar7,1,1,0x20);
          puVar8 = puStack_138;
        }
        puVar1 = (undefined4 *)(lVar9 + 0x30 + (longlong)puVar8);
        *puVar1 = local_78;
        puVar1[1] = uStack_74;
        puVar1[2] = uStack_70;
        puVar1[3] = uStack_6c;
        puVar1 = (undefined4 *)(lVar9 + 0x20 + (longlong)puVar8);
        *puVar1 = local_88;
        puVar1[1] = uStack_84;
        puVar1[2] = uStack_80;
        puVar1[3] = uStack_7c;
        local_130 = lVar7 + 1;
        lVar9 = lVar9 + 0x20;
      }
      param_1[2] = local_130;
      *param_1 = local_140;
      param_1[1] = (longlong)puStack_138;
      return param_1;
    }
  }
  *param_1 = 0;
  param_1[1] = 1;
  param_1[2] = 0;
  return param_1;
}

