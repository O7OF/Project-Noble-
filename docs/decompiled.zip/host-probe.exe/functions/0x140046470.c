// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<serde_core[7f01a81d286c67f3]::private::content::Content>
// address: 0x140046470
// body: available
// range: 0x140046470-0x1400465ac inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400465a8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<serde_core[7f01a81d286c67f3]::private::content::Content>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<serde_core[7f01a81d286c67f3]::private::content::Content>
          (undefined1 *param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong lVar4;
  
  switch(*param_1) {
  case 0:
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
  case 10:
  case 0xb:
  case 0xd:
  case 0xf:
  case 0x10:
  case 0x12:
    return;
  case 0xc:
  case 0xe:
    lVar3 = *(longlong *)(param_1 + 8);
    if (lVar3 == 0) {
      return;
    }
    lVar1 = *(longlong *)(param_1 + 0x10);
    uVar2 = 1;
    goto LAB_14004659b;
  case 0x11:
    lVar1 = *(longlong *)(param_1 + 8);
    <serde_core[7f01a81d286c67f3]::private::content::Content>(lVar1);
    break;
  case 0x13:
    lVar1 = *(longlong *)(param_1 + 8);
    <serde_core[7f01a81d286c67f3]::private::content::Content>(lVar1);
    break;
  case 0x14:
    lVar1 = *(longlong *)(param_1 + 0x10);
    if (*(longlong *)(param_1 + 0x18) != 0) {
      lVar4 = 1 - *(longlong *)(param_1 + 0x18);
      lVar3 = lVar1;
      do {
        <serde_core[7f01a81d286c67f3]::private::content::Content>(lVar3);
        lVar3 = lVar3 + 0x20;
        lVar4 = lVar4 + 1;
      } while (lVar4 != 1);
    }
    if (*(longlong *)(param_1 + 8) == 0) {
      return;
    }
    lVar3 = *(longlong *)(param_1 + 8) << 5;
    goto LAB_140046568;
  default:
    lVar1 = *(longlong *)(param_1 + 0x10);
    if (*(longlong *)(param_1 + 0x18) != 0) {
      lVar4 = 1 - *(longlong *)(param_1 + 0x18);
      lVar3 = 0;
      do {
        <serde_core[7f01a81d286c67f3]::private::content::Content>(lVar1 + lVar3);
        <serde_core[7f01a81d286c67f3]::private::content::Content>(lVar1 + lVar3 + 0x20);
        lVar4 = lVar4 + 1;
        lVar3 = lVar3 + 0x40;
      } while (lVar4 != 1);
    }
    if (*(longlong *)(param_1 + 8) == 0) {
      return;
    }
    lVar3 = *(longlong *)(param_1 + 8) << 6;
LAB_140046568:
    uVar2 = 8;
    goto LAB_14004659b;
  }
  lVar3 = 0x20;
  uVar2 = 8;
LAB_14004659b:
  __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar1,lVar3,uVar2);
  return;
}

