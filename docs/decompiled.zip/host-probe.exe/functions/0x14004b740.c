// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::sync::atomic::Atomic<u32>>,host_probe[b94139f9089eb1d8]::glow::frame::{closure#0}>,host_probe[b94139f9089eb1d8]::glow::frame::{closure#1}>,host_probe[b94139f9089eb1d8]::glow::frame::{closure#2}>>>::from_iter
// address: 0x14004b740
// body: available
// range: 0x14004b740-0x14004b904 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::sync::atomic::Atomic<u32>>,
   host_probe[b94139f9089eb1d8]::glow::frame::{closure#0}>,
   host_probe[b94139f9089eb1d8]::glow::frame::{closure#1}>,
   host_probe[b94139f9089eb1d8]::glow::frame::{closure#2}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::sync::atomic::Atomic<u32>>,host_probe[b94139f9089eb1d8]::glow::frame::{closure#0}>,host_probe[b94139f9089eb1d8]::glow::frame::{closure#1}>,host_probe[b94139f9089eb1d8]::glow::frame::{closure#2}>>>
::from_iter(longlong *param_1,int *param_2,int *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  code *pcVar3;
  undefined4 *puVar4;
  longlong lVar5;
  longlong local_a0;
  undefined4 *puStack_98;
  longlong local_90;
  int local_84;
  undefined8 local_80;
  undefined8 uStack_78;
  undefined8 local_70;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  int *local_50;
  code *local_48;
  
  do {
    if (param_2 == param_3) goto LAB_14004b8b3;
    LOCK();
    iVar2 = *param_2;
    *param_2 = 0;
    UNLOCK();
    param_2 = param_2 + 1;
  } while (iVar2 == 0);
  local_a0 = CONCAT44(local_a0._4_4_,iVar2);
  local_80 = &local_a0;
  uStack_78 = <u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_68,&DAT_1406a3da0,&local_80);
  if (CONCAT44(uStack_64,local_68) == -1) {
LAB_14004b8b3:
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    puVar4 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
    if (puVar4 == (undefined4 *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
      pcVar3 = (code *)invalidInstructionException();
      (*pcVar3)();
    }
    *(undefined8 *)(puVar4 + 4) = local_58;
    *puVar4 = local_68;
    puVar4[1] = uStack_64;
    puVar4[2] = uStack_60;
    puVar4[3] = uStack_5c;
    local_a0 = 4;
    local_90 = 1;
    lVar5 = 1;
    puStack_98 = puVar4;
    while (param_2 != param_3) {
      LOCK();
      local_84 = *param_2;
      *param_2 = 0;
      UNLOCK();
      param_2 = param_2 + 1;
      if (local_84 != 0) {
        local_50 = &local_84;
        local_48 = <u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_80,&DAT_1406a3da0,&local_50);
        if (local_80 == (longlong *)0xffffffffffffffff) break;
        if (lVar5 == local_a0) {
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>(&local_a0,lVar5,1,8,0x18);
          puVar4 = puStack_98;
        }
        *(undefined8 *)(puVar4 + lVar5 * 6 + 4) = local_70;
        puVar1 = puVar4 + lVar5 * 6;
        *puVar1 = (undefined4)local_80;
        puVar1[1] = local_80._4_4_;
        puVar1[2] = (undefined4)uStack_78;
        puVar1[3] = uStack_78._4_4_;
        lVar5 = lVar5 + 1;
        local_90 = lVar5;
      }
    }
    param_1[2] = local_90;
    *param_1 = local_a0;
    param_1[1] = (longlong)puStack_98;
  }
  return param_1;
}

