// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::set_prebound_socket
// address: 0x140026e20
// body: available
// range: 0x140026e20-0x140026f2a inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140026f0d to 0x140610d80 <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::set_prebound_socket */

void __rustcall host_probe[b94139f9089eb1d8]::net::set_prebound_socket(undefined8 param_1)

{
  code *pcVar1;
  undefined *puVar2;
  char cVar3;
  bool bVar4;
  undefined1 *local_28;
  byte local_20;
  
  LOCK();
  bVar4 = PREBOUND == '\0';
  if (bVar4) {
    PREBOUND = '\x01';
  }
  UNLOCK();
  if (!bVar4) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&PREBOUND);
  }
  puVar2 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    local_20 = 0;
  }
  else {
    local_20 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_20 = local_20 ^ 1;
  }
  if (DAT_1406997b9 != '\0') {
    local_28 = &PREBOUND;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_28,
               &anon_d5c34e88a06ee720b116585eb143da4b_143_llvm_14435704873730135342,
               &anon_d5c34e88a06ee720b116585eb143da4b_439_llvm_14435704873730135342);
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  if (DAT_1406997c0 != 0xffffffffffffffff) {
    closesocket(DAT_1406997c0);
  }
  DAT_1406997c0 = param_1;
  if (((local_20 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
     (cVar3 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar3 == '\0')) {
    DAT_1406997b9 = '\x01';
  }
  cVar3 = PREBOUND;
  LOCK();
  PREBOUND = 0;
  UNLOCK();
  if (cVar3 != '\x02') {
    return;
  }
  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&PREBOUND);
  return;
}

