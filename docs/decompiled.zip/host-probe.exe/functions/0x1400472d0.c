// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u32,u32,[u8;90usize])>>::resize
// address: 0x1400472d0
// body: available
// range: 0x1400472d0-0x1400474c9 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u32, u32, [u8; 90usize])>>::resize */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u32,u32,[u8;90usize])>>::resize
          (longlong *param_1,ulonglong param_2,undefined4 *param_3)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  undefined8 *puVar14;
  undefined4 *puVar15;
  ulonglong uVar16;
  
  uVar4 = param_1[2];
  uVar13 = param_2 - uVar4;
  if (param_2 < uVar4 || uVar13 == 0) goto LAB_140047480;
  uVar2 = *param_3;
  uVar3 = param_3[1];
  uVar1 = *(undefined2 *)((longlong)param_3 + 0x62);
  uVar12 = uVar4;
  if (*param_1 - uVar4 < uVar13) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,uVar4,uVar13,4,100);
    uVar12 = param_1[2];
  }
  puVar14 = (undefined8 *)(param_3 + 2);
  puVar15 = (undefined4 *)(uVar12 * 100 + param_1[1]);
  if (1 < uVar13) {
    if (param_2 - 2 == uVar4) {
LAB_1400473e7:
      *puVar15 = uVar2;
      puVar15[1] = uVar3;
      uVar5 = *(undefined8 *)(param_3 + 4);
      uVar6 = *(undefined8 *)(param_3 + 6);
      uVar7 = *(undefined8 *)(param_3 + 8);
      uVar8 = *(undefined8 *)(param_3 + 10);
      uVar9 = *(undefined8 *)(param_3 + 0xc);
      uVar10 = *(undefined8 *)(param_3 + 0xe);
      uVar11 = *(undefined8 *)(param_3 + 0x10);
      *(undefined8 *)(puVar15 + 2) = *puVar14;
      *(undefined8 *)(puVar15 + 4) = uVar5;
      *(undefined8 *)(puVar15 + 6) = uVar6;
      *(undefined8 *)(puVar15 + 8) = uVar7;
      *(undefined8 *)(puVar15 + 10) = uVar8;
      *(undefined8 *)(puVar15 + 0xc) = uVar9;
      *(undefined8 *)(puVar15 + 0xe) = uVar10;
      *(undefined8 *)(puVar15 + 0x10) = uVar11;
      uVar5 = *(undefined8 *)(param_3 + 0x14);
      *(undefined8 *)(puVar15 + 0x12) = *(undefined8 *)(param_3 + 0x12);
      *(undefined8 *)(puVar15 + 0x14) = uVar5;
      uVar5 = *(undefined8 *)((longlong)param_3 + 0x5a);
      *(undefined8 *)((longlong)puVar15 + 0x52) = *(undefined8 *)((longlong)param_3 + 0x52);
      *(undefined8 *)((longlong)puVar15 + 0x5a) = uVar5;
      puVar15 = puVar15 + 0x19;
    }
    else {
      uVar16 = param_2 + ~uVar4 & 0xfffffffffffffffe;
      do {
        *puVar15 = uVar2;
        puVar15[1] = uVar3;
        uVar5 = *(undefined8 *)(param_3 + 4);
        uVar6 = *(undefined8 *)(param_3 + 6);
        uVar7 = *(undefined8 *)(param_3 + 8);
        uVar8 = *(undefined8 *)(param_3 + 10);
        uVar9 = *(undefined8 *)(param_3 + 0xc);
        uVar10 = *(undefined8 *)(param_3 + 0xe);
        uVar11 = *(undefined8 *)(param_3 + 0x10);
        *(undefined8 *)(puVar15 + 2) = *puVar14;
        *(undefined8 *)(puVar15 + 4) = uVar5;
        *(undefined8 *)(puVar15 + 6) = uVar6;
        *(undefined8 *)(puVar15 + 8) = uVar7;
        *(undefined8 *)(puVar15 + 10) = uVar8;
        *(undefined8 *)(puVar15 + 0xc) = uVar9;
        *(undefined8 *)(puVar15 + 0xe) = uVar10;
        *(undefined8 *)(puVar15 + 0x10) = uVar11;
        uVar5 = *(undefined8 *)(param_3 + 0x14);
        *(undefined8 *)(puVar15 + 0x12) = *(undefined8 *)(param_3 + 0x12);
        *(undefined8 *)(puVar15 + 0x14) = uVar5;
        uVar5 = *(undefined8 *)((longlong)param_3 + 0x5a);
        *(undefined8 *)((longlong)puVar15 + 0x52) = *(undefined8 *)((longlong)param_3 + 0x52);
        *(undefined8 *)((longlong)puVar15 + 0x5a) = uVar5;
        puVar15[0x19] = uVar2;
        puVar15[0x1a] = uVar3;
        uVar5 = *(undefined8 *)(param_3 + 4);
        uVar6 = *(undefined8 *)(param_3 + 6);
        uVar7 = *(undefined8 *)(param_3 + 8);
        uVar8 = *(undefined8 *)(param_3 + 10);
        uVar9 = *(undefined8 *)(param_3 + 0xc);
        uVar10 = *(undefined8 *)(param_3 + 0xe);
        uVar11 = *(undefined8 *)(param_3 + 0x10);
        *(undefined8 *)(puVar15 + 0x1b) = *puVar14;
        *(undefined8 *)(puVar15 + 0x1d) = uVar5;
        *(undefined8 *)(puVar15 + 0x1f) = uVar6;
        *(undefined8 *)(puVar15 + 0x21) = uVar7;
        *(undefined8 *)(puVar15 + 0x23) = uVar8;
        *(undefined8 *)(puVar15 + 0x25) = uVar9;
        *(undefined8 *)(puVar15 + 0x27) = uVar10;
        *(undefined8 *)(puVar15 + 0x29) = uVar11;
        uVar5 = *(undefined8 *)(param_3 + 0x14);
        *(undefined8 *)(puVar15 + 0x2b) = *(undefined8 *)(param_3 + 0x12);
        *(undefined8 *)(puVar15 + 0x2d) = uVar5;
        uVar5 = *(undefined8 *)((longlong)param_3 + 0x5a);
        *(undefined8 *)((longlong)puVar15 + 0xb6) = *(undefined8 *)((longlong)param_3 + 0x52);
        *(undefined8 *)((longlong)puVar15 + 0xbe) = uVar5;
        puVar15 = puVar15 + 0x32;
        uVar16 = uVar16 - 2;
      } while (uVar16 != 0);
      if ((param_2 + ~uVar4 & 1) != 0) goto LAB_1400473e7;
    }
    uVar12 = (uVar12 + uVar13) - 1;
  }
  *puVar15 = uVar2;
  puVar15[1] = uVar3;
  uVar5 = *(undefined8 *)(param_3 + 4);
  uVar6 = *(undefined8 *)(param_3 + 6);
  uVar7 = *(undefined8 *)(param_3 + 8);
  uVar8 = *(undefined8 *)(param_3 + 10);
  uVar9 = *(undefined8 *)(param_3 + 0xc);
  uVar10 = *(undefined8 *)(param_3 + 0xe);
  uVar11 = *(undefined8 *)(param_3 + 0x10);
  *(undefined8 *)(puVar15 + 2) = *puVar14;
  *(undefined8 *)(puVar15 + 4) = uVar5;
  *(undefined8 *)(puVar15 + 6) = uVar6;
  *(undefined8 *)(puVar15 + 8) = uVar7;
  *(undefined8 *)(puVar15 + 10) = uVar8;
  *(undefined8 *)(puVar15 + 0xc) = uVar9;
  *(undefined8 *)(puVar15 + 0xe) = uVar10;
  *(undefined8 *)(puVar15 + 0x10) = uVar11;
  uVar5 = *(undefined8 *)(param_3 + 0x14);
  *(undefined8 *)(puVar15 + 0x12) = *(undefined8 *)(param_3 + 0x12);
  *(undefined8 *)(puVar15 + 0x14) = uVar5;
  uVar5 = *(undefined8 *)((longlong)param_3 + 0x5a);
  *(undefined8 *)((longlong)puVar15 + 0x52) = *(undefined8 *)((longlong)param_3 + 0x52);
  *(undefined8 *)((longlong)puVar15 + 0x5a) = uVar5;
  *(undefined2 *)((longlong)puVar15 + 0x62) = uVar1;
  param_2 = uVar12 + 1;
LAB_140047480:
  param_1[2] = param_2;
  return;
}

