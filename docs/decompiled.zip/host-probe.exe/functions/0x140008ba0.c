// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold::<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<&mut_core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>::{closure#0}>::{closure#0}>
// address: 0x140008ba0
// body: available
// range: 0x140008ba0-0x140008d01 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut 
   core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>
   as core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold::<(),
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,
   <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<&mut
   core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>::{closure#0}>::{closure#0}>
    */

void __rustcall
<&mut_core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
::fold::
<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<&mut_core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>::_closure_0_>::_closure_0_>
          (longlong *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined1 uVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined1 *puVar5;
  undefined1 *puVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined1 *puVar11;
  ulonglong uVar12;
  longlong lVar13;
  undefined1 *puVar14;
  uint uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  
  plVar3 = (longlong *)*param_2;
  lVar4 = param_2[1];
  puVar5 = (undefined1 *)*param_1;
  puVar6 = (undefined1 *)param_1[1];
  lVar13 = lVar4;
  if (puVar5 == puVar6) goto LAB_140008c6c;
  lVar7 = param_2[2];
  uVar12 = (longlong)puVar6 - (longlong)puVar5;
  puVar14 = puVar5;
  if ((uVar12 < 8) || (0xffffffffffffffe0 < (ulonglong)((longlong)puVar5 - (lVar4 + lVar7)))) {
LAB_140008bea:
    uVar15 = (int)puVar6 - (int)puVar14 & 3;
    uVar12 = (ulonglong)uVar15;
    puVar11 = puVar14;
    if (uVar15 != 0) {
      do {
        uVar2 = *puVar11;
        puVar11 = puVar11 + 1;
        *(undefined1 *)(lVar7 + lVar13) = uVar2;
        lVar13 = lVar13 + 1;
        uVar12 = uVar12 - 1;
      } while (uVar12 != 0);
    }
    if ((ulonglong)((longlong)puVar14 - (longlong)puVar6) < 0xfffffffffffffffd) {
      do {
        *(undefined1 *)(lVar7 + lVar13) = *puVar11;
        *(undefined1 *)(lVar7 + 1 + lVar13) = puVar11[1];
        *(undefined1 *)(lVar7 + 2 + lVar13) = puVar11[2];
        puVar5 = puVar11 + 3;
        puVar11 = puVar11 + 4;
        *(undefined1 *)(lVar7 + 3 + lVar13) = *puVar5;
        lVar13 = lVar13 + 4;
      } while (puVar11 != puVar6);
    }
  }
  else if (uVar12 < 0x20) {
    uVar16 = 0;
LAB_140008cce:
    uVar17 = uVar12 & 0xfffffffffffffff8;
    lVar13 = lVar4 + uVar17;
    puVar11 = puVar5 + uVar17;
    do {
      *(undefined8 *)(lVar4 + lVar7 + uVar16) = *(undefined8 *)(puVar5 + uVar16);
      uVar16 = uVar16 + 8;
    } while (uVar17 != uVar16);
    puVar14 = puVar11;
    if (uVar12 != uVar17) goto LAB_140008bea;
  }
  else {
    uVar16 = uVar12 & 0xffffffffffffffe0;
    lVar13 = lVar4 + uVar16;
    puVar11 = puVar5 + uVar16;
    uVar17 = 0;
    do {
      uVar8 = *(undefined8 *)((longlong)(puVar5 + uVar17) + 8);
      uVar9 = *(undefined8 *)(puVar5 + uVar17 + 0x10);
      uVar10 = *(undefined8 *)((longlong)(puVar5 + uVar17 + 0x10) + 8);
      puVar1 = (undefined8 *)(lVar4 + lVar7 + uVar17);
      *puVar1 = *(undefined8 *)(puVar5 + uVar17);
      puVar1[1] = uVar8;
      puVar1 = (undefined8 *)(lVar4 + lVar7 + 0x10 + uVar17);
      *puVar1 = uVar9;
      puVar1[1] = uVar10;
      uVar17 = uVar17 + 0x20;
    } while (uVar16 != uVar17);
    if (uVar12 != uVar16) {
      puVar14 = puVar11;
      if ((uVar12 & 0x18) == 0) goto LAB_140008bea;
      goto LAB_140008cce;
    }
  }
  *param_1 = (longlong)puVar11;
LAB_140008c6c:
  *plVar3 = lVar13;
  return;
}

