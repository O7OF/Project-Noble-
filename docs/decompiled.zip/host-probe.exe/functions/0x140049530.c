// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<f32>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<f32,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}::{closure#0}>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
// address: 0x140049530
// body: available
// range: 0x140049530-0x140049620 inclusive
// range: 0x140049630-0x140049733 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<f32> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<f32,
   core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}::{closure#0}>,
   core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
    */

SIZE_T * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<f32>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<f32,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}::{closure#0}>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>
::from_iter(SIZE_T *param_1,undefined8 *param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  undefined1 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  code *pcVar6;
  undefined4 uVar7;
  SIZE_T SVar8;
  BOOL BVar9;
  HANDLE pvVar10;
  undefined4 *puVar11;
  longlong lVar12;
  SIZE_T local_88;
  undefined4 local_7c;
  SIZE_T local_78;
  undefined4 *local_70;
  SIZE_T local_68;
  undefined1 *local_60;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  if (uVar1 < uVar2) {
    puVar3 = (undefined1 *)param_2[3];
    plVar4 = (longlong *)*param_2;
    lVar12 = *plVar4;
    local_88 = local_88 & 0xffffffff00000000;
    local_78 = 0;
    pvVar10 = GetCurrentProcess();
    BVar9 = ReadProcessMemory(pvVar10,(LPCVOID)(uVar1 * 4 + lVar12),&local_88,4,&local_78);
    if ((BVar9 != 0) && (local_78 == 4)) {
      uVar7 = (undefined4)local_88;
      local_60 = puVar3;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      puVar11 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x10,4);
      if (puVar11 == (undefined4 *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(4,0x10);
                    /* WARNING: Does not return */
        pcVar6 = (code *)invalidInstructionException();
        (*pcVar6)();
      }
      *puVar11 = uVar7;
      local_78 = 4;
      local_68 = 1;
      local_70 = puVar11;
      if (uVar1 + 1 < uVar2) {
        lVar12 = uVar1 * 4;
        do {
          SVar8 = local_68;
          lVar12 = lVar12 + 4;
          lVar5 = *plVar4;
          local_7c = 0;
          local_88 = 0;
          pvVar10 = GetCurrentProcess();
          BVar9 = ReadProcessMemory(pvVar10,(LPCVOID)(lVar5 + lVar12),&local_7c,4,&local_88);
          uVar7 = local_7c;
          if ((BVar9 == 0) || (local_88 != 4)) {
            *local_60 = 1;
            break;
          }
          if (SVar8 == local_78) {
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
            <alloc[246c2e7857c81348]::alloc::Global>(&local_78,SVar8,1,4,4);
            puVar11 = local_70;
          }
          puVar11[SVar8] = uVar7;
          local_68 = SVar8 + 1;
        } while (uVar2 - uVar1 != local_68);
      }
      param_1[2] = local_68;
      *param_1 = local_78;
      param_1[1] = (SIZE_T)local_70;
      return param_1;
    }
    *puVar3 = 1;
  }
  *param_1 = 0;
  param_1[1] = 4;
  param_1[2] = 0;
  return param_1;
}

