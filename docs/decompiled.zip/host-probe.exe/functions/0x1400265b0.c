// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::note_star_oversize
// address: 0x1400265b0
// body: available
// range: 0x1400265b0-0x140026660 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14002665c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::note_star_oversize */

void __rustcall host_probe[b94139f9089eb1d8]::net::note_star_oversize(undefined8 param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  undefined8 local_68;
  ulonglong local_60;
  longlong local_58;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 *local_40;
  code *local_38;
  undefined *local_30;
  code *local_28;
  ulonglong *local_20;
  code *local_18;
  
  LOCK();
  lVar1 = DAT_1407f10f0 + 1;
  UNLOCK();
  local_60 = DAT_1407f10f0 + 1;
  if ((local_60 < 5) || (uVar2 = local_60 & DAT_1407f10f0, DAT_1407f10f0 = lVar1, uVar2 == 0)) {
    local_40 = &local_68;
    local_38 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_30 = &DAT_1406a2598;
    local_28 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_20 = &local_60;
    local_18 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    DAT_1407f10f0 = lVar1;
    local_68 = param_1;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a25a0,&local_40);
    host::log(local_50,local_48);
    if (local_58 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(local_50,local_58,1);
      return;
    }
  }
  return;
}

