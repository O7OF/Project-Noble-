// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::dropped
// address: 0x140028cb0
// body: available
// range: 0x140028cb0-0x140028dbe inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::dropped */

undefined8 __rustcall host_probe[b94139f9089eb1d8]::net::dropped(void)

{
  code *pcVar1;
  longlong lVar2;
  undefined *puVar3;
  char cVar4;
  undefined8 uVar5;
  bool bVar6;
  undefined1 *local_20;
  byte local_18;
  
  LOCK();
  bVar6 = IMPAIR == '\0';
  if (bVar6) {
    IMPAIR = '\x01';
  }
  UNLOCK();
  if (!bVar6) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended();
  }
  puVar3 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    local_18 = 0;
    lVar2 = DAT_140699658;
    uVar5 = DAT_1406996b8;
  }
  else {
    local_18 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_18 = local_18 ^ 1;
    lVar2 = DAT_140699658;
    uVar5 = DAT_1406996b8;
  }
  DAT_140699658 = lVar2;
  DAT_1406996b8 = uVar5;
  if (DAT_140699651 != '\0') {
    local_20 = &IMPAIR;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_20,
               &anon_d5c34e88a06ee720b116585eb143da4b_138_llvm_14435704873730135342,
               &anon_d5c34e88a06ee720b116585eb143da4b_457_llvm_14435704873730135342);
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  if (((local_18 == 0) && ((*(ulonglong *)puVar3 & 0x7fffffffffffffff) != 0)) &&
     (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar4 == '\0')) {
    DAT_140699651 = '\x01';
  }
  cVar4 = IMPAIR;
  LOCK();
  IMPAIR = 0;
  UNLOCK();
  if (cVar4 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&IMPAIR);
  }
  if (lVar2 == -1) {
    uVar5 = 0;
  }
  return uVar5;
}

