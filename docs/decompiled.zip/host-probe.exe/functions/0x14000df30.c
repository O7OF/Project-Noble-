// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::change_epoch
// address: 0x14000df30
// body: available
// range: 0x14000df30-0x14000dfc8 inclusive
// range: 0x14000dfd0-0x14000e02f inclusive
// range: 0x14000e039-0x14000e295 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000e02b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000e1b2 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000e245 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::change_epoch */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::change_epoch
          (longlong param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  ulonglong uVar8;
  longlong lVar9;
  ulonglong uVar10;
  char *pcVar11;
  ulonglong uVar12;
  longlong lVar13;
  ulonglong uVar14;
  longlong lVar15;
  ulonglong uVar16;
  bool bVar17;
  undefined4 local_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 local_d8;
  undefined1 local_b0 [120];
  
  uVar1 = *(undefined8 *)(param_1 + 0x58);
  uVar2 = *(undefined8 *)(param_1 + 0x60);
  uVar3 = *(undefined8 *)(param_1 + 0x68);
  uVar5 = param_2[1];
  uVar6 = param_2[2];
  uVar7 = param_2[3];
  *(undefined4 *)(param_1 + 0x58) = *param_2;
  *(undefined4 *)(param_1 + 0x5c) = uVar5;
  *(undefined4 *)(param_1 + 0x60) = uVar6;
  *(undefined4 *)(param_1 + 100) = uVar7;
  *(undefined8 *)(param_1 + 0x68) = *(undefined8 *)(param_2 + 4);
  uVar8 = *(ulonglong *)(param_1 + 0x88);
  uVar10 = *(ulonglong *)(param_1 + 0x70);
  if (uVar8 == uVar10) {
    <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<alloc[246c2e7857c81348]::string::String>>
    ::grow(param_1 + 0x70);
    uVar10 = *(ulonglong *)(param_1 + 0x70);
    uVar8 = *(ulonglong *)(param_1 + 0x88);
  }
  *(ulonglong *)(param_1 + 0x88) = uVar8 + 1;
  uVar8 = uVar8 + *(longlong *)(param_1 + 0x80);
  uVar12 = 0;
  if (uVar10 <= uVar8) {
    uVar12 = uVar10;
  }
  lVar9 = uVar8 - uVar12;
  lVar13 = *(longlong *)(param_1 + 0x78);
  *(undefined8 *)(lVar13 + lVar9 * 0x18) = uVar1;
  *(undefined8 *)(lVar13 + 8 + lVar9 * 0x18) = uVar2;
  *(undefined8 *)(lVar13 + 0x10 + lVar9 * 0x18) = uVar3;
  uVar8 = *(ulonglong *)(param_1 + 0x88);
  if (8 < uVar8) {
    do {
      lVar13 = *(longlong *)(param_1 + 0x80);
      uVar10 = *(ulonglong *)(param_1 + 0x70);
      if (lVar13 + 1U < *(ulonglong *)(param_1 + 0x70)) {
        uVar10 = 0;
      }
      *(ulonglong *)(param_1 + 0x80) = (lVar13 - uVar10) + 1;
      uVar8 = uVar8 - 1;
      *(ulonglong *)(param_1 + 0x88) = uVar8;
      uVar12 = *(ulonglong *)(*(longlong *)(param_1 + 0x78) + lVar13 * 0x18);
      if (uVar12 - 1 < 0xfffffffffffffffe) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc
                  (*(undefined8 *)(*(longlong *)(param_1 + 0x78) + lVar13 * 0x18 + 8),uVar12,1);
        return;
      }
    } while (8 < uVar8);
  }
  uVar8 = *(ulonglong *)(param_1 + 0x250);
  if (uVar8 != 0) {
    uVar10 = *(ulonglong *)(param_1 + 0x238);
    lVar13 = *(longlong *)(param_1 + 0x240);
    uVar12 = uVar10;
    if (*(ulonglong *)(param_1 + 0x248) < uVar10) {
      uVar12 = 0;
    }
    lVar9 = *(ulonglong *)(param_1 + 0x248) - uVar12;
    uVar16 = uVar10 - lVar9;
    uVar14 = lVar9 + uVar8;
    if (uVar16 < uVar8) {
      uVar14 = uVar10;
    }
    *(undefined8 *)(param_1 + 0x250) = 0;
    lVar15 = uVar14 - lVar9;
    if (lVar15 != 0) {
      lVar9 = lVar9 * 0x20 + lVar13;
      do {
        lVar15 = lVar15 + -1;
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(lVar9);
        lVar9 = lVar9 + 0x20;
      } while (lVar15 != 0);
    }
    if (uVar16 < uVar8) {
      if (uVar8 < uVar16) {
        uVar16 = uVar8;
      }
      lVar9 = ~uVar16 + uVar8;
      do {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(lVar13);
        lVar13 = lVar13 + 0x20;
        bVar17 = lVar9 != 0;
        lVar9 = lVar9 + -1;
      } while (bVar17);
    }
  }
  *(undefined8 *)(param_1 + 0x248) = 0;
  if (*(longlong *)(param_1 + 0x3a0) != 0) {
    uVar8 = *(ulonglong *)(param_1 + 0x390);
    if (uVar8 == 0) {
      uVar10 = 0;
    }
    else {
      memset(*(void **)(param_1 + 0x388),(int)CONCAT71((int7)(uVar12 >> 8),0xff),uVar8 + 0x11);
      uVar10 = (uVar8 + 1 & 0xfffffffffffffff8) - (uVar8 + 1 >> 3);
      if (uVar8 < 8) {
        uVar10 = uVar8;
      }
    }
    *(undefined8 *)(param_1 + 0x3a0) = 0;
    *(ulonglong *)(param_1 + 0x398) = uVar10;
  }
  *(undefined8 *)(param_1 + 0x3e0) = 0;
  *(undefined4 *)(param_1 + 1000) = 0;
  lVar13 = *(longlong *)(param_1 + 0x288);
  *(undefined8 *)(param_1 + 0x288) = 0xffffffffffffffff;
  if (lVar13 != -1) {
    memcpy(&uStack_e0,(void *)(param_1 + 0x290),0xa8);
    if (*(longlong *)(param_1 + 600) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (*(undefined8 *)(param_1 + 0x260),*(longlong *)(param_1 + 600),1);
      return;
    }
    *(undefined8 *)(param_1 + 0x268) = local_d8;
    local_e8 = (undefined4)lVar13;
    uStack_e4 = (undefined4)((ulonglong)lVar13 >> 0x20);
    *(undefined4 *)(param_1 + 600) = local_e8;
    *(undefined4 *)(param_1 + 0x25c) = uStack_e4;
    *(undefined4 *)(param_1 + 0x260) = uStack_e0;
    *(undefined4 *)(param_1 + 0x264) = uStack_dc;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    pcVar11 = (char *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x56,1);
    if (pcVar11 == (char *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x56);
                    /* WARNING: Does not return */
      pcVar4 = (code *)invalidInstructionException();
      (*pcVar4)();
    }
    builtin_strncpy(pcVar11,
                    "Match membership changed; delivery is unconfirmed. Check history before sending again."
                    ,0x56);
    if (*(longlong *)(param_1 + 0x270) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (*(undefined8 *)(param_1 + 0x278),*(longlong *)(param_1 + 0x270),1);
      return;
    }
    *(undefined8 *)(param_1 + 0x270) = 0x56;
    *(char **)(param_1 + 0x278) = pcVar11;
    *(undefined8 *)(param_1 + 0x280) = 0x56;
    core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
              (local_b0);
  }
  return;
}

