// rea decompile_all
// name: <[&str;9usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<alloc[246c2e7857c81348]::string::String>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<alloc[246c2e7857c81348]::string::String>>::wrap_mut_1<&str,<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::convert::From<&str>>::from>::{closure#0}>
// address: 0x140002250
// body: available
// range: 0x140002250-0x140002716 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <[&str;
   9usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<alloc[246c2e7857c81348]::string::String>,
   <core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<alloc[246c2e7857c81348]::string::String>>::wrap_mut_1<&str,
   <alloc[246c2e7857c81348]::string::String as
   core[505b25137b8ba7f]::convert::From<&str>>::from>::{closure#0}> */

void * __rustcall
<[&str;9usize]>::try_map::
<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<alloc[246c2e7857c81348]::string::String>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<alloc[246c2e7857c81348]::string::String>>::wrap_mut_1<&str,<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::convert::From<&str>>::from>::_closure_0_>
          (void *param_1,undefined8 *param_2)

{
  size_t _Size;
  size_t _Size_00;
  void *_Src;
  size_t _Size_01;
  void *_Src_00;
  size_t _Size_02;
  void *_Src_01;
  size_t _Size_03;
  void *_Src_02;
  size_t _Size_04;
  void *_Src_03;
  size_t _Size_05;
  void *_Src_04;
  size_t _Size_06;
  void *_Src_05;
  size_t _Size_07;
  void *_Src_06;
  code *pcVar1;
  void *pvVar2;
  void *pvVar3;
  undefined8 uVar4;
  size_t local_118;
  void *local_110;
  size_t local_108;
  size_t local_100;
  void *local_f8;
  size_t local_f0;
  size_t local_e8;
  void *local_e0;
  size_t local_d8;
  size_t local_d0;
  void *local_c8;
  size_t local_c0;
  size_t local_b8;
  void *local_b0;
  size_t local_a8;
  size_t local_a0;
  void *local_98;
  size_t local_90;
  size_t local_88;
  void *local_80;
  size_t local_78;
  size_t local_70;
  void *local_68;
  size_t local_60;
  size_t local_58;
  void *local_50;
  size_t local_48;
  
  _Size = param_2[1];
  if ((longlong)_Size < 0) {
    uVar4 = 0;
LAB_14000226f:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size);
    goto LAB_140002693;
  }
  pvVar3 = (void *)param_2[2];
  _Size_00 = param_2[3];
  _Src = (void *)param_2[4];
  _Size_01 = param_2[5];
  _Src_00 = (void *)param_2[6];
  _Size_02 = param_2[7];
  _Src_01 = (void *)param_2[8];
  _Size_03 = param_2[9];
  _Src_02 = (void *)param_2[10];
  _Size_04 = param_2[0xb];
  _Src_03 = (void *)param_2[0xc];
  _Size_05 = param_2[0xd];
  _Src_04 = (void *)param_2[0xe];
  _Size_06 = param_2[0xf];
  _Src_05 = (void *)param_2[0x10];
  _Size_07 = param_2[0x11];
  if (_Size == 0) {
    pvVar2 = (void *)0x1;
  }
  else {
    _Src_06 = (void *)*param_2;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar4 = 1;
    pvVar2 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size,1);
    if (pvVar2 == (void *)0x0) goto LAB_14000226f;
    memcpy(pvVar2,_Src_06,_Size);
  }
  local_118 = _Size;
  local_110 = pvVar2;
  local_108 = _Size;
  if ((longlong)_Size_00 < 0) {
    uVar4 = 0;
LAB_14000236b:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_00);
    goto LAB_140002693;
  }
  if (_Size_00 == 0) {
    pvVar2 = (void *)0x1;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar4 = 1;
    pvVar2 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_00,1);
    if (pvVar2 == (void *)0x0) goto LAB_14000236b;
    memcpy(pvVar2,pvVar3,_Size_00);
  }
  local_100 = _Size_00;
  local_f8 = pvVar2;
  local_f0 = _Size_00;
  if ((longlong)_Size_01 < 0) {
    uVar4 = 0;
LAB_1400023d5:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_01);
    goto LAB_140002693;
  }
  if (_Size_01 == 0) {
    pvVar3 = (void *)0x1;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar4 = 1;
    pvVar3 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_01,1);
    if (pvVar3 == (void *)0x0) goto LAB_1400023d5;
    memcpy(pvVar3,_Src,_Size_01);
  }
  local_e8 = _Size_01;
  local_e0 = pvVar3;
  local_d8 = _Size_01;
  if ((longlong)_Size_02 < 0) {
    uVar4 = 0;
LAB_140002444:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_02);
    goto LAB_140002693;
  }
  if (_Size_02 == 0) {
    pvVar3 = (void *)0x1;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar4 = 1;
    pvVar3 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_02,1);
    if (pvVar3 == (void *)0x0) goto LAB_140002444;
    memcpy(pvVar3,_Src_00,_Size_02);
  }
  local_d0 = _Size_02;
  local_c8 = pvVar3;
  local_c0 = _Size_02;
  if ((longlong)_Size_03 < 0) {
    uVar4 = 0;
LAB_1400024b8:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_03);
    goto LAB_140002693;
  }
  if (_Size_03 == 0) {
    pvVar3 = (void *)0x1;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar4 = 1;
    pvVar3 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_03,1);
    if (pvVar3 == (void *)0x0) goto LAB_1400024b8;
    memcpy(pvVar3,_Src_01,_Size_03);
  }
  local_b8 = _Size_03;
  local_b0 = pvVar3;
  local_a8 = _Size_03;
  if ((longlong)_Size_04 < 0) {
    uVar4 = 0;
LAB_140002538:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_04);
    goto LAB_140002693;
  }
  if (_Size_04 == 0) {
    pvVar3 = (void *)0x1;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar4 = 1;
    pvVar3 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_04,1);
    if (pvVar3 == (void *)0x0) goto LAB_140002538;
    memcpy(pvVar3,_Src_02,_Size_04);
  }
  local_a0 = _Size_04;
  local_98 = pvVar3;
  local_90 = _Size_04;
  if ((longlong)_Size_05 < 0) {
    uVar4 = 0;
LAB_1400025a4:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_05);
    goto LAB_140002693;
  }
  if (_Size_05 == 0) {
    pvVar3 = (void *)0x1;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar4 = 1;
    pvVar3 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_05,1);
    if (pvVar3 == (void *)0x0) goto LAB_1400025a4;
    memcpy(pvVar3,_Src_03,_Size_05);
  }
  local_88 = _Size_05;
  local_80 = pvVar3;
  local_78 = _Size_05;
  if ((longlong)_Size_06 < 0) {
    uVar4 = 0;
LAB_140002615:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_06);
  }
  else {
    if (_Size_06 == 0) {
      pvVar3 = (void *)0x1;
    }
    else {
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar4 = 1;
      pvVar3 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_06,1);
      if (pvVar3 == (void *)0x0) goto LAB_140002615;
      memcpy(pvVar3,_Src_04,_Size_06);
    }
    local_70 = _Size_06;
    local_68 = pvVar3;
    local_60 = _Size_06;
    if ((longlong)_Size_07 < 0) {
      uVar4 = 0;
    }
    else {
      if (_Size_07 == 0) {
        local_50 = (void *)0x1;
LAB_1400026cd:
        local_58 = _Size_07;
        local_48 = _Size_07;
        memcpy(param_1,&local_118,0xd8);
        return param_1;
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar4 = 1;
      local_50 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_07,1);
      if (local_50 != (void *)0x0) {
        memcpy(local_50,_Src_05,_Size_07);
        goto LAB_1400026cd;
      }
    }
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar4,_Size_07);
  }
LAB_140002693:
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

