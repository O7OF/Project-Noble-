// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::block_peer
// address: 0x140021a90
// body: available
// range: 0x140021a90-0x140021d04 inclusive
// range: 0x140021d10-0x140021df5 inclusive
// range: 0x140021e00-0x140022280 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::block_peer */

void __rustcall host_probe[b94139f9089eb1d8]::net::block_peer(longlong param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  undefined1 *puVar2;
  longlong lVar3;
  code *pcVar4;
  uint uVar5;
  uint uVar6;
  longlong lVar7;
  char *pcVar8;
  undefined2 uVar9;
  undefined *puVar10;
  byte bVar11;
  char cVar12;
  char cVar13;
  ulonglong uVar14;
  undefined8 uVar15;
  ulonglong uVar16;
  undefined1 (*pauVar17) [16];
  undefined4 uVar18;
  undefined1 (*pauVar19) [16];
  int iVar20;
  longlong lVar21;
  uint uVar22;
  ushort uVar23;
  ulonglong uVar24;
  bool bVar25;
  bool bVar26;
  byte bVar27;
  undefined1 auVar28 [16];
  undefined1 auVar29 [16];
  undefined1 auVar30 [16];
  undefined1 *local_100;
  undefined4 local_f8;
  undefined4 uStack_f4;
  byte local_f0;
  undefined1 *local_e8;
  undefined4 local_e0;
  undefined4 local_dc;
  byte bStack_d8;
  undefined1 uStack_d7;
  undefined2 uStack_d6;
  undefined2 uStack_d4;
  undefined6 uStack_d2;
  longlong local_cc;
  undefined8 uStack_c4;
  ulonglong local_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  longlong local_a0;
  undefined1 local_98 [8];
  byte local_90;
  undefined8 local_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  ulonglong uStack_68;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  
  if (DAT_140699990 != 0) {
    return;
  }
  uVar16 = param_2 & 0xffffffff;
  LOCK();
  bVar26 = DAT_140699948 == '\0';
  if (bVar26) {
    DAT_140699948 = '\x01';
  }
  UNLOCK();
  uVar24 = param_2;
  local_a0 = param_1;
  if (!bVar26) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
  }
  puVar10 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar11 = 0;
  }
  else {
    bVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar11 = bVar11 ^ 1;
  }
  if (DAT_140699949 != '\0') {
    local_e8 = &DAT_140699948;
    local_e0._1_3_ = (undefined3)((uint)local_e0 >> 8);
    local_e0 = CONCAT31(local_e0._1_3_,bVar11);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_e8,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1dd0);
    goto LAB_14002225c;
  }
  cVar12 = (char)uVar16;
  if (DAT_140699968 != 0) {
    uVar14 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
             ::hash_one::<&usize>(&DAT_140699970,&local_a0);
    bVar27 = (byte)(uVar14 >> 0x39);
    auVar28 = ZEXT216(CONCAT11(bVar27,bVar27));
    auVar28 = pshuflw(auVar28,auVar28,0);
    lVar21 = 0;
    do {
      uVar14 = uVar14 & DAT_140699958;
      auVar1 = *(undefined1 (*) [16])(*DAT_140699950 + uVar14);
      auVar30[0] = -(auVar1[0] == auVar28[0]);
      auVar30[1] = -(auVar1[1] == auVar28[1]);
      auVar30[2] = -(auVar1[2] == auVar28[2]);
      auVar30[3] = -(auVar1[3] == auVar28[3]);
      auVar30[4] = -(auVar1[4] == auVar28[4]);
      auVar30[5] = -(auVar1[5] == auVar28[5]);
      auVar30[6] = -(auVar1[6] == auVar28[6]);
      auVar30[7] = -(auVar1[7] == auVar28[7]);
      auVar30[8] = -(auVar1[8] == auVar28[0]);
      auVar30[9] = -(auVar1[9] == auVar28[1]);
      auVar30[10] = -(auVar1[10] == auVar28[2]);
      auVar30[0xb] = -(auVar1[0xb] == auVar28[3]);
      auVar30[0xc] = -(auVar1[0xc] == auVar28[4]);
      auVar30[0xd] = -(auVar1[0xd] == auVar28[5]);
      auVar30[0xe] = -(auVar1[0xe] == auVar28[6]);
      auVar30[0xf] = -(auVar1[0xf] == auVar28[7]);
      uVar23 = (ushort)(SUB161(auVar30 >> 7,0) & 1) | (ushort)(SUB161(auVar30 >> 0xf,0) & 1) << 1 |
               (ushort)(SUB161(auVar30 >> 0x17,0) & 1) << 2 |
               (ushort)(SUB161(auVar30 >> 0x1f,0) & 1) << 3 |
               (ushort)(SUB161(auVar30 >> 0x27,0) & 1) << 4 |
               (ushort)(SUB161(auVar30 >> 0x2f,0) & 1) << 5 |
               (ushort)(SUB161(auVar30 >> 0x37,0) & 1) << 6 |
               (ushort)(SUB161(auVar30 >> 0x3f,0) & 1) << 7 |
               (ushort)(SUB161(auVar30 >> 0x47,0) & 1) << 8 |
               (ushort)(SUB161(auVar30 >> 0x4f,0) & 1) << 9 |
               (ushort)(SUB161(auVar30 >> 0x57,0) & 1) << 10 |
               (ushort)(SUB161(auVar30 >> 0x5f,0) & 1) << 0xb |
               (ushort)(SUB161(auVar30 >> 0x67,0) & 1) << 0xc |
               (ushort)(SUB161(auVar30 >> 0x6f,0) & 1) << 0xd |
               (ushort)(SUB161(auVar30 >> 0x77,0) & 1) << 0xe | (ushort)(auVar30[0xf] >> 7) << 0xf;
      uVar22 = (uint)uVar23;
      while (uVar23 != 0) {
        uVar5 = 0;
        for (uVar6 = uVar22; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
          uVar5 = uVar5 + 1;
        }
        uVar24 = uVar5 + uVar14 & DAT_140699958;
        if (param_1 == *(longlong *)DAT_140699950[uVar24 * -5 + -5]) {
          puVar2 = *(undefined1 **)(DAT_140699950[uVar24 * -5 + -5] + 8);
          uVar18 = *(undefined4 *)DAT_140699950[uVar24 * -5 + -4];
          uStack_54 = *(undefined8 *)(DAT_140699950[uVar24 * -5 + -1] + 8);
          uStack_58 = (undefined4)
                      ((ulonglong)*(undefined8 *)DAT_140699950[uVar24 * -5 + -1] >> 0x20);
          uStack_68 = *(ulonglong *)(DAT_140699950[uVar24 * -5 + -2] + 4);
          uStack_60 = (undefined4)*(undefined8 *)(DAT_140699950[uVar24 * -5 + -2] + 0xc);
          local_5c = (undefined4)
                     ((ulonglong)*(undefined8 *)(DAT_140699950[uVar24 * -5 + -2] + 0xc) >> 0x20);
          uStack_70 = *(undefined8 *)(DAT_140699950[uVar24 * -5 + -3] + 0xc);
          uStack_78 = (undefined4)*(undefined8 *)(DAT_140699950[uVar24 * -5 + -3] + 4);
          uStack_74 = (undefined4)
                      ((ulonglong)*(undefined8 *)(DAT_140699950[uVar24 * -5 + -3] + 4) >> 0x20);
          local_88 = *(undefined8 *)(DAT_140699950[uVar24 * -5 + -4] + 4);
          uStack_80 = (undefined4)*(undefined8 *)(DAT_140699950[uVar24 * -5 + -4] + 0xc);
          uStack_7c = (undefined4)
                      ((ulonglong)*(undefined8 *)(DAT_140699950[uVar24 * -5 + -4] + 0xc) >> 0x20);
          if (((bVar11 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
             (cVar13 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
             cVar13 == '\0')) {
            DAT_140699949 = '\x01';
          }
          cVar13 = DAT_140699948;
          LOCK();
          DAT_140699948 = '\0';
          UNLOCK();
          if (cVar13 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
          }
          local_cc = CONCAT44(uStack_74,uStack_78);
          local_dc = (undefined4)local_88;
          bStack_d8 = (byte)((ulonglong)local_88 >> 0x20);
          uStack_d7 = (undefined1)((ulonglong)local_88 >> 0x28);
          uStack_d6 = (undefined2)((ulonglong)local_88 >> 0x30);
          uStack_d4 = (undefined2)uStack_80;
          uStack_d2 = (undefined6)(CONCAT44(uStack_7c,uStack_80) >> 0x10);
          uStack_c4 = uStack_70;
          local_bc = uStack_68;
          uStack_b4 = uStack_60;
          uStack_b0 = local_5c;
          uStack_ac = uStack_58;
          uStack_a8 = uStack_54;
          local_e8 = puVar2;
          local_e0 = uVar18;
          send_kick(&local_e8,param_1,param_2 & 0xffffffff);
          LOCK();
          bVar26 = DAT_140699948 == '\0';
          if (bVar26) {
            DAT_140699948 = '\x01';
          }
          UNLOCK();
          if (bVar26) {
            if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) == 0) goto LAB_140021cae;
LAB_140021ff6:
            bVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar11 = bVar11 ^ 1;
            bVar27 = bStack_d8;
            uVar9 = uStack_d6;
            lVar21 = local_cc;
          }
          else {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
            if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0) goto LAB_140021ff6;
LAB_140021cae:
            bVar11 = 0;
            bVar27 = bStack_d8;
            uVar9 = uStack_d6;
            lVar21 = local_cc;
          }
          bStack_d8 = bVar27;
          uStack_d6 = uVar9;
          local_cc = lVar21;
          if (DAT_140699949 == '\0') {
            auVar28 = *DAT_140699950;
            pauVar19 = DAT_140699950 + 1;
            uVar22 = ~(uint)(ushort)((ushort)(SUB161(auVar28 >> 7,0) & 1) |
                                     (ushort)(SUB161(auVar28 >> 0xf,0) & 1) << 1 |
                                     (ushort)(SUB161(auVar28 >> 0x17,0) & 1) << 2 |
                                     (ushort)(SUB161(auVar28 >> 0x1f,0) & 1) << 3 |
                                     (ushort)(SUB161(auVar28 >> 0x27,0) & 1) << 4 |
                                     (ushort)(SUB161(auVar28 >> 0x2f,0) & 1) << 5 |
                                     (ushort)(SUB161(auVar28 >> 0x37,0) & 1) << 6 |
                                     (ushort)(SUB161(auVar28 >> 0x3f,0) & 1) << 7 |
                                     (ushort)(SUB161(auVar28 >> 0x47,0) & 1) << 8 |
                                     (ushort)(SUB161(auVar28 >> 0x4f,0) & 1) << 9 |
                                     (ushort)(SUB161(auVar28 >> 0x57,0) & 1) << 10 |
                                     (ushort)(SUB161(auVar28 >> 0x5f,0) & 1) << 0xb |
                                     (ushort)(SUB161(auVar28 >> 0x67,0) & 1) << 0xc |
                                     (ushort)(SUB161(auVar28 >> 0x6f,0) & 1) << 0xd |
                                     (ushort)(SUB161(auVar28 >> 0x77,0) & 1) << 0xe |
                                    (ushort)(byte)(auVar28[0xf] >> 7) << 0xf);
            iVar20 = CONCAT22(uStack_d4,uVar9);
            lVar3 = CONCAT62(uStack_d2,uStack_d4);
            pauVar17 = DAT_140699950;
            lVar7 = DAT_140699968;
            if ((bVar27 & 1) != 0) goto joined_r0x000140021cfe;
            goto joined_r0x000140021d8b;
          }
          local_100 = &DAT_140699948;
          uVar22 = (uint)local_f8 >> 8;
          local_f8 = CONCAT31((int3)uVar22,bVar11);
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,&local_100,
                     &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                     &
                     PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1de8
                    );
          goto LAB_14002225c;
        }
        uVar23 = (ushort)(uVar22 - 1) & (ushort)uVar22;
        uVar22 = CONCAT22((short)(uVar22 - 1 >> 0x10),uVar23);
      }
      auVar29[0] = -(auVar1[0] == -1);
      auVar29[1] = -(auVar1[1] == -1);
      auVar29[2] = -(auVar1[2] == -1);
      auVar29[3] = -(auVar1[3] == -1);
      auVar29[4] = -(auVar1[4] == -1);
      auVar29[5] = -(auVar1[5] == -1);
      auVar29[6] = -(auVar1[6] == -1);
      auVar29[7] = -(auVar1[7] == -1);
      auVar29[8] = -(auVar1[8] == -1);
      auVar29[9] = -(auVar1[9] == -1);
      auVar29[10] = -(auVar1[10] == -1);
      auVar29[0xb] = -(auVar1[0xb] == -1);
      auVar29[0xc] = -(auVar1[0xc] == -1);
      auVar29[0xd] = -(auVar1[0xd] == -1);
      auVar29[0xe] = -(auVar1[0xe] == -1);
      auVar29[0xf] = -(auVar1[0xf] == -1);
      uVar24 = DAT_140699958;
      if ((((((((((((((((SUB161(auVar29 >> 7,0) & 1) != 0 || (SUB161(auVar29 >> 0xf,0) & 1) != 0) ||
                      (SUB161(auVar29 >> 0x17,0) & 1) != 0) || (SUB161(auVar29 >> 0x1f,0) & 1) != 0)
                    || (SUB161(auVar29 >> 0x27,0) & 1) != 0) || (SUB161(auVar29 >> 0x2f,0) & 1) != 0
                   ) || (SUB161(auVar29 >> 0x37,0) & 1) != 0) ||
                 (SUB161(auVar29 >> 0x3f,0) & 1) != 0) || (SUB161(auVar29 >> 0x47,0) & 1) != 0) ||
               (SUB161(auVar29 >> 0x4f,0) & 1) != 0) || (SUB161(auVar29 >> 0x57,0) & 1) != 0) ||
             (SUB161(auVar29 >> 0x5f,0) & 1) != 0) || (SUB161(auVar29 >> 0x67,0) & 1) != 0) ||
           (SUB161(auVar29 >> 0x6f,0) & 1) != 0) || (SUB161(auVar29 >> 0x77,0) & 1) != 0) ||
          auVar29[0xf] < '\0') break;
      uVar14 = uVar14 + lVar21 + 0x10;
      lVar21 = lVar21 + 0x10;
    } while( true );
  }
  uVar18 = (undefined4)uVar24;
  if (((bVar11 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
     (cVar13 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar13 == '\0'))
  {
    DAT_140699949 = '\x01';
  }
  cVar13 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar13 != '\x02') {
    if (cVar12 != '\0') goto LAB_140021bda;
    goto LAB_140022068;
  }
  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  if (cVar12 == '\0') goto LAB_140022068;
LAB_140021bda:
  uVar18 = 0xffffffff;
  goto LAB_14002208f;
joined_r0x000140021d8b:
  if (lVar7 == 0) goto LAB_140021d8d;
  uVar23 = (ushort)uVar22;
  while (uVar23 == 0) {
    auVar28 = *pauVar19;
    pauVar17 = pauVar17 + -0x50;
    pauVar19 = pauVar19 + 1;
    uVar23 = ((ushort)(SUB161(auVar28 >> 7,0) & 1) | (ushort)(SUB161(auVar28 >> 0xf,0) & 1) << 1 |
              (ushort)(SUB161(auVar28 >> 0x17,0) & 1) << 2 |
              (ushort)(SUB161(auVar28 >> 0x1f,0) & 1) << 3 |
              (ushort)(SUB161(auVar28 >> 0x27,0) & 1) << 4 |
              (ushort)(SUB161(auVar28 >> 0x2f,0) & 1) << 5 |
              (ushort)(SUB161(auVar28 >> 0x37,0) & 1) << 6 |
              (ushort)(SUB161(auVar28 >> 0x3f,0) & 1) << 7 |
              (ushort)(SUB161(auVar28 >> 0x47,0) & 1) << 8 |
              (ushort)(SUB161(auVar28 >> 0x4f,0) & 1) << 9 |
              (ushort)(SUB161(auVar28 >> 0x57,0) & 1) << 10 |
              (ushort)(SUB161(auVar28 >> 0x5f,0) & 1) << 0xb |
              (ushort)(SUB161(auVar28 >> 0x67,0) & 1) << 0xc |
              (ushort)(SUB161(auVar28 >> 0x6f,0) & 1) << 0xd |
              (ushort)(SUB161(auVar28 >> 0x77,0) & 1) << 0xe |
             (ushort)(byte)(auVar28[0xf] >> 7) << 0xf) ^ 0xffff;
    uVar22 = (uint)uVar23;
  }
  uVar5 = 0;
  for (uVar6 = uVar22; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
    uVar5 = uVar5 + 1;
  }
  uVar24 = (ulonglong)uVar5;
  if (((*(longlong *)pauVar17[uVar24 * -5 + -5] != param_1) &&
      (pauVar17[uVar24 * -5 + -4][8] == '\0')) &&
     (*(int *)(pauVar17[uVar24 * -5 + -4] + 10) == iVar20)) goto LAB_140021e65;
  uVar22 = uVar22 - 1 & uVar22;
  lVar7 = lVar7 + -1;
  goto joined_r0x000140021d8b;
joined_r0x000140021cfe:
  if (lVar7 == 0) goto LAB_140021d8d;
  uVar23 = (ushort)uVar22;
  while (uVar23 == 0) {
    auVar28 = *pauVar19;
    pauVar17 = pauVar17 + -0x50;
    pauVar19 = pauVar19 + 1;
    uVar23 = ((ushort)(SUB161(auVar28 >> 7,0) & 1) | (ushort)(SUB161(auVar28 >> 0xf,0) & 1) << 1 |
              (ushort)(SUB161(auVar28 >> 0x17,0) & 1) << 2 |
              (ushort)(SUB161(auVar28 >> 0x1f,0) & 1) << 3 |
              (ushort)(SUB161(auVar28 >> 0x27,0) & 1) << 4 |
              (ushort)(SUB161(auVar28 >> 0x2f,0) & 1) << 5 |
              (ushort)(SUB161(auVar28 >> 0x37,0) & 1) << 6 |
              (ushort)(SUB161(auVar28 >> 0x3f,0) & 1) << 7 |
              (ushort)(SUB161(auVar28 >> 0x47,0) & 1) << 8 |
              (ushort)(SUB161(auVar28 >> 0x4f,0) & 1) << 9 |
              (ushort)(SUB161(auVar28 >> 0x57,0) & 1) << 10 |
              (ushort)(SUB161(auVar28 >> 0x5f,0) & 1) << 0xb |
              (ushort)(SUB161(auVar28 >> 0x67,0) & 1) << 0xc |
              (ushort)(SUB161(auVar28 >> 0x6f,0) & 1) << 0xd |
              (ushort)(SUB161(auVar28 >> 0x77,0) & 1) << 0xe |
             (ushort)(byte)(auVar28[0xf] >> 7) << 0xf) ^ 0xffff;
    uVar22 = (uint)uVar23;
  }
  uVar5 = 0;
  for (uVar6 = uVar22; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
    uVar5 = uVar5 + 1;
  }
  uVar24 = (ulonglong)uVar5;
  if (((*(longlong *)pauVar17[uVar24 * -5 + -5] != param_1) &&
      (*(short *)(pauVar17[uVar24 * -5 + -4] + 8) == 1)) &&
     (*(longlong *)(pauVar17[uVar24 * -5 + -3] + 4) == lVar21 &&
      *(longlong *)(pauVar17[uVar24 * -5 + -4] + 0xc) == lVar3)) goto LAB_140021e65;
  uVar22 = uVar22 - 1 & uVar22;
  lVar7 = lVar7 + -1;
  goto joined_r0x000140021cfe;
LAB_140021d8d:
  uVar18 = SUB84(pauVar19,0);
  bVar25 = false;
  bVar26 = false;
  goto joined_r0x000140021e6a;
LAB_140021e65:
  uVar18 = SUB84(pauVar19,0);
  bVar25 = true;
  bVar26 = true;
joined_r0x000140021e6a:
  if (((bVar11 == 0) && (bVar26 = bVar25, (*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
     (cVar13 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar13 == '\0'))
  {
    DAT_140699949 = '\x01';
  }
  cVar13 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar13 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
  if (cVar12 == '\0') {
LAB_140022068:
    uVar15 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    uVar16 = <std[3bf9d48a0c3997f0]::time::Instant_as_core[505b25137b8ba7f]::ops::arith::Add<core[505b25137b8ba7f]::time::Duration>>
             ::add(uVar15);
  }
  else {
    if (!bVar26 && (local_bc & 0x100000000) == 0) {
      if ((bVar27 & 1) == 0) {
        if ((char)uVar9 != '\x7f') goto LAB_140021e7f;
      }
      else if (lVar21 != 0x100000000000000 || lVar3 != 0) {
LAB_140021e7f:
        <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
        ::lock(&local_100,&BANNED_IPS);
        if ((int)local_100 == 1) {
          local_90 = local_f0;
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,local_98,
                     &
                     PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1010
                     ,&
                      PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1e00
                    );
          goto LAB_14002225c;
        }
        pcVar8 = (char *)CONCAT44(uStack_f4,local_f8);
        bVar26 = (bVar27 & 1) != 0;
        if (bVar26) {
          local_f8 = uStack_74;
          local_100 = (undefined1 *)CONCAT44(uStack_78,uStack_7c);
          iVar20 = (int)lVar3;
        }
        uVar16 = (ulonglong)local_f0;
        lVar21 = *(longlong *)(pcVar8 + 0x18);
        if (lVar21 == *(longlong *)(pcVar8 + 8)) {
          <alloc[246c2e7857c81348]::raw_vec::RawVec<core[505b25137b8ba7f]::net::ip_addr::IpAddr>>::
          grow_one(pcVar8 + 8);
        }
        lVar3 = *(longlong *)(pcVar8 + 0x10);
        lVar7 = lVar21 * 0x11;
        *(bool *)(lVar3 + lVar7) = bVar26;
        *(int *)(lVar3 + 1 + lVar7) = iVar20;
        *(undefined1 **)(lVar3 + 5 + lVar7) = local_100;
        *(undefined4 *)(lVar3 + 0xd + lVar7) = local_f8;
        *(longlong *)(pcVar8 + 0x18) = lVar21 + 1;
        if (((local_f0 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
           (cVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
           cVar12 == '\0')) {
          pcVar8[1] = '\x01';
        }
        LOCK();
        cVar12 = *pcVar8;
        *pcVar8 = '\0';
        UNLOCK();
        if (cVar12 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar8);
        }
      }
    }
    uVar18 = 0xffffffff;
  }
LAB_14002208f:
  LOCK();
  bVar26 = BLOCKED == '\0';
  if (bVar26) {
    BLOCKED = '\x01';
  }
  UNLOCK();
  if (bVar26) {
    if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) == 0) goto LAB_1400220ad;
LAB_140022149:
    bVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar11 = bVar11 ^ 1;
    lVar21 = DAT_140699788;
  }
  else {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&BLOCKED);
    if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0) goto LAB_140022149;
LAB_1400220ad:
    bVar11 = 0;
    lVar21 = DAT_140699788;
  }
  DAT_140699788 = lVar21;
  if (DAT_140699771 == '\0') {
    if (lVar21 == DAT_140699778) {
      <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::vec::Vec<[u8;12usize]>>>::
      grow_one(&DAT_140699778);
    }
    lVar3 = DAT_140699780;
    *(longlong *)(DAT_140699780 + lVar21 * 0x18) = param_1;
    *(ulonglong *)(lVar3 + 8 + lVar21 * 0x18) = uVar16;
    *(undefined4 *)(lVar3 + 0x10 + lVar21 * 0x18) = uVar18;
    DAT_140699788 = lVar21 + 1;
    if (((bVar11 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
       (cVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar12 == '\0')
       ) {
      DAT_140699771 = '\x01';
    }
    cVar12 = BLOCKED;
    LOCK();
    BLOCKED = 0;
    UNLOCK();
    if (cVar12 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&BLOCKED);
    }
    return;
  }
  local_e8 = &BLOCKED;
  local_e0._1_3_ = (undefined3)((uint)local_e0 >> 8);
  local_e0 = CONCAT31(local_e0._1_3_,bVar11);
  core[505b25137b8ba7f]::result::unwrap_failed
            ("called `Result::unwrap()` on an `Err` value",0x2b,&local_e8,
             &
             PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1050
             ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1e30);
LAB_14002225c:
                    /* WARNING: Does not return */
  pcVar4 = (code *)invalidInstructionException();
  (*pcVar4)();
}

