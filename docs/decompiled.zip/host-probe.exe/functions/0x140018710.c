// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::valid_expiry
// address: 0x140018710
// body: available
// range: 0x140018710-0x140018763 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::valid_expiry */

undefined8 __rustcall
host_probe[b94139f9089eb1d8]::ingame_chat::valid_expiry(undefined8 param_1,ulonglong param_2)

{
  char *pcVar1;
  ulonglong uVar2;
  
  pcVar1 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                             ("expires_unix_ms",0xf,param_1);
  if (pcVar1 == (char *)0x0) {
    pcVar1 = 
    __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
    ;
  }
  if (((*pcVar1 == '\x02') && (*(longlong *)(pcVar1 + 8) == 0)) &&
     (uVar2 = *(ulonglong *)(pcVar1 + 0x10) - param_2, param_2 <= *(ulonglong *)(pcVar1 + 0x10))) {
    return CONCAT71((int7)(uVar2 >> 8),uVar2 < 0x1389);
  }
  return 0;
}

