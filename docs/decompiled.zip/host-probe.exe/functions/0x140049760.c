// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u8>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<u8,&mut_core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>>::from_iter
// address: 0x140049760
// body: available
// range: 0x140049760-0x1400498f4 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u8> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<u8, &mut
   core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>>::from_iter
    */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<u8>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<u8,&mut_core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>>
::from_iter(ulonglong *param_1,longlong *param_2)

{
  undefined8 *puVar1;
  undefined1 *puVar2;
  code *pcVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined8 uVar9;
  undefined1 *puVar10;
  undefined1 *puVar11;
  undefined1 *puVar12;
  uint uVar13;
  ulonglong uVar14;
  
  puVar11 = (undefined1 *)*param_2;
  puVar2 = (undefined1 *)param_2[1];
  uVar8 = (longlong)puVar2 - (longlong)puVar11;
  if ((longlong)uVar8 < 0) {
    uVar9 = 0;
LAB_14004977e:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar9,uVar8);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  if (uVar8 == 0) {
    uVar6 = 1;
    uVar7 = 0;
    goto LAB_1400498d9;
  }
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  uVar9 = 1;
  uVar6 = __rustc[9d087a5ab36ea756]::__rust_alloc(uVar8,1);
  if (uVar6 == 0) goto LAB_14004977e;
  if ((longlong)puVar11 - uVar6 < 0xffffffffffffffe1 && 3 < uVar8) {
    if (uVar8 < 0x20) {
      uVar14 = 0;
LAB_14004983e:
      uVar7 = uVar8 & 0x7ffffffffffffffc;
      puVar12 = puVar11 + uVar7;
      do {
        *(undefined4 *)(uVar6 + uVar14) = *(undefined4 *)(puVar11 + uVar14);
        uVar14 = uVar14 + 4;
      } while (uVar7 != uVar14);
      puVar10 = puVar12;
      if (uVar8 != uVar7) goto LAB_140049866;
    }
    else {
      uVar7 = uVar8 & 0x7fffffffffffffe0;
      puVar12 = puVar11 + uVar7;
      uVar14 = 0;
      do {
        uVar9 = *(undefined8 *)((longlong)(puVar11 + uVar14) + 8);
        uVar4 = *(undefined8 *)(puVar11 + uVar14 + 0x10);
        uVar5 = *(undefined8 *)((longlong)(puVar11 + uVar14 + 0x10) + 8);
        *(undefined8 *)(uVar6 + uVar14) = *(undefined8 *)(puVar11 + uVar14);
        ((undefined8 *)(uVar6 + uVar14))[1] = uVar9;
        puVar1 = (undefined8 *)(uVar6 + 0x10 + uVar14);
        *puVar1 = uVar4;
        puVar1[1] = uVar5;
        uVar14 = uVar14 + 0x20;
      } while (uVar7 != uVar14);
      if (uVar8 != uVar7) {
        uVar14 = uVar7;
        puVar10 = puVar12;
        if ((uVar8 & 0x1c) == 0) goto LAB_140049866;
        goto LAB_14004983e;
      }
    }
  }
  else {
    uVar7 = 0;
    puVar10 = puVar11;
LAB_140049866:
    uVar13 = (int)puVar2 - (int)puVar10 & 3;
    uVar14 = (ulonglong)uVar13;
    puVar12 = puVar10;
    puVar11 = puVar10;
    if (uVar13 != 0) {
      do {
        puVar12 = puVar11 + 1;
        *(undefined1 *)(uVar6 + uVar7) = *puVar11;
        uVar7 = uVar7 + 1;
        uVar14 = uVar14 - 1;
        puVar11 = puVar12;
      } while (uVar14 != 0);
    }
    if ((ulonglong)((longlong)puVar10 - (longlong)puVar2) < 0xfffffffffffffffd) {
      do {
        *(undefined1 *)(uVar6 + uVar7) = *puVar12;
        *(undefined1 *)(uVar6 + 1 + uVar7) = puVar12[1];
        *(undefined1 *)(uVar6 + 2 + uVar7) = puVar12[2];
        puVar11 = puVar12 + 3;
        puVar12 = puVar12 + 4;
        *(undefined1 *)(uVar6 + 3 + uVar7) = *puVar11;
        uVar7 = uVar7 + 4;
      } while (puVar12 != puVar2);
    }
  }
  *param_2 = (longlong)puVar12;
LAB_1400498d9:
  *param_1 = uVar8;
  param_1[1] = uVar6;
  param_1[2] = uVar7;
  return param_1;
}

