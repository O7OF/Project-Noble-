// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<&serde_json[7404bcab4dc139c7]::value::Value,core[505b25137b8ba7f]::result::Result<(),serde_json[7404bcab4dc139c7]::error::Error>,<serde_json[7404bcab4dc139c7]::value::ser::Serializer_as_serde_core[7f01a81d286c67f3]::ser::Serializer>::collect_seq<&alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&serde_json[7404bcab4dc139c7]::value::Value)>>::call_mut
// address: 0x14003e480
// body: available
// range: 0x14003e480-0x14003e4fb inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut 
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<&serde_json[7404bcab4dc139c7]::value::Value,
   core[505b25137b8ba7f]::result::Result<(), serde_json[7404bcab4dc139c7]::error::Error>,
   <serde_json[7404bcab4dc139c7]::value::ser::Serializer as
   serde_core[7f01a81d286c67f3]::ser::Serializer>::collect_seq<&alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>>::{closure#0}>::{closure#0}
   as core[505b25137b8ba7f]::ops::function::FnMut<((),
   &serde_json[7404bcab4dc139c7]::value::Value)>>::call_mut */

undefined8 __rustcall
<&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<&serde_json[7404bcab4dc139c7]::value::Value,core[505b25137b8ba7f]::result::Result<(),serde_json[7404bcab4dc139c7]::error::Error>,<serde_json[7404bcab4dc139c7]::value::ser::Serializer_as_serde_core[7f01a81d286c67f3]::ser::Serializer>::collect_seq<&alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&serde_json[7404bcab4dc139c7]::value::Value)>>
::call_mut(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  plVar2 = *(longlong **)*param_1;
  <&serde_json[7404bcab4dc139c7]::value::Value_as_serde_core[7f01a81d286c67f3]::ser::Serialize>::
  serialize::<serde_json[7404bcab4dc139c7]::value::ser::Serializer>(&local_58);
  if ((char)local_58 != -1) {
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    lVar3 = plVar2[2];
    if (lVar3 == *plVar2) {
      <alloc[246c2e7857c81348]::raw_vec::RawVec<serde_json[7404bcab4dc139c7]::value::Value>>::
      grow_one(plVar2);
    }
    lVar4 = plVar2[1];
    puVar1 = (undefined8 *)(lVar4 + 0x10 + lVar3 * 0x20);
    *puVar1 = CONCAT44(uStack_44,local_48);
    puVar1[1] = CONCAT44(uStack_3c,uStack_40);
    puVar1 = (undefined8 *)(lVar4 + lVar3 * 0x20);
    *puVar1 = CONCAT44(uStack_54,local_58);
    puVar1[1] = CONCAT44(uStack_4c,uStack_50);
    plVar2[2] = lVar3 + 1;
    return 0;
  }
  return CONCAT44(uStack_4c,uStack_50);
}

