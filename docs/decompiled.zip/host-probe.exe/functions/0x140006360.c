// rea decompile_all
// name: std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::announce::announce::{closure#27},()>
// address: 0x140006360
// body: available
// range: 0x140006360-0x140006610 inclusive
// range: 0x14000661b-0x140006669 inclusive
// range: 0x140006670-0x1400066b2 inclusive
// range: 0x1400066c0-0x14000670d inclusive
// range: 0x140006710-0x14000672f inclusive
// range: 0x140006732-0x140006a09 inclusive
// range: 0x140006a10-0x140006aed inclusive
// range: 0x140006af3-0x140006b22 inclusive
// range: 0x140006b30-0x140006b50 inclusive
// range: 0x140006b60-0x140006cee inclusive
// range: 0x140006cf0-0x140006d13 inclusive
// range: 0x140006d16-0x140006d6a inclusive
// range: 0x140006d70-0x140006d8f inclusive
// range: 0x140006d92-0x140006db1 inclusive
// range: 0x140006db4-0x140006e76 inclusive
// range: 0x140006e80-0x140006f39 inclusive
// range: 0x140006f40-0x1400070ca inclusive
// range: 0x1400070d0-0x140007137 inclusive
// range: 0x140007140-0x14000734c inclusive
// range: 0x140007352-0x1400073a2 inclusive
// range: 0x1400073a8-0x1400073fc inclusive
// range: 0x140007402-0x140007551 inclusive
// range: 0x140007560-0x14000757f inclusive
// range: 0x140007582-0x1400076a2 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000660c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000672b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006752 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006ac5 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006ae9 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006b4c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006b76 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006d0f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006d8b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140006dad to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000708e to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400070c6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::announce::announce::{closure#27},
   ()> */

void __rustcall
std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::
<host_probe[b94139f9089eb1d8]::announce::announce::_closure_27_,()>(longlong *param_1,uint param_2)

{
  longlong *plVar1;
  undefined1 auVar2 [16];
  short sVar3;
  undefined4 uVar4;
  code *pcVar5;
  uint uVar6;
  uint uVar7;
  short *psVar8;
  longlong lVar9;
  undefined2 uVar10;
  undefined4 uVar11;
  char cVar12;
  byte bVar13;
  int iVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  undefined8 *puVar17;
  undefined8 uVar18;
  longlong *plVar19;
  longlong lVar20;
  char *pcVar21;
  uint uVar22;
  uint uVar23;
  longlong lVar24;
  undefined1 (*pauVar25) [16];
  ulonglong uVar26;
  short *psVar27;
  undefined1 (*pauVar28) [16];
  longlong *plVar29;
  longlong lVar30;
  longlong *plVar31;
  byte bVar32;
  short sVar33;
  ushort uVar34;
  uint uVar35;
  undefined8 *unaff_RSI;
  undefined7 uVar36;
  longlong lVar37;
  longlong *plVar38;
  longlong lVar39;
  longlong lVar40;
  bool bVar41;
  bool bVar42;
  undefined8 local_2b8;
  uint local_2a8;
  longlong local_288;
  uint local_280;
  uint local_27c;
  undefined1 local_278;
  undefined1 uStack_277;
  undefined4 uStack_276;
  short sStack_272;
  ushort uStack_270;
  undefined6 uStack_26e;
  undefined2 uStack_268;
  undefined6 uStack_266;
  undefined8 uStack_260;
  undefined8 local_258;
  uint uStack_250;
  undefined4 uStack_24c;
  uint uStack_248;
  undefined4 uStack_244;
  undefined8 uStack_240;
  undefined4 local_238;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined4 local_228;
  undefined4 uStack_224;
  undefined4 uStack_220;
  undefined4 uStack_21c;
  longlong local_218;
  longlong lStack_210;
  longlong local_208;
  ulonglong local_200;
  ulonglong local_1f8;
  ulonglong local_1f0;
  ulonglong local_1e8;
  longlong *local_1e0;
  longlong *local_1d8;
  longlong local_1d0;
  longlong *local_1c8;
  longlong local_1c0;
  undefined8 local_1b8;
  undefined8 local_1b0;
  longlong local_1a8;
  ulonglong uStack_1a0;
  undefined8 local_198;
  ulonglong local_188;
  longlong local_180;
  ulonglong local_178;
  longlong local_170;
  longlong lStack_168;
  longlong local_160;
  ulonglong local_158;
  uint local_150;
  undefined4 local_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  longlong lStack_138;
  longlong local_130;
  longlong *local_128;
  longlong local_120;
  short local_118;
  undefined4 uStack_116;
  short sStack_112;
  ushort uStack_110;
  undefined2 uStack_10e;
  undefined4 uStack_10c;
  undefined2 local_108;
  undefined2 uStack_106;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  longlong local_c8;
  longlong *plStack_c0;
  longlong *local_b8;
  undefined8 local_a8;
  undefined8 uStack_a0;
  ulonglong local_98;
  uint local_90;
  undefined8 uStack_88;
  undefined6 uStack_80;
  undefined2 local_7a;
  undefined2 uStack_78;
  undefined4 uStack_76;
  undefined4 uStack_72;
  undefined4 uStack_6e;
  undefined1 local_60 [16];
  undefined4 local_50;
  undefined2 local_48;
  
  local_180 = DAT_1407f04b8;
  local_280 = param_2;
  local_188 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  local_50 = 0xffffffff;
  local_48 = 0x200;
  local_27c = local_280;
  local_178 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  uStack_148 = 0xffffffff;
  uStack_144 = 0xffffffff;
  local_1e8 = 0;
  local_1f0 = 0;
  uVar26 = local_1f8;
LAB_140006420:
  do {
    local_1f8 = uVar26;
    uVar22 = 250000000;
    std[3bf9d48a0c3997f0]::thread::functions::sleep(0);
    if (host_probe[b94139f9089eb1d8]::announce::WITHDRAW != '\0') {
LAB_140007529:
      lVar37 = CONCAT44(uStack_144,uStack_148);
      if (lVar37 != -1) {
        if (lStack_138 != 0) {
          puVar17 = (undefined8 *)(CONCAT44(uStack_13c,uStack_140) + 8);
          lVar24 = lStack_138;
          do {
            if (puVar17[-1] != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar17,puVar17[-1],1);
              return;
            }
            puVar17 = puVar17 + 3;
            lVar24 = lVar24 + -1;
          } while (lVar24 != 0);
        }
        if (lVar37 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(CONCAT44(uStack_13c,uStack_140),lVar37 * 0x18,8)
          ;
          return;
        }
      }
      param_1 = (longlong *)*param_1;
      LOCK();
      *param_1 = *param_1 + -1;
      UNLOCK();
      if (*param_1 == 0) {
        <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<reach_directory[4b72b9694f6c3c08]::protocol::Listing>>>
        ::drop_slow();
      }
      return;
    }
    if (DAT_14069ddf0 == 0) {
      uVar18 = DAT_14069dde0;
      cVar12 = host_probe[b94139f9089eb1d8]::announce::withdraw_asked(DAT_14069ddd8);
      uVar22 = (uint)uVar18;
      if (cVar12 != '\0') {
        host_probe[b94139f9089eb1d8]::host::log(&DAT_1406a09a8,0x4b);
        LOCK();
        host_probe[b94139f9089eb1d8]::announce::WITHDRAW = '\x01';
        UNLOCK();
        host_probe[b94139f9089eb1d8]::announce::withdraw_held(1,500000000);
        goto LAB_140007529;
      }
    }
    uVar15 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    bVar41 = uVar22 < local_27c;
    if (uVar15 != local_178) {
      bVar41 = uVar15 < local_178;
    }
    uVar26 = local_1f8;
    local_98 = uVar15;
    local_90 = uVar22;
  } while (bVar41);
  uVar26 = uVar15;
  local_27c = uVar22;
  local_178 = <std[3bf9d48a0c3997f0]::time::Instant_as_core[505b25137b8ba7f]::ops::arith::Add<core[505b25137b8ba7f]::time::Duration>>
              ::add(uVar15,uVar22,1,0,&PTR_s_src_announce_rs_1406a0880);
  local_258._0_4_ = (undefined4)uVar15;
  local_258._4_4_ = (undefined4)(uVar15 >> 0x20);
  if (DAT_1407f04b8 != local_180) {
    local_1e8 = CONCAT71((int7)(uVar26 >> 8),1);
    local_180 = DAT_1407f04b8;
    local_280 = uVar22;
    local_188 = uVar15;
  }
  uVar26 = local_188;
  uStack_250 = uVar22;
  uVar16 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&local_258,local_188,local_280);
  uVar23 = (uint)uVar26;
  uVar36 = (undefined7)((ulonglong)unaff_RSI >> 8);
  bVar32 = 0x1d < uVar16 & (byte)local_1e8;
  if ((byte)local_1f0 != bVar32) {
    if (bVar32 == 0) {
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      puVar17 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x1e,1);
      if (puVar17 == (undefined8 *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x1e);
        goto LAB_1400076a1;
      }
      *(undefined8 *)((longlong)puVar17 + 0xe) = 0x757220656d616720;
      *(undefined8 *)((longlong)puVar17 + 0x16) = 0x6e6961676120736e;
      *puVar17 = 0x726f746365726964;
      puVar17[1] = 0x6720656874203a79;
      lVar37 = 0x1e;
      uVar23 = 0x1e;
    }
    else {
      local_278 = (undefined1)uVar16;
      uStack_277 = (undefined1)(uVar16 >> 8);
      uStack_276 = (undefined4)(uVar16 >> 0x10);
      sStack_272 = (short)(uVar16 >> 0x30);
      local_118 = (short)&local_278;
      uStack_116 = (undefined4)((ulonglong)&local_278 >> 0x10);
      sStack_112 = (short)((ulonglong)&local_278 >> 0x30);
      uStack_110 = 0x3280;
      uStack_10e = 0x4069;
      uStack_10c = 1;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_258,&DAT_1406a08b6,&local_118);
      lVar37 = CONCAT44(local_258._4_4_,(undefined4)local_258);
      puVar17 = (undefined8 *)CONCAT44(uStack_24c,uStack_250);
      uVar23 = uStack_248;
    }
    host_probe[b94139f9089eb1d8]::host::log(puVar17);
    local_1f0 = CONCAT71(uVar36,bVar32) & 0xffffffff;
    if (lVar37 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar17,lVar37,1);
      return;
    }
  }
  cVar12 = host_probe[b94139f9089eb1d8]::announce::HUNG_NOW;
  if ((local_1e8 & 1) == 0) {
    LOCK();
    host_probe[b94139f9089eb1d8]::announce::HUNG_NOW = false;
    UNLOCK();
    unaff_RSI = (undefined8 *)0x0;
    uVar23 = 0x21;
    pcVar21 = "directory: listing the game again";
    uVar35 = 0x21;
    if (cVar12 != '\0') goto LAB_14000668a;
  }
  else {
    bVar41 = 0x77 < uVar16;
    unaff_RSI = (undefined8 *)CONCAT71(uVar36,bVar41);
    LOCK();
    UNLOCK();
    bVar42 = host_probe[b94139f9089eb1d8]::announce::HUNG_NOW != '\0';
    host_probe[b94139f9089eb1d8]::announce::HUNG_NOW = bVar41;
    if (bVar41 != bVar42) {
      uVar35 = 0x21;
      if (0x77 < uVar16) {
        uVar35 = 0x5b;
      }
      pcVar21 = "directory: listing the game again";
      if (0x77 < uVar16) {
        pcVar21 = 
        "directory: the game has stood still for 2 minutes; off the server lists until it runs again"
        ;
      }
LAB_14000668a:
      uVar23 = uVar35;
      host_probe[b94139f9089eb1d8]::host::log(pcVar21);
    }
  }
  local_200 = uVar15;
  if (bVar32 == 0) {
    host_probe[b94139f9089eb1d8]::dedicated::roster(&local_258);
    lVar37 = CONCAT44(local_258._4_4_,(undefined4)local_258);
    if (lVar37 == -1) {
      local_2b8 = 0;
    }
    else {
      local_288 = CONCAT44(uStack_244,uStack_248);
      if (local_288 != 0) {
        puVar17 = (undefined8 *)(CONCAT44(uStack_24c,uStack_250) + 8);
        lVar24 = local_288;
        do {
          if (puVar17[-1] != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar17,puVar17[-1],1);
            return;
          }
          puVar17 = puVar17 + 3;
          lVar24 = lVar24 + -1;
          uVar23 = 0;
        } while (lVar24 != 0);
      }
      local_2b8 = 1;
      if (lVar37 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(CONCAT44(uStack_24c,uStack_250),lVar37 * 0x18,8);
        return;
      }
    }
    if (DAT_140699990 == 0) {
      LOCK();
      bVar41 = DAT_140699948 == '\0';
      if (bVar41) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
      if (!bVar41) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar13 = 0;
      }
      else {
        bVar13 = panicking::panic_count::is_zero_slow_path();
        bVar13 = bVar13 ^ 1;
      }
      if (DAT_140699949 == '\0') {
        uVar18 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
        auVar2 = *DAT_140699950;
        pauVar25 = DAT_140699950 + 1;
        uVar35 = ~(uint)(ushort)((ushort)(SUB161(auVar2 >> 7,0) & 1) |
                                 (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
                                 (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                                 (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                                 (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                                 (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                                 (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                                 (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                                 (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                                 (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                                 (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                                 (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                                 (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                                 (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                                 (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
                                (ushort)(byte)(auVar2[0xf] >> 7) << 0xf);
        lVar37 = 0;
        sVar33 = (short)uVar35;
        pauVar28 = DAT_140699950;
        lVar24 = DAT_140699968;
        uVar15 = local_200;
        do {
          local_200 = uVar15;
          if (sVar33 == 0) {
            if (lVar24 == 0) goto LAB_140006878;
            do {
              auVar2 = *pauVar25;
              pauVar28 = pauVar28 + -0x50;
              pauVar25 = pauVar25 + 1;
              uVar34 = ((ushort)(SUB161(auVar2 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
                       (ushort)(byte)(auVar2[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar35 = (uint)uVar34;
            } while (uVar34 == 0);
          }
          uVar6 = 0;
          for (uVar7 = uVar35; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
            uVar6 = uVar6 + 1;
          }
          local_258._0_4_ = (undefined4)uVar18;
          local_258._4_4_ = (undefined4)((ulonglong)uVar18 >> 0x20);
          uStack_250 = uVar23;
          uVar26 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                             (&local_258,*(undefined8 *)(pauVar28[(ulonglong)uVar6 * -5 + -5] + 8),
                              *(undefined4 *)pauVar28[(ulonglong)uVar6 * -5 + -4]);
          uVar35 = uVar35 - 1 & uVar35;
          lVar37 = lVar37 + (ulonglong)(uVar26 < 0xf);
          lVar24 = lVar24 + -1;
          sVar33 = (short)uVar35;
          uVar15 = local_200;
        } while( true );
      }
      local_258._0_4_ = 0x40699948;
      local_258._4_4_ = 1;
      uStack_250._1_3_ = (undefined3)(uStack_250 >> 8);
      uStack_250 = CONCAT31(uStack_250._1_3_,bVar13);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_258,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0758);
      goto LAB_1400076a1;
    }
    unaff_RSI = (undefined8 *)((ulonglong)unaff_RSI & 0xffffffff);
    lVar37 = 0;
  }
  else {
    local_2b8 = 0;
    lVar37 = 0;
  }
  goto LAB_1400068c0;
LAB_140006878:
  unaff_RSI = (undefined8 *)((ulonglong)unaff_RSI & 0xffffffff);
  if ((bVar13 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar12 = panicking::panic_count::is_zero_slow_path();
    if (cVar12 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
  cVar12 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar12 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
LAB_1400068c0:
  lVar24 = *param_1;
  pcVar21 = (char *)(lVar24 + 0x10);
  LOCK();
  bVar41 = *(char *)(lVar24 + 0x10) == '\0';
  if (bVar41) {
    *(char *)(lVar24 + 0x10) = '\x01';
  }
  UNLOCK();
  if (!bVar41) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(pcVar21);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar13 = 0;
    cVar12 = *(char *)(lVar24 + 0x11);
  }
  else {
    bVar13 = panicking::panic_count::is_zero_slow_path();
    bVar13 = bVar13 ^ 1;
    cVar12 = *(char *)(lVar24 + 0x11);
  }
  if (cVar12 == '\0') {
    <host_probe[b94139f9089eb1d8]::announce::Count>::sample
              (&local_258,local_60,local_2b8,local_288,
               host_probe[b94139f9089eb1d8]::dedicated::DEDICATED_0_llvm_15918893398050881851 !=
               '\0',lVar37,bVar32,*(undefined4 *)(lVar24 + 0x110),uVar15,uVar22);
    local_b8 = uStack_240;
    local_c8 = CONCAT44(uStack_24c,uStack_250);
    plStack_c0 = (longlong *)CONCAT44(uStack_244,uStack_248);
    *(undefined4 *)(lVar24 + 0x10c) = (undefined4)local_258;
    if ((bVar13 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar12 = panicking::panic_count::is_zero_slow_path();
      if (cVar12 == '\0') {
        *(undefined1 *)(lVar24 + 0x11) = 1;
      }
    }
    LOCK();
    cVar12 = *pcVar21;
    *pcVar21 = '\0';
    UNLOCK();
    if (cVar12 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar21);
    }
    plVar19 = plStack_c0;
    lVar37 = local_c8;
    plVar1 = plStack_c0 + (longlong)local_b8 * 3;
    local_258._0_4_ = SUB84(plStack_c0,0);
    local_258._4_4_ = (undefined4)((ulonglong)plStack_c0 >> 0x20);
    uStack_248 = (uint)local_c8;
    uStack_244 = (undefined4)((ulonglong)local_c8 >> 0x20);
    plVar31 = plStack_c0;
    plVar38 = plStack_c0;
    uStack_250 = (undefined4)local_258;
    uStack_24c = local_258._4_4_;
    uStack_240 = plVar1;
    if (local_b8 != (longlong *)0x0) {
      do {
        plVar29 = plVar38 + 3;
        lVar24 = *plVar38;
        local_1a8 = plVar38[1];
        uStack_1a0 = plVar38[2];
        plVar31 = plVar29;
        if (lVar24 == -1) break;
        local_278 = (undefined1)lVar24;
        uStack_277 = (undefined1)((ulonglong)lVar24 >> 8);
        uStack_276 = (undefined4)((ulonglong)lVar24 >> 0x10);
        sStack_272 = (short)((ulonglong)lVar24 >> 0x30);
        uStack_270 = (ushort)local_1a8;
        uStack_26e = (undefined6)((ulonglong)local_1a8 >> 0x10);
        uStack_268 = (undefined2)uStack_1a0;
        uStack_266 = (undefined6)(uStack_1a0 >> 0x10);
        local_1e0 = (longlong *)&local_278;
        local_1d8 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                     ::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_118,&DAT_1406a0858,&local_1e0);
        lVar24 = CONCAT26(sStack_112,CONCAT42(uStack_116,local_118));
        uVar18 = CONCAT44(uStack_10c,CONCAT22(uStack_10e,uStack_110));
        host_probe[b94139f9089eb1d8]::host::log
                  (uVar18,CONCAT44(uStack_104,CONCAT22(uStack_106,local_108)));
        if (lVar24 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar18,lVar24,1);
          return;
        }
        lVar24 = CONCAT26(sStack_272,CONCAT42(uStack_276,CONCAT11(uStack_277,local_278)));
        if (lVar24 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(CONCAT62(uStack_26e,uStack_270),lVar24,1);
          return;
        }
        plVar31 = plVar1;
        plVar38 = plVar29;
      } while (plVar29 != plVar1);
      uStack_250 = (uint)plVar31;
      uStack_24c = (undefined4)((ulonglong)plVar31 >> 0x20);
    }
    if (plVar1 != plVar31) {
      uVar26 = (ulonglong)((longlong)plVar1 - (longlong)plVar31) / 0x18;
      plVar31 = plVar31 + 1;
      do {
        if (plVar31[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*plVar31,plVar31[-1],1);
          return;
        }
        plVar31 = plVar31 + 3;
        uVar26 = uVar26 - 1;
      } while (uVar26 != 0);
    }
    if (lVar37 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar19,lVar37 * 0x18,8);
      return;
    }
    uVar26 = local_1f8;
    if (((char)unaff_RSI != '\0') || (DAT_140699990 != 0)) goto LAB_140006420;
    LOCK();
    bVar41 = host_probe[b94139f9089eb1d8]::announce::LEASES == '\0';
    if (bVar41) {
      host_probe[b94139f9089eb1d8]::announce::LEASES = '\x01';
    }
    UNLOCK();
    if (!bVar41) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                (&host_probe[b94139f9089eb1d8]::announce::LEASES);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar32 = 0;
    }
    else {
      bVar32 = panicking::panic_count::is_zero_slow_path();
      bVar32 = bVar32 ^ 1;
    }
    if (DAT_14069ddb1 == '\0') {
      <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>as_core[505b25137b8ba7f]::clone::Clone>
      ::clone(&local_130,&DAT_14069ddb8);
      if ((bVar32 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar12 = panicking::panic_count::is_zero_slow_path();
        if (cVar12 == '\0') {
          DAT_14069ddb1 = '\x01';
        }
      }
      cVar12 = host_probe[b94139f9089eb1d8]::announce::LEASES;
      LOCK();
      host_probe[b94139f9089eb1d8]::announce::LEASES = '\0';
      UNLOCK();
      if (cVar12 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake
                  (&host_probe[b94139f9089eb1d8]::announce::LEASES);
      }
      lVar9 = local_120;
      plVar1 = local_128;
      plVar38 = local_128 + local_120 * 0xe;
      <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>,host_probe[b94139f9089eb1d8]::announce::hand_over<host_probe[b94139f9089eb1d8]::announce::announce::{closure#26}::{closure#1}>::{closure#2}>>>
      ::from_iter(&local_170);
      lVar39 = local_160;
      lVar24 = lStack_168;
      lVar37 = CONCAT44(uStack_144,uStack_148);
      if (lVar37 == -1) {
        uStack_244 = (undefined4)local_160;
        uStack_240._0_4_ = (undefined4)((ulonglong)local_160 >> 0x20);
        local_258._4_4_ = (undefined4)local_170;
        uStack_250 = (uint)((ulonglong)local_170 >> 0x20);
        uStack_24c = (undefined4)lStack_168;
        uStack_248 = (uint)((ulonglong)lStack_168 >> 0x20);
        local_118 = (short)(undefined4)local_258;
        uStack_116 = (undefined4)(CONCAT44(local_258._4_4_,(undefined4)local_258) >> 0x10);
        sStack_112 = (short)((ulonglong)local_170 >> 0x10);
        uStack_110 = (ushort)((ulonglong)local_170 >> 0x20);
        uStack_10e = (undefined2)((ulonglong)local_170 >> 0x30);
        local_108 = (undefined2)((ulonglong)lStack_168 >> 0x20);
        uStack_106 = (undefined2)((ulonglong)lStack_168 >> 0x30);
        uStack_10c = uStack_24c;
        uStack_104 = uStack_244;
        uStack_100 = (undefined4)uStack_240;
      }
      else {
        uVar26 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                           (&local_98,local_1f8,local_2a8);
        lVar30 = lStack_138;
        lVar20 = CONCAT44(uStack_13c,uStack_140);
        if (lStack_138 == lVar39 && uVar26 < 0x14) {
          if (lVar39 != 0) {
            unaff_RSI = (undefined8 *)&DAT_00000010;
            lVar40 = 0;
            plVar19 = uStack_240;
            do {
              uStack_240._4_4_ = (undefined4)((ulonglong)plVar19 >> 0x20);
              if (*(size_t *)(lVar20 + (longlong)unaff_RSI) !=
                  *(size_t *)(lVar24 + (longlong)unaff_RSI)) goto LAB_140006d16;
              uStack_240 = plVar19;
              iVar14 = memcmp(*(void **)(lVar20 + -8 + (longlong)unaff_RSI),
                              *(void **)(lVar24 + -8 + (longlong)unaff_RSI),
                              *(size_t *)(lVar20 + (longlong)unaff_RSI));
              if (iVar14 != 0) goto LAB_140006d16;
              lVar40 = lVar40 + 1;
              unaff_RSI = unaff_RSI + 3;
              plVar19 = uStack_240;
            } while (lVar39 != lVar40);
            unaff_RSI = (undefined8 *)(lVar24 + 8);
            do {
              if (unaff_RSI[-1] != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(*unaff_RSI,unaff_RSI[-1],1);
                return;
              }
              unaff_RSI = unaff_RSI + 3;
              lVar39 = lVar39 + -1;
            } while (lVar39 != 0);
          }
          if (local_170 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar24,local_170 * 0x18,8);
            return;
          }
          <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>as_core[505b25137b8ba7f]::ops::drop::Drop>
          ::drop();
          uVar26 = local_1f8;
          if (local_130 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar1,local_130 * 0x70,8);
            return;
          }
          goto LAB_140006420;
        }
LAB_140006d16:
        uStack_244 = (undefined4)local_160;
        uStack_240._0_4_ = (undefined4)((ulonglong)local_160 >> 0x20);
        local_258._4_4_ = (undefined4)local_170;
        uStack_250 = (uint)((ulonglong)local_170 >> 0x20);
        uStack_24c = (undefined4)lStack_168;
        uStack_248 = (uint)((ulonglong)lStack_168 >> 0x20);
        local_118 = (short)(undefined4)local_258;
        uStack_116 = (undefined4)(CONCAT44(local_258._4_4_,(undefined4)local_258) >> 0x10);
        sStack_112 = (short)((ulonglong)local_170 >> 0x10);
        uStack_110 = (ushort)((ulonglong)local_170 >> 0x20);
        uStack_10e = (undefined2)((ulonglong)local_170 >> 0x30);
        uStack_10c = uStack_24c;
        local_108 = (undefined2)((ulonglong)lStack_168 >> 0x20);
        uStack_106 = (undefined2)((ulonglong)lStack_168 >> 0x30);
        uStack_104 = uStack_244;
        uStack_100 = (undefined4)uStack_240;
        if (lVar30 != 0) {
          unaff_RSI = (undefined8 *)(lVar20 + 8);
          do {
            if (unaff_RSI[-1] != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(*unaff_RSI,unaff_RSI[-1],1);
              return;
            }
            unaff_RSI = unaff_RSI + 3;
            lVar30 = lVar30 + -1;
          } while (lVar30 != 0);
        }
        if (lVar37 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar20,lVar37 * 0x18,8);
          return;
        }
      }
      lVar37 = local_130;
      local_158 = local_200;
      lStack_138 = CONCAT44(uStack_100,uStack_104);
      uStack_13c = (undefined4)(CONCAT26(uStack_106,CONCAT24(local_108,uStack_10c)) >> 0x20);
      uStack_144 = CONCAT22(uStack_10e,uStack_110);
      local_14c = (undefined4)CONCAT42(uStack_116,local_118);
      uStack_148 = (undefined4)(CONCAT26(sStack_112,CONCAT42(uStack_116,local_118)) >> 0x20);
      uStack_140 = uStack_10c;
      local_1e0 = plVar1;
      local_1d8 = plVar1;
      local_1d0 = local_130;
      plVar19 = plVar1;
      plVar31 = plVar1;
      uVar26 = local_200;
      uStack_24c = uStack_10c;
      uStack_244 = uStack_104;
      uStack_240._0_4_ = uStack_100;
      local_1c8 = plVar38;
      local_150 = uVar22;
      if (lVar9 != 0) {
        do {
          plVar29 = plVar19 + 0xe;
          lVar24 = *plVar19;
          plVar31 = plVar29;
          if (lVar24 == -1) break;
          local_288 = plVar19[1];
          local_208 = plVar19[0xd];
          local_218 = plVar19[0xb];
          lStack_210 = plVar19[0xc];
          uStack_248 = *(uint *)(plVar19 + 5);
          uStack_244 = *(undefined4 *)((longlong)plVar19 + 0x2c);
          uStack_240._0_4_ = (undefined4)plVar19[6];
          uStack_240._4_4_ = *(undefined4 *)((longlong)plVar19 + 0x34);
          local_238 = (undefined4)plVar19[7];
          uStack_234 = *(undefined4 *)((longlong)plVar19 + 0x3c);
          uStack_230 = (undefined4)plVar19[8];
          uStack_22c = *(undefined4 *)((longlong)plVar19 + 0x44);
          local_228 = (undefined4)plVar19[9];
          uStack_224 = *(undefined4 *)((longlong)plVar19 + 0x4c);
          uStack_220 = (undefined4)plVar19[10];
          uStack_21c = *(undefined4 *)((longlong)plVar19 + 0x54);
          local_258._0_4_ = (undefined4)plVar19[3];
          local_258._4_4_ = (undefined4)((ulonglong)plVar19[3] >> 0x20);
          uStack_250 = (uint)plVar19[4];
          uStack_24c = (undefined4)((ulonglong)plVar19[4] >> 0x20);
          reach_directory[4b72b9694f6c3c08]::rendezvous::master_udp_addrs
                    (&local_118,local_288,plVar19[2]);
          lVar39 = CONCAT26(sStack_112,CONCAT42(uStack_116,local_118));
          psVar8 = (short *)CONCAT44(uStack_10c,CONCAT22(uStack_10e,uStack_110));
          lVar9 = CONCAT44(uStack_104,CONCAT22(uStack_106,local_108));
          if (lVar9 != 0) {
            psVar27 = psVar8;
            do {
              sVar33 = *psVar27;
              if (sVar33 == 2) break;
              uVar4 = *(undefined4 *)(psVar27 + 1);
              sVar3 = psVar27[3];
              uVar26 = *(ulonglong *)(psVar27 + 4);
              local_a8 = *(undefined8 *)(psVar27 + 8);
              uStack_a0 = *(undefined8 *)(psVar27 + 0xc);
              sStack_112 = psVar27[3];
              uStack_116 = *(undefined4 *)(psVar27 + 1);
              uStack_110 = (ushort)uVar26;
              uVar34 = uStack_110;
              uStack_10e = (undefined2)(uVar26 >> 0x10);
              uVar10 = uStack_10e;
              uStack_10c = (undefined4)(uVar26 >> 0x20);
              uVar11 = uStack_10c;
              uVar18 = *(undefined8 *)(psVar27 + 8);
              local_108 = (undefined2)uVar18;
              uStack_106 = (undefined2)((ulonglong)uVar18 >> 0x10);
              uStack_104 = (undefined4)((ulonglong)uVar18 >> 0x20);
              uStack_100 = (undefined4)*(undefined8 *)(psVar27 + 0xc);
              uStack_fc = (undefined4)((ulonglong)*(undefined8 *)(psVar27 + 0xc) >> 0x20);
              local_118 = sVar33;
              host_probe[b94139f9089eb1d8]::net::add_master();
              lVar20 = param_1[1];
              unaff_RSI = (undefined8 *)0x0;
              if (DAT_140699990 == 0) {
                <std[3bf9d48a0c3997f0]::net::tcp::TcpStream>::local_addr(&local_118,&DAT_140699980);
                if (local_118 == 2) {
                  if ((1 < (uStack_110 & 3) - 2) && ((uStack_110 & 3) != 0)) {
                    lVar20 = CONCAT44(uStack_10c,CONCAT22(uStack_10e,uStack_110)) + -1;
                    uStack_270 = (ushort)lVar20;
                    uStack_26e = (undefined6)((ulonglong)lVar20 >> 0x10);
                    local_278 = 3;
                    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                    ::drop();
                  }
                  goto LAB_140006fd1;
                }
                uStack_88 = CONCAT26(uStack_110,CONCAT24(sStack_112,uStack_116));
                uStack_80 = CONCAT42(uStack_10c,uStack_10e);
                uStack_76 = uStack_104;
                uStack_72 = uStack_100;
                uStack_6e = uStack_fc;
                uStack_78 = uStack_106;
                local_7a = local_108;
                if ((char)lVar20 == '\0') goto LAB_140006fd1;
                local_278 = (undefined1)local_118;
                uStack_277 = (undefined1)((ushort)local_118 >> 8);
                uStack_260 = CONCAT44(uStack_fc,uStack_100);
                uStack_266 = (undefined6)
                             (CONCAT44(uStack_104,CONCAT22(uStack_106,local_108)) >> 0x10);
                uStack_276 = uStack_116;
                sStack_272 = sStack_112;
                uStack_270 = uStack_110;
                uStack_268 = local_108;
                local_108 = (undefined2)local_a8;
                uStack_106 = (undefined2)((ulonglong)local_a8 >> 0x10);
                uStack_104 = (undefined4)((ulonglong)local_a8 >> 0x20);
                uStack_100 = (undefined4)uStack_a0;
                uStack_fc = (undefined4)((ulonglong)uStack_a0 >> 0x20);
                uStack_26e = uStack_80;
                local_118 = sVar33;
                uStack_116 = uVar4;
                sStack_112 = sVar3;
                uStack_110 = uVar34;
                uStack_10e = uVar10;
                uStack_10c = uVar11;
                reach_directory[4b72b9694f6c3c08]::rendezvous::own_lan_addrs
                          (&local_1c0,&local_278,&local_118);
              }
              else {
LAB_140006fd1:
                local_1c0 = 0;
                local_1b8 = 4;
                local_1b0 = 0;
              }
              reach_directory[4b72b9694f6c3c08]::rendezvous::host_message
                        (&local_118,CONCAT44(uStack_24c,uStack_250),CONCAT44(uStack_244,uStack_248),
                         CONCAT44(uStack_234,local_238),CONCAT44(uStack_22c,uStack_230),local_1b8,
                         local_1b0,*(undefined1 *)((longlong)param_1 + 9));
              reach_directory[4b72b9694f6c3c08]::rendezvous::encode(&local_1a8,&local_118);
              if (DAT_140699990 == 0) {
                if (sVar33 != -1) {
                  local_278 = (undefined1)sVar33;
                  uStack_277 = (undefined1)((ushort)sVar33 >> 8);
                  uStack_26e = (undefined6)(uVar26 >> 0x10);
                  uStack_268 = (undefined2)local_a8;
                  uStack_266 = (undefined6)((ulonglong)local_a8 >> 0x10);
                  uStack_260 = uStack_a0;
                  uVar26 = uStack_1a0;
                  uStack_276 = uVar4;
                  sStack_272 = sVar3;
                  uStack_270 = uVar34;
                  uVar15 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                                     (&DAT_140699980,uStack_1a0,local_198);
                  if ((uVar15 & 1) == 0) {
                    LOCK();
                    DAT_1407f1050 = DAT_1407f1050 + uVar26;
                    UNLOCK();
                    LOCK();
                    DAT_1407f1058 = DAT_1407f1058 + 1;
                    UNLOCK();
                    goto LAB_140007073;
                  }
                }
                LOCK();
                DAT_1407f1080 = DAT_1407f1080 + 1;
                UNLOCK();
                if ((1 < ((uint)uVar26 & 3) - 2) && ((uVar26 & 3) != 0)) {
                  uStack_270 = (ushort)(uVar26 - 1);
                  uStack_26e = (undefined6)(uVar26 - 1 >> 0x10);
                  local_278 = 3;
                  <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                  ::drop(&uStack_270);
                }
              }
LAB_140007073:
              if (local_1a8 != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_1a0,local_1a8,1);
                return;
              }
              core[505b25137b8ba7f]::ptr::drop_glue::
              <reach_directory[4b72b9694f6c3c08]::rendezvous::Message>(&local_118);
              if (local_1c0 != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(local_1b8,local_1c0 << 5,4);
                return;
              }
              psVar27 = psVar27 + 0x10;
              uVar26 = local_200;
            } while (psVar27 != psVar8 + lVar9 * 0x10);
          }
          if (lVar39 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(psVar8,lVar39 << 5,4);
            return;
          }
          if (CONCAT44(local_258._4_4_,(undefined4)local_258) != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      (CONCAT44(uStack_24c,uStack_250),
                       CONCAT44(local_258._4_4_,(undefined4)local_258),1);
            return;
          }
          if (CONCAT44(uStack_240._4_4_,(undefined4)uStack_240) != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      (CONCAT44(uStack_234,local_238),
                       CONCAT44(uStack_240._4_4_,(undefined4)uStack_240),1);
            return;
          }
          if (CONCAT44(uStack_224,local_228) != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      (CONCAT44(uStack_21c,uStack_220),CONCAT44(uStack_224,local_228),1);
            return;
          }
          if (lVar24 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(local_288,lVar24,1);
            return;
          }
          plVar19 = plVar29;
          plVar31 = plVar38;
        } while (plVar29 != plVar38);
      }
      local_1d8 = plVar31;
      core[505b25137b8ba7f]::ptr::drop_glue::
      <[(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)]>
                (plVar31,((ulonglong)((longlong)plVar38 - (longlong)plVar31) >> 4) *
                         0x6db6db6db6db6db7);
      local_2a8 = uVar22;
      if (lVar37 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar1,lVar37 * 0x70,8);
        return;
      }
      goto LAB_140006420;
    }
    local_258._0_4_ = 0x4069ddb0;
    local_258._4_4_ = 1;
    uStack_250._1_3_ = (undefined3)(uStack_250 >> 8);
    uStack_250 = CONCAT31(uStack_250._1_3_,bVar32);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_258,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1030
               ,&PTR_s_src_announce_rs_1406a0990);
  }
  else {
    uStack_250._1_3_ = (undefined3)(uStack_250 >> 8);
    uStack_250 = CONCAT31(uStack_250._1_3_,bVar13);
    local_258 = pcVar21;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_258,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1110
               ,&PTR_s_src_announce_rs_1406a0978);
  }
LAB_1400076a1:
                    /* WARNING: Does not return */
  pcVar5 = (code *)invalidInstructionException();
  (*pcVar5)();
}

