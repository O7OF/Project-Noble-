// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::parse_keys
// address: 0x1400180f0
// body: available
// range: 0x1400180f0-0x14001818e inclusive
// range: 0x140018194-0x1400183f2 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14001818a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400181ce to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140018369 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::parse_keys */

void __rustcall
host_probe[b94139f9089eb1d8]::ingame_chat::parse_keys
          (undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  code *pcVar4;
  undefined *puVar5;
  longlong *plVar6;
  ulonglong uVar7;
  longlong lVar8;
  DWORD dwTlsIndex;
  char local_91;
  longlong local_90;
  longlong *local_88;
  longlong local_80;
  char *local_78;
  longlong lStack_70;
  longlong local_68;
  longlong lStack_60;
  longlong local_58;
  longlong lStack_50;
  longlong local_48;
  undefined8 local_40;
  undefined1 local_38;
  undefined2 local_30;
  
  local_91 = -1;
  local_78 = &local_91;
  lStack_70 = 0;
  lStack_50 = 0;
  local_40 = 0x2c0000002c;
  local_38 = 1;
  local_30 = 1;
  local_68 = param_3;
  lStack_60 = param_2;
  local_58 = param_3;
  local_48 = param_3;
  <alloc[246c2e7857c81348]::vec::Vec<usize>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<usize,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,<str>::parse<usize>>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,core[505b25137b8ba7f]::num::error::ParseIntError>>>>
  ::from_iter(&local_90,&local_78);
  puVar5 = 
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
  ;
  if (local_91 == -1) {
    if (local_90 == -1) goto LAB_140018393;
    if (local_80 == 3) {
      lVar1 = *local_88;
      plVar2 = (longlong *)local_88[1];
      lVar3 = local_88[2];
      if (local_90 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_88,local_90 << 3,8);
        return;
      }
      if (((((lVar1 - 0xdbU < 5) || (lVar1 - 0xbaU < 7)) || (lVar1 - 0x60U < 0x28)) ||
          ((lVar1 - 0x30U < 10 || (lVar1 - 0x41U < 0x1a)))) &&
         (((((longlong)plVar2 - 0xdbU < 5 ||
            (((longlong)plVar2 - 0xbaU < 7 || (plVar2 + -0xc < (longlong *)0x28)))) ||
           ((plVar2 + -6 < (longlong *)0xa || ((longlong)plVar2 - 0x41U < 0x1a)))) &&
          ((((lVar3 - 0xdbU < 5 || (lVar3 - 0xbaU < 7)) || (lVar3 - 0x60U < 0x28)) ||
           ((lVar3 - 0x30U < 10 || (lVar3 - 0x41U < 0x1a)))))))) {
        local_90 = lVar1;
        local_88 = plVar2;
        local_80 = lVar3;
        if (*(longlong *)
             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
            != 0) {
          std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
        }
        if (*(int *)(puVar5 + 0x18) == 0) {
          dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                                 (
                                 __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                                 );
          plVar6 = TlsGetValue(dwTlsIndex);
        }
        else {
          dwTlsIndex = *(int *)(puVar5 + 0x18) - 1;
          plVar6 = TlsGetValue(dwTlsIndex);
        }
        if (plVar6 < (longlong *)0x2) {
          plVar6 = (longlong *)
                   <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                   ::try_initialize::
                   <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                             (dwTlsIndex,plVar6,0);
        }
        if (plVar6 == (longlong *)0x0) {
          std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                    (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
                    /* WARNING: Does not return */
          pcVar4 = (code *)invalidInstructionException();
          (*pcVar4)();
        }
        local_58 = *plVar6;
        lStack_50 = plVar6[1];
        *plVar6 = *plVar6 + 1;
        local_68 = 0;
        lStack_60 = 0;
        local_78 = &DAT_1406a0540;
        lStack_70 = 0;
        <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(&usize,())>>::reserve_rehash::
        <hashbrown[ad6d4a1843b2832d]::map::make_hasher<&usize,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>::_closure_0_>
                  (&local_78,3,&local_58);
        <hashbrown[ad6d4a1843b2832d]::map::HashMap<&usize,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
        ::insert(&local_78,&local_90);
        <hashbrown[ad6d4a1843b2832d]::map::HashMap<&usize,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
        ::insert(&local_78,&local_88);
        <hashbrown[ad6d4a1843b2832d]::map::HashMap<&usize,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
        ::insert(&local_78,&local_80);
        if (lStack_70 != 0) {
          uVar7 = lStack_70 * 8 & 0xfffffffffffffff0;
          lVar8 = lStack_70 + uVar7 + 0x21;
          if (lVar8 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(local_78 + (-0x10 - uVar7),lVar8,0x10);
            return;
          }
        }
        if (lStack_60 == 3) {
          param_1[1] = lVar1;
          param_1[2] = plVar2;
          param_1[3] = lVar3;
          *param_1 = 1;
          return;
        }
      }
      *param_1 = 0;
      return;
    }
  }
  if (local_90 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_88,local_90 << 3,8);
    return;
  }
LAB_140018393:
  *param_1 = 0;
  return;
}

