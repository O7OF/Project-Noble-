// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<std[3bf9d48a0c3997f0]::path::PathBuf>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<std[3bf9d48a0c3997f0]::path::PathBuf,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::str::iter::Lines,host_probe[b94139f9089eb1d8]::steam::all_libraries::{closure#0}>>>::from_iter
// address: 0x14004df70
// body: available
// range: 0x14004df70-0x14004e109 inclusive
// range: 0x14004e110-0x14004e195 inclusive
// range: 0x14004e1a0-0x14004e1d6 inclusive
// range: 0x14004e1e0-0x14004e34f inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<std[3bf9d48a0c3997f0]::path::PathBuf> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<std[3bf9d48a0c3997f0]::path::PathBuf,
   core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::str::iter::Lines,
   host_probe[b94139f9089eb1d8]::steam::all_libraries::{closure#0}>>>::from_iter */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<std[3bf9d48a0c3997f0]::path::PathBuf>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<std[3bf9d48a0c3997f0]::path::PathBuf,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::str::iter::Lines,host_probe[b94139f9089eb1d8]::steam::all_libraries::{closure#0}>>>
::from_iter(ulonglong *param_1,ulonglong *param_2)

{
  char cVar1;
  code *pcVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  int iVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong lVar10;
  ulonglong *puVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong _Size;
  ulonglong uVar17;
  ulonglong local_100;
  ulonglong *local_f8;
  ulonglong local_f0;
  ulonglong local_e8;
  ulonglong uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  ulonglong local_c8;
  undefined8 uStack_c0;
  ulonglong local_b8;
  ulonglong uStack_b0;
  undefined8 local_a8;
  ulonglong *local_98;
  ulonglong local_90;
  ulonglong local_88;
  ulonglong *local_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined1 local_48 [8];
  
  puVar11 = param_2;
  lVar8 = <core[505b25137b8ba7f]::str::iter::Lines_as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
          ::next(param_2);
  if (lVar8 != 0) {
    do {
      puVar12 = &local_100;
      <&mut_host_probe[b94139f9089eb1d8]::steam::all_libraries::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<(&str,)>>
      ::call_mut(&local_e8,&local_100,lVar8,puVar11);
      if (local_e8 != 0xffffffffffffffff) {
        local_78 = (undefined4)local_d8;
        uStack_74 = local_d8._4_4_;
        uStack_70 = (undefined4)uStack_d0;
        uStack_6c = uStack_d0._4_4_;
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        local_80 = (ulonglong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x80);
        if (local_80 == (ulonglong *)0x0) {
          alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x80);
                    /* WARNING: Does not return */
          pcVar2 = (code *)invalidInstructionException();
          (*pcVar2)();
        }
        *local_80 = local_e8;
        local_80[1] = uStack_e0;
        local_80[2] = CONCAT44(uStack_74,local_78);
        local_80[3] = CONCAT44(uStack_6c,uStack_70);
        local_100 = 4;
        local_f0 = 1;
        local_a8 = param_2[8];
        uVar15 = local_a8;
        local_e8 = *param_2;
        uStack_e0 = param_2[1];
        local_d8 = param_2[2];
        uStack_d0 = param_2[3];
        local_c8 = param_2[4];
        uStack_c0 = param_2[5];
        local_b8 = param_2[6];
        uStack_b0 = param_2[7];
        local_a8._1_1_ = (char)(param_2[8] >> 8);
        local_f8 = local_80;
        if (local_a8._1_1_ != '\0') goto LAB_14004e30e;
        local_98 = param_1;
        local_a8 = uVar15;
        goto LAB_14004e09b;
      }
      lVar8 = <core[505b25137b8ba7f]::str::iter::Lines_as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
              ::next(param_2);
      puVar11 = puVar12;
    } while (lVar8 != 0);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
LAB_14004e09b:
  uVar6 = local_a8;
  uVar5 = uStack_c0;
  uVar4 = uStack_d0;
  uVar3 = local_d8;
  local_88 = local_f0;
  _Size = uStack_b0 & 0xff;
  local_90 = uStack_e0;
  uVar15 = local_c8;
  uVar17 = local_e8;
  do {
    uVar16 = uVar15;
    if ((uVar5 <= uVar4) && (uVar15 <= uVar5)) {
      cVar1 = *(char *)((longlong)&uStack_c0 + _Size + 7);
      do {
        uVar14 = uVar3 + uVar15;
        uVar16 = uVar5;
        if (uVar5 - uVar15 < 0x10) {
          if (uVar5 == uVar15) break;
          uVar13 = 0;
          while (*(char *)(uVar14 + uVar13) != cVar1) {
            uVar13 = uVar13 + 1;
            if (uVar5 - uVar15 == uVar13) goto LAB_14004e1a3;
          }
        }
        else {
          uVar9 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(cVar1);
          uVar13 = uVar14;
          if ((uVar9 & 1) == 0) break;
        }
        uVar15 = uVar15 + uVar13 + 1;
        if ((_Size <= uVar15 && uVar15 <= uVar4) &&
           (iVar7 = memcmp((void *)((uVar15 - _Size) + uVar3),&local_b8,_Size), iVar7 == 0)) {
          lVar8 = uVar15 - uVar17;
          uVar16 = uVar15;
          uVar14 = uVar15;
          goto joined_r0x00014004e18f;
        }
        uVar16 = uVar15;
      } while (uVar15 <= uVar5);
    }
LAB_14004e1a3:
    local_a8._0_2_ = CONCAT11(1,(undefined1)local_a8);
    if (((uVar6 & 1) == 0) && (param_1 = local_98, local_90 == uVar17)) goto LAB_14004e30e;
    lVar8 = local_90 - uVar17;
    uVar15 = uVar16;
    uVar16 = uVar17;
    uVar14 = local_90;
joined_r0x00014004e18f:
    lVar10 = lVar8;
    if ((lVar8 != 0) && (*(char *)((uVar3 - 1) + uVar14) == '\n')) {
      lVar10 = lVar8 + -1;
      if (lVar10 == 0) {
        lVar10 = 0;
      }
      else if (*(char *)((uVar3 - 2) + uVar14) == '\r') {
        lVar10 = lVar8 + -2;
      }
    }
    <&mut_host_probe[b94139f9089eb1d8]::steam::all_libraries::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<(&str,)>>
    ::call_mut(&local_78,local_48,uVar3 + uVar17,lVar10);
    uVar14 = local_88;
    uVar17 = CONCAT44(uStack_74,local_78);
    if (uVar17 != 0xffffffffffffffff) break;
    param_1 = local_98;
    uVar17 = uVar16;
    if (local_a8._1_1_ != '\0') goto LAB_14004e30e;
  } while( true );
  uVar3 = CONCAT44(uStack_6c,uStack_70);
  local_58 = local_68;
  uStack_54 = uStack_64;
  uStack_50 = uStack_60;
  uStack_4c = uStack_5c;
  local_e8 = uVar16;
  local_c8 = uVar15;
  if (local_88 == local_100) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_100,local_88,1,8,0x20);
    local_80 = local_f8;
  }
  local_80[uVar14 * 4] = uVar17;
  local_80[uVar14 * 4 + 1] = uVar3;
  local_80[uVar14 * 4 + 2] = CONCAT44(uStack_54,local_58);
  (local_80 + uVar14 * 4 + 2)[1] = CONCAT44(uStack_4c,uStack_50);
  local_f0 = uVar14 + 1;
  param_1 = local_98;
  if (local_a8._1_1_ != '\0') {
LAB_14004e30e:
    param_1[2] = local_f0;
    *param_1 = local_100;
    param_1[1] = (ulonglong)local_f8;
    return param_1;
  }
  goto LAB_14004e09b;
}

