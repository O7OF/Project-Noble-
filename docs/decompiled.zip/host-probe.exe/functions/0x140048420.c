// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::vote::Player>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<host_probe[b94139f9089eb1d8]::vote::Player,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<u8>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#1}>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
// address: 0x140048420
// body: available
// range: 0x140048420-0x1400484f6 inclusive
// range: 0x140048500-0x1400485f5 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::vote::Player> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<host_probe[b94139f9089eb1d8]::vote::Player,
   core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<u8>,
   host_probe[b94139f9089eb1d8]::vote::decode::{closure#1}>,
   core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::vote::Player>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<host_probe[b94139f9089eb1d8]::vote::Player,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<u8>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#1}>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined1 local_d1;
  longlong local_d0;
  longlong *plStack_c8;
  longlong local_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  longlong local_98;
  longlong local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  undefined8 uStack_50;
  
  <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<u8>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::try_fold::
  <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<u8>,host_probe[b94139f9089eb1d8]::vote::decode::_closure_1_>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<host_probe[b94139f9089eb1d8]::vote::Player,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>>>
            (&local_98,param_2,&local_d1,param_2[2]);
  lVar3 = local_90;
  lVar9 = local_98;
  if (local_98 != -2) {
    local_b8 = local_88;
    uVar4 = local_b8;
    uStack_b0 = uStack_80;
    uVar5 = uStack_b0;
    if (local_98 != -1) {
      local_b8._0_4_ = (undefined4)local_88;
      local_b8._4_4_ = (undefined4)((ulonglong)local_88 >> 0x20);
      uStack_b0._0_4_ = (undefined4)uStack_80;
      uStack_b0._4_4_ = (undefined4)((ulonglong)uStack_80 >> 0x20);
      local_78 = (undefined4)local_b8;
      uStack_74 = local_b8._4_4_;
      uStack_70 = (undefined4)uStack_b0;
      uStack_6c = uStack_b0._4_4_;
      local_b8 = uVar4;
      uStack_b0 = uVar5;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      plVar8 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x80,8);
      if (plVar8 == (longlong *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x80);
                    /* WARNING: Does not return */
        pcVar2 = (code *)invalidInstructionException();
        (*pcVar2)();
      }
      *plVar8 = lVar9;
      plVar8[1] = lVar3;
      plVar8[2] = CONCAT44(uStack_74,local_78);
      plVar8[3] = CONCAT44(uStack_6c,uStack_70);
      local_d0 = 4;
      local_c0 = 1;
      local_a8 = param_2[2];
      local_b8 = *param_2;
      uStack_b0 = param_2[1];
      lVar9 = 0x30;
      plStack_c8 = plVar8;
      while (lVar3 = local_c0,
            <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<u8>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
            ::try_fold::
            <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<u8>,host_probe[b94139f9089eb1d8]::vote::decode::_closure_1_>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<host_probe[b94139f9089eb1d8]::vote::Player,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::vote::Player>>>
                      (&local_98,&local_b8,&local_d1,local_a8), lVar7 = local_90, lVar6 = local_98,
            local_98 != -2) {
        local_58 = local_88;
        uVar4 = local_58;
        uStack_50 = uStack_80;
        uVar5 = uStack_50;
        if (local_98 == -1) break;
        local_58._0_4_ = (undefined4)local_88;
        local_68 = (undefined4)local_58;
        local_58._4_4_ = (undefined4)((ulonglong)local_88 >> 0x20);
        uStack_64 = local_58._4_4_;
        uStack_50._0_4_ = (undefined4)uStack_80;
        uStack_60 = (undefined4)uStack_50;
        uStack_50._4_4_ = (undefined4)((ulonglong)uStack_80 >> 0x20);
        uStack_5c = uStack_50._4_4_;
        local_58 = local_88;
        uStack_50 = uStack_80;
        if (lVar3 == local_d0) {
          local_58 = uVar4;
          uStack_50 = uVar5;
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>(&local_d0,lVar3,1,8,0x20);
          plVar8 = plStack_c8;
        }
        *(longlong *)((longlong)plVar8 + lVar9 + -0x10) = lVar6;
        *(longlong *)((longlong)plVar8 + lVar9 + -8) = lVar7;
        puVar1 = (undefined4 *)((longlong)plVar8 + lVar9);
        *puVar1 = local_68;
        puVar1[1] = uStack_64;
        puVar1[2] = uStack_60;
        puVar1[3] = uStack_5c;
        local_c0 = lVar3 + 1;
        lVar9 = lVar9 + 0x20;
      }
      param_1[2] = local_c0;
      *param_1 = local_d0;
      param_1[1] = (longlong)plStack_c8;
      return param_1;
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

