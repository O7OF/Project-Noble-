// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::hudx::data_new
// address: 0x14003da80
// body: available
// range: 0x14003da80-0x14003db87 inclusive
// range: 0x14003db8a-0x14003dc0e inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003dad1 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003db83 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::hudx::data_new */

void __rustcall
host_probe[b94139f9089eb1d8]::hudx::data_new
          (longlong *param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined8 param_5)

{
  size_t sVar1;
  int local_80;
  undefined4 local_7c;
  undefined8 local_78;
  undefined8 uStack_70;
  int *local_68;
  code *local_60;
  undefined4 *local_58;
  code *local_50;
  longlong *local_40;
  longlong local_38;
  undefined4 local_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 local_20;
  
  local_80 = param_2;
  local_7c = param_3;
  std[3bf9d48a0c3997f0]::sys::env::windows::getenv(&local_78,&DAT_1406a378b,0xd);
  if (local_78 == (longlong **)0xffffffffffffffff) {
    if (param_1 == (longlong *)0x0) goto LAB_14003dbdf;
  }
  else {
    if (local_78 != (longlong **)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_70,local_78,1);
      return;
    }
    if (param_1 == (longlong *)0x0) goto LAB_14003dbdf;
    sVar1 = strlen((char *)param_1);
    local_38 = sVar1 + 1;
    local_78 = &local_40;
    uStack_70 = <&core[505b25137b8ba7f]::ffi::c_str::CStr_as_core[505b25137b8ba7f]::fmt::Debug>::fmt
    ;
    local_68 = &local_80;
    local_60 = <u32_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_58 = &local_7c;
    local_50 = <u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    local_40 = param_1;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_30,&DAT_1406a3798,&local_78);
    local_78 = (longlong **)CONCAT44(uStack_2c,local_30);
    uStack_70 = (code *)CONCAT44(uStack_24,uStack_28);
    local_68 = (int *)local_20;
    host::log(uStack_70);
    if (local_78 != (longlong **)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_70,local_78,1);
      return;
    }
  }
  sVar1 = strlen((char *)param_1);
  param_2 = local_80;
  if ((0xb < sVar1) &&
     (local_80 == 0x80 && ((int)param_1[1] == 0x73746567 && *param_1 == 0x6469772064756863))) {
    local_80 = (int)capacity::PLAYERS_0_llvm_16945119018599968161 << 3;
    param_2 = local_80;
  }
LAB_14003dbdf:
  (*ORIG_DATA_NEW_0)(param_1,param_2,local_7c,param_4,param_5);
  return;
}

