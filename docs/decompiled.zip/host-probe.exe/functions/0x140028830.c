// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::cut_off
// address: 0x140028830
// body: available
// range: 0x140028830-0x140028c56 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::cut_off */

void __rustcall host_probe[b94139f9089eb1d8]::net::cut_off(longlong param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  undefined1 *puVar2;
  code *pcVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined *puVar10;
  byte bVar11;
  char cVar12;
  ulonglong uVar13;
  undefined8 uVar14;
  undefined4 uVar15;
  ulonglong uVar16;
  longlong lVar17;
  uint uVar18;
  ushort uVar19;
  longlong lVar20;
  bool bVar21;
  byte bVar22;
  undefined1 auVar23 [16];
  undefined1 in_XMM1_Ba;
  undefined1 in_XMM1_Bb;
  undefined1 in_XMM1_Bc;
  undefined1 in_XMM1_Bd;
  undefined1 in_XMM1_Be;
  undefined1 in_XMM1_Bf;
  undefined1 in_XMM1_Bg;
  undefined1 in_XMM1_Bh;
  undefined1 in_XMM1_Bi;
  undefined1 in_XMM1_Bj;
  undefined1 in_XMM1_Bk;
  undefined1 in_XMM1_Bl;
  undefined1 in_XMM1_Bm;
  undefined1 in_XMM1_Bn;
  undefined1 in_XMM1_Bo;
  undefined1 in_XMM1_Bp;
  undefined1 auVar24 [16];
  undefined1 auVar25 [16];
  longlong local_d8;
  undefined1 *local_d0;
  undefined4 local_c8;
  undefined8 local_c4;
  undefined8 uStack_bc;
  undefined1 local_b4;
  undefined1 uStack_b3;
  undefined1 uStack_b2;
  undefined1 uStack_b1;
  undefined1 uStack_b0;
  undefined1 uStack_af;
  undefined1 uStack_ae;
  undefined1 uStack_ad;
  undefined1 uStack_ac;
  undefined1 uStack_ab;
  undefined1 uStack_aa;
  undefined1 uStack_a9;
  undefined1 uStack_a8;
  undefined1 uStack_a7;
  undefined1 uStack_a6;
  undefined1 uStack_a5;
  undefined8 local_a4;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  
  if (DAT_140699990 != 0) {
    return;
  }
  LOCK();
  bVar21 = DAT_140699948 == '\0';
  if (bVar21) {
    DAT_140699948 = '\x01';
  }
  UNLOCK();
  uVar16 = param_2;
  local_d8 = param_1;
  if (!bVar21) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
  }
  puVar10 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar11 = 0;
  }
  else {
    bVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar11 = bVar11 ^ 1;
  }
  if (DAT_140699949 != '\0') {
    local_d0 = &DAT_140699948;
    local_c8._1_3_ = (undefined3)((uint)local_c8 >> 8);
    local_c8 = CONCAT31(local_c8._1_3_,bVar11);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_d0,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2830);
    goto LAB_140028bc5;
  }
  if (DAT_140699968 != 0) {
    uVar13 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
             ::hash_one::<&usize>(&DAT_140699970,&local_d8);
    bVar22 = (byte)(uVar13 >> 0x39);
    auVar23 = ZEXT216(CONCAT11(bVar22,bVar22));
    auVar23 = pshuflw(auVar23,auVar23,0);
    lVar17 = 0;
    iVar6 = -(uint)(CONCAT13(in_XMM1_Bd,CONCAT12(in_XMM1_Bc,CONCAT11(in_XMM1_Bb,in_XMM1_Ba))) ==
                   CONCAT13(in_XMM1_Bd,CONCAT12(in_XMM1_Bc,CONCAT11(in_XMM1_Bb,in_XMM1_Ba))));
    iVar7 = -(uint)(CONCAT13(in_XMM1_Bh,CONCAT12(in_XMM1_Bg,CONCAT11(in_XMM1_Bf,in_XMM1_Be))) ==
                   CONCAT13(in_XMM1_Bh,CONCAT12(in_XMM1_Bg,CONCAT11(in_XMM1_Bf,in_XMM1_Be))));
    iVar8 = -(uint)(CONCAT13(in_XMM1_Bl,CONCAT12(in_XMM1_Bk,CONCAT11(in_XMM1_Bj,in_XMM1_Bi))) ==
                   CONCAT13(in_XMM1_Bl,CONCAT12(in_XMM1_Bk,CONCAT11(in_XMM1_Bj,in_XMM1_Bi))));
    iVar9 = -(uint)(CONCAT13(in_XMM1_Bp,CONCAT12(in_XMM1_Bo,CONCAT11(in_XMM1_Bn,in_XMM1_Bm))) ==
                   CONCAT13(in_XMM1_Bp,CONCAT12(in_XMM1_Bo,CONCAT11(in_XMM1_Bn,in_XMM1_Bm))));
    while( true ) {
      uVar13 = uVar13 & DAT_140699958;
      auVar1 = *(undefined1 (*) [16])(DAT_140699950 + uVar13);
      auVar25[0] = -(auVar1[0] == auVar23[0]);
      auVar25[1] = -(auVar1[1] == auVar23[1]);
      auVar25[2] = -(auVar1[2] == auVar23[2]);
      auVar25[3] = -(auVar1[3] == auVar23[3]);
      auVar25[4] = -(auVar1[4] == auVar23[4]);
      auVar25[5] = -(auVar1[5] == auVar23[5]);
      auVar25[6] = -(auVar1[6] == auVar23[6]);
      auVar25[7] = -(auVar1[7] == auVar23[7]);
      auVar25[8] = -(auVar1[8] == auVar23[0]);
      auVar25[9] = -(auVar1[9] == auVar23[1]);
      auVar25[10] = -(auVar1[10] == auVar23[2]);
      auVar25[0xb] = -(auVar1[0xb] == auVar23[3]);
      auVar25[0xc] = -(auVar1[0xc] == auVar23[4]);
      auVar25[0xd] = -(auVar1[0xd] == auVar23[5]);
      auVar25[0xe] = -(auVar1[0xe] == auVar23[6]);
      auVar25[0xf] = -(auVar1[0xf] == auVar23[7]);
      uVar19 = (ushort)(SUB161(auVar25 >> 7,0) & 1) | (ushort)(SUB161(auVar25 >> 0xf,0) & 1) << 1 |
               (ushort)(SUB161(auVar25 >> 0x17,0) & 1) << 2 |
               (ushort)(SUB161(auVar25 >> 0x1f,0) & 1) << 3 |
               (ushort)(SUB161(auVar25 >> 0x27,0) & 1) << 4 |
               (ushort)(SUB161(auVar25 >> 0x2f,0) & 1) << 5 |
               (ushort)(SUB161(auVar25 >> 0x37,0) & 1) << 6 |
               (ushort)(SUB161(auVar25 >> 0x3f,0) & 1) << 7 |
               (ushort)(SUB161(auVar25 >> 0x47,0) & 1) << 8 |
               (ushort)(SUB161(auVar25 >> 0x4f,0) & 1) << 9 |
               (ushort)(SUB161(auVar25 >> 0x57,0) & 1) << 10 |
               (ushort)(SUB161(auVar25 >> 0x5f,0) & 1) << 0xb |
               (ushort)(SUB161(auVar25 >> 0x67,0) & 1) << 0xc |
               (ushort)(SUB161(auVar25 >> 0x6f,0) & 1) << 0xd |
               (ushort)(SUB161(auVar25 >> 0x77,0) & 1) << 0xe | (ushort)(auVar25[0xf] >> 7) << 0xf;
      uVar18 = (uint)uVar19;
      while (uVar19 != 0) {
        uVar4 = 0;
        for (uVar5 = uVar18; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
          uVar4 = uVar4 + 1;
        }
        lVar20 = (uVar4 + uVar13 & DAT_140699958) * -0x50;
        if (param_1 == *(longlong *)(DAT_140699950 + -0x50 + lVar20)) {
          lVar20 = DAT_140699950 + lVar20;
          puVar2 = *(undefined1 **)(lVar20 + -0x48);
          uVar15 = *(undefined4 *)(lVar20 + -0x40);
          uStack_54 = *(undefined8 *)(lVar20 + -8);
          uStack_58 = (undefined4)((ulonglong)*(undefined8 *)(lVar20 + -0x10) >> 0x20);
          uStack_68 = *(undefined8 *)(lVar20 + -0x1c);
          uStack_60 = (undefined4)*(undefined8 *)(lVar20 + -0x14);
          local_5c = (undefined4)((ulonglong)*(undefined8 *)(lVar20 + -0x14) >> 0x20);
          local_78 = *(undefined8 *)(lVar20 + -0x2c);
          uStack_70 = *(undefined8 *)(lVar20 + -0x24);
          local_88 = *(undefined8 *)(lVar20 + -0x3c);
          uStack_80 = *(undefined8 *)(lVar20 + -0x34);
          if (((bVar11 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
             (cVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
             cVar12 == '\0')) {
            DAT_140699949 = '\x01';
          }
          cVar12 = DAT_140699948;
          LOCK();
          DAT_140699948 = '\0';
          UNLOCK();
          if (cVar12 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
          }
          local_c4 = local_88;
          uStack_bc = uStack_80;
          local_b4 = (undefined1)local_78;
          uStack_b3 = local_78._1_1_;
          uStack_b2 = local_78._2_1_;
          uStack_b1 = local_78._3_1_;
          uStack_b0 = local_78._4_1_;
          uStack_af = local_78._5_1_;
          uStack_ae = local_78._6_1_;
          uStack_ad = local_78._7_1_;
          uStack_ac = (undefined1)uStack_70;
          uStack_ab = uStack_70._1_1_;
          uStack_aa = uStack_70._2_1_;
          uStack_a9 = uStack_70._3_1_;
          uStack_a8 = uStack_70._4_1_;
          uStack_a7 = uStack_70._5_1_;
          uStack_a6 = uStack_70._6_1_;
          uStack_a5 = uStack_70._7_1_;
          local_a4 = uStack_68;
          uStack_9c = uStack_60;
          uStack_98 = local_5c;
          uStack_94 = uStack_58;
          uStack_90 = uStack_54;
          lVar17 = param_1;
          local_d0 = puVar2;
          local_c8 = uVar15;
          send_kick(&local_d0,param_1,param_2 & 0xffffffff);
          uVar15 = (undefined4)lVar17;
          LOCK();
          bVar21 = BLOCKED == '\0';
          if (bVar21) {
            BLOCKED = '\x01';
          }
          UNLOCK();
          goto joined_r0x000140028aee;
        }
        uVar19 = (ushort)(uVar18 - 1) & (ushort)uVar18;
        uVar18 = CONCAT22((short)(uVar18 - 1 >> 0x10),uVar19);
      }
      auVar24[0] = -(auVar1[0] == (char)iVar6);
      auVar24[1] = -(auVar1[1] == (char)((uint)iVar6 >> 8));
      auVar24[2] = -(auVar1[2] == (char)((uint)iVar6 >> 0x10));
      auVar24[3] = -(auVar1[3] == (char)((uint)iVar6 >> 0x18));
      auVar24[4] = -(auVar1[4] == (char)iVar7);
      auVar24[5] = -(auVar1[5] == (char)((uint)iVar7 >> 8));
      auVar24[6] = -(auVar1[6] == (char)((uint)iVar7 >> 0x10));
      auVar24[7] = -(auVar1[7] == (char)((uint)iVar7 >> 0x18));
      auVar24[8] = -(auVar1[8] == (char)iVar8);
      auVar24[9] = -(auVar1[9] == (char)((uint)iVar8 >> 8));
      auVar24[10] = -(auVar1[10] == (char)((uint)iVar8 >> 0x10));
      auVar24[0xb] = -(auVar1[0xb] == (char)((uint)iVar8 >> 0x18));
      auVar24[0xc] = -(auVar1[0xc] == (char)iVar9);
      auVar24[0xd] = -(auVar1[0xd] == (char)((uint)iVar9 >> 8));
      auVar24[0xe] = -(auVar1[0xe] == (char)((uint)iVar9 >> 0x10));
      auVar24[0xf] = -(auVar1[0xf] == (char)((uint)iVar9 >> 0x18));
      uVar16 = DAT_140699958;
      if ((((((((((((((((SUB161(auVar24 >> 7,0) & 1) != 0 || (SUB161(auVar24 >> 0xf,0) & 1) != 0) ||
                      (SUB161(auVar24 >> 0x17,0) & 1) != 0) || (SUB161(auVar24 >> 0x1f,0) & 1) != 0)
                    || (SUB161(auVar24 >> 0x27,0) & 1) != 0) || (SUB161(auVar24 >> 0x2f,0) & 1) != 0
                   ) || (SUB161(auVar24 >> 0x37,0) & 1) != 0) ||
                 (SUB161(auVar24 >> 0x3f,0) & 1) != 0) || (SUB161(auVar24 >> 0x47,0) & 1) != 0) ||
               (SUB161(auVar24 >> 0x4f,0) & 1) != 0) || (SUB161(auVar24 >> 0x57,0) & 1) != 0) ||
             (SUB161(auVar24 >> 0x5f,0) & 1) != 0) || (SUB161(auVar24 >> 0x67,0) & 1) != 0) ||
           (SUB161(auVar24 >> 0x6f,0) & 1) != 0) || (SUB161(auVar24 >> 0x77,0) & 1) != 0) ||
          auVar24[0xf] < '\0') break;
      uVar13 = uVar13 + lVar17 + 0x10;
      lVar17 = lVar17 + 0x10;
    }
  }
  uVar15 = (undefined4)uVar16;
  if (((bVar11 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
     (cVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar12 == '\0'))
  {
    DAT_140699949 = '\x01';
  }
  cVar12 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar12 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    LOCK();
    bVar21 = BLOCKED == '\0';
    if (bVar21) {
      BLOCKED = '\x01';
    }
    UNLOCK();
joined_r0x000140028aee:
    if (!bVar21) goto LAB_140028af4;
LAB_140028985:
    if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) == 0) goto LAB_140028991;
LAB_140028b0c:
    bVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar11 = bVar11 ^ 1;
  }
  else {
    LOCK();
    bVar21 = BLOCKED == '\0';
    if (bVar21) {
      BLOCKED = '\x01';
    }
    UNLOCK();
    if (bVar21) goto LAB_140028985;
LAB_140028af4:
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&BLOCKED);
    if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0) goto LAB_140028b0c;
LAB_140028991:
    bVar11 = 0;
  }
  if (DAT_140699771 == '\0') {
    uVar14 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    uVar14 = <std[3bf9d48a0c3997f0]::time::Instant_as_core[505b25137b8ba7f]::ops::arith::Add<core[505b25137b8ba7f]::time::Duration>>
             ::add(uVar14);
    lVar17 = DAT_140699788;
    if (DAT_140699788 == DAT_140699778) {
      <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::vec::Vec<[u8;12usize]>>>::
      grow_one(&DAT_140699778);
    }
    lVar20 = DAT_140699780;
    *(longlong *)(DAT_140699780 + lVar17 * 0x18) = param_1;
    *(undefined8 *)(lVar20 + 8 + lVar17 * 0x18) = uVar14;
    *(undefined4 *)(lVar20 + 0x10 + lVar17 * 0x18) = uVar15;
    DAT_140699788 = lVar17 + 1;
    if (((bVar11 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
       (cVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar12 == '\0')
       ) {
      DAT_140699771 = '\x01';
    }
    cVar12 = BLOCKED;
    LOCK();
    BLOCKED = 0;
    UNLOCK();
    if (cVar12 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&BLOCKED);
    }
    return;
  }
  local_d0 = &BLOCKED;
  local_c8._1_3_ = (undefined3)((uint)local_c8 >> 8);
  local_c8 = CONCAT31(local_c8._1_3_,bVar11);
  core[505b25137b8ba7f]::result::unwrap_failed
            ("called `Result::unwrap()` on an `Err` value",0x2b,&local_d0,
             &
             PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1050
             ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2848);
LAB_140028bc5:
                    /* WARNING: Does not return */
  pcVar3 = (code *)invalidInstructionException();
  (*pcVar3)();
}

