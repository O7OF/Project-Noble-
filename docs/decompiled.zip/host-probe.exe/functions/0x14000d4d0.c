// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::dedicated::start_roster_log::{closure#0}
// address: 0x14000d4d0
// body: available
// range: 0x14000d4d0-0x14000d553 inclusive
// range: 0x14000d560-0x14000d58b inclusive
// range: 0x14000d590-0x14000d5d0 inclusive
// range: 0x14000d5e0-0x14000d69c inclusive
// range: 0x14000d6b0-0x14000d6c2 inclusive
// range: 0x14000d6d0-0x14000d6f7 inclusive
// range: 0x14000d700-0x14000d732 inclusive
// range: 0x14000d740-0x14000d7fc inclusive
// range: 0x14000d810-0x14000d81a inclusive
// range: 0x14000d820-0x14000d83f inclusive
// range: 0x14000d850-0x14000d87d inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000d65e to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000d698 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000d7be to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000d7f8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000d83b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000d879 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::dedicated::start_roster_log::{closure#0} */

void __rustcall host_probe[b94139f9089eb1d8]::dedicated::start_roster_log::_closure_0_(void)

{
  longlong lVar1;
  undefined8 ***pppuVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  int iVar5;
  undefined8 *puVar6;
  void *pvVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 *puVar10;
  undefined8 ****ppppuVar11;
  size_t sVar12;
  undefined8 *local_b8;
  undefined8 ***local_a8;
  longlong *local_a0;
  undefined8 *local_98;
  undefined8 ***local_90;
  code *local_88;
  longlong local_80;
  undefined8 local_78;
  longlong *local_68;
  longlong *local_60;
  longlong local_58;
  undefined8 local_50;
  undefined8 local_48;
  
  plVar8 = (longlong *)0x0;
  puVar4 = (undefined8 *)0x8;
  ppppuVar11 = (undefined8 ****)0x0;
  do {
    puVar10 = puVar4;
    local_60 = plVar8;
    do {
      std[3bf9d48a0c3997f0]::thread::functions::sleep(2,0);
      roster(&local_a0);
      pppuVar2 = local_90;
      puVar4 = local_98;
    } while (local_a0 == (longlong *)0xffffffffffffffff);
    local_68 = local_a0;
    lVar1 = (longlong)local_90 * 0x18;
    local_b8 = local_98;
    if ((undefined8 ****)local_90 != (undefined8 ****)0x0) {
      do {
        if (ppppuVar11 != (undefined8 ****)0x0) {
          do {
            pvVar7 = (void *)local_b8[1];
            sVar12 = local_b8[2];
            local_b8 = local_b8 + 3;
            lVar9 = 0;
            while ((*(size_t *)((longlong)puVar10 + lVar9 + 0x10) != sVar12 ||
                   (iVar5 = memcmp(*(void **)((longlong)puVar10 + lVar9 + 8),pvVar7,sVar12),
                   iVar5 != 0))) {
              lVar9 = lVar9 + 0x18;
              if ((longlong)ppppuVar11 * 0x18 == lVar9) goto LAB_14000d5f1;
            }
          } while (local_b8 != puVar4 + (longlong)pppuVar2 * 3);
          break;
        }
        pvVar7 = (void *)local_b8[1];
        sVar12 = local_b8[2];
        local_b8 = local_b8 + 3;
LAB_14000d5f1:
        reach_directory[4b72b9694f6c3c08]::logmask::mask_untrusted(&local_80,pvVar7,sVar12);
        local_a8 = pppuVar2;
        local_98 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                    ::fmt;
        local_90 = &local_a8;
        local_88 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_a0 = &local_80;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a0a1b,&local_a0);
        uVar3 = local_50;
        lVar9 = local_58;
        if (local_80 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(local_78,local_80,1);
          return;
        }
        host::log(local_50);
        if (lVar9 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar3,lVar9,1);
          return;
        }
      } while (local_b8 != puVar4 + (longlong)pppuVar2 * 3);
    }
    if (ppppuVar11 != (undefined8 ****)0x0) {
      local_b8 = puVar10;
      do {
        if ((undefined8 ****)pppuVar2 != (undefined8 ****)0x0) {
          do {
            pvVar7 = (void *)local_b8[1];
            sVar12 = local_b8[2];
            local_b8 = local_b8 + 3;
            lVar9 = 0;
            while ((*(size_t *)((longlong)puVar4 + lVar9 + 0x10) != sVar12 ||
                   (iVar5 = memcmp(*(void **)((longlong)puVar4 + lVar9 + 8),pvVar7,sVar12),
                   iVar5 != 0))) {
              lVar9 = lVar9 + 0x18;
              if (lVar1 == lVar9) goto LAB_14000d751;
            }
          } while (local_b8 != puVar10 + (longlong)ppppuVar11 * 3);
          break;
        }
        pvVar7 = (void *)local_b8[1];
        sVar12 = local_b8[2];
        local_b8 = local_b8 + 3;
LAB_14000d751:
        reach_directory[4b72b9694f6c3c08]::logmask::mask_untrusted(&local_80,pvVar7,sVar12);
        local_a8 = pppuVar2;
        local_98 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                    ::fmt;
        local_90 = &local_a8;
        local_88 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_a0 = &local_80;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a09f3,&local_a0);
        uVar3 = local_50;
        lVar9 = local_58;
        if (local_80 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(local_78,local_80,1);
          return;
        }
        host::log(local_50,local_48);
        if (lVar9 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar3,lVar9,1);
          return;
        }
      } while (local_b8 != puVar10 + (longlong)ppppuVar11 * 3);
      puVar6 = puVar10 + 1;
      do {
        if (puVar6[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar6,puVar6[-1],1);
          return;
        }
        puVar6 = puVar6 + 3;
        ppppuVar11 = (undefined8 ****)((longlong)ppppuVar11 + -1);
      } while (ppppuVar11 != (undefined8 ****)0x0);
    }
    plVar8 = local_68;
    ppppuVar11 = (undefined8 ****)pppuVar2;
    if (local_60 != (longlong *)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar10,(longlong)local_60 * 0x18,8);
      return;
    }
  } while( true );
}

