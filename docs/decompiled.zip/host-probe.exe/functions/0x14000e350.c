// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::keep_general
// address: 0x14000e350
// body: available
// range: 0x14000e350-0x14000e38d inclusive
// range: 0x14000e390-0x14000e4f7 inclusive
// range: 0x14000e500-0x14000e5c7 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::keep_general */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::keep_general
          (longlong param_1,longlong param_2,longlong param_3,undefined8 param_4,undefined4 param_5)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong lVar11;
  ulonglong uVar12;
  char local_128;
  undefined4 uStack_127;
  undefined4 uStack_123;
  undefined4 uStack_11f;
  undefined4 uStack_11b;
  undefined4 uStack_117;
  undefined4 uStack_113;
  undefined4 uStack_10f;
  undefined4 uStack_10b;
  undefined4 local_107;
  undefined4 uStack_103;
  undefined4 uStack_ff;
  undefined4 uStack_fb;
  undefined4 local_f7;
  undefined4 uStack_f3;
  undefined4 uStack_ef;
  undefined4 uStack_eb;
  undefined3 local_e7;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined1 uStack_d8;
  undefined7 uStack_d7;
  undefined1 uStack_d0;
  undefined7 uStack_cf;
  undefined1 local_c8;
  undefined7 uStack_c7;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  char local_a8;
  undefined4 local_a7;
  undefined4 uStack_a3;
  undefined4 uStack_9f;
  undefined4 uStack_9b;
  undefined4 local_97;
  undefined4 uStack_93;
  undefined4 uStack_8f;
  undefined4 uStack_8b;
  undefined4 local_87;
  undefined4 uStack_83;
  undefined4 uStack_7f;
  undefined4 uStack_7b;
  undefined4 local_77;
  undefined4 uStack_73;
  undefined4 uStack_6f;
  undefined4 uStack_6b;
  undefined8 local_67;
  undefined8 uStack_5f;
  undefined8 uStack_57;
  undefined7 uStack_4f;
  undefined1 local_48;
  undefined7 uStack_47;
  undefined8 uStack_40;
  
  if (param_3 != 0) {
    lVar11 = 0;
    do {
      reach_directory[4b72b9694f6c3c08]::chat::decode
                (&local_a8,*(undefined8 *)(param_2 + 0x10 + lVar11),
                 *(undefined8 *)(param_2 + 0x18 + lVar11));
      if (local_a8 != -1) {
        if ((local_a8 == '\x01') && ((local_a7._1_1_ - 3U & 0xfd) == 0)) {
          uStack_c7 = uStack_47;
          uStack_c0 = uStack_40;
          uStack_d7 = (undefined7)uStack_57;
          uStack_d0 = (undefined1)((ulonglong)uStack_57 >> 0x38);
          uStack_cf = uStack_4f;
          local_c8 = local_48;
          local_e7 = (undefined3)local_67;
          uStack_e4 = (undefined4)((ulonglong)local_67 >> 0x18);
          uStack_e0._0_1_ = (undefined1)((ulonglong)local_67 >> 0x38);
          uStack_e0._1_3_ = (undefined3)uStack_5f;
          uStack_dc = (undefined4)((ulonglong)uStack_5f >> 0x18);
          uStack_d8 = (undefined1)((ulonglong)uStack_5f >> 0x38);
          local_f7 = local_77;
          uStack_f3 = uStack_73;
          uStack_ef = uStack_6f;
          uStack_eb = uStack_6b;
          local_107 = local_87;
          uStack_103 = uStack_83;
          uStack_ff = uStack_7f;
          uStack_fb = uStack_7b;
          uStack_117 = local_97;
          uStack_113 = uStack_93;
          uStack_10f = uStack_8f;
          uStack_10b = uStack_8b;
          uStack_127 = local_a7;
          uStack_123 = uStack_a3;
          uStack_11f = uStack_9f;
          uStack_11b = uStack_9b;
          local_128 = local_a8;
          uStack_b0 = CONCAT44(uStack_b0._4_4_,param_5);
          uVar10 = *(ulonglong *)(param_1 + 0x18);
          uVar8 = *(ulonglong *)(param_1 + 0x30);
          local_b8 = param_4;
          if (uVar8 == uVar10) {
            <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>>
            ::grow(param_1 + 0x18);
            uVar10 = *(ulonglong *)(param_1 + 0x18);
            uVar8 = *(ulonglong *)(param_1 + 0x30);
          }
          *(ulonglong *)(param_1 + 0x30) = uVar8 + 1;
          uVar8 = uVar8 + *(longlong *)(param_1 + 0x28);
          uVar12 = 0;
          if (uVar10 <= uVar8) {
            uVar12 = uVar10;
          }
          lVar11 = *(longlong *)(param_1 + 0x20);
          lVar9 = (uVar8 - uVar12) * 0x80;
          puVar1 = (undefined8 *)(lVar11 + 0x70 + lVar9);
          *puVar1 = local_b8;
          puVar1[1] = uStack_b0;
          puVar1 = (undefined8 *)(lVar11 + 0x60 + lVar9);
          *puVar1 = CONCAT71(uStack_c7,local_c8);
          puVar1[1] = uStack_c0;
          puVar1 = (undefined8 *)(lVar11 + 0x50 + lVar9);
          *puVar1 = CONCAT71(uStack_d7,uStack_d8);
          puVar1[1] = CONCAT71(uStack_cf,uStack_d0);
          puVar1 = (undefined8 *)(lVar11 + 0x40 + lVar9);
          *puVar1 = CONCAT44(uStack_e4,CONCAT31(local_e7,uStack_eb._3_1_));
          puVar1[1] = CONCAT44(uStack_dc,uStack_e0);
          puVar1 = (undefined8 *)(lVar11 + 0x30 + lVar9);
          *puVar1 = CONCAT35((undefined3)uStack_f3,CONCAT41(local_f7,uStack_fb._3_1_));
          puVar1[1] = CONCAT35((undefined3)uStack_eb,CONCAT41(uStack_ef,uStack_f3._3_1_));
          puVar1 = (undefined8 *)(lVar11 + 0x20 + lVar9);
          *puVar1 = CONCAT35((undefined3)uStack_103,CONCAT41(local_107,uStack_10b._3_1_));
          puVar1[1] = CONCAT35((undefined3)uStack_fb,CONCAT41(uStack_ff,uStack_103._3_1_));
          puVar1 = (undefined8 *)(lVar11 + 0x10 + lVar9);
          *puVar1 = CONCAT35((undefined3)uStack_113,CONCAT41(uStack_117,uStack_11b._3_1_));
          puVar1[1] = CONCAT35((undefined3)uStack_10b,CONCAT41(uStack_10f,uStack_113._3_1_));
          *(undefined8 *)(lVar11 + lVar9) =
               CONCAT35((undefined3)uStack_123,CONCAT41(uStack_127,local_128));
          ((undefined8 *)(lVar11 + lVar9))[1] =
               CONCAT35((undefined3)uStack_11b,CONCAT41(uStack_11f,uStack_123._3_1_));
          uVar10 = *(ulonglong *)(param_1 + 0x30);
          if (uVar10 < 0x33) {
            return;
          }
          do {
            lVar11 = *(longlong *)(param_1 + 0x28);
            lVar9 = *(longlong *)(param_1 + 0x20);
            uVar8 = *(ulonglong *)(param_1 + 0x18);
            if (lVar11 + 1U < *(ulonglong *)(param_1 + 0x18)) {
              uVar8 = 0;
            }
            *(ulonglong *)(param_1 + 0x28) = (lVar11 - uVar8) + 1;
            uVar10 = uVar10 - 1;
            *(ulonglong *)(param_1 + 0x30) = uVar10;
            lVar11 = lVar11 * 0x80;
            puVar1 = (undefined8 *)(lVar9 + 0x70 + lVar11);
            local_b8 = *puVar1;
            uStack_b0 = puVar1[1];
            uVar6 = *(undefined8 *)(lVar9 + lVar11);
            uVar7 = ((undefined8 *)(lVar9 + lVar11))[1];
            puVar2 = (undefined4 *)(lVar9 + 0x10 + lVar11);
            puVar3 = (undefined4 *)(lVar9 + 0x20 + lVar11);
            puVar4 = (undefined4 *)(lVar9 + 0x30 + lVar11);
            local_128 = (char)uVar6;
            uStack_127 = (undefined4)((ulonglong)uVar6 >> 8);
            uStack_123._0_3_ = (undefined3)((ulonglong)uVar6 >> 0x28);
            uStack_123._3_1_ = (undefined1)uVar7;
            uStack_11f = (undefined4)((ulonglong)uVar7 >> 8);
            uStack_11b._0_3_ = (undefined3)((ulonglong)uVar7 >> 0x28);
            puVar1 = (undefined8 *)(lVar9 + 0x60 + lVar11);
            uVar6 = *puVar1;
            uStack_c0 = puVar1[1];
            local_c8 = (undefined1)uVar6;
            uStack_c7 = (undefined7)((ulonglong)uVar6 >> 8);
            puVar1 = (undefined8 *)(lVar9 + 0x50 + lVar11);
            uVar6 = *puVar1;
            uVar7 = puVar1[1];
            uStack_d8 = (undefined1)uVar6;
            uStack_d7 = (undefined7)((ulonglong)uVar6 >> 8);
            uStack_d0 = (undefined1)uVar7;
            uStack_cf = (undefined7)((ulonglong)uVar7 >> 8);
            puVar5 = (undefined4 *)(lVar9 + 0x40 + lVar11);
            uStack_e4 = puVar5[1];
            uStack_e0 = puVar5[2];
            uStack_dc = puVar5[3];
            local_e7 = (undefined3)((uint)*puVar5 >> 8);
            local_f7._3_1_ = (undefined1)puVar4[1];
            local_f7 = CONCAT13(local_f7._3_1_,(int3)((uint)*puVar4 >> 8));
            uStack_f3._3_1_ = (undefined1)puVar4[2];
            uStack_f3 = CONCAT13(uStack_f3._3_1_,(int3)((uint)puVar4[1] >> 8));
            uStack_ef._3_1_ = (undefined1)puVar4[3];
            uStack_ef = CONCAT13(uStack_ef._3_1_,(int3)((uint)puVar4[2] >> 8));
            uStack_eb._0_3_ = (undefined3)((uint)puVar4[3] >> 8);
            uStack_eb = CONCAT13((char)*puVar5,(undefined3)uStack_eb);
            local_107._3_1_ = (undefined1)puVar3[1];
            local_107 = CONCAT13(local_107._3_1_,(int3)((uint)*puVar3 >> 8));
            uStack_103._3_1_ = (undefined1)puVar3[2];
            uStack_103 = CONCAT13(uStack_103._3_1_,(int3)((uint)puVar3[1] >> 8));
            uStack_ff._3_1_ = (undefined1)puVar3[3];
            uStack_ff = CONCAT13(uStack_ff._3_1_,(int3)((uint)puVar3[2] >> 8));
            uStack_fb._0_3_ = (undefined3)((uint)puVar3[3] >> 8);
            uStack_fb = CONCAT13((char)*puVar4,(undefined3)uStack_fb);
            uStack_11b._3_1_ = (undefined1)*puVar2;
            uStack_117._3_1_ = (undefined1)puVar2[1];
            uStack_117 = CONCAT13(uStack_117._3_1_,(int3)((uint)*puVar2 >> 8));
            uStack_113._3_1_ = (undefined1)puVar2[2];
            uStack_113 = CONCAT13(uStack_113._3_1_,(int3)((uint)puVar2[1] >> 8));
            uStack_10f._3_1_ = (undefined1)puVar2[3];
            uStack_10f = CONCAT13(uStack_10f._3_1_,(int3)((uint)puVar2[2] >> 8));
            uStack_10b._0_3_ = (undefined3)((uint)puVar2[3] >> 8);
            uStack_10b = CONCAT13((char)*puVar3,(undefined3)uStack_10b);
            if ((int)uStack_b0 != -1) {
              core[505b25137b8ba7f]::ptr::drop_glue::
              <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(&local_128);
              uVar10 = *(ulonglong *)(param_1 + 0x30);
            }
          } while (0x32 < uVar10);
          return;
        }
        core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                  (&local_a8);
      }
      lVar11 = lVar11 + 0x20;
    } while (param_3 << 5 != lVar11);
  }
  return;
}

