// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<&host_probe[b94139f9089eb1d8]::vote::Row>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&host_probe[b94139f9089eb1d8]::vote::Row,core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<host_probe[b94139f9089eb1d8]::vote::Row>,<host_probe[b94139f9089eb1d8]::vote::Vote>::counted::{closure#0}>>>::from_iter
// address: 0x14004fa10
// body: available
// range: 0x14004fa10-0x14004fa39 inclusive
// range: 0x14004fa40-0x14004fad4 inclusive
// range: 0x14004fae0-0x14004fafa inclusive
// range: 0x14004fb00-0x14004fb92 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<&host_probe[b94139f9089eb1d8]::vote::Row> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&host_probe[b94139f9089eb1d8]::vote::Row,
   core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<host_probe[b94139f9089eb1d8]::vote::Row>,
   <host_probe[b94139f9089eb1d8]::vote::Vote>::counted::{closure#0}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<&host_probe[b94139f9089eb1d8]::vote::Row>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&host_probe[b94139f9089eb1d8]::vote::Row,core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<host_probe[b94139f9089eb1d8]::vote::Row>,<host_probe[b94139f9089eb1d8]::vote::Vote>::counted::{closure#0}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  int *piVar2;
  code *pcVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  
  lVar1 = param_2[1];
  if (*param_2 != lVar1) {
    piVar2 = (int *)param_2[2];
    lVar4 = *param_2;
    do {
      lVar6 = lVar4 + 0x48;
      if ((*(char *)(lVar4 + 0x40) == '\0') &&
         (((*(longlong *)(lVar4 + 0x10) == 0 || (*piVar2 != 1)) ||
          (*(longlong *)(lVar4 + 0x18) != *(longlong *)(piVar2 + 2))))) {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        local_40 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x20,8);
        if (local_40 == (longlong *)0x0) {
          alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x20);
                    /* WARNING: Does not return */
          pcVar3 = (code *)invalidInstructionException();
          (*pcVar3)();
        }
        *local_40 = lVar4;
        local_48 = 4;
        local_38 = 1;
        if (lVar6 != lVar1) {
          plVar5 = local_40;
          do {
            lVar4 = local_38;
            lVar7 = lVar6 + 0x48;
            if ((*(char *)(lVar6 + 0x40) == '\0') &&
               (((*(longlong *)(lVar6 + 0x10) == 0 || (*piVar2 != 1)) ||
                (*(longlong *)(lVar6 + 0x18) != *(longlong *)(piVar2 + 2))))) {
              if (local_38 == local_48) {
                <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
                <alloc[246c2e7857c81348]::alloc::Global>(&local_48,local_38,1,8,8);
                plVar5 = local_40;
              }
              plVar5[lVar4] = lVar6;
              local_38 = lVar4 + 1;
            }
            lVar6 = lVar7;
          } while (lVar7 != lVar1);
        }
        param_1[2] = local_38;
        *param_1 = local_48;
        param_1[1] = (longlong)local_40;
        return param_1;
      }
      lVar4 = lVar6;
    } while (lVar6 != lVar1);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

