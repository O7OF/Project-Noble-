// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,7usize>>
// address: 0x140043570
// body: available
// range: 0x140043570-0x1400436a0 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,
   7usize>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::
<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,7usize>>
          (longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong local_e0;
  longlong local_d8;
  undefined8 local_d0 [21];
  
  lVar7 = param_1[2];
  if ((ulonglong)(*param_1 - lVar7) < (ulonglong)(param_2[1] - *param_2)) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar7,param_2[1] - *param_2,8,0x18);
    lVar7 = param_1[2];
  }
  lVar4 = param_1[1];
  memcpy(&local_e0,param_2,0xb8);
  if (local_d8 != local_e0) {
    lVar6 = local_e0;
    if (((int)local_d8 - (int)local_e0 & 1U) != 0) {
      *(undefined8 *)(lVar4 + 0x10 + lVar7 * 0x18) = local_d0[local_e0 * 3 + 2];
      uVar5 = local_d0[local_e0 * 3 + 1];
      puVar2 = (undefined8 *)(lVar4 + lVar7 * 0x18);
      *puVar2 = local_d0[local_e0 * 3];
      puVar2[1] = uVar5;
      lVar7 = lVar7 + 1;
      lVar6 = local_e0 + 1;
    }
    if (local_d8 != local_e0 + 1) {
      lVar4 = lVar4 + lVar7 * 0x18;
      lVar1 = lVar6 * 0x18;
      lVar8 = 0;
      do {
        *(undefined8 *)(lVar4 + 0x10 + lVar8) =
             *(undefined8 *)((longlong)local_d0 + lVar8 + lVar1 + 0x10);
        puVar2 = (undefined8 *)((longlong)local_d0 + lVar8 + lVar1);
        uVar5 = puVar2[1];
        *(undefined8 *)(lVar4 + lVar8) = *puVar2;
        ((undefined8 *)(lVar4 + lVar8))[1] = uVar5;
        lVar6 = lVar6 + 2;
        puVar2 = (undefined8 *)((longlong)local_d0 + lVar8 + lVar1 + 0x18);
        uVar5 = puVar2[1];
        puVar3 = (undefined8 *)(lVar4 + 0x18 + lVar8);
        *puVar3 = *puVar2;
        puVar3[1] = uVar5;
        *(undefined8 *)(lVar4 + 0x28 + lVar8) =
             *(undefined8 *)((longlong)local_d0 + lVar8 + lVar1 + 0x28);
        lVar7 = lVar7 + 2;
        lVar8 = lVar8 + 0x30;
      } while (local_d8 != lVar6);
    }
  }
  param_1[2] = lVar7;
  return;
}

