// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::queue_engine
// address: 0x1400244b0
// body: available
// range: 0x1400244b0-0x140024779 inclusive
// range: 0x14002477e-0x1400247ae inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140024775 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::queue_engine */

void __rustcall
host_probe[b94139f9089eb1d8]::net::queue_engine
          (longlong param_1,undefined8 param_2,ushort *param_3,ulonglong param_4)

{
  ulonglong uVar1;
  code *pcVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong *puVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  void *_Dst;
  ulonglong uVar13;
  longlong *plVar14;
  
  if (param_4 < 2) {
    puVar9 = (ulonglong *)(param_1 + 0x20);
    if (param_4 != 0) goto LAB_140024522;
    _Dst = (void *)0x1;
    uVar4 = *puVar9;
    uVar11 = *(ulonglong *)(param_1 + 0x38);
    if (uVar11 == uVar4) goto LAB_14002455a;
  }
  else {
    uVar4 = (ulonglong)*param_3;
    puVar9 = (ulonglong *)
             (param_1 +
             (ulonglong)((param_4 < uVar4 + 2 || 0x600 < uVar4) || 0x200 < (param_4 - uVar4) - 2) *
             0x20);
LAB_140024522:
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    _Dst = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(param_4,1);
    if (_Dst == (void *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,param_4);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    memcpy(_Dst,param_3,param_4);
    uVar4 = *puVar9;
    uVar11 = puVar9[3];
    if (uVar11 == uVar4) {
LAB_14002455a:
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>
      ::grow(puVar9);
      uVar4 = *puVar9;
      uVar11 = puVar9[3];
    }
  }
  puVar9[3] = uVar11 + 1;
  uVar7 = 0;
  if (uVar4 <= uVar11 + puVar9[2]) {
    uVar7 = uVar4;
  }
  uVar4 = puVar9[1];
  lVar3 = ((uVar11 + puVar9[2]) - uVar7) * 0x20;
  *(undefined8 *)(uVar4 + lVar3) = param_2;
  *(ulonglong *)(uVar4 + 8 + lVar3) = param_4;
  *(void **)(uVar4 + 0x10 + lVar3) = _Dst;
  *(ulonglong *)(uVar4 + 0x18 + lVar3) = param_4;
  uVar4 = puVar9[3];
  if (uVar4 < 0x21) {
    return;
  }
  uVar11 = puVar9[2];
  uVar7 = *puVar9;
  uVar10 = 0;
  uVar8 = uVar7;
  if (uVar11 < uVar7) {
    uVar8 = uVar10;
  }
  lVar3 = uVar11 - uVar8;
  uVar13 = uVar7 - lVar3;
  uVar6 = (uVar4 - uVar13) * 0x20;
  if (uVar4 <= uVar13) {
    uVar6 = uVar10;
  }
  uVar1 = puVar9[1];
  uVar12 = lVar3 + uVar4;
  if (uVar13 < uVar4) {
    uVar12 = uVar7;
  }
  uVar12 = uVar12 - lVar3;
  if (uVar12 != 0) {
    if (uVar12 < 4) {
      uVar7 = 0;
      uVar10 = 0;
    }
    else {
      plVar14 = (longlong *)(uVar11 * 0x20 + uVar8 * -0x20 + uVar1 + 0x78);
      uVar7 = 0;
      uVar10 = 0;
      do {
        uVar10 = uVar10 + plVar14[-0xc] + plVar14[-8] + plVar14[-4] + *plVar14;
        uVar7 = uVar7 + 4;
        plVar14 = plVar14 + 0x10;
      } while ((uVar12 & 0xfffffffffffffffc) != uVar7);
      if ((uVar12 & 3) == 0) goto LAB_14002468d;
    }
    uVar13 = 0;
    do {
      uVar10 = uVar10 + *(longlong *)
                         (uVar11 * 0x20 + uVar7 * 0x20 + uVar8 * -0x20 + uVar1 + 0x18 + uVar13);
      uVar13 = uVar13 + 0x20;
    } while (((uint)uVar12 & 3) << 5 != uVar13);
  }
LAB_14002468d:
  if (uVar6 != 0) {
    uVar11 = uVar6 >> 5;
    if (uVar6 < 0x80) {
      uVar7 = 0;
    }
    else {
      plVar14 = (longlong *)(uVar1 + 0x78);
      uVar7 = 0;
      do {
        uVar10 = uVar10 + plVar14[-0xc] + plVar14[-8] + plVar14[-4] + *plVar14;
        uVar7 = uVar7 + 4;
        plVar14 = plVar14 + 0x10;
      } while ((uVar11 & 0xfffffffffffffffc) != uVar7);
      if ((uVar11 & 3) == 0) goto joined_r0x000140024713;
    }
    uVar8 = 0;
    do {
      uVar10 = uVar10 + *(longlong *)(uVar1 + uVar7 * 0x20 + 0x18 + uVar8);
      uVar8 = uVar8 + 0x20;
    } while (((uint)uVar11 & 3) << 5 != uVar8);
  }
joined_r0x000140024713:
  while( true ) {
    if (((uVar4 < 0x401) && (uVar10 < 0x200001)) || (uVar4 == 0)) {
      return;
    }
    uVar11 = puVar9[2];
    uVar7 = puVar9[1];
    uVar8 = 0;
    if (*puVar9 <= uVar11 + 1) {
      uVar8 = *puVar9;
    }
    puVar9[2] = (uVar11 - uVar8) + 1;
    uVar4 = uVar4 - 1;
    puVar9[3] = uVar4;
    lVar5 = uVar11 * 0x20;
    lVar3 = *(longlong *)(uVar7 + 8 + lVar5);
    if (lVar3 == -1) break;
    uVar10 = uVar10 - *(longlong *)(uVar7 + lVar5 + 0x18);
    if (lVar3 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(*(undefined8 *)(uVar7 + 0x10 + lVar5),lVar3,1);
      return;
    }
  }
  return;
}

