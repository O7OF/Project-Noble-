// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String),std[3bf9d48a0c3997f0]::env::Vars>>::from_iter
// address: 0x140050400
// body: available
// range: 0x140050400-0x1400504b3 inclusive
// range: 0x1400504c0-0x14005059e inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,
   alloc[246c2e7857c81348]::string::String)> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(alloc[246c2e7857c81348]::string::String,
   alloc[246c2e7857c81348]::string::String), std[3bf9d48a0c3997f0]::env::Vars>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String),std[3bf9d48a0c3997f0]::env::Vars>>
::from_iter(longlong *param_1,undefined8 param_2,undefined8 param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong local_d0;
  longlong *plStack_c8;
  longlong local_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  longlong local_98;
  longlong lStack_90;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  
  local_b8 = param_2;
  uStack_b0 = param_3;
  <std[3bf9d48a0c3997f0]::env::Vars_as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::
  next(&local_98,&local_b8);
  if (local_98 == -1) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
    <std[3bf9d48a0c3997f0]::sys::env::windows::Env_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&local_b8);
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0xc0,8);
    if (plVar4 == (longlong *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(8,0xc0);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    *(undefined4 *)(plVar4 + 4) = local_78;
    *(undefined4 *)((longlong)plVar4 + 0x24) = uStack_74;
    *(undefined4 *)(plVar4 + 5) = uStack_70;
    *(undefined4 *)((longlong)plVar4 + 0x2c) = uStack_6c;
    *(undefined4 *)(plVar4 + 2) = local_88;
    *(undefined4 *)((longlong)plVar4 + 0x14) = uStack_84;
    *(undefined4 *)(plVar4 + 3) = uStack_80;
    *(undefined4 *)((longlong)plVar4 + 0x1c) = uStack_7c;
    *plVar4 = local_98;
    plVar4[1] = lStack_90;
    local_d0 = 4;
    local_c0 = 1;
    local_a8 = (undefined4)local_b8;
    uStack_a4 = local_b8._4_4_;
    uStack_a0 = (undefined4)uStack_b0;
    uStack_9c = uStack_b0._4_4_;
    lVar5 = 0;
    plStack_c8 = plVar4;
    while( true ) {
      lVar3 = local_c0;
      <std[3bf9d48a0c3997f0]::env::Vars_as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
      ::next(&local_68,&local_a8);
      if (CONCAT44(uStack_64,local_68) == -1) break;
      if (lVar3 == local_d0) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_d0,lVar3,1,8,0x30);
        plVar4 = plStack_c8;
      }
      puVar1 = (undefined4 *)(lVar5 + 0x50 + (longlong)plVar4);
      *puVar1 = local_48;
      puVar1[1] = uStack_44;
      puVar1[2] = uStack_40;
      puVar1[3] = uStack_3c;
      puVar1 = (undefined4 *)(lVar5 + 0x40 + (longlong)plVar4);
      *puVar1 = local_58;
      puVar1[1] = uStack_54;
      puVar1[2] = uStack_50;
      puVar1[3] = uStack_4c;
      puVar1 = (undefined4 *)(lVar5 + 0x30 + (longlong)plVar4);
      *puVar1 = local_68;
      puVar1[1] = uStack_64;
      puVar1[2] = uStack_60;
      puVar1[3] = uStack_5c;
      local_c0 = lVar3 + 1;
      lVar5 = lVar5 + 0x30;
    }
    <std[3bf9d48a0c3997f0]::sys::env::windows::Env_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&local_a8);
    param_1[2] = local_c0;
    *param_1 = local_d0;
    param_1[1] = (longlong)plStack_c8;
  }
  return param_1;
}

