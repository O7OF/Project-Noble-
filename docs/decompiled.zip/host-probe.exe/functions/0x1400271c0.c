// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::handle
// address: 0x1400271c0
// body: available
// range: 0x1400271c0-0x140027dce inclusive
// range: 0x140027dd4-0x1400281b8 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400272d6 to 0x140028df0 host_probe[b94139f9089eb1d8]::net::receive (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140027373 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400273a9 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400274f9 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140027513 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140027549 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140027c60 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140027dca to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140027ec3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain 
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::handle */

ulonglong __rustcall host_probe[b94139f9089eb1d8]::net::handle(longlong param_1,undefined8 *param_2)

{
  int3 *******pppppppiVar1;
  char *pcVar2;
  code *pcVar3;
  uint uVar4;
  uint uVar5;
  undefined *puVar6;
  int3 *******pppppppiVar7;
  int3 *******pppppppiVar8;
  undefined1 uVar9;
  char cVar10;
  byte bVar11;
  byte bVar12;
  ulonglong uVar13;
  undefined8 uVar14;
  ulonglong uVar15;
  int3 ******ppppppiVar16;
  undefined8 uVar17;
  undefined4 uVar18;
  int3 *******pppppppiVar19;
  int3 ******ppppppiVar20;
  int iVar21;
  undefined1 uVar22;
  int3 ******ppppppiVar23;
  longlong lVar24;
  uint uVar25;
  ushort uVar26;
  longlong lVar27;
  ulonglong uVar28;
  int3 *******pppppppiVar29;
  int3 *******pppppppiVar30;
  bool bVar31;
  bool bVar32;
  byte bVar33;
  undefined1 auVar34 [16];
  undefined1 auVar35 [16];
  undefined1 auVar36 [16];
  undefined1 auVar37 [16];
  undefined1 auVar38 [16];
  undefined1 auVar39 [16];
  undefined1 auVar40 [16];
  int3 ******local_178;
  int3 *******local_170;
  int3 *******local_168;
  code *pcStack_160;
  int3 *******local_158;
  int3 *******local_148;
  int3 *******pppppppiStack_140;
  int3 *******local_138;
  code *pcStack_130;
  int3 *******local_128;
  undefined8 *local_120;
  undefined8 uStack_118;
  undefined8 local_110;
  undefined8 uStack_108;
  int3 *******local_100;
  undefined1 local_f8;
  int3 *******local_e8;
  int3 *******local_e0;
  int iStack_d8;
  undefined4 uStack_d4;
  undefined4 local_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  longlong local_58;
  undefined8 local_50;
  undefined4 local_48;
  
  if (param_1 == 0x2b) {
    uVar13 = receive(*param_2,param_2[1],param_2[2]);
    return uVar13;
  }
  if (param_1 != 0x29) {
    return (ulonglong)(int3 ******)0x0;
  }
  local_170 = (int3 *******)*param_2;
  ppppppiVar16 = (int3 ******)param_2[1];
  ppppppiVar20 = (int3 ******)param_2[2];
  local_178 = ppppppiVar20;
  cVar10 = record(local_170,ppppppiVar20,0);
  if (cVar10 != '\0') {
    if (ppppppiVar16 == (int3 ******)0x0) {
LAB_1400272e2:
      local_168 = (int3 *******)0x0;
      pcStack_160 = (code *)0x1;
      local_158 = (int3 *******)0x0;
    }
    else {
      ppppppiVar23 = (int3 ******)0x18;
      if (ppppppiVar20 < (int3 ******)0x18) {
        ppppppiVar23 = ppppppiVar20;
      }
      if (ppppppiVar20 == (int3 ******)0x0) goto LAB_1400272e2;
      local_148 = (int3 *******)&local_168;
      pppppppiStack_140 = (int3 *******)<&u8_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_168 = (int3 *******)ppppppiVar16;
      alloc[246c2e7857c81348]::fmt::format::format_inner
                (&local_e0,&anon_1a1cfe3ac28698fadcb73c62956d839a_28_llvm_3977132774650517797,
                 &local_148);
      if (local_e0 == (int3 *******)0xffffffffffffffff) goto LAB_1400272e2;
      local_138 = (int3 *******)CONCAT44(uStack_cc,local_d0);
      pppppppiStack_140 = (int3 *******)CONCAT44(uStack_d4,iStack_d8);
      local_148 = local_e0;
      <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<u8>,host_probe[b94139f9089eb1d8]::aiwave::place_squad::{closure#1}::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
      ::fold::
      <(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<alloc[246c2e7857c81348]::string::String,<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::Extend<alloc[246c2e7857c81348]::string::String>>::extend<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<u8>,host_probe[b94139f9089eb1d8]::aiwave::place_squad::_closure_1_::_closure_0_>>::_closure_0_>::_closure_0_>
                ((longlong)ppppppiVar16 + 1,(longlong)ppppppiVar23 + (longlong)ppppppiVar16,
                 &local_148);
      local_158 = local_138;
      local_168 = local_148;
      pcStack_160 = (code *)pppppppiStack_140;
    }
    local_148 = (int3 *******)&local_170;
    pppppppiStack_140 = (int3 *******)<usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    local_138 = &local_178;
    pcStack_130 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_128 = (int3 *******)&local_168;
    local_120 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>::
                 fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_e0,&DAT_1406a2748,&local_148);
    pppppppiVar30 = local_e0;
    if (local_168 != (int3 *******)0x0) {
      uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(pcStack_160,local_168,1);
      return uVar13;
    }
    uVar14 = CONCAT44(uStack_d4,iStack_d8);
    host::log(uVar14,CONCAT44(uStack_cc,local_d0));
    ppppppiVar20 = local_178;
    if (pppppppiVar30 != (int3 *******)0x0) {
      uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar14,pppppppiVar30,1);
      return uVar13;
    }
  }
  if (((ppppppiVar16 != (int3 ******)0x0) && (ppppppiVar20 == (int3 ******)0xc)) &&
     (*(int3 *)ppppppiVar16 == 0x18008e)) {
    pppppppiStack_140 = (int3 *******)<&u8_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    local_168 = (int3 *******)ppppppiVar16;
    local_148 = (int3 *******)&local_168;
    alloc[246c2e7857c81348]::fmt::format::format_inner
              (&local_e0,&anon_1a1cfe3ac28698fadcb73c62956d839a_28_llvm_3977132774650517797,
               &local_148);
    if (local_e0 == (int3 *******)0xffffffffffffffff) {
      local_168 = (int3 *******)0x0;
      pcStack_160 = (code *)0x1;
      local_158 = (int3 *******)0x0;
    }
    else {
      local_138 = (int3 *******)CONCAT44(uStack_cc,local_d0);
      pppppppiStack_140 = (int3 *******)CONCAT44(uStack_d4,iStack_d8);
      local_148 = local_e0;
      <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<u8>,host_probe[b94139f9089eb1d8]::aiwave::place_squad::{closure#1}::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
      ::fold::
      <(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<alloc[246c2e7857c81348]::string::String,<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::Extend<alloc[246c2e7857c81348]::string::String>>::extend<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<u8>,host_probe[b94139f9089eb1d8]::aiwave::place_squad::_closure_1_::_closure_0_>>::_closure_0_>::_closure_0_>
                ((longlong)ppppppiVar16 + 1,(int3 *)((longlong)ppppppiVar16 + 0xc),&local_148);
      local_158 = local_138;
      local_168 = local_148;
      pcStack_160 = (code *)pppppppiStack_140;
    }
    host::reach_stack(&local_e0);
    local_148 = (int3 *******)&local_170;
    pppppppiStack_140 = (int3 *******)<usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    pcStack_130 = (code *)&<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                           ::fmt;
    local_120 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>::
                 fmt;
    local_138 = (int3 *******)&local_168;
    local_128 = (int3 *******)&local_e0;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a276e,&local_148);
    if (local_e0 != (int3 *******)0x0) {
      uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(CONCAT44(uStack_d4,iStack_d8),local_e0,1);
      return uVar13;
    }
    if (local_168 != (int3 *******)0x0) {
      uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(pcStack_160,local_168,1);
      return uVar13;
    }
    uVar18 = local_48;
    host::log(local_50);
    if (local_58 != 0) {
      uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_50,local_58,1);
      return uVar13;
    }
    if (((HOST_ID_0_llvm_14435704873730135342 != (int3 *******)0x0) &&
        (IS_HOST_0_llvm_14435704873730135342 == '\0')) &&
       (HOST_ID_0_llvm_14435704873730135342 == local_170)) {
      uVar14 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
      LOCK();
      bVar31 = HOST_CLOSED == '\0';
      if (bVar31) {
        HOST_CLOSED = '\x01';
      }
      UNLOCK();
      if (!bVar31) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&HOST_CLOSED);
      }
      puVar6 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar11 = 0;
      }
      else {
        bVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar11 = bVar11 ^ 1;
      }
      if (DAT_1406995c9 != '\0') {
        local_148 = (int3 *******)&HOST_CLOSED;
        pppppppiStack_140._1_7_ = (undefined7)((ulonglong)pppppppiStack_140 >> 8);
        pppppppiStack_140 = (int3 *******)CONCAT71(pppppppiStack_140._1_7_,bVar11);
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&local_148,
                   &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a27a0)
        ;
        goto LAB_140028126;
      }
      DAT_1406995d0 = uVar14;
      DAT_1406995d8 = uVar18;
      if (((bVar11 == 0) && ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) != 0)) &&
         (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
         cVar10 == '\0')) {
        DAT_1406995c9 = '\x01';
      }
      cVar10 = HOST_CLOSED;
      LOCK();
      HOST_CLOSED = '\0';
      UNLOCK();
      if (cVar10 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&HOST_CLOSED);
      }
    }
  }
  if (DAT_140699990 != 0) {
    return (ulonglong)local_178;
  }
  uVar13 = (ulonglong)local_148 >> 0x10;
  local_148 = (int3 *******)CONCAT62((int6)uVar13,2);
  cVar10 = is_blocked(local_170,&local_148);
  if (cVar10 != '\0') {
    return (ulonglong)local_178;
  }
  LOCK();
  bVar31 = DAT_140699948 == '\0';
  if (bVar31) {
    DAT_140699948 = '\x01';
  }
  UNLOCK();
  if (!bVar31) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
  }
  puVar6 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar11 = 0;
    pppppppiVar30 = HOST_ID_0_llvm_14435704873730135342;
  }
  else {
    bVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar11 = bVar11 ^ 1;
    pppppppiVar30 = HOST_ID_0_llvm_14435704873730135342;
  }
  HOST_ID_0_llvm_14435704873730135342 = pppppppiVar30;
  if (DAT_140699949 != '\0') {
    local_148 = (int3 *******)&DAT_140699948;
    pppppppiStack_140._1_7_ = (undefined7)((ulonglong)pppppppiStack_140 >> 8);
    pppppppiStack_140 = (int3 *******)CONCAT71(pppppppiStack_140._1_7_,bVar11);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_148,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a27b8);
    goto LAB_140028126;
  }
  bVar31 = IS_HOST_0_llvm_14435704873730135342 == '\0';
  LOCK();
  bVar32 = TRANSPORT == '\0';
  if (bVar32) {
    TRANSPORT = '\x01';
  }
  UNLOCK();
  if (!bVar32) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&TRANSPORT);
  }
  if ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) == 0) {
    bVar12 = 0;
    pppppppiVar29 = local_170;
  }
  else {
    bVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar12 = bVar12 ^ 1;
    pppppppiVar29 = local_170;
  }
  local_170 = pppppppiVar29;
  if (DAT_140699831 != '\0') {
    local_148 = (int3 *******)&TRANSPORT;
    pppppppiStack_140._1_7_ = (undefined7)((ulonglong)pppppppiStack_140 >> 8);
    pppppppiStack_140 = (int3 *******)CONCAT71(pppppppiStack_140._1_7_,bVar12);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_148,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a27d0);
    goto LAB_140028126;
  }
  local_e0 = pppppppiVar29;
  if (((DAT_140699860 & (pppppppiVar30 != (int3 *******)0x0 && bVar31)) == 0) ||
     (local_148 = pppppppiVar30, pppppppiVar29 == pppppppiVar30)) {
    iVar21 = -1;
    if (DAT_140699968 != 0) {
      uVar13 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
               ::hash_one::<&usize>(&DAT_140699970,&local_e0);
      bVar33 = (byte)(uVar13 >> 0x39);
      auVar34 = ZEXT216(CONCAT11(bVar33,bVar33));
      auVar34 = pshuflw(auVar34,auVar34,0);
      lVar24 = 0;
      while( true ) {
        uVar13 = uVar13 & DAT_140699958;
        pcVar2 = (char *)(DAT_140699950 + uVar13);
        auVar38[0] = -(*pcVar2 == auVar34[0]);
        auVar38[1] = -(pcVar2[1] == auVar34[1]);
        auVar38[2] = -(pcVar2[2] == auVar34[2]);
        auVar38[3] = -(pcVar2[3] == auVar34[3]);
        auVar38[4] = -(pcVar2[4] == auVar34[4]);
        auVar38[5] = -(pcVar2[5] == auVar34[5]);
        auVar38[6] = -(pcVar2[6] == auVar34[6]);
        auVar38[7] = -(pcVar2[7] == auVar34[7]);
        auVar38[8] = -(pcVar2[8] == auVar34[0]);
        auVar38[9] = -(pcVar2[9] == auVar34[1]);
        auVar38[10] = -(pcVar2[10] == auVar34[2]);
        auVar38[0xb] = -(pcVar2[0xb] == auVar34[3]);
        auVar38[0xc] = -(pcVar2[0xc] == auVar34[4]);
        auVar38[0xd] = -(pcVar2[0xd] == auVar34[5]);
        auVar38[0xe] = -(pcVar2[0xe] == auVar34[6]);
        auVar38[0xf] = -(pcVar2[0xf] == auVar34[7]);
        uVar26 = (ushort)(SUB161(auVar38 >> 7,0) & 1) | (ushort)(SUB161(auVar38 >> 0xf,0) & 1) << 1
                 | (ushort)(SUB161(auVar38 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar38 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar38 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar38 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar38 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar38 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar38 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar38 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar38 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar38 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar38 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar38 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar38 >> 0x77,0) & 1) << 0xe | (ushort)(auVar38[0xf] >> 7) << 0xf
        ;
        uVar25 = (uint)uVar26;
        while (uVar26 != 0) {
          uVar4 = 0;
          for (uVar5 = uVar25; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
            uVar4 = uVar4 + 1;
          }
          lVar27 = (uVar4 + uVar13 & DAT_140699958) * -0x50;
          if (pppppppiVar29 == *(int3 ********)(DAT_140699950 + -0x50 + lVar27)) {
            lVar27 = DAT_140699950 + lVar27;
            pppppppiVar29 = *(int3 ********)(lVar27 + -0x48);
            iVar21 = *(int *)(lVar27 + -0x40);
            uStack_64 = *(undefined8 *)(lVar27 + -8);
            uStack_68 = (undefined4)((ulonglong)*(undefined8 *)(lVar27 + -0x10) >> 0x20);
            local_78 = *(undefined8 *)(lVar27 + -0x1c);
            uStack_70 = (undefined4)*(undefined8 *)(lVar27 + -0x14);
            uStack_6c = (undefined4)((ulonglong)*(undefined8 *)(lVar27 + -0x14) >> 0x20);
            local_88 = *(undefined8 *)(lVar27 + -0x2c);
            uStack_80 = *(undefined8 *)(lVar27 + -0x24);
            local_98 = *(undefined8 *)(lVar27 + -0x3c);
            uStack_90 = *(undefined8 *)(lVar27 + -0x34);
            pppppppiVar30 = (int3 *******)0x0;
            goto LAB_1400278b5;
          }
          uVar26 = (ushort)(uVar25 - 1) & (ushort)uVar25;
          uVar25 = CONCAT22((short)(uVar25 - 1 >> 0x10),uVar26);
        }
        auVar35[0] = -(*pcVar2 == -1);
        auVar35[1] = -(pcVar2[1] == -1);
        auVar35[2] = -(pcVar2[2] == -1);
        auVar35[3] = -(pcVar2[3] == -1);
        auVar35[4] = -(pcVar2[4] == -1);
        auVar35[5] = -(pcVar2[5] == -1);
        auVar35[6] = -(pcVar2[6] == -1);
        auVar35[7] = -(pcVar2[7] == -1);
        auVar35[8] = -(pcVar2[8] == -1);
        auVar35[9] = -(pcVar2[9] == -1);
        auVar35[10] = -(pcVar2[10] == -1);
        auVar35[0xb] = -(pcVar2[0xb] == -1);
        auVar35[0xc] = -(pcVar2[0xc] == -1);
        auVar35[0xd] = -(pcVar2[0xd] == -1);
        auVar35[0xe] = -(pcVar2[0xe] == -1);
        auVar35[0xf] = -(pcVar2[0xf] == -1);
        if ((((((((((((((((SUB161(auVar35 >> 7,0) & 1) != 0 || (SUB161(auVar35 >> 0xf,0) & 1) != 0)
                        || (SUB161(auVar35 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar35 >> 0x1f,0) & 1) != 0) || (SUB161(auVar35 >> 0x27,0) & 1) != 0
                      ) || (SUB161(auVar35 >> 0x2f,0) & 1) != 0) ||
                    (SUB161(auVar35 >> 0x37,0) & 1) != 0) || (SUB161(auVar35 >> 0x3f,0) & 1) != 0)
                  || (SUB161(auVar35 >> 0x47,0) & 1) != 0) || (SUB161(auVar35 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar35 >> 0x57,0) & 1) != 0) || (SUB161(auVar35 >> 0x5f,0) & 1) != 0) ||
              (SUB161(auVar35 >> 0x67,0) & 1) != 0) || (SUB161(auVar35 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar35 >> 0x77,0) & 1) != 0) || auVar35[0xf] < '\0') break;
        uVar13 = uVar13 + lVar24 + 0x10;
        lVar24 = lVar24 + 0x10;
      }
    }
  }
  else {
    iVar21 = -1;
    if (DAT_140699968 != 0) {
      uVar13 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
               ::hash_one::<&usize>(&DAT_140699970,&local_148);
      bVar33 = (byte)(uVar13 >> 0x39);
      auVar34 = ZEXT216(CONCAT11(bVar33,bVar33));
      auVar34 = pshuflw(auVar34,auVar34,0);
      lVar24 = 0;
      while( true ) {
        uVar13 = uVar13 & DAT_140699958;
        pcVar2 = (char *)(DAT_140699950 + uVar13);
        auVar39[0] = -(*pcVar2 == auVar34[0]);
        auVar39[1] = -(pcVar2[1] == auVar34[1]);
        auVar39[2] = -(pcVar2[2] == auVar34[2]);
        auVar39[3] = -(pcVar2[3] == auVar34[3]);
        auVar39[4] = -(pcVar2[4] == auVar34[4]);
        auVar39[5] = -(pcVar2[5] == auVar34[5]);
        auVar39[6] = -(pcVar2[6] == auVar34[6]);
        auVar39[7] = -(pcVar2[7] == auVar34[7]);
        auVar39[8] = -(pcVar2[8] == auVar34[0]);
        auVar39[9] = -(pcVar2[9] == auVar34[1]);
        auVar39[10] = -(pcVar2[10] == auVar34[2]);
        auVar39[0xb] = -(pcVar2[0xb] == auVar34[3]);
        auVar39[0xc] = -(pcVar2[0xc] == auVar34[4]);
        auVar39[0xd] = -(pcVar2[0xd] == auVar34[5]);
        auVar39[0xe] = -(pcVar2[0xe] == auVar34[6]);
        auVar39[0xf] = -(pcVar2[0xf] == auVar34[7]);
        uVar26 = (ushort)(SUB161(auVar39 >> 7,0) & 1) | (ushort)(SUB161(auVar39 >> 0xf,0) & 1) << 1
                 | (ushort)(SUB161(auVar39 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar39 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar39 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar39 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar39 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar39 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar39 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar39 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar39 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar39 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar39 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar39 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar39 >> 0x77,0) & 1) << 0xe | (ushort)(auVar39[0xf] >> 7) << 0xf
        ;
        uVar25 = (uint)uVar26;
        while (uVar26 != 0) {
          uVar4 = 0;
          for (uVar5 = uVar25; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
            uVar4 = uVar4 + 1;
          }
          lVar27 = (uVar4 + uVar13 & DAT_140699958) * -0x50;
          if (pppppppiVar30 == *(int3 ********)(DAT_140699950 + -0x50 + lVar27)) {
            lVar27 = DAT_140699950 + lVar27;
            pppppppiVar29 = *(int3 ********)(lVar27 + -0x48);
            iVar21 = *(int *)(lVar27 + -0x40);
            uStack_64 = *(undefined8 *)(lVar27 + -8);
            uStack_68 = (undefined4)((ulonglong)*(undefined8 *)(lVar27 + -0x10) >> 0x20);
            local_78 = *(undefined8 *)(lVar27 + -0x1c);
            uStack_70 = (undefined4)*(undefined8 *)(lVar27 + -0x14);
            uStack_6c = (undefined4)((ulonglong)*(undefined8 *)(lVar27 + -0x14) >> 0x20);
            local_88 = *(undefined8 *)(lVar27 + -0x2c);
            uStack_80 = *(undefined8 *)(lVar27 + -0x24);
            local_98 = *(undefined8 *)(lVar27 + -0x3c);
            uStack_90 = *(undefined8 *)(lVar27 + -0x34);
            goto LAB_1400278b2;
          }
          uVar26 = (ushort)(uVar25 - 1) & (ushort)uVar25;
          uVar25 = CONCAT22((short)(uVar25 - 1 >> 0x10),uVar26);
        }
        auVar36[0] = -(*pcVar2 == -1);
        auVar36[1] = -(pcVar2[1] == -1);
        auVar36[2] = -(pcVar2[2] == -1);
        auVar36[3] = -(pcVar2[3] == -1);
        auVar36[4] = -(pcVar2[4] == -1);
        auVar36[5] = -(pcVar2[5] == -1);
        auVar36[6] = -(pcVar2[6] == -1);
        auVar36[7] = -(pcVar2[7] == -1);
        auVar36[8] = -(pcVar2[8] == -1);
        auVar36[9] = -(pcVar2[9] == -1);
        auVar36[10] = -(pcVar2[10] == -1);
        auVar36[0xb] = -(pcVar2[0xb] == -1);
        auVar36[0xc] = -(pcVar2[0xc] == -1);
        auVar36[0xd] = -(pcVar2[0xd] == -1);
        auVar36[0xe] = -(pcVar2[0xe] == -1);
        auVar36[0xf] = -(pcVar2[0xf] == -1);
        if ((((((((((((((((SUB161(auVar36 >> 7,0) & 1) != 0 || (SUB161(auVar36 >> 0xf,0) & 1) != 0)
                        || (SUB161(auVar36 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar36 >> 0x1f,0) & 1) != 0) || (SUB161(auVar36 >> 0x27,0) & 1) != 0
                      ) || (SUB161(auVar36 >> 0x2f,0) & 1) != 0) ||
                    (SUB161(auVar36 >> 0x37,0) & 1) != 0) || (SUB161(auVar36 >> 0x3f,0) & 1) != 0)
                  || (SUB161(auVar36 >> 0x47,0) & 1) != 0) || (SUB161(auVar36 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar36 >> 0x57,0) & 1) != 0) || (SUB161(auVar36 >> 0x5f,0) & 1) != 0) ||
              (SUB161(auVar36 >> 0x67,0) & 1) != 0) || (SUB161(auVar36 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar36 >> 0x77,0) & 1) != 0) || auVar36[0xf] < '\0') break;
        uVar13 = uVar13 + lVar24 + 0x10;
        lVar24 = lVar24 + 0x10;
      }
    }
LAB_1400278b2:
    pppppppiVar30 = (int3 *******)0x1;
  }
LAB_1400278b5:
  if (((bVar12 == 0) && ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) != 0)) &&
     (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar10 == '\0'))
  {
    DAT_140699831 = '\x01';
  }
  cVar10 = TRANSPORT;
  LOCK();
  TRANSPORT = '\0';
  UNLOCK();
  if (cVar10 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
  }
  if (((bVar11 == 0) && ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) != 0)) &&
     (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar10 == '\0'))
  {
    DAT_140699949 = '\x01';
  }
  cVar10 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  uStack_ac = uStack_70;
  uStack_a8 = uStack_6c;
  uStack_a4 = uStack_68;
  uStack_a0 = uStack_64;
  if (cVar10 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    uStack_ac = uStack_70;
    uStack_a8 = uStack_6c;
    uStack_a4 = uStack_68;
    uStack_a0 = uStack_64;
  }
  if (iVar21 == -1) {
    return (ulonglong)local_178;
  }
  uStack_d4 = (undefined4)local_98;
  local_d0 = (undefined4)((ulonglong)local_98 >> 0x20);
  uStack_cc = (undefined4)uStack_90;
  uStack_c8 = (undefined4)((ulonglong)uStack_90 >> 0x20);
  uStack_c4 = (undefined4)local_88;
  uStack_c0 = (undefined4)((ulonglong)local_88 >> 0x20);
  uStack_bc = (undefined4)uStack_80;
  uStack_b8 = (undefined4)((ulonglong)uStack_80 >> 0x20);
  uStack_b4 = (undefined4)local_78;
  uStack_b0 = (undefined4)((ulonglong)local_78 >> 0x20);
  local_e0 = pppppppiVar29;
  iStack_d8 = iVar21;
  uStack_70 = uStack_ac;
  uStack_6c = uStack_a8;
  uStack_68 = uStack_a4;
  uStack_64 = uStack_a0;
  cVar10 = is_blocked(local_170,&local_d0);
  if (cVar10 != '\0') {
    return (ulonglong)local_178;
  }
  if (((((ulonglong)pppppppiVar30 & 1) != 0) &&
      (HOST_ID_0_llvm_14435704873730135342 != (int3 *******)0x0)) &&
     ((IS_HOST_0_llvm_14435704873730135342 == '\0' &&
      (cVar10 = is_blocked(HOST_ID_0_llvm_14435704873730135342,&local_d0), cVar10 != '\0')))) {
    return (ulonglong)local_178;
  }
  if ((DAT_140699988 != '\0') && (DAT_140699989 == '\0')) {
    <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
    ::lock(&local_148,&DAT_1406998e8);
    pppppppiVar29 = pppppppiStack_140;
    if ((int)local_148 != 1) {
      uVar13 = (ulonglong)local_138 & 0xff;
      if (pppppppiStack_140[4] != (int3 ******)0x0) {
        uVar15 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                 ::hash_one::<&usize>(pppppppiStack_140 + 5,&local_170);
        ppppppiVar20 = pppppppiVar29[1];
        bVar11 = (byte)(uVar15 >> 0x39);
        auVar34 = ZEXT216(CONCAT11(bVar11,bVar11));
        auVar34 = pshuflw(auVar34,auVar34,0);
        lVar24 = 0;
        while( true ) {
          uVar15 = uVar15 & (ulonglong)pppppppiVar29[2];
          auVar38 = *(undefined1 (*) [16])((longlong)ppppppiVar20 + uVar15);
          auVar40[0] = -(auVar38[0] == auVar34[0]);
          auVar40[1] = -(auVar38[1] == auVar34[1]);
          auVar40[2] = -(auVar38[2] == auVar34[2]);
          auVar40[3] = -(auVar38[3] == auVar34[3]);
          auVar40[4] = -(auVar38[4] == auVar34[4]);
          auVar40[5] = -(auVar38[5] == auVar34[5]);
          auVar40[6] = -(auVar38[6] == auVar34[6]);
          auVar40[7] = -(auVar38[7] == auVar34[7]);
          auVar40[8] = -(auVar38[8] == auVar34[0]);
          auVar40[9] = -(auVar38[9] == auVar34[1]);
          auVar40[10] = -(auVar38[10] == auVar34[2]);
          auVar40[0xb] = -(auVar38[0xb] == auVar34[3]);
          auVar40[0xc] = -(auVar38[0xc] == auVar34[4]);
          auVar40[0xd] = -(auVar38[0xd] == auVar34[5]);
          auVar40[0xe] = -(auVar38[0xe] == auVar34[6]);
          auVar40[0xf] = -(auVar38[0xf] == auVar34[7]);
          uVar26 = (ushort)(SUB161(auVar40 >> 7,0) & 1) |
                   (ushort)(SUB161(auVar40 >> 0xf,0) & 1) << 1 |
                   (ushort)(SUB161(auVar40 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar40 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar40 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar40 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar40 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar40 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar40 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar40 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar40 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar40 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar40 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar40 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar40 >> 0x77,0) & 1) << 0xe |
                   (ushort)(auVar40[0xf] >> 7) << 0xf;
          uVar25 = (uint)uVar26;
          while (uVar26 != 0) {
            uVar4 = 0;
            for (uVar5 = uVar25; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
              uVar4 = uVar4 + 1;
            }
            uVar28 = uVar4 + uVar15 & (ulonglong)pppppppiVar29[2];
            if (local_170 == (int3 *******)ppppppiVar20[uVar28 * -10 + -10]) {
              cVar10 = <host_probe[b94139f9089eb1d8]::net::Route>::is
                                 (ppppppiVar20 + uVar28 * -10 + -9,(longlong)&local_98 + 4,
                                  (longlong)&local_78 + 4);
              if (cVar10 == '\0') goto LAB_140027afd;
              core[505b25137b8ba7f]::ptr::drop_glue::
              <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>
                        (pppppppiVar29,uVar13);
              goto LAB_140027ab2;
            }
            uVar26 = (ushort)(uVar25 - 1) & (ushort)uVar25;
            uVar25 = CONCAT22((short)(uVar25 - 1 >> 0x10),uVar26);
          }
          auVar37[0] = -(auVar38[0] == -1);
          auVar37[1] = -(auVar38[1] == -1);
          auVar37[2] = -(auVar38[2] == -1);
          auVar37[3] = -(auVar38[3] == -1);
          auVar37[4] = -(auVar38[4] == -1);
          auVar37[5] = -(auVar38[5] == -1);
          auVar37[6] = -(auVar38[6] == -1);
          auVar37[7] = -(auVar38[7] == -1);
          auVar37[8] = -(auVar38[8] == -1);
          auVar37[9] = -(auVar38[9] == -1);
          auVar37[10] = -(auVar38[10] == -1);
          auVar37[0xb] = -(auVar38[0xb] == -1);
          auVar37[0xc] = -(auVar38[0xc] == -1);
          auVar37[0xd] = -(auVar38[0xd] == -1);
          auVar37[0xe] = -(auVar38[0xe] == -1);
          auVar37[0xf] = -(auVar38[0xf] == -1);
          if ((((((((((((((((SUB161(auVar37 >> 7,0) & 1) != 0 || (SUB161(auVar37 >> 0xf,0) & 1) != 0
                           ) || (SUB161(auVar37 >> 0x17,0) & 1) != 0) ||
                         (SUB161(auVar37 >> 0x1f,0) & 1) != 0) ||
                        (SUB161(auVar37 >> 0x27,0) & 1) != 0) ||
                       (SUB161(auVar37 >> 0x2f,0) & 1) != 0) || (SUB161(auVar37 >> 0x37,0) & 1) != 0
                      ) || (SUB161(auVar37 >> 0x3f,0) & 1) != 0) ||
                    (SUB161(auVar37 >> 0x47,0) & 1) != 0) || (SUB161(auVar37 >> 0x4f,0) & 1) != 0)
                  || (SUB161(auVar37 >> 0x57,0) & 1) != 0) || (SUB161(auVar37 >> 0x5f,0) & 1) != 0)
                || (SUB161(auVar37 >> 0x67,0) & 1) != 0) || (SUB161(auVar37 >> 0x6f,0) & 1) != 0) ||
              (SUB161(auVar37 >> 0x77,0) & 1) != 0) || auVar37[0xf] < '\0') break;
          uVar15 = uVar15 + lVar24 + 0x10;
          lVar24 = lVar24 + 0x10;
        }
      }
LAB_140027afd:
      core[505b25137b8ba7f]::ptr::drop_glue::
      <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>
                (pppppppiVar29,uVar13);
      return (ulonglong)local_178;
    }
    local_168 = pppppppiStack_140;
    pcStack_160 = (code *)CONCAT71(pcStack_160._1_7_,local_138._0_1_);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_168,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a27e8);
    goto LAB_140028126;
  }
LAB_140027ab2:
  if (((ulonglong)pppppppiVar30 & 1) == 0) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in(&local_148,local_178 + 1,0,1,1)
    ;
    pppppppiVar30 = pppppppiStack_140;
    uVar14 = DAT_1406998e0;
    if ((char)local_148 != '\0') {
      alloc[246c2e7857c81348]::raw_vec::handle_error(pppppppiStack_140,local_138);
                    /* WARNING: Does not return */
      pcVar3 = (code *)invalidInstructionException();
      (*pcVar3)();
    }
    local_148 = pppppppiStack_140;
    pppppppiStack_140 = local_138;
    local_138 = (int3 *******)0x0;
    if (pppppppiVar30 < &DAT_00000008) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_148,0,8,1,1);
    }
    *(undefined8 *)((longlong)pppppppiStack_140 + (longlong)local_138) = uVar14;
    local_138 = (int3 *******)((longlong)local_138 + 8);
    if (DAT_140699988 != '\0') {
      if ((ulonglong)((longlong)local_148 - (longlong)local_138) < 8) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_148,local_138,8,1,1);
      }
      pppppppiVar30 = local_138;
      *(undefined8 *)((longlong)pppppppiStack_140 + (longlong)local_138) = 0x31304749422d5252;
      cVar10 = DAT_140699988;
      local_138 = local_138 + 1;
      if (local_138 == local_148) {
        <alloc[246c2e7857c81348]::raw_vec::RawVec<u8>>::grow_one(&local_148);
      }
      *(char *)((longlong)(pppppppiStack_140 + 1) + (longlong)pppppppiVar30) = cVar10;
      local_138 = (int3 *******)((longlong)pppppppiVar30 + 9);
    }
    ppppppiVar20 = local_178;
    if ((int3 ******)((longlong)local_148 - (longlong)local_138) < local_178) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_148,local_138,local_178,1,1);
LAB_140027c03:
      memcpy((undefined1 *)((longlong)local_138 + (longlong)pppppppiStack_140),ppppppiVar16,
             (size_t)ppppppiVar20);
    }
    else if (local_178 != (int3 ******)0x0) goto LAB_140027c03;
    pppppppiVar30 = (int3 *******)((longlong)local_138 + (longlong)ppppppiVar20);
    uVar22 = 0;
    cVar10 = (char)uStack_b0;
  }
  else {
    cVar10 = (char)uStack_b0;
    star_wrap(&local_148,local_170,ppppppiVar16,local_178,(char)uStack_b0);
    if (local_148 == (int3 *******)0xffffffffffffffff) {
      note_star_oversize(pppppppiStack_140);
      return (ulonglong)local_178;
    }
    uVar22 = 2;
    pppppppiVar30 = local_138;
  }
  pppppppiVar7 = pppppppiStack_140;
  pppppppiVar29 = local_148;
  if ((cVar10 != '\0') &&
     (reach_directory[4b72b9694f6c3c08]::rendezvous::relay_wrap
                (&local_148,(longlong)&uStack_b0 + 1,pppppppiStack_140,pppppppiVar30),
     pppppppiVar30 = local_138, pppppppiVar29 != (int3 *******)0x0)) {
    uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(pppppppiVar7,pppppppiVar29,1);
    return uVar13;
  }
  pppppppiVar7 = pppppppiStack_140;
  pppppppiVar29 = local_148;
  flush_held();
  pppppppiVar19 = (int3 *******)&IMPAIR;
  <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
  ::lock(&local_148,&IMPAIR);
  pppppppiVar8 = pppppppiStack_140;
  uVar9 = local_138._0_1_;
  local_e8 = pppppppiVar7;
  if ((int)local_148 != 1) {
    pppppppiVar1 = pppppppiStack_140 + 1;
    if (pppppppiStack_140[1] != (int3 ******)0xffffffffffffffff) {
      ppppppiVar16 = pppppppiStack_140[3];
      if (ppppppiVar16 == (int3 ******)0x0) {
LAB_140027dfa:
        uVar18 = SUB84(pppppppiVar19,0);
        uVar14 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
        uVar17 = <host_probe[b94139f9089eb1d8]::net::Impairment>::fate(pppppppiVar1,uVar14,uVar18);
        pppppppiVar7 = local_e8;
        ppppppiVar16 = local_178;
        if ((int)uVar14 != -1) {
          local_120 = (undefined8 *)CONCAT44(uStack_cc,local_d0);
          uStack_118 = CONCAT44(uStack_c4,uStack_c8);
          local_110 = CONCAT44(uStack_bc,uStack_c0);
          uStack_108 = CONCAT44(uStack_b4,uStack_b8);
          pppppppiStack_140 = local_e8;
          local_128 = (int3 *******)CONCAT44(local_128._4_4_,(int)uVar14);
          local_100 = local_170;
          local_148 = pppppppiVar29;
          local_138 = pppppppiVar30;
          pcStack_130 = (code *)uVar17;
          local_f8 = uVar22;
          <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>>
          ::push_back_mut(pppppppiVar8 + 4,&local_148);
          ppppppiVar16 = local_178;
          core[505b25137b8ba7f]::ptr::drop_glue::
          <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<[usize_3usize]>>>
                    (pppppppiVar8,uVar9);
          return (ulonglong)ppppppiVar16;
        }
        core[505b25137b8ba7f]::ptr::drop_glue::
        <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<[usize_3usize]>>>
                  (pppppppiVar8,uVar9);
        if (pppppppiVar29 == (int3 *******)0x0) {
          return (ulonglong)ppppppiVar16;
        }
        uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(pppppppiVar7,pppppppiVar29,1);
        return uVar13;
      }
      ppppppiVar20 = pppppppiStack_140[2];
      uVar13 = (ulonglong)ppppppiVar16 & 0xffffffffffffff8;
      pppppppiVar19 = local_170;
      if (uVar13 != 0) {
        uVar15 = 0;
        do {
          if ((((((int3 *******)ppppppiVar20[uVar15] == local_170) ||
                ((int3 *******)ppppppiVar20[uVar15 + 1] == local_170)) ||
               ((int3 *******)ppppppiVar20[uVar15 + 2] == local_170)) ||
              (((int3 *******)ppppppiVar20[uVar15 + 3] == local_170 ||
               ((int3 *******)ppppppiVar20[uVar15 + 4] == local_170)))) ||
             (((int3 *******)ppppppiVar20[uVar15 + 5] == local_170 ||
              (((int3 *******)ppppppiVar20[uVar15 + 6] == local_170 ||
               ((int3 *******)ppppppiVar20[uVar15 + 7] == local_170)))))) goto LAB_140027dfa;
          uVar15 = uVar15 + 8;
        } while (uVar13 != uVar15);
      }
      if (((ulonglong)ppppppiVar16 & 7) != 0) {
        uVar15 = 0;
        do {
          if (*(int3 ********)((longlong)ppppppiVar20 + uVar15 + uVar13 * 8) == local_170)
          goto LAB_140027dfa;
          uVar15 = uVar15 + 8;
        } while (((uint)ppppppiVar16 & 7) << 3 != uVar15);
      }
    }
    core[505b25137b8ba7f]::ptr::drop_glue::
    <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<[usize_3usize]>>>
              (pppppppiStack_140,(ulonglong)local_138 & 0xff);
    local_148 = (int3 *******)CONCAT44(uStack_cc,local_d0);
    pppppppiStack_140 = (int3 *******)CONCAT44(uStack_c4,uStack_c8);
    local_138 = (int3 *******)CONCAT44(uStack_bc,uStack_c0);
    pcStack_130 = (code *)CONCAT44(uStack_b4,uStack_b8);
    uVar13 = netstats::send_to::<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>
                       (&DAT_140699980,pppppppiVar7,pppppppiVar30,&local_148,uVar22);
    ppppppiVar16 = local_178;
    core[505b25137b8ba7f]::ptr::drop_glue::
    <core[505b25137b8ba7f]::result::Result<usize,core[505b25137b8ba7f]::io::error::Error>>(uVar13);
    if ((uVar13 & 1) != 0) {
      ppppppiVar16 = (int3 ******)0x0;
    }
    if (pppppppiVar29 == (int3 *******)0x0) {
      return (ulonglong)ppppppiVar16;
    }
    uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(pppppppiVar7,pppppppiVar29,1);
    return uVar13;
  }
  local_168 = pppppppiStack_140;
  pcStack_160 = (code *)CONCAT71(pcStack_160._1_7_,local_138._0_1_);
  core[505b25137b8ba7f]::result::unwrap_failed
            ("called `Result::unwrap()` on an `Err` value",0x2b,&local_168,
             &anon_d5c34e88a06ee720b116585eb143da4b_138_llvm_14435704873730135342,
             &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2800);
LAB_140028126:
                    /* WARNING: Does not return */
  pcVar3 = (code *)invalidInstructionException();
  (*pcVar3)();
}

