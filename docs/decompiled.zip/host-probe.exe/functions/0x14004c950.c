// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#16}>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#17}>>>::from_iter
// address: 0x14004c950
// body: available
// range: 0x14004c950-0x14004cc3f inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#16}>,
   host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#17}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#16}>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#17}>>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  ulonglong uVar2;
  ulonglong *puVar3;
  longlong *plVar4;
  code *pcVar5;
  undefined4 *puVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong local_b8;
  undefined4 *local_b0;
  longlong local_a8;
  ulonglong *local_a0;
  code *local_98;
  longlong local_90;
  code *local_88;
  undefined8 local_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 local_70;
  longlong *local_68;
  ulonglong local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  uVar2 = param_2[2];
  uVar9 = param_2[1];
  if (uVar9 < uVar2) {
    puVar3 = (ulonglong *)*param_2;
    lVar7 = uVar9 * -0xb0 + -0x2b30;
    local_90 = uVar9 * -0xb0 + -0x1708;
    do {
      if ((*puVar3 >> (uVar9 & 0x3f) & 1) != 0) {
        plVar4 = (longlong *)param_2[3];
        lVar8 = *plVar4;
        if (host_probe[b94139f9089eb1d8]::pbx::RELOCATED_0_llvm_10439611301029776152 == '\0') {
          local_90 = lVar8 - lVar7;
        }
        else {
          local_90 = (lVar8 + host_probe[b94139f9089eb1d8]::pbx::DELTA_0_llvm_10439611301029776152)
                     - local_90;
        }
        local_90 = local_90 + 0xc;
        local_a0 = &local_80;
        local_98 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_88 = <i32_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_80 = uVar9;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a3dd5,&local_a0);
        if (CONCAT44(uStack_54,local_58) != -1) {
          local_68 = plVar4;
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
          if (puVar6 == (undefined4 *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
            pcVar5 = (code *)invalidInstructionException();
            (*pcVar5)();
          }
          uVar9 = uVar9 + 1;
          *(undefined8 *)(puVar6 + 4) = local_48;
          *puVar6 = local_58;
          puVar6[1] = uStack_54;
          puVar6[2] = uStack_50;
          puVar6[3] = uStack_4c;
          local_b8 = 4;
          local_a8 = 1;
          local_b0 = puVar6;
          if (uVar2 <= uVar9) goto LAB_14004cbe5;
          goto LAB_14004cab8;
        }
        break;
      }
      uVar9 = uVar9 + 1;
      lVar7 = lVar7 + -0xb0;
      local_90 = local_90 + -0xb0;
    } while (uVar2 != uVar9);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
  while( true ) {
    if (lVar7 == local_b8) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_b8,lVar7,1,8,0x18);
      puVar6 = local_b0;
    }
    uVar9 = uVar9 + 1;
    *(undefined8 *)(puVar6 + lVar7 * 6 + 4) = local_70;
    puVar1 = puVar6 + lVar7 * 6;
    *puVar1 = (undefined4)local_80;
    puVar1[1] = local_80._4_4_;
    puVar1[2] = uStack_78;
    puVar1[3] = uStack_74;
    local_a8 = lVar7 + 1;
    if (uVar2 <= uVar9) break;
LAB_14004cab8:
    lVar7 = local_a8;
    lVar8 = uVar9 * -0xb0 + -0x2b30;
    local_90 = uVar9 * -0xb0 + -0x1708;
    while ((*puVar3 >> (uVar9 & 0x3f) & 1) == 0) {
      uVar9 = uVar9 + 1;
      lVar8 = lVar8 + -0xb0;
      local_90 = local_90 + -0xb0;
      if (uVar2 == uVar9) goto LAB_14004cbe5;
    }
    if (host_probe[b94139f9089eb1d8]::pbx::RELOCATED_0_llvm_10439611301029776152 == '\0') {
      local_90 = *local_68 - lVar8;
    }
    else {
      local_90 = (*local_68 + host_probe[b94139f9089eb1d8]::pbx::DELTA_0_llvm_10439611301029776152)
                 - local_90;
    }
    local_90 = local_90 + 0xc;
    local_a0 = &local_60;
    local_98 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_88 = <i32_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_60 = uVar9;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_80,&DAT_1406a3dd5,&local_a0);
    if (local_80 == 0xffffffffffffffff) break;
  }
LAB_14004cbe5:
  param_1[2] = local_a8;
  *param_1 = local_b8;
  param_1[1] = (longlong)local_b0;
  return param_1;
}

