// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::receive::{closure#0}
// address: 0x14000ca00
// body: available
// range: 0x14000ca00-0x14000cc85 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::receive::{closure#0} */

byte __rustcall
host_probe[b94139f9089eb1d8]::net::receive::_closure_0_(undefined1 *param_1,longlong param_2)

{
  char *pcVar1;
  code *pcVar2;
  uint uVar3;
  uint uVar4;
  undefined *puVar5;
  char cVar6;
  char cVar7;
  ulonglong uVar8;
  longlong lVar9;
  uint uVar10;
  ushort uVar11;
  longlong lVar12;
  bool bVar13;
  byte bVar14;
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined1 *local_40;
  byte local_38;
  
  cVar6 = is_blocked(param_1,(short *)(param_2 + 0x10));
  cVar7 = DAT_140699988;
  bVar14 = 1;
  if (cVar6 == '\0') {
    LOCK();
    bVar13 = DAT_1406998e8 == '\0';
    if (bVar13) {
      DAT_1406998e8 = '\x01';
    }
    UNLOCK();
    if (!bVar13) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended();
    }
    puVar5 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      local_38 = 0;
    }
    else {
      local_38 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      local_38 = local_38 ^ 1;
    }
    if (DAT_1406998e9 != '\0') {
      local_40 = &DAT_1406998e8;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_40,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0788);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    local_40 = param_1;
    if (cVar7 == '\0') {
      bVar14 = 0;
    }
    else {
      bVar14 = 1;
      if (DAT_140699908 != 0) {
        uVar8 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                ::hash_one::<&usize>(&DAT_140699910,&local_40);
        bVar14 = (byte)(uVar8 >> 0x39);
        auVar15 = ZEXT216(CONCAT11(bVar14,bVar14));
        auVar15 = pshuflw(auVar15,auVar15,0);
        lVar9 = 0;
        while( true ) {
          uVar8 = uVar8 & DAT_1406998f8;
          pcVar1 = (char *)(DAT_1406998f0 + uVar8);
          auVar18[0] = -(*pcVar1 == auVar15[0]);
          auVar18[1] = -(pcVar1[1] == auVar15[1]);
          auVar18[2] = -(pcVar1[2] == auVar15[2]);
          auVar18[3] = -(pcVar1[3] == auVar15[3]);
          auVar18[4] = -(pcVar1[4] == auVar15[4]);
          auVar18[5] = -(pcVar1[5] == auVar15[5]);
          auVar18[6] = -(pcVar1[6] == auVar15[6]);
          auVar18[7] = -(pcVar1[7] == auVar15[7]);
          auVar18[8] = -(pcVar1[8] == auVar15[0]);
          auVar18[9] = -(pcVar1[9] == auVar15[1]);
          auVar18[10] = -(pcVar1[10] == auVar15[2]);
          auVar18[0xb] = -(pcVar1[0xb] == auVar15[3]);
          auVar18[0xc] = -(pcVar1[0xc] == auVar15[4]);
          auVar18[0xd] = -(pcVar1[0xd] == auVar15[5]);
          auVar18[0xe] = -(pcVar1[0xe] == auVar15[6]);
          auVar18[0xf] = -(pcVar1[0xf] == auVar15[7]);
          uVar11 = (ushort)(SUB161(auVar18 >> 7,0) & 1) |
                   (ushort)(SUB161(auVar18 >> 0xf,0) & 1) << 1 |
                   (ushort)(SUB161(auVar18 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar18 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar18 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar18 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar18 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar18 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar18 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar18 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar18 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar18 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar18 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar18 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar18 >> 0x77,0) & 1) << 0xe |
                   (ushort)(auVar18[0xf] >> 7) << 0xf;
          uVar10 = (uint)uVar11;
          bVar14 = 1;
          while (uVar11 != 0) {
            uVar3 = 0;
            for (uVar4 = uVar10; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
              uVar3 = uVar3 + 1;
            }
            lVar12 = (uVar3 + uVar8 & DAT_1406998f8) * -0x50;
            if (param_1 == *(undefined1 **)(DAT_1406998f0 + -0x50 + lVar12)) {
              lVar12 = DAT_1406998f0 + lVar12;
              if (*(short *)(lVar12 + -0x38) != *(short *)(param_2 + 0x10)) goto LAB_14000cbb6;
              if (*(short *)(lVar12 + -0x38) == 0) {
                if ((*(short *)(lVar12 + -0x32) != *(short *)(param_2 + 0x16)) ||
                   (*(int *)(lVar12 + -0x36) != *(int *)(param_2 + 0x12))) goto LAB_14000cbb6;
              }
              else if ((*(short *)(lVar12 + -0x1c) != *(short *)(param_2 + 0x2c)) ||
                      (((*(int *)(lVar12 + -0x24) != *(int *)(param_2 + 0x24) ||
                        (*(int *)(lVar12 + -0x20) != *(int *)(param_2 + 0x28))) ||
                       (auVar15[0] = -(*(char *)(param_2 + 0x14) == *(char *)(lVar12 + -0x34)),
                       auVar15[1] = -(*(char *)(param_2 + 0x15) == *(char *)(lVar12 + -0x33)),
                       auVar15[2] = -(*(char *)(param_2 + 0x16) == *(char *)(lVar12 + -0x32)),
                       auVar15[3] = -(*(char *)(param_2 + 0x17) == *(char *)(lVar12 + -0x31)),
                       auVar15[4] = -(*(char *)(param_2 + 0x18) == *(char *)(lVar12 + -0x30)),
                       auVar15[5] = -(*(char *)(param_2 + 0x19) == *(char *)(lVar12 + -0x2f)),
                       auVar15[6] = -(*(char *)(param_2 + 0x1a) == *(char *)(lVar12 + -0x2e)),
                       auVar15[7] = -(*(char *)(param_2 + 0x1b) == *(char *)(lVar12 + -0x2d)),
                       auVar15[8] = -(*(char *)(param_2 + 0x1c) == *(char *)(lVar12 + -0x2c)),
                       auVar15[9] = -(*(char *)(param_2 + 0x1d) == *(char *)(lVar12 + -0x2b)),
                       auVar15[10] = -(*(char *)(param_2 + 0x1e) == *(char *)(lVar12 + -0x2a)),
                       auVar15[0xb] = -(*(char *)(param_2 + 0x1f) == *(char *)(lVar12 + -0x29)),
                       auVar15[0xc] = -(*(char *)(param_2 + 0x20) == *(char *)(lVar12 + -0x28)),
                       auVar15[0xd] = -(*(char *)(param_2 + 0x21) == *(char *)(lVar12 + -0x27)),
                       auVar15[0xe] = -(*(char *)(param_2 + 0x22) == *(char *)(lVar12 + -0x26)),
                       auVar15[0xf] = -(*(char *)(param_2 + 0x23) == *(char *)(lVar12 + -0x25)),
                       (ushort)((ushort)(SUB161(auVar15 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar15 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar15 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar15 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar15 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar15 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar15 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar15 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar15 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar15 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar15 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar15 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar15 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar15 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar15 >> 0x77,0) & 1) << 0xe |
                               (ushort)(auVar15[0xf] >> 7) << 0xf) != 0xffff)))) goto LAB_14000cbb6;
              if ((*(byte *)(param_2 + 0x30) & *(byte *)(lVar12 + -0x18)) == 0) {
                bVar14 = *(byte *)(param_2 + 0x30) | *(byte *)(lVar12 + -0x18);
              }
              else {
                auVar16[0] = -(*(char *)(param_2 + 0x31) == *(char *)(lVar12 + -0x17));
                auVar16[1] = -(*(char *)(param_2 + 0x32) == *(char *)(lVar12 + -0x16));
                auVar16[2] = -(*(char *)(param_2 + 0x33) == *(char *)(lVar12 + -0x15));
                auVar16[3] = -(*(char *)(param_2 + 0x34) == *(char *)(lVar12 + -0x14));
                auVar16[4] = -(*(char *)(param_2 + 0x35) == *(char *)(lVar12 + -0x13));
                auVar16[5] = -(*(char *)(param_2 + 0x36) == *(char *)(lVar12 + -0x12));
                auVar16[6] = -(*(char *)(param_2 + 0x37) == *(char *)(lVar12 + -0x11));
                auVar16[7] = -(*(char *)(param_2 + 0x38) == *(char *)(lVar12 + -0x10));
                auVar16[8] = -(*(char *)(param_2 + 0x39) == *(char *)(lVar12 + -0xf));
                auVar16[9] = -(*(char *)(param_2 + 0x3a) == *(char *)(lVar12 + -0xe));
                auVar16[10] = -(*(char *)(param_2 + 0x3b) == *(char *)(lVar12 + -0xd));
                auVar16[0xb] = -(*(char *)(param_2 + 0x3c) == *(char *)(lVar12 + -0xc));
                auVar16[0xc] = -(*(char *)(param_2 + 0x3d) == *(char *)(lVar12 + -0xb));
                auVar16[0xd] = -(*(char *)(param_2 + 0x3e) == *(char *)(lVar12 + -10));
                auVar16[0xe] = -(*(char *)(param_2 + 0x3f) == *(char *)(lVar12 + -9));
                auVar16[0xf] = -(*(char *)(param_2 + 0x40) == *(char *)(lVar12 + -8));
                bVar14 = (ushort)((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                                  (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                                  (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                                  (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                                  (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                                  (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                                  (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                                  (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                                  (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                                  (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                                  (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                                  (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                                  (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                                  (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                                  (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                                 (ushort)(auVar16[0xf] >> 7) << 0xf) != 0xffff;
              }
              goto LAB_14000cbb6;
            }
            uVar11 = (ushort)(uVar10 - 1) & (ushort)uVar10;
            uVar10 = CONCAT22((short)(uVar10 - 1 >> 0x10),uVar11);
          }
          auVar17[0] = -(*pcVar1 == -1);
          auVar17[1] = -(pcVar1[1] == -1);
          auVar17[2] = -(pcVar1[2] == -1);
          auVar17[3] = -(pcVar1[3] == -1);
          auVar17[4] = -(pcVar1[4] == -1);
          auVar17[5] = -(pcVar1[5] == -1);
          auVar17[6] = -(pcVar1[6] == -1);
          auVar17[7] = -(pcVar1[7] == -1);
          auVar17[8] = -(pcVar1[8] == -1);
          auVar17[9] = -(pcVar1[9] == -1);
          auVar17[10] = -(pcVar1[10] == -1);
          auVar17[0xb] = -(pcVar1[0xb] == -1);
          auVar17[0xc] = -(pcVar1[0xc] == -1);
          auVar17[0xd] = -(pcVar1[0xd] == -1);
          auVar17[0xe] = -(pcVar1[0xe] == -1);
          auVar17[0xf] = -(pcVar1[0xf] == -1);
          if ((((((((((((((((SUB161(auVar17 >> 7,0) & 1) != 0 || (SUB161(auVar17 >> 0xf,0) & 1) != 0
                           ) || (SUB161(auVar17 >> 0x17,0) & 1) != 0) ||
                         (SUB161(auVar17 >> 0x1f,0) & 1) != 0) ||
                        (SUB161(auVar17 >> 0x27,0) & 1) != 0) ||
                       (SUB161(auVar17 >> 0x2f,0) & 1) != 0) || (SUB161(auVar17 >> 0x37,0) & 1) != 0
                      ) || (SUB161(auVar17 >> 0x3f,0) & 1) != 0) ||
                    (SUB161(auVar17 >> 0x47,0) & 1) != 0) || (SUB161(auVar17 >> 0x4f,0) & 1) != 0)
                  || (SUB161(auVar17 >> 0x57,0) & 1) != 0) || (SUB161(auVar17 >> 0x5f,0) & 1) != 0)
                || (SUB161(auVar17 >> 0x67,0) & 1) != 0) || (SUB161(auVar17 >> 0x6f,0) & 1) != 0) ||
              (SUB161(auVar17 >> 0x77,0) & 1) != 0) || auVar17[0xf] < '\0') break;
          uVar8 = uVar8 + lVar9 + 0x10;
          lVar9 = lVar9 + 0x10;
        }
      }
    }
LAB_14000cbb6:
    if (((local_38 == 0) && ((*(ulonglong *)puVar5 & 0x7fffffffffffffff) != 0)) &&
       (cVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar7 == '\0'))
    {
      DAT_1406998e9 = '\x01';
    }
    cVar7 = DAT_1406998e8;
    LOCK();
    DAT_1406998e8 = '\0';
    UNLOCK();
    if (cVar7 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_1406998e8);
    }
  }
  return bVar14;
}

