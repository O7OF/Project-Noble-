// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>,<host_probe[b94139f9089eb1d8]::server_admin::reload::State>::notice::{closure#0}::{closure#0}>,<host_probe[b94139f9089eb1d8]::server_admin::reload::State>::notice::{closure#0}::{closure#1}>>>::from_iter
// address: 0x14004d100
// body: available
// range: 0x14004d100-0x14004d131 inclusive
// range: 0x14004d140-0x14004d1f9 inclusive
// range: 0x14004d200-0x14004d2fa inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,
   alloc[246c2e7857c81348]::string::String)>,
   <host_probe[b94139f9089eb1d8]::server_admin::reload::State>::notice::{closure#0}::{closure#0}>,
   <host_probe[b94139f9089eb1d8]::server_admin::reload::State>::notice::{closure#0}::{closure#1}>>>::from_iter
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>,<host_probe[b94139f9089eb1d8]::server_admin::reload::State>::notice::{closure#0}::{closure#0}>,<host_probe[b94139f9089eb1d8]::server_admin::reload::State>::notice::{closure#0}::{closure#1}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  undefined8 *puVar2;
  size_t sVar3;
  code *pcVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong local_88;
  longlong *local_80;
  longlong local_78;
  longlong local_70;
  longlong lStack_68;
  longlong local_60;
  longlong local_58;
  longlong lStack_50;
  longlong local_48;
  
  lVar1 = param_2[1];
  if (*param_2 != lVar1) {
    puVar2 = (undefined8 *)param_2[2];
    sVar3 = puVar2[1];
    lVar8 = *param_2 + 0x18;
    do {
      if ((*(size_t *)(lVar8 + -8) == sVar3) &&
         (iVar5 = memcmp(*(void **)(lVar8 + -0x10),(void *)*puVar2,sVar3), iVar5 == 0)) {
        <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                  (&local_70,lVar8);
        if (local_70 != -1) {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          plVar6 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
          if (plVar6 == (longlong *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
            pcVar4 = (code *)invalidInstructionException();
            (*pcVar4)();
          }
          lVar8 = lVar8 + 0x18;
          plVar6[2] = local_60;
          *plVar6 = local_70;
          plVar6[1] = lStack_68;
          local_88 = 4;
          local_78 = 1;
          local_80 = plVar6;
          if (lVar8 == lVar1) goto LAB_14004d2a3;
          goto LAB_14004d1ef;
        }
        break;
      }
      lVar7 = lVar8 + 0x18;
      lVar8 = lVar8 + 0x30;
    } while (lVar7 != lVar1);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
  while( true ) {
    if (lVar7 == local_88) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_88,lVar7,1,8,0x18);
      plVar6 = local_80;
    }
    lVar8 = lVar8 + 0x18;
    plVar6[lVar7 * 3 + 2] = local_48;
    plVar6[lVar7 * 3] = local_58;
    (plVar6 + lVar7 * 3)[1] = lStack_50;
    local_78 = lVar7 + 1;
    if (lVar8 == lVar1) break;
LAB_14004d1ef:
    lVar7 = local_78;
    sVar3 = puVar2[1];
    lVar8 = lVar8 + 0x18;
    while ((*(size_t *)(lVar8 + -8) != sVar3 ||
           (iVar5 = memcmp(*(void **)(lVar8 + -0x10),(void *)*puVar2,sVar3), iVar5 != 0))) {
      lVar9 = lVar8 + 0x18;
      lVar8 = lVar8 + 0x30;
      if (lVar9 == lVar1) goto LAB_14004d2a3;
    }
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (&local_58,lVar8);
    if (local_58 == -1) break;
  }
LAB_14004d2a3:
  param_1[2] = local_78;
  *param_1 = local_88;
  param_1[1] = (longlong)local_80;
  return param_1;
}

