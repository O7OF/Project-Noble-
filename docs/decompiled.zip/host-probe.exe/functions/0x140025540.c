// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::set_banned_ips
// address: 0x140025540
// body: available
// range: 0x140025540-0x1400256f9 inclusive
// range: 0x140025701-0x140025889 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400256f5 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002571a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::set_banned_ips */

void __rustcall host_probe[b94139f9089eb1d8]::net::set_banned_ips(longlong *param_1)

{
  code *pcVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined *puVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  undefined1 *puVar8;
  byte bVar9;
  char cVar10;
  longlong *plVar11;
  longlong lVar12;
  DWORD dwTlsIndex;
  ulonglong uVar13;
  bool bVar14;
  undefined8 local_b8;
  undefined1 *puStack_b0;
  longlong local_a8;
  undefined1 *puStack_a0;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  
  local_a8 = *param_1;
  local_b8 = (undefined1 *)param_1[1];
  puStack_a0 = local_b8 + param_1[2] * 0x12;
  puStack_b0 = local_b8;
  <alloc[246c2e7857c81348]::vec::into_iter::IntoIter<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::partition::
  <alloc[246c2e7857c81348]::vec::Vec<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>,host_probe[b94139f9089eb1d8]::net::set_banned_ips::_closure_0_>
            (&local_88,&local_b8);
  puVar8 = uStack_70;
  lVar12 = local_78;
  lVar2 = uStack_80;
  uVar7 = local_88;
  puVar5 = 
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
  ;
  uVar3 = CONCAT44(uStack_64,local_68);
  uVar4 = CONCAT44(uStack_5c,uStack_60);
  if (*(longlong *)
       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
      != 0) {
    std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
  }
  if (*(int *)(puVar5 + 0x18) == 0) {
    dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                           (
                           __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                           );
    plVar11 = TlsGetValue(dwTlsIndex);
  }
  else {
    dwTlsIndex = *(int *)(puVar5 + 0x18) - 1;
    plVar11 = TlsGetValue(dwTlsIndex);
  }
  if (plVar11 < (longlong *)0x2) {
    plVar11 = (longlong *)
              <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
              ::try_initialize::
              <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                        (dwTlsIndex,plVar11,0);
  }
  if (plVar11 == (longlong *)0x0) {
    std[3bf9d48a0c3997f0]::thread::local::panic_access_error
              (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
  }
  else {
    local_98 = (undefined4)*plVar11;
    uStack_94 = *(undefined4 *)((longlong)plVar11 + 4);
    uStack_90 = (undefined4)plVar11[1];
    uStack_8c = *(undefined4 *)((longlong)plVar11 + 0xc);
    *plVar11 = *plVar11 + 1;
    local_a8 = 0;
    puStack_a0 = (undefined1 *)0x0;
    local_b8._0_4_ = 0x406a0540;
    uVar6 = (undefined4)local_b8;
    local_b8._0_4_ = 0x406a0540;
    local_b8._4_4_ = 1;
    puStack_b0 = (undefined1 *)0x0;
    if (lVar12 != 0) {
      local_b8._0_4_ = uVar6;
      <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(core[505b25137b8ba7f]::net::ip_addr::IpAddr,())>>
      ::reserve_rehash::
      <hashbrown[ad6d4a1843b2832d]::map::make_hasher<core[505b25137b8ba7f]::net::ip_addr::IpAddr,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>::_closure_0_>
                (&local_b8,lVar12,&local_98);
    }
    uStack_70 = (undefined1 *)(lVar2 + lVar12 * 0x12);
    local_88 = lVar2;
    local_78 = uVar7;
    <alloc[246c2e7857c81348]::vec::into_iter::IntoIter<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
    ::fold::
    <(),core[505b25137b8ba7f]::iter::adapters::map::map_fold<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet,core[505b25137b8ba7f]::net::ip_addr::IpAddr,(),host_probe[b94139f9089eb1d8]::net::set_banned_ips::_closure_1_,core[505b25137b8ba7f]::iter::adapters::map::map_fold<core[505b25137b8ba7f]::net::ip_addr::IpAddr,(core[505b25137b8ba7f]::net::ip_addr::IpAddr,()),(),<hashbrown[ad6d4a1843b2832d]::set::HashSet<core[505b25137b8ba7f]::net::ip_addr::IpAddr,std[3bf9d48a0c3997f0]::hash::random::RandomState>as_core[505b25137b8ba7f]::iter::traits::collect::Extend<core[505b25137b8ba7f]::net::ip_addr::IpAddr>>::extend<core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>,host_probe[b94139f9089eb1d8]::net::set_banned_ips::_closure_1_>>::_closure_0_,core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<(core[505b25137b8ba7f]::net::ip_addr::IpAddr,()),<hashbrown[ad6d4a1___set_banned_ips::_closure_1_>>::_closure_0_>>::_closure_0_>___closure_0_>___closure_0_>___closure_0_>
              (&local_88,&local_b8);
    local_88 = CONCAT44(local_b8._4_4_,(undefined4)local_b8);
    uStack_80 = (longlong)puStack_b0;
    local_78 = local_a8;
    uStack_70 = puStack_a0;
    local_68 = local_98;
    uStack_64 = uStack_94;
    uStack_60 = uStack_90;
    uStack_5c = uStack_8c;
    local_58 = puVar8;
    LOCK();
    bVar14 = SAVED_IPS == '\0';
    if (bVar14) {
      SAVED_IPS = '\x01';
    }
    UNLOCK();
    uStack_50 = uVar3;
    local_48 = uVar4;
    if (!bVar14) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&SAVED_IPS);
    }
    puVar5 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar9 = 0;
      uVar3 = local_88;
    }
    else {
      bVar9 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar9 = bVar9 ^ 1;
      uVar3 = local_88;
    }
    local_88 = uVar3;
    if (DAT_1406997e1 == '\0') {
      lVar2 = CONCAT44(DAT_140699818._4_4_,(undefined4)DAT_140699818);
      if (lVar2 != -1) {
        lVar12 = CONCAT44(DAT_1406997f0._4_4_,(undefined4)DAT_1406997f0);
        if (lVar12 != 0) {
          uVar13 = lVar12 * 0x11 & 0xfffffffffffffff0;
          lVar12 = lVar12 + uVar13 + 0x31;
          if (lVar12 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      ((CONCAT44(DAT_1406997e8._4_4_,(undefined4)DAT_1406997e8) - uVar13) + -0x20,
                       lVar12,0x10);
            return;
          }
        }
        if (lVar2 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc
                    (CONCAT44(DAT_140699820._4_4_,(undefined4)DAT_140699820),lVar2 * 0x12,1);
          return;
        }
      }
      local_88._0_4_ = (undefined4)uVar3;
      local_88._4_4_ = (undefined4)((ulonglong)uVar3 >> 0x20);
      uStack_80._4_4_ = (undefined4)((ulonglong)uStack_80 >> 0x20);
      local_78._4_4_ = (undefined4)((ulonglong)local_78 >> 0x20);
      uStack_70._4_4_ = (undefined4)((ulonglong)uStack_70 >> 0x20);
      local_58._4_4_ = (undefined4)((ulonglong)local_58 >> 0x20);
      uStack_50._4_4_ = (undefined4)((ulonglong)uStack_50 >> 0x20);
      DAT_140699818._0_4_ = (undefined4)local_58;
      DAT_140699818._4_4_ = local_58._4_4_;
      DAT_140699820._0_4_ = (undefined4)uStack_50;
      DAT_140699820._4_4_ = uStack_50._4_4_;
      _DAT_1406997f8 = (undefined4)local_78;
      uRam00000001406997fc = local_78._4_4_;
      uRam0000000140699800 = (undefined4)uStack_70;
      uRam0000000140699804 = uStack_70._4_4_;
      DAT_1406997e8._0_4_ = (undefined4)local_88;
      DAT_1406997e8._4_4_ = local_88._4_4_;
      DAT_1406997f0._0_4_ = (undefined4)uStack_80;
      DAT_1406997f0._4_4_ = uStack_80._4_4_;
      _DAT_140699808 = local_68;
      uRam000000014069980c = uStack_64;
      uRam0000000140699810 = uStack_60;
      uRam0000000140699814 = uStack_5c;
      DAT_140699828 = local_48;
      if (((bVar9 == 0) && ((*(ulonglong *)puVar5 & 0x7fffffffffffffff) != 0)) &&
         (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
         cVar10 == '\0')) {
        DAT_1406997e1 = '\x01';
      }
      cVar10 = SAVED_IPS;
      LOCK();
      SAVED_IPS = 0;
      UNLOCK();
      if (cVar10 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&SAVED_IPS);
      }
      return;
    }
    local_b8 = &SAVED_IPS;
    uVar13 = (ulonglong)puStack_b0 >> 8;
    puStack_b0 = (undefined1 *)CONCAT71((int7)uVar13,bVar9);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_b8,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0f90
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a22e0);
  }
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

