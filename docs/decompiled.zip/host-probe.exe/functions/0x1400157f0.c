// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>::remove
// address: 0x1400157f0
// body: available
// range: 0x1400157f0-0x1400158ff inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>::remove
    */

undefined8 * __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>
::remove(undefined8 *param_1,ulonglong *param_2,ulonglong param_3)

{
  undefined8 *puVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  longlong lVar16;
  ulonglong uVar17;
  
  uVar2 = param_2[3];
  if (param_3 < uVar2) {
    uVar3 = *param_2;
    uVar15 = param_2[2];
    uVar14 = 0;
    if (uVar3 <= uVar15 + param_3) {
      uVar14 = uVar3;
    }
    lVar16 = (uVar15 + param_3) - uVar14;
    uVar14 = param_2[1];
    uVar4 = *(undefined8 *)(uVar14 + 0x40 + lVar16 * 0x48);
    puVar1 = (undefined8 *)(uVar14 + lVar16 * 0x48);
    uVar6 = *puVar1;
    uVar7 = puVar1[1];
    puVar1 = (undefined8 *)(uVar14 + 0x10 + lVar16 * 0x48);
    uVar8 = *puVar1;
    uVar9 = puVar1[1];
    puVar1 = (undefined8 *)(uVar14 + 0x20 + lVar16 * 0x48);
    uVar10 = *puVar1;
    uVar11 = puVar1[1];
    puVar1 = (undefined8 *)(uVar14 + 0x30 + lVar16 * 0x48);
    uVar5 = *(undefined4 *)puVar1;
    uVar12 = *puVar1;
    uVar13 = puVar1[1];
    if (~param_3 + uVar2 < param_3) {
      uVar15 = 0;
      if (uVar3 <= lVar16 + 1U) {
        uVar15 = uVar3;
      }
      uVar15 = (lVar16 - uVar15) + 1;
      param_3 = ~param_3 + uVar2;
    }
    else {
      uVar17 = 0;
      if (uVar3 <= uVar15 + 1) {
        uVar17 = uVar3;
      }
      param_2[2] = (uVar15 - uVar17) + 1;
    }
    wrap_copy(uVar3,uVar14,uVar15,uVar5,param_3);
    param_2[3] = uVar2 - 1;
    param_1[8] = uVar4;
    param_1[6] = uVar12;
    param_1[7] = uVar13;
    param_1[4] = uVar10;
    param_1[5] = uVar11;
    param_1[2] = uVar8;
    param_1[3] = uVar9;
    *param_1 = uVar6;
    param_1[1] = uVar7;
  }
  else {
    *param_1 = 0xffffffffffffffff;
  }
  return param_1;
}

