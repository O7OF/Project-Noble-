// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::scoreboard::session_names::{closure#0}>,host_probe[b94139f9089eb1d8]::scoreboard::session_names::{closure#1}>>>::from_iter
// address: 0x14004bea0
// body: available
// range: 0x14004bea0-0x14004c216 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14004bfb6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004c141 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::scoreboard::session_names::{closure#0}>,
   host_probe[b94139f9089eb1d8]::scoreboard::session_names::{closure#1}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::scoreboard::session_names::{closure#0}>,host_probe[b94139f9089eb1d8]::scoreboard::session_names::{closure#1}>>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  ulonglong uVar2;
  ulonglong *puVar3;
  code *pcVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined4 *puVar7;
  longlong lVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong *local_d0;
  longlong local_c8;
  ulonglong local_c0;
  undefined1 local_b8;
  longlong local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  longlong local_98;
  longlong *local_90;
  longlong local_88;
  undefined8 local_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 local_70;
  longlong *local_68;
  longlong local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  uVar2 = param_2[2];
  uVar10 = param_2[1];
  if (uVar10 < uVar2) {
    puVar3 = (ulonglong *)*param_2;
    lVar8 = uVar10 * -0xb0 + -0x2b30;
    local_80 = uVar10 * -0xb0 + -0x1708;
    do {
      if ((*puVar3 >> (uVar10 & 0x3f) & 1) != 0) {
        plVar6 = (longlong *)param_2[3];
        lVar9 = *plVar6;
        if (host_probe[b94139f9089eb1d8]::pbx::RELOCATED_0_llvm_10439611301029776152 == '\0') {
          local_80 = lVar9 - lVar8;
        }
        else {
          local_80 = (lVar9 + host_probe[b94139f9089eb1d8]::pbx::DELTA_0_llvm_10439611301029776152)
                     - local_80;
        }
        local_80 = local_80 + 0x20;
        local_d0 = &local_80;
        local_c8 = 0;
        local_c0 = 0x10;
        local_b8 = 0;
        <alloc[246c2e7857c81348]::vec::Vec<u16>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<u16,core[505b25137b8ba7f]::iter::adapters::take_while::TakeWhile<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::scoreboard::utf16_name::{closure#0}>,host_probe[b94139f9089eb1d8]::scoreboard::utf16_name::{closure#1}>>>
        ::from_iter(&local_98,&local_d0);
        plVar5 = local_90;
        local_c8 = (longlong)local_90 + local_88 * 2;
        local_d0 = local_90;
        local_c0 = local_c0 & 0xffffffffffff0000;
        <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::FromIterator<char>>
        ::from_iter::
        <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::char::decode::DecodeUtf16<core[505b25137b8ba7f]::iter::adapters::cloned::Cloned<core[505b25137b8ba7f]::slice::iter::Iter<u16>>>,<alloc[246c2e7857c81348]::string::String>::from_utf16_lossy::_closure_0_>>
                  (&local_58,&local_d0);
        if (local_98 != 0) {
          plVar6 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_dealloc(plVar5,local_98 * 2,2);
          return plVar6;
        }
        if (CONCAT44(uStack_54,local_58) != -1) {
          local_68 = plVar6;
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          puVar7 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
          if (puVar7 == (undefined4 *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
            pcVar4 = (code *)invalidInstructionException();
            (*pcVar4)();
          }
          uVar10 = uVar10 + 1;
          *(undefined8 *)(puVar7 + 4) = local_48;
          *puVar7 = local_58;
          puVar7[1] = uStack_54;
          puVar7[2] = uStack_50;
          puVar7[3] = uStack_4c;
          local_b0 = 4;
          local_a0 = 1;
          local_a8 = puVar7;
          if (uVar2 <= uVar10) goto LAB_14004c1bc;
          goto LAB_14004c044;
        }
        break;
      }
      uVar10 = uVar10 + 1;
      lVar8 = lVar8 + -0xb0;
      local_80 = local_80 + -0xb0;
    } while (uVar2 != uVar10);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
  while( true ) {
    if (lVar8 == local_b0) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_b0,lVar8,1,8,0x18);
      puVar7 = local_a8;
    }
    uVar10 = uVar10 + 1;
    *(undefined8 *)(puVar7 + lVar8 * 6 + 4) = local_70;
    puVar1 = puVar7 + lVar8 * 6;
    *puVar1 = (undefined4)local_80;
    puVar1[1] = local_80._4_4_;
    puVar1[2] = uStack_78;
    puVar1[3] = uStack_74;
    local_a0 = lVar8 + 1;
    if (uVar2 <= uVar10) break;
LAB_14004c044:
    lVar8 = local_a0;
    lVar9 = uVar10 * -0xb0 + -0x2b30;
    local_60 = uVar10 * -0xb0 + -0x1708;
    while ((*puVar3 >> (uVar10 & 0x3f) & 1) == 0) {
      uVar10 = uVar10 + 1;
      lVar9 = lVar9 + -0xb0;
      local_60 = local_60 + -0xb0;
      if (uVar2 == uVar10) goto LAB_14004c1bc;
    }
    if (host_probe[b94139f9089eb1d8]::pbx::RELOCATED_0_llvm_10439611301029776152 == '\0') {
      local_60 = *local_68 - lVar9;
    }
    else {
      local_60 = (*local_68 + host_probe[b94139f9089eb1d8]::pbx::DELTA_0_llvm_10439611301029776152)
                 - local_60;
    }
    local_60 = local_60 + 0x20;
    local_d0 = &local_60;
    local_c8 = 0;
    local_c0 = 0x10;
    local_b8 = 0;
    <alloc[246c2e7857c81348]::vec::Vec<u16>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<u16,core[505b25137b8ba7f]::iter::adapters::take_while::TakeWhile<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::scoreboard::utf16_name::{closure#0}>,host_probe[b94139f9089eb1d8]::scoreboard::utf16_name::{closure#1}>>>
    ::from_iter(&local_98,&local_d0);
    plVar6 = local_90;
    local_c8 = local_88 * 2 + (longlong)local_90;
    local_d0 = local_90;
    local_c0 = local_c0 & 0xffffffffffff0000;
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::FromIterator<char>>
    ::from_iter::
    <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::char::decode::DecodeUtf16<core[505b25137b8ba7f]::iter::adapters::cloned::Cloned<core[505b25137b8ba7f]::slice::iter::Iter<u16>>>,<alloc[246c2e7857c81348]::string::String>::from_utf16_lossy::_closure_0_>>
              (&local_80,&local_d0);
    if (local_98 != 0) {
      plVar6 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_dealloc(plVar6,local_98 * 2,2);
      return plVar6;
    }
    if (local_80 == -1) break;
  }
LAB_14004c1bc:
  param_1[2] = local_a0;
  *param_1 = local_b0;
  param_1[1] = (longlong)local_a8;
  return param_1;
}

