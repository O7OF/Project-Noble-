// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::option::IntoIter<&alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::ModMap>>>,host_probe[b94139f9089eb1d8]::modmaps::names::{closure#0}>>>::from_iter
// address: 0x14004d350
// body: available
// range: 0x14004d350-0x14004d53d inclusive
// range: 0x14004d540-0x14004d5de inclusive
// range: 0x14004d5e0-0x14004d602 inclusive
// range: 0x14004d610-0x14004d70f inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::option::IntoIter<&alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::ModMap>>>,
   host_probe[b94139f9089eb1d8]::modmaps::names::{closure#0}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::option::IntoIter<&alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::ModMap>>>,host_probe[b94139f9089eb1d8]::modmaps::names::{closure#0}>>>
::from_iter(longlong *param_1,byte *param_2)

{
  undefined4 *puVar1;
  byte bVar2;
  code *pcVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 *puVar6;
  longlong lVar7;
  ulonglong uVar8;
  longlong lVar9;
  longlong lVar10;
  longlong unaff_RBP;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  ulonglong uVar14;
  undefined8 uVar15;
  longlong local_a8;
  longlong local_98;
  undefined4 *puStack_90;
  longlong local_88;
  longlong local_80;
  longlong *local_78;
  undefined4 local_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  lVar9 = *(longlong *)(param_2 + 0x10);
  bVar2 = *param_2;
  lVar12 = *(longlong *)(param_2 + 0x18);
  local_a8 = *(longlong *)(param_2 + 8);
  if ((bVar2 & 1) == 0) {
    lVar5 = lVar12;
    if (lVar9 != 0) {
      local_80 = lVar9 + 0x48;
      lVar5 = 0;
      if (lVar9 != lVar12) {
        lVar5 = local_80;
      }
      *(longlong *)(param_2 + 0x10) = lVar5;
      lVar5 = lVar9;
      if (lVar9 != lVar12) goto LAB_14004d428;
    }
LAB_14004d400:
    lVar9 = *(longlong *)(param_2 + 0x20);
    lVar12 = lVar5;
joined_r0x00014004d6dc:
    if (lVar9 == 0) goto LAB_14004d6e2;
    local_80 = 0;
    lVar5 = lVar9 + 0x48;
    if (lVar9 == *(longlong *)(param_2 + 0x28)) {
      lVar5 = local_80;
    }
    *(longlong *)(param_2 + 0x20) = lVar5;
    if (lVar9 == *(longlong *)(param_2 + 0x28)) goto LAB_14004d6e2;
  }
  else if (lVar9 == 0) {
LAB_14004d3bf:
    param_2[8] = 0;
    param_2[9] = 0;
    param_2[10] = 0;
    param_2[0xb] = 0;
    param_2[0xc] = 0;
    param_2[0xd] = 0;
    param_2[0xe] = 0;
    param_2[0xf] = 0;
    if (local_a8 == 0) {
      local_a8 = 0;
      lVar9 = *(longlong *)(param_2 + 0x20);
      goto joined_r0x00014004d6dc;
    }
    lVar9 = *(longlong *)(local_a8 + 8);
    lVar7 = *(longlong *)(local_a8 + 0x10);
    lVar5 = lVar9 + lVar7 * 0x48;
    *(longlong *)(param_2 + 0x18) = lVar5;
    local_80 = lVar9 + 0x48;
    local_a8 = 0;
    lVar12 = 0;
    if (lVar7 != 0) {
      lVar12 = local_80;
    }
    *(longlong *)(param_2 + 0x10) = lVar12;
    lVar12 = lVar5;
    if (lVar7 == 0) goto LAB_14004d400;
  }
  else {
    local_80 = lVar9 + 0x48;
    lVar5 = 0;
    if (lVar9 != lVar12) {
      lVar5 = local_80;
    }
    *(longlong *)(param_2 + 0x10) = lVar5;
    if (lVar9 == lVar12) goto LAB_14004d3bf;
  }
LAB_14004d428:
  <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
            (&local_70,lVar9);
  if (CONCAT44(uStack_6c,local_70) != -1) {
    if (local_80 == 0) {
      lVar5 = 0;
      lVar9 = *(longlong *)(param_2 + 0x20);
    }
    else {
      lVar5 = ((ulonglong)(lVar12 - local_80) >> 3) * -0x71c71c71c71c71c7;
      lVar9 = *(longlong *)(param_2 + 0x20);
    }
    if (lVar9 == 0) {
      lVar7 = 0;
    }
    else {
      lVar7 = ((ulonglong)(*(longlong *)(param_2 + 0x28) - lVar9) >> 3) * -0x71c71c71c71c71c7;
    }
    uVar8 = lVar7 + lVar5;
    uVar14 = 3;
    if (3 < uVar8) {
      uVar14 = uVar8;
    }
    if (uVar8 < 0x555555555555555) {
      unaff_RBP = (uVar14 + 1) * 0x18;
      local_78 = param_1;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar15 = 8;
      puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(unaff_RBP,8);
      if (puVar6 != (undefined4 *)0x0) {
        *(undefined8 *)(puVar6 + 4) = local_60;
        *puVar6 = local_70;
        puVar6[1] = uStack_6c;
        puVar6[2] = uStack_68;
        puVar6[3] = uStack_64;
        local_88 = 1;
        lVar5 = *(longlong *)(param_2 + 0x28);
        lVar10 = 0;
        lVar7 = local_80;
        local_98 = uVar14 + 1;
        puStack_90 = puVar6;
        do {
          lVar4 = local_88;
          lVar11 = lVar7 + 0x48;
          if ((bVar2 & 1) == 0) {
            if (lVar7 == lVar12 || lVar7 == 0) goto LAB_14004d5e4;
          }
          else if (lVar7 == lVar12 || lVar7 == 0) {
            if (local_a8 != 0) {
              lVar7 = *(longlong *)(local_a8 + 8);
              lVar12 = lVar7 + *(longlong *)(local_a8 + 0x10) * 0x48;
              if (*(longlong *)(local_a8 + 0x10) != 0) {
                lVar11 = lVar7 + 0x48;
                local_a8 = 0;
                goto LAB_14004d613;
              }
            }
            local_a8 = 0;
LAB_14004d5e4:
            if ((lVar9 == 0) || (lVar9 == lVar5)) {
LAB_14004d6b6:
              local_78[2] = local_88;
              *local_78 = local_98;
              local_78[1] = (longlong)puStack_90;
              return local_78;
            }
            lVar11 = 0;
            lVar7 = lVar9;
            lVar9 = lVar9 + 0x48;
          }
LAB_14004d613:
          <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                    (&local_58,lVar7);
          if (CONCAT44(uStack_54,local_58) == -1) goto LAB_14004d6b6;
          if (lVar4 == local_98) {
            if (lVar11 == 0) {
              lVar7 = 1;
              if (lVar9 == 0) goto LAB_14004d680;
LAB_14004d540:
              lVar13 = ((ulonglong)(lVar5 - lVar9) >> 3) * -0x71c71c71c71c71c7;
            }
            else {
              lVar7 = ((ulonglong)(lVar12 - lVar11) >> 3) * -0x71c71c71c71c71c7 + 1;
              if (lVar9 != 0) goto LAB_14004d540;
LAB_14004d680:
              lVar13 = 0;
            }
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
            <alloc[246c2e7857c81348]::alloc::Global>(&local_98,lVar4,lVar13 + lVar7,8,0x18);
            puVar6 = puStack_90;
          }
          *(undefined8 *)(lVar10 + 0x28 + (longlong)puVar6) = local_48;
          puVar1 = (undefined4 *)(lVar10 + 0x18 + (longlong)puVar6);
          *puVar1 = local_58;
          puVar1[1] = uStack_54;
          puVar1[2] = uStack_50;
          puVar1[3] = uStack_4c;
          local_88 = lVar4 + 1;
          lVar10 = lVar10 + 0x18;
          lVar7 = lVar11;
        } while( true );
      }
    }
    else {
      uVar15 = 0;
    }
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar15,unaff_RBP);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
LAB_14004d6e2:
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

