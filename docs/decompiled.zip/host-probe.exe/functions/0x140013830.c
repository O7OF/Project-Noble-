// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill
// address: 0x140013830
// body: available
// range: 0x140013830-0x1400138eb inclusive
// range: 0x1400138f0-0x1400139ea inclusive
// range: 0x1400139f0-0x140013a9e inclusive
// range: 0x140013aa0-0x140013af8 inclusive
// range: 0x140013aff-0x140013c15 inclusive
// range: 0x140013c17-0x140013c2a inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140013af4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140013c11 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill
          (undefined8 *param_1,longlong param_2,longlong param_3,void *param_4,size_t param_5,
          undefined8 param_6,undefined4 param_7)

{
  code *pcVar1;
  int iVar2;
  void *_Dst;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  longlong lVar13;
  ulonglong uVar14;
  undefined8 local_b0;
  undefined4 local_a8;
  longlong local_a0;
  longlong local_98;
  longlong local_90;
  longlong *local_88;
  longlong local_80;
  undefined8 *local_78;
  longlong local_70;
  longlong local_68;
  ulonglong local_60;
  undefined1 local_58 [24];
  
  local_b0 = param_6;
  local_a8 = param_7;
  uVar3 = *(ulonglong *)(param_2 + 0x50);
  uVar12 = *(ulonglong *)(param_2 + 0x38);
  uVar7 = *(ulonglong *)(param_2 + 0x48);
  local_a0 = param_3;
  if (uVar3 == 0) {
    lVar4 = *(longlong *)(param_2 + 0x40);
  }
  else {
    uVar8 = uVar12;
    if (uVar7 < uVar12) {
      uVar8 = 0;
    }
    uVar6 = uVar7 - uVar8;
    uVar14 = uVar12 - uVar6;
    uVar10 = (uVar3 - uVar14) * 0x20;
    if (uVar3 <= uVar14) {
      uVar10 = 0;
    }
    uVar5 = uVar6 + uVar3;
    if (uVar14 < uVar3) {
      uVar5 = uVar12;
    }
    lVar4 = *(longlong *)(param_2 + 0x40);
    if (uVar6 != uVar5) {
      lVar13 = uVar7 * 0x20 + uVar8 * -0x20 + lVar4;
      if (uVar3 < uVar14) {
        uVar14 = uVar3;
      }
      lVar9 = 0;
      do {
        if (((*(longlong *)(lVar13 + lVar9) == param_3) &&
            (*(size_t *)(lVar13 + 0x18 + lVar9) == param_5)) &&
           (iVar2 = memcmp(*(void **)(lVar13 + 0x10 + lVar9),param_4,param_5), iVar2 == 0))
        goto LAB_140013a20;
        lVar9 = lVar9 + 0x20;
      } while (uVar14 * 0x20 != lVar9);
    }
    if (uVar10 != 0) {
      uVar8 = 0;
      do {
        if (((*(longlong *)(lVar4 + uVar8) == param_3) &&
            (*(size_t *)(lVar4 + 0x18 + uVar8) == param_5)) &&
           (iVar2 = memcmp(*(void **)(lVar4 + 0x10 + uVar8),param_4,param_5), iVar2 == 0)) {
LAB_140013a20:
          *param_1 = 0;
          param_1[1] = 8;
          param_1[2] = 0;
          return;
        }
        uVar8 = uVar8 + 0x20;
      } while (uVar10 != uVar8);
    }
  }
  if (-1 < (longlong)param_5) {
    if (param_5 == 0) {
      _Dst = (void *)0x1;
    }
    else {
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar11 = 1;
      _Dst = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(param_5,1);
      if (_Dst == (void *)0x0) goto LAB_140013944;
      memcpy(_Dst,param_4,param_5);
    }
    if (uVar3 == uVar12) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::string::String)>>
      ::grow();
      uVar3 = *(ulonglong *)(param_2 + 0x50);
      uVar12 = *(ulonglong *)(param_2 + 0x38);
      lVar4 = *(longlong *)(param_2 + 0x40);
      uVar7 = *(ulonglong *)(param_2 + 0x48);
    }
    *(ulonglong *)(param_2 + 0x50) = uVar3 + 1;
    uVar8 = 0;
    if (uVar12 <= uVar7 + uVar3) {
      uVar8 = uVar12;
    }
    lVar13 = ((uVar7 + uVar3) - uVar8) * 0x20;
    *(longlong *)(lVar4 + lVar13) = param_3;
    *(size_t *)(lVar4 + 8 + lVar13) = param_5;
    *(void **)(lVar4 + 0x10 + lVar13) = _Dst;
    *(size_t *)(lVar4 + 0x18 + lVar13) = param_5;
    uVar3 = *(ulonglong *)(param_2 + 0x50);
    if (0x100 < uVar3) {
      do {
        lVar4 = *(longlong *)(param_2 + 0x48);
        uVar12 = *(ulonglong *)(param_2 + 0x38);
        if (lVar4 + 1U < *(ulonglong *)(param_2 + 0x38)) {
          uVar12 = 0;
        }
        *(ulonglong *)(param_2 + 0x48) = (lVar4 - uVar12) + 1;
        uVar3 = uVar3 - 1;
        *(ulonglong *)(param_2 + 0x50) = uVar3;
        lVar13 = *(longlong *)(*(longlong *)(param_2 + 0x40) + 8 + lVar4 * 0x20);
        if (lVar13 - 1U < 0xfffffffffffffffe) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc
                    (*(undefined8 *)(*(longlong *)(param_2 + 0x40) + lVar4 * 0x20 + 0x10),lVar13,1);
          return;
        }
      } while (0x100 < uVar3);
    }
    uVar3 = *(ulonglong *)(param_2 + 0x30);
    if (uVar3 == 0) {
      lVar4 = 0;
      uVar12 = 0;
      lVar13 = 0;
    }
    else {
      uVar12 = *(ulonglong *)(param_2 + 0x18);
      uVar7 = 0;
      if (uVar12 <= *(ulonglong *)(param_2 + 0x28)) {
        uVar7 = uVar12;
      }
      lVar4 = *(ulonglong *)(param_2 + 0x28) - uVar7;
      lVar13 = uVar3 - (uVar12 - lVar4);
      if (uVar3 < uVar12 - lVar4 || lVar13 == 0) {
        uVar12 = uVar3 + lVar4;
        lVar13 = 0;
      }
    }
    local_88 = *(longlong **)(param_2 + 0x20);
    local_98 = lVar4 * 0x80 + (longlong)local_88;
    local_90 = uVar12 * 0x80 + (longlong)local_88;
    local_80 = lVar13 * 0x80 + (longlong)local_88;
    local_78 = &local_b0;
    <alloc[246c2e7857c81348]::vec::Vec<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant),core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill::{closure#1}>>>
    ::from_iter(&local_70,&local_98);
    local_90 = local_68 + local_60 * 8;
    lVar4 = 0;
    if (9 < local_60) {
      lVar4 = local_60 - 10;
    }
    local_98 = local_68 + lVar4 * 8;
    local_88 = &local_a0;
    <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill::{closure#2}>>>
    ::from_iter(local_58,&local_98);
    deliver(param_1,param_2,local_58,local_b0,local_a8);
    if (local_70 == 0) {
      return;
    }
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_68,local_70 << 3,8);
    return;
  }
  uVar11 = 0;
LAB_140013944:
  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar11,param_5);
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

