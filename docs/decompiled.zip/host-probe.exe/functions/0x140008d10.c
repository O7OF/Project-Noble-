// rea decompile_all
// name: <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::iter::adapters::rev::Rev<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold::<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::iter::adapters::rev::Rev<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>>::{closure#0}>::{closure#0}>
// address: 0x140008d10
// body: available
// range: 0x140008d10-0x140008f2f inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::iter::adapters::rev::Rev<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>
   as core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold::<(),
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,
   <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::iter::adapters::rev::Rev<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>>::{closure#0}>::{closure#0}>
    */

void __rustcall
<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::iter::adapters::rev::Rev<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
::fold::
<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<u8,<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::iter::adapters::rev::Rev<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>>::_closure_0_>::_closure_0_>
          (ulonglong param_1,ulonglong param_2,undefined8 *param_3)

{
  undefined1 *puVar1;
  longlong lVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  short sVar7;
  short sVar8;
  short sVar9;
  short sVar10;
  short sVar11;
  short sVar12;
  short sVar13;
  short sVar14;
  short sVar15;
  short sVar16;
  short sVar17;
  short sVar18;
  short sVar19;
  short sVar20;
  short sVar21;
  short sVar22;
  short sVar23;
  short sVar24;
  short sVar25;
  short sVar26;
  short sVar27;
  short sVar28;
  short sVar29;
  short sVar30;
  short sVar31;
  short sVar32;
  short sVar33;
  short sVar34;
  undefined1 auVar35 [15];
  undefined1 auVar36 [15];
  undefined1 auVar37 [15];
  undefined1 auVar38 [15];
  undefined1 auVar39 [15];
  undefined1 auVar40 [15];
  undefined1 auVar41 [15];
  undefined1 auVar42 [15];
  undefined1 auVar43 [15];
  undefined1 auVar44 [15];
  undefined1 auVar45 [15];
  undefined1 auVar46 [15];
  undefined1 auVar47 [15];
  undefined1 auVar48 [15];
  undefined1 auVar49 [15];
  undefined1 auVar50 [15];
  undefined1 auVar51 [15];
  undefined1 auVar52 [15];
  undefined1 auVar53 [15];
  undefined1 auVar54 [15];
  undefined1 auVar55 [15];
  undefined1 auVar56 [15];
  undefined1 auVar57 [15];
  undefined1 auVar58 [15];
  undefined1 auVar59 [15];
  undefined1 auVar60 [11];
  undefined1 auVar61 [15];
  undefined1 auVar62 [11];
  undefined1 auVar63 [15];
  undefined1 auVar64 [11];
  undefined1 auVar65 [15];
  undefined1 auVar66 [15];
  undefined1 auVar67 [15];
  undefined1 auVar68 [15];
  undefined1 auVar69 [15];
  undefined1 auVar70 [15];
  ulonglong uVar71;
  longlong lVar72;
  longlong lVar73;
  uint uVar74;
  ulonglong uVar75;
  ulonglong uVar76;
  ulonglong uVar77;
  char *pcVar78;
  undefined8 *puVar79;
  longlong lVar80;
  undefined1 auVar81 [11];
  undefined1 auVar83 [16];
  undefined1 auVar84 [11];
  undefined1 auVar86 [16];
  undefined1 auVar87 [16];
  undefined1 auVar88 [16];
  undefined1 auVar89 [16];
  undefined1 auVar82 [15];
  undefined1 auVar85 [15];
  
  if (param_1 == param_2) {
    lVar72 = param_3[1];
    goto LAB_140008dda;
  }
  lVar73 = param_3[1];
  lVar2 = param_3[2];
  uVar77 = param_2 - param_1;
  lVar72 = lVar73;
  uVar76 = param_2;
  if ((7 < uVar77) &&
     ((param_2 <= (ulonglong)(lVar2 + lVar73) || (((lVar73 + param_2) - param_1) + lVar2 <= param_1)
      ))) {
    if (uVar77 < 0x20) {
      uVar75 = 0;
    }
    else {
      uVar75 = uVar77 & 0xffffffffffffffe0;
      lVar72 = lVar73 + uVar75;
      pcVar78 = (char *)(lVar73 + lVar2 + 0x10);
      lVar80 = 0;
      do {
        auVar83 = *(undefined1 (*) [16])((param_2 - 0x20) + lVar80);
        auVar86 = *(undefined1 (*) [16])((param_2 - 0x10) + lVar80);
        auVar35[0xd] = 0;
        auVar35._0_13_ = auVar86._0_13_;
        auVar35[0xe] = auVar86[7];
        auVar38[0xc] = auVar86[6];
        auVar38._0_12_ = auVar86._0_12_;
        auVar38._13_2_ = auVar35._13_2_;
        auVar41[0xb] = 0;
        auVar41._0_11_ = auVar86._0_11_;
        auVar41._12_3_ = auVar38._12_3_;
        auVar44[10] = auVar86[5];
        auVar44._0_10_ = auVar86._0_10_;
        auVar44._11_4_ = auVar41._11_4_;
        auVar47[9] = 0;
        auVar47._0_9_ = auVar86._0_9_;
        auVar47._10_5_ = auVar44._10_5_;
        auVar50[8] = auVar86[4];
        auVar50._0_8_ = auVar86._0_8_;
        auVar50._9_6_ = auVar47._9_6_;
        auVar88[7] = 0;
        auVar88._0_7_ = auVar50._8_7_;
        auVar59._7_8_ = 0;
        auVar59._0_7_ = auVar50._8_7_;
        auVar65._1_8_ = SUB158(auVar59 << 0x40,7);
        auVar65[0] = auVar86[3];
        auVar65._9_6_ = 0;
        auVar60._1_10_ = SUB1510(auVar65 << 0x30,5);
        auVar60[0] = auVar86[2];
        auVar66._11_4_ = 0;
        auVar66._0_11_ = auVar60;
        auVar53[2] = auVar86[1];
        auVar53._0_2_ = auVar86._0_2_;
        auVar53._3_12_ = SUB1512(auVar66 << 0x20,3);
        auVar56._2_13_ = auVar53._2_13_;
        auVar56._0_2_ = auVar86._0_2_ & 0xff;
        auVar88._8_4_ = auVar56._0_4_;
        auVar88._12_4_ = auVar60._0_4_;
        auVar87 = pshuflw(auVar88,auVar88,0x1b);
        auVar88 = pshufhw(auVar87,auVar87,0x1b);
        auVar87[8] = auVar86[8];
        auVar87[9] = 0;
        auVar87[10] = auVar86[9];
        auVar84._0_10_ = (unkuint10)auVar86[0xc] << 0x40;
        auVar84[10] = auVar86[0xd];
        auVar85[0xb] = 0;
        auVar85._0_11_ = auVar84;
        auVar85[0xc] = auVar86[0xe];
        auVar85[0xd] = 0;
        auVar85[0xe] = auVar86[0xf];
        auVar87[3] = 0;
        auVar87._0_3_ = auVar84._8_3_;
        auVar87._4_3_ = auVar85._12_3_;
        auVar87[7] = 0;
        auVar87[0xb] = 0;
        auVar87._12_3_ = (int3)(CONCAT16(auVar86[0xb],(uint6)auVar86[10] << 0x20) >> 0x20);
        auVar87[0xf] = 0;
        auVar86 = pshuflw(auVar87,auVar87,0x1b);
        auVar87 = pshufhw(auVar86,auVar86,0x1b);
        sVar4 = auVar87._0_2_;
        sVar5 = auVar87._2_2_;
        sVar7 = auVar87._4_2_;
        sVar9 = auVar87._6_2_;
        sVar11 = auVar87._8_2_;
        sVar13 = auVar87._10_2_;
        sVar15 = auVar87._12_2_;
        sVar17 = auVar87._14_2_;
        sVar19 = auVar88._0_2_;
        sVar21 = auVar88._2_2_;
        sVar23 = auVar88._4_2_;
        sVar25 = auVar88._6_2_;
        sVar27 = auVar88._8_2_;
        sVar29 = auVar88._10_2_;
        sVar31 = auVar88._12_2_;
        sVar33 = auVar88._14_2_;
        auVar36[0xd] = 0;
        auVar36._0_13_ = auVar83._0_13_;
        auVar36[0xe] = auVar83[7];
        auVar39[0xc] = auVar83[6];
        auVar39._0_12_ = auVar83._0_12_;
        auVar39._13_2_ = auVar36._13_2_;
        auVar42[0xb] = 0;
        auVar42._0_11_ = auVar83._0_11_;
        auVar42._12_3_ = auVar39._12_3_;
        auVar45[10] = auVar83[5];
        auVar45._0_10_ = auVar83._0_10_;
        auVar45._11_4_ = auVar42._11_4_;
        auVar48[9] = 0;
        auVar48._0_9_ = auVar83._0_9_;
        auVar48._10_5_ = auVar45._10_5_;
        auVar51[8] = auVar83[4];
        auVar51._0_8_ = auVar83._0_8_;
        auVar51._9_6_ = auVar48._9_6_;
        auVar89[7] = 0;
        auVar89._0_7_ = auVar51._8_7_;
        auVar61._7_8_ = 0;
        auVar61._0_7_ = auVar51._8_7_;
        auVar67._1_8_ = SUB158(auVar61 << 0x40,7);
        auVar67[0] = auVar83[3];
        auVar67._9_6_ = 0;
        auVar62._1_10_ = SUB1510(auVar67 << 0x30,5);
        auVar62[0] = auVar83[2];
        auVar68._11_4_ = 0;
        auVar68._0_11_ = auVar62;
        auVar54[2] = auVar83[1];
        auVar54._0_2_ = auVar83._0_2_;
        auVar54._3_12_ = SUB1512(auVar68 << 0x20,3);
        auVar57._2_13_ = auVar54._2_13_;
        auVar57._0_2_ = auVar83._0_2_ & 0xff;
        auVar89._8_4_ = auVar57._0_4_;
        auVar89._12_4_ = auVar62._0_4_;
        auVar86 = pshuflw(auVar89,auVar89,0x1b);
        auVar89 = pshufhw(auVar86,auVar86,0x1b);
        auVar86[8] = auVar83[8];
        auVar86[9] = 0;
        auVar86[10] = auVar83[9];
        auVar81._0_10_ = (unkuint10)auVar83[0xc] << 0x40;
        auVar81[10] = auVar83[0xd];
        auVar82[0xb] = 0;
        auVar82._0_11_ = auVar81;
        auVar82[0xc] = auVar83[0xe];
        auVar82[0xd] = 0;
        auVar82[0xe] = auVar83[0xf];
        auVar86[3] = 0;
        auVar86._0_3_ = auVar81._8_3_;
        auVar86._4_3_ = auVar82._12_3_;
        auVar86[7] = 0;
        auVar86[0xb] = 0;
        auVar86._12_3_ = (int3)(CONCAT16(auVar83[0xb],(uint6)auVar83[10] << 0x20) >> 0x20);
        auVar86[0xf] = 0;
        auVar83 = pshuflw(auVar86,auVar86,0x1b);
        auVar83 = pshufhw(auVar83,auVar83,0x1b);
        sVar3 = auVar83._0_2_;
        sVar6 = auVar83._2_2_;
        sVar8 = auVar83._4_2_;
        sVar10 = auVar83._6_2_;
        sVar12 = auVar83._8_2_;
        sVar14 = auVar83._10_2_;
        sVar16 = auVar83._12_2_;
        sVar18 = auVar83._14_2_;
        sVar20 = auVar89._0_2_;
        sVar22 = auVar89._2_2_;
        sVar24 = auVar89._4_2_;
        sVar26 = auVar89._6_2_;
        sVar28 = auVar89._8_2_;
        sVar30 = auVar89._10_2_;
        sVar32 = auVar89._12_2_;
        sVar34 = auVar89._14_2_;
        pcVar78[-0x10] = (0 < sVar4) * (sVar4 < 0x100) * auVar87[0] - (0xff < sVar4);
        pcVar78[-0xf] = (0 < sVar5) * (sVar5 < 0x100) * auVar87[2] - (0xff < sVar5);
        pcVar78[-0xe] = (0 < sVar7) * (sVar7 < 0x100) * auVar87[4] - (0xff < sVar7);
        pcVar78[-0xd] = (0 < sVar9) * (sVar9 < 0x100) * auVar87[6] - (0xff < sVar9);
        pcVar78[-0xc] = (0 < sVar11) * (sVar11 < 0x100) * auVar87[8] - (0xff < sVar11);
        pcVar78[-0xb] = (0 < sVar13) * (sVar13 < 0x100) * auVar87[10] - (0xff < sVar13);
        pcVar78[-10] = (0 < sVar15) * (sVar15 < 0x100) * auVar87[0xc] - (0xff < sVar15);
        pcVar78[-9] = (0 < sVar17) * (sVar17 < 0x100) * auVar87[0xe] - (0xff < sVar17);
        pcVar78[-8] = (0 < sVar19) * (sVar19 < 0x100) * auVar88[0] - (0xff < sVar19);
        pcVar78[-7] = (0 < sVar21) * (sVar21 < 0x100) * auVar88[2] - (0xff < sVar21);
        pcVar78[-6] = (0 < sVar23) * (sVar23 < 0x100) * auVar88[4] - (0xff < sVar23);
        pcVar78[-5] = (0 < sVar25) * (sVar25 < 0x100) * auVar88[6] - (0xff < sVar25);
        pcVar78[-4] = (0 < sVar27) * (sVar27 < 0x100) * auVar88[8] - (0xff < sVar27);
        pcVar78[-3] = (0 < sVar29) * (sVar29 < 0x100) * auVar88[10] - (0xff < sVar29);
        pcVar78[-2] = (0 < sVar31) * (sVar31 < 0x100) * auVar88[0xc] - (0xff < sVar31);
        pcVar78[-1] = (0 < sVar33) * (sVar33 < 0x100) * auVar88[0xe] - (0xff < sVar33);
        *pcVar78 = (0 < sVar3) * (sVar3 < 0x100) * auVar83[0] - (0xff < sVar3);
        pcVar78[1] = (0 < sVar6) * (sVar6 < 0x100) * auVar83[2] - (0xff < sVar6);
        pcVar78[2] = (0 < sVar8) * (sVar8 < 0x100) * auVar83[4] - (0xff < sVar8);
        pcVar78[3] = (0 < sVar10) * (sVar10 < 0x100) * auVar83[6] - (0xff < sVar10);
        pcVar78[4] = (0 < sVar12) * (sVar12 < 0x100) * auVar83[8] - (0xff < sVar12);
        pcVar78[5] = (0 < sVar14) * (sVar14 < 0x100) * auVar83[10] - (0xff < sVar14);
        pcVar78[6] = (0 < sVar16) * (sVar16 < 0x100) * auVar83[0xc] - (0xff < sVar16);
        pcVar78[7] = (0 < sVar18) * (sVar18 < 0x100) * auVar83[0xe] - (0xff < sVar18);
        pcVar78[8] = (0 < sVar20) * (sVar20 < 0x100) * auVar89[0] - (0xff < sVar20);
        pcVar78[9] = (0 < sVar22) * (sVar22 < 0x100) * auVar89[2] - (0xff < sVar22);
        pcVar78[10] = (0 < sVar24) * (sVar24 < 0x100) * auVar89[4] - (0xff < sVar24);
        pcVar78[0xb] = (0 < sVar26) * (sVar26 < 0x100) * auVar89[6] - (0xff < sVar26);
        pcVar78[0xc] = (0 < sVar28) * (sVar28 < 0x100) * auVar89[8] - (0xff < sVar28);
        pcVar78[0xd] = (0 < sVar30) * (sVar30 < 0x100) * auVar89[10] - (0xff < sVar30);
        pcVar78[0xe] = (0 < sVar32) * (sVar32 < 0x100) * auVar89[0xc] - (0xff < sVar32);
        pcVar78[0xf] = (0 < sVar34) * (sVar34 < 0x100) * auVar89[0xe] - (0xff < sVar34);
        pcVar78 = pcVar78 + 0x20;
        lVar80 = lVar80 + -0x20;
      } while (-lVar80 != uVar75);
      if (uVar77 == uVar75) goto LAB_140008dda;
      uVar76 = param_2 - uVar75;
      if ((uVar77 & 0x18) == 0) goto LAB_140008d5a;
    }
    uVar71 = uVar77 & 0xfffffffffffffff8;
    lVar72 = lVar73 + uVar71;
    puVar79 = (undefined8 *)(uVar75 + lVar73 + lVar2);
    lVar73 = -uVar75;
    do {
      uVar76 = *(ulonglong *)((param_2 - 8) + lVar73);
      auVar37._8_6_ = 0;
      auVar37._0_8_ = uVar76;
      auVar37[0xe] = (char)(uVar76 >> 0x38);
      auVar40._8_4_ = 0;
      auVar40._0_8_ = uVar76;
      auVar40[0xc] = (char)(uVar76 >> 0x30);
      auVar40._13_2_ = auVar37._13_2_;
      auVar43._8_4_ = 0;
      auVar43._0_8_ = uVar76;
      auVar43._12_3_ = auVar40._12_3_;
      auVar46._8_2_ = 0;
      auVar46._0_8_ = uVar76;
      auVar46[10] = (char)(uVar76 >> 0x28);
      auVar46._11_4_ = auVar43._11_4_;
      auVar49._8_2_ = 0;
      auVar49._0_8_ = uVar76;
      auVar49._10_5_ = auVar46._10_5_;
      auVar52[8] = (char)(uVar76 >> 0x20);
      auVar52._0_8_ = uVar76;
      auVar52._9_6_ = auVar49._9_6_;
      auVar83[7] = 0;
      auVar83._0_7_ = auVar52._8_7_;
      auVar63._7_8_ = 0;
      auVar63._0_7_ = auVar52._8_7_;
      auVar69._1_8_ = SUB158(auVar63 << 0x40,7);
      auVar69[0] = (char)(uVar76 >> 0x18);
      auVar69._9_6_ = 0;
      auVar64._1_10_ = SUB1510(auVar69 << 0x30,5);
      auVar64[0] = (char)(uVar76 >> 0x10);
      auVar70._11_4_ = 0;
      auVar70._0_11_ = auVar64;
      auVar55[2] = (char)(uVar76 >> 8);
      auVar55._0_2_ = (ushort)uVar76;
      auVar55._3_12_ = SUB1512(auVar70 << 0x20,3);
      auVar58._2_13_ = auVar55._2_13_;
      auVar58._0_2_ = (ushort)uVar76 & 0xff;
      auVar83._8_4_ = auVar58._0_4_;
      auVar83._12_4_ = auVar64._0_4_;
      auVar83 = pshuflw(auVar83,auVar83,0x1b);
      auVar83 = pshufhw(auVar83,auVar83,0x1b);
      sVar4 = auVar83._0_2_;
      sVar3 = auVar83._2_2_;
      sVar5 = auVar83._4_2_;
      sVar6 = auVar83._6_2_;
      sVar7 = auVar83._8_2_;
      sVar8 = auVar83._10_2_;
      sVar9 = auVar83._12_2_;
      sVar10 = auVar83._14_2_;
      *puVar79 = CONCAT17((0 < sVar10) * (sVar10 < 0x100) * auVar83[0xe] - (0xff < sVar10),
                          CONCAT16((0 < sVar9) * (sVar9 < 0x100) * auVar83[0xc] - (0xff < sVar9),
                                   CONCAT15((0 < sVar8) * (sVar8 < 0x100) * auVar83[10] -
                                            (0xff < sVar8),
                                            CONCAT14((0 < sVar7) * (sVar7 < 0x100) * auVar83[8] -
                                                     (0xff < sVar7),
                                                     CONCAT13((0 < sVar6) * (sVar6 < 0x100) *
                                                              auVar83[6] - (0xff < sVar6),
                                                              CONCAT12((0 < sVar5) * (sVar5 < 0x100)
                                                                       * auVar83[4] - (0xff < sVar5)
                                                                       ,CONCAT11((0 < sVar3) *
                                                                                 (sVar3 < 0x100) *
                                                                                 auVar83[2] -
                                                                                 (0xff < sVar3),
                                                                                 (0 < sVar4) *
                                                                                 (sVar4 < 0x100) *
                                                                                 auVar83[0] -
                                                                                 (0xff < sVar4))))))
                                  ));
      puVar79 = puVar79 + 1;
      lVar73 = lVar73 + -8;
    } while (-lVar73 != uVar71);
    uVar76 = param_2 - uVar71;
    if (uVar77 == uVar71) goto LAB_140008dda;
  }
LAB_140008d5a:
  uVar74 = (int)uVar76 - (int)param_1 & 3;
  uVar75 = (ulonglong)uVar74;
  uVar77 = uVar76;
  if (uVar74 != 0) {
    do {
      puVar1 = (undefined1 *)(uVar77 - 1);
      uVar77 = uVar77 - 1;
      *(undefined1 *)(lVar2 + lVar72) = *puVar1;
      lVar72 = lVar72 + 1;
      uVar75 = uVar75 - 1;
    } while (uVar75 != 0);
  }
  if (param_1 - uVar76 < 0xfffffffffffffffd) {
    do {
      *(undefined1 *)(lVar2 + lVar72) = *(undefined1 *)(uVar77 - 1);
      *(undefined1 *)(lVar2 + 1 + lVar72) = *(undefined1 *)(uVar77 - 2);
      *(undefined1 *)(lVar2 + 2 + lVar72) = *(undefined1 *)(uVar77 - 3);
      puVar1 = (undefined1 *)(uVar77 - 4);
      uVar77 = uVar77 - 4;
      *(undefined1 *)(lVar2 + 3 + lVar72) = *puVar1;
      lVar72 = lVar72 + 4;
    } while (uVar77 != param_1);
  }
LAB_140008dda:
  *(longlong *)*param_3 = lVar72;
  return;
}

