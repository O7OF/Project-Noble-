// rea decompile_all
// name: <core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u64,host_probe[b94139f9089eb1d8]::net::Route>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::next
// address: 0x1400412e0
// body: available
// range: 0x1400412e0-0x140041353 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u64,
   host_probe[b94139f9089eb1d8]::net::Route>> as
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::next */

undefined8 __rustcall
<core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u64,host_probe[b94139f9089eb1d8]::net::Route>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
::next(longlong *param_1)

{
  undefined1 auVar1 [16];
  longlong lVar2;
  ushort uVar3;
  uint uVar4;
  undefined1 (*pauVar5) [16];
  
  if (param_1[4] != 0) {
    uVar3 = *(ushort *)(param_1 + 3);
    lVar2 = *param_1;
    if (uVar3 == 0) {
      pauVar5 = (undefined1 (*) [16])param_1[1];
      do {
        auVar1 = *pauVar5;
        lVar2 = lVar2 + -0x500;
        pauVar5 = pauVar5 + 1;
        uVar3 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) | (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                 (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
      } while (uVar3 == 0);
      param_1[1] = (longlong)pauVar5;
      *param_1 = lVar2;
    }
    for (uVar4 = (uint)uVar3; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
    }
    *(ushort *)(param_1 + 3) = uVar3 - 1 & uVar3;
    param_1[4] = param_1[4] + -1;
    return 1;
  }
  return 0;
}

