// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::accept
// address: 0x14000e960
// body: available
// range: 0x14000e960-0x14000ea07 inclusive
// range: 0x14000ea0d-0x14000ebc6 inclusive
// range: 0x14000ebd0-0x14000ec3d inclusive
// range: 0x14000ec40-0x14000ede1 inclusive
// range: 0x14000edf0-0x14000ef26 inclusive
// range: 0x14000ef30-0x14000ef92 inclusive
// range: 0x14000efa0-0x14000f07f inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000ea03 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000ea9b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000eb2a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000f047 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::accept */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::accept
          (longlong param_1,longlong *param_2,undefined8 param_3,undefined4 param_4)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  size_t _Size;
  code *pcVar4;
  void *pvVar5;
  int iVar6;
  ulonglong uVar7;
  longlong lVar8;
  longlong *plVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  longlong lVar12;
  ulonglong uVar13;
  longlong lVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  bool bVar21;
  longlong local_188;
  void *pvStack_180;
  size_t local_178;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 local_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 local_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  longlong local_148;
  longlong lStack_140;
  longlong local_138;
  longlong lStack_130;
  longlong local_128;
  longlong lStack_120;
  undefined8 local_118;
  undefined8 uStack_110;
  undefined8 local_108;
  undefined8 uStack_100;
  undefined8 local_f8;
  longlong local_f0;
  undefined8 local_e8;
  undefined8 local_e0;
  undefined1 local_b8 [120];
  
  cVar3 = (char)*param_2;
  if (cVar3 == '\x03') {
    plVar9 = (longlong *)(ulonglong)*(uint *)((longlong)param_2 + 4);
    bVar21 = true;
    lVar8 = *(longlong *)(param_1 + 0x288);
  }
  else if (cVar3 == '\x01') {
    if (*(byte *)((longlong)param_2 + 2) < 3) goto LAB_14000ef4b;
    plVar9 = (longlong *)param_2[0xb];
    _Size = param_2[0xc];
    reach_directory[4b72b9694f6c3c08]::chat::clean(&local_188,plVar9,_Size);
    pvVar5 = pvStack_180;
    lVar8 = local_188;
    if (local_188 == -1) goto LAB_14000ef4b;
    if ((local_178 != _Size) || (iVar6 = memcmp(pvStack_180,plVar9,_Size), iVar6 != 0)) {
      if (lVar8 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(pvStack_180,lVar8,1);
        return;
      }
      goto LAB_14000ef4b;
    }
    if (lVar8 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar5,lVar8,1);
      return;
    }
    bVar21 = param_2[3] == *(longlong *)(param_1 + 0x3b8);
    if (bVar21) {
      plVar9 = (longlong *)(ulonglong)*(uint *)((longlong)param_2 + 4);
    }
    lVar8 = *(longlong *)(param_1 + 0x288);
  }
  else {
    bVar21 = false;
    lVar8 = *(longlong *)(param_1 + 0x288);
    plVar9 = param_2;
  }
  if ((lVar8 != -1) && ((bool)(bVar21 & *(int *)(param_1 + 0x330) == (int)plVar9))) {
    memcpy(&local_e8,(void *)(param_1 + 0x290),0xa8);
    *(undefined8 *)(param_1 + 0x288) = 0xffffffffffffffff;
    local_f0 = lVar8;
    if (*(longlong *)(param_1 + 600) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (*(undefined8 *)(param_1 + 0x260),*(longlong *)(param_1 + 600),1);
      return;
    }
    *(undefined8 *)(param_1 + 0x268) = local_e0;
    *(longlong *)(param_1 + 600) = lVar8;
    *(undefined8 *)(param_1 + 0x260) = local_e8;
    core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
              (local_b8);
    if (cVar3 == '\x03') {
      local_188 = param_2[2];
      pvStack_180 = (void *)(param_2[3] + local_188);
      local_178 = 200;
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::FromIterator<char>>
      ::from_iter::
      <core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::str::iter::Chars>>
                (&local_108,&local_188);
      lVar8 = *(longlong *)(param_1 + 0x270);
    }
    else {
      local_108 = 0;
      uStack_100 = 1;
      local_f8 = 0;
      lVar8 = *(longlong *)(param_1 + 0x270);
    }
    if (lVar8 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(*(undefined8 *)(param_1 + 0x278),lVar8,1);
      return;
    }
    *(undefined8 *)(param_1 + 0x280) = local_f8;
    *(undefined8 *)(param_1 + 0x270) = local_108;
    *(undefined8 *)(param_1 + 0x278) = uStack_100;
  }
  if (cVar3 != '\x01') {
LAB_14000ef4b:
    core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
              (param_2);
    return;
  }
  uVar7 = *(ulonglong *)(param_1 + 0x218);
  uVar15 = *(ulonglong *)(param_1 + 0x228);
  uVar17 = *(ulonglong *)(param_1 + 0x230);
  local_118 = param_3;
  if (uVar17 != 0) {
    uVar20 = uVar7;
    if (uVar15 < uVar7) {
      uVar20 = 0;
    }
    uVar19 = uVar15 - uVar20;
    uVar11 = uVar7 - uVar19;
    uVar16 = (uVar17 - uVar11) * 0x80;
    if (uVar17 <= uVar11) {
      uVar16 = 0;
    }
    uVar18 = uVar19 + uVar17;
    if (uVar11 < uVar17) {
      uVar18 = uVar7;
    }
    lVar8 = *(longlong *)(param_1 + 0x220);
    if (uVar19 != uVar18) {
      lVar12 = lVar8 + uVar15 * 0x80 + uVar20 * -0x80;
      if (uVar17 < uVar11) {
        uVar11 = uVar17;
      }
      lVar14 = 0;
      do {
        if ((*(char *)(lVar12 + lVar14) == '\x01') &&
           (*(longlong *)(lVar12 + 0x10 + lVar14) == param_2[2])) goto LAB_14000ef4b;
        lVar14 = lVar14 + 0x80;
      } while (uVar11 * 0x80 != lVar14);
    }
    if (uVar16 != 0) {
      uVar20 = 0;
      do {
        if ((*(char *)(lVar8 + uVar20) == '\x01') &&
           (*(longlong *)(lVar8 + 0x10 + uVar20) == param_2[2])) goto LAB_14000ef4b;
        uVar20 = uVar20 + 0x80;
      } while (uVar16 != uVar20);
    }
    uVar20 = 0;
    uVar11 = uVar7;
    if (uVar15 < uVar7) {
      uVar11 = uVar20;
    }
    uVar18 = uVar15 - uVar11;
    uVar19 = uVar7 - uVar18;
    uVar16 = (uVar17 - uVar19) * 0x80;
    if (uVar17 <= uVar19) {
      uVar16 = uVar20;
    }
    uVar13 = uVar18 + uVar17;
    if (uVar19 < uVar17) {
      uVar13 = uVar7;
    }
    if (uVar18 != uVar13) {
      if (uVar17 < uVar19) {
        uVar19 = uVar17;
      }
      lVar12 = lVar8 + uVar15 * 0x80 + uVar11 * -0x80;
      uVar20 = 0;
      lVar14 = 0;
      do {
        if ((*(char *)(lVar12 + lVar14) == '\x01') &&
           ((ulonglong)param_2[2] < *(ulonglong *)(lVar12 + 0x10 + lVar14))) goto LAB_14000efbf;
        uVar20 = uVar20 + 1;
        lVar14 = lVar14 + 0x80;
      } while (uVar19 * 0x80 != lVar14);
    }
    if (uVar16 != 0) {
      uVar11 = 0;
      do {
        if ((*(char *)(lVar8 + uVar11) == '\x01') &&
           ((ulonglong)param_2[2] < *(ulonglong *)(lVar8 + 0x10 + uVar11))) goto LAB_14000efbf;
        uVar20 = uVar20 + 1;
        uVar11 = uVar11 + 0x80;
      } while (uVar16 != uVar11);
    }
  }
  local_128 = param_2[0xc];
  lStack_120 = param_2[0xd];
  local_138 = param_2[10];
  lStack_130 = param_2[0xb];
  local_148 = param_2[8];
  lStack_140 = param_2[9];
  local_188 = *param_2;
  pvStack_180 = (void *)param_2[1];
  local_178 = param_2[2];
  uStack_170 = (undefined4)param_2[3];
  uStack_16c = *(undefined4 *)((longlong)param_2 + 0x1c);
  local_168 = (undefined4)param_2[4];
  uStack_164 = *(undefined4 *)((longlong)param_2 + 0x24);
  uStack_160 = (undefined4)param_2[5];
  uStack_15c = *(undefined4 *)((longlong)param_2 + 0x2c);
  local_158 = (undefined4)param_2[6];
  uStack_154 = *(undefined4 *)((longlong)param_2 + 0x34);
  uStack_150 = (undefined4)param_2[7];
  uStack_14c = *(undefined4 *)((longlong)param_2 + 0x3c);
  uVar20 = uVar17;
  goto LAB_14000ecbd;
LAB_14000efbf:
  local_128 = param_2[0xc];
  lStack_120 = param_2[0xd];
  local_138 = param_2[10];
  lStack_130 = param_2[0xb];
  local_148 = param_2[8];
  lStack_140 = param_2[9];
  local_188 = *param_2;
  pvStack_180 = (void *)param_2[1];
  local_178 = param_2[2];
  uStack_170 = (undefined4)param_2[3];
  uStack_16c = *(undefined4 *)((longlong)param_2 + 0x1c);
  local_168 = (undefined4)param_2[4];
  uStack_164 = *(undefined4 *)((longlong)param_2 + 0x24);
  uStack_160 = (undefined4)param_2[5];
  uStack_15c = *(undefined4 *)((longlong)param_2 + 0x2c);
  local_158 = (undefined4)param_2[6];
  uStack_154 = *(undefined4 *)((longlong)param_2 + 0x34);
  uStack_150 = (undefined4)param_2[7];
  uStack_14c = *(undefined4 *)((longlong)param_2 + 0x3c);
  uStack_110 = CONCAT44(uStack_110._4_4_,param_4);
  if (uVar17 < uVar20) {
    core[505b25137b8ba7f]::panicking::panic_fmt
              ("index out of bounds",0x27,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_4_llvm_14435704873730135342_1406a1648);
                    /* WARNING: Does not return */
    pcVar4 = (code *)invalidInstructionException();
    (*pcVar4)();
  }
LAB_14000ecbd:
  uStack_110 = CONCAT44(uStack_110._4_4_,param_4);
  if (uVar17 == uVar7) {
    <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
    ::grow(param_1 + 0x218);
    uVar17 = *(ulonglong *)(param_1 + 0x230);
    uVar7 = *(ulonglong *)(param_1 + 0x218);
    uVar15 = *(ulonglong *)(param_1 + 0x228);
  }
  if (uVar17 - uVar20 < uVar20) {
    uVar16 = uVar7;
    if (uVar15 + uVar20 < uVar7) {
      uVar16 = 0;
    }
    uVar11 = uVar15 + uVar20 + 1;
    uVar19 = 0;
    if (uVar7 <= uVar11) {
      uVar19 = uVar7;
    }
    uVar11 = uVar11 - uVar19;
    uVar10 = *(undefined8 *)(param_1 + 0x220);
    uVar15 = (uVar15 + uVar20) - uVar16;
    uVar17 = uVar17 - uVar20;
  }
  else {
    uVar17 = uVar15 - 1;
    uVar11 = uVar17 + uVar7;
    if (!CARRY8(uVar17,uVar7)) {
      uVar11 = uVar17;
    }
    *(ulonglong *)(param_1 + 0x228) = uVar11;
    uVar10 = *(undefined8 *)(param_1 + 0x220);
    uVar17 = uVar20;
  }
  <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
  ::wrap_copy(uVar7,uVar10,uVar15,uVar11,uVar17);
  *(longlong *)(param_1 + 0x230) = *(longlong *)(param_1 + 0x230) + 1;
  uVar20 = uVar20 + *(longlong *)(param_1 + 0x228);
  lVar8 = *(longlong *)(param_1 + 0x220);
  uVar7 = 0;
  if (*(ulonglong *)(param_1 + 0x218) <= uVar20) {
    uVar7 = *(ulonglong *)(param_1 + 0x218);
  }
  lVar12 = (uVar20 - uVar7) * 0x80;
  puVar1 = (undefined8 *)(lVar8 + 0x70 + lVar12);
  *puVar1 = local_118;
  puVar1[1] = uStack_110;
  plVar9 = (longlong *)(lVar8 + 0x60 + lVar12);
  *plVar9 = local_128;
  plVar9[1] = lStack_120;
  plVar9 = (longlong *)(lVar8 + 0x50 + lVar12);
  *plVar9 = local_138;
  plVar9[1] = lStack_130;
  plVar9 = (longlong *)(lVar8 + 0x40 + lVar12);
  *plVar9 = local_148;
  plVar9[1] = lStack_140;
  puVar1 = (undefined8 *)(lVar8 + 0x30 + lVar12);
  *puVar1 = CONCAT44(uStack_154,local_158);
  puVar1[1] = CONCAT44(uStack_14c,uStack_150);
  puVar1 = (undefined8 *)(lVar8 + 0x20 + lVar12);
  *puVar1 = CONCAT44(uStack_164,local_168);
  puVar1[1] = CONCAT44(uStack_15c,uStack_160);
  plVar9 = (longlong *)(lVar8 + 0x10 + lVar12);
  *plVar9 = local_178;
  plVar9[1] = CONCAT44(uStack_16c,uStack_170);
  *(longlong *)(lVar8 + lVar12) = local_188;
  ((longlong *)(lVar8 + lVar12))[1] = (longlong)pvStack_180;
  uVar7 = *(ulonglong *)(param_1 + 0x230);
  if (200 < uVar7) {
    do {
      lVar8 = *(longlong *)(param_1 + 0x228);
      lVar12 = *(longlong *)(param_1 + 0x220);
      uVar15 = *(ulonglong *)(param_1 + 0x218);
      if (lVar8 + 1U < *(ulonglong *)(param_1 + 0x218)) {
        uVar15 = 0;
      }
      *(ulonglong *)(param_1 + 0x228) = (lVar8 - uVar15) + 1;
      uVar7 = uVar7 - 1;
      *(ulonglong *)(param_1 + 0x230) = uVar7;
      lVar8 = lVar8 * 0x80;
      puVar1 = (undefined8 *)(lVar12 + 0x70 + lVar8);
      local_118 = *puVar1;
      uStack_110 = puVar1[1];
      local_188 = *(longlong *)(lVar12 + lVar8);
      pvStack_180 = (void *)((longlong *)(lVar12 + lVar8))[1];
      puVar1 = (undefined8 *)(lVar12 + 0x10 + lVar8);
      local_178 = *puVar1;
      uStack_170 = *(undefined4 *)(puVar1 + 1);
      uStack_16c = *(undefined4 *)((longlong)puVar1 + 0xc);
      puVar2 = (undefined4 *)(lVar12 + 0x20 + lVar8);
      local_168 = *puVar2;
      uStack_164 = puVar2[1];
      uStack_160 = puVar2[2];
      uStack_15c = puVar2[3];
      puVar2 = (undefined4 *)(lVar12 + 0x30 + lVar8);
      local_158 = *puVar2;
      uStack_154 = puVar2[1];
      uStack_150 = puVar2[2];
      uStack_14c = puVar2[3];
      puVar1 = (undefined8 *)(lVar12 + 0x60 + lVar8);
      local_128 = *puVar1;
      lStack_120 = puVar1[1];
      puVar1 = (undefined8 *)(lVar12 + 0x50 + lVar8);
      local_138 = *puVar1;
      lStack_130 = puVar1[1];
      puVar1 = (undefined8 *)(lVar12 + 0x40 + lVar8);
      local_148 = *puVar1;
      lStack_140 = puVar1[1];
      if ((int)uStack_110 != -1) {
        core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                  (&local_188);
        uVar7 = *(ulonglong *)(param_1 + 0x230);
      }
    } while (200 < uVar7);
  }
  return;
}

