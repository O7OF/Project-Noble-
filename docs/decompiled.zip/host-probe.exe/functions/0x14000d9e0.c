// rea decompile_all
// name: core[505b25137b8ba7f]::str::pattern::simd_contains::{closure#2}
// address: 0x14000d9e0
// body: available
// range: 0x14000d9e0-0x14000da07 inclusive
// range: 0x14000da10-0x14000da65 inclusive
// range: 0x14000da70-0x14000dace inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::str::pattern::simd_contains::{closure#2} */

ulonglong __rustcall
core[505b25137b8ba7f]::str::pattern::simd_contains::_closure_2_
          (longlong *param_1,longlong param_2,uint param_3,char param_4)

{
  int iVar1;
  int *piVar2;
  ulonglong uVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  ulonglong uVar8;
  int *piVar9;
  ushort uVar10;
  undefined8 in_R11;
  int *piVar11;
  
  if (param_4 == '\0') {
    param_2 = param_2 + *param_1;
    piVar2 = (int *)param_1[2];
    uVar3 = param_1[3];
    if (uVar3 < 4) {
      do {
        if (uVar3 == 0) break;
        uVar5 = 0;
        for (uVar6 = param_3; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
          uVar5 = uVar5 + 1;
        }
        uVar8 = (ulonglong)uVar5;
        if (*(char *)(param_2 + 1 + uVar8) == (char)*piVar2) {
          if (uVar3 == 1) {
            return 1;
          }
          if (*(char *)(param_2 + 2 + uVar8) == *(char *)((longlong)piVar2 + 1)) {
            if (uVar3 == 2) {
              return 1;
            }
            if (*(char *)(param_2 + 3 + uVar8) == *(char *)((longlong)piVar2 + 2)) {
              return 1;
            }
          }
        }
        bVar4 = (byte)uVar5 & 0xf;
        uVar10 = (ushort)param_3 & (-2 << bVar4 | 0xfffeU >> 0x10 - bVar4);
        param_3 = CONCAT22((short)(param_3 >> 0x10),uVar10);
      } while (uVar10 != 0);
      return CONCAT71((int7)((ulonglong)in_R11 >> 8),uVar3 == 0) & 0xffffffff;
    }
    do {
      uVar5 = 0;
      for (uVar6 = param_3; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
        uVar5 = uVar5 + 1;
      }
      piVar7 = (int *)(param_2 + (ulonglong)uVar5 + uVar3 + -3);
      piVar9 = piVar2;
      for (piVar11 = (int *)(param_2 + (ulonglong)uVar5 + 1); piVar11 < piVar7;
          piVar11 = piVar11 + 1) {
        if (*piVar11 != *piVar9) goto LAB_14000da1d;
        piVar9 = piVar9 + 1;
      }
      iVar1 = *piVar7;
      if (iVar1 == *(int *)((longlong)piVar2 + (uVar3 - 4))) {
        return CONCAT71((uint7)(uint3)((uint)iVar1 >> 8),1);
      }
LAB_14000da1d:
      bVar4 = (byte)uVar5 & 0xf;
      uVar10 = (ushort)param_3 & (-2 << bVar4 | 0xfffeU >> 0x10 - bVar4);
      param_3 = CONCAT22((short)(param_3 >> 0x10),uVar10);
    } while (uVar10 != 0);
  }
  return 0;
}

