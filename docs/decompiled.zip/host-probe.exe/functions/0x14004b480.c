// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<usize>,host_probe[b94139f9089eb1d8]::host::reach_stack::{closure#0}>>,host_probe[b94139f9089eb1d8]::host::reach_stack::{closure#1}>>>::from_iter
// address: 0x14004b480
// body: available
// range: 0x14004b480-0x14004b6ea inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<usize>,
   host_probe[b94139f9089eb1d8]::host::reach_stack::{closure#0}>>,
   host_probe[b94139f9089eb1d8]::host::reach_stack::{closure#1}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<usize>,host_probe[b94139f9089eb1d8]::host::reach_stack::{closure#0}>>,host_probe[b94139f9089eb1d8]::host::reach_stack::{closure#1}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  undefined4 *puVar1;
  longlong lVar2;
  ulonglong *puVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong *plVar6;
  longlong lVar7;
  code *pcVar8;
  undefined4 *puVar9;
  longlong lVar10;
  ulonglong *puVar11;
  longlong local_a8;
  undefined4 *local_a0;
  longlong local_98;
  undefined8 local_90;
  undefined8 uStack_88;
  undefined8 local_80;
  longlong *local_78;
  longlong local_70;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  longlong *local_50;
  code *local_48;
  
  lVar2 = param_2[3];
  if (lVar2 != 0) {
    puVar11 = (ulonglong *)*param_2;
    puVar3 = (ulonglong *)param_2[1];
    if (puVar11 != puVar3) {
      plVar4 = (longlong *)param_2[2];
      lVar10 = *plVar4;
      do {
        uVar5 = *puVar11;
        if (lVar10 - 1U < uVar5 && uVar5 < lVar10 + 0x5000000U) {
          plVar6 = (longlong *)param_2[4];
          local_a8 = uVar5 - *plVar6;
          local_90 = &local_a8;
          uStack_88 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
          alloc[246c2e7857c81348]::fmt::format::format_inner(&local_68,&DAT_1406a3da0,&local_90);
          if (CONCAT44(uStack_64,local_68) != -1) {
            local_78 = plVar6;
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            puVar9 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
            if (puVar9 == (undefined4 *)0x0) {
              alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
              pcVar8 = (code *)invalidInstructionException();
              (*pcVar8)();
            }
            *(undefined8 *)(puVar9 + 4) = local_58;
            *puVar9 = local_68;
            puVar9[1] = uStack_64;
            puVar9[2] = uStack_60;
            puVar9[3] = uStack_5c;
            local_a8 = 4;
            local_98 = 1;
            local_a0 = puVar9;
            lVar10 = local_98;
            goto joined_r0x00014004b593;
          }
          break;
        }
        puVar11 = puVar11 + 1;
      } while (puVar11 != puVar3);
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
joined_r0x00014004b593:
  lVar2 = lVar2 + -1;
  local_98 = lVar10;
  if ((lVar2 == 0) || (puVar11 = puVar11 + 1, puVar11 == puVar3)) {
LAB_14004b690:
    param_1[2] = local_98;
    *param_1 = local_a8;
    param_1[1] = (longlong)local_a0;
    return param_1;
  }
  lVar7 = *plVar4;
  while (uVar5 = *puVar11, uVar5 <= lVar7 - 1U || lVar7 + 0x5000000U <= uVar5) {
    puVar11 = puVar11 + 1;
    if (puVar11 == puVar3) goto LAB_14004b690;
  }
  local_70 = uVar5 - *local_78;
  local_50 = &local_70;
  local_48 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_90,&DAT_1406a3da0,&local_50);
  if (local_90 == (longlong *)0xffffffffffffffff) goto LAB_14004b690;
  if (lVar10 == local_a8) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_a8,lVar10,1,8,0x18);
    puVar9 = local_a0;
  }
  *(undefined8 *)(puVar9 + lVar10 * 6 + 4) = local_80;
  puVar1 = puVar9 + lVar10 * 6;
  *puVar1 = (undefined4)local_90;
  puVar1[1] = local_90._4_4_;
  puVar1[2] = (undefined4)uStack_88;
  puVar1[3] = uStack_88._4_4_;
  lVar10 = lVar10 + 1;
  goto joined_r0x00014004b593;
}

