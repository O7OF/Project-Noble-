// rea decompile_all
// name: <&mut_host_probe[b94139f9089eb1d8]::net::configure::{closure#12}as_core[505b25137b8ba7f]::ops::function::FnMut<(&alloc[246c2e7857c81348]::string::String,)>>::call_mut
// address: 0x14003fde0
// body: available
// range: 0x14003fde0-0x14003ff3e inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut host_probe[b94139f9089eb1d8]::net::configure::{closure#12} as
   core[505b25137b8ba7f]::ops::function::FnMut<(&alloc[246c2e7857c81348]::string::String,)>>::call_mut
    */

undefined8 __rustcall
<&mut_host_probe[b94139f9089eb1d8]::net::configure::{closure#12}as_core[505b25137b8ba7f]::ops::function::FnMut<(&alloc[246c2e7857c81348]::string::String,)>>
::call_mut(undefined8 param_1,longlong param_2)

{
  char cVar1;
  byte bVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  char *pcVar11;
  uint uVar12;
  longlong local_a0;
  longlong local_98;
  undefined1 local_88 [104];
  
  lVar3 = *(longlong *)(param_2 + 8);
  lVar4 = *(longlong *)(param_2 + 0x10);
  <core[505b25137b8ba7f]::str::pattern::StrSearcher>::new
            (local_88,lVar3,lVar4,
             &anon_d5c34e88a06ee720b116585eb143da4b_38_llvm_14435704873730135342,2);
  do {
    <core[505b25137b8ba7f]::str::pattern::StrSearcher_as_core[505b25137b8ba7f]::str::pattern::Searcher>
    ::next(&local_a0);
  } while (local_a0 == 0);
  if (((int)local_a0 == 1) && (uVar9 = lVar4 - local_98, uVar9 != 0)) {
    pcVar11 = (char *)(lVar3 + local_98);
    if (uVar9 == 1) {
      cVar1 = *pcVar11;
      if (cVar1 == '+') {
        return 0;
      }
      if (cVar1 == '-') {
        return 0;
      }
    }
    else {
      cVar1 = *pcVar11;
    }
    uVar5 = (ulonglong)(cVar1 == '+');
    uVar10 = uVar9 - uVar5;
    if (uVar10 < 0x11) {
      uVar6 = 1;
      if (uVar9 != uVar5) {
        uVar9 = 0;
        do {
          bVar2 = pcVar11[uVar9 + uVar5];
          uVar12 = bVar2 - 0x30;
          if (0x39 < bVar2) {
            uVar12 = (bVar2 - 0x41 & 0xffffffdf) + 10;
          }
          if (0xf < uVar12) {
            return 0;
          }
          uVar9 = uVar9 + 1;
        } while (uVar10 != uVar9);
      }
    }
    else {
      uVar9 = 0;
      uVar8 = 0;
      do {
        if (uVar8 >> 0x3c != 0) {
          return 0;
        }
        uVar7 = uVar8 * 0x10;
        bVar2 = pcVar11[uVar9 + uVar5];
        uVar12 = bVar2 - 0x30;
        if (0x39 < bVar2) {
          uVar12 = (bVar2 - 0x41 & 0xffffffdf) + 10;
        }
        uVar8 = uVar12 + uVar7;
        if (CARRY8((ulonglong)uVar12,uVar7) || 0xf < uVar12) {
          return 0;
        }
        uVar9 = uVar9 + 1;
        uVar6 = 1;
      } while (uVar10 != uVar9);
    }
  }
  else {
    uVar6 = 0;
  }
  return uVar6;
}

