// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::hudx::grow_game_state
// address: 0x14003c210
// body: available
// range: 0x14003c210-0x14003c2d3 inclusive
// range: 0x14003c2e0-0x14003c340 inclusive
// range: 0x14003c350-0x14003c481 inclusive
// range: 0x14003c490-0x14003c4b3 inclusive
// range: 0x14003c4b6-0x14003c550 inclusive
// range: 0x14003c55f-0x14003c5ba inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003c4af to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003c54c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003c57c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::hudx::grow_game_state */

undefined8 * __rustcall
host_probe[b94139f9089eb1d8]::hudx::grow_game_state
          (undefined8 *param_1,longlong param_2,int param_3,int param_4)

{
  void *_Src;
  ulonglong _Size;
  code *pcVar1;
  longlong lVar2;
  int iVar3;
  void *_Dst;
  longlong lVar4;
  longlong lVar5;
  undefined8 *puVar6;
  int iVar7;
  longlong lVar8;
  longlong local_e8;
  longlong lStack_e0;
  longlong local_d8;
  longlong local_d0;
  int local_c4;
  int local_c0;
  int local_bc;
  undefined8 *local_b8;
  longlong *local_b0;
  code *local_a8;
  longlong local_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  longlong **local_88;
  code *local_80;
  void **local_78;
  code *local_70;
  void *local_68;
  ulonglong local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  local_e8 = 0;
  lStack_e0 = 8;
  local_d8 = 0;
  local_c0 = param_4 + param_3;
  local_bc = param_4 + 0x220000;
  local_c4 = param_3 * 3 + param_4;
  lVar8 = 0;
  local_a0 = param_2;
  do {
    local_d0 = *(longlong *)((longlong)&DAT_1406a3300 + lVar8);
    _Src = *(void **)((longlong)&PTR_DAT_1406a32f0 + lVar8);
    _Size = *(ulonglong *)((longlong)&DAT_1406a32f8 + lVar8);
    local_68 = _Src;
    local_60 = _Size;
    if (_Size < 4) {
LAB_14003c420:
      local_b0 = &local_d0;
      local_a8 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_98,&DAT_1406a07b8,&local_b0);
      param_1[3] = local_88;
      *(undefined4 *)(param_1 + 1) = (undefined4)local_98;
      *(undefined4 *)((longlong)param_1 + 0xc) = local_98._4_4_;
      *(undefined4 *)(param_1 + 2) = (undefined4)uStack_90;
      *(undefined4 *)((longlong)param_1 + 0x14) = uStack_90._4_4_;
      *param_1 = 1;
      if (local_d8 != 0) {
        puVar6 = (undefined8 *)(lStack_e0 + 0x20);
        lVar8 = local_d8;
        do {
          if (puVar6[-1] != 0) {
            puVar6 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar6,puVar6[-1],1);
            return puVar6;
          }
          puVar6 = puVar6 + 6;
          lVar8 = lVar8 + -1;
        } while (lVar8 != 0);
      }
      if (local_e8 == 0) {
        return param_1;
      }
      puVar6 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lStack_e0,local_e8 * 0x30,8);
      return puVar6;
    }
    iVar3 = *(int *)((longlong)&DAT_1406a3308 + lVar8);
    lVar8 = lVar8 + 0x20;
    lVar5 = 0;
    while (*(int *)((longlong)_Src + lVar5) != iVar3) {
      lVar5 = lVar5 + 1;
      if (_Size - 3 == lVar5) goto LAB_14003c420;
    }
    local_b8 = param_1;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    _Dst = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size,1);
    if (_Dst == (void *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,_Size);
LAB_14003c5b9:
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    memcpy(_Dst,_Src,_Size);
    lVar2 = local_d0;
    if (_Size < lVar5 + 4U) {
      core[505b25137b8ba7f]::slice::index::slice_index_fail
                (lVar5,lVar5 + 4U,_Size,&PTR_s_src_hudx_rs_1406a3258);
      goto LAB_14003c5b9;
    }
    if (iVar3 < 0xa40000) {
      iVar7 = local_bc;
      if ((iVar3 != 0x220000) && (iVar7 = param_3 + 0x490000, iVar3 != 0x490000)) {
LAB_14003c369:
        iVar7 = local_c4;
        goto LAB_14003c36e;
      }
    }
    else {
      iVar7 = local_c0;
      if ((iVar3 != 0xa40000) && (iVar3 != 0xa60000)) goto LAB_14003c369;
LAB_14003c36e:
      iVar7 = iVar3 + iVar7;
    }
    *(int *)((longlong)_Dst + lVar5) = iVar7;
    local_b0 = (longlong *)(local_d0 + local_a0);
    local_a8 = (code *)_Size;
    iVar3 = memcmp(local_b0,_Src,_Size);
    lVar5 = local_d8;
    if (iVar3 != 0) {
      local_98 = &local_d0;
      uStack_90 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_88 = &local_b0;
      local_80 = <&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
      local_78 = &local_68;
      local_70 = <&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a3610,&local_98);
      local_b8[3] = local_48;
      *(undefined4 *)(local_b8 + 1) = local_58;
      *(undefined4 *)((longlong)local_b8 + 0xc) = uStack_54;
      *(undefined4 *)(local_b8 + 2) = uStack_50;
      *(undefined4 *)((longlong)local_b8 + 0x14) = uStack_4c;
      *local_b8 = 1;
      puVar6 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(_Dst,_Size,1);
      return puVar6;
    }
    if (local_d8 == local_e8) {
      <alloc[246c2e7857c81348]::raw_vec::RawVec<host_probe[b94139f9089eb1d8]::gpu::Adapter>>::
      grow_one(&local_e8);
    }
    lVar4 = lVar5 * 0x30;
    *(void **)(lStack_e0 + lVar4) = _Src;
    *(ulonglong *)(lStack_e0 + 8 + lVar4) = _Size;
    *(longlong *)(lStack_e0 + 0x10 + lVar4) = lVar2;
    *(ulonglong *)(lStack_e0 + 0x18 + lVar4) = _Size;
    *(void **)(lStack_e0 + 0x20 + lVar4) = _Dst;
    *(ulonglong *)(lStack_e0 + 0x28 + lVar4) = _Size;
    local_d8 = lVar5 + 1;
    param_1 = local_b8;
    if (lVar8 == 800) {
      local_b8[3] = local_d8;
      local_b8[1] = local_e8;
      local_b8[2] = lStack_e0;
      *local_b8 = 0;
      return local_b8;
    }
  } while( true );
}

