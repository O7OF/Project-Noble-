// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u32,usize)>>::retain::<host_probe[b94139f9089eb1d8]::trace::auto_aim_ai::{closure#9}>
// address: 0x140042840
// body: available
// range: 0x140042840-0x140042955 inclusive
// range: 0x140042960-0x14004298d inclusive
// range: 0x140042990-0x1400429aa inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u32,
   usize)>>::retain::<host_probe[b94139f9089eb1d8]::trace::auto_aim_ai::{closure#9}> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u32,usize)>>::retain::
<host_probe[b94139f9089eb1d8]::trace::auto_aim_ai::_closure_9_>(longlong param_1,ulonglong *param_2)

{
  undefined8 *puVar1;
  ulonglong *puVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  longlong lVar7;
  ulonglong *puVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  
  uVar3 = *(ulonglong *)(param_1 + 0x10);
  if (uVar3 != 0) {
    lVar4 = *(longlong *)(param_1 + 8);
    uVar5 = *param_2;
    uVar13 = (ulonglong)((uint)uVar3 & 3);
    if (uVar3 < 4) {
      uVar10 = 0;
    }
    else {
      puVar8 = (ulonglong *)(lVar4 + 0x38);
      uVar9 = 0;
      do {
        if (puVar8[-6] <= uVar5) {
          uVar10 = uVar9 + 1;
          goto LAB_140042902;
        }
        if (puVar8[-4] <= uVar5) {
          uVar10 = uVar9 + 2;
          uVar9 = uVar9 + 1;
          goto LAB_140042902;
        }
        if (puVar8[-2] <= uVar5) {
          uVar10 = uVar9 + 3;
          uVar9 = uVar9 + 2;
          goto LAB_140042902;
        }
        uVar10 = uVar9 + 4;
        if (*puVar8 <= uVar5) {
          uVar9 = uVar9 | 3;
          goto LAB_140042902;
        }
        puVar8 = puVar8 + 8;
        uVar9 = uVar10;
      } while ((uVar3 & 0x7fffffffffffffc) != uVar10);
      if (uVar13 == 0) {
        return;
      }
    }
    puVar8 = (ulonglong *)(uVar10 * 0x10 + lVar4 + 8);
    lVar7 = 0;
    do {
      if (*puVar8 <= uVar5) {
        uVar9 = uVar10 - lVar7;
        uVar10 = uVar9 + 1;
LAB_140042902:
        if (uVar10 < uVar3) {
          uVar13 = uVar10 + 1;
          uVar12 = uVar10;
          if ((((uint)uVar3 - (int)uVar10 & 1) != 0) &&
             (uVar12 = uVar13, uVar5 < *(ulonglong *)(lVar4 + 8 + uVar10 * 0x10))) {
            puVar11 = (undefined8 *)(uVar10 * 0x10 + lVar4);
            uVar6 = puVar11[1];
            puVar1 = (undefined8 *)(lVar4 + uVar9 * 0x10);
            *puVar1 = *puVar11;
            puVar1[1] = uVar6;
            uVar9 = uVar9 + 1;
          }
          if (uVar3 != uVar13) {
            lVar7 = uVar3 - uVar12;
            puVar8 = (ulonglong *)(uVar12 * 0x10 + lVar4 + 0x18);
            do {
              if (uVar5 < puVar8[-2]) {
                uVar3 = puVar8[-2];
                puVar2 = (ulonglong *)(lVar4 + uVar9 * 0x10);
                *puVar2 = puVar8[-3];
                puVar2[1] = uVar3;
                uVar9 = uVar9 + 1;
                uVar3 = *puVar8;
              }
              else {
                uVar3 = *puVar8;
              }
              if (uVar5 < uVar3) {
                uVar3 = *puVar8;
                puVar2 = (ulonglong *)(lVar4 + uVar9 * 0x10);
                *puVar2 = puVar8[-1];
                puVar2[1] = uVar3;
                uVar9 = uVar9 + 1;
              }
              puVar8 = puVar8 + 4;
              lVar7 = lVar7 + -2;
            } while (lVar7 != 0);
          }
        }
        *(ulonglong *)(param_1 + 0x10) = uVar9;
        return;
      }
      lVar7 = lVar7 + -1;
      puVar8 = puVar8 + 2;
    } while (-lVar7 != uVar13);
  }
  return;
}

