// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::rategate::RowState>>::extend_with
// address: 0x140047830
// body: available
// range: 0x140047830-0x14004793e inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::rategate::RowState>>::extend_with
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::rategate::RowState>>::extend_with
          (longlong *param_1,ulonglong param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong lVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  
  lVar3 = param_1[2];
  if ((ulonglong)(*param_1 - lVar3) < param_2) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar3,param_2,4,0x18);
    lVar3 = param_1[2];
  }
  puVar2 = (undefined8 *)(lVar3 * 0x18 + param_1[1]);
  if (param_2 < 2) {
    if (param_2 == 0) goto LAB_140047907;
  }
  else {
    uVar4 = (ulonglong)((uint)(param_2 - 1) & 3);
    if (param_2 - 2 < 3) goto LAB_1400478d0;
    uVar5 = param_2 - 1 & 0xfffffffffffffffc;
    do {
      puVar2[2] = param_3[2];
      uVar1 = param_3[1];
      *puVar2 = *param_3;
      puVar2[1] = uVar1;
      puVar2[5] = param_3[2];
      uVar1 = param_3[1];
      puVar2[3] = *param_3;
      puVar2[4] = uVar1;
      puVar2[8] = param_3[2];
      uVar1 = param_3[1];
      puVar2[6] = *param_3;
      puVar2[7] = uVar1;
      uVar1 = param_3[1];
      puVar2[9] = *param_3;
      puVar2[10] = uVar1;
      puVar2[0xb] = param_3[2];
      puVar2 = puVar2 + 0xc;
      uVar5 = uVar5 - 4;
    } while (uVar5 != 0);
    for (; uVar4 != 0; uVar4 = uVar4 - 1) {
LAB_1400478d0:
      puVar2[2] = param_3[2];
      uVar1 = param_3[1];
      *puVar2 = *param_3;
      puVar2[1] = uVar1;
      puVar2 = puVar2 + 3;
    }
    lVar3 = lVar3 + param_2 + -1;
  }
  puVar2[2] = param_3[2];
  uVar1 = param_3[1];
  *puVar2 = *param_3;
  puVar2[1] = uVar1;
  lVar3 = lVar3 + 1;
LAB_140047907:
  param_1[2] = lVar3;
  return;
}

