// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<usize>>::retain::<host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}>
// address: 0x140042db0
// body: available
// range: 0x140042db0-0x140042e76 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<usize>>::retain::<host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<usize>>::retain::
<host_probe[b94139f9089eb1d8]::host::armory::write_suit::_closure_1_>
          (longlong param_1,undefined8 param_2,undefined8 param_3)

{
  ulonglong uVar1;
  longlong lVar2;
  char cVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 local_50;
  undefined8 local_48;
  
  uVar1 = *(ulonglong *)(param_1 + 0x10);
  if (uVar1 != 0) {
    lVar2 = *(longlong *)(param_1 + 8);
    lVar5 = 8;
    lVar4 = 0;
    local_50 = param_2;
    local_48 = param_3;
    do {
      cVar3 = <host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}>::_closure_0_
                        (&local_50,*(undefined8 *)(lVar2 + -8 + lVar5));
      if (cVar3 == '\0') {
        lVar6 = -lVar4;
        if (1U - lVar4 < uVar1) {
          lVar4 = (1 - uVar1) - lVar4;
          do {
            cVar3 = <host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}>::
                    _closure_0_(&local_50,*(undefined8 *)(lVar2 + lVar5));
            if (cVar3 != '\0') {
              *(undefined8 *)(lVar2 + lVar6 * 8) = *(undefined8 *)(lVar2 + lVar5);
              lVar6 = lVar6 + 1;
            }
            lVar5 = lVar5 + 8;
            lVar4 = lVar4 + 1;
          } while (lVar4 != 0);
        }
        *(longlong *)(param_1 + 0x10) = lVar6;
        return;
      }
      lVar5 = lVar5 + 8;
      lVar4 = lVar4 + -1;
    } while (-lVar4 != uVar1);
  }
  return;
}

