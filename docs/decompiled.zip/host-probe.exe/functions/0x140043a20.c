// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::fileshare::SharedFile>>::extend_trusted::<core[505b25137b8ba7f]::option::IntoIter<host_probe[b94139f9089eb1d8]::fileshare::SharedFile>>
// address: 0x140043a20
// body: available
// range: 0x140043a20-0x140043ab5 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::fileshare::SharedFile>>::extend_trusted::<core[505b25137b8ba7f]::option::IntoIter<host_probe[b94139f9089eb1d8]::fileshare::SharedFile>>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::fileshare::SharedFile>>::
extend_trusted::
<core[505b25137b8ba7f]::option::IntoIter<host_probe[b94139f9089eb1d8]::fileshare::SharedFile>>
          (longlong *param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  
  lVar2 = *param_2;
  lVar10 = param_1[2];
  if ((ulonglong)(*param_1 - lVar10) < (ulonglong)(lVar2 != -1)) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar10,(ulonglong)(lVar2 != -1),8,0x48);
    lVar10 = param_1[2];
  }
  if (lVar2 != -1) {
    lVar3 = param_1[1];
    *(longlong *)(lVar3 + lVar10 * 0x48) = lVar2;
    lVar2 = param_2[2];
    lVar4 = param_2[3];
    lVar5 = param_2[4];
    lVar6 = param_2[5];
    lVar7 = param_2[6];
    lVar8 = param_2[7];
    lVar9 = param_2[8];
    plVar1 = (longlong *)(lVar3 + 8 + lVar10 * 0x48);
    *plVar1 = param_2[1];
    plVar1[1] = lVar2;
    plVar1 = (longlong *)(lVar3 + 0x18 + lVar10 * 0x48);
    *plVar1 = lVar4;
    plVar1[1] = lVar5;
    plVar1 = (longlong *)(lVar3 + 0x28 + lVar10 * 0x48);
    *plVar1 = lVar6;
    plVar1[1] = lVar7;
    plVar1 = (longlong *)(lVar3 + 0x38 + lVar10 * 0x48);
    *plVar1 = lVar8;
    plVar1[1] = lVar9;
    lVar10 = lVar10 + 1;
  }
  param_1[2] = lVar10;
  return;
}

