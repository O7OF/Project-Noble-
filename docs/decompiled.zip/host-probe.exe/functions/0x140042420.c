// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::trades::Death>>::retain::<<host_probe[b94139f9089eb1d8]::trades::Tracker>::expire::{closure#0}>
// address: 0x140042420
// body: available
// range: 0x140042420-0x14004250e inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::trades::Death>>::retain::<<host_probe[b94139f9089eb1d8]::trades::Tracker>::expire::{closure#0}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::trades::Death>>::retain::
<<host_probe[b94139f9089eb1d8]::trades::Tracker>::expire::_closure_0_>
          (longlong param_1,int *param_2)

{
  undefined8 *puVar1;
  int iVar2;
  ulonglong uVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  int *piVar9;
  
  uVar3 = *(ulonglong *)(param_1 + 0x10);
  if (uVar3 != 0) {
    lVar4 = *(longlong *)(param_1 + 8);
    iVar2 = *param_2;
    if (uVar3 == 1) {
      uVar7 = 0;
    }
    else {
      piVar9 = (int *)(lVar4 + 0x1c);
      uVar7 = 0;
      do {
        if ((iVar2 < piVar9[-5]) || (0x3c < iVar2 - piVar9[-5])) {
          uVar8 = uVar7 + 1;
          goto LAB_1400424b6;
        }
        if ((iVar2 < *piVar9) || (0x3c < iVar2 - *piVar9)) {
          uVar8 = uVar7 + 2;
          uVar7 = uVar7 + 1;
          goto LAB_1400424b6;
        }
        uVar7 = uVar7 + 2;
        piVar9 = piVar9 + 10;
      } while ((uVar3 & 0x7fffffffffffffe) != uVar7);
      if ((uVar3 & 1) == 0) {
        return;
      }
    }
    uVar8 = uVar7 + 1;
    piVar9 = (int *)(lVar4 + 8 + uVar7 * 0x14);
    if ((iVar2 < *piVar9) || (0x3c < iVar2 - *piVar9)) {
LAB_1400424b6:
      lVar6 = uVar3 - uVar8;
      if (uVar8 <= uVar3 && lVar6 != 0) {
        piVar9 = (int *)(lVar4 + uVar8 * 0x14 + 8);
        do {
          if (iVar2 - *piVar9 < 0x3d && *piVar9 <= iVar2) {
            *(int *)(lVar4 + 0x10 + uVar7 * 0x14) = piVar9[2];
            uVar5 = *(undefined8 *)piVar9;
            puVar1 = (undefined8 *)(lVar4 + uVar7 * 0x14);
            *puVar1 = *(undefined8 *)(piVar9 + -2);
            puVar1[1] = uVar5;
            uVar7 = uVar7 + 1;
          }
          piVar9 = piVar9 + 5;
          lVar6 = lVar6 + -1;
        } while (lVar6 != 0);
      }
      *(ulonglong *)(param_1 + 0x10) = uVar7;
      return;
    }
  }
  return;
}

