// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::HostRelay>
// address: 0x140003f00
// body: available
// range: 0x140003f00-0x140003f68 inclusive
// range: 0x140003f70-0x140003fab inclusive
// range: 0x140003fae-0x140004049 inclusive
// range: 0x140004050-0x1400040b1 inclusive
// range: 0x1400040b4-0x140004190 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140003f8c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003fa7 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003fc4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000400b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400040ad to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400040db to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004125 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004170 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000418c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain e
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::HostRelay> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::HostRelay>
          (ulonglong *param_1)

{
  undefined1 auVar1 [16];
  ulonglong uVar2;
  ulonglong uVar3;
  int iVar4;
  uint uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined8 *puVar8;
  ulonglong uVar9;
  longlong lVar10;
  ushort uVar11;
  uint uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  undefined1 (*pauVar16) [16];
  undefined1 (*pauVar17) [16];
  
  uVar2 = *param_1;
  uVar6 = param_1[3];
  if (uVar6 == 0) {
    uVar9 = param_1[1];
  }
  else {
    uVar9 = param_1[1];
    uVar3 = param_1[2];
    uVar7 = uVar2;
    if (uVar3 < uVar2) {
      uVar7 = 0;
    }
    lVar10 = uVar3 - uVar7;
    uVar13 = uVar2 - lVar10;
    uVar15 = uVar6 - uVar13;
    if (uVar6 < uVar13) {
      uVar15 = 0;
    }
    uVar14 = lVar10 + uVar6;
    if (uVar6 >= uVar13 && uVar6 - uVar13 != 0) {
      uVar14 = uVar2;
    }
    lVar10 = uVar14 - lVar10;
    if (lVar10 != 0) {
      puVar8 = (undefined8 *)(uVar3 * 0x38 + uVar7 * -0x38 + uVar9 + 0x28);
      do {
        if (puVar8[-5] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar8[-4],puVar8[-5],1);
          return;
        }
        if (puVar8[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar8,puVar8[-1] << 3,8);
          return;
        }
        puVar8 = puVar8 + 7;
        lVar10 = lVar10 + -1;
      } while (lVar10 != 0);
    }
    if (uVar13 < uVar6) {
      puVar8 = (undefined8 *)(uVar9 + 0x28);
      do {
        if (puVar8[-5] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar8[-4],puVar8[-5],1);
          return;
        }
        if (puVar8[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar8,puVar8[-1] << 3,8);
          return;
        }
        puVar8 = puVar8 + 7;
        uVar15 = uVar15 - 1;
      } while (uVar15 != 0);
    }
  }
  if (uVar2 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar9,uVar2 * 0x38,8);
    return;
  }
  <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,reach_directory[4b72b9694f6c3c08]::chat::Bucket)>as_core[505b25137b8ba7f]::ops::drop::Drop>
  ::drop(param_1 + 0xd);
  uVar2 = param_1[0x14];
  if (uVar2 != 0) {
    uVar6 = uVar2 * 0x18 & 0xfffffffffffffff0;
    lVar10 = uVar2 + uVar6 + 0x31;
    if (lVar10 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc((param_1[0x13] - uVar6) + -0x20,lVar10,0x10);
      return;
    }
  }
  uVar2 = param_1[0x1a];
  if (uVar2 != 0) {
    uVar6 = param_1[0x1c];
    if (uVar6 != 0) {
      pauVar16 = (undefined1 (*) [16])param_1[0x19];
      auVar1 = *pauVar16;
      pauVar17 = pauVar16 + 1;
      uVar12 = ~(uint)(ushort)((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                               (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                               (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                               (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                               (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                               (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                               (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                               (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                               (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                               (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                               (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                               (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                               (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                               (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                               (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                              (ushort)(byte)(auVar1[0xf] >> 7) << 0xf);
      do {
        uVar11 = (ushort)uVar12;
        while (uVar11 == 0) {
          auVar1 = *pauVar17;
          pauVar16 = pauVar16 + -0x20;
          pauVar17 = pauVar17 + 1;
          uVar11 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) | (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1
                    | (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                   (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar12 = (uint)uVar11;
        }
        iVar4 = 0;
        for (uVar5 = uVar12; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
          iVar4 = iVar4 + 1;
        }
        lVar10 = *(longlong *)((longlong)pauVar16 + (-0x18 - (ulonglong)(uint)(iVar4 << 5)));
        if (lVar10 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc
                    (*(undefined8 *)((longlong)pauVar16 + (-0x10 - (ulonglong)(uint)(iVar4 << 5))),
                     lVar10,1);
          return;
        }
        uVar6 = uVar6 - 1;
        uVar12 = uVar12 - 1 & uVar12;
      } while (uVar6 != 0);
    }
    lVar10 = uVar2 * 0x21 + 0x31;
    if (lVar10 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x19] + uVar2 * -0x20 + -0x20,lVar10,0x10);
      return;
    }
  }
  uVar2 = param_1[0x20];
  if (uVar2 != 0) {
    uVar6 = uVar2 * 8 & 0xfffffffffffffff0;
    lVar10 = uVar2 + uVar6 + 0x21;
    if (lVar10 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc((param_1[0x1f] - uVar6) + -0x10,lVar10,0x10);
      return;
    }
  }
  return;
}

