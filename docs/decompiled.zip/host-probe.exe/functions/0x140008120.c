// rea decompile_all
// name: std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::host::armory::frame::{closure#1},()>
// address: 0x140008120
// body: available
// range: 0x140008120-0x14000885a inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140008258 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400082e3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000842a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400084c8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400085ff to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000868a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::host::armory::frame::{closure#1},
   ()> */

void __rustcall
std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::
<host_probe[b94139f9089eb1d8]::host::armory::frame::_closure_1_,()>(void)

{
  code *pcVar1;
  undefined *puVar2;
  char *pcVar3;
  undefined1 *puVar4;
  ulonglong uVar5;
  byte bVar6;
  char cVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong lVar10;
  bool bVar11;
  char *local_c0;
  byte local_b8;
  undefined1 *local_b0;
  undefined1 *local_a8;
  undefined8 local_a0;
  undefined1 *local_98;
  char **local_90;
  longlong local_88;
  undefined1 *local_80;
  ulonglong local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined1 *local_60;
  longlong local_58;
  undefined8 *local_50;
  code *local_48;
  
  std[3bf9d48a0c3997f0]::thread::functions::sleep(0,300000000);
  host_probe[b94139f9089eb1d8]::host::armory::find_all(&local_68,&DAT_1406a0ae0,4);
  LOCK();
  bVar11 = host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS == '\0';
  if (bVar11) {
    host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS = '\x01';
  }
  UNLOCK();
  if (!bVar11) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
              (&host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS);
  }
  puVar2 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar6 = 0;
    local_a0 = local_68;
    local_b0 = local_60;
  }
  else {
    bVar6 = panicking::panic_count::is_zero_slow_path();
    bVar6 = bVar6 ^ 1;
    local_a0 = local_68;
    local_b0 = local_60;
  }
  if (DAT_14069bbb9 == '\0') {
    local_c0 = &host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS;
    local_98 = local_b0 + local_58 * 8;
    local_b8 = bVar6;
    local_a8 = local_b0;
    local_90 = &local_c0;
    local_68 = local_a0;
    local_60 = local_b0;
    alloc[246c2e7857c81348]::vec::in_place_collect::from_iter_in_place::
    <core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<usize>,host_probe[b94139f9089eb1d8]::host::armory::frame::_closure_1_::_closure_0_>,usize>
              (&local_88,&local_b0);
    uVar5 = local_78;
    puVar4 = local_80;
    lVar10 = local_88;
    pcVar3 = local_c0;
    if (local_78 == 0) {
      if (local_88 != 0) {
        local_b0 = (undefined1 *)(local_88 << 3);
        uVar8 = 8;
        goto LAB_1400082e3;
      }
    }
    else {
      lVar9 = *(longlong *)(local_c0 + 0x18);
      if ((ulonglong)(*(longlong *)(local_c0 + 8) - lVar9) < local_78) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(local_c0 + 8,lVar9,local_78,8,8);
        lVar9 = *(longlong *)(pcVar3 + 0x18);
      }
      memcpy((void *)(lVar9 * 8 + *(longlong *)(pcVar3 + 0x10)),puVar4,uVar5 * 8);
      *(ulonglong *)(pcVar3 + 0x18) = lVar9 + uVar5;
      if (lVar10 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar4,lVar10 << 3,8);
        return;
      }
      local_70 = *(undefined8 *)(local_c0 + 0x18);
      local_50 = &local_70;
      local_48 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_b0,&DAT_1406a0bb0,&local_50);
      puVar4 = local_a8;
      host_probe[b94139f9089eb1d8]::host::log(local_a8,local_a0);
      if (local_b0 != (undefined1 *)0x0) {
        uVar8 = 1;
        local_80 = puVar4;
LAB_1400082e3:
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_80,local_b0,uVar8);
        return;
      }
    }
    pcVar3 = local_c0;
    if (((local_b8 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
       (cVar7 = panicking::panic_count::is_zero_slow_path(), cVar7 == '\0')) {
      pcVar3[1] = '\x01';
    }
    LOCK();
    cVar7 = *pcVar3;
    *pcVar3 = '\0';
    UNLOCK();
    if (cVar7 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar3);
    }
    std[3bf9d48a0c3997f0]::thread::functions::sleep(0,700000000);
    host_probe[b94139f9089eb1d8]::host::armory::find_all(&local_68,&DAT_1406a0ae0,4);
    LOCK();
    bVar11 = host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS == '\0';
    if (bVar11) {
      host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS = '\x01';
    }
    UNLOCK();
    if (!bVar11) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                (&host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS);
    }
    if ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) == 0) {
      bVar6 = 0;
      local_a0 = local_68;
      local_b0 = local_60;
    }
    else {
      bVar6 = panicking::panic_count::is_zero_slow_path();
      bVar6 = bVar6 ^ 1;
      local_a0 = local_68;
      local_b0 = local_60;
    }
    if (DAT_14069bbb9 == '\0') {
      local_c0 = &host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS;
      local_98 = local_b0 + local_58 * 8;
      local_b8 = bVar6;
      local_a8 = local_b0;
      local_90 = &local_c0;
      local_68 = local_a0;
      local_60 = local_b0;
      alloc[246c2e7857c81348]::vec::in_place_collect::from_iter_in_place::
      <core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<usize>,host_probe[b94139f9089eb1d8]::host::armory::frame::_closure_1_::_closure_0_>,usize>
                (&local_88,&local_b0);
      uVar5 = local_78;
      puVar4 = local_80;
      lVar10 = local_88;
      pcVar3 = local_c0;
      if (local_78 == 0) {
        if (local_88 != 0) {
          local_b0 = (undefined1 *)(local_88 << 3);
          uVar8 = 8;
          goto LAB_1400084c8;
        }
      }
      else {
        lVar9 = *(longlong *)(local_c0 + 0x18);
        if ((ulonglong)(*(longlong *)(local_c0 + 8) - lVar9) < local_78) {
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>(local_c0 + 8,lVar9,local_78,8,8);
          lVar9 = *(longlong *)(pcVar3 + 0x18);
        }
        memcpy((void *)(lVar9 * 8 + *(longlong *)(pcVar3 + 0x10)),puVar4,uVar5 * 8);
        *(ulonglong *)(pcVar3 + 0x18) = lVar9 + uVar5;
        if (lVar10 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar4,lVar10 << 3,8);
          return;
        }
        local_70 = *(undefined8 *)(local_c0 + 0x18);
        local_50 = &local_70;
        local_48 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_b0,&DAT_1406a0bb0,&local_50);
        puVar4 = local_a8;
        host_probe[b94139f9089eb1d8]::host::log(local_a8,local_a0);
        if (local_b0 != (undefined1 *)0x0) {
          uVar8 = 1;
          local_80 = puVar4;
LAB_1400084c8:
          __rustc[9d087a5ab36ea756]::__rust_dealloc(local_80,local_b0,uVar8);
          return;
        }
      }
      pcVar3 = local_c0;
      if (((local_b8 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
         (cVar7 = panicking::panic_count::is_zero_slow_path(), cVar7 == '\0')) {
        pcVar3[1] = '\x01';
      }
      LOCK();
      cVar7 = *pcVar3;
      *pcVar3 = '\0';
      UNLOCK();
      if (cVar7 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar3);
      }
      std[3bf9d48a0c3997f0]::thread::functions::sleep(1,500000000);
      host_probe[b94139f9089eb1d8]::host::armory::find_all(&local_68,&DAT_1406a0ae0,4);
      LOCK();
      bVar11 = host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS == '\0';
      if (bVar11) {
        host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS = '\x01';
      }
      UNLOCK();
      if (!bVar11) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                  (&host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS);
      }
      if ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) == 0) {
        bVar6 = 0;
        local_a0 = local_68;
        local_b0 = local_60;
      }
      else {
        bVar6 = panicking::panic_count::is_zero_slow_path();
        bVar6 = bVar6 ^ 1;
        local_a0 = local_68;
        local_b0 = local_60;
      }
      if (DAT_14069bbb9 == '\0') {
        local_c0 = &host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS;
        local_98 = local_b0 + local_58 * 8;
        local_b8 = bVar6;
        local_a8 = local_b0;
        local_90 = &local_c0;
        alloc[246c2e7857c81348]::vec::in_place_collect::from_iter_in_place::
        <core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<usize>,host_probe[b94139f9089eb1d8]::host::armory::frame::_closure_1_::_closure_0_>,usize>
                  (&local_88,&local_b0);
        pcVar3 = local_c0;
        if (local_78 == 0) {
          if (local_88 == 0) goto LAB_14000868f;
          local_b0 = (undefined1 *)(local_88 << 3);
          uVar8 = 8;
          local_a8 = local_80;
        }
        else {
          lVar10 = *(longlong *)(local_c0 + 0x18);
          if ((ulonglong)(*(longlong *)(local_c0 + 8) - lVar10) < local_78) {
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
            <alloc[246c2e7857c81348]::alloc::Global>(local_c0 + 8,lVar10,local_78,8,8);
            lVar10 = *(longlong *)(pcVar3 + 0x18);
          }
          memcpy((void *)(lVar10 * 8 + *(longlong *)(pcVar3 + 0x10)),local_80,local_78 * 8);
          *(ulonglong *)(pcVar3 + 0x18) = lVar10 + local_78;
          if (local_88 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(local_80,local_88 << 3,8);
            return;
          }
          local_70 = *(undefined8 *)(local_c0 + 0x18);
          local_50 = &local_70;
          local_48 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
          alloc[246c2e7857c81348]::fmt::format::format_inner(&local_b0,&DAT_1406a0bb0,&local_50);
          host_probe[b94139f9089eb1d8]::host::log(local_a8,local_a0);
          if (local_b0 == (undefined1 *)0x0) {
LAB_14000868f:
            pcVar3 = local_c0;
            if (((local_b8 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
               (cVar7 = panicking::panic_count::is_zero_slow_path(), cVar7 == '\0')) {
              pcVar3[1] = '\x01';
            }
            LOCK();
            cVar7 = *pcVar3;
            *pcVar3 = '\0';
            UNLOCK();
            if (cVar7 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar3);
            }
            return;
          }
          uVar8 = 1;
        }
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_a8,local_b0,uVar8);
        return;
      }
    }
  }
  local_b0 = &host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS;
  local_a8 = (undefined1 *)CONCAT71(local_a8._1_7_,bVar6);
  core[505b25137b8ba7f]::result::unwrap_failed
            ("called `Result::unwrap()` on an `Err` value",0x2b,&local_b0,
             &
             PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1090
             ,&PTR_s_src_armory_rs_1406a0b98);
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

