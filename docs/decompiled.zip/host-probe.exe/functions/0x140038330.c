// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::peer_ids
// address: 0x140038330
// body: available
// range: 0x140038330-0x1400384a7 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::peer_ids */

undefined8 * __rustcall host_probe[b94139f9089eb1d8]::net::peer_ids(undefined8 *param_1)

{
  undefined1 auVar1 [16];
  code *pcVar2;
  ulonglong uVar3;
  undefined *puVar4;
  byte bVar5;
  char cVar6;
  bool bVar7;
  undefined1 (*local_40) [16];
  undefined1 (*local_38) [16];
  undefined1 *local_30;
  ushort local_28;
  undefined8 local_20;
  
  if (DAT_140699990 == 0) {
    LOCK();
    bVar7 = DAT_140699948 == '\0';
    if (bVar7) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar7) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    puVar4 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar5 = 0;
    }
    else {
      bVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar5 = bVar5 ^ 1;
    }
    if (DAT_140699949 != '\0') {
      local_40 = (undefined1 (*) [16])&DAT_140699948;
      uVar3 = (ulonglong)local_38 >> 8;
      local_38 = (undefined1 (*) [16])CONCAT71((int7)uVar3,bVar5);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_40,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &anon_d5c34e88a06ee720b116585eb143da4b_48_llvm_14435704873730135342);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    local_30 = *DAT_140699950 + DAT_140699958 + 1;
    auVar1 = *DAT_140699950;
    local_28 = ~((ushort)(SUB161(auVar1 >> 7,0) & 1) | (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                 (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                (ushort)(byte)(auVar1[0xf] >> 7) << 0xf);
    local_38 = DAT_140699950 + 1;
    local_40 = DAT_140699950;
    local_20 = DAT_140699968;
    <alloc[246c2e7857c81348]::vec::Vec<u64>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<u64,core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u64,host_probe[b94139f9089eb1d8]::net::Route>>>>
    ::from_iter(param_1,&local_40);
    if (((bVar5 == 0) && ((*(ulonglong *)puVar4 & 0x7fffffffffffffff) != 0)) &&
       (cVar6 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar6 == '\0'))
    {
      DAT_140699949 = '\x01';
    }
    cVar6 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar6 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
  }
  else {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
  }
  return param_1;
}

