// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::star_control_packet
// address: 0x140026f60
// body: available
// range: 0x140026f60-0x140027194 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::star_control_packet */

void __rustcall
host_probe[b94139f9089eb1d8]::net::star_control_packet(longlong *param_1,char *param_2)

{
  char cVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  code *pcVar4;
  longlong lVar5;
  longlong local_40;
  undefined8 *puStack_38;
  longlong local_30;
  
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  puStack_38 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(8,1);
  if (puStack_38 != (undefined8 *)0x0) {
    local_40 = 8;
    *puStack_38 = 0x31524545502d5252;
    local_30 = 8;
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_40,8,8,1,1);
    lVar5 = local_30;
    *(undefined8 *)((longlong)puStack_38 + local_30) = 0x31435254532d5252;
    local_30 = local_30 + 8;
    uVar2 = *(undefined8 *)(param_2 + 8);
    if (*param_2 == '\x01') {
      uVar3 = *(undefined8 *)(param_2 + 0x10);
      cVar1 = param_2[1];
      if (local_30 == local_40) {
        <alloc[246c2e7857c81348]::raw_vec::RawVec<u8>>::grow_one(&local_40);
      }
      *(undefined1 *)((longlong)puStack_38 + lVar5 + 8) = 1;
      local_30 = lVar5 + 9;
      if ((ulonglong)(local_40 - local_30) < 8) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_40,local_30,8,1,1);
      }
      *(undefined8 *)((longlong)puStack_38 + local_30) = uVar2;
      local_30 = local_30 + 8;
      if ((ulonglong)(local_40 - local_30) < 8) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_40,local_30,8,1,1);
      }
      lVar5 = local_30;
      *(undefined8 *)((longlong)puStack_38 + local_30) = uVar3;
      local_30 = local_30 + 8;
      if (local_30 == local_40) {
        <alloc[246c2e7857c81348]::raw_vec::RawVec<u8>>::grow_one(&local_40);
      }
      *(char *)((longlong)puStack_38 + lVar5 + 8) = cVar1;
      lVar5 = lVar5 + 9;
    }
    else {
      if (local_30 == local_40) {
        <alloc[246c2e7857c81348]::raw_vec::RawVec<u8>>::grow_one(&local_40);
      }
      *(undefined1 *)((longlong)puStack_38 + lVar5 + 8) = 0;
      local_30 = lVar5 + 9;
      if ((ulonglong)(local_40 - local_30) < 8) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_40,local_30,8,1,1);
      }
      *(undefined8 *)((longlong)puStack_38 + local_30) = uVar2;
      lVar5 = local_30 + 8;
    }
    param_1[2] = lVar5;
    *param_1 = local_40;
    param_1[1] = (longlong)puStack_38;
    return;
  }
  alloc[246c2e7857c81348]::raw_vec::handle_error(1,8);
                    /* WARNING: Does not return */
  pcVar4 = (code *)invalidInstructionException();
  (*pcVar4)();
}

