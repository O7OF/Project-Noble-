// rea decompile_all
// name: <&mut_host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#3}as_core[505b25137b8ba7f]::ops::function::FnMut<(&(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr),)>>::call_mut
// address: 0x14003f5a0
// body: available
// range: 0x14003f5a0-0x14003fcfb inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003fbaa to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* <&mut host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#3} as
   core[505b25137b8ba7f]::ops::function::FnMut<(&(u64,
   core[505b25137b8ba7f]::net::socket_addr::SocketAddr),)>>::call_mut */

undefined8 * __rustcall
<&mut_host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#3}as_core[505b25137b8ba7f]::ops::function::FnMut<(&(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr),)>>
::call_mut(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  ulonglong *puVar4;
  char *pcVar5;
  ulonglong uVar6;
  char *pcVar7;
  undefined8 uVar8;
  undefined8 *******pppppppuVar9;
  undefined *puVar10;
  char cVar11;
  byte bVar12;
  ushort uVar13;
  longlong *plVar14;
  undefined8 *puVar15;
  ushort uVar16;
  uint uVar17;
  DWORD dwTlsIndex;
  uint uVar18;
  int iVar19;
  ushort uVar20;
  int iVar21;
  code *pcVar22;
  uint uVar23;
  bool bVar24;
  undefined1 auVar25 [16];
  undefined1 local_d1;
  undefined8 local_d0;
  code *local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  ulonglong uStack_b0;
  undefined8 local_a8;
  undefined **ppuStack_a0;
  code *local_98;
  ulonglong uStack_90;
  longlong local_80;
  undefined8 uStack_78;
  undefined8 local_70;
  longlong local_68;
  undefined8 *local_60;
  ulonglong local_58;
  code *local_50;
  undefined8 ******local_48;
  
  local_60 = param_1;
  param_2 = (undefined8 *)*param_2;
  uVar20 = *(ushort *)(param_3 + 1);
  uVar13 = *(ushort *)((longlong)param_3 + 0xe);
  uVar23 = *(uint *)((longlong)param_3 + 10);
  local_a8 = (code *)CONCAT44(CONCAT22(local_a8._6_2_,uVar13),uVar23);
  pcVar22 = (code *)param_3[2];
  uVar17 = *(uint *)(param_3 + 3);
  iVar19 = *(int *)((longlong)param_3 + 0x1c);
  iVar21 = *(int *)(param_3 + 4);
  uVar16 = *(ushort *)((longlong)param_3 + 0x24);
  puVar4 = (ulonglong *)*param_2;
  uVar1 = *(uint *)((longlong)puVar4 + 2);
  local_d0 = (undefined8 *******)
             CONCAT44(CONCAT22(local_d0._6_2_,*(ushort *)((longlong)puVar4 + 6)),uVar1);
  pcVar5 = (char *)param_2[2];
  uVar6 = *(ulonglong *)(pcVar5 + 1);
  local_68 = *(longlong *)(pcVar5 + 9);
  uVar2 = *(uint *)((longlong)&local_a8 + (ulonglong)uVar20 * 2);
  cVar11 = (char)uVar2;
  if ((ushort)*puVar4 == 1) {
    if (((ulonglong)(uint)puVar4[2] << 0x20 | puVar4[1] >> 0x20) != 0x100000000000000 ||
        ((puVar4[1] & 0xffffffff) != 0 || local_d0._2_4_ != 0)) goto LAB_14003f663;
LAB_14003f6e3:
    if (uVar20 != 2) goto LAB_14003f825;
  }
  else {
    pcVar7 = (char *)param_2[1];
    uVar3 = *(uint *)(pcVar7 + 1);
    local_50 = *(code **)(pcVar7 + 5);
    local_58 = (ulonglong)*(uint *)(pcVar7 + 0xd);
    bVar12 = (byte)(uVar1 >> 8);
    uVar18 = uVar1 & 0xff;
    if (uVar18 < 0xac) {
      if (uVar18 != 10) {
        if (uVar18 == 0x7f) goto LAB_14003f6e3;
LAB_14003f74c:
        if (bVar12 != 0xfe || (char)uVar1 != -0x57) goto LAB_14003f663;
      }
LAB_14003f767:
      if ((uVar20 & 1) == 0) {
        if (cVar11 == '\x7f') goto LAB_14003f799;
      }
      else if (((ulonglong)uVar17 << 0x20 | (ulonglong)pcVar22 >> 0x20) == 0x100000000000000 &&
               (uVar2 == 0 && ((ulonglong)pcVar22 & 0xffffffff) == 0)) {
LAB_14003f799:
        if (*pcVar7 == '\x02') goto LAB_14003f9bf;
        if ((uVar20 & 1) == 0) {
          uVar16 = uVar13;
        }
        iVar21 = 0;
        if (*pcVar7 == '\x01') {
          uVar20 = 1;
          iVar19 = 0;
          pcVar22 = local_50;
          uVar23 = uVar3 << 0x10;
          uVar17 = *(uint *)(pcVar7 + 0xd);
          uVar13 = (ushort)(uVar3 >> 0x10);
        }
        else {
          iVar19 = 0;
          uVar20 = 0;
          uVar23 = uVar3;
          uVar13 = uVar16;
        }
      }
LAB_14003f825:
      local_d0 = (undefined8 *******)CONCAT26(uVar13,CONCAT42(uVar23,uVar20));
      uStack_c0 = (undefined **)CONCAT44(iVar19,uVar17);
      local_b8 = (code *)CONCAT26(*(undefined2 *)((longlong)param_3 + 0x26),CONCAT24(uVar16,iVar21))
      ;
      uVar8 = *param_3;
      local_80 = 0;
      uStack_78 = 1;
      local_70 = 0;
      local_98 = (code *)0x60000020;
      local_a8 = (code *)&local_80;
      ppuStack_a0 = &PTR_<alloc[246c2e7857c81348]::string::String>_1406a3830;
      local_c8 = pcVar22;
      cVar11 = <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::fmt::Display>
               ::fmt(&local_d0,&local_a8);
      if (cVar11 == '\0') {
        local_60[3] = local_70;
        local_60[1] = local_80;
        local_60[2] = uStack_78;
        *local_60 = uVar8;
        return local_60;
      }
      core[505b25137b8ba7f]::result::unwrap_failed
                ("a Display implementation returned an error unexpectedly",0x37,&local_d1,
                 &DAT_1406a1170,&PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
      goto LAB_14003fcfa;
    }
    if (uVar18 == 0xc0) {
      if (bVar12 == 0xa8) goto LAB_14003f767;
    }
    else {
      if (uVar18 != 0xac) goto LAB_14003f74c;
      if ((bVar12 & 0xf0) == 0x10) goto LAB_14003f767;
    }
LAB_14003f663:
    if ((uVar20 & 1) == 0) {
      if (cVar11 != '\n') {
        bVar12 = (byte)(uVar2 >> 8);
        if ((uVar2 & 0xff) == 0xc0) {
          if (bVar12 != 0xa8) goto LAB_14003f7f0;
        }
        else if (((uVar2 & 0xff) != 0xac) || ((bVar12 & 0xf0) != 0x10)) {
LAB_14003f7f0:
          if ((cVar11 != '\x7f') && (bVar12 != 0xfe || cVar11 != -0x57)) goto LAB_14003f825;
        }
      }
    }
    else if (((ulonglong)uVar17 << 0x20 | (ulonglong)pcVar22 >> 0x20) != 0x100000000000000 ||
             (uVar2 != 0 || ((ulonglong)pcVar22 & 0xffffffff) != 0)) goto LAB_14003f825;
    uVar23 = (uint)uVar6;
    if (*pcVar5 == '\0') {
      cVar11 = (char)uVar6;
      if (cVar11 != '\n') {
        bVar12 = (byte)(uVar6 >> 8);
        if ((uVar23 & 0xff) == 0xc0) {
          if (bVar12 != 0xa8) goto LAB_14003f986;
        }
        else if (((uVar23 & 0xff) != 0xac) || ((bVar12 & 0xf0) != 0x10)) {
LAB_14003f986:
          if ((cVar11 != '\x7f') && (bVar12 != 0xfe || cVar11 != -0x57)) {
            if ((uVar20 & 1) == 0) {
              uVar16 = uVar13;
            }
            iVar21 = 0;
            iVar19 = 0;
            uVar20 = 0;
            uVar13 = uVar16;
            goto LAB_14003f825;
          }
        }
      }
    }
    else if ((*pcVar5 != '\x02') && (local_68 != 0x100000000000000 || uVar6 != 0)) {
      if ((uVar20 & 1) == 0) {
        uVar16 = uVar13;
      }
      uVar20 = 1;
      iVar21 = 0;
      iVar19 = 0;
      pcVar22 = (code *)(uVar6 >> 0x20 | local_68 << 0x20);
      uVar23 = uVar23 << 0x10;
      uVar17 = (uint)((ulonglong)local_68 >> 0x20);
      uVar13 = (ushort)(uVar6 >> 0x10);
      goto LAB_14003f825;
    }
  }
LAB_14003f9bf:
  if (uVar20 == (ushort)*puVar4) {
    if ((uVar20 & 1) == 0) {
      if ((*(ushort *)((longlong)param_3 + 0xe) == *(ushort *)((longlong)puVar4 + 6)) &&
         (*(int *)((longlong)param_3 + 10) == *(int *)((longlong)puVar4 + 2))) goto LAB_14003fbda;
    }
    else if ((uVar16 == *(ushort *)((longlong)puVar4 + 0x1c)) &&
            (((iVar19 == *(int *)((longlong)puVar4 + 0x14) && (iVar21 == (int)puVar4[3])) &&
             (auVar25[0] = -(*(char *)((longlong)puVar4 + 4) == *(char *)((longlong)param_3 + 0xc)),
             auVar25[1] = -(*(char *)((longlong)puVar4 + 5) == *(char *)((longlong)param_3 + 0xd)),
             auVar25[2] = -(*(char *)((longlong)puVar4 + 6) == *(char *)((longlong)param_3 + 0xe)),
             auVar25[3] = -(*(char *)((longlong)puVar4 + 7) == *(char *)((longlong)param_3 + 0xf)),
             auVar25[4] = -((char)puVar4[1] == *(char *)(param_3 + 2)),
             auVar25[5] = -(*(char *)((longlong)puVar4 + 9) == *(char *)((longlong)param_3 + 0x11)),
             auVar25[6] = -(*(char *)((longlong)puVar4 + 10) == *(char *)((longlong)param_3 + 0x12))
             , auVar25[7] = -(*(char *)((longlong)puVar4 + 0xb) ==
                             *(char *)((longlong)param_3 + 0x13)),
             auVar25[8] = -(*(char *)((longlong)puVar4 + 0xc) == *(char *)((longlong)param_3 + 0x14)
                           ),
             auVar25[9] = -(*(char *)((longlong)puVar4 + 0xd) == *(char *)((longlong)param_3 + 0x15)
                           ),
             auVar25[10] = -(*(char *)((longlong)puVar4 + 0xe) ==
                            *(char *)((longlong)param_3 + 0x16)),
             auVar25[0xb] = -(*(char *)((longlong)puVar4 + 0xf) ==
                             *(char *)((longlong)param_3 + 0x17)),
             auVar25[0xc] = -((char)puVar4[2] == *(char *)(param_3 + 3)),
             auVar25[0xd] = -(*(char *)((longlong)puVar4 + 0x11) ==
                             *(char *)((longlong)param_3 + 0x19)),
             auVar25[0xe] = -(*(char *)((longlong)puVar4 + 0x12) ==
                             *(char *)((longlong)param_3 + 0x1a)),
             auVar25[0xf] = -(*(char *)((longlong)puVar4 + 0x13) ==
                             *(char *)((longlong)param_3 + 0x1b)),
             (ushort)((ushort)(SUB161(auVar25 >> 7,0) & 1) |
                      (ushort)(SUB161(auVar25 >> 0xf,0) & 1) << 1 |
                      (ushort)(SUB161(auVar25 >> 0x17,0) & 1) << 2 |
                      (ushort)(SUB161(auVar25 >> 0x1f,0) & 1) << 3 |
                      (ushort)(SUB161(auVar25 >> 0x27,0) & 1) << 4 |
                      (ushort)(SUB161(auVar25 >> 0x2f,0) & 1) << 5 |
                      (ushort)(SUB161(auVar25 >> 0x37,0) & 1) << 6 |
                      (ushort)(SUB161(auVar25 >> 0x3f,0) & 1) << 7 |
                      (ushort)(SUB161(auVar25 >> 0x47,0) & 1) << 8 |
                      (ushort)(SUB161(auVar25 >> 0x4f,0) & 1) << 9 |
                      (ushort)(SUB161(auVar25 >> 0x57,0) & 1) << 10 |
                      (ushort)(SUB161(auVar25 >> 0x5f,0) & 1) << 0xb |
                      (ushort)(SUB161(auVar25 >> 0x67,0) & 1) << 0xc |
                      (ushort)(SUB161(auVar25 >> 0x6f,0) & 1) << 0xd |
                      (ushort)(SUB161(auVar25 >> 0x77,0) & 1) << 0xe |
                     (ushort)(auVar25[0xf] >> 7) << 0xf) == 0xffff)))) goto LAB_14003fbda;
  }
  pppppppuVar9 = (undefined8 *******)*param_3;
  local_a8 = (code *)*puVar4;
  ppuStack_a0 = (undefined **)puVar4[1];
  local_98 = (code *)puVar4[2];
  uStack_90 = puVar4[3];
  LOCK();
  bVar24 = host_probe[b94139f9089eb1d8]::net::UNLISTED == '\0';
  if (bVar24) {
    host_probe[b94139f9089eb1d8]::net::UNLISTED = '\x01';
  }
  UNLOCK();
  local_48 = pppppppuVar9;
  if (!bVar24) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
              (&host_probe[b94139f9089eb1d8]::net::UNLISTED);
  }
  puVar10 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar12 = 0;
    plVar14 = (longlong *)
              __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
    ;
  }
  else {
    bVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar12 = bVar12 ^ 1;
    plVar14 = (longlong *)
              __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
    ;
  }
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
       = (undefined *)plVar14;
  if (DAT_1407f0161 != '\0') {
    local_d0 = (undefined8 *******)&host_probe[b94139f9089eb1d8]::net::UNLISTED;
    uVar6 = (ulonglong)local_c8 >> 8;
    local_c8 = (code *)CONCAT71((int7)uVar6,bVar12);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_d0,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0e70
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2208);
LAB_14003fcfa:
                    /* WARNING: Does not return */
    pcVar22 = (code *)invalidInstructionException();
    (*pcVar22)();
  }
  if (DAT_1407f0168 == (undefined *)0x0) {
    if (*plVar14 != 0) {
      std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
    }
    if ((int)plVar14[3] == 0) {
      dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                             (
                             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                             );
      plVar14 = TlsGetValue(dwTlsIndex);
    }
    else {
      dwTlsIndex = (int)plVar14[3] - 1;
      plVar14 = TlsGetValue(dwTlsIndex);
    }
    if (plVar14 < (longlong *)0x2) {
      plVar14 = (longlong *)
                <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                ::try_initialize::
                <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                          (dwTlsIndex,plVar14,0);
    }
    if (plVar14 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
      goto LAB_14003fcfa;
    }
    _DAT_1407f0188 = *plVar14;
    lRam00000001407f0190 = plVar14[1];
    *plVar14 = *plVar14 + 1;
    _DAT_1407f0178 = 0;
    DAT_1407f0180 = 0;
    DAT_1407f0168 = &DAT_1406a0540;
    uRam00000001407f0170 = 0;
LAB_14003faff:
    local_c8 = local_a8;
    uStack_c0 = ppuStack_a0;
    local_b8 = local_98;
    uStack_b0 = uStack_90;
    local_d0 = pppppppuVar9;
    cVar11 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr),(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
             ::insert(&DAT_1407f0168,&local_d0);
    if (cVar11 == '\0') {
      local_d0 = &local_48;
      local_c8 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      uStack_c0 = (undefined **)&local_a8;
      local_b8 = <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::fmt::Display>
                 ::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_80,&DAT_1406a2220,&local_d0);
      host_probe[b94139f9089eb1d8]::host::log(uStack_78,local_70);
      if (local_80 != 0) {
        puVar15 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_78,local_80,1);
        return puVar15;
      }
    }
  }
  else if (DAT_1407f0180 < 0x400) goto LAB_14003faff;
  if (((bVar12 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
     (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0'))
  {
    DAT_1407f0161 = '\x01';
  }
  cVar11 = host_probe[b94139f9089eb1d8]::net::UNLISTED;
  LOCK();
  host_probe[b94139f9089eb1d8]::net::UNLISTED = '\0';
  UNLOCK();
  if (cVar11 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake
              (&host_probe[b94139f9089eb1d8]::net::UNLISTED);
  }
LAB_14003fbda:
  local_60[1] = 0xffffffffffffffff;
  return local_60;
}

