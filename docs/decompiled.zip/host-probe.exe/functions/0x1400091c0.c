// rea decompile_all
// name: <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<usize>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold::<usize,core[505b25137b8ba7f]::iter::traits::iterator::Iterator::max_by::fold<usize,<usize_as_core[505b25137b8ba7f]::cmp::Ord>::cmp>::{closure#0}>
// address: 0x1400091c0
// body: available
// range: 0x1400091c0-0x14000933c inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<usize>>
   as core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold::<usize,
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::max_by::fold<usize, <usize as
   core[505b25137b8ba7f]::cmp::Ord>::cmp>::{closure#0}> */

void __rustcall
<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<usize>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
::fold::
<usize,core[505b25137b8ba7f]::iter::traits::iterator::Iterator::max_by::fold<usize,<usize_as_core[505b25137b8ba7f]::cmp::Ord>::cmp>::_closure_0_>
          (longlong param_1,longlong param_2,ulonglong param_3)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined1 auVar4 [16];
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined1 auVar11 [16];
  int iVar14;
  undefined1 auVar12 [16];
  int iVar15;
  undefined1 auVar13 [16];
  int iVar16;
  int iVar18;
  int iVar19;
  int iVar20;
  undefined1 auVar17 [16];
  
  if (param_1 != param_2) {
    uVar3 = (ulonglong)(param_2 - param_1) >> 3;
    if (0x1f < (ulonglong)(param_2 - param_1)) {
      uVar2 = uVar3 & 0xfffffffffffffffc;
      auVar6._8_4_ = (int)param_3;
      auVar6._0_8_ = param_3;
      auVar6._12_4_ = (int)(param_3 >> 0x20);
      uVar1 = 0;
      auVar8 = auVar6;
      do {
        auVar7 = *(undefined1 (*) [16])(param_1 + uVar1 * 8);
        auVar4 = *(undefined1 (*) [16])(param_1 + 0x10 + uVar1 * 8);
        auVar5 = auVar6 ^ _DAT_1406a0060;
        auVar12 = auVar7 ^ _DAT_1406a0060;
        iVar16 = -(uint)(auVar12._0_4_ < auVar5._0_4_);
        iVar18 = -(uint)(auVar12._4_4_ < auVar5._4_4_);
        iVar19 = -(uint)(auVar12._8_4_ < auVar5._8_4_);
        iVar20 = -(uint)(auVar12._12_4_ < auVar5._12_4_);
        iVar14 = -(uint)(auVar12._4_4_ == auVar5._4_4_);
        iVar15 = -(uint)(auVar12._12_4_ == auVar5._12_4_);
        auVar12._4_4_ = iVar14;
        auVar12._0_4_ = iVar14;
        auVar12._8_4_ = iVar15;
        auVar12._12_4_ = iVar15;
        auVar5._4_4_ = iVar16;
        auVar5._0_4_ = iVar16;
        auVar5._8_4_ = iVar19;
        auVar5._12_4_ = iVar19;
        auVar13._4_4_ = iVar18;
        auVar13._0_4_ = iVar18;
        auVar13._8_4_ = iVar20;
        auVar13._12_4_ = iVar20;
        auVar13 = auVar13 | auVar12 & auVar5;
        auVar6 = ~auVar13 & auVar7 | auVar6 & auVar13;
        auVar7 = auVar8 ^ _DAT_1406a0060;
        auVar5 = auVar4 ^ _DAT_1406a0060;
        iVar14 = -(uint)(auVar5._0_4_ < auVar7._0_4_);
        iVar16 = -(uint)(auVar5._4_4_ < auVar7._4_4_);
        iVar15 = -(uint)(auVar5._8_4_ < auVar7._8_4_);
        iVar18 = -(uint)(auVar5._12_4_ < auVar7._12_4_);
        auVar17._4_4_ = iVar14;
        auVar17._0_4_ = iVar14;
        auVar17._8_4_ = iVar15;
        auVar17._12_4_ = iVar15;
        iVar14 = -(uint)(auVar5._4_4_ == auVar7._4_4_);
        iVar15 = -(uint)(auVar5._12_4_ == auVar7._12_4_);
        auVar7._4_4_ = iVar14;
        auVar7._0_4_ = iVar14;
        auVar7._8_4_ = iVar15;
        auVar7._12_4_ = iVar15;
        auVar10._4_4_ = iVar16;
        auVar10._0_4_ = iVar16;
        auVar10._8_4_ = iVar18;
        auVar10._12_4_ = iVar18;
        auVar10 = auVar10 | auVar7 & auVar17;
        auVar8 = ~auVar10 & auVar4 | auVar8 & auVar10;
        uVar1 = uVar1 + 4;
      } while (uVar2 != uVar1);
      auVar5 = auVar8 ^ _DAT_1406a0060;
      auVar7 = _DAT_1406a0060 ^ auVar6;
      iVar14 = -(uint)(auVar5._0_4_ < auVar7._0_4_);
      iVar15 = -(uint)(auVar5._4_4_ < auVar7._4_4_);
      iVar16 = -(uint)(auVar5._8_4_ < auVar7._8_4_);
      iVar18 = -(uint)(auVar5._12_4_ < auVar7._12_4_);
      auVar11._4_4_ = iVar14;
      auVar11._0_4_ = iVar14;
      auVar11._8_4_ = iVar16;
      auVar11._12_4_ = iVar16;
      auVar4._4_4_ = -(uint)(auVar7._4_4_ == auVar5._4_4_);
      auVar4._12_4_ = -(uint)(auVar7._12_4_ == auVar5._12_4_);
      auVar4._0_4_ = auVar4._4_4_;
      auVar4._8_4_ = auVar4._12_4_;
      auVar9._4_4_ = iVar15;
      auVar9._0_4_ = iVar15;
      auVar9._8_4_ = iVar18;
      auVar9._12_4_ = iVar18;
      auVar9 = auVar9 | auVar4 & auVar11;
      auVar8 = ~auVar9 & auVar8 | auVar6 & auVar9;
      uVar1 = auVar8._0_8_;
      param_3 = auVar8._8_8_;
      if (uVar1 <= param_3) goto LAB_140009324;
      param_3 = uVar1;
      goto LAB_140009324;
    }
    uVar2 = 0;
    do {
      uVar1 = *(ulonglong *)(param_1 + uVar2 * 8);
      if (uVar1 < param_3) {
        uVar1 = param_3;
      }
      uVar2 = uVar2 + 1;
      param_3 = uVar1;
LAB_140009324:
    } while (uVar3 != uVar2);
  }
  return;
}

