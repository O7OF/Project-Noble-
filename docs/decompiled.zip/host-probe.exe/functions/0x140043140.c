// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,2usize>>
// address: 0x140043140
// body: available
// range: 0x140043140-0x140043266 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,
   2usize>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::
<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,2usize>>
          (longlong *param_1,ulonglong *param_2)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong local_58 [4];
  ulonglong local_38;
  ulonglong uStack_30;
  
  lVar4 = param_1[2];
  if ((ulonglong)(*param_1 - lVar4) < param_2[1] - *param_2) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar4,param_2[1] - *param_2,8,0x18);
    lVar4 = param_1[2];
  }
  lVar1 = param_1[1];
  uVar7 = *param_2;
  uVar2 = param_2[1];
  local_58[3] = param_2[5];
  local_38 = param_2[6];
  uStack_30 = param_2[7];
  local_58[2] = param_2[4];
  local_58[0] = param_2[2];
  local_58[1] = param_2[3];
  if (uVar2 != uVar7) {
    uVar6 = uVar7;
    if (((int)uVar2 - (int)uVar7 & 1U) != 0) {
      *(ulonglong *)(lVar1 + 0x10 + lVar4 * 0x18) = local_58[uVar7 * 3 + 2];
      uVar6 = local_58[uVar7 * 3 + 1];
      puVar5 = (ulonglong *)(lVar1 + lVar4 * 0x18);
      *puVar5 = local_58[uVar7 * 3];
      puVar5[1] = uVar6;
      lVar4 = lVar4 + 1;
      uVar6 = uVar7 + 1;
    }
    if (uVar2 != uVar7 + 1) {
      puVar5 = (ulonglong *)(lVar1 + lVar4 * 0x18);
      uVar7 = uVar6;
      do {
        lVar4 = lVar4 + 2;
        puVar5[2] = local_58[uVar7 * 3 + 2];
        uVar3 = local_58[uVar7 * 3 + 1];
        *puVar5 = local_58[uVar7 * 3];
        puVar5[1] = uVar3;
        puVar5[3] = local_58[3];
        puVar5[4] = local_38;
        puVar5[5] = uStack_30;
        puVar5 = puVar5 + 6;
        uVar7 = uVar6 | 2;
      } while ((uVar6 | 2) != uVar2);
    }
  }
  param_1[2] = lVar4;
  return;
}

