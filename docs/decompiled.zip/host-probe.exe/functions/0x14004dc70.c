// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,std[3bf9d48a0c3997f0]::env::Args>>::from_iter
// address: 0x14004dc70
// body: available
// range: 0x14004dc70-0x14004dd2f inclusive
// range: 0x14004dd32-0x14004dd50 inclusive
// range: 0x14004dd56-0x14004dddb inclusive
// range: 0x14004dde0-0x14004de7c inclusive
// range: 0x14004de80-0x14004de9f inclusive
// range: 0x14004dea2-0x14004dee7 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14004dd2b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004dd4c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004de9b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004debb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   std[3bf9d48a0c3997f0]::env::Args>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,std[3bf9d48a0c3997f0]::env::Args>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  longlong lVar3;
  longlong *plVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined8 uVar9;
  longlong unaff_R15;
  longlong local_b0;
  longlong *plStack_a8;
  longlong local_a0;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  longlong local_88;
  longlong lStack_80;
  longlong local_70;
  longlong lStack_68;
  longlong local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  <std[3bf9d48a0c3997f0]::env::Args_as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::
  next(&local_70);
  if (local_70 == -1) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
    uVar6 = param_2[3] - param_2[1];
    if (uVar6 != 0) {
      uVar6 = uVar6 >> 5;
      puVar8 = (undefined8 *)(param_2[1] + 8);
      do {
        if (puVar8[-1] != 0) {
          plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar8,puVar8[-1],1);
          return plVar4;
        }
        puVar8 = puVar8 + 4;
        uVar6 = uVar6 - 1;
      } while (uVar6 != 0);
    }
    if (param_2[2] == 0) {
      return param_1;
    }
    plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_dealloc(*param_2,param_2[2] << 5,8);
    return plVar4;
  }
  uVar5 = (ulonglong)(param_2[3] - param_2[1]) >> 5;
  uVar6 = 3;
  if (3 < uVar5) {
    uVar6 = uVar5;
  }
  if ((ulonglong)(param_2[3] - param_2[1]) < 0xaaaaaaaaaaaaaa81) {
    unaff_R15 = (uVar6 + 1) * 0x18;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar9 = 8;
    plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(unaff_R15,8);
    if (plVar4 != (longlong *)0x0) {
      plVar4[2] = local_60;
      *plVar4 = local_70;
      plVar4[1] = lStack_68;
      local_a0 = 1;
      local_98 = *(undefined4 *)param_2;
      uStack_94 = *(undefined4 *)((longlong)param_2 + 4);
      uStack_90 = *(undefined4 *)(param_2 + 1);
      uStack_8c = *(undefined4 *)((longlong)param_2 + 0xc);
      local_88 = param_2[2];
      lStack_80 = param_2[3];
      lVar7 = 0;
      local_b0 = uVar6 + 1;
      plStack_a8 = plVar4;
      while (lVar3 = local_a0,
            <std[3bf9d48a0c3997f0]::env::Args_as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
            ::next(&local_58,&local_98), CONCAT44(uStack_54,local_58) != -1) {
        if (lVar3 == local_b0) {
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>
                    (&local_b0,lVar3,
                     ((ulonglong)(lStack_80 - CONCAT44(uStack_8c,uStack_90)) >> 5) + 1,8,0x18);
          plVar4 = plStack_a8;
        }
        *(undefined8 *)(lVar7 + 0x28 + (longlong)plVar4) = local_48;
        puVar1 = (undefined4 *)(lVar7 + 0x18 + (longlong)plVar4);
        *puVar1 = local_58;
        puVar1[1] = uStack_54;
        puVar1[2] = uStack_50;
        puVar1[3] = uStack_4c;
        local_a0 = lVar3 + 1;
        lVar7 = lVar7 + 0x18;
      }
      uVar6 = lStack_80 - CONCAT44(uStack_8c,uStack_90);
      if (uVar6 != 0) {
        uVar6 = uVar6 >> 5;
        puVar8 = (undefined8 *)(CONCAT44(uStack_8c,uStack_90) + 8);
        do {
          if (puVar8[-1] != 0) {
            plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar8,puVar8[-1],1);
            return plVar4;
          }
          puVar8 = puVar8 + 4;
          uVar6 = uVar6 - 1;
        } while (uVar6 != 0);
      }
      if (local_88 == 0) {
        param_1[2] = local_a0;
        *param_1 = local_b0;
        param_1[1] = (longlong)plStack_a8;
        return param_1;
      }
      plVar4 = (longlong *)
               __rustc[9d087a5ab36ea756]::__rust_dealloc
                         (CONCAT44(uStack_94,local_98),local_88 << 5,8);
      return plVar4;
    }
  }
  else {
    uVar9 = 0;
  }
  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar9,unaff_R15);
                    /* WARNING: Does not return */
  pcVar2 = (code *)invalidInstructionException();
  (*pcVar2)();
}

