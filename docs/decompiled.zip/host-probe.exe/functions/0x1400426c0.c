// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(usize,alloc[246c2e7857c81348]::boxed::Box<[i32;47usize]>)>>::retain::<host_probe[b94139f9089eb1d8]::machinex::reset_parameter_times::{closure#0}>
// address: 0x1400426c0
// body: available
// range: 0x1400426c0-0x1400427c2 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400427be to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(usize, alloc[246c2e7857c81348]::boxed::Box<[i32;
   47usize]>)>>::retain::<host_probe[b94139f9089eb1d8]::machinex::reset_parameter_times::{closure#0}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(usize,alloc[246c2e7857c81348]::boxed::Box<[i32;47usize]>)>>::
retain::<host_probe[b94139f9089eb1d8]::machinex::reset_parameter_times::_closure_0_>
          (longlong param_1,longlong *param_2)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  
  uVar1 = *(ulonglong *)(param_1 + 0x10);
  if (uVar1 != 0) {
    lVar7 = *(longlong *)(param_1 + 8);
    lVar2 = *param_2;
    uVar5 = (ulonglong)((uint)uVar1 & 3);
    if (uVar1 < 4) {
      lVar6 = 0;
    }
    else {
      lVar3 = 0;
      lVar6 = 0;
      do {
        if (*(longlong *)(lVar7 + lVar3) == lVar2) {
          plVar4 = (longlong *)(lVar3 + lVar7);
          goto LAB_1400427af;
        }
        lVar8 = lVar6 * 0x10;
        if (*(longlong *)(lVar7 + 0x10 + lVar3) == lVar2) {
          plVar4 = (longlong *)(lVar7 + lVar8 + 0x10);
          goto LAB_1400427af;
        }
        if (*(longlong *)(lVar7 + 0x20 + lVar3) == lVar2) {
          plVar4 = (longlong *)(lVar7 + lVar8 + 0x20);
          goto LAB_1400427af;
        }
        if (*(longlong *)(lVar7 + 0x30 + lVar3) == lVar2) {
          plVar4 = (longlong *)(lVar7 + lVar8 + 0x30);
          goto LAB_1400427af;
        }
        lVar6 = lVar6 + 4;
        lVar3 = lVar3 + 0x40;
      } while ((uVar1 & 0xffffffffffffffc) * 0x10 != lVar3);
      if (uVar5 == 0) {
        return;
      }
    }
    plVar4 = (longlong *)(lVar6 * 0x10 + lVar7);
    lVar7 = 0;
    do {
      if (*plVar4 == lVar2) {
LAB_1400427af:
        __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar4[1],0xbc,4);
        return;
      }
      lVar7 = lVar7 + -1;
      plVar4 = plVar4 + 2;
    } while (-lVar7 != uVar5);
  }
  return;
}

