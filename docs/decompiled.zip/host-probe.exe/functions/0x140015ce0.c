// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>::truncate
// address: 0x140015ce0
// body: available
// range: 0x140015ce0-0x140015e01 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>::truncate
    */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>
::truncate(ulonglong *param_1,ulonglong param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  
  uVar1 = param_1[3];
  if (param_2 < uVar1) {
    uVar2 = param_1[2];
    uVar3 = *param_1;
    uVar4 = param_1[1];
    uVar5 = uVar3;
    if (uVar2 < uVar3) {
      uVar5 = 0;
    }
    lVar8 = uVar2 - uVar5;
    uVar9 = uVar3 - lVar8;
    uVar6 = uVar1 - uVar9;
    if (uVar1 < uVar9) {
      uVar6 = 0;
    }
    uVar10 = lVar8 + uVar1;
    if (uVar1 >= uVar9 && uVar1 - uVar9 != 0) {
      uVar10 = uVar3;
    }
    uVar10 = uVar10 - lVar8;
    param_1[3] = param_2;
    if (param_2 < uVar10 || param_2 - uVar10 == 0) {
      lVar8 = uVar10 - param_2;
      if (lVar8 != 0) {
        lVar7 = param_2 * 0xa0 + uVar2 * 0xa0 + uVar5 * -0xa0 + uVar4 + 0x20;
        do {
          core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                    (lVar7);
          lVar7 = lVar7 + 0xa0;
          lVar8 = lVar8 + -1;
        } while (lVar8 != 0);
      }
      if (uVar9 < uVar1) {
        lVar8 = uVar4 + 0x20;
        do {
          core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                    (lVar8);
          lVar8 = lVar8 + 0xa0;
          uVar6 = uVar6 - 1;
        } while (uVar6 != 0);
      }
    }
    else {
      lVar8 = uVar6 - (param_2 - uVar10);
      if (lVar8 != 0) {
        lVar7 = uVar4 + param_2 * 0xa0 + uVar10 * -0xa0 + 0x20;
        do {
          core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                    (lVar7);
          lVar7 = lVar7 + 0xa0;
          lVar8 = lVar8 + -1;
        } while (lVar8 != 0);
      }
    }
  }
  return;
}

