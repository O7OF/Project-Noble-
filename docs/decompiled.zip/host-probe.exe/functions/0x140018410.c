// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::filter_keys
// address: 0x140018410
// body: available
// range: 0x140018410-0x1400186d5 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400186a5 to 0x140610d80 <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::filter_keys */

void __rustcall host_probe[b94139f9089eb1d8]::ingame_chat::filter_keys(longlong param_1)

{
  char cVar1;
  code *pcVar2;
  undefined *puVar3;
  byte bVar4;
  byte bVar5;
  char cVar6;
  BOOL BVar7;
  byte bVar8;
  ulonglong uVar9;
  byte bVar10;
  WPARAM wParam;
  byte bVar11;
  bool bVar12;
  undefined1 *local_30;
  byte local_28;
  
  if (ENABLED_0_llvm_14435704873730135342 == '\0') {
    return;
  }
  LOCK();
  bVar12 = STATE == '\0';
  if (bVar12) {
    STATE = '\x01';
  }
  UNLOCK();
  if (!bVar12) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&STATE);
  }
  puVar3 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar5 = 0;
  }
  else {
    bVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar5 = bVar5 ^ 1;
  }
  if (DAT_140699029 == '\0') {
    if (DAT_140699030 == -1) {
LAB_1400185f4:
      if (((bVar5 == 0) && ((*(ulonglong *)puVar3 & 0x7fffffffffffffff) != 0)) &&
         (cVar6 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar6 == '\0')
         ) {
        DAT_140699029 = '\x01';
      }
      cVar6 = STATE;
      LOCK();
      STATE = 0;
      UNLOCK();
      if (cVar6 != '\x02') {
        STATE = 0;
        return;
      }
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&STATE);
      return;
    }
    if (((DAT_1406994d0 == (HWND)0x0) ||
        (BVar7 = IsWindow(DAT_1406994d0), bVar10 = DAT_140699498, BVar7 == 0)) ||
       (win::GAME_MENU_OPEN_0_llvm_15994678344015752266 != '\0')) {
      uVar9 = DAT_140699480;
      if (((DAT_140699480 < 0x100) &&
          (DAT_140699498 = 0, uVar9 = DAT_140699488, DAT_140699488 < 0x100)) &&
         (DAT_140699499 = 0, uVar9 = DAT_140699490, DAT_140699490 < 0x100)) {
        DAT_14069949a = 0;
        goto LAB_1400185f4;
      }
    }
    else {
      uVar9 = DAT_140699480;
      if (DAT_140699480 < 0x100) {
        cVar6 = *(char *)(param_1 + DAT_140699480);
        DAT_140699498 = cVar6 != '\0';
        *(undefined1 *)(param_1 + DAT_140699480) = 0;
        bVar4 = DAT_140699499;
        uVar9 = DAT_140699488;
        if (DAT_140699488 < 0x100) {
          cVar1 = *(char *)(param_1 + DAT_140699488);
          DAT_140699499 = cVar1 != '\0';
          *(undefined1 *)(param_1 + DAT_140699488) = 0;
          uVar9 = DAT_140699490;
          if (DAT_140699490 < 0x100) {
            bVar4 = bVar4 ^ 1 | cVar1 != '\0';
            bVar10 = cVar6 == '\0' & bVar10;
            bVar11 = bVar4 ^ 1 | bVar10;
            bVar12 = *(char *)(param_1 + DAT_140699490) != '\0';
            *(undefined1 *)(param_1 + DAT_140699490) = 0;
            bVar8 = DAT_14069949a ^ 1 | bVar12;
            DAT_14069949a = bVar12;
            if ((bVar8 != 1) || (bVar11 != 0)) {
              wParam = 3;
              if (((bVar8 | bVar11) & 1) != 0) {
                wParam = 2 - (ulonglong)((bVar4 | bVar10) & 1);
              }
              PostMessageW(DAT_1406994d0,0x800c,wParam,0);
            }
            goto LAB_1400185f4;
          }
        }
      }
    }
    core[505b25137b8ba7f]::panicking::panic_bounds_check(uVar9,0x100,&DAT_1406a1598);
  }
  else {
    local_30 = &STATE;
    local_28 = bVar5;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_30,
               &anon_d5c34e88a06ee720b116585eb143da4b_137_llvm_14435704873730135342,&DAT_1406a1a58);
  }
                    /* WARNING: Does not return */
  pcVar2 = (code *)invalidInstructionException();
  (*pcVar2)();
}

