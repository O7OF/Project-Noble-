// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<std[3bf9d48a0c3997f0]::path::PathBuf>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<std[3bf9d48a0c3997f0]::path::PathBuf,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,std[3bf9d48a0c3997f0]::path::PathBuf)>,host_probe[b94139f9089eb1d8]::firewall::run::{closure#3}>,host_probe[b94139f9089eb1d8]::firewall::run::{closure#4}>>>::from_iter
// address: 0x14004e3c0
// body: available
// range: 0x14004e3c0-0x14004e3e3 inclusive
// range: 0x14004e3f0-0x14004e4f9 inclusive
// range: 0x14004e500-0x14004e629 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<std[3bf9d48a0c3997f0]::path::PathBuf> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<std[3bf9d48a0c3997f0]::path::PathBuf,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,
   std[3bf9d48a0c3997f0]::path::PathBuf)>,
   host_probe[b94139f9089eb1d8]::firewall::run::{closure#3}>,
   host_probe[b94139f9089eb1d8]::firewall::run::{closure#4}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<std[3bf9d48a0c3997f0]::path::PathBuf>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<std[3bf9d48a0c3997f0]::path::PathBuf,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,std[3bf9d48a0c3997f0]::path::PathBuf)>,host_probe[b94139f9089eb1d8]::firewall::run::{closure#3}>,host_probe[b94139f9089eb1d8]::firewall::run::{closure#4}>>>
::from_iter(longlong *param_1,longlong param_2,longlong param_3)

{
  undefined1 uVar1;
  size_t _Size;
  void *pvVar2;
  code *pcVar3;
  longlong lVar4;
  void *pvVar5;
  size_t *psVar6;
  longlong lVar7;
  undefined8 uVar8;
  void *local_60;
  longlong local_58;
  size_t *local_50;
  longlong local_48;
  
  do {
    lVar4 = param_2;
    if (lVar4 == param_3) {
      *param_1 = 0;
      param_1[1] = 8;
      param_1[2] = 0;
      return param_1;
    }
    param_2 = lVar4 + 0x38;
  } while ((*(longlong *)(lVar4 + 0x10) != 7) ||
          (*(int *)((longlong)*(int **)(lVar4 + 8) + 3) != 0x64656b63 ||
           **(int **)(lVar4 + 8) != 0x636f6c62));
  _Size = *(size_t *)(lVar4 + 0x28);
  if ((longlong)_Size < 0) {
    uVar8 = 0;
LAB_14004e425:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar8,_Size);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  if (_Size == 0) {
    pvVar5 = (void *)0x1;
  }
  else {
    pvVar2 = *(void **)(lVar4 + 0x20);
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar8 = 1;
    pvVar5 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size,1);
    if (pvVar5 == (void *)0x0) goto LAB_14004e425;
    memcpy(pvVar5,pvVar2,_Size);
  }
  uVar1 = *(undefined1 *)(lVar4 + 0x30);
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  psVar6 = (size_t *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x80,8);
  if (psVar6 == (size_t *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x80);
LAB_14004e61c:
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  *psVar6 = _Size;
  psVar6[1] = (size_t)pvVar5;
  psVar6[2] = _Size;
  *(undefined1 *)(psVar6 + 3) = uVar1;
  local_58 = 4;
  local_48 = 1;
  local_50 = psVar6;
  if (param_2 != param_3) {
    do {
      while ((lVar4 = local_48, lVar7 = param_2 + 0x38, *(longlong *)(param_2 + 0x10) == 7 &&
             (*(int *)((longlong)*(int **)(param_2 + 8) + 3) == 0x64656b63 &&
              **(int **)(param_2 + 8) == 0x636f6c62))) {
        pvVar5 = *(void **)(param_2 + 0x28);
        if ((longlong)pvVar5 < 0) {
          uVar8 = 0;
LAB_14004e601:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uVar8,local_60);
          goto LAB_14004e61c;
        }
        if (pvVar5 == (void *)0x0) {
          local_60 = (void *)0x1;
        }
        else {
          pvVar2 = *(void **)(param_2 + 0x20);
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          local_60 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(pvVar5,1);
          if (local_60 == (void *)0x0) {
            uVar8 = 1;
            local_60 = pvVar5;
            goto LAB_14004e601;
          }
          memcpy(local_60,pvVar2,(size_t)pvVar5);
        }
        uVar1 = *(undefined1 *)(param_2 + 0x30);
        if (lVar4 == local_58) {
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>(&local_58,lVar4,1,8,0x20);
          psVar6 = local_50;
        }
        psVar6[lVar4 * 4] = (size_t)pvVar5;
        psVar6[lVar4 * 4 + 1] = (size_t)local_60;
        psVar6[lVar4 * 4 + 2] = (size_t)pvVar5;
        *(undefined1 *)(psVar6 + lVar4 * 4 + 3) = uVar1;
        local_48 = lVar4 + 1;
        param_2 = lVar7;
        if (lVar7 == param_3) goto LAB_14004e5e0;
      }
      param_2 = lVar7;
    } while (lVar7 != param_3);
  }
LAB_14004e5e0:
  param_1[2] = local_48;
  *param_1 = local_58;
  param_1[1] = (longlong)local_50;
  return param_1;
}

