// rea decompile_all
// name: std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::announce::announce::{closure#26},()>
// address: 0x140005340
// body: available
// range: 0x140005340-0x1400054d2 inclusive
// range: 0x1400054e0-0x140005584 inclusive
// range: 0x140005590-0x1400056c7 inclusive
// range: 0x1400056d0-0x140005767 inclusive
// range: 0x140005770-0x1400057d7 inclusive
// range: 0x1400057da-0x14000582c inclusive
// range: 0x140005830-0x14000584f inclusive
// range: 0x140005852-0x1400058f3 inclusive
// range: 0x140005900-0x1400059c9 inclusive
// range: 0x1400059cf-0x140005a36 inclusive
// range: 0x140005a40-0x140005b10 inclusive
// range: 0x140005b16-0x140005b45 inclusive
// range: 0x140005b50-0x140005b6f inclusive
// range: 0x140005b72-0x140005bda inclusive
// range: 0x140005be0-0x140005c00 inclusive
// range: 0x140005c03-0x140005d40 inclusive
// range: 0x140005d50-0x140005d73 inclusive
// range: 0x140005d76-0x140005dd2 inclusive
// range: 0x140005de0-0x140005ea6 inclusive
// range: 0x140005eac-0x140005ee0 inclusive
// range: 0x140005ef0-0x140005f0f inclusive
// range: 0x140005f12-0x14000612f inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140005554 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000567a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000569f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400056c3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400056f7 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000578c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400057a4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400057bc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400057d3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000584b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400059a7 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400059c5 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::announce::announce::{closure#26},
   ()> */

void __rustcall
std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::
<host_probe[b94139f9089eb1d8]::announce::announce::_closure_26_,()>
          (longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined1 auVar2 [16];
  code *pcVar3;
  longlong *plVar4;
  byte bVar5;
  char cVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  longlong lVar13;
  ulonglong *puVar14;
  undefined8 *puVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong *plVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  longlong *plVar21;
  bool bVar22;
  undefined1 *in_stack_fffffffffffffc08;
  undefined4 uVar23;
  longlong *local_3d8;
  longlong *local_3d0;
  longlong *plStack_3c8;
  longlong *local_3c0;
  longlong local_3b8;
  undefined4 uStack_3b0;
  undefined4 uStack_3ac;
  undefined4 uStack_3a8;
  undefined4 uStack_3a4;
  longlong **local_398;
  undefined8 *local_390;
  undefined8 local_388;
  longlong local_380;
  longlong local_378;
  longlong local_370;
  longlong *local_368;
  undefined8 *puStack_360;
  longlong *local_358;
  longlong *local_350;
  longlong local_348;
  longlong *local_340;
  longlong *local_338;
  longlong *plStack_330;
  undefined8 local_328;
  undefined8 uStack_320;
  undefined4 local_318;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined4 local_308;
  undefined4 uStack_304;
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  undefined4 local_2f8;
  undefined4 uStack_2f4;
  undefined4 uStack_2f0;
  undefined4 uStack_2ec;
  undefined8 local_230;
  longlong *local_228;
  longlong *plStack_220;
  undefined4 local_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined4 local_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined4 local_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined4 local_1e8;
  undefined4 uStack_1e4;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  longlong local_1d8;
  undefined8 local_1d0;
  longlong local_1c0;
  undefined8 local_1b8;
  longlong local_1a8;
  undefined8 local_1a0;
  undefined8 local_188;
  undefined4 local_180;
  undefined4 local_170;
  undefined2 local_168;
  undefined1 local_166;
  undefined4 local_158;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  longlong *local_148;
  longlong *local_140;
  longlong local_138;
  longlong **pplVar12;
  
  uVar7 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  lVar13 = *(longlong *)(param_1 + 0x80);
  plVar1 = (longlong *)(lVar13 + 0x10);
  LOCK();
  bVar22 = *(char *)(lVar13 + 0x10) == '\0';
  if (bVar22) {
    *(char *)(lVar13 + 0x10) = '\x01';
  }
  UNLOCK();
  if (!bVar22) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(plVar1);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar5 = 0;
    cVar6 = *(char *)(lVar13 + 0x11);
  }
  else {
    bVar5 = panicking::panic_count::is_zero_slow_path();
    bVar5 = bVar5 ^ 1;
    cVar6 = *(char *)(lVar13 + 0x11);
  }
  if (cVar6 != '\0') {
    plStack_330._1_7_ = (undefined7)((ulonglong)plStack_330 >> 8);
    plStack_330 = (longlong *)CONCAT71(plStack_330._1_7_,bVar5);
    local_338 = plVar1;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_338,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1110
               ,&PTR_s_src_announce_rs_1406a0840);
LAB_14000610b:
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  <host_probe[b94139f9089eb1d8]::announce::Shown>::of(&local_338,lVar13 + 0x18);
  puVar14 = (ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
  ;
  local_170 = 0xffffffff;
  local_228 = local_338;
  plStack_220 = plStack_330;
  local_218 = (undefined4)local_328;
  uStack_214 = local_328._4_4_;
  uStack_210 = (undefined4)uStack_320;
  uStack_20c = uStack_320._4_4_;
  local_208 = local_318;
  uStack_204 = uStack_314;
  uStack_200 = uStack_310;
  uStack_1fc = uStack_30c;
  local_1f8 = local_308;
  uStack_1f4 = uStack_304;
  uStack_1f0 = uStack_300;
  uStack_1ec = uStack_2fc;
  local_1e8 = local_2f8;
  uStack_1e4 = uStack_2f4;
  uStack_1e0 = uStack_2f0;
  uStack_1dc = uStack_2ec;
  local_1d8 = -1;
  local_168 = 0;
  local_166 = 0;
  local_188 = uVar7;
  local_180 = param_2;
  if (((bVar5 == 0) &&
      ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
       0x7fffffffffffffff) != 0)) &&
     (cVar6 = panicking::panic_count::is_zero_slow_path(), cVar6 == '\0')) {
    *(undefined1 *)(lVar13 + 0x11) = 1;
  }
  LOCK();
  cVar6 = *(char *)plVar1;
  *(char *)plVar1 = '\0';
  UNLOCK();
  if (cVar6 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(plVar1);
  }
  <reach_directory[4b72b9694f6c3c08]::host::Publisher>::leases(&local_338,param_1);
  plVar1 = local_338;
  uStack_320 = plStack_330 + (longlong)local_328 * 0xe;
  local_338 = plStack_330;
  local_328 = plVar1;
  alloc[246c2e7857c81348]::vec::in_place_collect::from_iter_in_place::
  <core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>,host_probe[b94139f9089eb1d8]::announce::announce::_closure_26_::_closure_0_>,alloc[246c2e7857c81348]::string::String>
            (&local_380,&local_338);
  while( true ) {
    std[3bf9d48a0c3997f0]::thread::functions::sleep(1,0);
    cVar6 = host_probe[b94139f9089eb1d8]::announce::NUDGE;
    uVar23 = (undefined4)((ulonglong)in_stack_fffffffffffffc08 >> 0x20);
    if (host_probe[b94139f9089eb1d8]::announce::WITHDRAW != '\0') break;
    if (host_probe[b94139f9089eb1d8]::announce::HUNG_NOW == '\0') {
      LOCK();
      host_probe[b94139f9089eb1d8]::announce::NUDGE = '\0';
      UNLOCK();
      if (cVar6 != '\0') {
        local_168 = CONCAT11(local_168._1_1_,1);
      }
      host_probe[b94139f9089eb1d8]::announce::snapshot
                (&local_338,*(longlong *)(param_1 + 0x80) + 0x10,
                 *(longlong *)(param_1 + 0x88) + 0x10);
      pplVar12 = &local_148;
      memcpy(pplVar12,&local_338,0x108);
      uVar7 = local_230;
      <host_probe[b94139f9089eb1d8]::announce::Shown>::of(&local_338,pplVar12);
      uVar10 = SUB84(pplVar12,0);
      uVar8 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
      uVar11 = 0x3c;
      uVar9 = <reach_directory[4b72b9694f6c3c08]::host::Publisher>::heartbeat_interval
                        (param_1,0x3c,0);
      in_stack_fffffffffffffc08 = (undefined1 *)CONCAT44(uVar23,uVar11);
      cVar6 = <host_probe[b94139f9089eb1d8]::announce::Beats>::due
                        (&local_228,uVar8,uVar10,uVar9,in_stack_fffffffffffffc08,&local_338,
                         DAT_140699990 == 0);
      if (cVar6 == '\x02') {
LAB_14000565f:
        if (local_338 != (longlong *)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(plStack_330,local_338,1);
          return;
        }
        if (uStack_320 != (longlong *)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(CONCAT44(uStack_314,local_318),uStack_320,1);
          return;
        }
        if (CONCAT44(uStack_304,local_308) != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc
                    (CONCAT44(uStack_2fc,uStack_300),CONCAT44(uStack_304,local_308),1);
          return;
        }
      }
      else {
        LOCK();
        host_probe[b94139f9089eb1d8]::announce::BEATING = 1;
        UNLOCK();
        if (host_probe[b94139f9089eb1d8]::announce::WITHDRAW != '\0') {
          LOCK();
          host_probe[b94139f9089eb1d8]::announce::BEATING = 0;
          UNLOCK();
          goto LAB_14000565f;
        }
        <reach_directory[4b72b9694f6c3c08]::host::Publisher>::beat_game
                  (&local_3d8,param_1,&local_148,uVar7,cVar6,
                   &host_probe[b94139f9089eb1d8]::announce::WITHDRAW);
        plVar16 = plStack_3c8;
        plVar21 = local_3d0;
        plVar17 = local_3d8;
        plVar1 = local_3d0 + (longlong)plStack_3c8 * 3;
        local_3d8 = local_3d0;
        plStack_3c8 = plVar17;
        plVar18 = local_3d0;
        plVar4 = local_3d0;
        local_3c0 = plVar1;
        if (plVar16 != (longlong *)0x0) {
          do {
            plVar16 = plVar4 + 3;
            local_368 = (longlong *)plVar4[1];
            puStack_360 = (undefined8 *)plVar4[2];
            plVar18 = plVar16;
            if (*plVar4 == -1) break;
            local_358 = &local_3b8;
            local_350 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                         ::fmt;
            local_3b8 = *plVar4;
            uStack_3b0 = (int)plVar4[1];
            uStack_3ac = *(undefined4 *)((longlong)plVar4 + 0xc);
            uStack_3a8 = (int)plVar4[2];
            uStack_3a4 = *(undefined4 *)((longlong)plVar4 + 0x14);
            alloc[246c2e7857c81348]::fmt::format::format_inner(&local_398,&DAT_1406a0858,&local_358)
            ;
            puVar15 = local_390;
            pplVar12 = local_398;
            host_probe[b94139f9089eb1d8]::host::log(local_390,local_388);
            if (pplVar12 != (longlong **)0x0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar15,pplVar12,1);
              return;
            }
            if (local_3b8 != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(CONCAT44(uStack_3ac,uStack_3b0),local_3b8,1)
              ;
              return;
            }
            plVar18 = plVar1;
            plVar4 = plVar16;
          } while (plVar16 != plVar1);
        }
        auVar2._8_8_ = 0;
        auVar2._0_8_ = (longlong)plVar1 - (longlong)plVar18;
        uVar19 = SUB168(auVar2 * ZEXT816(0xaaaaaaaaaaaaaaab),8);
        local_3d0 = plVar18;
        if (plVar1 != plVar18) {
          uVar20 = (ulonglong)((longlong)plVar1 - (longlong)plVar18) / 0x18;
          plVar18 = plVar18 + 1;
          do {
            if (plVar18[-1] != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(*plVar18,plVar18[-1],1);
              return;
            }
            plVar18 = plVar18 + 3;
            uVar20 = uVar20 - 1;
            uVar19 = 0;
          } while (uVar20 != 0);
        }
        if (plVar17 != (longlong *)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar21,(longlong)plVar17 * 0x18,8);
          return;
        }
        uVar7 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
        puVar14 = (ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
        <host_probe[b94139f9089eb1d8]::announce::Beats>::sent
                  (&local_228,uVar7,uVar19 & 0xffffffff,&local_338,cVar6,
                   *(undefined1 *)(param_1 + 0x78));
        <reach_directory[4b72b9694f6c3c08]::host::Publisher>::leases(&local_3d8,param_1);
        in_stack_fffffffffffffc08 = &host_probe[b94139f9089eb1d8]::announce::WITHDRAW;
        host_probe[b94139f9089eb1d8]::announce::hand_over::
        <host_probe[b94139f9089eb1d8]::announce::announce::_closure_26_::_closure_1_>
                  (&local_358,&local_3d8,&local_380,&host_probe[b94139f9089eb1d8]::announce::LEASES,
                   &host_probe[b94139f9089eb1d8]::announce::WITHDRAW,
                   &host_probe[b94139f9089eb1d8]::announce::BEATING);
        plVar1 = local_358;
        if (local_358 != (longlong *)0xffffffffffffffff) {
          plVar4 = local_350 + local_348 * 3;
          local_3d8 = local_350;
          local_3d0 = local_350;
          plStack_3c8 = local_358;
          plVar17 = local_350;
          plVar21 = local_350;
          local_3c0 = plVar4;
          if (local_348 == 0) goto LAB_140005ebc;
          local_340 = local_350;
          plVar16 = local_350;
          goto LAB_140005dfa;
        }
      }
      core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::protocol::Listing>
                (&local_148);
    }
    else {
      <reach_directory[4b72b9694f6c3c08]::host::Publisher>::leases(&local_338);
      if (local_328 == (longlong *)0x0) {
        <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>as_core[505b25137b8ba7f]::ops::drop::Drop>
        ::drop(&local_338);
        if (local_338 != (longlong *)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(plStack_330,(longlong)local_338 * 0x70,8);
          return;
        }
        local_168 = CONCAT11(local_168._1_1_,1);
      }
      else {
        <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>as_core[505b25137b8ba7f]::ops::drop::Drop>
        ::drop(&local_338);
        if (local_338 != (longlong *)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(plStack_330,(longlong)local_338 * 0x70,8);
          return;
        }
        LOCK();
        host_probe[b94139f9089eb1d8]::announce::BEATING = 1;
        UNLOCK();
        if (host_probe[b94139f9089eb1d8]::announce::WITHDRAW == '\0') {
          LOCK();
          bVar22 = host_probe[b94139f9089eb1d8]::announce::LEASES == '\0';
          if (bVar22) {
            host_probe[b94139f9089eb1d8]::announce::LEASES = '\x01';
          }
          UNLOCK();
          if (!bVar22) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                      (&host_probe[b94139f9089eb1d8]::announce::LEASES);
          }
          if ((*puVar14 & 0x7fffffffffffffff) == 0) {
            bVar5 = 0;
            lVar13 = DAT_14069ddc8;
          }
          else {
            bVar5 = panicking::panic_count::is_zero_slow_path();
            bVar5 = bVar5 ^ 1;
            lVar13 = DAT_14069ddc8;
          }
          if (DAT_14069ddb1 != '\0') {
            local_338 = (longlong *)&host_probe[b94139f9089eb1d8]::announce::LEASES;
            plStack_330._1_7_ = (undefined7)((ulonglong)plStack_330 >> 8);
            plStack_330 = (longlong *)CONCAT71(plStack_330._1_7_,bVar5);
            DAT_14069ddc8 = lVar13;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&local_338,
                       &
                       PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1030
                       ,&PTR_s_src_announce_rs_1406a0868);
            goto LAB_14000610b;
          }
          DAT_14069ddc8 = 0;
          if (lVar13 != 0) {
            puVar15 = (undefined8 *)(DAT_14069ddc0 + 0x50);
            do {
              if (puVar15[-10] != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar15[-9],puVar15[-10],1);
                return;
              }
              if (puVar15[-7] != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar15[-6],puVar15[-7],1);
                return;
              }
              if (puVar15[-4] != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar15[-3],puVar15[-4],1);
                return;
              }
              if (puVar15[-1] != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar15,puVar15[-1],1);
                return;
              }
              puVar15 = puVar15 + 0xe;
              lVar13 = lVar13 + -1;
            } while (lVar13 != 0);
          }
          if (((bVar5 == 0) && ((*puVar14 & 0x7fffffffffffffff) != 0)) &&
             (cVar6 = panicking::panic_count::is_zero_slow_path(), cVar6 == '\0')) {
            DAT_14069ddb1 = '\x01';
          }
          cVar6 = host_probe[b94139f9089eb1d8]::announce::LEASES;
          LOCK();
          host_probe[b94139f9089eb1d8]::announce::LEASES = '\0';
          UNLOCK();
          if (cVar6 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake
                      (&host_probe[b94139f9089eb1d8]::announce::LEASES);
          }
          lVar13 = local_370;
          local_370 = 0;
          if (lVar13 != 0) {
            puVar15 = (undefined8 *)(local_378 + 8);
            do {
              if (puVar15[-1] != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar15,puVar15[-1],1);
                return;
              }
              puVar15 = puVar15 + 3;
              lVar13 = lVar13 + -1;
            } while (lVar13 != 0);
          }
          local_338 = (longlong *)0x0;
          plStack_330 = (longlong *)0x8;
          local_328 = (longlong *)0x0;
          host_probe[b94139f9089eb1d8]::net::set_own_leases(&local_338);
          <reach_directory[4b72b9694f6c3c08]::host::Publisher>::take_leases(&local_338,param_1);
          reach_directory[4b72b9694f6c3c08]::host::withdraw_at_once(&local_148,&local_338,3,0);
          plVar21 = local_140;
          plVar17 = local_148;
          plVar1 = local_140 + local_138 * 3;
          local_338 = local_140;
          plStack_330 = local_140;
          local_328 = local_148;
          plVar16 = local_140;
          plVar4 = local_140;
          uStack_320 = plVar1;
          if (local_138 != 0) {
            do {
              plVar18 = plVar4 + 3;
              local_3b8 = plVar4[1];
              uStack_3b0 = (undefined4)plVar4[2];
              uStack_3ac = *(undefined4 *)((longlong)plVar4 + 0x14);
              plVar16 = plVar18;
              if ((longlong *)*plVar4 == (longlong *)0xffffffffffffffff) break;
              local_398 = &local_3d8;
              local_390 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                           ::fmt;
              local_3d8 = (longlong *)*plVar4;
              local_3d0 = (longlong *)plVar4[1];
              plStack_3c8 = (longlong *)plVar4[2];
              alloc[246c2e7857c81348]::fmt::format::format_inner
                        (&local_148,&DAT_1406a0858,&local_398);
              plVar16 = local_140;
              plVar4 = local_148;
              host_probe[b94139f9089eb1d8]::host::log(local_140,local_138);
              if (plVar4 != (longlong *)0x0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar16,plVar4,1);
                return;
              }
              if (local_3d8 != (longlong *)0x0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(local_3d0,local_3d8,1);
                return;
              }
              plVar16 = plVar1;
              plVar4 = plVar18;
            } while (plVar18 != plVar1);
          }
          plStack_330 = plVar16;
          if (plVar1 != plVar16) {
            uVar19 = (ulonglong)((longlong)plVar1 - (longlong)plVar16) / 0x18;
            plVar16 = plVar16 + 1;
            do {
              if (plVar16[-1] != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc(*plVar16,plVar16[-1],1);
                return;
              }
              plVar16 = plVar16 + 3;
              uVar19 = uVar19 - 1;
            } while (uVar19 != 0);
          }
          if (plVar17 != (longlong *)0x0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar21,(longlong)plVar17 * 0x18,8);
            return;
          }
          LOCK();
          host_probe[b94139f9089eb1d8]::announce::BEATING = 0;
          UNLOCK();
          local_168 = CONCAT11(local_168._1_1_,1);
        }
        else {
          LOCK();
          host_probe[b94139f9089eb1d8]::announce::BEATING = 0;
          UNLOCK();
          local_168 = CONCAT11(local_168._1_1_,1);
        }
      }
    }
  }
  host_probe[b94139f9089eb1d8]::announce::withdraw_held(1,500000000);
  goto joined_r0x000140005d2d;
  while( true ) {
    local_368 = &local_3b8;
    puStack_360 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                   ::fmt;
    local_3b8 = *plVar16;
    uStack_3b0 = local_158;
    uStack_3ac = uStack_154;
    uStack_3a8 = uStack_150;
    uStack_3a4 = uStack_14c;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_398,&DAT_1406a0858,&local_368);
    puVar15 = local_390;
    pplVar12 = local_398;
    host_probe[b94139f9089eb1d8]::host::log(local_390,local_388);
    if (pplVar12 != (longlong **)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar15,pplVar12,1);
      return;
    }
    if (local_3b8 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(CONCAT44(uStack_3ac,uStack_3b0),local_3b8,1);
      return;
    }
    plVar17 = plVar4;
    plVar21 = local_340;
    plVar16 = plVar18;
    if (plVar18 == plVar4) break;
LAB_140005dfa:
    plVar18 = plVar16 + 3;
    local_158 = (undefined4)plVar16[1];
    uStack_154 = *(undefined4 *)((longlong)plVar16 + 0xc);
    uStack_150 = (undefined4)plVar16[2];
    uStack_14c = *(undefined4 *)((longlong)plVar16 + 0x14);
    plVar17 = plVar18;
    plVar21 = local_340;
    if (*plVar16 == -1) break;
  }
LAB_140005ebc:
  local_3d0 = plVar17;
  if (plVar4 != plVar17) {
    uVar19 = (ulonglong)((longlong)plVar4 - (longlong)plVar17) / 0x18;
    plVar17 = plVar17 + 1;
    do {
      if (plVar17[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*plVar17,plVar17[-1],1);
        return;
      }
      plVar17 = plVar17 + 3;
      uVar19 = uVar19 - 1;
    } while (uVar19 != 0);
  }
  if (plVar1 != (longlong *)0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar21,(longlong)plVar1 * 0x18,8);
    return;
  }
  host_probe[b94139f9089eb1d8]::announce::withdraw_held(1,500000000);
  core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::protocol::Listing>
            (&local_148);
joined_r0x000140005d2d:
  if (local_370 != 0) {
    puVar15 = (undefined8 *)(local_378 + 8);
    lVar13 = local_370;
    do {
      if (puVar15[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar15,puVar15[-1],1);
        return;
      }
      puVar15 = puVar15 + 3;
      lVar13 = lVar13 + -1;
    } while (lVar13 != 0);
  }
  if (local_380 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_378,local_380 * 0x18,8);
    return;
  }
  if (local_228 != (longlong *)0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(plStack_220,local_228,1);
    return;
  }
  if (CONCAT44(uStack_20c,uStack_210) == 0) {
    if (CONCAT44(uStack_1f4,local_1f8) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (CONCAT44(uStack_1ec,uStack_1f0),CONCAT44(uStack_1f4,local_1f8),1);
      return;
    }
    if (local_1d8 != -1) {
      if (local_1d8 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_1d0,local_1d8,1);
        return;
      }
      if (local_1c0 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_1b8,local_1c0,1);
        return;
      }
      if (local_1a8 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_1a0,local_1a8,1);
        return;
      }
    }
    core[505b25137b8ba7f]::ptr::drop_glue::
    <host_probe[b94139f9089eb1d8]::announce::announce::_closure_26_>(param_1);
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc
            (CONCAT44(uStack_204,local_208),CONCAT44(uStack_20c,uStack_210),1);
  return;
}

