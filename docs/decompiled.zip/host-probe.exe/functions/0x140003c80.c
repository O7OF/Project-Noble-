// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::rendezvous::Message>
// address: 0x140003c80
// body: available
// range: 0x140003c80-0x140003d3e inclusive
// range: 0x140003d40-0x140003d5f inclusive
// range: 0x140003d62-0x140003e0b inclusive
// range: 0x140003e10-0x140003e2f inclusive
// range: 0x140003e32-0x140003e5a inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140003ce5 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003d0f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003d27 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003d5b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003d87 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003d9f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003dc4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003ddc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003df4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003e2b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::rendezvous::Message>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::rendezvous::Message>
          (longlong *param_1)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  
  lVar2 = *param_1;
  switch(lVar2 >> 0x3f & lVar2 + 0x8000000000000001U) {
  case 0:
    if (lVar2 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],lVar2,1);
      return;
    }
    if (param_1[3] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[4],param_1[3],1);
      return;
    }
    lVar1 = param_1[7];
    lVar2 = param_1[8];
    if (lVar2 != 0) {
      puVar4 = (undefined8 *)(lVar1 + 8);
      do {
        if (puVar4[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar4,puVar4[-1],1);
          return;
        }
        puVar4 = puVar4 + 3;
        lVar2 = lVar2 + -1;
      } while (lVar2 != 0);
    }
    lVar2 = param_1[6];
    goto joined_r0x000140003e39;
  default:
    lVar2 = param_1[1];
    if (lVar2 == 0) {
      return;
    }
    lVar1 = param_1[2];
    break;
  case 2:
  case 5:
  case 7:
    if (param_1[1] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[2],param_1[1],1);
      return;
    }
    lVar2 = param_1[4];
    if (lVar2 == 0) {
      return;
    }
    lVar1 = param_1[5];
    break;
  case 3:
    if (param_1[1] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[2],param_1[1],1);
      return;
    }
    if (param_1[4] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[5],param_1[4],1);
      return;
    }
    lVar1 = param_1[8];
    lVar2 = param_1[9];
    if (lVar2 != 0) {
      puVar4 = (undefined8 *)(lVar1 + 8);
      do {
        if (puVar4[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar4,puVar4[-1],1);
          return;
        }
        puVar4 = puVar4 + 3;
        lVar2 = lVar2 + -1;
      } while (lVar2 != 0);
    }
    lVar2 = param_1[7];
joined_r0x000140003e39:
    if (lVar2 == 0) {
      return;
    }
    lVar2 = lVar2 * 0x18;
    uVar3 = 8;
    goto LAB_140003dbb;
  case 8:
    if (param_1[1] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[2],param_1[1],1);
      return;
    }
    if (param_1[4] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[5],param_1[4],1);
      return;
    }
    lVar2 = param_1[7];
    if (lVar2 == 0) {
      return;
    }
    lVar1 = param_1[8];
  }
  uVar3 = 1;
LAB_140003dbb:
  __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar1,lVar2,uVar3);
  return;
}

