// rea decompile_all
// name: <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>::hash_one::<&alloc[246c2e7857c81348]::vec::Vec<u8>>
// address: 0x140009600
// body: available
// range: 0x140009600-0x140009778 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <std[3bf9d48a0c3997f0]::hash::random::RandomState as
   core[505b25137b8ba7f]::hash::BuildHasher>::hash_one::<&alloc[246c2e7857c81348]::vec::Vec<u8>> */

ulonglong __rustcall
<std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>::
hash_one::<&alloc[246c2e7857c81348]::vec::Vec<u8>>(undefined1 (*param_1) [16],longlong param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  undefined8 local_70;
  undefined1 local_68 [16];
  undefined1 local_58 [16];
  undefined1 local_48 [16];
  undefined1 local_38 [16];
  undefined8 local_28;
  
  local_48 = *param_1;
  auVar9._0_8_ = local_48._0_8_;
  auVar9._8_4_ = local_48._0_4_;
  auVar9._12_4_ = local_48._4_4_;
  local_68 = auVar9 ^ (undefined1  [16])s_uespemosarenegyl_1406a0090;
  auVar10._0_8_ = local_48._8_8_;
  auVar10._8_4_ = local_48._8_4_;
  auVar10._12_4_ = local_48._12_4_;
  local_58 = auVar10 ^ (undefined1  [16])s_modnarodsetybdet_1406a00a0;
  local_38 = (undefined1  [16])0x0;
  local_28 = 0;
  uVar1 = *(undefined8 *)(param_2 + 8);
  uVar2 = *(undefined8 *)(param_2 + 0x10);
  local_70 = uVar2;
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_68,&local_70,8);
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_68,uVar1,uVar2);
  uVar8 = local_38._0_8_ << 0x38 | local_38._8_8_;
  uVar4 = local_58._8_8_ ^ uVar8;
  uVar3 = local_68._0_8_ + local_58._0_8_;
  uVar6 = (local_58._0_8_ << 0xd | (ulonglong)local_58._0_8_ >> 0x33) ^ uVar3;
  uVar5 = (uVar4 << 0x10 | uVar4 >> 0x30) ^ local_68._8_8_ + uVar4;
  uVar7 = local_68._8_8_ + uVar4 + uVar6;
  uVar3 = (uVar3 << 0x20 | uVar3 >> 0x20) + uVar5;
  uVar6 = (uVar6 << 0x11 | uVar6 >> 0x2f) ^ uVar7;
  uVar4 = (uVar5 << 0x15 | uVar5 >> 0x2b) ^ uVar3;
  uVar3 = (uVar3 ^ uVar8) + uVar6;
  uVar7 = ((uVar7 << 0x20 | uVar7 >> 0x20) ^ 0xff) + uVar4;
  uVar5 = (uVar6 << 0xd | uVar6 >> 0x33) ^ uVar3;
  uVar4 = (uVar4 << 0x10 | uVar4 >> 0x30) ^ uVar7;
  uVar7 = uVar7 + uVar5;
  uVar3 = (uVar3 << 0x20 | uVar3 >> 0x20) + uVar4;
  uVar5 = (uVar5 << 0x11 | uVar5 >> 0x2f) ^ uVar7;
  uVar4 = (uVar4 << 0x15 | uVar4 >> 0x2b) ^ uVar3;
  uVar3 = uVar3 + uVar5;
  uVar6 = (uVar7 << 0x20 | uVar7 >> 0x20) + uVar4;
  uVar5 = (uVar5 << 0xd | uVar5 >> 0x33) ^ uVar3;
  uVar4 = (uVar4 << 0x10 | uVar4 >> 0x30) ^ uVar6;
  uVar6 = uVar6 + uVar5;
  uVar3 = (uVar3 << 0x20 | uVar3 >> 0x20) + uVar4;
  uVar5 = (uVar5 << 0x11 | uVar5 >> 0x2f) ^ uVar6;
  uVar4 = (uVar4 << 0x15 | uVar4 >> 0x2b) ^ uVar3;
  uVar6 = (uVar6 << 0x20 | uVar6 >> 0x20) + uVar4;
  uVar5 = (uVar5 << 0xd | uVar5 >> 0x33) ^ uVar3 + uVar5;
  uVar3 = (uVar4 << 0x10 | uVar4 >> 0x30) ^ uVar6;
  uVar6 = uVar6 + uVar5;
  return (uVar6 << 0x20 | uVar6 >> 0x20) ^ (uVar5 << 0x11 | uVar5 >> 0x2f) ^
         (uVar3 << 0x15 | uVar3 >> 0x2b) ^ uVar6;
}

