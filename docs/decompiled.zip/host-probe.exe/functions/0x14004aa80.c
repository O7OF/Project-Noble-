// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#9}>>>::from_iter
// address: 0x14004aa80
// body: available
// range: 0x14004aa80-0x14004aac9 inclusive
// range: 0x14004aad0-0x14004ac15 inclusive
// range: 0x14004ac20-0x14004ad95 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#9}>>>::from_iter */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#9}>>>
::from_iter(ulonglong *param_1,undefined8 *param_2)

{
  short sVar1;
  short sVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong lVar5;
  code *pcVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong lVar11;
  ulonglong uVar12;
  undefined8 local_d0;
  short local_c6;
  short local_c4;
  short local_c2;
  ulonglong local_c0;
  longlong *local_b8;
  ulonglong local_b0;
  longlong local_a8;
  ulonglong *local_a0;
  longlong local_98;
  longlong local_90;
  longlong local_88;
  ulonglong *local_80;
  code *local_78;
  short *local_70;
  code *local_68;
  short *local_60;
  code *local_58;
  short *local_50;
  code *local_48;
  
  uVar12 = param_2[1];
  uVar3 = param_2[2];
  local_a0 = param_1;
  if (uVar12 < uVar3) {
    plVar4 = (longlong *)*param_2;
    lVar11 = uVar12 * 8;
    do {
      uVar10 = local_d0;
      lVar5 = *plVar4;
      sVar1 = *(short *)(lVar11 + 2 + lVar5);
      sVar2 = *(short *)(lVar11 + 4 + lVar5);
      local_d0._6_2_ = SUB82(uVar10,6);
      local_d0._0_6_ = CONCAT24(sVar2,CONCAT22(sVar1,*(short *)(lVar11 + lVar5)));
      if ((uVar12 < 0x14) || ((sVar1 != 0 || *(short *)(lVar11 + lVar5) != 0) || sVar2 != 0)) {
        local_80 = &local_c0;
        local_78 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_70 = (short *)&local_d0;
        local_68 = <i16_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_60 = (short *)((longlong)&local_d0 + 2);
        local_58 = <i16_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_50 = (short *)((longlong)&local_d0 + 4);
        local_48 = <i16_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_c0 = uVar12;
        alloc[246c2e7857c81348]::fmt::format::format_inner
                  (&local_98,&anon_553b4e5fea14f94d7b140aed25da7182_27_llvm_1181841624220042269,
                   &local_80);
        lVar8 = local_88;
        lVar7 = local_90;
        lVar5 = local_98;
        if (local_98 != -1) {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          plVar9 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
          if (plVar9 == (longlong *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
            pcVar6 = (code *)invalidInstructionException();
            (*pcVar6)();
          }
          *plVar9 = lVar5;
          plVar9[1] = lVar7;
          plVar9[2] = lVar8;
          local_c0 = 4;
          local_b0 = 1;
          local_b8 = plVar9;
          uVar10 = local_b0;
          goto joined_r0x00014004ac01;
        }
      }
      uVar12 = uVar12 + 1;
      lVar11 = lVar11 + 8;
    } while (uVar3 != uVar12);
  }
  *local_a0 = 0;
  local_a0[1] = 8;
  local_a0[2] = 0;
  return;
joined_r0x00014004ac01:
  uVar12 = uVar12 + 1;
  local_b0 = uVar10;
  if (uVar3 <= uVar12) {
LAB_14004ad52:
    local_a0[2] = local_b0;
    *local_a0 = local_c0;
    local_a0[1] = (ulonglong)local_b8;
    return;
  }
  lVar11 = uVar12 * 8;
  do {
    lVar5 = *plVar4;
    local_c6 = *(short *)(lVar11 + lVar5);
    local_c4 = *(short *)(lVar11 + 2 + lVar5);
    local_c2 = *(short *)(lVar11 + 4 + lVar5);
    if ((uVar12 < 0x14) || ((local_c4 != 0 || local_c6 != 0) || local_c2 != 0)) {
      local_80 = &local_d0;
      local_78 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      local_70 = &local_c6;
      local_68 = <i16_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      local_60 = &local_c4;
      local_58 = <i16_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      local_50 = &local_c2;
      local_48 = <i16_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      local_d0 = uVar12;
      alloc[246c2e7857c81348]::fmt::format::format_inner
                (&local_98,&anon_553b4e5fea14f94d7b140aed25da7182_27_llvm_1181841624220042269,
                 &local_80);
      lVar7 = local_88;
      lVar5 = local_98;
      if (local_98 != -1) break;
    }
    uVar12 = uVar12 + 1;
    lVar11 = lVar11 + 8;
    if (uVar3 == uVar12) goto LAB_14004ad52;
  } while( true );
  local_a8 = local_90;
  if (uVar10 == local_c0) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_c0,uVar10,1,8,0x18);
    plVar9 = local_b8;
  }
  plVar9[uVar10 * 3] = lVar5;
  plVar9[uVar10 * 3 + 1] = local_a8;
  plVar9[uVar10 * 3 + 2] = lVar7;
  uVar10 = uVar10 + 1;
  goto joined_r0x00014004ac01;
}

