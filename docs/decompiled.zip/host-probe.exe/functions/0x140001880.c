// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::retain::<<host_probe[b94139f9089eb1d8]::aiwave::Cohorts>::expire::{closure#0}>
// address: 0x140001880
// body: available
// range: 0x140001880-0x140001b50 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140001b32 to 0x140015460 <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::truncate (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::retain::<<host_probe[b94139f9089eb1d8]::aiwave::Cohorts>::expire::{closure#0}>
    */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>
::retain::<<host_probe[b94139f9089eb1d8]::aiwave::Cohorts>::expire::_closure_0_>
          (ulonglong *param_1,int *param_2,float *param_3)

{
  undefined8 *puVar1;
  float fVar2;
  int iVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  code *pcVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  undefined8 uVar26;
  undefined8 uVar27;
  undefined8 uVar28;
  undefined8 uVar29;
  undefined8 uVar30;
  undefined8 uVar31;
  undefined8 uVar32;
  undefined8 uVar33;
  ulonglong uVar34;
  ulonglong uVar35;
  longlong lVar36;
  ulonglong uVar37;
  ulonglong uVar38;
  ulonglong uVar39;
  undefined8 *puVar40;
  undefined4 local_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  
  uVar4 = param_1[3];
  if (uVar4 == 0) {
    uVar34 = 0;
    uVar35 = 0;
LAB_140001ae6:
    if (uVar35 != uVar34) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>
      ::truncate();
      return;
    }
  }
  else {
    lVar36 = param_1[2] * 0x68 + param_1[1] + 0x60;
    uVar34 = 0;
    do {
      uVar35 = 0;
      if (*param_1 <= param_1[2] + uVar34) {
        uVar35 = *param_1;
      }
      if (30.0 <= (float)((longlong)*param_2 - (longlong)*(int *)(lVar36 + uVar35 * -0x68)) *
                  *param_3) {
        uVar39 = uVar34 + 1;
        uVar35 = uVar39;
        if (uVar39 < uVar4) {
          uVar5 = param_1[2];
          uVar37 = uVar4;
          if (uVar4 < uVar34) {
            uVar37 = uVar34;
          }
          uVar6 = *param_1;
          uVar7 = param_1[1];
          iVar3 = *param_2;
          fVar2 = *param_3;
          do {
            lVar36 = (uVar5 + uVar39) * 0x68 + uVar7;
            uVar35 = uVar39;
            while( true ) {
              uVar38 = uVar6;
              if (uVar5 + uVar35 < uVar6) {
                uVar38 = 0;
              }
              if ((float)((longlong)iVar3 - (longlong)*(int *)(lVar36 + 0x60 + uVar38 * -0x68)) *
                  fVar2 < 30.0) break;
              uVar35 = uVar35 + 1;
              lVar36 = lVar36 + 0x68;
              if (uVar4 <= uVar35) {
                uVar35 = uVar39 + 1;
                if (uVar39 + 1 < uVar4) {
                  uVar35 = uVar4;
                }
                goto LAB_140001ae6;
              }
            }
            if (uVar34 == uVar37) {
              core[505b25137b8ba7f]::panicking::panic
                        (&anon_d5c34e88a06ee720b116585eb143da4b_235_llvm_14435704873730135342,0x20,
                         &anon_d5c34e88a06ee720b116585eb143da4b_236_llvm_14435704873730135342);
                    /* WARNING: Does not return */
              pcVar10 = (code *)invalidInstructionException();
              (*pcVar10)();
            }
            puVar40 = (undefined8 *)(lVar36 + uVar38 * -0x68);
            uVar39 = 0;
            if (uVar6 <= uVar34 + uVar5) {
              uVar39 = uVar6;
            }
            lVar36 = ((uVar34 + uVar5) - uVar39) * 0x68;
            uVar8 = *(undefined8 *)(uVar7 + 0x60 + lVar36);
            puVar1 = (undefined8 *)(uVar7 + 0x50 + lVar36);
            uVar11 = *puVar1;
            uVar12 = puVar1[1];
            puVar1 = (undefined8 *)(uVar7 + 0x40 + lVar36);
            uVar13 = *puVar1;
            uVar14 = puVar1[1];
            uVar15 = *(undefined8 *)(uVar7 + lVar36);
            uVar16 = ((undefined8 *)(uVar7 + lVar36))[1];
            puVar1 = (undefined8 *)(uVar7 + 0x10 + lVar36);
            uVar17 = *puVar1;
            uVar18 = puVar1[1];
            puVar1 = (undefined8 *)(uVar7 + 0x20 + lVar36);
            uVar19 = *puVar1;
            uVar20 = puVar1[1];
            puVar1 = (undefined8 *)(uVar7 + 0x30 + lVar36);
            uVar21 = *puVar1;
            uVar22 = puVar1[1];
            uVar9 = puVar40[0xc];
            uVar23 = puVar40[10];
            uVar24 = puVar40[0xb];
            uVar25 = puVar40[8];
            uVar26 = puVar40[9];
            uVar27 = puVar40[1];
            uVar28 = puVar40[2];
            uVar29 = puVar40[3];
            uVar30 = puVar40[4];
            uVar31 = puVar40[5];
            uVar32 = puVar40[6];
            uVar33 = puVar40[7];
            *(undefined8 *)(uVar7 + lVar36) = *puVar40;
            ((undefined8 *)(uVar7 + lVar36))[1] = uVar27;
            puVar1 = (undefined8 *)(uVar7 + 0x10 + lVar36);
            *puVar1 = uVar28;
            puVar1[1] = uVar29;
            puVar1 = (undefined8 *)(uVar7 + 0x20 + lVar36);
            *puVar1 = uVar30;
            puVar1[1] = uVar31;
            puVar1 = (undefined8 *)(uVar7 + 0x30 + lVar36);
            *puVar1 = uVar32;
            puVar1[1] = uVar33;
            puVar1 = (undefined8 *)(uVar7 + 0x40 + lVar36);
            *puVar1 = uVar25;
            puVar1[1] = uVar26;
            puVar1 = (undefined8 *)(uVar7 + 0x50 + lVar36);
            *puVar1 = uVar23;
            puVar1[1] = uVar24;
            *(undefined8 *)(uVar7 + 0x60 + lVar36) = uVar9;
            puVar40[0xc] = uVar8;
            puVar40[10] = uVar11;
            puVar40[0xb] = uVar12;
            puVar40[8] = uVar13;
            puVar40[9] = uVar14;
            local_d8 = (undefined4)uVar15;
            uStack_d4 = (undefined4)((ulonglong)uVar15 >> 0x20);
            uStack_d0 = (undefined4)uVar16;
            uStack_cc = (undefined4)((ulonglong)uVar16 >> 0x20);
            local_c8 = (undefined4)uVar17;
            uStack_c4 = (undefined4)((ulonglong)uVar17 >> 0x20);
            uStack_c0 = (undefined4)uVar18;
            uStack_bc = (undefined4)((ulonglong)uVar18 >> 0x20);
            puVar40[6] = uVar21;
            puVar40[7] = uVar22;
            puVar40[4] = uVar19;
            puVar40[5] = uVar20;
            *(undefined4 *)(puVar40 + 2) = local_c8;
            *(undefined4 *)((longlong)puVar40 + 0x14) = uStack_c4;
            *(undefined4 *)(puVar40 + 3) = uStack_c0;
            *(undefined4 *)((longlong)puVar40 + 0x1c) = uStack_bc;
            *(undefined4 *)puVar40 = local_d8;
            *(undefined4 *)((longlong)puVar40 + 4) = uStack_d4;
            *(undefined4 *)(puVar40 + 1) = uStack_d0;
            *(undefined4 *)((longlong)puVar40 + 0xc) = uStack_cc;
            uVar39 = uVar35 + 1;
            uVar34 = uVar34 + 1;
          } while (uVar39 < uVar4);
          uVar35 = uVar35 + 1;
        }
        goto LAB_140001ae6;
      }
      uVar34 = uVar34 + 1;
      lVar36 = lVar36 + 0x68;
    } while (uVar4 != uVar34);
  }
  return;
}

