// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u64,core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>)>>::retain::<host_probe[b94139f9089eb1d8]::net::is_blocked::{closure#0}>
// address: 0x140042b20
// body: available
// range: 0x140042b20-0x140042b45 inclusive
// range: 0x140042b50-0x140042bc3 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u64,
   core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>)>>::retain::<host_probe[b94139f9089eb1d8]::net::is_blocked::{closure#0}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u64,core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>)>>
::retain::<host_probe[b94139f9089eb1d8]::net::is_blocked::_closure_0_>
          (longlong param_1,ulonglong *param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  uint uVar3;
  ulonglong uVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined8 uVar8;
  ulonglong uVar9;
  longlong lVar10;
  uint *puVar11;
  bool bVar12;
  
  uVar4 = *(ulonglong *)(param_1 + 0x10);
  if (uVar4 == 0) {
    return;
  }
  lVar5 = *(longlong *)(param_1 + 8);
  uVar6 = *param_2;
  uVar2 = (uint)param_2[1];
  puVar11 = (uint *)(lVar5 + 0x28);
  uVar9 = 0;
  do {
    uVar3 = puVar11[-6];
    if (uVar3 != 0xffffffff) {
      uVar7 = *(ulonglong *)(puVar11 + -8);
      bVar12 = uVar7 < uVar6;
      if (uVar7 == uVar6) {
        bVar12 = uVar3 < uVar2;
      }
      if (bVar12 || uVar7 == uVar6 && uVar3 == uVar2) {
        if (uVar4 <= uVar9 + 1) goto LAB_140042bbc;
        lVar10 = (uVar4 - 1) - uVar9;
        break;
      }
    }
    uVar9 = uVar9 + 1;
    puVar11 = puVar11 + 6;
    if (uVar4 == uVar9) {
      return;
    }
  } while( true );
LAB_140042ba4:
  if (*puVar11 == 0xffffffff) {
LAB_140042b7f:
    *(undefined8 *)(lVar5 + 0x10 + uVar9 * 0x18) = *(undefined8 *)puVar11;
    uVar8 = *(undefined8 *)(puVar11 + -2);
    puVar1 = (undefined8 *)(lVar5 + uVar9 * 0x18);
    *puVar1 = *(undefined8 *)(puVar11 + -4);
    puVar1[1] = uVar8;
    uVar9 = uVar9 + 1;
  }
  else if (*(ulonglong *)(puVar11 + -2) == uVar6) {
    if (uVar2 < *puVar11) goto LAB_140042b7f;
  }
  else if (uVar6 <= *(ulonglong *)(puVar11 + -2)) goto LAB_140042b7f;
  puVar11 = puVar11 + 6;
  lVar10 = lVar10 + -1;
  if (lVar10 == 0) {
LAB_140042bbc:
    *(ulonglong *)(param_1 + 0x10) = uVar9;
    return;
  }
  goto LAB_140042ba4;
}

