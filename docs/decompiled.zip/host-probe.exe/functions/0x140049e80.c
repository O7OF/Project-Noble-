// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<[u8;12usize]>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<[u8;12usize],core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::armorpack::build_merged::{closure#1}>,host_probe[b94139f9089eb1d8]::armorpack::build_merged::{closure#2}>>>::from_iter
// address: 0x140049e80
// body: available
// range: 0x140049e80-0x14004a063 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<[u8; 12usize]> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<[u8; 12usize],
   core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::armorpack::build_merged::{closure#1}>,
   host_probe[b94139f9089eb1d8]::armorpack::build_merged::{closure#2}>>>::from_iter */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<[u8;12usize]>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<[u8;12usize],core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::armorpack::build_merged::{closure#1}>,host_probe[b94139f9089eb1d8]::armorpack::build_merged::{closure#2}>>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  longlong *plVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  code *pcVar7;
  char cVar8;
  longlong lVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  longlong lVar12;
  longlong local_78;
  undefined4 *local_70;
  longlong local_68;
  ulonglong local_60;
  undefined4 local_54;
  undefined4 *local_50;
  longlong *local_48;
  
  uVar11 = param_2[1];
  local_60 = param_2[2];
  local_48 = param_1;
  if (uVar11 < local_60) {
    plVar2 = (longlong *)*param_2;
    uVar3 = param_2[3];
    lVar12 = uVar11 * 0xc;
    lVar9 = -local_60;
    do {
      uVar10 = uVar11 + 1;
      lVar4 = *plVar2;
      uVar1 = *(undefined4 *)(lVar12 + lVar4);
      uVar5 = *(undefined8 *)(lVar12 + 4 + lVar4);
      local_78 = CONCAT44(local_78._4_4_,uVar1);
      cVar8 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<u32,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
              ::contains_key::<u32>(uVar3,&local_78);
      if (cVar8 != '\0') {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        local_70 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x30,1);
        if (local_70 == (undefined4 *)0x0) {
          alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x30);
                    /* WARNING: Does not return */
          pcVar7 = (code *)invalidInstructionException();
          (*pcVar7)();
        }
        *local_70 = uVar1;
        *(undefined8 *)(local_70 + 1) = uVar5;
        local_78 = 4;
        local_68 = 1;
        local_50 = local_70;
        if (uVar10 < local_60) {
          do {
            lVar4 = local_68;
            lVar12 = uVar10 * 0xc;
            uVar11 = uVar10;
            while( true ) {
              uVar10 = uVar11 + 1;
              lVar6 = *plVar2;
              uVar1 = *(undefined4 *)(lVar12 + lVar6);
              uVar5 = *(undefined8 *)(lVar12 + 4 + lVar6);
              local_54 = uVar1;
              cVar8 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<u32,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                      ::contains_key::<u32>(uVar3,&local_54);
              if (cVar8 != '\0') break;
              lVar12 = lVar12 + 0xc;
              lVar6 = uVar11 + 2;
              uVar11 = uVar10;
              if (lVar6 + lVar9 == 1) goto LAB_14004a023;
            }
            if (lVar4 == local_78) {
              <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
              <alloc[246c2e7857c81348]::alloc::Global>(&local_78,lVar4,1,1,0xc);
              local_50 = local_70;
            }
            local_50[lVar4 * 3] = uVar1;
            *(undefined8 *)(local_50 + lVar4 * 3 + 1) = uVar5;
            local_68 = lVar4 + 1;
          } while (uVar10 < local_60);
        }
LAB_14004a023:
        local_48[2] = local_68;
        *local_48 = local_78;
        local_48[1] = (longlong)local_70;
        return;
      }
      lVar12 = lVar12 + 0xc;
      lVar4 = uVar11 + 2;
      uVar11 = uVar10;
    } while (lVar4 + lVar9 != 1);
  }
  *local_48 = 0;
  local_48[1] = 1;
  local_48[2] = 0;
  return;
}

