// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
// address: 0x14003dfc0
// body: available
// range: 0x14003dfc0-0x14003e070 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>
   as core[505b25137b8ba7f]::ops::drop::Drop>::drop */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>as_core[505b25137b8ba7f]::ops::drop::Drop>
::drop(ulonglong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  bool bVar7;
  
  uVar2 = param_1[3];
  if (uVar2 == 0) {
    lVar3 = 0;
    uVar2 = param_1[1];
  }
  else {
    uVar1 = *param_1;
    uVar5 = 0;
    if (uVar1 <= param_1[2]) {
      uVar5 = uVar1;
    }
    uVar5 = param_1[2] - uVar5;
    lVar3 = uVar2 - (uVar1 - uVar5);
    if (uVar2 < uVar1 - uVar5 || lVar3 == 0) {
      uVar1 = uVar2 + uVar5;
      lVar3 = 0;
    }
    uVar2 = param_1[1];
    if (uVar1 != uVar5) {
      lVar4 = uVar5 * 0x20 + uVar2;
      lVar6 = ~uVar5 + uVar1;
      do {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(lVar4);
        lVar4 = lVar4 + 0x20;
        bVar7 = lVar6 != 0;
        lVar6 = lVar6 + -1;
      } while (bVar7);
    }
  }
  if (lVar3 != 0) {
    lVar3 = 1 - lVar3;
    do {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(uVar2);
      uVar2 = uVar2 + 0x20;
      lVar3 = lVar3 + 1;
    } while (lVar3 != 1);
  }
  return;
}

