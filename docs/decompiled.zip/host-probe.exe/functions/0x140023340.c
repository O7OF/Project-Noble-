// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::route_peer
// address: 0x140023340
// body: available
// range: 0x140023340-0x1400234a2 inclusive
// range: 0x1400234b0-0x1400236e7 inclusive
// range: 0x1400236f0-0x140023748 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::route_peer */

undefined8 __rustcall
host_probe[b94139f9089eb1d8]::net::route_peer(undefined8 *param_1,ushort *param_2,byte *param_3)

{
  ushort *puVar1;
  byte bVar2;
  ushort uVar3;
  longlong lVar4;
  longlong lVar5;
  uint uVar6;
  uint uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  longlong lVar10;
  undefined1 (*pauVar11) [16];
  undefined1 (*pauVar12) [16];
  ushort uVar13;
  uint uVar14;
  ulonglong uVar15;
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined4 local_68;
  undefined2 uStack_64;
  char cStack_62;
  char cStack_61;
  char cStack_60;
  char cStack_5f;
  char cStack_5e;
  char cStack_5d;
  char cStack_5c;
  char cStack_5b;
  char cStack_5a;
  char cStack_59;
  char local_58;
  char cStack_57;
  
  pauVar11 = (undefined1 (*) [16])*param_1;
  lVar10 = param_1[3];
  auVar16 = *pauVar11;
  pauVar12 = pauVar11 + 1;
  uVar14 = ~(uint)(ushort)((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                           (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                           (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                           (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                           (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                           (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                           (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                           (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                           (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                           (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                           (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                           (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                           (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                           (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                           (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                          (ushort)(byte)(auVar16[0xf] >> 7) << 0xf);
  puVar1 = param_2 + 1;
  uVar3 = *param_2;
  bVar2 = *param_3;
  lVar4 = *(longlong *)(param_3 + 1);
  lVar5 = *(longlong *)(param_3 + 9);
  if ((uVar3 & 1) == 0) {
    if ((bVar2 & 1) == 0) {
      if (lVar10 != 0) {
        while( true ) {
          uVar13 = (ushort)uVar14;
          while (uVar13 == 0) {
            auVar16 = *pauVar12;
            pauVar11 = pauVar11 + -0x50;
            pauVar12 = pauVar12 + 1;
            uVar13 = ((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                      (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                      (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                      (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                      (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                      (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                      (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                      (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                      (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                      (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                      (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                      (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                      (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                      (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                      (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                     (ushort)(byte)(auVar16[0xf] >> 7) << 0xf) ^ 0xffff;
            uVar14 = (uint)uVar13;
          }
          uVar6 = 0;
          for (uVar7 = uVar14; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
            uVar6 = uVar6 + 1;
          }
          uVar15 = (ulonglong)uVar6;
          uVar14 = uVar14 - 1 & uVar14;
          lVar10 = lVar10 + -1;
          if ((((*(ushort *)(pauVar11[uVar15 * -5 + -4] + 8) == uVar3) &&
               (uStack_64 = (short)((ulonglong)*(undefined8 *)puVar1 >> 0x20),
               *(short *)(pauVar11[uVar15 * -5 + -4] + 0xe) == uStack_64)) &&
              (local_68 = (int)*(undefined8 *)puVar1,
              *(int *)(pauVar11[uVar15 * -5 + -4] + 10) == local_68)) &&
             (pauVar11[uVar15 * -5 + -2][8] != '\x01')) break;
          if (lVar10 == 0) {
            return 0;
          }
        }
        goto joined_r0x00014002360d;
      }
    }
    else if (lVar10 != 0) {
      while( true ) {
        uVar13 = (ushort)uVar14;
        while (uVar13 == 0) {
          auVar16 = *pauVar12;
          pauVar11 = pauVar11 + -0x50;
          pauVar12 = pauVar12 + 1;
          uVar13 = ((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                   (ushort)(byte)(auVar16[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar14 = (uint)uVar13;
        }
        uVar6 = 0;
        for (uVar7 = uVar14; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
          uVar6 = uVar6 + 1;
        }
        uVar15 = (ulonglong)uVar6;
        uVar14 = uVar14 - 1 & uVar14;
        lVar10 = lVar10 + -1;
        if (((*(ushort *)(pauVar11[uVar15 * -5 + -4] + 8) == uVar3) &&
            (uStack_64 = (short)((ulonglong)*(undefined8 *)puVar1 >> 0x20),
            *(short *)(pauVar11[uVar15 * -5 + -4] + 0xe) == uStack_64)) &&
           ((local_68 = (int)*(undefined8 *)puVar1,
            *(int *)(pauVar11[uVar15 * -5 + -4] + 10) == local_68 &&
            ((pauVar11[uVar15 * -5 + -2][8] == '\x01' &&
             (*(longlong *)(pauVar11[uVar15 * -5 + -1] + 1) == lVar5 &&
              *(longlong *)(pauVar11[uVar15 * -5 + -2] + 9) == lVar4)))))) break;
        if (lVar10 == 0) {
          return 0;
        }
      }
joined_r0x00014002360d:
      do {
        if (lVar10 == 0) {
          return 1;
        }
        uVar13 = (ushort)uVar14;
        while (uVar13 == 0) {
          auVar16 = *pauVar12;
          pauVar11 = pauVar11 + -0x50;
          pauVar12 = pauVar12 + 1;
          uVar13 = ((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                   (ushort)(byte)(auVar16[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar14 = (uint)uVar13;
        }
        uVar6 = 0;
        for (uVar7 = uVar14; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
          uVar6 = uVar6 + 1;
        }
        uVar15 = (ulonglong)uVar6;
        uVar8 = *(undefined8 *)puVar1;
        uVar9 = *(undefined8 *)(param_2 + 5);
        if (*(ushort *)(pauVar11[uVar15 * -5 + -4] + 8) == uVar3) {
          if ((uVar3 & 1) == 0) {
            uStack_64 = (short)((ulonglong)uVar8 >> 0x20);
            if ((*(short *)(pauVar11[uVar15 * -5 + -4] + 0xe) == uStack_64) &&
               (local_68 = (int)uVar8, *(int *)(pauVar11[uVar15 * -5 + -4] + 10) == local_68)) {
LAB_140023711:
              if (pauVar11[uVar15 * -5 + -2][8] == '\x01') {
                if (((bVar2 & 1) != 0) &&
                   (*(longlong *)(pauVar11[uVar15 * -5 + -1] + 1) == lVar5 &&
                    *(longlong *)(pauVar11[uVar15 * -5 + -2] + 9) == lVar4)) {
                  return 0;
                }
              }
              else if ((bVar2 & 1) == 0) {
                return 0;
              }
            }
          }
          else if ((*(ushort *)(pauVar11[uVar15 * -5 + -2] + 4) == param_2[0xe]) &&
                  ((*(int *)(pauVar11[uVar15 * -5 + -3] + 0xc) == *(int *)(param_2 + 10) &&
                   (*(int *)pauVar11[uVar15 * -5 + -2] == *(int *)(param_2 + 0xc))))) {
            local_68._2_1_ = (char)((ulonglong)uVar8 >> 0x10);
            local_68._3_1_ = (char)((ulonglong)uVar8 >> 0x18);
            uStack_64._0_1_ = (char)((ulonglong)uVar8 >> 0x20);
            uStack_64._1_1_ = (char)((ulonglong)uVar8 >> 0x28);
            cStack_62 = (char)((ulonglong)uVar8 >> 0x30);
            cStack_61 = (char)((ulonglong)uVar8 >> 0x38);
            cStack_60 = (char)uVar9;
            cStack_5f = (char)((ulonglong)uVar9 >> 8);
            cStack_5e = (char)((ulonglong)uVar9 >> 0x10);
            cStack_5d = (char)((ulonglong)uVar9 >> 0x18);
            cStack_5c = (char)((ulonglong)uVar9 >> 0x20);
            cStack_5b = (char)((ulonglong)uVar9 >> 0x28);
            cStack_5a = (char)((ulonglong)uVar9 >> 0x30);
            cStack_59 = (char)((ulonglong)uVar9 >> 0x38);
            local_58 = (char)param_2[9];
            cStack_57 = (char)(param_2[9] >> 8);
            auVar17[0] = -(local_68._2_1_ == pauVar11[uVar15 * -5 + -4][0xc]);
            auVar17[1] = -(local_68._3_1_ == pauVar11[uVar15 * -5 + -4][0xd]);
            auVar17[2] = -((char)uStack_64 == pauVar11[uVar15 * -5 + -4][0xe]);
            auVar17[3] = -(uStack_64._1_1_ == pauVar11[uVar15 * -5 + -4][0xf]);
            auVar17[4] = -(cStack_62 == pauVar11[uVar15 * -5 + -3][0]);
            auVar17[5] = -(cStack_61 == pauVar11[uVar15 * -5 + -3][1]);
            auVar17[6] = -(cStack_60 == pauVar11[uVar15 * -5 + -3][2]);
            auVar17[7] = -(cStack_5f == pauVar11[uVar15 * -5 + -3][3]);
            auVar17[8] = -(cStack_5e == pauVar11[uVar15 * -5 + -3][4]);
            auVar17[9] = -(cStack_5d == pauVar11[uVar15 * -5 + -3][5]);
            auVar17[10] = -(cStack_5c == pauVar11[uVar15 * -5 + -3][6]);
            auVar17[0xb] = -(cStack_5b == pauVar11[uVar15 * -5 + -3][7]);
            auVar17[0xc] = -(cStack_5a == pauVar11[uVar15 * -5 + -3][8]);
            auVar17[0xd] = -(cStack_59 == pauVar11[uVar15 * -5 + -3][9]);
            auVar17[0xe] = -(local_58 == pauVar11[uVar15 * -5 + -3][10]);
            auVar17[0xf] = -(cStack_57 == pauVar11[uVar15 * -5 + -3][0xb]);
            if ((ushort)((ushort)(SUB161(auVar17 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar17 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar17 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar17 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar17 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar17 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar17 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar17 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar17 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar17 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar17 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar17 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar17 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar17 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar17 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar17[0xf] >> 7) << 0xf) == 0xffff) goto LAB_140023711;
          }
        }
        uVar14 = uVar14 - 1 & uVar14;
        lVar10 = lVar10 + -1;
      } while( true );
    }
  }
  else if (lVar10 != 0) {
    do {
      uVar13 = (ushort)uVar14;
      while (uVar13 == 0) {
        auVar16 = *pauVar12;
        pauVar11 = pauVar11 + -0x50;
        pauVar12 = pauVar12 + 1;
        uVar13 = ((ushort)(SUB161(auVar16 >> 7,0) & 1) | (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1
                  | (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                  (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                  (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                  (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                  (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                  (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                  (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                  (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                  (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                  (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                  (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                  (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                  (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                 (ushort)(byte)(auVar16[0xf] >> 7) << 0xf) ^ 0xffff;
        uVar14 = (uint)uVar13;
      }
      uVar6 = 0;
      for (uVar7 = uVar14; (uVar7 & 1) == 0; uVar7 = uVar7 >> 1 | 0x80000000) {
        uVar6 = uVar6 + 1;
      }
      uVar15 = (ulonglong)uVar6;
      uVar14 = uVar14 - 1 & uVar14;
      lVar10 = lVar10 + -1;
      uVar8 = *(undefined8 *)puVar1;
      uVar9 = *(undefined8 *)(param_2 + 5);
      if ((((*(ushort *)(pauVar11[uVar15 * -5 + -4] + 8) == uVar3) &&
           (*(ushort *)(pauVar11[uVar15 * -5 + -2] + 4) == param_2[0xe])) &&
          (*(int *)(pauVar11[uVar15 * -5 + -3] + 0xc) == *(int *)(param_2 + 10))) &&
         (*(int *)pauVar11[uVar15 * -5 + -2] == *(int *)(param_2 + 0xc))) {
        local_68._2_1_ = (char)((ulonglong)uVar8 >> 0x10);
        local_68._3_1_ = (char)((ulonglong)uVar8 >> 0x18);
        uStack_64._0_1_ = (char)((ulonglong)uVar8 >> 0x20);
        uStack_64._1_1_ = (char)((ulonglong)uVar8 >> 0x28);
        cStack_62 = (char)((ulonglong)uVar8 >> 0x30);
        cStack_61 = (char)((ulonglong)uVar8 >> 0x38);
        cStack_60 = (char)uVar9;
        cStack_5f = (char)((ulonglong)uVar9 >> 8);
        cStack_5e = (char)((ulonglong)uVar9 >> 0x10);
        cStack_5d = (char)((ulonglong)uVar9 >> 0x18);
        cStack_5c = (char)((ulonglong)uVar9 >> 0x20);
        cStack_5b = (char)((ulonglong)uVar9 >> 0x28);
        cStack_5a = (char)((ulonglong)uVar9 >> 0x30);
        cStack_59 = (char)((ulonglong)uVar9 >> 0x38);
        local_58 = (char)param_2[9];
        cStack_57 = (char)(param_2[9] >> 8);
        auVar16[0] = -(local_68._2_1_ == pauVar11[uVar15 * -5 + -4][0xc]);
        auVar16[1] = -(local_68._3_1_ == pauVar11[uVar15 * -5 + -4][0xd]);
        auVar16[2] = -((char)uStack_64 == pauVar11[uVar15 * -5 + -4][0xe]);
        auVar16[3] = -(uStack_64._1_1_ == pauVar11[uVar15 * -5 + -4][0xf]);
        auVar16[4] = -(cStack_62 == pauVar11[uVar15 * -5 + -3][0]);
        auVar16[5] = -(cStack_61 == pauVar11[uVar15 * -5 + -3][1]);
        auVar16[6] = -(cStack_60 == pauVar11[uVar15 * -5 + -3][2]);
        auVar16[7] = -(cStack_5f == pauVar11[uVar15 * -5 + -3][3]);
        auVar16[8] = -(cStack_5e == pauVar11[uVar15 * -5 + -3][4]);
        auVar16[9] = -(cStack_5d == pauVar11[uVar15 * -5 + -3][5]);
        auVar16[10] = -(cStack_5c == pauVar11[uVar15 * -5 + -3][6]);
        auVar16[0xb] = -(cStack_5b == pauVar11[uVar15 * -5 + -3][7]);
        auVar16[0xc] = -(cStack_5a == pauVar11[uVar15 * -5 + -3][8]);
        auVar16[0xd] = -(cStack_59 == pauVar11[uVar15 * -5 + -3][9]);
        auVar16[0xe] = -(local_58 == pauVar11[uVar15 * -5 + -3][10]);
        auVar16[0xf] = -(cStack_57 == pauVar11[uVar15 * -5 + -3][0xb]);
        if ((ushort)((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                    (ushort)(auVar16[0xf] >> 7) << 0xf) == 0xffff) {
          if (pauVar11[uVar15 * -5 + -2][8] == '\0') {
            if ((bVar2 & 1) == 0) goto joined_r0x00014002360d;
          }
          else if (((bVar2 & 1) != 0) &&
                  (*(longlong *)(pauVar11[uVar15 * -5 + -1] + 1) == lVar5 &&
                   *(longlong *)(pauVar11[uVar15 * -5 + -2] + 9) == lVar4))
          goto joined_r0x00014002360d;
        }
      }
      if (lVar10 == 0) {
        return 0;
      }
    } while( true );
  }
  return 0;
}

