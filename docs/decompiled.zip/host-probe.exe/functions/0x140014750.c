// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>::wrap_copy
// address: 0x140014750
// body: available
// range: 0x140014750-0x14001497f inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14001497b to 0x1406968d8 memmove (external=false, thunk=true, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>::wrap_copy
    */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
::wrap_copy(ulonglong param_1,void *param_2,longlong param_3,longlong param_4,ulonglong param_5)

{
  ulonglong uVar1;
  ulonglong uVar2;
  size_t sVar3;
  void *pvVar4;
  void *_Dst;
  void *pvVar5;
  ulonglong uVar6;
  size_t _Size;
  longlong lVar7;
  
  uVar6 = param_4 - param_3;
  if ((uVar6 != 0) && (param_5 != 0)) {
    uVar1 = uVar6 + param_1;
    if (!CARRY8(uVar6,param_1)) {
      uVar1 = uVar6;
    }
    uVar6 = param_1 - param_3;
    uVar2 = param_1 - param_4;
    lVar7 = param_5 - uVar6;
    pvVar5 = param_2;
    if (param_5 < uVar6 || lVar7 == 0) {
      pvVar4 = (void *)(param_3 * 0x80 + (longlong)param_2);
      lVar7 = param_5 - uVar2;
      if (param_5 < uVar2 || lVar7 == 0) {
        pvVar5 = (void *)(param_4 * 0x80 + (longlong)param_2);
        sVar3 = param_5 << 7;
      }
      else if (uVar1 < param_5) {
        sVar3 = uVar2 * 0x80;
        memmove(param_2,(void *)((longlong)pvVar4 + sVar3),lVar7 * 0x80);
        pvVar5 = (void *)(param_4 * 0x80 + (longlong)param_2);
      }
      else {
        memmove((void *)(param_4 * 0x80 + (longlong)param_2),pvVar4,uVar2 * 0x80);
        pvVar4 = (void *)(uVar2 * 0x80 + (longlong)pvVar4);
        sVar3 = lVar7 * 0x80;
      }
    }
    else if (uVar1 < param_5) {
      if (uVar2 < param_5) {
        sVar3 = (uVar6 - uVar2) * 0x80;
        memmove((void *)((longlong)param_2 + sVar3),param_2,lVar7 * 0x80);
        memmove(param_2,(void *)((param_1 - (uVar6 - uVar2)) * 0x80 + (longlong)param_2),sVar3);
        sVar3 = uVar2 * 0x80;
        pvVar5 = (void *)(param_4 * 0x80 + (longlong)param_2);
        pvVar4 = (void *)(param_3 * 0x80 + (longlong)param_2);
      }
      else {
        pvVar5 = (void *)(param_4 * 0x80 + (longlong)param_2);
        sVar3 = uVar6 * 0x80;
        memmove((void *)((longlong)pvVar5 + sVar3),param_2,lVar7 * 0x80);
        pvVar4 = (void *)(param_3 * 0x80 + (longlong)param_2);
      }
    }
    else {
      pvVar4 = (void *)(param_3 * 0x80 + (longlong)param_2);
      _Dst = (void *)(param_4 * 0x80 + (longlong)param_2);
      _Size = uVar6 * 0x80;
      if (param_5 < uVar2 || param_5 - uVar2 == 0) {
        memmove(_Dst,pvVar4,_Size);
        sVar3 = lVar7 * 0x80;
        pvVar5 = (void *)((longlong)_Dst + _Size);
        pvVar4 = param_2;
      }
      else {
        memmove(_Dst,pvVar4,_Size);
        sVar3 = (uVar2 - uVar6) * 0x80;
        memmove((void *)((longlong)_Dst + _Size),param_2,sVar3);
        pvVar4 = (void *)(sVar3 + (longlong)param_2);
        sVar3 = (param_5 - uVar2) * 0x80;
      }
    }
    memmove(pvVar5,pvVar4,sVar3);
    return;
  }
  return;
}

