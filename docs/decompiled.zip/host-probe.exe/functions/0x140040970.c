// rea decompile_all
// name: <serde_json[7404bcab4dc139c7]::value::Value_as_core[505b25137b8ba7f]::clone::Clone>::clone
// address: 0x140040970
// body: available
// range: 0x140040970-0x140040a08 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Instruction at (ram,0x000140040df0) overlaps instruction at (ram,0x000140040def)
    */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* <serde_json[7404bcab4dc139c7]::value::Value as core[505b25137b8ba7f]::clone::Clone>::clone */

void __rustcall
<serde_json[7404bcab4dc139c7]::value::Value_as_core[505b25137b8ba7f]::clone::Clone>::clone
          (undefined8 param_1,undefined8 param_2,undefined8 param_3,byte param_4,undefined8 param_5,
          undefined8 param_6,undefined8 param_7,undefined8 param_8,undefined *param_9,
          undefined8 param_10,undefined8 param_11,undefined8 param_12,undefined8 param_13,
          undefined8 param_14,undefined8 param_15,undefined8 param_16,undefined8 param_17,
          undefined8 param_18,undefined8 param_19,undefined8 param_20)

{
  undefined8 uVar1;
  byte bVar2;
  undefined1 uVar3;
  undefined1 uVar4;
  uint uVar5;
  code *pcVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  uint *in_RCX;
  uint *puVar9;
  byte *in_RDX;
  uint uVar10;
  undefined8 unaff_RBX;
  undefined8 unaff_RSI;
  byte unaff_DIL;
  ulonglong uVar12;
  uint uVar13;
  uint uVar14;
  uint in_XMM0_Dc;
  uint in_XMM0_Dd;
  uint uVar15;
  uint uVar16;
  uint in_XMM1_Dc;
  uint in_XMM1_Dd;
  uint uVar17;
  uint uVar18;
  uint in_XMM2_Dc;
  uint in_XMM2_Dd;
  undefined *unaff_retaddr;
  undefined8 uStackX_8;
  char acStackX_10 [8];
  undefined1 auStackX_18 [16];
  char acStack_18 [8];
  ulonglong uVar11;
  
  bVar2 = *in_RDX;
  uVar11 = (ulonglong)bVar2;
  uVar10 = (uint)bVar2;
  puVar9 = &switchD_14004098d::switchdataD_1406a03b0;
  uVar5 = (&switchD_14004098d::switchdataD_1406a03b0)[uVar11];
  uVar13 = (uint)param_1;
  uVar14 = (uint)((ulonglong)param_1 >> 0x20);
  uVar15 = (uint)param_2;
  uVar16 = (uint)((ulonglong)param_2 >> 0x20);
  uVar17 = (uint)param_3;
  uVar18 = (uint)((ulonglong)param_3 >> 0x20);
                    /* WARNING (jumptable): Sanity check requires truncation of jumptable */
                    /* WARNING: Could not find normalized switch variable to match jumptable */
  switch(bVar2) {
  case 1:
    *(byte *)((longlong)in_RCX + 1) = in_RDX[1];
    break;
  case 2:
    uVar1 = *(undefined8 *)(in_RDX + 0x10);
    *(undefined8 *)(in_RCX + 2) = *(undefined8 *)(in_RDX + 8);
    *(undefined8 *)(in_RCX + 4) = uVar1;
    break;
  case 3:
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (in_RCX + 2,in_RDX + 8);
    break;
  case 4:
    <alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>as_core[505b25137b8ba7f]::clone::Clone>
    ::clone(in_RCX + 2,in_RDX + 8);
    break;
  case 5:
    if (*(longlong *)(in_RDX + 0x18) == 0) {
      in_RCX[2] = 0;
      in_RCX[3] = 0;
      in_RCX[6] = 0;
      in_RCX[7] = 0;
    }
    else {
      if (*(longlong *)(in_RDX + 8) == 0) {
        core[505b25137b8ba7f]::option::unwrap_failed
                  (&anon_78f5a4a341bdef2ce7ac238d2c24ea85_1322_llvm_9926003741679196139);
                    /* WARNING: Does not return */
        pcVar6 = (code *)invalidInstructionException();
        (*pcVar6)();
      }
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<_,_,_>as_core[505b25137b8ba7f]::clone::Clone>
      ::clone::clone_subtree::
      <alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value,alloc[246c2e7857c81348]::alloc::Global>
                (in_RCX + 2,*(longlong *)(in_RDX + 8),*(undefined8 *)(in_RDX + 0x10));
    }
    break;
  case 6:
    uVar12 = (ulonglong)in_RDX & 0xffffffff;
    in_RCX = &switchD_14004098d::switchdataD_1406a03b0;
                    /* WARNING (jumptable): Sanity check requires truncation of jumptable */
                    /* WARNING: Could not find normalized switch variable to match jumptable */
    switch(*in_RDX) {
    case 0:
      in_RDX = (byte *)(uVar12 + 8);
      uVar10 = *(uint *)(uVar12 + 4);
      unaff_DIL = *(byte *)(uVar12 + 1);
      goto switchD_14004098d_caseD_a;
    case 1:
      uVar7 = *(undefined8 *)(uVar12 + 0x10);
      uVar8 = *(undefined8 *)(uVar12 + 0x18);
      uVar1 = *(undefined8 *)(uVar12 + 4);
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (acStack_18,uVar12 + 0x20);
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (&stack0x00000000,uVar12 + 0x38);
      uVar3 = *(undefined1 *)(uVar12 + 1);
      uVar4 = *(undefined1 *)(uVar12 + 2);
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (&param_9,uVar12 + 0x50);
                    /* WARNING: Read-only address (ram,0x0001406a03c0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03c8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b4) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b8) is written */
      UINT_1406a03b4 = (uint)uVar1;
      UINT_1406a03b8 = (uint)((ulonglong)uVar1 >> 0x20);
      switchD_14004098d::switchdataD_1406a03b0._0_1_ = 1;
      switchD_14004098d::switchdataD_1406a03b0._1_1_ = uVar3;
      switchD_14004098d::switchdataD_1406a03b0._2_1_ = uVar4;
      _UINT_1406a03c0 = uVar7;
      _switchdataD_1406a03c8 = uVar8;
      UINT_1406a03d0._0_1_ = acStack_18[0];
      UINT_1406a03d0._1_1_ = acStack_18[1];
      UINT_1406a03d0._2_1_ = acStack_18[2];
      UINT_1406a03d0._3_1_ = acStack_18[3];
      UINT_1406a03d4._0_1_ = acStack_18[4];
      UINT_1406a03d4._1_1_ = acStack_18[5];
      UINT_1406a03d4._2_1_ = acStack_18[6];
      UINT_1406a03d4._3_1_ = acStack_18[7];
      _UINT_1406a03d8 = unaff_RBX;
      s_no_entry_found_for_key_1406a03dc._4_8_ = unaff_RSI;
      s_no_entry_found_for_key_1406a03dc._12_8_ = unaff_retaddr;
      ram0x0001406a03f0 = uStackX_8;
      anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342._6_8_ = acStackX_10;
      PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0400 = param_9;
      _UNK_1406a0408 = param_10;
      _UNK_1406a0410 = param_11;
      return;
                    /* WARNING: Read-only address (ram,0x0001406a03d0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03d8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03e0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03e8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03f0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03f8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b1) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b2) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0400) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0408) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0410) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b0) is written */
    case 2:
                    /* WARNING: Read-only address (ram,0x0001406a03b8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03bc) is written */
      UINT_1406a03b8 = (uint)*(undefined8 *)(uVar12 + 8);
      UINT_1406a03bc = (uint)((ulonglong)*(undefined8 *)(uVar12 + 8) >> 0x20);
      switchD_14004098d::switchdataD_1406a03b0._0_1_ = 2;
      switchD_14004098d::switchdataD_1406a03b0._1_1_ = 6;
      switchD_14004098d::switchdataD_1406a03b0._2_1_ = 0x9a;
      UINT_1406a03b4 = 0xff9a05df;
      _UINT_1406a03c0 = 0xff9a0610ff9a05e8;
      _switchdataD_1406a03c8 = 0xff9a0a3fff9a08db;
      _UINT_1406a03d0 = 0xff9a0a21ff9a0a11;
      _UINT_1406a03d8 = 0x65206f6eff9a08fe;
      s_no_entry_found_for_key_1406a03dc[4] = 'n';
      s_no_entry_found_for_key_1406a03dc[5] = 't';
      s_no_entry_found_for_key_1406a03dc[6] = 'r';
      s_no_entry_found_for_key_1406a03dc[7] = 'y';
      s_no_entry_found_for_key_1406a03dc[8] = ' ';
      s_no_entry_found_for_key_1406a03dc[9] = 'f';
      s_no_entry_found_for_key_1406a03dc[10] = 'o';
      s_no_entry_found_for_key_1406a03dc[0xb] = 'u';
      s_no_entry_found_for_key_1406a03dc[0xc] = 'n';
      s_no_entry_found_for_key_1406a03dc[0xd] = 'd';
      s_no_entry_found_for_key_1406a03dc[0xe] = ' ';
      s_no_entry_found_for_key_1406a03dc[0xf] = 'f';
      s_no_entry_found_for_key_1406a03dc[0x10] = 'o';
      s_no_entry_found_for_key_1406a03dc[0x11] = 'r';
      s_no_entry_found_for_key_1406a03dc[0x12] = ' ';
      s_no_entry_found_for_key_1406a03dc[0x13] = 'k';
      ram0x0001406a03f0 = 0x656e5c6372737965;
      builtin_strncpy("t.rs","t.rs",5);
      anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342[0xb] = '\0';
      anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342[0xc] = '\0';
      anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342[0xd] = '\0';
      PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0400 =
           anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342;
      _UNK_1406a0408 = 10;
      _UNK_1406a0410 = 0x2700000137;
      return;
                    /* WARNING: Read-only address (ram,0x0001406a03b0) is written */
    case 3:
      uVar10 = *(uint *)(uVar12 + 4);
      in_RDX = (byte *)(uVar12 + 8);
      puVar9 = &UINT_1406a03b8;
      goto code_r0x000140040df7;
    case 4:
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (auStackX_18,uVar12 + 8);
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (&param_6,uVar12 + 0x20);
      uVar11 = *(ulonglong *)(uVar12 + 0x68);
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (acStack_18,uVar12 + 0x38);
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (&stack0x00000000,uVar12 + 0x50);
                    /* WARNING: Read-only address (ram,0x0001406a0408) is written */
      _UNK_1406a0408 = uStackX_8;
                    /* WARNING: Read-only address (ram,0x0001406a0410) is written */
      _UNK_1406a0410 = acStackX_10;
                    /* WARNING: Read-only address (ram,0x0001406a03f8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0400) is written */
      param_9._0_4_ = (uint)auStackX_18._0_8_;
      param_9._4_4_ = SUB84(auStackX_18._0_8_,4);
      param_10._0_4_ = (uint)auStackX_18._8_8_;
      param_10._4_4_ = SUB84(auStackX_18._8_8_,4);
      param_11._0_4_ = (uint)param_5;
      param_11._4_4_ = (uint)((ulonglong)param_5 >> 0x20);
      param_12._0_4_ = (uint)param_6;
      param_12._4_4_ = (uint)((ulonglong)param_6 >> 0x20);
      param_13._0_4_ = (uint)param_7;
      param_13._4_4_ = (uint)((ulonglong)param_7 >> 0x20);
      param_14._0_4_ = (uint)param_8;
      param_14._4_4_ = (uint)((ulonglong)param_8 >> 0x20);
                    /* WARNING: Read-only address (ram,0x0001406a03e8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03f0) is written */
      s_no_entry_found_for_key_1406a03dc[0xc] = acStack_18[0];
      s_no_entry_found_for_key_1406a03dc[0xd] = acStack_18[1];
      s_no_entry_found_for_key_1406a03dc[0xe] = acStack_18[2];
      s_no_entry_found_for_key_1406a03dc[0xf] = acStack_18[3];
      s_no_entry_found_for_key_1406a03dc[0x10] = acStack_18[4];
      s_no_entry_found_for_key_1406a03dc[0x11] = acStack_18[5];
      s_no_entry_found_for_key_1406a03dc[0x12] = acStack_18[6];
      s_no_entry_found_for_key_1406a03dc[0x13] = acStack_18[7];
      uVar13 = (uint)param_9;
      uVar14 = param_9._4_4_;
      in_XMM0_Dc = (uint)param_10;
      in_XMM0_Dd = param_10._4_4_;
      uVar15 = (uint)param_11;
      uVar16 = param_11._4_4_;
      in_XMM1_Dc = (uint)param_12;
      in_XMM1_Dd = param_12._4_4_;
      uVar17 = (uint)param_13;
      uVar18 = param_13._4_4_;
      in_XMM2_Dc = (uint)param_14;
      in_XMM2_Dd = param_14._4_4_;
      unique0x1000073e = unaff_RBX;
      anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342._6_8_ = unaff_RSI;
      PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0400 =
           unaff_retaddr;
    }
  case 8:
    in_RCX[10] = uVar17;
    in_RCX[0xb] = uVar18;
    in_RCX[0xc] = in_XMM2_Dc;
    in_RCX[0xd] = in_XMM2_Dd;
    in_RCX[6] = uVar15;
    in_RCX[7] = uVar16;
    in_RCX[8] = in_XMM1_Dc;
    in_RCX[9] = in_XMM1_Dd;
    in_RCX[2] = uVar13;
    in_RCX[3] = uVar14;
    in_RCX[4] = in_XMM0_Dc;
    in_RCX[5] = in_XMM0_Dd;
    *(ulonglong *)(in_RCX + 0x1a) = uVar11;
  case 9:
    *(byte *)in_RCX = 4;
                    /* WARNING: Read-only address (ram,0x0001406a03b0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b1) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b2) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b4) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03b8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03bc) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03c0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03c8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03d0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03d8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03e0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03e8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03f0) is written */
                    /* WARNING: Read-only address (ram,0x0001406a03f8) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0400) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0408) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0410) is written */
    return;
  case 7:
    (&UNK_1406a033d)[(int)uVar5] = (&UNK_1406a033d)[(int)uVar5] | 0xb0;
    (&UNK_1406a0339)[(int)uVar5] = (&UNK_1406a0339)[(int)uVar5] | param_4;
code_r0x000140040df7:
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (puVar9,in_RDX);
    in_RCX[1] = uVar10;
    *(byte *)in_RCX = 3;
    return;
  case 10:
switchD_14004098d_caseD_a:
    <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
              (in_RCX + 2,in_RDX);
    in_RCX[1] = uVar10;
    *(byte *)((longlong)in_RCX + 1) = unaff_DIL;
    *(byte *)in_RCX = 0;
    return;
  }
  *(byte *)in_RCX = bVar2;
  return;
}

