// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::truncate
// address: 0x140015460
// body: available
// range: 0x140015460-0x1400154db inclusive
// range: 0x1400154e0-0x140015503 inclusive
// range: 0x140015506-0x140015515 inclusive
// range: 0x140015520-0x140015543 inclusive
// range: 0x140015546-0x140015595 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400154ff to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001553f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140015591 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::truncate
    */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>
::truncate(ulonglong *param_1,ulonglong param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  ulonglong uVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  
  uVar1 = param_1[3];
  if (param_2 < uVar1) {
    uVar2 = param_1[2];
    uVar3 = *param_1;
    uVar4 = param_1[1];
    uVar7 = uVar3;
    if (uVar2 < uVar3) {
      uVar7 = 0;
    }
    lVar8 = uVar2 - uVar7;
    uVar9 = uVar3 - lVar8;
    uVar5 = uVar1 - uVar9;
    if (uVar1 < uVar9) {
      uVar5 = 0;
    }
    uVar10 = lVar8 + uVar1;
    if (uVar1 >= uVar9 && uVar1 - uVar9 != 0) {
      uVar10 = uVar3;
    }
    uVar10 = uVar10 - lVar8;
    param_1[3] = param_2;
    if (param_2 < uVar10 || param_2 - uVar10 == 0) {
      lVar8 = uVar10 - param_2;
      if (lVar8 != 0) {
        puVar6 = (undefined8 *)(param_2 * 0x68 + uVar2 * 0x68 + uVar7 * -0x68 + uVar4 + 8);
        do {
          if (puVar6[-1] != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar6,puVar6[-1] * 0x6c,1);
            return;
          }
          puVar6 = puVar6 + 0xd;
          lVar8 = lVar8 + -1;
        } while (lVar8 != 0);
      }
      if (uVar9 < uVar1) {
        puVar6 = (undefined8 *)(uVar4 + 8);
        do {
          if (puVar6[-1] != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar6,puVar6[-1] * 0x6c,1);
            return;
          }
          puVar6 = puVar6 + 0xd;
          uVar5 = uVar5 - 1;
        } while (uVar5 != 0);
      }
    }
    else {
      lVar8 = uVar5 - (param_2 - uVar10);
      if (lVar8 != 0) {
        puVar6 = (undefined8 *)(uVar4 + param_2 * 0x68 + uVar10 * -0x68 + 8);
        do {
          if (puVar6[-1] != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar6,puVar6[-1] * 0x6c,1);
            return;
          }
          puVar6 = puVar6 + 0xd;
          lVar8 = lVar8 + -1;
        } while (lVar8 != 0);
      }
    }
  }
  return;
}

