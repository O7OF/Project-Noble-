// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::greet_heard
// address: 0x140023d10
// body: available
// range: 0x140023d10-0x140023e65 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::greet_heard */

void __rustcall
host_probe[b94139f9089eb1d8]::net::greet_heard
          (undefined1 *param_1,undefined8 param_2,undefined8 param_3)

{
  code *pcVar1;
  ulonglong uVar2;
  undefined *puVar3;
  byte bVar4;
  char cVar5;
  bool bVar6;
  undefined1 *local_30;
  undefined8 local_28;
  
  LOCK();
  bVar6 = GREETING == '\0';
  if (bVar6) {
    GREETING = '\x01';
  }
  UNLOCK();
  if (!bVar6) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&GREETING);
  }
  puVar3 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar4 = 0;
  }
  else {
    bVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path
                      (param_1,param_2,param_3);
    bVar4 = bVar4 ^ 1;
  }
  if (DAT_1407f00e9 != '\0') {
    local_30 = &GREETING;
    uVar2 = (ulonglong)local_28 >> 8;
    local_28 = CONCAT71((int7)uVar2,bVar4);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_30,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0f10
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1f50);
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  if (DAT_1407f00f0 != 0) {
    local_30 = param_1;
    local_28 = param_2;
    <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,u32,std[3bf9d48a0c3997f0]::time::Instant),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
    ::retain::<<host_probe[b94139f9089eb1d8]::net::Greeting>::heard::_closure_0_>
              (&DAT_1407f00f0,&local_30,param_3);
  }
  if (((bVar4 == 0) && ((*(ulonglong *)puVar3 & 0x7fffffffffffffff) != 0)) &&
     (cVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar5 == '\0')) {
    DAT_1407f00e9 = '\x01';
  }
  cVar5 = GREETING;
  LOCK();
  GREETING = 0;
  UNLOCK();
  if (cVar5 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&GREETING);
  }
  return;
}

