// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find_map::check<&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line,serde_json[7404bcab4dc139c7]::value::Value,&mut<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line)>>::call_mut
// address: 0x14003e6a0
// body: available
// range: 0x14003e6a0-0x14003eedb inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003e847 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003e991 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut 
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find_map::check<&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line,
   serde_json[7404bcab4dc139c7]::value::Value, &mut
   <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>::{closure#0}
   as core[505b25137b8ba7f]::ops::function::FnMut<((),
   &host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line)>>::call_mut */

undefined1 * __rustcall
<&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find_map::check<&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line,serde_json[7404bcab4dc139c7]::value::Value,&mut<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line)>>
::call_mut(undefined1 *param_1,undefined8 *param_2,char *param_3)

{
  size_t sVar1;
  code *pcVar2;
  longlong lVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  void *pvVar7;
  void *pvVar8;
  undefined1 *puVar9;
  longlong lVar10;
  char *_Size;
  ulonglong uVar11;
  undefined8 uVar12;
  char local_e0;
  undefined1 uStack_df;
  undefined2 uStack_de;
  undefined4 uStack_dc;
  int iStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  int iStack_c8;
  int iStack_c4;
  undefined8 local_c0;
  undefined4 *local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  int local_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  void *local_70;
  longlong local_68;
  char *local_60 [4];
  
  if (*param_3 != '\x01') {
    *param_1 = 0xff;
    return param_1;
  }
  local_68 = **(longlong **)*param_2;
  lVar10 = (*(longlong **)*param_2)[1];
  local_60[0] = param_3 + 0x18;
  local_88 = 0;
  local_78 = 0;
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  uVar12 = 2;
  puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(2,1);
  if (puVar6 != (undefined4 *)0x0) {
    *(undefined2 *)puVar6 = 0x6469;
    local_c0 = 2;
    local_b0 = 2;
    _Size = &local_e0;
    local_b8 = puVar6;
    pvVar7 = (void *)::<u64>::_fmt(*(undefined8 *)(param_3 + 0x10),_Size,0x14);
    if ((longlong)_Size < 0) {
      uVar12 = 0;
LAB_14003e75c:
      alloc[246c2e7857c81348]::raw_vec::handle_error(uVar12,_Size);
      goto LAB_14003eeda;
    }
    if (_Size == (char *)0x0) {
      pvVar8 = (void *)0x1;
      pvVar7 = (void *)0x1;
    }
    else {
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar12 = 1;
      pvVar8 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size,1);
      if (pvVar8 == (void *)0x0) goto LAB_14003e75c;
      memcpy(pvVar8,pvVar7,(size_t)_Size);
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      pvVar7 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size,1);
      if (pvVar7 == (void *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(1,_Size);
        goto LAB_14003eeda;
      }
      memcpy(pvVar7,pvVar8,(size_t)_Size);
    }
    local_e0 = '\x03';
    iStack_d8 = (int)_Size;
    uStack_d4 = (int)((ulonglong)_Size >> 0x20);
    uStack_d0._0_4_ = (int)pvVar7;
    uStack_d0._4_4_ = (int)((ulonglong)pvVar7 >> 0x20);
    iStack_c8 = iStack_d8;
    iStack_c4 = uStack_d4;
    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
    ::insert(&local_a8,&local_88,&local_c0,&local_e0);
    if ((char)local_a8 != -1) {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(&local_a8)
      ;
    }
    if (_Size != (char *)0x0) {
      puVar9 = (undefined1 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar8,_Size,1);
      return puVar9;
    }
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar12 = 6;
    puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(6,1);
    if (puVar6 != (undefined4 *)0x0) {
      *(undefined2 *)(puVar6 + 1) = 0x7265;
      *puVar6 = 0x646e6573;
      local_c0 = 6;
      local_b0 = 6;
      local_a8 = local_60;
      uStack_a0 = <&u64_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_b8 = puVar6;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_e0,&DAT_1406a067e,&local_a8);
      iVar5 = uStack_d0._4_4_;
      iVar4 = (int)uStack_d0;
      lVar3 = CONCAT44(uStack_dc,CONCAT22(uStack_de,CONCAT11(uStack_df,local_e0)));
      local_70 = (void *)CONCAT44(uStack_d4,iStack_d8);
      sVar1 = CONCAT44(uStack_d0._4_4_,(int)uStack_d0);
      if (uStack_d0._4_4_ < 0) {
        uVar12 = 0;
LAB_14003e8e2:
        alloc[246c2e7857c81348]::raw_vec::handle_error(uVar12,sVar1);
        goto LAB_14003eeda;
      }
      if (sVar1 == 0) {
        pvVar7 = (void *)0x1;
      }
      else {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar12 = 1;
        pvVar7 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
        if (pvVar7 == (void *)0x0) goto LAB_14003e8e2;
        memcpy(pvVar7,local_70,sVar1);
      }
      local_e0 = '\x03';
      iStack_d8 = iVar4;
      uStack_d4 = iVar5;
      uStack_d0._0_4_ = (int)pvVar7;
      uStack_d0._4_4_ = (int)((ulonglong)pvVar7 >> 0x20);
      iStack_c8 = iVar4;
      iStack_c4 = iVar5;
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
      ::insert(&local_a8,&local_88,&local_c0,&local_e0);
      if ((char)local_a8 != -1) {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                  (&local_a8);
      }
      if (lVar3 != 0) {
        puVar9 = (undefined1 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(local_70,lVar3,1);
        return puVar9;
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar12 = 4;
      puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
      if (puVar6 != (undefined4 *)0x0) {
        *puVar6 = 0x65646f63;
        local_c0 = 4;
        local_b0 = 4;
        local_e0 = '\x03';
        iStack_d8 = 0;
        uStack_d4 = 0;
        uStack_d0._0_4_ = 1;
        uStack_d0._4_4_ = 0;
        iStack_c8 = 0;
        iStack_c4 = 0;
        local_b8 = puVar6;
        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
        ::insert(&local_a8,&local_88,&local_c0,&local_e0);
        if ((char)local_a8 != -1) {
          core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                    (&local_a8);
        }
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar12 = 4;
        puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
        if (puVar6 != (undefined4 *)0x0) {
          *puVar6 = 0x656d616e;
          local_c0 = 4;
          local_b0 = 4;
          sVar1 = *(size_t *)(param_3 + 0x30);
          local_b8 = puVar6;
          if ((longlong)sVar1 < 0) {
            uVar12 = 0;
LAB_14003ea71:
            alloc[246c2e7857c81348]::raw_vec::handle_error(uVar12,sVar1);
            goto LAB_14003eeda;
          }
          if (sVar1 == 0) {
            pvVar7 = (void *)0x1;
          }
          else {
            pvVar8 = *(void **)(param_3 + 0x28);
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            uVar12 = 1;
            pvVar7 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
            if (pvVar7 == (void *)0x0) goto LAB_14003ea71;
            memcpy(pvVar7,pvVar8,sVar1);
          }
          local_e0 = '\x03';
          iStack_d8 = (int)sVar1;
          uStack_d4 = (int)(sVar1 >> 0x20);
          uStack_d0._0_4_ = (int)pvVar7;
          uStack_d0._4_4_ = (int)((ulonglong)pvVar7 >> 0x20);
          iStack_c8 = iStack_d8;
          iStack_c4 = uStack_d4;
          <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
          ::insert(&local_a8,&local_88,&local_c0,&local_e0);
          if ((char)local_a8 != -1) {
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (&local_a8);
          }
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar12 = 4;
          puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
          if (puVar6 != (undefined4 *)0x0) {
            *puVar6 = 0x6d616574;
            local_c0 = 4;
            local_b0 = 4;
            local_e0 = '\x02';
            uStack_d0._4_4_ = 0;
            iStack_d8 = 0;
            uStack_d4 = 0;
            uStack_d0._0_4_ = (int)param_3[1];
            local_b8 = puVar6;
            <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
            ::insert(&local_a8,&local_88,&local_c0,&local_e0);
            if ((char)local_a8 != -1) {
              core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                        (&local_a8);
            }
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            uVar12 = 7;
            puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(7,1);
            if (puVar6 != (undefined4 *)0x0) {
              *(undefined4 *)((longlong)puVar6 + 3) = 0x6c656e6e;
              *puVar6 = 0x6e616863;
              local_c0 = 7;
              local_b0 = 7;
              local_b8 = puVar6;
              <reach_directory[4b72b9694f6c3c08]::chat::Channel_as_serde_core[7f01a81d286c67f3]::ser::Serialize>
              ::serialize::<serde_json[7404bcab4dc139c7]::value::ser::Serializer>
                        (&local_e0,param_3 + 2);
              if (local_e0 == -1) {
                local_a8 = (char **)CONCAT44(uStack_d4,iStack_d8);
                core[505b25137b8ba7f]::result::unwrap_failed
                          ("called `Result::unwrap()` on an `Err` value",0x2b,&local_a8,
                           &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                           &PTR_s_src_ingame_chat_transport_rs_1406a0660);
                goto LAB_14003eeda;
              }
              local_98 = (int)uStack_d0;
              iStack_94 = uStack_d0._4_4_;
              iStack_90 = iStack_c8;
              iStack_8c = iStack_c4;
              local_a8 = (char **)CONCAT44(uStack_dc,
                                           CONCAT22(uStack_de,CONCAT11(uStack_df,local_e0)));
              uStack_a0 = (code *)CONCAT44(uStack_d4,iStack_d8);
              <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
              ::insert(&local_e0,&local_88,&local_c0,&local_a8);
              if (local_e0 != -1) {
                core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                          (&local_e0);
              }
              __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
              uVar12 = 4;
              puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
              if (puVar6 != (undefined4 *)0x0) {
                *puVar6 = 0x74786574;
                local_c0 = 4;
                local_b0 = 4;
                sVar1 = *(size_t *)(param_3 + 0x60);
                local_b8 = puVar6;
                if ((longlong)sVar1 < 0) {
                  uVar12 = 0;
LAB_14003ec7d:
                  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar12,sVar1);
                  goto LAB_14003eeda;
                }
                if (sVar1 == 0) {
                  pvVar7 = (void *)0x1;
                }
                else {
                  pvVar8 = *(void **)(param_3 + 0x58);
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  uVar12 = 1;
                  pvVar7 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
                  if (pvVar7 == (void *)0x0) goto LAB_14003ec7d;
                  memcpy(pvVar7,pvVar8,sVar1);
                }
                local_e0 = '\x03';
                iStack_d8 = (int)sVar1;
                uStack_d4 = (int)(sVar1 >> 0x20);
                uStack_d0._0_4_ = (int)pvVar7;
                uStack_d0._4_4_ = (int)((ulonglong)pvVar7 >> 0x20);
                iStack_c8 = iStack_d8;
                iStack_c4 = uStack_d4;
                <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                ::insert(&local_a8,&local_88,&local_c0,&local_e0);
                if ((char)local_a8 != -1) {
                  core[505b25137b8ba7f]::ptr::drop_glue::
                  <serde_json[7404bcab4dc139c7]::value::Value>(&local_a8);
                }
                __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                uVar12 = 4;
                puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
                if (puVar6 != (undefined4 *)0x0) {
                  *puVar6 = 0x656e696d;
                  local_c0 = 4;
                  local_b0 = 4;
                  uStack_df = *(longlong *)(param_3 + 0x18) == *(longlong *)(local_68 + 0x3b8);
                  local_e0 = '\x01';
                  local_b8 = puVar6;
                  <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                  ::insert(&local_a8,&local_88,&local_c0,&local_e0);
                  if ((char)local_a8 != -1) {
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <serde_json[7404bcab4dc139c7]::value::Value>(&local_a8);
                  }
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  uVar12 = 6;
                  puVar6 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(6,1);
                  if (puVar6 != (undefined4 *)0x0) {
                    *(undefined2 *)(puVar6 + 1) = 0x736d;
                    *puVar6 = 0x5f656761;
                    local_c0 = 6;
                    local_b0 = 6;
                    uVar11 = *(ulonglong *)(param_3 + 0x70);
                    local_b8 = puVar6;
                    lVar10 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                                       (lVar10,uVar11,*(undefined4 *)(param_3 + 0x78));
                    uStack_d0 = (uVar11 & 0xffffffff) / 1000000 + lVar10 * 1000;
                    local_e0 = '\x02';
                    iStack_d8 = 0;
                    uStack_d4 = 0;
                    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                    ::insert(&local_a8,&local_88,&local_c0,&local_e0);
                    if ((char)local_a8 != -1) {
                      core[505b25137b8ba7f]::ptr::drop_glue::
                      <serde_json[7404bcab4dc139c7]::value::Value>(&local_a8);
                    }
                    uStack_dc._3_1_ = (undefined1)local_88;
                    iStack_d8 = (int)((ulonglong)local_88 >> 8);
                    uStack_d4._0_3_ = (undefined3)((ulonglong)local_88 >> 0x28);
                    uStack_d4._3_1_ = (undefined1)uStack_80;
                    *param_1 = 5;
                    *(ulonglong *)(param_1 + 1) =
                         CONCAT44(uStack_dc,CONCAT22(uStack_de,CONCAT11(uStack_df,local_e0)));
                    *(ulonglong *)(param_1 + 9) = CONCAT44(uStack_d4,iStack_d8);
                    *(undefined8 *)(param_1 + 0x10) = uStack_80;
                    *(undefined8 *)(param_1 + 0x18) = local_78;
                    return param_1;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar12);
LAB_14003eeda:
                    /* WARNING: Does not return */
  pcVar2 = (code *)invalidInstructionException();
  (*pcVar2)();
}

