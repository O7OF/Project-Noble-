// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::m64::enabled
// address: 0x1400205d0
// body: available
// range: 0x1400205d0-0x14002062b inclusive
// range: 0x140020630-0x14002064c inclusive
// range: 0x14002064f-0x140020656 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140020627 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140020648 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::m64::enabled */

undefined4 __rustcall host_probe[b94139f9089eb1d8]::m64::enabled(undefined4 param_1)

{
  undefined4 uVar1;
  longlong local_38;
  longlong local_30;
  undefined8 local_28;
  undefined8 local_20;
  
  std[3bf9d48a0c3997f0]::env::var::inner
            (&local_38,&anon_d5c34e88a06ee720b116585eb143da4b_351_llvm_14435704873730135342,0xd);
  if (local_38 == -2) {
    uVar1 = <char_as_core[505b25137b8ba7f]::str::pattern::Pattern>::is_contained_in
                      (param_1,local_28,local_20);
    if (local_30 != 0) {
      uVar1 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_28,local_30,1);
      return uVar1;
    }
  }
  else {
    uVar1 = 1;
    if ((local_38 != -1) && (local_38 != 0)) {
      uVar1 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_30,local_38,1);
      return uVar1;
    }
  }
  return uVar1;
}

