// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::scoreboard::ActionTarget>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::scoreboard::ActionTarget,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::scoreboard::game_players::{closure#0}>>>::from_iter
// address: 0x14004ecc0
// body: available
// range: 0x14004ecc0-0x14004eec1 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::scoreboard::ActionTarget> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::scoreboard::ActionTarget,
   core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::scoreboard::game_players::{closure#0}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::scoreboard::ActionTarget>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::scoreboard::ActionTarget,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::scoreboard::game_players::{closure#0}>>>
::from_iter(longlong *param_1,undefined4 *param_2)

{
  longlong *plVar1;
  code *pcVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 *puVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  undefined4 *local_b0;
  longlong *local_a8;
  undefined4 *local_a0;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  ulonglong local_88;
  undefined4 *local_80;
  longlong local_78;
  longlong local_70;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  
  uVar7 = *(ulonglong *)(param_2 + 4);
  if (*(ulonglong *)(param_2 + 2) < uVar7) {
    uVar8 = *(ulonglong *)(param_2 + 2);
    local_b0 = param_2;
    do {
      uVar9 = uVar8 + 1;
      *(ulonglong *)(param_2 + 2) = uVar9;
      <&mut_host_probe[b94139f9089eb1d8]::scoreboard::game_players::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<(usize,)>>
      ::call_mut(&local_78,&local_b0,uVar8);
      lVar4 = local_70;
      lVar3 = local_78;
      if (local_78 != -1) {
        local_98 = local_68;
        uStack_94 = uStack_64;
        uStack_90 = CONCAT44(uStack_5c,uStack_60);
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        plVar5 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x80,8);
        if (plVar5 == (longlong *)0x0) {
          alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x80);
                    /* WARNING: Does not return */
          pcVar2 = (code *)invalidInstructionException();
          (*pcVar2)();
        }
        *plVar5 = lVar3;
        plVar5[1] = lVar4;
        plVar5[2] = CONCAT44(uStack_94,local_98);
        plVar5[3] = uStack_90;
        local_b0 = (undefined4 *)0x4;
        local_a0 = (undefined4 *)0x1;
        local_88 = *(ulonglong *)(param_2 + 4);
        local_98 = *param_2;
        uStack_94 = param_2[1];
        local_80 = &local_98;
        local_a8 = plVar5;
        if (local_88 <= *(ulonglong *)(param_2 + 2)) goto LAB_14004ee80;
        puVar6 = (undefined4 *)0x1;
        uVar7 = local_88;
        uStack_90 = *(ulonglong *)(param_2 + 2);
        goto LAB_14004edd0;
      }
      uVar8 = uVar9;
    } while (uVar7 != uVar9);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
LAB_14004edd0:
  uVar9 = uStack_90 + 1;
  uVar8 = uStack_90;
  uStack_90 = uVar9;
  <&mut_host_probe[b94139f9089eb1d8]::scoreboard::game_players::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<(usize,)>>
  ::call_mut(&local_78,&local_80,uVar8);
  lVar4 = local_70;
  lVar3 = local_78;
  if (local_78 == -1) {
    uStack_90 = uVar9;
    if (uVar7 == uVar9) goto LAB_14004ee80;
    goto LAB_14004edd0;
  }
  local_58 = local_68;
  uStack_54 = uStack_64;
  uStack_50 = uStack_60;
  uStack_4c = uStack_5c;
  if (puVar6 == local_b0) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_b0,puVar6,1,8,0x20);
    plVar5 = local_a8;
  }
  plVar5[(longlong)puVar6 * 4] = lVar3;
  plVar5[(longlong)puVar6 * 4 + 1] = lVar4;
  plVar1 = plVar5 + (longlong)puVar6 * 4 + 2;
  *(undefined4 *)plVar1 = local_58;
  *(undefined4 *)((longlong)plVar1 + 4) = uStack_54;
  *(undefined4 *)(plVar1 + 1) = uStack_50;
  *(undefined4 *)((longlong)plVar1 + 0xc) = uStack_4c;
  puVar6 = (undefined4 *)((longlong)puVar6 + 1);
  local_80 = &local_98;
  uVar7 = local_88;
  local_a0 = puVar6;
  if (local_88 <= uStack_90) {
LAB_14004ee80:
    param_1[2] = (longlong)local_a0;
    *param_1 = (longlong)local_b0;
    param_1[1] = (longlong)local_a8;
    return param_1;
  }
  goto LAB_14004edd0;
}

