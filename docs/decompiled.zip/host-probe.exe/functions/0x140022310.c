// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::flush_held
// address: 0x140022310
// body: available
// range: 0x140022310-0x14002255e inclusive
// range: 0x140022560-0x140022699 inclusive
// range: 0x14002269f-0x1400227be inclusive
// range: 0x1400227c0-0x1400227df inclusive
// range: 0x1400227e2-0x1400228fc inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140022695 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400227db to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400227f4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::flush_held */

void __rustcall host_probe[b94139f9089eb1d8]::net::flush_held(undefined8 param_1,uint param_2)

{
  short sVar1;
  uint uVar2;
  undefined *puVar3;
  undefined **ppuVar4;
  undefined *puVar5;
  code *pcVar6;
  char cVar7;
  byte bVar8;
  char cVar9;
  undefined **ppuVar10;
  undefined **ppuVar11;
  undefined **ppuVar12;
  ulonglong uVar13;
  longlong lVar14;
  undefined **ppuVar15;
  ulonglong uVar16;
  undefined **ppuVar17;
  ulonglong uVar18;
  longlong lVar19;
  ulonglong uVar20;
  ulonglong uVar21;
  undefined **ppuVar22;
  ulonglong *puVar23;
  undefined **ppuVar24;
  bool bVar25;
  bool bVar26;
  undefined8 local_e1;
  undefined8 local_d8;
  undefined **ppuStack_d0;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  longlong lStack_b8;
  ulonglong local_b0;
  undefined **local_a8;
  undefined **ppuStack_a0;
  undefined **local_98;
  undefined **ppuStack_90;
  ulonglong local_88;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined **local_68;
  undefined **local_60;
  
  LOCK();
  bVar26 = IMPAIR == '\0';
  if (bVar26) {
    IMPAIR = '\x01';
  }
  UNLOCK();
  if (!bVar26) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&IMPAIR);
  }
  puVar23 = (ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
  ;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar8 = 0;
  }
  else {
    bVar8 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar8 = bVar8 ^ 1;
  }
  if (DAT_140699651 != '\0') {
    local_d8 = (undefined **)&IMPAIR;
    uVar20 = (ulonglong)ppuStack_d0 >> 8;
    ppuStack_d0 = (undefined **)CONCAT71((int7)uVar20,bVar8);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_d8,
               &anon_d5c34e88a06ee720b116585eb143da4b_138_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1e48);
                    /* WARNING: Does not return */
    pcVar6 = (code *)invalidInstructionException();
    (*pcVar6)();
  }
  if (DAT_140699658 == -1) goto LAB_1400227f9;
  local_78 = (undefined *)<std[3bf9d48a0c3997f0]::time::Instant>::now();
  ppuStack_a0 = (undefined **)DAT_140699688;
  uStack_70 = (undefined *)CONCAT44(uStack_70._4_4_,param_2);
  ppuVar10 = (undefined **)&DAT_00000008;
  if (DAT_140699688 != 0) {
    uVar20 = DAT_140699670;
    if (DAT_140699680 < DAT_140699670) {
      uVar20 = 0;
    }
    uVar13 = DAT_140699680 - uVar20;
    uVar21 = DAT_140699670 - uVar13;
    uVar18 = (DAT_140699688 - uVar21) * 0x58;
    if (DAT_140699688 <= uVar21) {
      uVar18 = 0;
    }
    uVar16 = uVar13 + DAT_140699688;
    if (uVar21 < DAT_140699688) {
      uVar16 = DAT_140699670;
    }
    if (uVar13 != uVar16) {
      lVar19 = DAT_140699680 * 0x58 + uVar20 * -0x58 + DAT_140699678;
      if (DAT_140699688 < uVar21) {
        uVar21 = DAT_140699688;
      }
      lVar14 = 0;
      do {
        puVar3 = *(undefined **)(lVar19 + 0x18 + lVar14);
        bVar25 = puVar3 < local_78;
        bVar26 = false;
        if (puVar3 == local_78) {
          uVar2 = *(uint *)(lVar19 + 0x20 + lVar14);
          bVar25 = uVar2 < param_2;
          bVar26 = uVar2 == param_2;
        }
        if (bVar25 || bVar26) goto LAB_140022467;
        lVar14 = lVar14 + 0x58;
      } while (uVar21 * 0x58 - lVar14 != 0);
    }
    if (uVar18 != 0) {
      local_98 = (undefined **)0x0;
      uVar20 = 0;
      do {
        puVar3 = *(undefined **)(DAT_140699678 + 0x18 + uVar20);
        bVar25 = puVar3 < local_78;
        bVar26 = false;
        if (puVar3 == local_78) {
          uVar2 = *(uint *)(DAT_140699678 + 0x20 + uVar20);
          bVar25 = uVar2 < param_2;
          bVar26 = uVar2 == param_2;
        }
        if (bVar25 || bVar26) goto LAB_140022467;
        uVar20 = uVar20 + 0x58;
      } while (uVar18 != uVar20);
      local_a8 = (undefined **)0x0;
      goto LAB_140022519;
    }
  }
  local_98 = (undefined **)0x0;
  local_a8 = (undefined **)0x0;
LAB_140022519:
  ppuVar24 = ppuVar10 + (longlong)local_98 * 0xb;
  bVar26 = local_98 != (undefined **)0x0;
  ppuVar15 = local_a8;
  ppuVar17 = ppuVar10;
  ppuVar22 = ppuVar10;
  ppuVar4 = ppuVar10;
  ppuStack_a0 = ppuVar10;
  local_98 = local_a8;
  ppuStack_90 = ppuVar24;
  if (bVar26) {
    do {
      local_60 = ppuVar22;
      local_68 = ppuVar15;
      local_a8 = ppuVar4;
      ppuVar17 = ppuVar10 + 0xb;
      puVar3 = *ppuVar10;
      ppuVar15 = local_68;
      ppuVar22 = local_60;
      puVar23 = (ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
      ppuVar4 = local_a8;
      if (puVar3 == (undefined *)0xffffffffffffffff) break;
      ppuVar4 = (undefined **)ppuVar10[1];
      puVar5 = ppuVar10[2];
      cVar9 = *(char *)(ppuVar10 + 10);
      sVar1 = *(short *)(ppuVar10 + 5);
      local_e1._5_2_ = *(undefined2 *)((longlong)ppuVar10 + 0x2e);
      local_e1._1_4_ = *(undefined4 *)((longlong)ppuVar10 + 0x2a);
      ppuVar11 = (undefined **)ppuVar10[6];
      local_78 = ppuVar10[7];
      uStack_70 = ppuVar10[8];
      local_d8 = (undefined **)ppuVar10[5];
      ppuStack_d0 = (undefined **)ppuVar10[6];
      local_c8 = *(undefined4 *)(ppuVar10 + 7);
      uStack_c4 = *(undefined4 *)((longlong)ppuVar10 + 0x3c);
      uStack_c0 = *(undefined4 *)(ppuVar10 + 8);
      uStack_bc = *(undefined4 *)((longlong)ppuVar10 + 0x44);
      cVar7 = is_blocked(ppuVar10[9],&local_d8);
      ppuVar15 = local_68;
      ppuVar22 = local_60;
      puVar23 = (ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
      if (cVar7 == '\0') {
        ppuVar10 = &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
        if ((sVar1 != 2) && (ppuVar10 = ppuVar11, sVar1 != -1)) {
          local_d8 = (undefined **)CONCAT26(local_e1._5_2_,CONCAT42(local_e1._1_4_,sVar1));
          local_c8 = (undefined4)local_78;
          uStack_c4 = local_78._4_4_;
          uStack_c0 = (undefined4)uStack_70;
          uStack_bc = uStack_70._4_4_;
          ppuVar10 = ppuVar4;
          ppuStack_d0 = ppuVar11;
          uVar20 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                             (&DAT_140699980,ppuVar4,puVar5,&local_d8);
          if ((uVar20 & 1) == 0) {
            ppuVar15 = local_68;
            ppuVar22 = local_60;
            if (cVar9 == '\0') {
              LOCK();
              netstats::C = netstats::C + (longlong)ppuVar10;
              UNLOCK();
              LOCK();
              DAT_1407f1048 = DAT_1407f1048 + 1;
              UNLOCK();
              ppuVar11 = DAT_1407f1088;
              do {
                ppuVar12 = ppuVar10;
                if (ppuVar10 < ppuVar11) {
                  ppuVar12 = ppuVar11;
                }
                LOCK();
                bVar26 = ppuVar11 != DAT_1407f1088;
                if (bVar26) {
                  ppuVar11 = DAT_1407f1088;
                  ppuVar12 = DAT_1407f1088;
                }
                DAT_1407f1088 = ppuVar12;
                UNLOCK();
              } while (bVar26);
              if (ppuVar10 < (undefined **)0x80) {
                lVar19 = 0;
              }
              else {
                lVar19 = 1;
                if (((undefined **)0xff < ppuVar10) && (lVar19 = 2, (undefined **)0x1ff < ppuVar10))
                {
                  lVar19 = 4 - (ulonglong)(ppuVar10 < (undefined **)0x400);
                }
              }
              LOCK();
              (&DAT_1407f1090)[lVar19] = (&DAT_1407f1090)[lVar19] + 1;
              UNLOCK();
              puVar23 = (ulonglong *)
                        __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
            }
            else {
              puVar23 = (ulonglong *)
                        __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
              if (cVar9 == '\x01') {
                LOCK();
                DAT_1407f1050 = DAT_1407f1050 + (longlong)ppuVar10;
                UNLOCK();
                LOCK();
                DAT_1407f1058 = DAT_1407f1058 + 1;
                UNLOCK();
              }
              else {
                LOCK();
                DAT_1407f10d0 = DAT_1407f10d0 + (longlong)ppuVar10;
                UNLOCK();
                LOCK();
                DAT_1407f10d8 = DAT_1407f10d8 + 1;
                UNLOCK();
              }
            }
            goto joined_r0x000140022765;
          }
        }
        LOCK();
        DAT_1407f1080 = DAT_1407f1080 + 1;
        UNLOCK();
        ppuVar15 = local_68;
        ppuVar22 = local_60;
        puVar23 = (ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
        if ((1 < ((uint)ppuVar10 & 3) - 2) && (((ulonglong)ppuVar10 & 3) != 0)) {
          ppuStack_d0 = (undefined **)((longlong)ppuVar10 + -1);
          local_d8 = (undefined **)CONCAT71(local_d8._1_7_,3);
          <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
          ::drop(&ppuStack_d0);
          ppuVar15 = local_68;
          ppuVar22 = local_60;
          puVar23 = (ulonglong *)
                    __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
        }
      }
joined_r0x000140022765:
      __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT =
           (undefined *)puVar23;
      local_68 = ppuVar15;
      local_60 = ppuVar22;
      if (puVar3 != (undefined *)0x0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(ppuVar4,puVar3,1);
        return;
      }
      ppuVar10 = ppuVar17;
      ppuVar4 = local_a8;
    } while (ppuVar17 != ppuVar24);
  }
  local_a8 = ppuVar4;
  ppuStack_a0 = ppuVar17;
  if (ppuVar24 != ppuVar17) {
    uVar20 = (ulonglong)((longlong)ppuVar24 - (longlong)ppuVar17) / 0x58;
    ppuVar17 = ppuVar17 + 1;
    do {
      if (ppuVar17[-1] != (undefined *)0x0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*ppuVar17,ppuVar17[-1],1);
        return;
      }
      ppuVar17 = ppuVar17 + 0xb;
      uVar20 = uVar20 - 1;
    } while (uVar20 != 0);
  }
  if (ppuVar15 != (undefined **)0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(ppuVar22,(longlong)ppuVar15 * 0x58,8);
    return;
  }
LAB_1400227f9:
  if (((bVar8 == 0) && ((*puVar23 & 0x7fffffffffffffff) != 0)) &&
     (cVar9 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar9 == '\0')) {
    DAT_140699651 = '\x01';
  }
  cVar9 = IMPAIR;
  LOCK();
  IMPAIR = 0;
  UNLOCK();
  if (cVar9 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&IMPAIR);
  }
  return;
LAB_140022467:
  DAT_140699688 = 0;
  local_a8 = (undefined **)&DAT_140699670;
  local_98 = (undefined **)0x0;
  ppuStack_90 = (undefined **)0x0;
  local_88 = (ulonglong)ppuStack_a0;
  <alloc[246c2e7857c81348]::collections::vec_deque::drain::Drain<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::partition::
  <alloc[246c2e7857c81348]::vec::Vec<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>,<host_probe[b94139f9089eb1d8]::net::Impairment>::take_due::_closure_1_>
            (&local_d8,&local_a8,&local_78);
  local_98 = (undefined **)CONCAT44(uStack_c4,local_c8);
  local_a8 = local_d8;
  ppuStack_a0 = ppuStack_d0;
  uVar20 = CONCAT44(uStack_bc,uStack_c0);
  core[505b25137b8ba7f]::ptr::drop_glue::
  <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>>
            (&DAT_140699670);
  DAT_140699678 = lStack_b8;
  DAT_140699680 = 0;
  DAT_140699688 = local_b0;
  local_d8 = (undefined **)&local_e1;
  ppuVar10 = ppuStack_a0;
  DAT_140699670 = uVar20;
  if (1 < local_98) {
    if (local_98 < 0x15) {
      core[505b25137b8ba7f]::slice::sort::shared::smallsort::insertion_sort_shift_left::
      <(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind),<[(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)]>::sort_by_key<std[3bf9d48a0c3997f0]::time::Instant,<host_probe[b94139f9089eb1d8]::net::Impairment>::take_due::_closure_2_>::_closure_0_>
                (ppuStack_a0,local_98,1,&local_d8);
    }
    else {
      core[505b25137b8ba7f]::slice::sort::stable::driftsort_main::
      <(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind),<[(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)]>::sort_by_key<std[3bf9d48a0c3997f0]::time::Instant,<host_probe[b94139f9089eb1d8]::net::Impairment>::take_due::_closure_2_>::_closure_0_,alloc[246c2e7857c81348]::vec::Vec<(std[3bf9d48a0c3997f0]::time::Instant,u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,alloc[246c2e7857c81348]::vec::Vec<u8>,host_probe[b94139f9089eb1d8]::netstats::Kind)>>
                (ppuStack_a0,local_98,&local_d8);
    }
  }
  goto LAB_140022519;
}

