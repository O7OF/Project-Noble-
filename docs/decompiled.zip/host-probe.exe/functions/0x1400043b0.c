// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::protocol::Listing>
// address: 0x1400043b0
// body: available
// range: 0x1400043b0-0x1400044a2 inclusive
// range: 0x1400044b0-0x1400044e7 inclusive
// range: 0x1400044ea-0x140004538 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400043ce to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400043e6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400043fe to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004416 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000442e to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004449 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004467 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004485 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400044cc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400044e3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004503 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000452a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::protocol::Listing> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::protocol::Listing>
          (longlong *param_1)

{
  longlong lVar1;
  undefined8 *puVar2;
  
  if (*param_1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],*param_1,1);
    return;
  }
  if (param_1[3] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[4],param_1[3],1);
    return;
  }
  if (param_1[6] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[7],param_1[6],1);
    return;
  }
  if (param_1[9] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[10],param_1[9],1);
    return;
  }
  if (param_1[0xc] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0xd],param_1[0xc],1);
    return;
  }
  if (param_1[0xf] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x10],param_1[0xf],1);
    return;
  }
  if (param_1[0x12] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x13],param_1[0x12],1);
    return;
  }
  if (param_1[0x15] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x16],param_1[0x15],1);
    return;
  }
  lVar1 = param_1[0x1a];
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)(param_1[0x19] + 0x20);
    do {
      if (puVar2[-4] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar2[-3],puVar2[-4],1);
        return;
      }
      if (puVar2[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar2,puVar2[-1],1);
        return;
      }
      puVar2 = puVar2 + 7;
      lVar1 = lVar1 + -1;
    } while (lVar1 != 0);
  }
  if (param_1[0x18] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x19],param_1[0x18] * 0x38,8);
    return;
  }
  if (param_1[0x1b] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x1c],param_1[0x1b],1);
    return;
  }
  return;
}

