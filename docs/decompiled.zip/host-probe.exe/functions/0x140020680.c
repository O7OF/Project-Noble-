// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::m64::install
// address: 0x140020680
// body: available
// range: 0x140020680-0x140020f50 inclusive
// range: 0x140020f56-0x140021311 inclusive
// range: 0x140021320-0x1400213ab inclusive
// range: 0x1400213c0-0x140021538 inclusive
// range: 0x14002153e-0x1400215fe inclusive
// range: 0x140021604-0x1400216d5 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140020a72 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140020c62 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140020c7c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140020c9c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140020f4c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140021011 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002103f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140021057 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140021072 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400213a7 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002150f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140021534 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::m64::install */

undefined8 * __rustcall
host_probe[b94139f9089eb1d8]::m64::install
          (undefined8 *param_1,longlong param_2,char param_3,byte param_4)

{
  undefined4 uVar1;
  code *pcVar2;
  uint uVar3;
  longlong lVar4;
  undefined8 uVar5;
  byte ***_Size;
  char cVar6;
  byte bVar7;
  longlong lVar8;
  undefined8 *puVar9;
  byte bVar10;
  byte bVar11;
  longlong lVar12;
  ulonglong uVar13;
  longlong lVar14;
  byte *pbVar15;
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 local_271;
  longlong local_270;
  longlong lStack_268;
  longlong local_260;
  byte *local_258;
  longlong local_250;
  byte *local_248;
  byte **local_240;
  code *local_238;
  byte **local_230;
  undefined8 *local_228;
  undefined8 local_220;
  byte *local_218;
  code *pcStack_210;
  byte ***local_208;
  longlong local_1f8;
  longlong lStack_1f0;
  longlong local_1e8;
  longlong local_1d8;
  char local_1d0;
  undefined8 local_1c8;
  undefined4 local_1c0;
  undefined2 local_1bc;
  undefined4 local_1b8;
  undefined4 local_1b4;
  byte *local_1b0;
  undefined8 uStack_1a8;
  undefined8 local_1a0;
  longlong *local_198;
  undefined8 local_190;
  byte *local_188;
  code *pcStack_180;
  byte ***local_178;
  code *local_170;
  longlong **local_168;
  code *local_160;
  byte ***local_158;
  undefined8 local_150;
  undefined *local_148;
  code *local_140;
  undefined *local_138;
  undefined8 local_130;
  undefined4 local_128;
  code *local_120;
  undefined *local_118;
  undefined8 local_110;
  undefined4 local_108;
  code *local_100;
  undefined *local_f8;
  undefined8 local_f0;
  undefined4 local_e8;
  code *local_e0;
  undefined *local_d8;
  undefined8 local_d0;
  undefined4 local_c8;
  code *local_c0;
  undefined *local_b8;
  undefined8 local_b0;
  undefined4 local_a8;
  code *local_a0;
  undefined *local_98;
  undefined8 local_90;
  undefined4 local_88;
  code *local_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined4 local_68;
  byte *local_60;
  code *pcStack_58;
  byte ***local_50;
  byte **local_48;
  
  if ((pbx::RELOCATED_0_llvm_10439611301029776152 == '\0') ||
     (pbx::WIDE_0_llvm_10439611301029776152 == '\0')) {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    pcStack_210 = (code *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x4f,1);
    if (pcStack_210 == (code *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x4f);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    *(undefined8 *)(pcStack_210 + 0x3f) = 0x525220313d42505f;
    *(undefined8 *)(pcStack_210 + 0x47) = 0x29313d343642505f;
    *(undefined8 *)(pcStack_210 + 0x30) = 0x6c7320726579616c;
    *(undefined8 *)(pcStack_210 + 0x38) = 0x5f5252282073746f;
    *(undefined8 *)(pcStack_210 + 0x20) = 0x206b636f6c622072;
    *(undefined8 *)(pcStack_210 + 0x28) = 0x7020343620646e61;
    *(undefined8 *)(pcStack_210 + 0x10) = 0x766f6d2065687420;
    *(undefined8 *)(pcStack_210 + 0x18) = 0x6579616c70206465;
    *(undefined8 *)pcStack_210 = 0x696863616d203436;
    *(undefined8 *)(pcStack_210 + 8) = 0x6465656e2073656e;
    local_218 = &DAT_0000004f;
    local_208 = (byte ***)&DAT_0000004f;
LAB_140020cb0:
    param_1[2] = local_208;
    *param_1 = local_218;
    param_1[1] = pcStack_210;
  }
  else {
    local_271 = 0;
    if (param_3 != '\0') {
      local_271 = param_4;
    }
    if (local_271 < 0x40) {
      local_1b8 = 0x40b0;
      local_1b4 = 0x40e0;
      local_1d8 = 0x4b89e9ab0f2c4b8b;
      local_1d0 = ',';
      local_188 = &DAT_1406a1bcf;
      pcStack_180 = (code *)0x3;
      local_170 = (code *)0x4;
      local_168 = (longlong **)&DAT_1406a1bd2;
      local_160 = (code *)0x2;
      local_150 = 4;
      local_148 = &DAT_1406a1bd4;
      local_140 = (code *)0x3;
      local_178 = (byte ***)&local_1b8;
      local_158 = (byte ***)&local_1b8;
      <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_1b0,&local_188,5);
      local_1c8._0_6_ = 0x748b482c438b;
      local_1c8._6_2_ = 0x4024;
      local_1c0 = 0x89f8b30f;
      local_1bc = 0x2c43;
      local_188 = &DAT_1406a1bd7;
      pcStack_180 = (code *)0x3;
      local_170 = (code *)0x4;
      local_168 = (longlong **)&DAT_1406a1bda;
      local_160 = (code *)0x2;
      local_150 = 4;
      local_148 = &DAT_1406a1bdc;
      local_140 = (code *)0x8;
      local_178 = (byte ***)&local_1b8;
      local_158 = (byte ***)&local_1b8;
      <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_258,&local_188,5);
      local_78 = -0x5cf012cca3b974bf;
      uStack_70 = 0x20fd83c5ff0973e8;
      local_68 = 0x5ebf47c;
      local_188 = &DAT_1406a1be4;
      pcStack_180 = (code *)0x3;
      local_178 = (byte ***)&local_1b4;
      local_170 = (code *)0x4;
      <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat(&local_270,&local_188,2);
      bVar7 = local_271;
      if ((ulonglong)(local_270 - local_260) < 7) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_270,local_260,7,1,1);
      }
      *(undefined1 *)(local_260 + lStack_268) = 0xbd;
      *(byte *)(local_260 + lStack_268 + 1) = bVar7;
      *(undefined4 *)(local_260 + lStack_268 + 2) = 0x31000000;
      *(undefined1 *)(local_260 + lStack_268 + 6) = 0xd2;
      local_260 = local_260 + 7;
      if ((ulonglong)(local_270 - local_260) < 6) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_270,local_260,6,1,1);
      }
      *(undefined4 *)(local_260 + lStack_268) = 0xe8a30f48;
      *(undefined2 *)(local_260 + lStack_268 + 4) = 0x1a73;
      local_260 = local_260 + 6;
      if ((ulonglong)(local_270 - local_260) < 0xc) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_270,local_260,0xc,1,1);
      }
      *(undefined8 *)(local_260 + lStack_268) = 0x83c2ff3fe583c5ff;
      *(undefined4 *)(local_260 + lStack_268 + 8) = 0xee7c40fa;
      lVar12 = local_260 + 0xc;
      local_260 = lVar12;
      hook::far_jump(&local_188,param_2 + 0x3953d5);
      _Size = local_178;
      pcVar2 = pcStack_180;
      pbVar15 = local_188;
      if ((byte ***)(local_270 - lVar12) < local_178) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_270,lVar12,local_178,1,1);
        lVar12 = local_260;
LAB_140020a46:
        memcpy((void *)(lVar12 + lStack_268),pcVar2,(size_t)_Size);
      }
      else if (local_178 != (byte ***)0x0) goto LAB_140020a46;
      lVar12 = lVar12 + (longlong)_Size;
      local_260 = lVar12;
      if (pbVar15 != (byte *)0x0) {
        puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(pcVar2,pbVar15,1);
        return puVar9;
      }
      local_1f8 = 0x39d054;
      local_198 = &local_1d8;
      local_190 = 9;
      local_240 = (byte **)(param_2 + 0x39d054);
      local_238 = (code *)0x9;
      if (*(char *)(param_2 + 0x39d05c) != local_1d0 ||
          *(longlong *)(param_2 + 0x39d054) != local_1d8) {
LAB_140020bbc:
        local_188 = (byte *)&local_1f8;
        pcStack_180 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
        local_178 = &local_240;
        local_170 = <&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
        local_168 = &local_198;
        local_160 = <&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_60,&DAT_1406a1cb8,&local_188);
        local_218 = local_60;
        pcStack_210 = pcStack_58;
        local_208 = local_50;
LAB_140020c4d:
        if (local_270 != 0) {
          puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lStack_268,local_270,1);
          return puVar9;
        }
        if (local_258 != (byte *)0x0) {
          puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(local_250,local_258,1);
          return puVar9;
        }
        if (local_1b0 != (byte *)0x0) {
          puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_1a8,local_1b0,1);
          return puVar9;
        }
        goto LAB_140020ca1;
      }
      local_1f8 = 0x39d13e;
      local_198 = &local_1c8;
      local_190 = 0xe;
      local_240 = (byte **)(param_2 + 0x39d13e);
      local_238 = (code *)0xe;
      if (*(longlong *)(param_2 + 0x39d144) !=
          CONCAT26(local_1bc,CONCAT42(local_1c0,local_1c8._6_2_)) ||
          *(longlong *)(param_2 + 0x39d13e) != CONCAT26(local_1c8._6_2_,(undefined6)local_1c8))
      goto LAB_140020bbc;
      local_1f8 = 0x3953bc;
      local_198 = &local_78;
      local_190 = 0x14;
      local_240 = (byte **)(param_2 + 0x3953bc);
      local_238 = (code *)0x14;
      uVar1 = *(undefined4 *)(param_2 + 0x3953cc);
      auVar16[0] = -(*(char *)(param_2 + 0x3953bc) == (char)local_78);
      auVar16[1] = -(*(char *)(param_2 + 0x3953bd) == local_78._1_1_);
      auVar16[2] = -(*(char *)(param_2 + 0x3953be) == local_78._2_1_);
      auVar16[3] = -(*(char *)(param_2 + 0x3953bf) == local_78._3_1_);
      auVar16[4] = -(*(char *)(param_2 + 0x3953c0) == local_78._4_1_);
      auVar16[5] = -(*(char *)(param_2 + 0x3953c1) == local_78._5_1_);
      auVar16[6] = -(*(char *)(param_2 + 0x3953c2) == local_78._6_1_);
      auVar16[7] = -(*(char *)(param_2 + 0x3953c3) == local_78._7_1_);
      auVar16[8] = -(*(char *)(param_2 + 0x3953c4) == (char)uStack_70);
      auVar16[9] = -(*(char *)(param_2 + 0x3953c5) == uStack_70._1_1_);
      auVar16[10] = -(*(char *)(param_2 + 0x3953c6) == uStack_70._2_1_);
      auVar16[0xb] = -(*(char *)(param_2 + 0x3953c7) == uStack_70._3_1_);
      auVar16[0xc] = -(*(char *)(param_2 + 0x3953c8) == uStack_70._4_1_);
      auVar16[0xd] = -(*(char *)(param_2 + 0x3953c9) == uStack_70._5_1_);
      auVar16[0xe] = -(*(char *)(param_2 + 0x3953ca) == uStack_70._6_1_);
      auVar16[0xf] = -(*(char *)(param_2 + 0x3953cb) == uStack_70._7_1_);
      auVar17[0] = -((char)local_68 == (char)uVar1);
      auVar17[1] = -((char)((uint)local_68 >> 8) == (char)((uint)uVar1 >> 8));
      auVar17[2] = -((char)((uint)local_68 >> 0x10) == (char)((uint)uVar1 >> 0x10));
      auVar17[3] = -((char)((uint)local_68 >> 0x18) == (char)((uint)uVar1 >> 0x18));
      auVar17[4] = 0xff;
      auVar17[5] = 0xff;
      auVar17[6] = 0xff;
      auVar17[7] = 0xff;
      auVar17[8] = 0xff;
      auVar17[9] = 0xff;
      auVar17[10] = 0xff;
      auVar17[0xb] = 0xff;
      auVar17[0xc] = 0xff;
      auVar17[0xd] = 0xff;
      auVar17[0xe] = 0xff;
      auVar17[0xf] = 0xff;
      auVar16 = auVar16 & auVar17;
      if ((ushort)((ushort)(SUB161(auVar16 >> 7,0) & 1) |
                   (ushort)(SUB161(auVar16 >> 0xf,0) & 1) << 1 |
                   (ushort)(SUB161(auVar16 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar16 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar16 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar16 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar16 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar16 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar16 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar16 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar16 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar16 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar16 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar16 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar16 >> 0x77,0) & 1) << 0xe |
                  (ushort)(byte)(auVar16[0xf] >> 7) << 0xf) != 0xffff) goto LAB_140020bbc;
      local_228 = (undefined8 *)&DAT_1406a1be7;
      local_220 = 8;
      local_240 = (byte **)0x0;
      local_238 = (code *)0x8;
      local_230 = (byte **)0x0;
      <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                (&local_240,0x3fbde2,&DAT_1406a1bef,4,&DAT_1406a1bf3,4);
      <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                (&local_240,0x3fbdf6,&DAT_1406a18a8,4,&DAT_1406a1bf7,4);
      <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                (&local_240,0x3fbe64,&DAT_1406a1bfb,5,&DAT_1406a1c00,5);
      <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
                (&local_240,0x3fbe7d,&DAT_1406a1c05,3,&DAT_1406a1c08,3);
      <host_probe[b94139f9089eb1d8]::p64::Batch>::apply(&local_188,&local_240,param_2);
      uVar5 = uStack_1a8;
      if ((((local_188 != (byte *)0xffffffffffffffff) ||
           (hook::detour_to(&local_188,param_2,0x39d054,&local_1d8,9,uStack_1a8,local_1a0,0x39d05d),
           lVar14 = local_250, local_188 != (byte *)0xffffffffffffffff)) ||
          (hook::detour_to(&local_188,param_2,0x39d13e,&local_1c8,0xe,local_250,local_248,0x39d14c),
          lVar8 = lStack_268, local_188 != (byte *)0xffffffffffffffff)) ||
         (hook::detour_to(&local_188,param_2,0x3953bc,&local_78,0x14,lStack_268,lVar12,0x3953d0),
         local_188 != (byte *)0xffffffffffffffff)) {
        local_208 = local_178;
        local_218 = local_188;
        pcStack_210 = pcStack_180;
        <alloc[246c2e7857c81348]::vec::Vec<(std[3bf9d48a0c3997f0]::path::PathBuf,alloc[246c2e7857c81348]::string::String)>as_core[505b25137b8ba7f]::ops::drop::Drop>
        ::drop(&local_240);
        if (local_240 != (byte **)0x0) {
          puVar9 = (undefined8 *)
                   __rustc[9d087a5ab36ea756]::__rust_dealloc(local_238,(longlong)local_240 * 0x38,8)
          ;
          return puVar9;
        }
        goto LAB_140020c4d;
      }
      local_48 = (byte **)(pbx::DELTA_0_llvm_10439611301029776152 + 0x260);
      local_188 = &DAT_1406a1c10;
      pcStack_180 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_178 = &local_48;
      local_170 = <isize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_168 = (longlong **)&local_271;
      local_160 = <u8_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_1f8,&DAT_1406a1c18,&local_188);
      lVar4 = lStack_1f0;
      lVar12 = local_1f8;
      host::log(lStack_1f0,local_1e8);
      if (lVar12 != 0) {
        puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lVar4,lVar12,1);
        return puVar9;
      }
      local_218 = (byte *)0xffffffffffffffff;
      core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::p64::Batch>(&local_240);
      if (local_270 != 0) {
        puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lVar8,local_270,1);
        return puVar9;
      }
      if (local_258 != (byte *)0x0) {
        puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lVar14,local_258,1);
        return puVar9;
      }
      if (local_1b0 != (byte *)0x0) {
        puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar5,local_1b0,1);
        return puVar9;
      }
    }
    else {
      local_188 = &local_271;
      pcStack_180 = <u8_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&local_218,&DAT_1406a1ce9,&local_188);
LAB_140020ca1:
      if (local_218 != (byte *)0xffffffffffffffff) goto LAB_140020cb0;
    }
    local_258 = (byte *)0x0;
    local_250 = 1;
    local_248 = (byte *)0x0;
    local_188 = (byte *)0x0;
    pcStack_180 = (code *)0x8;
    local_178 = (byte ***)&DAT_1406a1468;
    local_170 = (code *)0x4;
    local_168 = (longlong **)CONCAT44(local_168._4_4_,0x4a);
    local_160 = m64_join::install;
    local_158 = (byte ***)&DAT_1406a1d1e;
    local_150 = 7;
    local_148 = (undefined *)CONCAT44(local_148._4_4_,0x52);
    local_140 = m64_records::install;
    local_138 = &DAT_1406a1d25;
    local_130 = 7;
    local_128 = 0x50;
    local_120 = m64_readers::install;
    local_118 = &DAT_1406a1d2c;
    local_110 = 6;
    local_108 = 0x4d;
    local_100 = m64_member::install;
    local_f8 = &DAT_1406a1d32;
    local_f0 = 6;
    local_e8 = 0x55;
    local_e0 = m64_update::install;
    local_d8 = &DAT_1406a1d38;
    local_d0 = 8;
    local_c8 = 0x4f;
    local_c0 = m64_observer::install;
    local_b8 = &DAT_1406a1d40;
    local_b0 = 5;
    local_a8 = 0x56;
    local_a0 = m64_views::install;
    local_98 = &DAT_1406a1d45;
    local_90 = 9;
    local_88 = 0x54;
    local_80 = m64_transport::install;
    lVar12 = 1;
    pbVar15 = (byte *)0x0;
    lVar14 = 0;
    do {
      if (*(int *)((longlong)&local_168 + lVar14) == -1) break;
      pcVar2 = *(code **)((longlong)&local_160 + lVar14);
      local_1b0 = *(byte **)((longlong)&local_178 + lVar14);
      uStack_1a8 = *(undefined8 *)((longlong)&local_170 + lVar14);
      local_218 = (byte *)CONCAT44(local_218._4_4_,*(int *)((longlong)&local_168 + lVar14));
      cVar6 = enabled();
      if (cVar6 == '\0') {
        local_240 = &local_218;
        local_238 = <char_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_230 = &local_1b0;
        local_228 = &<&str_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_1f8,&DAT_1406a1d90,&local_240);
        lVar4 = lStack_1f0;
        lVar8 = local_1f8;
        host::log(lStack_1f0,local_1e8);
        if (lVar8 != 0) {
          puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lVar4,lVar8,1);
          return puVar9;
        }
      }
      else {
        (*pcVar2)(&local_270,param_2);
        if (local_270 != -1) {
          local_1e8 = local_260;
          local_1f8 = local_270;
          lStack_1f0 = lStack_268;
          local_240 = &local_1b0;
          local_238 = (code *)&<&str_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
          local_230 = (byte **)&local_1f8;
          local_228 = &<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                       ::fmt;
          alloc[246c2e7857c81348]::fmt::format::format_inner(&local_60,&DAT_1406a06c8,&local_240);
          if (local_1f8 != 0) {
            puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lStack_1f0,local_1f8,1)
            ;
            return puVar9;
          }
          param_1[2] = local_50;
          *param_1 = local_60;
          param_1[1] = pcStack_58;
          if (local_258 == (byte *)0x0) {
            return param_1;
          }
          puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(lVar12,local_258,1);
          return puVar9;
        }
        uVar3 = (uint)local_218;
        bVar7 = (byte)local_218;
        if ((uint)local_218 < 0x80) {
          if (local_258 == pbVar15) {
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
            <alloc[246c2e7857c81348]::alloc::Global>(&local_258,pbVar15,1,1,1);
          }
          pbVar15[local_250] = bVar7;
          lVar8 = 1;
          lVar12 = local_250;
        }
        else {
          uVar13 = 4 - (ulonglong)((uint)local_218 < 0x10000);
          if ((uint)local_218 < 0x800) {
            uVar13 = 2;
          }
          if ((ulonglong)((longlong)local_258 - (longlong)pbVar15) < uVar13) {
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
            <alloc[246c2e7857c81348]::alloc::Global>(&local_258,pbVar15,uVar13,1,1);
            lVar12 = local_250;
          }
          bVar7 = bVar7 & 0x3f | 0x80;
          bVar10 = (byte)(uVar3 >> 6);
          if (uVar3 < 0x800) {
            pbVar15[lVar12] = bVar10 | 0xc0;
            pbVar15[lVar12 + 1] = bVar7;
            lVar8 = 2;
          }
          else {
            bVar10 = bVar10 & 0x3f | 0x80;
            bVar11 = (byte)(uVar3 >> 0xc);
            if (uVar3 < 0x10000) {
              pbVar15[lVar12] = bVar11 | 0xe0;
              pbVar15[lVar12 + 1] = bVar10;
              pbVar15[lVar12 + 2] = bVar7;
              lVar8 = 3;
            }
            else {
              pbVar15[lVar12] = (byte)(uVar3 >> 0x12) | 0xf0;
              pbVar15[lVar12 + 1] = bVar11 & 0x3f | 0x80;
              pbVar15[lVar12 + 2] = bVar10;
              pbVar15[lVar12 + 3] = bVar7;
              lVar8 = 4;
            }
          }
        }
        pbVar15 = pbVar15 + lVar8;
        local_248 = pbVar15;
      }
      lVar14 = lVar14 + 0x20;
    } while (lVar14 != 0x100);
    local_240 = &local_258;
    local_238 = (code *)&<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Display>
                         ::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_188,&DAT_1406a1d4e,&local_240);
    pcVar2 = pcStack_180;
    pbVar15 = local_188;
    host::log(pcStack_180,local_178);
    if (pbVar15 != (byte *)0x0) {
      puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(pcVar2,pbVar15,1);
      return puVar9;
    }
    *param_1 = 0xffffffffffffffff;
    if (local_258 != (byte *)0x0) {
      puVar9 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(local_250,local_258,1);
      return puVar9;
    }
  }
  return param_1;
}

