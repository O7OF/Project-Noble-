// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>>
// address: 0x140045ac0
// body: available
// range: 0x140045ac0-0x140045bde inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140045bd2 to 0x14052a040 <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::path::PathBuf>>::drop_slow (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>>
          (longlong *param_1)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  
  lVar3 = param_1[0x98];
  if (lVar3 == -1) goto LAB_140045b87;
  lVar1 = param_1[0x134];
  if (lVar1 != -1) {
    if (lVar1 != 0) {
      if ((int)lVar1 == 2) goto LAB_140045b21;
      <std[3bf9d48a0c3997f0]::sys::fs::windows::FindNextFileHandle_as_core[505b25137b8ba7f]::ops::drop::Drop>
      ::drop(param_1 + 0x135);
    }
    plVar2 = (longlong *)param_1[0x136];
    LOCK();
    *plVar2 = *plVar2 + -1;
    UNLOCK();
    if (*plVar2 == 0) {
      <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::path::PathBuf>>::drop_slow
                (param_1 + 0x136);
    }
    lVar3 = param_1[0x98];
  }
LAB_140045b21:
  if (lVar3 == 0) {
LAB_140045b38:
    plVar2 = (longlong *)param_1[0x9a];
    LOCK();
    *plVar2 = *plVar2 + -1;
    UNLOCK();
    if (*plVar2 == 0) {
      <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::path::PathBuf>>::drop_slow
                (param_1 + 0x9a);
    }
  }
  else if (lVar3 != 2) {
    <std[3bf9d48a0c3997f0]::sys::fs::windows::FindNextFileHandle_as_core[505b25137b8ba7f]::ops::drop::Drop>
    ::drop(param_1 + 0x99);
    goto LAB_140045b38;
  }
  if (param_1[0xe6] != 0) {
    if ((int)param_1[0xe6] == 2) goto LAB_140045b87;
    <std[3bf9d48a0c3997f0]::sys::fs::windows::FindNextFileHandle_as_core[505b25137b8ba7f]::ops::drop::Drop>
    ::drop(param_1 + 0xe7);
  }
  plVar2 = (longlong *)param_1[0xe8];
  LOCK();
  *plVar2 = *plVar2 + -1;
  UNLOCK();
  if (*plVar2 == 0) {
    <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::path::PathBuf>>::drop_slow
              (param_1 + 0xe8);
  }
LAB_140045b87:
  if ((*param_1 != 0) && (plVar2 = (longlong *)param_1[1], plVar2 != (longlong *)0x0)) {
    LOCK();
    *plVar2 = *plVar2 + -1;
    UNLOCK();
    if (*plVar2 == 0) {
      <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::path::PathBuf>>::drop_slow
                (param_1 + 1);
    }
  }
  if ((param_1[0x4c] != 0) && (plVar2 = (longlong *)param_1[0x4d], plVar2 != (longlong *)0x0)) {
    LOCK();
    *plVar2 = *plVar2 + -1;
    UNLOCK();
    if (*plVar2 == 0) {
      <alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::path::PathBuf>>::drop_slow
                (param_1 + 0x4d);
      return;
    }
  }
  return;
}

