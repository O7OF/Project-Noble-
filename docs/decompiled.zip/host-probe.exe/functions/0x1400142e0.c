// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::net::Route>::is
// address: 0x1400142e0
// body: available
// range: 0x1400142e0-0x140014364 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::net::Route>::is */

ushort __rustcall
<host_probe[b94139f9089eb1d8]::net::Route>::is(longlong param_1,short *param_2,byte *param_3)

{
  ushort uVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  
  if (*(short *)(param_1 + 0x10) == *param_2) {
    if (*(short *)(param_1 + 0x10) == 0) {
      if (*(short *)(param_1 + 0x16) != param_2[3]) {
        return 0;
      }
      if (*(int *)(param_1 + 0x12) != *(int *)(param_2 + 1)) {
        return 0;
      }
    }
    else {
      if (*(short *)(param_1 + 0x2c) != param_2[0xe]) {
        return 0;
      }
      if (*(int *)(param_1 + 0x24) != *(int *)(param_2 + 10)) {
        return 0;
      }
      if (*(int *)(param_1 + 0x28) != *(int *)(param_2 + 0xc)) {
        return 0;
      }
      auVar2[0] = -((char)param_2[2] == *(char *)(param_1 + 0x14));
      auVar2[1] = -(*(char *)((longlong)param_2 + 5) == *(char *)(param_1 + 0x15));
      auVar2[2] = -((char)param_2[3] == *(char *)(param_1 + 0x16));
      auVar2[3] = -(*(char *)((longlong)param_2 + 7) == *(char *)(param_1 + 0x17));
      auVar2[4] = -((char)param_2[4] == *(char *)(param_1 + 0x18));
      auVar2[5] = -(*(char *)((longlong)param_2 + 9) == *(char *)(param_1 + 0x19));
      auVar2[6] = -((char)param_2[5] == *(char *)(param_1 + 0x1a));
      auVar2[7] = -(*(char *)((longlong)param_2 + 0xb) == *(char *)(param_1 + 0x1b));
      auVar2[8] = -((char)param_2[6] == *(char *)(param_1 + 0x1c));
      auVar2[9] = -(*(char *)((longlong)param_2 + 0xd) == *(char *)(param_1 + 0x1d));
      auVar2[10] = -((char)param_2[7] == *(char *)(param_1 + 0x1e));
      auVar2[0xb] = -(*(char *)((longlong)param_2 + 0xf) == *(char *)(param_1 + 0x1f));
      auVar2[0xc] = -((char)param_2[8] == *(char *)(param_1 + 0x20));
      auVar2[0xd] = -(*(char *)((longlong)param_2 + 0x11) == *(char *)(param_1 + 0x21));
      auVar2[0xe] = -((char)param_2[9] == *(char *)(param_1 + 0x22));
      auVar2[0xf] = -(*(char *)((longlong)param_2 + 0x13) == *(char *)(param_1 + 0x23));
      if ((ushort)((ushort)(SUB161(auVar2 >> 7,0) & 1) | (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1
                   | (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe | (ushort)(auVar2[0xf] >> 7) << 0xf
                  ) != 0xffff) {
        return 0;
      }
    }
    if (*(char *)(param_1 + 0x30) == '\0') {
      return (ushort)(*param_3 ^ 1);
    }
    if (*param_3 != 0) {
      auVar3[0] = -(param_3[1] == *(byte *)(param_1 + 0x31));
      auVar3[1] = -(param_3[2] == *(byte *)(param_1 + 0x32));
      auVar3[2] = -(param_3[3] == *(byte *)(param_1 + 0x33));
      auVar3[3] = -(param_3[4] == *(byte *)(param_1 + 0x34));
      auVar3[4] = -(param_3[5] == *(byte *)(param_1 + 0x35));
      auVar3[5] = -(param_3[6] == *(byte *)(param_1 + 0x36));
      auVar3[6] = -(param_3[7] == *(byte *)(param_1 + 0x37));
      auVar3[7] = -(param_3[8] == *(byte *)(param_1 + 0x38));
      auVar3[8] = -(param_3[9] == *(byte *)(param_1 + 0x39));
      auVar3[9] = -(param_3[10] == *(byte *)(param_1 + 0x3a));
      auVar3[10] = -(param_3[0xb] == *(byte *)(param_1 + 0x3b));
      auVar3[0xb] = -(param_3[0xc] == *(byte *)(param_1 + 0x3c));
      auVar3[0xc] = -(param_3[0xd] == *(byte *)(param_1 + 0x3d));
      auVar3[0xd] = -(param_3[0xe] == *(byte *)(param_1 + 0x3e));
      auVar3[0xe] = -(param_3[0xf] == *(byte *)(param_1 + 0x3f));
      auVar3[0xf] = -(param_3[0x10] == *(byte *)(param_1 + 0x40));
      uVar1 = (ushort)(SUB161(auVar3 >> 7,0) & 1) | (ushort)(SUB161(auVar3 >> 0xf,0) & 1) << 1 |
              (ushort)(SUB161(auVar3 >> 0x17,0) & 1) << 2 |
              (ushort)(SUB161(auVar3 >> 0x1f,0) & 1) << 3 |
              (ushort)(SUB161(auVar3 >> 0x27,0) & 1) << 4 |
              (ushort)(SUB161(auVar3 >> 0x2f,0) & 1) << 5 |
              (ushort)(SUB161(auVar3 >> 0x37,0) & 1) << 6 |
              (ushort)(SUB161(auVar3 >> 0x3f,0) & 1) << 7 |
              (ushort)(SUB161(auVar3 >> 0x47,0) & 1) << 8 |
              (ushort)(SUB161(auVar3 >> 0x4f,0) & 1) << 9 |
              (ushort)(SUB161(auVar3 >> 0x57,0) & 1) << 10 |
              (ushort)(SUB161(auVar3 >> 0x5f,0) & 1) << 0xb |
              (ushort)(SUB161(auVar3 >> 0x67,0) & 1) << 0xc |
              (ushort)(SUB161(auVar3 >> 0x6f,0) & 1) << 0xd |
              (ushort)(SUB161(auVar3 >> 0x77,0) & 1) << 0xe | (ushort)(auVar3[0xf] >> 7) << 0xf;
      return CONCAT11((char)(uVar1 >> 8),uVar1 == 0xffff);
    }
  }
  return 0;
}

