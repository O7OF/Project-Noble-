// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,4usize>>
// address: 0x140043290
// body: available
// range: 0x140043290-0x1400433de inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,
   4usize>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::
<core[505b25137b8ba7f]::array::iter::IntoIter<alloc[246c2e7857c81348]::string::String,4usize>>
          (longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong local_88 [9];
  longlong lStack_40;
  longlong local_38;
  longlong lStack_30;
  
  lVar8 = param_1[2];
  if ((ulonglong)(*param_1 - lVar8) < (ulonglong)(param_2[1] - *param_2)) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar8,param_2[1] - *param_2,8,0x18);
    lVar8 = param_1[2];
  }
  lVar5 = param_1[1];
  lVar1 = *param_2;
  lVar6 = param_2[1];
  local_38 = param_2[0xc];
  lStack_30 = param_2[0xd];
  local_88[8] = param_2[10];
  lStack_40 = param_2[0xb];
  local_88[6] = param_2[8];
  local_88[7] = param_2[9];
  local_88[4] = param_2[6];
  local_88[5] = param_2[7];
  local_88[2] = param_2[4];
  local_88[3] = param_2[5];
  local_88[0] = param_2[2];
  local_88[1] = param_2[3];
  if (lVar6 != lVar1) {
    lVar9 = lVar1;
    if (((int)lVar6 - (int)lVar1 & 1U) != 0) {
      *(longlong *)(lVar5 + 0x10 + lVar8 * 0x18) = local_88[lVar1 * 3 + 2];
      lVar9 = local_88[lVar1 * 3 + 1];
      plVar2 = (longlong *)(lVar5 + lVar8 * 0x18);
      *plVar2 = local_88[lVar1 * 3];
      plVar2[1] = lVar9;
      lVar8 = lVar8 + 1;
      lVar9 = lVar1 + 1;
    }
    if (lVar6 != lVar1 + 1) {
      lVar5 = lVar5 + lVar8 * 0x18;
      lVar1 = lVar9 * 0x18;
      lVar10 = 0;
      do {
        *(undefined8 *)(lVar5 + 0x10 + lVar10) =
             *(undefined8 *)((longlong)local_88 + lVar10 + lVar1 + 0x10);
        puVar3 = (undefined8 *)((longlong)local_88 + lVar10 + lVar1);
        uVar7 = puVar3[1];
        *(undefined8 *)(lVar5 + lVar10) = *puVar3;
        ((undefined8 *)(lVar5 + lVar10))[1] = uVar7;
        lVar9 = lVar9 + 2;
        puVar3 = (undefined8 *)((longlong)local_88 + lVar10 + lVar1 + 0x18);
        uVar7 = puVar3[1];
        puVar4 = (undefined8 *)(lVar5 + 0x18 + lVar10);
        *puVar4 = *puVar3;
        puVar4[1] = uVar7;
        *(undefined8 *)(lVar5 + 0x28 + lVar10) =
             *(undefined8 *)((longlong)local_88 + lVar10 + lVar1 + 0x28);
        lVar8 = lVar8 + 2;
        lVar10 = lVar10 + 0x30;
      } while (lVar6 != lVar9);
    }
  }
  param_1[2] = lVar8;
  return;
}

