// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::m64_member::detour
// address: 0x1400165d0
// body: available
// range: 0x1400165d0-0x140016974 inclusive
// range: 0x140016976-0x140016a16 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140016730 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140016958 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140016970 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::m64_member::detour */

void __rustcall
host_probe[b94139f9089eb1d8]::m64_member::detour
          (ulonglong *param_1,undefined8 param_2,longlong param_3,code *param_4,undefined8 param_5,
          ulonglong param_6,void *param_7,size_t param_8,longlong param_9)

{
  code *pcVar1;
  void *pvVar2;
  code **ppcVar3;
  code **_Size;
  undefined1 *puVar4;
  undefined1 *_Dst;
  ulonglong uVar5;
  int iVar6;
  longlong lVar7;
  ulonglong uVar8;
  size_t sVar9;
  ulonglong uVar10;
  size_t local_c8;
  void *local_c0;
  size_t local_b8;
  longlong local_b0;
  undefined1 *local_a8;
  ulonglong local_a0;
  code **local_98;
  code *local_90;
  code **local_88;
  code *local_80;
  undefined8 local_78;
  ulonglong local_70;
  int local_68;
  undefined8 local_64;
  undefined4 local_5c;
  code *local_58;
  code *local_50;
  code *local_48;
  
  local_58 = param_4;
  if (param_6 < 5) {
    local_70 = param_6;
    local_98 = &local_58;
    local_90 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    local_88 = (code **)&local_70;
    local_80 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(param_1,&DAT_1406a18d1,&local_98);
    return;
  }
  if (param_8 == 0) {
    local_c8 = 0;
    local_c0 = (void *)0x1;
    local_b8 = 0;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    local_c0 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(param_8,1);
    if (local_c0 == (void *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,param_8);
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    local_c8 = param_8;
    memcpy(local_c0,param_7,param_8);
    local_b8 = param_8;
  }
  local_78 = param_2;
  hook::far_jump(&local_98,param_9 + param_3);
  _Size = local_88;
  pcVar1 = local_90;
  ppcVar3 = local_98;
  if ((code **)(param_8 - local_b8) < local_88) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_c8,local_b8,local_88,1,1);
LAB_140016704:
    sVar9 = local_b8;
    memcpy((void *)((longlong)local_c0 + local_b8),pcVar1,(size_t)_Size);
  }
  else {
    sVar9 = local_b8;
    if (local_88 != (code **)0x0) goto LAB_140016704;
  }
  pvVar2 = local_c0;
  local_b8 = sVar9 + (longlong)_Size;
  if (ppcVar3 != (code **)0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(pcVar1,ppcVar3,1);
    return;
  }
  hook::place_code(&local_98,param_3,local_c0,local_b8);
  pcVar1 = local_90;
  if (local_98 == (code **)0xffffffffffffffff) {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    puVar4 = (undefined1 *)__rustc[9d087a5ab36ea756]::__rust_alloc(1,1);
    if (puVar4 == (undefined1 *)0x0) {
      alloc[246c2e7857c81348]::alloc::handle_alloc_error(1,1);
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    *puVar4 = 0xe9;
    local_b0 = 1;
    local_a0 = 1;
    local_50 = param_4 + param_3 + 5;
    local_48 = pcVar1;
    lVar7 = (longlong)pcVar1 - (longlong)local_50;
    iVar6 = (int)lVar7;
    local_a8 = puVar4;
    if (iVar6 != lVar7) {
      local_98 = &local_48;
      local_90 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      local_88 = &local_50;
      local_80 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner
                (&local_70,&anon_2ea4320f4837ea28fa7015f50151942e_26_llvm_7975856906012809254,
                 &local_98);
      iVar6 = local_68;
      if (local_70 != 0xffffffffffffffff) {
        *(undefined4 *)((longlong)param_1 + 0x14) = local_5c;
        *(undefined8 *)((longlong)param_1 + 0xc) = local_64;
        *param_1 = local_70;
        *(int *)(param_1 + 1) = local_68;
        lVar7 = 1;
        goto LAB_140016958;
      }
    }
    local_68 = iVar6;
    iVar6 = local_68;
    uVar5 = 0;
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_b0,1,4,1,1);
    *(int *)(local_a8 + local_a0) = iVar6;
    uVar10 = local_a0 + 4;
    uVar8 = param_6 - uVar10;
    puVar4 = local_a8;
    local_a0 = param_6;
    if (uVar10 <= param_6 && uVar8 != 0) {
      if (local_b0 - uVar10 < uVar8) {
        local_a0 = uVar10;
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_b0,uVar10,uVar8,1,1);
        _Dst = local_a8 + local_a0;
        uVar5 = uVar10;
        puVar4 = local_a8;
        uVar10 = local_a0;
      }
      else {
        _Dst = local_a8 + uVar10;
      }
      local_a8 = puVar4;
      if (1 < uVar8) {
        local_a0 = uVar10;
        memset(_Dst,(int)CONCAT71((int7)(uVar5 >> 8),0x90),uVar8 - 1);
        uVar10 = (uVar10 + uVar8) - 1;
        _Dst = puVar4 + uVar10;
      }
      *_Dst = 0x90;
      local_a0 = uVar10 + 1;
    }
    <host_probe[b94139f9089eb1d8]::p64::Batch>::patch
              (local_78,param_4,param_5,param_6,puVar4,local_a0);
    *param_1 = 0xffffffffffffffff;
    lVar7 = local_b0;
    if (local_b0 != 0) {
LAB_140016958:
      __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar4,lVar7,1);
      return;
    }
  }
  else {
    *param_1 = (ulonglong)local_98;
    param_1[1] = (ulonglong)local_90;
    param_1[2] = (ulonglong)local_88;
  }
  if (local_c8 == 0) {
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar2,local_c8,1);
  return;
}

