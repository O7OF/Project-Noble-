// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u8>>::dedup_by::<<alloc[246c2e7857c81348]::vec::Vec<u8>>::dedup::{closure#0}>
// address: 0x140042ce0
// body: available
// range: 0x140042ce0-0x140042d55 inclusive
// range: 0x140042d60-0x140042d83 inclusive
// range: 0x140042d90-0x140042dac inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u8>>::dedup_by::<<alloc[246c2e7857c81348]::vec::Vec<u8>>::dedup::{closure#0}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<u8>>::dedup_by::
<<alloc[246c2e7857c81348]::vec::Vec<u8>>::dedup::_closure_0_>(longlong param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong uVar4;
  char cVar5;
  longlong lVar6;
  
  uVar1 = *(ulonglong *)(param_1 + 0x10);
  if (1 < uVar1) {
    lVar2 = *(longlong *)(param_1 + 8);
    lVar6 = 0;
    do {
      if (*(char *)(lVar2 + 1 + lVar6) == *(char *)(lVar2 + lVar6)) {
        uVar4 = lVar6 + 2;
        lVar3 = lVar6 + 1;
        if (uVar1 <= uVar4) goto LAB_140042d50;
        if (((int)uVar1 - (int)lVar6 & 1U) != 0) {
          cVar5 = *(char *)(lVar2 + 2 + lVar6);
          if (cVar5 != *(char *)(lVar2 + lVar6)) {
            *(char *)(lVar2 + 1 + lVar6) = cVar5;
            lVar3 = lVar6 + 2;
          }
          uVar4 = lVar6 + 3;
        }
        if (uVar1 - 3 != lVar6) goto LAB_140042d69;
        goto LAB_140042d50;
      }
      lVar6 = lVar6 + 1;
    } while (uVar1 - 1 != lVar6);
  }
  return;
LAB_140042d69:
  if (*(char *)(lVar2 + uVar4) == *(char *)(lVar2 + -1 + lVar3)) {
    cVar5 = *(char *)(lVar2 + 1 + uVar4);
    if (cVar5 != *(char *)(lVar2 + -1 + lVar3)) {
LAB_140042da4:
      *(char *)(lVar2 + lVar3) = cVar5;
      lVar3 = lVar3 + 1;
    }
  }
  else {
    *(char *)(lVar2 + lVar3) = *(char *)(lVar2 + uVar4);
    lVar3 = lVar3 + 1;
    cVar5 = *(char *)(lVar2 + 1 + uVar4);
    if (cVar5 != *(char *)(lVar2 + -1 + lVar3)) goto LAB_140042da4;
  }
  uVar4 = uVar4 + 2;
  if (uVar1 == uVar4) {
LAB_140042d50:
    *(longlong *)(param_1 + 0x10) = lVar3;
    return;
  }
  goto LAB_140042d69;
}

