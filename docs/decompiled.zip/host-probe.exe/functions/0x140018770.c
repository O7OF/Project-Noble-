// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::tick
// address: 0x140018770
// body: available
// range: 0x140018770-0x140018947 inclusive
// range: 0x140018950-0x140018d70 inclusive
// range: 0x140018d80-0x1400193c2 inclusive
// range: 0x1400193c8-0x1400194bd inclusive
// range: 0x1400194c1-0x140019515 inclusive
// range: 0x140019520-0x1400196d1 inclusive
// range: 0x1400196e0-0x14001974a inclusive
// range: 0x140019750-0x1400198aa inclusive
// range: 0x1400198b0-0x1400198cf inclusive
// range: 0x1400198d2-0x140019a0b inclusive
// range: 0x140019a0e-0x140019abc inclusive
// range: 0x140019ac0-0x140019adf inclusive
// range: 0x140019ae2-0x140019c3f inclusive
// range: 0x140019c42-0x140019d5e inclusive
// range: 0x140019d60-0x140019e3c inclusive
// range: 0x140019e40-0x140019f20 inclusive
// range: 0x140019f30-0x140019f96 inclusive
// range: 0x140019f9c-0x140019fb9 inclusive
// range: 0x140019fbf-0x14001a04b inclusive
// range: 0x14001a050-0x14001a1fe inclusive
// range: 0x14001a204-0x14001b26d inclusive
// range: 0x14001b270-0x14001b295 inclusive
// range: 0x14001b298-0x14001b9bd inclusive
// range: 0x14001b9c0-0x14001baa1 inclusive
// range: 0x14001bab0-0x14001bb63 inclusive
// range: 0x14001bb70-0x14001bc29 inclusive
// range: 0x14001bc30-0x14001bca3 inclusive
// range: 0x14001bcb0-0x14001bd08 inclusive
// range: 0x14001bd10-0x14001bd7c inclusive
// range: 0x14001bd80-0x14001bdba inclusive
// range: 0x14001bdc0-0x14001bdd1 inclusive
// range: 0x14001bde0-0x14001c3cb inclusive
// range: 0x14001c3d0-0x14001c3f9 inclusive
// range: 0x14001c3fc-0x14001ced9 inclusive
// range: 0x14001cedc-0x14001cff4 inclusive
// range: 0x14001d000-0x14001d289 inclusive
// range: 0x14001d28f-0x14001d31d inclusive
// range: 0x14001d320-0x14001d33f inclusive
// range: 0x14001d342-0x14001d361 inclusive
// range: 0x14001d367-0x14001db97 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400192ad to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400193be to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400194b9 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400198cb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140019a07 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140019adb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140019b03 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140019c3b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140019c88 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140019f92 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140019fb5 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001a1fa to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::tick */

void __rustcall host_probe[b94139f9089eb1d8]::ingame_chat::tick(undefined8 param_1,int param_2)

{
  size_t sVar1;
  char *_Dst;
  int *piVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  code *pcVar5;
  ushort uVar6;
  short sVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  bool bVar11;
  bool bVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 auVar18 [16];
  undefined5 uVar19;
  undefined1 auVar20 [12];
  undefined1 auVar21 [12];
  SIZE_T SVar22;
  int iVar23;
  undefined *puVar24;
  short sVar25;
  char cVar26;
  byte bVar27;
  BOOL BVar28;
  int iVar29;
  undefined4 uVar30;
  longlong lVar31;
  longlong *plVar32;
  undefined1 (*pauVar33) [16];
  ulonglong uVar34;
  char *pcVar35;
  size_t sVar36;
  ulonglong uVar37;
  ulonglong uVar38;
  undefined1 (*pauVar39) [16];
  undefined4 *puVar40;
  void *pvVar41;
  undefined1 (*pauVar42) [16];
  void *pvVar43;
  undefined8 *puVar44;
  undefined2 *puVar45;
  undefined1 *puVar46;
  undefined4 uVar47;
  undefined1 *puVar48;
  longlong lVar49;
  undefined1 uVar50;
  undefined1 *puVar51;
  DWORD dwTlsIndex;
  ulonglong uVar52;
  undefined1 (*pauVar53) [16];
  undefined7 uVar54;
  ulonglong uVar55;
  undefined8 uVar56;
  undefined8 uVar57;
  undefined8 uVar58;
  ushort uVar59;
  undefined1 (*pauVar60) [16];
  undefined1 (*pauVar61) [16];
  uint uVar62;
  longlong lVar63;
  undefined1 (*pauVar64) [16];
  longlong lVar65;
  uint uVar66;
  longlong lVar67;
  undefined1 (*pauVar68) [16];
  bool bVar69;
  byte bVar70;
  undefined1 auVar71 [16];
  undefined1 auVar72 [16];
  undefined1 auVar73 [16];
  undefined1 auVar74 [16];
  undefined1 auVar75 [16];
  undefined1 auVar76 [16];
  undefined1 auVar77 [16];
  char unaff_XMM6_Ba;
  char unaff_XMM6_Bb;
  char unaff_XMM6_Bc;
  char unaff_XMM6_Bd;
  char unaff_XMM6_Be;
  char unaff_XMM6_Bf;
  char unaff_XMM6_Bg;
  char unaff_XMM6_Bh;
  char unaff_XMM6_Bi;
  char unaff_XMM6_Bj;
  char unaff_XMM6_Bk;
  char unaff_XMM6_Bl;
  char unaff_XMM6_Bm;
  char unaff_XMM6_Bn;
  char unaff_XMM6_Bo;
  char unaff_XMM6_Bp;
  undefined1 (*in_stack_fffffffffffffc70) [16];
  undefined1 (*in_stack_fffffffffffffc80) [16];
  undefined4 uVar78;
  undefined8 local_370;
  undefined1 uStack_368;
  undefined7 uStack_367;
  uint uStack_360;
  undefined4 uStack_35c;
  undefined1 (*pauStack_358) [16];
  undefined1 local_349;
  undefined1 (*local_348) [16];
  undefined1 (*local_340) [16];
  int local_334;
  undefined8 local_330;
  undefined1 (*local_328) [16];
  undefined1 (*local_320) [16];
  byte local_318;
  byte bStack_317;
  short sStack_316;
  undefined4 uStack_314;
  undefined8 uStack_310;
  undefined1 uStack_308;
  undefined1 uStack_307;
  short sStack_306;
  undefined4 uStack_304;
  undefined8 uStack_300;
  undefined8 local_2f8;
  undefined8 uStack_2f0;
  undefined4 uStack_2e8;
  undefined4 uStack_2e4;
  uint uStack_2e0;
  undefined4 uStack_2dc;
  undefined1 uStack_2d8;
  undefined7 uStack_2d7;
  undefined1 uStack_2d0;
  undefined8 uStack_2cf;
  undefined8 uStack_2c7;
  undefined8 uStack_2b0;
  undefined8 *local_278;
  undefined1 (*pauStack_270) [16];
  undefined1 (*local_268) [16];
  byte local_258 [2];
  short sStack_256;
  short sStack_254;
  short sStack_252;
  byte bStack_250;
  undefined1 uStack_24f;
  short sStack_24e;
  short sStack_24c;
  undefined1 uStack_24a;
  undefined1 uStack_249;
  undefined1 local_248;
  undefined1 uStack_247;
  short sStack_246;
  short sStack_244;
  undefined1 uStack_242;
  undefined1 uStack_241;
  undefined1 uStack_240;
  undefined1 uStack_23f;
  short sStack_23e;
  short sStack_23c;
  undefined1 uStack_23a;
  undefined1 uStack_239;
  byte local_238;
  undefined7 uStack_237;
  undefined4 uStack_230;
  uint uStack_22c;
  undefined4 uStack_228;
  undefined5 uStack_224;
  undefined3 uStack_21f;
  undefined5 uStack_21c;
  undefined8 local_217;
  undefined8 uStack_20f;
  undefined8 uStack_207;
  undefined8 uStack_1f0;
  undefined8 local_1e8;
  undefined1 (*local_1e0) [16];
  undefined1 (*local_1d8) [16];
  undefined8 *local_1d0;
  undefined1 (*local_1c8) [16];
  undefined1 (*local_1c0) [16];
  longlong local_1b8;
  undefined1 (*local_1b0) [16];
  uint local_1a4;
  undefined1 (*local_1a0) [16];
  undefined4 local_194;
  undefined1 (*local_190) [16];
  undefined1 (*local_188) [16];
  longlong local_180;
  undefined1 (*local_178) [16];
  int local_170;
  longlong local_168;
  undefined1 (*pauStack_160) [16];
  undefined1 (*local_158) [16];
  longlong local_150;
  undefined4 local_144;
  undefined4 local_140;
  undefined1 local_130 [24];
  longlong local_118;
  void *pvStack_110;
  undefined4 *local_108;
  undefined1 local_e0 [160];
  
  if (ENABLED_0_llvm_14435704873730135342 == '\0') {
    return;
  }
  local_334 = param_2;
  local_1c0 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
  pauVar39 = (undefined1 (*) [16])CONCAT71((int7)((ulonglong)param_1 >> 8),1);
  LOCK();
  bVar69 = STATE == '\0';
  if (bVar69) {
    STATE = '\x01';
  }
  UNLOCK();
  local_178 = local_1c0;
  local_170 = local_334;
  if (!bVar69) {
    pauVar39 = (undefined1 (*) [16])&STATE;
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&STATE);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    local_1a4 = 0;
    pauVar61 = DAT_140699450;
  }
  else {
    local_1a4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_1a4 = local_1a4 ^ 1;
    pauVar61 = DAT_140699450;
  }
  DAT_140699450 = pauVar61;
  if (DAT_140699029 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    local_318 = 0x28;
    bStack_317 = 0x90;
    sStack_316 = 0x4069;
    uStack_314 = 1;
    uStack_310._1_3_ = (undefined3)((uint)uStack_310 >> 8);
    uStack_310._0_4_ = CONCAT31(uStack_310._1_3_,(char)local_1a4);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_318,
               &anon_d5c34e88a06ee720b116585eb143da4b_137_llvm_14435704873730135342,&DAT_1406a1a80);
    goto LAB_14001db96;
  }
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  if (DAT_140699030 == -1) {
LAB_140018840:
    if (((char)local_1a4 == '\0') &&
       (((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0 &&
        (cVar26 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar26 == '\0'
        )))) {
      DAT_140699029 = '\x01';
    }
    cVar26 = STATE;
    LOCK();
    STATE = '\0';
    UNLOCK();
    if (cVar26 != '\x02') {
      STATE = '\0';
      return;
    }
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&STATE);
    return;
  }
  if (DAT_140699458 != -1) {
    pauVar39 = (undefined1 (*) [16])&local_178;
    lVar31 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(pauVar39);
    if ((lVar31 == 0) && ((uint)pauVar61 < 50000000)) goto LAB_140018840;
  }
  lVar31 = REACH_BASE;
  DAT_140699450 = local_1c0;
  DAT_140699458 = local_334;
  if (DAT_1406993e8 == DAT_1406993f0) {
    pauVar61 = (undefined1 (*) [16])&DAT_00000008;
    if ((REACH_BASE == 0) || (DAT_140699990 != 0)) {
      pauVar33 = (undefined1 (*) [16])0x0;
      local_340 = (undefined1 (*) [16])0x0;
      pauVar42 = DAT_1406994a0;
      pauVar60 = DAT_1406994a8;
      lVar31 = DAT_1406994b0;
      lVar49 = DAT_1406994b8;
    }
    else {
      net::peer_ids(&local_318);
      local_1d8 = (undefined1 (*) [16])
                  CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)));
      local_1d0 = (undefined8 *)CONCAT44(uStack_310._4_4_,(uint)uStack_310);
      lVar49 = CONCAT44(uStack_304,CONCAT22(sStack_306,CONCAT11(uStack_307,uStack_308)));
      puVar44 = local_1d0;
      if (lVar49 != 0) {
        lVar65 = 0;
        do {
          uVar56 = *(undefined8 *)((longlong)local_1d0 + lVar65);
          local_318 = 2;
          bStack_317 = 0;
          cVar26 = net::is_blocked(uVar56,&local_318);
          if (cVar26 == '\0') {
            *puVar44 = uVar56;
            puVar44 = puVar44 + 1;
          }
          lVar65 = lVar65 + 8;
        } while (lVar49 << 3 != lVar65);
      }
      local_1c8 = (undefined1 (*) [16])((ulonglong)((longlong)puVar44 - (longlong)local_1d0) >> 3);
      if (dedicated::DEDICATED_0_llvm_15918893398050881851 == '\0') {
LAB_1400189c9:
        pauVar39 = local_1c8;
        uVar56 = DAT_1406998e0;
        if (DAT_140699990 != 0) {
          uVar56 = 0;
        }
        if (local_1c8 == local_1d8) {
          <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<reach_directory[4b72b9694f6c3c08]::rendezvous::State>>>>
          ::grow_one(&local_1d8);
        }
        local_1d0[(longlong)pauVar39] = uVar56;
        local_1c8 = (undefined1 (*) [16])(*pauVar39 + 1);
      }
      else {
        if (dedicated::no_local_user::KEEP != 0) {
          <std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<bool>>::initialize::
          <<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<bool>>::get_or_init<host_probe[b94139f9089eb1d8]::dedicated::no_local_user::_closure_0_>::_closure_0_,_>
                    (&dedicated::no_local_user::KEEP);
        }
        if (DAT_14069af18 != '\0') goto LAB_1400189c9;
      }
      local_318 = 0;
      bStack_317 = 0;
      sStack_316 = 0;
      uStack_314 = 0;
      BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,(LPCVOID)(lVar31 + 0x2a1fe08),local_258,
                                 8,(SIZE_T *)&local_318);
      lVar49 = CONCAT26(sStack_252,
                        CONCAT24(sStack_254,CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))
                                ));
      if ((lVar49 != 0 && BVar28 != 0) &&
          CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 8) {
        local_318 = 0;
        bStack_317 = 0;
        sStack_316 = 0;
        uStack_314 = 0;
        BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,(LPCVOID)(lVar49 + 0x60ef8),local_258,
                                   4,(SIZE_T *)&local_318);
        if (((BVar28 != 0) &&
            (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 4)) &&
           (CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0])) != 0)) goto LAB_140018b68;
      }
      local_318 = 0;
      bStack_317 = 0;
      sStack_316 = 0;
      uStack_314 = 0;
      uVar56 = 0xffffffffffffffff;
      BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,(LPCVOID)(lVar31 + 0x2a1fe18),local_258,
                                 8,(SIZE_T *)&local_318);
      bVar69 = CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 8;
      pauVar39 = (undefined1 (*) [16])CONCAT71((int7)((ulonglong)uVar56 >> 8),bVar69);
      lVar49 = CONCAT26(sStack_252,
                        CONCAT24(sStack_254,CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))
                                ));
      if ((lVar49 != 0 && BVar28 != 0) && bVar69) {
        local_318 = 0;
        bStack_317 = 0;
        sStack_316 = 0;
        uStack_314 = 0;
        pauVar39 = (undefined1 (*) [16])0xffffffffffffffff;
        BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,(LPCVOID)(lVar49 + 0x60ef8),local_258,
                                   4,(SIZE_T *)&local_318);
        if (((BVar28 != 0) &&
            (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 4)) &&
           (CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0])) != 0)) {
LAB_140018b68:
          if (pbx::RELOCATED_0_llvm_10439611301029776152 == '\0') {
            local_318 = 0;
            bStack_317 = 0;
            sStack_316 = 0;
            uStack_314 = 0;
            BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,(LPCVOID)(lVar49 + 0x2b64),
                                       local_258,4,(SIZE_T *)&local_318);
            uVar38 = (ulonglong)CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]));
            if (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) != 4) {
              uVar38 = 0;
            }
            if (BVar28 == 0) {
              uVar38 = 0;
            }
          }
          else {
            local_318 = 0;
            bStack_317 = 0;
            sStack_316 = 0;
            uStack_314 = 0;
            BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,
                                       (LPCVOID)(pbx::DELTA_0_llvm_10439611301029776152 + lVar49 +
                                                0x1730),local_258,8,(SIZE_T *)&local_318);
            uVar55 = 0;
            if (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 8) {
              uVar55 = CONCAT26(sStack_252,
                                CONCAT24(sStack_254,
                                         CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))));
            }
            uVar38 = 0;
            if (BVar28 != 0) {
              uVar38 = uVar55;
            }
          }
          if (((capacity::MACHINES_0_llvm_16945119018599968161 == (undefined1 (*) [16])&DAT_00000040
               ) && (capacity::PLAYERS_0_llvm_16945119018599968161 == 0x40)) &&
             (pbx::WIDE_0_llvm_10439611301029776152 != '\0')) {
            local_318 = 0;
            bStack_317 = 0;
            sStack_316 = 0;
            uStack_314 = 0;
            BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,(LPCVOID)(lVar49 + 0x40e0),
                                       local_258,8,(SIZE_T *)&local_318);
            pauVar39 = (undefined1 (*) [16])0x0;
            if (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 8) {
              pauVar39 = (undefined1 (*) [16])
                         CONCAT26(sStack_252,
                                  CONCAT24(sStack_254,
                                           CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0])))
                                 );
            }
            local_340 = (undefined1 (*) [16])0x0;
            if (BVar28 != 0) {
              local_340 = pauVar39;
            }
          }
          else {
            local_318 = 0;
            bStack_317 = 0;
            sStack_316 = 0;
            uStack_314 = 0;
            BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,(LPCVOID)(lVar49 + 0x5c),local_258
                                       ,4,(SIZE_T *)&local_318);
            pauVar39 = (undefined1 (*) [16])0x0;
            local_340 = (undefined1 (*) [16])
                        (ulonglong)CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]));
            if (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) != 4) {
              local_340 = pauVar39;
            }
            if (BVar28 == 0) {
              local_340 = pauVar39;
            }
          }
          pauVar42 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310);
          local_330 = (undefined1 (*) [16])0x0;
          local_328 = (undefined1 (*) [16])&DAT_00000008;
          local_320 = (undefined1 (*) [16])0x0;
          local_1b0 = (undefined1 (*) [16])(lVar49 + 0x60);
          local_348 = (undefined1 (*) [16])(lVar49 + 0x1740);
          uVar55 = 0;
LAB_140018d8d:
          if ((uVar38 >> (uVar55 & 0x3f) & 1) != 0) {
            if (pbx::RELOCATED_0_llvm_10439611301029776152 == '\0') {
              puVar51 = (undefined1 *)(uVar55 * 0xb0 + lVar49 + 0x2b68);
            }
            else {
              puVar51 = (undefined1 *)
                        ((longlong)local_348[uVar55 * 0xb] + pbx::DELTA_0_llvm_10439611301029776152)
              ;
            }
            local_318 = 0;
            bStack_317 = 0;
            sStack_316 = 0;
            uStack_314 = 0;
            uVar34 = 0xffffffffffffffff;
            uStack_310 = pauVar42;
            BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,puVar51 + 0xc,local_258,4,
                                       (SIZE_T *)&local_318);
            pauVar39 = (undefined1 (*) [16])(uVar34 & 0xffffffffffffff00);
            uVar66 = CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]));
            pauVar42 = uStack_310;
            if ((((CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) != 4 ||
                  BVar28 == 0) || sStack_256 < 0) ||
                (pauVar39 = (undefined1 (*) [16])(ulonglong)uVar66,
                capacity::MACHINES_0_llvm_16945119018599968161 <= pauVar39)) ||
               (((ulonglong)local_340 >> ((ulonglong)uVar66 & 0x3f) & 1) == 0)) goto LAB_140018d80;
            puVar44 = (undefined8 *)((longlong)pauVar39 * 0x158 + (longlong)local_1b0);
            if (0x2f < uVar66) {
              puVar44 = (undefined8 *)
                        ((longlong)puVar44 + pbx::DELTA_0_llvm_10439611301029776152 + 0x260);
            }
            local_318 = 0;
            bStack_317 = 0;
            sStack_316 = 0;
            uStack_314 = 0;
            BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,puVar44,local_258,8,
                                       (SIZE_T *)&local_318);
            uVar56 = 0;
            if (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 8) {
              uVar56 = CONCAT26(sStack_252,
                                CONCAT24(sStack_254,
                                         CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))));
            }
            if (BVar28 == 0) {
              uVar56 = 0;
            }
            local_318 = 0;
            bStack_317 = 0;
            sStack_316 = 0;
            uStack_314 = 0;
            BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,puVar44 + 0x27,local_258,8,
                                       (SIZE_T *)&local_318);
            uVar57 = 0;
            if (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 8) {
              uVar57 = CONCAT26(sStack_252,
                                CONCAT24(sStack_254,
                                         CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))));
            }
            if (BVar28 == 0) {
              uVar57 = 0;
            }
            uStack_310._0_4_ = 0;
            uStack_310._4_4_ = 0;
            uStack_308 = 2;
            uStack_307 = 0;
            sStack_306 = 0;
            uStack_304 = 0;
            uStack_300._0_4_ = (undefined4)uVar56;
            uStack_300._4_4_ = (undefined4)((ulonglong)uVar56 >> 0x20);
            local_2f8._0_4_ = (uint)uVar57;
            local_2f8._4_4_ = (undefined4)((ulonglong)uVar57 >> 0x20);
            local_318 = (byte)&local_1d8;
            bStack_317 = (byte)((ulonglong)&local_1d8 >> 8);
            sStack_316 = (short)((ulonglong)&local_1d8 >> 0x10);
            uStack_314 = (undefined4)((ulonglong)&local_1d8 >> 0x20);
            pauVar39 = (undefined1 (*) [16])&local_278;
            <alloc[246c2e7857c81348]::vec::Vec<u64>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<u64,core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::array::iter::IntoIter<u64,2usize>,host_probe[b94139f9089eb1d8]::ingame_chat::engine_roster::{closure#2}>>>
            ::from_iter(pauVar39);
            pauVar60 = local_268;
            pauVar33 = pauStack_270;
            pauVar42 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310);
            pauVar61 = local_268;
            if ((undefined1 (*) [16])0x1 < local_268) {
              pauVar61 = pauVar60;
              if ((undefined1 (*) [16])&DAT_00000014 < local_268) {
                core[505b25137b8ba7f]::slice::sort::unstable::ipnsort::
                <usize,<usize_as_core[505b25137b8ba7f]::cmp::PartialOrd>::lt>
                          (pauStack_270,local_268,&local_349);
LAB_1400191a9:
                puVar48 = (undefined1 *)0x0;
                do {
                  pauVar39 = *(undefined1 (**) [16])((longlong)*pauVar33 + (puVar48 + 1) * 8);
                  if (pauVar39 == *(undefined1 (**) [16])((longlong)*pauVar33 + puVar48 * 8)) {
                    pauVar39 = (undefined1 (*) [16])(puVar48 + 2);
                    local_268 = (undefined1 (*) [16])(puVar48 + 1);
                    pauVar61 = local_268;
                    if (pauVar39 < pauVar60) {
                      if (((int)pauVar60 - (int)puVar48 & 1U) != 0) {
                        if (*(longlong *)((longlong)pauVar33[1] + puVar48 * 8) !=
                            *(longlong *)((longlong)*pauVar33 + puVar48 * 8)) {
                          *(longlong *)((longlong)*pauVar33 + (puVar48 + 1) * 8) =
                               *(longlong *)((longlong)pauVar33[1] + puVar48 * 8);
                          local_268 = (undefined1 (*) [16])(puVar48 + 2);
                        }
                        pauVar39 = (undefined1 (*) [16])(puVar48 + 3);
                      }
                      pauVar61 = local_268;
                      if ((undefined1 *)((longlong)pauVar60[-1] + 0xd) != puVar48)
                      goto LAB_140019435;
                    }
                    break;
                  }
                  puVar48 = puVar48 + 1;
                } while ((undefined1 *)((longlong)pauVar60[-1] + 0xf) != puVar48);
              }
              else {
                pauVar39 = (undefined1 (*) [16])((longlong)*pauStack_270 + 8);
                lVar31 = 0;
                do {
                  uVar34 = *(ulonglong *)*pauVar39;
                  if (uVar34 < *(ulonglong *)((longlong)pauVar39[-1] + 8)) {
                    *(ulonglong *)*pauVar39 = *(ulonglong *)((longlong)pauVar39[-1] + 8);
                    lVar65 = lVar31;
                    pauVar42 = pauStack_270;
                    if ((undefined1 (*) [16])((longlong)pauVar39[-1] + 8) != pauStack_270) {
                      do {
                        uVar52 = *(ulonglong *)((longlong)pauStack_270[-1] + lVar65 + 8);
                        if (uVar52 <= uVar34) {
                          pauVar42 = (undefined1 (*) [16])((longlong)*pauStack_270 + lVar65);
                          break;
                        }
                        *(ulonglong *)((longlong)*pauStack_270 + lVar65) = uVar52;
                        lVar65 = lVar65 + -8;
                      } while (lVar65 != 0);
                    }
                    *(ulonglong *)*pauVar42 = uVar34;
                  }
                  pauVar39 = (undefined1 (*) [16])((longlong)*pauVar39 + 8);
                  lVar31 = lVar31 + 8;
                } while (pauVar39 != (undefined1 (*) [16])((longlong)*pauStack_270 + local_268 * 8))
                ;
                if ((undefined1 (*) [16])0x1 < local_268) goto LAB_1400191a9;
              }
              goto LAB_14001940d;
            }
            goto joined_r0x000140019421;
          }
          goto LAB_140018d80;
        }
      }
      pauVar42 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310);
      pauVar60 = (undefined1 (*) [16])0x0;
      pauVar33 = (undefined1 (*) [16])0x0;
      pauVar61 = (undefined1 (*) [16])&DAT_00000008;
LAB_1400194a2:
      uStack_310 = pauVar42;
      if (local_1d8 != (undefined1 (*) [16])0x0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_1d0,(longlong)local_1d8 << 3,8);
        return;
      }
      local_1d8 = (undefined1 (*) [16])0x0;
      local_340 = pauVar60;
      pauVar42 = DAT_1406994a0;
      pauVar60 = DAT_1406994a8;
      lVar31 = DAT_1406994b0;
      lVar49 = DAT_1406994b8;
    }
    DAT_1406994a0 = pauVar42;
    DAT_1406994a8 = pauVar60;
    DAT_1406994b0 = lVar31;
    DAT_1406994b8 = lVar49;
    if (lVar49 != 0) {
      auVar71 = *pauVar42;
      uVar66 = ~(uint)(ushort)((ushort)(SUB161(auVar71 >> 7,0) & 1) |
                               (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                               (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                               (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                               (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                               (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                               (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                               (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                               (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                               (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                               (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                               (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                               (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                               (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                               (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                              (ushort)(byte)(auVar71[0xf] >> 7) << 0xf);
      pauVar64 = pauVar42 + 1;
      pauVar53 = pauVar42;
      lVar65 = lVar49;
      do {
        uVar59 = (ushort)uVar66;
        while (uVar59 == 0) {
          auVar71 = *pauVar64;
          pauVar53 = pauVar53 + -8;
          pauVar64 = pauVar64 + 1;
          uVar59 = ((ushort)(SUB161(auVar71 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                   (ushort)(byte)(auVar71[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar66 = (uint)uVar59;
        }
        iVar29 = 0;
        for (uVar62 = uVar66; (uVar62 & 1) == 0; uVar62 = uVar62 >> 1 | 0x80000000) {
          iVar29 = iVar29 + 1;
        }
        lVar67 = (longlong)pauVar53 - (ulonglong)(uint)(iVar29 << 3);
        if (pauVar33 != (undefined1 (*) [16])0x0) {
          lVar63 = 0;
          do {
            if (*(longlong *)((longlong)pauVar61[1] + lVar63 + 8) == *(longlong *)(lVar67 + -8))
            goto LAB_140019533;
            lVar63 = lVar63 + 0x28;
          } while ((longlong)pauVar33 * 0x28 != lVar63);
        }
        lVar67 = (longlong)pauVar42 - lVar67 >> 3;
        uVar38 = lVar67 - 0x10U & (ulonglong)pauVar60;
        pcVar35 = (char *)((longlong)*pauVar42 + uVar38);
        auVar71[0] = -(*pcVar35 == -1);
        auVar71[1] = -(pcVar35[1] == -1);
        auVar71[2] = -(pcVar35[2] == -1);
        auVar71[3] = -(pcVar35[3] == -1);
        auVar71[4] = -(pcVar35[4] == -1);
        auVar71[5] = -(pcVar35[5] == -1);
        auVar71[6] = -(pcVar35[6] == -1);
        auVar71[7] = -(pcVar35[7] == -1);
        auVar71[8] = -(pcVar35[8] == -1);
        auVar71[9] = -(pcVar35[9] == -1);
        auVar71[10] = -(pcVar35[10] == -1);
        auVar71[0xb] = -(pcVar35[0xb] == -1);
        auVar71[0xc] = -(pcVar35[0xc] == -1);
        auVar71[0xd] = -(pcVar35[0xd] == -1);
        auVar71[0xe] = -(pcVar35[0xe] == -1);
        auVar71[0xf] = -(pcVar35[0xf] == -1);
        uVar6 = (ushort)(SUB161(auVar71 >> 7,0) & 1) | (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe | (ushort)(auVar71[0xf] >> 7) << 0xf;
        pcVar35 = (char *)((longlong)*pauVar42 + lVar67);
        auVar72[0] = -(*pcVar35 == -1);
        auVar72[1] = -(pcVar35[1] == -1);
        auVar72[2] = -(pcVar35[2] == -1);
        auVar72[3] = -(pcVar35[3] == -1);
        auVar72[4] = -(pcVar35[4] == -1);
        auVar72[5] = -(pcVar35[5] == -1);
        auVar72[6] = -(pcVar35[6] == -1);
        auVar72[7] = -(pcVar35[7] == -1);
        auVar72[8] = -(pcVar35[8] == -1);
        auVar72[9] = -(pcVar35[9] == -1);
        auVar72[10] = -(pcVar35[10] == -1);
        auVar72[0xb] = -(pcVar35[0xb] == -1);
        auVar72[0xc] = -(pcVar35[0xc] == -1);
        auVar72[0xd] = -(pcVar35[0xd] == -1);
        auVar72[0xe] = -(pcVar35[0xe] == -1);
        auVar72[0xf] = -(pcVar35[0xf] == -1);
        uVar59 = 0xf;
        if (uVar6 != 0) {
          for (; uVar6 >> uVar59 == 0; uVar59 = uVar59 - 1) {
          }
        }
        sVar7 = 0;
        for (uVar62 = (ushort)((ushort)(SUB161(auVar72 >> 7,0) & 1) |
                               (ushort)(SUB161(auVar72 >> 0xf,0) & 1) << 1 |
                               (ushort)(SUB161(auVar72 >> 0x17,0) & 1) << 2 |
                               (ushort)(SUB161(auVar72 >> 0x1f,0) & 1) << 3 |
                               (ushort)(SUB161(auVar72 >> 0x27,0) & 1) << 4 |
                               (ushort)(SUB161(auVar72 >> 0x2f,0) & 1) << 5 |
                               (ushort)(SUB161(auVar72 >> 0x37,0) & 1) << 6 |
                               (ushort)(SUB161(auVar72 >> 0x3f,0) & 1) << 7 |
                               (ushort)(SUB161(auVar72 >> 0x47,0) & 1) << 8 |
                               (ushort)(SUB161(auVar72 >> 0x4f,0) & 1) << 9 |
                               (ushort)(SUB161(auVar72 >> 0x57,0) & 1) << 10 |
                               (ushort)(SUB161(auVar72 >> 0x5f,0) & 1) << 0xb |
                               (ushort)(SUB161(auVar72 >> 0x67,0) & 1) << 0xc |
                               (ushort)(SUB161(auVar72 >> 0x6f,0) & 1) << 0xd |
                               (ushort)(SUB161(auVar72 >> 0x77,0) & 1) << 0xe |
                              (ushort)(auVar72[0xf] >> 7) << 0xf) | 0x10000; (uVar62 & 1) == 0;
            uVar62 = uVar62 >> 1 | 0x80000000) {
          sVar7 = sVar7 + 1;
        }
        uVar50 = 0x80;
        if ((ushort)(sVar7 + (uVar59 ^ 0xf)) < 0x10) {
          lVar31 = lVar31 + 1;
          uVar50 = 0xff;
          DAT_1406994b0 = lVar31;
        }
        *(undefined1 *)((longlong)*pauVar42 + lVar67) = uVar50;
        *(undefined1 *)((longlong)pauVar42[1] + uVar38) = uVar50;
        lVar49 = lVar49 + -1;
        DAT_1406994b8 = lVar49;
LAB_140019533:
        uVar66 = uVar66 - 1 & uVar66;
        lVar65 = lVar65 + -1;
        pauVar39 = pauVar42;
        local_348 = pauVar60;
      } while (lVar65 != 0);
    }
    puVar24 = 
    __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
    ;
    pauVar42 = DAT_1406993e8;
    local_370._0_4_ = (int)local_340;
    local_370._4_4_ = (undefined4)((ulonglong)local_340 >> 0x20);
    uStack_368 = SUB81(pauVar61,0);
    uVar50 = uStack_368;
    uStack_367 = (undefined7)((ulonglong)pauVar61 >> 8);
    uStack_360 = (uint)pauVar33;
    uStack_35c = (undefined4)((ulonglong)pauVar33 >> 0x20);
    if (DAT_1406993e8 == DAT_1406993f0) {
      if (*(longlong *)
           __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
          != 0) {
        std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
      }
      if (*(int *)(puVar24 + 0x18) == 0) {
        dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                               (
                               __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                               );
        plVar32 = TlsGetValue(dwTlsIndex);
      }
      else {
        dwTlsIndex = *(int *)(puVar24 + 0x18) - 1;
        plVar32 = TlsGetValue(dwTlsIndex);
      }
      if (plVar32 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
        plVar32 = (longlong *)
                  <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                  ::try_initialize::
                  <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                            (dwTlsIndex,plVar32,0);
      }
      local_348 = pauVar42;
      if (plVar32 == (longlong *)0x0) {
        std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                  (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
        goto LAB_14001db96;
      }
      lVar31 = *plVar32;
      *plVar32 = *plVar32 + 1;
      local_248 = 0;
      uStack_247 = 0;
      sStack_246 = 0;
      sStack_244 = 0;
      uStack_242 = 0;
      uStack_241 = 0;
      uStack_240 = 0;
      uStack_23f = 0;
      sStack_23e = 0;
      sStack_23c = 0;
      uStack_23a = 0;
      uStack_239 = 0;
      local_258[0] = (byte)PTR_DAT_1406a0550;
      local_258[1] = PTR_DAT_1406a0550._1_1_;
      sStack_256 = PTR_DAT_1406a0550._2_2_;
      sStack_254 = PTR_DAT_1406a0550._4_2_;
      sStack_252 = PTR_DAT_1406a0550._6_2_;
      bStack_250 = PTR_DAT_1406a0550._8_1_;
      uStack_24f = PTR_DAT_1406a0550._9_1_;
      sStack_24e = PTR_DAT_1406a0550._10_2_;
      sStack_24c = PTR_DAT_1406a0550._12_2_;
      uStack_24a = PTR_DAT_1406a0550._14_1_;
      uStack_249 = PTR_DAT_1406a0550._15_1_;
      local_238 = (byte)lVar31;
      uStack_237 = (undefined7)((ulonglong)lVar31 >> 8);
      uStack_230 = (undefined4)plVar32[1];
      uStack_22c = (uint)((ulonglong)plVar32[1] >> 0x20);
      pauVar42 = (undefined1 (*) [16])((longlong)pauVar61 + (longlong)pauVar33 * 0x28);
      if (pauVar33 != (undefined1 (*) [16])0x0) {
        iVar29 = -(uint)(CONCAT13(unaff_XMM6_Bd,
                                  CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))) ==
                        CONCAT13(unaff_XMM6_Bd,
                                 CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))));
        unaff_XMM6_Ba = (char)iVar29;
        unaff_XMM6_Bb = (char)((uint)iVar29 >> 8);
        unaff_XMM6_Bc = (char)((uint)iVar29 >> 0x10);
        unaff_XMM6_Bd = (char)((uint)iVar29 >> 0x18);
        iVar29 = -(uint)(CONCAT13(unaff_XMM6_Bh,
                                  CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))) ==
                        CONCAT13(unaff_XMM6_Bh,
                                 CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))));
        unaff_XMM6_Be = (char)iVar29;
        unaff_XMM6_Bf = (char)((uint)iVar29 >> 8);
        unaff_XMM6_Bg = (char)((uint)iVar29 >> 0x10);
        unaff_XMM6_Bh = (char)((uint)iVar29 >> 0x18);
        iVar29 = -(uint)(CONCAT13(unaff_XMM6_Bl,
                                  CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))) ==
                        CONCAT13(unaff_XMM6_Bl,
                                 CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))));
        unaff_XMM6_Bi = (char)iVar29;
        unaff_XMM6_Bj = (char)((uint)iVar29 >> 8);
        unaff_XMM6_Bk = (char)((uint)iVar29 >> 0x10);
        unaff_XMM6_Bl = (char)((uint)iVar29 >> 0x18);
        iVar29 = -(uint)(CONCAT13(unaff_XMM6_Bp,
                                  CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))) ==
                        CONCAT13(unaff_XMM6_Bp,
                                 CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))));
        unaff_XMM6_Bm = (char)iVar29;
        unaff_XMM6_Bn = (char)((uint)iVar29 >> 8);
        unaff_XMM6_Bo = (char)((uint)iVar29 >> 0x10);
        unaff_XMM6_Bp = (char)((uint)iVar29 >> 0x18);
        pauVar39 = pauVar61;
        do {
          lVar31 = *(longlong *)((longlong)pauVar39[1] + 8);
          pauVar39 = (undefined1 (*) [16])((longlong)pauVar39[2] + 8);
          local_318 = (byte)lVar31;
          bStack_317 = (byte)((ulonglong)lVar31 >> 8);
          sStack_316 = (short)((ulonglong)lVar31 >> 0x10);
          uStack_314 = (undefined4)((ulonglong)lVar31 >> 0x20);
          uVar34 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                   ::hash_one::<&usize>(&local_238);
          pauVar33 = (undefined1 (*) [16])
                     CONCAT26(sStack_252,
                              CONCAT24(sStack_254,
                                       CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))));
          uVar38 = CONCAT17(uStack_249,
                            CONCAT16(uStack_24a,
                                     CONCAT24(sStack_24c,
                                              CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250))))
                           );
          bVar27 = (byte)(uVar34 >> 0x38);
          bVar70 = bVar27 >> 1;
          auVar71 = ZEXT216(CONCAT11(bVar70,bVar70));
          auVar71 = pshuflw(auVar71,auVar71,0);
          lVar49 = 0;
          uVar55 = uVar34;
          while( true ) {
            uVar55 = uVar55 & uVar38;
            auVar72 = *(undefined1 (*) [16])(*pauVar33 + uVar55);
            auVar76[0] = -(auVar72[0] == auVar71[0]);
            auVar76[1] = -(auVar72[1] == auVar71[1]);
            auVar76[2] = -(auVar72[2] == auVar71[2]);
            auVar76[3] = -(auVar72[3] == auVar71[3]);
            auVar76[4] = -(auVar72[4] == auVar71[4]);
            auVar76[5] = -(auVar72[5] == auVar71[5]);
            auVar76[6] = -(auVar72[6] == auVar71[6]);
            auVar76[7] = -(auVar72[7] == auVar71[7]);
            auVar76[8] = -(auVar72[8] == auVar71[0]);
            auVar76[9] = -(auVar72[9] == auVar71[1]);
            auVar76[10] = -(auVar72[10] == auVar71[2]);
            auVar76[0xb] = -(auVar72[0xb] == auVar71[3]);
            auVar76[0xc] = -(auVar72[0xc] == auVar71[4]);
            auVar76[0xd] = -(auVar72[0xd] == auVar71[5]);
            auVar76[0xe] = -(auVar72[0xe] == auVar71[6]);
            auVar76[0xf] = -(auVar72[0xf] == auVar71[7]);
            uVar59 = (ushort)(SUB161(auVar76 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar76 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar76 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar76 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar76 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar76 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar76 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar76 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar76 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar76 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar76 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar76 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar76 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar76 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar76 >> 0x77,0) & 1) << 0xe |
                     (ushort)(auVar76[0xf] >> 7) << 0xf;
            uVar66 = (uint)uVar59;
            while (uVar59 != 0) {
              uVar62 = 0;
              for (uVar8 = uVar66; (uVar8 & 1) == 0; uVar8 = uVar8 >> 1 | 0x80000000) {
                uVar62 = uVar62 + 1;
              }
              pauVar60 = pauVar33 + -(uVar62 + uVar55 & uVar38);
              if (*(longlong *)pauVar60[-1] == lVar31) goto LAB_1400197dc;
              uVar59 = (ushort)(uVar66 - 1) & (ushort)uVar66;
              uVar66 = CONCAT22((short)(uVar66 - 1 >> 0x10),uVar59);
            }
            auVar73[0] = -(auVar72[0] == unaff_XMM6_Ba);
            auVar73[1] = -(auVar72[1] == unaff_XMM6_Bb);
            auVar73[2] = -(auVar72[2] == unaff_XMM6_Bc);
            auVar73[3] = -(auVar72[3] == unaff_XMM6_Bd);
            auVar73[4] = -(auVar72[4] == unaff_XMM6_Be);
            auVar73[5] = -(auVar72[5] == unaff_XMM6_Bf);
            auVar73[6] = -(auVar72[6] == unaff_XMM6_Bg);
            auVar73[7] = -(auVar72[7] == unaff_XMM6_Bh);
            auVar73[8] = -(auVar72[8] == unaff_XMM6_Bi);
            auVar73[9] = -(auVar72[9] == unaff_XMM6_Bj);
            auVar73[10] = -(auVar72[10] == unaff_XMM6_Bk);
            auVar73[0xb] = -(auVar72[0xb] == unaff_XMM6_Bl);
            auVar73[0xc] = -(auVar72[0xc] == unaff_XMM6_Bm);
            auVar73[0xd] = -(auVar72[0xd] == unaff_XMM6_Bn);
            auVar73[0xe] = -(auVar72[0xe] == unaff_XMM6_Bo);
            auVar73[0xf] = -(auVar72[0xf] == unaff_XMM6_Bp);
            if ((((((((((((((((SUB161(auVar73 >> 7,0) & 1) != 0 ||
                             (SUB161(auVar73 >> 0xf,0) & 1) != 0) ||
                            (SUB161(auVar73 >> 0x17,0) & 1) != 0) ||
                           (SUB161(auVar73 >> 0x1f,0) & 1) != 0) ||
                          (SUB161(auVar73 >> 0x27,0) & 1) != 0) ||
                         (SUB161(auVar73 >> 0x2f,0) & 1) != 0) ||
                        (SUB161(auVar73 >> 0x37,0) & 1) != 0) ||
                       (SUB161(auVar73 >> 0x3f,0) & 1) != 0) || (SUB161(auVar73 >> 0x47,0) & 1) != 0
                      ) || (SUB161(auVar73 >> 0x4f,0) & 1) != 0) ||
                    (SUB161(auVar73 >> 0x57,0) & 1) != 0) || (SUB161(auVar73 >> 0x5f,0) & 1) != 0)
                  || (SUB161(auVar73 >> 0x67,0) & 1) != 0) || (SUB161(auVar73 >> 0x6f,0) & 1) != 0)
                || (SUB161(auVar73 >> 0x77,0) & 1) != 0) || auVar73[0xf] < '\0') break;
            uVar55 = uVar55 + lVar49 + 0x10;
            lVar49 = lVar49 + 0x10;
          }
          if (CONCAT17(uStack_241,
                       CONCAT16(uStack_242,
                                CONCAT24(sStack_244,
                                         CONCAT22(sStack_246,CONCAT11(uStack_247,local_248))))) == 0
             ) {
            <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,i32)>>::reserve_rehash::
            <hashbrown[ad6d4a1843b2832d]::map::make_hasher<u64,i32,std[3bf9d48a0c3997f0]::hash::random::RandomState>::_closure_0_>
                      (local_258,1,&local_238);
            pauVar33 = (undefined1 (*) [16])
                       CONCAT26(sStack_252,
                                CONCAT24(sStack_254,
                                         CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))));
            uVar38 = CONCAT17(uStack_249,
                              CONCAT16(uStack_24a,
                                       CONCAT24(sStack_24c,
                                                CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250))
                                               )));
          }
          uVar34 = uVar34 & uVar38;
          auVar71 = *(undefined1 (*) [16])(*pauVar33 + uVar34);
          uVar59 = (ushort)(SUB161(auVar71 >> 7,0) & 1) |
                   (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                   (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                   (ushort)(byte)(auVar71[0xf] >> 7) << 0xf;
          uVar66 = (uint)uVar59;
          if (uVar59 == 0) {
            lVar49 = 0x10;
            do {
              uVar34 = uVar34 + lVar49 & uVar38;
              auVar71 = *(undefined1 (*) [16])(*pauVar33 + uVar34);
              lVar49 = lVar49 + 0x10;
              uVar66 = (uint)(ushort)((ushort)(SUB161(auVar71 >> 7,0) & 1) |
                                      (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                                      (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                                      (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                                      (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                                      (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                                      (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                                      (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                                      (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                                      (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                                      (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                                      (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                                      (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                                      (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                                      (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                                     (ushort)(byte)(auVar71[0xf] >> 7) << 0xf);
            } while (uVar66 == 0);
          }
          uVar62 = 0;
          for (; (uVar66 & 1) == 0; uVar66 = uVar66 >> 1 | 0x80000000) {
            uVar62 = uVar62 + 1;
          }
          uVar55 = uVar62 + uVar34 & uVar38;
          bVar70 = (*pauVar33)[uVar55];
          if (-1 < (char)bVar70) {
            auVar71 = *pauVar33;
            uVar66 = 0;
            for (uVar62 = (uint)(ushort)((ushort)(SUB161(auVar71 >> 7,0) & 1) |
                                         (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                                         (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                                         (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                                         (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                                         (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                                         (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                                         (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                                         (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                                         (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                                         (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                                         (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                                         (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                                         (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                                         (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                                        (ushort)(byte)(auVar71[0xf] >> 7) << 0xf); (uVar62 & 1) == 0
                ; uVar62 = uVar62 >> 1 | 0x80000000) {
              uVar66 = uVar66 + 1;
            }
            uVar55 = (ulonglong)uVar66;
            bVar70 = (*pauVar33)[uVar55];
          }
          bVar27 = bVar27 >> 1;
          (*pauVar33)[uVar55] = bVar27;
          pauVar33[1][uVar55 - 0x10 & uVar38] = bVar27;
          pauVar60 = pauVar33 + -uVar55;
          *(longlong *)pauVar33[-1 - uVar55] = lVar31;
          *(undefined4 *)(pauVar60[-1] + 8) = 0;
          auVar74._0_8_ = CONCAT71(0,bVar70 & 1);
          auVar74._8_4_ = 0xffffffff;
          auVar74._12_4_ = 0xffffffff;
          lVar31 = CONCAT17(uStack_241,
                            CONCAT16(uStack_242,
                                     CONCAT24(sStack_244,
                                              CONCAT22(sStack_246,CONCAT11(uStack_247,local_248)))))
                   - auVar74._0_8_;
          lVar49 = CONCAT17(uStack_239,
                            CONCAT16(uStack_23a,
                                     CONCAT24(sStack_23c,
                                              CONCAT22(sStack_23e,CONCAT11(uStack_23f,uStack_240))))
                           ) - auVar74._8_8_;
          local_248 = (undefined1)lVar31;
          uStack_247 = (undefined1)((ulonglong)lVar31 >> 8);
          sStack_246 = (short)((ulonglong)lVar31 >> 0x10);
          sStack_244 = (short)((ulonglong)lVar31 >> 0x20);
          uStack_242 = (undefined1)((ulonglong)lVar31 >> 0x30);
          uStack_241 = (undefined1)((ulonglong)lVar31 >> 0x38);
          uStack_240 = (undefined1)lVar49;
          uStack_23f = (undefined1)((ulonglong)lVar49 >> 8);
          sStack_23e = (short)((ulonglong)lVar49 >> 0x10);
          sStack_23c = (short)((ulonglong)lVar49 >> 0x20);
          uStack_23a = (undefined1)((ulonglong)lVar49 >> 0x30);
          uStack_239 = (undefined1)((ulonglong)lVar49 >> 0x38);
LAB_1400197dc:
          *(int *)(pauVar60[-1] + 8) = *(int *)(pauVar60[-1] + 8) + 1;
        } while (pauVar39 != pauVar42);
      }
      bStack_317 = (byte)((ulonglong)pauVar61 >> 8);
      sStack_316 = (short)((ulonglong)pauVar61 >> 0x10);
      uStack_314 = (undefined4)((ulonglong)pauVar61 >> 0x20);
      uStack_310._0_4_ = (uint)pauVar61;
      uStack_308 = SUB81(local_340,0);
      uStack_307 = (undefined1)((ulonglong)local_340 >> 8);
      sStack_306 = (short)((ulonglong)local_340 >> 0x10);
      uStack_304 = (undefined4)((ulonglong)local_340 >> 0x20);
      local_2f8 = local_258;
      uStack_2f0._0_4_ = 0x40;
      uStack_2f0._4_4_ = 0;
      pauVar39 = (undefined1 (*) [16])&local_168;
      local_318 = uVar50;
      uStack_310._4_4_ = uStack_314;
      uStack_300 = pauVar42;
      alloc[246c2e7857c81348]::vec::in_place_collect::from_iter_in_place::
      <core[505b25137b8ba7f]::iter::adapters::take::Take<core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<reach_directory[4b72b9694f6c3c08]::chat::Player>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::roster::_closure_0_>>,reach_directory[4b72b9694f6c3c08]::chat::Player>
                (pauVar39,&local_318);
      pauVar33 = local_158;
      pauVar61 = pauStack_160;
      local_318 = (byte)&local_349;
      bStack_317 = (byte)((ulonglong)&local_349 >> 8);
      sStack_316 = (short)((ulonglong)&local_349 >> 0x10);
      uStack_314 = (undefined4)((ulonglong)&local_349 >> 0x20);
      if ((undefined1 (*) [16])0x1 < local_158) {
        pauVar39 = pauStack_160;
        if ((undefined1 (*) [16])&DAT_00000014 < local_158) {
          core[505b25137b8ba7f]::slice::sort::stable::driftsort_main::
          <reach_directory[4b72b9694f6c3c08]::chat::Player,<[reach_directory[4b72b9694f6c3c08]::chat::Player]>::sort_by_key<u64,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::roster::_closure_1_>::_closure_0_,alloc[246c2e7857c81348]::vec::Vec<reach_directory[4b72b9694f6c3c08]::chat::Player>>
                    (pauStack_160,local_158,&local_318);
        }
        else {
          core[505b25137b8ba7f]::slice::sort::shared::smallsort::insertion_sort_shift_left::
          <reach_directory[4b72b9694f6c3c08]::chat::Player,<[reach_directory[4b72b9694f6c3c08]::chat::Player]>::sort_by_key<u64,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::roster::_closure_1_>::_closure_0_>
                    (pauStack_160,local_158,1,&local_318);
        }
      }
      pauVar60 = DAT_1406990e8;
      pauVar42 = DAT_1406990e0;
      if (pauVar33 == DAT_1406990e8) {
        if (pauVar33 != (undefined1 (*) [16])0x0) {
          lVar31 = 0x24;
          pauVar64 = pauVar33;
          do {
            if (((*(longlong *)((longlong)pauVar61[-1] + lVar31 + 4) !=
                  *(longlong *)((longlong)pauVar42[-1] + lVar31 + 4)) ||
                (*(int *)((longlong)pauVar61[-1] + lVar31 + 0xc) !=
                 *(int *)((longlong)pauVar42[-1] + lVar31 + 0xc))) ||
               ((*(char *)((longlong)*pauVar61 + lVar31) != *(char *)((longlong)*pauVar42 + lVar31)
                || (sVar1 = *(size_t *)((longlong)pauVar61[-2] + lVar31 + 0xc),
                   sVar1 != *(size_t *)((longlong)pauVar42[-2] + lVar31 + 0xc)))))
            goto LAB_140019a0e;
            pauVar39 = *(undefined1 (**) [16])((longlong)pauVar61[-2] + lVar31 + 4);
            iVar29 = memcmp(pauVar39,*(void **)((longlong)pauVar42[-2] + lVar31 + 4),sVar1);
            if (iVar29 != 0) goto LAB_140019a0e;
            lVar31 = lVar31 + 0x28;
            pauVar64 = (undefined1 (*) [16])(pauVar64[-1] + 0xf);
          } while (pauVar64 != (undefined1 (*) [16])0x0);
          puVar44 = (undefined8 *)((longlong)*pauVar61 + 8);
          do {
            if (puVar44[-1] != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar44,puVar44[-1],1);
              return;
            }
            puVar44 = puVar44 + 5;
            pauVar33 = (undefined1 (*) [16])(pauVar33[-1] + 0xf);
          } while (pauVar33 != (undefined1 (*) [16])0x0);
        }
        if (local_168 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar61,local_168 * 0x28,8);
          return;
        }
      }
      else {
LAB_140019a0e:
        cVar26 = -1;
        if (pauVar33 != (undefined1 (*) [16])0x0) {
          lVar31 = 0;
          do {
            if (*(undefined1 (**) [16])((longlong)pauVar61[1] + lVar31 + 8) == local_348) {
              cVar26 = *(char *)((longlong)pauVar61[2] + lVar31 + 4);
              goto LAB_140019a4a;
            }
            lVar31 = lVar31 + 0x28;
          } while ((longlong)pauVar33 * 0x28 != lVar31);
          cVar26 = -1;
        }
LAB_140019a4a:
        if (pauVar60 != (undefined1 (*) [16])0x0) {
          lVar31 = 0;
          do {
            if (*(undefined1 (**) [16])((longlong)DAT_1406990e0[1] + lVar31 + 8) == local_348) {
              if (cVar26 != *(char *)((longlong)DAT_1406990e0[2] + lVar31 + 4)) goto LAB_140019a91;
              goto LAB_140019aab;
            }
            lVar31 = lVar31 + 0x28;
          } while ((longlong)pauVar60 * 0x28 != lVar31);
        }
        if (cVar26 != -1) {
LAB_140019a91:
          <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::drop_team_lines
                    (&DAT_140699030);
          pauVar60 = DAT_1406990e8;
        }
LAB_140019aab:
        DAT_14069941d = cVar26;
        if (pauVar60 != (undefined1 (*) [16])0x0) {
          puVar44 = (undefined8 *)((longlong)*DAT_1406990e0 + 8);
          do {
            if (puVar44[-1] != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar44,puVar44[-1],1);
              return;
            }
            puVar44 = puVar44 + 5;
            pauVar60 = (undefined1 (*) [16])(pauVar60[-1] + 0xf);
          } while (pauVar60 != (undefined1 (*) [16])0x0);
        }
        if (DAT_1406990d8 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_1406990e0,DAT_1406990d8 * 0x28,8);
          return;
        }
        DAT_1406990d8 = local_168;
        DAT_1406990e0 = pauStack_160;
        DAT_1406990e8 = local_158;
        <reach_directory[4b72b9694f6c3c08]::chat::HostRelay>::roster_changed
                  (&DAT_1406990f0,pauStack_160);
        reach_directory[4b72b9694f6c3c08]::registry::random_hex(&local_318);
        pauVar39 = (undefined1 (*) [16])&DAT_140699030;
        puVar44 = (undefined8 *)&local_318;
        <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::change_epoch
                  (&DAT_140699030,puVar44);
        pauVar61 = DAT_140699388;
        if (DAT_1406993a0 != 0) {
          auVar71 = *DAT_140699388;
          pauVar33 = DAT_140699388 + 1;
          uVar66 = ~(uint)(ushort)((ushort)(SUB161(auVar71 >> 7,0) & 1) |
                                   (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                                   (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                                   (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                                   (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                                   (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                                   (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                                   (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                                   (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                                   (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                                   (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                                   (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                                   (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                                   (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                                   (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                                  (ushort)(byte)(auVar71[0xf] >> 7) << 0xf);
          lVar31 = DAT_1406993a0;
          pauVar42 = DAT_140699388;
          do {
            uVar59 = (ushort)uVar66;
            while (uVar59 == 0) {
              auVar71 = *pauVar33;
              pauVar42 = pauVar42 + -0x50;
              pauVar33 = pauVar33 + 1;
              uVar59 = ((ushort)(SUB161(auVar71 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                       (ushort)(byte)(auVar71[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar66 = (uint)uVar59;
            }
            uVar62 = 0;
            for (uVar8 = uVar66; (uVar8 & 1) == 0; uVar8 = uVar8 >> 1 | 0x80000000) {
              uVar62 = uVar62 + 1;
            }
            pauVar39 = pauVar42 + (ulonglong)uVar62 * -5 + -5;
            core[505b25137b8ba7f]::ptr::drop_glue::
            <(u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection)>(pauVar39);
            uVar38 = DAT_140699390;
            uVar66 = uVar66 - 1 & uVar66;
            lVar31 = lVar31 + -1;
          } while (lVar31 != 0);
          if (DAT_140699390 == 0) {
            _DAT_140699398 = 0;
          }
          else {
            memset(pauVar61,(int)CONCAT71((int7)((ulonglong)puVar44 >> 8),0xff),DAT_140699390 + 0x11
                  );
            pauVar39 = (undefined1 (*) [16])(uVar38 + 1 >> 3);
            _DAT_140699398 = (uVar38 + 1 & 0xfffffffffffffff8) - (longlong)pauVar39;
            if (uVar38 < 8) {
              _DAT_140699398 = uVar38;
            }
          }
          DAT_1406993a0 = 0;
        }
      }
      lVar49 = CONCAT17(uStack_249,
                        CONCAT16(uStack_24a,
                                 CONCAT24(sStack_24c,
                                          CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250)))));
      uStack_310 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310);
      if ((lVar49 != 0) &&
         (lVar31 = lVar49 * 0x11 + 0x21,
         uStack_310 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310), lVar31 != 0)
         ) {
        pauVar61 = (undefined1 (*) [16])
                   (CONCAT26(sStack_252,
                             CONCAT24(sStack_254,
                                      CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0])))) +
                    lVar49 * -0x10 + -0x10);
        uVar56 = 0x10;
        goto LAB_140019c88;
      }
    }
    else {
      if (pauVar33 != (undefined1 (*) [16])0x0) {
        puVar44 = (undefined8 *)((longlong)*pauVar61 + 8);
        do {
          if (puVar44[-1] != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar44,puVar44[-1],1);
            return;
          }
          puVar44 = puVar44 + 5;
          pauVar33 = (undefined1 (*) [16])((longlong)pauVar33[-1] + 0xf);
        } while (pauVar33 != (undefined1 (*) [16])0x0);
      }
      if (local_340 != (undefined1 (*) [16])0x0) {
        lVar31 = (longlong)local_340 * 0x28;
        uVar56 = 8;
LAB_140019c88:
        __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar61,lVar31,uVar56);
        return;
      }
    }
  }
  local_190 = (undefined1 (*) [16])0x0;
  local_188 = (undefined1 (*) [16])&DAT_00000008;
  local_180 = 0;
  local_194 = (undefined4)CONCAT71((int7)((ulonglong)pauVar39 >> 8),1);
  LOCK();
  bVar69 = DAT_140699000 == '\0';
  if (bVar69) {
    DAT_140699000 = '\x01';
  }
  UNLOCK();
  if (!bVar69) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699000);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    uVar66 = 0;
    pauVar61 = DAT_140699020;
    pauVar39 = uStack_310;
  }
  else {
    uVar66 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    uVar66 = uVar66 ^ 1;
    pauVar61 = DAT_140699020;
    pauVar39 = uStack_310;
  }
  uVar78 = (undefined4)((ulonglong)in_stack_fffffffffffffc70 >> 0x20);
  if (DAT_140699001 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_310._4_4_ = (undefined4)((ulonglong)pauVar39 >> 0x20);
    local_318 = 0;
    bStack_317 = 0x90;
    sStack_316 = 0x4069;
    uStack_314 = 1;
    uStack_310._1_3_ = (undefined3)((ulonglong)pauVar39 >> 8);
    uStack_310._0_4_ = CONCAT31(uStack_310._1_3_,(char)uVar66);
    DAT_140699020 = pauVar61;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_318,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a10d0
               ,&DAT_1406a1a98);
    goto LAB_14001db96;
  }
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  DAT_140699020 = (undefined1 (*) [16])0x0;
  local_258[0] = 8;
  local_258[1] = 0x90;
  sStack_256 = 0x4069;
  sStack_254 = 1;
  sStack_252 = 0;
  bStack_250 = (byte)pauVar61;
  uStack_24f = (undefined1)((ulonglong)pauVar61 >> 8);
  sStack_24e = (short)((ulonglong)pauVar61 >> 0x10);
  sStack_24c = (short)((ulonglong)pauVar61 >> 0x20);
  uStack_24a = (undefined1)((ulonglong)pauVar61 >> 0x30);
  uStack_249 = (undefined1)((ulonglong)pauVar61 >> 0x38);
  local_248 = 0;
  uStack_247 = 0;
  sStack_246 = 0;
  sStack_244 = 0;
  uStack_242 = 0;
  uStack_241 = 0;
  uStack_240 = 0;
  uStack_23f = 0;
  sStack_23e = 0;
  sStack_23c = 0;
  uStack_23a = 0;
  uStack_239 = 0;
  uStack_237 = (undefined7)((ulonglong)pauVar61 >> 8);
  local_238 = bStack_250;
  if (pauVar61 != (undefined1 (*) [16])0x0) {
    uVar38 = (ulonglong)local_1e8 >> 0x20;
    local_1e8 = CONCAT44((int)uVar38,uVar66);
    pauVar33 = (undefined1 (*) [16])0x0;
    do {
      uVar78 = (undefined4)((ulonglong)in_stack_fffffffffffffc70 >> 0x20);
      puVar48 = (undefined1 *)((longlong)*pauVar33 + DAT_140699018);
      puVar51 = (undefined1 *)0x0;
      if (DAT_140699008 <= puVar48) {
        puVar51 = DAT_140699008;
      }
      pauVar33 = (undefined1 (*) [16])((longlong)*pauVar33 + 1);
      pauVar61 = (undefined1 (*) [16])((longlong)pauVar61[-1] + 0xf);
      lVar49 = ((longlong)puVar48 - (longlong)puVar51) * 0x20;
      lVar31 = *(longlong *)(DAT_140699010 + 8 + lVar49);
      if (lVar31 == -1) goto LAB_14001a207;
      local_1a0 = *(undefined1 (**) [16])(DAT_140699010 + lVar49);
      local_1e0 = *(undefined1 (**) [16])(DAT_140699010 + 0x10 + lVar49);
      in_stack_fffffffffffffc70 = local_1c0;
      local_348 = pauVar61;
      local_340 = pauVar33;
      uStack_310 = pauVar39;
      <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive
                (&local_278,&DAT_140699030,local_1a0,local_1e0,
                 *(undefined8 *)(DAT_140699010 + lVar49 + 0x18),local_1c0,local_334);
      pauVar42 = pauStack_270 + (longlong)local_268 * 2;
      local_1b0 = pauStack_270;
      pauVar39 = pauStack_270;
      if (local_268 == (undefined1 (*) [16])0x0) {
        bVar69 = false;
      }
      else {
        do {
          local_1b8 = lVar31;
          uVar38 = *(ulonglong *)((longlong)pauVar39[1] + 8);
          if (uVar38 < 8) {
            local_248 = SUB81(local_340,0);
            uStack_247 = (undefined1)((ulonglong)local_340 >> 8);
            sStack_246 = (short)((ulonglong)local_340 >> 0x10);
            sStack_244 = (short)((ulonglong)local_340 >> 0x20);
            uStack_242 = (undefined1)((ulonglong)local_340 >> 0x30);
            uStack_241 = (undefined1)((ulonglong)local_340 >> 0x38);
            local_238 = (byte)local_348;
            uStack_237 = (undefined7)((ulonglong)local_348 >> 8);
            core[505b25137b8ba7f]::slice::index::slice_index_fail(8,uVar38,uVar38,&DAT_1406a06a8);
            goto LAB_14001db96;
          }
          local_370 = *(longlong *)pauVar39[1] + 8;
          uStack_368 = (undefined1)(uVar38 - 8);
          uStack_367 = (undefined7)(uVar38 - 8 >> 8);
          uStack_360 = 0;
          uStack_35c = 0;
          serde_json[7404bcab4dc139c7]::de::from_trait::
          <serde_json[7404bcab4dc139c7]::read::SliceRead,serde_json[7404bcab4dc139c7]::value::Value>
                    (&local_318,&local_370);
          bVar27 = local_318;
          if (local_318 == 0xff) {
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::error::Error>
                      (&uStack_310);
          }
          else {
            uStack_367 = (undefined7)((ulonglong)uStack_310 >> 8);
            uVar78 = CONCAT22(sStack_306,CONCAT11(uStack_307,uStack_308));
            auVar16._4_4_ = uStack_304;
            auVar16._0_4_ = uVar78;
            auVar16._8_4_ = (undefined4)uStack_300;
            auVar16._12_4_ = uStack_300._4_4_;
            uStack_35c = uStack_304;
            pauStack_358 = auVar16._8_8_;
            local_370._4_4_ = uStack_314;
            uStack_368 = (byte)uStack_310;
            uStack_360 = CONCAT31((int3)((uint)uVar78 >> 8),uStack_308);
            local_370._0_4_ = CONCAT31(CONCAT21(sStack_316,bStack_317),local_318);
            pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                        ("kindsrc\\ingame_chat.rs",4,&local_370);
            if (pcVar35 == (char *)0x0) {
              pcVar35 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            if ((*pcVar35 == '\x03') && (*(longlong *)(pcVar35 + 0x18) == 5)) {
              iVar29 = **(int **)(pcVar35 + 0x10);
              iVar23 = (*(int **)(pcVar35 + 0x10))[1];
              core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                        (&local_370);
              if ((char)iVar23 == 'y' && iVar29 == 0x64616572) {
                bVar69 = true;
                lVar31 = local_1b8;
                goto LAB_14001a052;
              }
            }
            else {
              local_370 = CONCAT44(local_370._4_4_,(int)local_370);
              if (2 < bVar27) {
                if (bVar27 == 3) {
                  local_370 = CONCAT44(local_370._4_4_,(int)local_370);
                  if (CONCAT71(uStack_367,uStack_368) != 0) {
                    __rustc[9d087a5ab36ea756]::__rust_dealloc
                              (CONCAT44(uStack_35c,uStack_360),CONCAT71(uStack_367,uStack_368),1);
                    return;
                  }
                }
                else if (bVar27 == 4) {
                  if (pauStack_358 != (undefined1 (*) [16])0x0) {
                    lVar31 = CONCAT44(uStack_35c,uStack_360);
                    lVar49 = 1 - (longlong)pauStack_358;
                    do {
                      core[505b25137b8ba7f]::ptr::drop_glue::
                      <serde_json[7404bcab4dc139c7]::value::Value>(lVar31);
                      lVar31 = lVar31 + 0x20;
                      lVar49 = lVar49 + 1;
                    } while (lVar49 != 1);
                  }
                  local_370 = CONCAT44(local_370._4_4_,(int)local_370);
                  if (CONCAT71(uStack_367,uStack_368) != 0) {
                    __rustc[9d087a5ab36ea756]::__rust_dealloc
                              (CONCAT44(uStack_35c,uStack_360),CONCAT71(uStack_367,uStack_368) << 5,
                               8);
                    return;
                  }
                }
                else {
                  lVar31 = CONCAT71(uStack_367,uStack_368);
                  if (lVar31 == 0) {
                    pauVar61 = (undefined1 (*) [16])0x0;
                  }
                  else {
                    uStack_310 = (undefined1 (*) [16])0x0;
                    uStack_308 = uStack_368;
                    uStack_307 = (undefined1)uStack_367;
                    sStack_306 = (short)((uint7)uStack_367 >> 8);
                    uStack_304 = (undefined4)((uint7)uStack_367 >> 0x18);
                    uStack_300 = (undefined1 (*) [16])CONCAT44(uStack_35c,uStack_360);
                    uStack_2f0._0_4_ = 0;
                    uStack_2f0._4_4_ = 0;
                    uStack_2e8 = (undefined4)lVar31;
                    uStack_2e0 = uStack_360;
                    uStack_2dc = uStack_35c;
                    pauVar61 = pauStack_358;
                    uStack_2e4 = uStack_304;
                  }
                  local_318 = lVar31 != 0;
                  bStack_317 = 0;
                  sStack_316 = 0;
                  uStack_314 = 0;
                  local_2f8._0_4_ = (uint)local_318;
                  local_2f8._4_4_ = 0;
                  uStack_2d8 = SUB81(pauVar61,0);
                  uStack_2d7 = (undefined7)((ulonglong)pauVar61 >> 8);
                  core[505b25137b8ba7f]::ptr::drop_glue::
                  <alloc[246c2e7857c81348]::collections::btree::map::IntoIter<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                            (&local_318);
                  local_370 = CONCAT44(local_370._4_4_,(int)local_370);
                }
              }
            }
          }
          pauVar39 = pauVar39 + 2;
          lVar31 = local_1b8;
        } while (pauVar39 != pauVar42);
        bVar69 = false;
      }
LAB_14001a052:
      pauVar33 = local_340;
      pauVar61 = local_348;
      local_318 = (byte)local_1b0;
      bStack_317 = (byte)((ulonglong)local_1b0 >> 8);
      sStack_316 = (short)((ulonglong)local_1b0 >> 0x10);
      uStack_314 = (undefined4)((ulonglong)local_1b0 >> 0x20);
      uStack_308 = SUB81(local_278,0);
      uStack_307 = (undefined1)((ulonglong)local_278 >> 8);
      sStack_306 = (short)((ulonglong)local_278 >> 0x10);
      uStack_304 = (undefined4)((ulonglong)local_278 >> 0x20);
      uStack_310._0_4_ = (uint)local_1b0;
      uStack_310._4_4_ = uStack_314;
      uStack_300 = pauVar42;
      <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>>
      ::spec_extend(&local_190,&local_318);
      if (bVar69) {
        cVar26 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                 ::insert();
        if ((cVar26 == '\0') && (DAT_140699448 != 0)) {
          if (DAT_1406993e8 == DAT_1406993f0) {
            in_stack_fffffffffffffc70 = DAT_1406990e8;
            in_stack_fffffffffffffc80 = local_1a0;
            <reach_directory[4b72b9694f6c3c08]::chat::HostRelay>::server_line
                      (local_130,&DAT_1406990f0,DAT_140699440,DAT_140699448,DAT_1406990e0,
                       DAT_1406990e8,1,local_1a0);
            <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::deliver
                      (&local_370,&DAT_140699030,local_130,local_1c0,local_334);
            lVar49 = CONCAT71(uStack_367,uStack_368);
            lVar65 = CONCAT44(uStack_35c,uStack_360);
          }
          else {
            uStack_368 = 8;
            uStack_367 = 0;
            uStack_360 = 0;
            uStack_35c = 0;
            lVar49 = 8;
            lVar65 = 0;
            local_370 = 0;
          }
          uStack_300 = (undefined1 (*) [16])(lVar65 * 0x20 + lVar49);
          local_318 = (byte)lVar49;
          bStack_317 = (byte)((ulonglong)lVar49 >> 8);
          sStack_316 = (short)((ulonglong)lVar49 >> 0x10);
          uStack_314 = (undefined4)((ulonglong)lVar49 >> 0x20);
          uStack_308 = (undefined1)local_370;
          uStack_307 = (undefined1)(local_370 >> 8);
          sStack_306 = (short)(local_370 >> 0x10);
          uStack_304 = (undefined4)(local_370 >> 0x20);
          uStack_310._0_4_ = (uint)lVar49;
          uStack_310._4_4_ = uStack_314;
          <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>>
          ::spec_extend(&local_190,&local_318);
        }
      }
      uVar78 = (undefined4)((ulonglong)in_stack_fffffffffffffc70 >> 0x20);
      pauVar39 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310);
      if (lVar31 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_1e0,lVar31,1);
        return;
      }
    } while (pauVar61 != (undefined1 (*) [16])0x0);
    pauVar61 = (undefined1 (*) [16])0x0;
LAB_14001a207:
    local_248 = SUB81(pauVar33,0);
    uStack_247 = (undefined1)((ulonglong)pauVar33 >> 8);
    sStack_246 = (short)((ulonglong)pauVar33 >> 0x10);
    sStack_244 = (short)((ulonglong)pauVar33 >> 0x20);
    uStack_242 = (undefined1)((ulonglong)pauVar33 >> 0x30);
    uStack_241 = (undefined1)((ulonglong)pauVar33 >> 0x38);
    local_238 = (byte)pauVar61;
    uStack_237 = (undefined7)((ulonglong)pauVar61 >> 8);
    uVar66 = (uint)local_1e8;
  }
  uStack_310 = pauVar39;
  <alloc[246c2e7857c81348]::collections::vec_deque::drain::Drain<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_core[505b25137b8ba7f]::ops::drop::Drop>
  ::drop(local_258);
  if (((char)uVar66 == '\0') &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar26 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar26 == '\0') {
      DAT_140699001 = '\x01';
    }
  }
  cVar26 = DAT_140699000;
  LOCK();
  DAT_140699000 = '\0';
  UNLOCK();
  if (cVar26 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699000);
  }
  if (DAT_140699468 == -1) {
LAB_14001a28f:
    DAT_140699460 = local_1c0;
    DAT_140699468 = local_334;
    local_1d8 = (undefined1 (*) [16])0x0;
    local_1d0 = (undefined8 *)&DAT_00000008;
    local_1c8 = (undefined1 (*) [16])0x0;
    <std[3bf9d48a0c3997f0]::path::Path>::_join(local_258,&DAT_1406a1ab0,1,&DAT_1406a0c00,0x17);
    uVar56 = CONCAT17(uStack_249,
                      CONCAT16(uStack_24a,
                               CONCAT24(sStack_24c,
                                        CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250)))));
    read_json(&local_370,uVar56,
              CONCAT17(uStack_241,
                       CONCAT16(uStack_242,
                                CONCAT24(sStack_244,
                                         CONCAT22(sStack_246,CONCAT11(uStack_247,local_248))))),
              0x400);
    if ((byte)local_370 != 0xff) {
      uStack_308 = (undefined1)uStack_360;
      uStack_307 = (undefined1)(uStack_360 >> 8);
      sStack_306 = (short)(uStack_360 >> 0x10);
      uStack_304 = uStack_35c;
      uStack_300._0_4_ = SUB84(pauStack_358,0);
      uStack_300._4_4_ = (undefined4)((ulonglong)pauStack_358 >> 0x20);
      bStack_317 = (byte)(local_370 >> 8);
      sStack_316 = (short)(local_370 >> 0x10);
      uStack_314 = local_370._4_4_;
      uStack_310._0_4_ = (uint)CONCAT71(uStack_367,uStack_368);
      uStack_310._4_4_ = (undefined4)((uint7)uStack_367 >> 0x18);
      local_318 = (byte)local_370;
      pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                  (&DAT_1406a0be6,7,&local_318);
      if (pcVar35 == (char *)0x0) {
        pcVar35 = 
        __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
        ;
      }
      if (*pcVar35 == '\x02') {
        if (*(longlong *)(pcVar35 + 8) == 0) {
          lVar31 = *(longlong *)(pcVar35 + 0x10);
          if (-1 < lVar31) goto LAB_14001a398;
        }
        else if ((int)*(longlong *)(pcVar35 + 8) == 1) {
          lVar31 = *(longlong *)(pcVar35 + 0x10);
LAB_14001a398:
          if (lVar31 == 1) {
            pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                        (&DAT_1406a0c17,7,&local_318);
            if (pcVar35 == (char *)0x0) {
              pcVar35 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            if ((*pcVar35 == '\x03') && (sVar1 = *(size_t *)(pcVar35 + 0x18), sVar1 - 1 < 0x60)) {
              pvVar43 = *(void **)(pcVar35 + 0x10);
              if (sVar1 != 0) {
                sVar36 = 0;
                do {
                  bVar27 = *(byte *)((longlong)pvVar43 + sVar36);
                  bVar69 = (byte)(bVar27 - 0x3a) < 0xf6;
                  if (0x40 < bVar27) {
                    bVar69 = 0x5a < bVar27;
                  }
                  bVar11 = 0x7a < bVar27;
                  if (bVar27 < 0x61) {
                    bVar11 = bVar69;
                  }
                  if ((bVar27 != 0x2d) && (bVar11)) goto LAB_14001a5c2;
                  sVar36 = sVar36 + 1;
                } while (sVar1 != sVar36);
              }
              if (sVar1 == DAT_140699430) {
                iVar29 = memcmp(pvVar43,DAT_140699428,sVar1);
                if (iVar29 != 0) goto LAB_14001a492;
              }
              else {
LAB_14001a492:
                <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in
                          (&local_278,sVar1,0,1,1);
                pauVar61 = local_268;
                pauVar39 = pauStack_270;
                if ((char)local_278 != '\0') {
                  alloc[246c2e7857c81348]::raw_vec::handle_error(pauStack_270,local_268);
                  goto LAB_14001db96;
                }
                if (sVar1 != 0) {
                  memcpy(local_268,pvVar43,sVar1);
                }
                if (DAT_140699420 != (undefined1 (*) [16])0x0) {
                  __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_140699428,DAT_140699420,1);
                  return;
                }
                DAT_140699420 = pauVar39;
                DAT_140699428 = pauVar61;
                DAT_1406994d8 = 0;
                DAT_140699430 = sVar1;
                if (DAT_1406992b8 != -1) {
                  if (DAT_1406992b8 != 0) {
                    __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_1406992c0,DAT_1406992b8,1);
                    return;
                  }
                  core[505b25137b8ba7f]::ptr::drop_glue::
                  <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(&DAT_1406992f0);
                }
                DAT_1406992b8 = -1;
                DAT_140699298 = (undefined4 *)0x0;
                DAT_1406992b0 = (undefined1 (*) [16])0x0;
                _DAT_140699498 = 0;
                DAT_14069949a = 0;
              }
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into(&DAT_1406a0c1e,7,&local_318);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              if ((*pcVar35 == '\x02') && (*(longlong *)(pcVar35 + 8) == 0)) {
                DAT_1406994d0 = *(undefined8 *)(pcVar35 + 0x10);
              }
              else {
                DAT_1406994d0 = 0;
              }
            }
          }
        }
      }
LAB_14001a5c2:
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                (&local_318);
    }
    lVar31 = CONCAT26(sStack_252,
                      CONCAT24(sStack_254,CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))))
    ;
    if (lVar31 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar56,lVar31,1);
      return;
    }
    <std[3bf9d48a0c3997f0]::path::Path>::_join(&local_278,&DAT_1406a1ab0,1,&DAT_1406a0c25,0x13);
    pauVar61 = local_268;
    pauVar39 = pauStack_270;
    std[3bf9d48a0c3997f0]::sys::fs::metadata(&local_318,pauStack_270);
    if (CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)) == 2) {
      if ((1 < ((uint)uStack_310 & 3) - 2) && (((ulonglong)uStack_310 & 3) != 0)) {
        uStack_310 = (undefined1 (*) [16])(uStack_310[-1] + 0xf);
        local_318 = 3;
        <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
        drop(&uStack_310);
      }
    }
    else {
      read_json(local_258,pauVar39,pauVar61,0x800);
      uVar38 = std[3bf9d48a0c3997f0]::sys::fs::remove_file(pauVar39);
      uVar47 = SUB84(pauVar61,0);
      if (uVar38 == 0) {
        if (local_258[0] != 0xff) {
          uStack_314 = CONCAT22(sStack_252,sStack_254);
          uStack_310._0_4_ = CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250));
          uStack_304 = CONCAT13(uStack_241,CONCAT12(uStack_242,sStack_244));
          uVar56 = CONCAT26(sStack_23e,CONCAT15(uStack_23f,CONCAT14(uStack_240,uStack_304)));
          auVar20._8_2_ = sStack_23c;
          auVar20._0_8_ = uVar56;
          auVar20[10] = uStack_23a;
          auVar20[0xb] = uStack_239;
          uStack_308 = local_248;
          uStack_307 = uStack_247;
          sStack_306 = sStack_246;
          uStack_300._0_4_ = (undefined4)((ulonglong)uVar56 >> 0x20);
          uStack_300._4_4_ = auVar20._8_4_;
          local_318 = local_258[0];
          bStack_317 = local_258[1];
          sStack_316 = sStack_256;
          uStack_310._4_4_ =
               (undefined4)
               (CONCAT17(uStack_249,CONCAT16(uStack_24a,CONCAT24(sStack_24c,(uint)uStack_310))) >>
               0x20);
          uVar30 = <std[3bf9d48a0c3997f0]::time::SystemTime>::now();
          local_330 = (undefined1 (*) [16])CONCAT44(uVar47,uVar30);
          <std[3bf9d48a0c3997f0]::time::SystemTime>::duration_since
                    (&local_370,&local_330,0xd53e8000,0x19db1de);
          lVar31 = 0;
          if ((byte)local_370 == '\0') {
            lVar31 = (ulonglong)uStack_360 / 1000000 + CONCAT71(uStack_367,uStack_368) * 1000;
          }
          pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                      (&DAT_1406a0bdf,7);
          if (pcVar35 == (char *)0x0) {
            pcVar35 = 
            __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
            ;
          }
          if ((*pcVar35 == '\x03') && (uVar38 = *(ulonglong *)(pcVar35 + 0x18), uVar38 != 0)) {
            pcVar35 = *(char **)(pcVar35 + 0x10);
            if (uVar38 == 1) {
              cVar26 = *pcVar35;
              if ((cVar26 == '+') || (cVar26 == '-')) goto LAB_14001aa76;
            }
            else {
              cVar26 = *pcVar35;
            }
            uVar55 = (ulonglong)(cVar26 == '+');
            if (uVar38 - uVar55 < 0x11) {
              if (uVar38 == uVar55) goto LAB_14001aa76;
              uVar34 = 0;
              lVar49 = 0;
              do {
                if (9 < (byte)pcVar35[lVar49 + uVar55] - 0x30) goto LAB_14001aa76;
                uVar34 = (ulonglong)((byte)pcVar35[lVar49 + uVar55] - 0x30) + uVar34 * 10;
                lVar49 = lVar49 + 1;
              } while (lVar49 != uVar38 + -uVar55);
            }
            else {
              uVar34 = 0;
              lVar49 = 0;
              do {
                auVar3._8_8_ = 0;
                auVar3._0_8_ = uVar34;
                uVar52 = SUB168(auVar3 * ZEXT816(10),0);
                if (SUB168(auVar3 * ZEXT816(10),8) != 0) goto LAB_14001aa76;
                uVar66 = (byte)pcVar35[lVar49 + uVar55] - 0x30;
                uVar34 = uVar52 + uVar66;
                if ((9 < uVar66) || (CARRY8(uVar52,(ulonglong)uVar66))) goto LAB_14001aa76;
                lVar49 = lVar49 + 1;
              } while (lVar49 != uVar38 + -uVar55);
            }
            if (uVar34 <= DAT_1406994d8) goto LAB_14001aa76;
            pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                        (&DAT_1406a0be6,7);
            if (pcVar35 == (char *)0x0) {
              pcVar35 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            if ((*pcVar35 != '\x02') || (*(longlong *)(pcVar35 + 8) == 2)) goto LAB_14001aa76;
            if ((int)*(longlong *)(pcVar35 + 8) == 1) {
              lVar49 = *(longlong *)(pcVar35 + 0x10);
            }
            else {
              lVar49 = *(longlong *)(pcVar35 + 0x10);
              if (lVar49 < 0) goto LAB_14001aa76;
            }
            if ((lVar49 != 1) || (DAT_140699430 == 0)) goto LAB_14001aa76;
            pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                        (&DAT_1406a0c17,7);
            if (pcVar35 == (char *)0x0) {
              pcVar35 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            if ((*pcVar35 != '\x03') || (*(size_t *)(pcVar35 + 0x18) != DAT_140699430))
            goto LAB_14001aa76;
            iVar29 = memcmp(*(void **)(pcVar35 + 0x10),DAT_140699428,DAT_140699430);
            if (iVar29 != 0) goto LAB_14001aa76;
            DAT_1406994d8 = uVar34;
            pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                        (&DAT_1406a0bed,5,&local_318);
            if (pcVar35 == (char *)0x0) {
              pcVar35 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            pauVar60 = (undefined1 (*) [16])0x2f;
            pauVar61 = (undefined1 (*) [16])&DAT_1406a0c8a;
            if ((*pcVar35 == '\x03') && (*(size_t *)(pcVar35 + 0x18) == DAT_140699098)) {
              iVar29 = memcmp(*(void **)(pcVar35 + 0x10),DAT_140699090,DAT_140699098);
              if (iVar29 != 0) goto LAB_14001d8ad;
              cVar26 = valid_expiry(&local_318,lVar31);
              if (cVar26 == '\0') {
                pauVar61 = (undefined1 (*) [16])&DAT_1406a0c4d;
                pauVar60 = (undefined1 (*) [16])&DAT_00000028;
                goto LAB_14001d8ad;
              }
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into("channel",7,&local_318);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              uVar54 = (undefined7)((ulonglong)lVar31 >> 8);
              uVar66 = (uint)CONCAT71(uVar54,0xff);
              if (*pcVar35 == '\x03') {
                piVar2 = *(int **)(pcVar35 + 0x10);
                if (*(longlong *)(pcVar35 + 0x18) == 4) {
                  bVar69 = *piVar2 == 0x6d616574;
                  uVar66 = (uint)CONCAT71(uVar54,-!bVar69) | 4;
                }
                else {
                  if (*(longlong *)(pcVar35 + 0x18) != 3) goto LAB_14001d75e;
                  bVar11 = *(char *)((longlong)piVar2 + 2) == 'l';
                  bVar12 = (short)*piVar2 == 0x6c61;
                  bVar69 = bVar11 && bVar12;
                  uVar66 = (uint)CONCAT71(uVar54,-(!bVar11 || !bVar12)) | 3;
                }
              }
              else {
LAB_14001d75e:
                bVar69 = false;
              }
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into("text",4,&local_318);
              uVar47 = (undefined4)((ulonglong)in_stack_fffffffffffffc80 >> 0x20);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              pauVar61 = (undefined1 (*) [16])&DAT_1406a0c75;
              pauVar60 = (undefined1 (*) [16])&DAT_00000015;
              if ((*pcVar35 != '\x03') || (!bVar69)) goto LAB_14001d8ad;
              local_348 = *(undefined1 (**) [16])(pcVar35 + 0x10);
              uVar56 = *(undefined8 *)(pcVar35 + 0x18);
              puVar44 = &local_330;
              pvVar43 = (void *)::<u64>::_fmt(uVar34,puVar44,0x14);
              <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in(&local_370);
              uVar62 = uStack_360;
              uVar54 = uStack_367;
              lVar31 = CONCAT71(uStack_367,uStack_368);
              if ((int)local_370 != 1) {
                pvVar41 = (void *)CONCAT44(uStack_35c,uStack_360);
                if (puVar44 != (undefined8 *)0x0) {
                  memcpy(pvVar41,pvVar43,(size_t)puVar44);
                }
                local_370._0_4_ = (int)lVar31;
                local_370._4_4_ = (undefined4)((uint7)uVar54 >> 0x18);
                uStack_368 = (undefined1)uVar62;
                uStack_367 = (undefined7)((ulonglong)pvVar41 >> 8);
                uStack_360 = (uint)puVar44;
                uStack_35c = (undefined4)((ulonglong)puVar44 >> 0x20);
                in_stack_fffffffffffffc80 = (undefined1 (*) [16])CONCAT44(uVar47,local_334);
                <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::submit
                          (&local_330,&DAT_140699030,&local_370,uVar66,local_348,uVar56,local_1c0,
                           in_stack_fffffffffffffc80);
                uVar78 = (undefined4)((ulonglong)uVar56 >> 0x20);
                pauVar61 = local_328;
                pauVar33 = local_330;
                pauVar60 = local_320;
                pauVar42 = local_320;
                if (local_330 == (undefined1 (*) [16])0xffffffffffffffff) goto LAB_14001d8ad;
                goto LAB_14001d9c3;
              }
LAB_14001db54:
              alloc[246c2e7857c81348]::raw_vec::handle_error(lVar31,CONCAT44(uStack_35c,uStack_360))
              ;
              goto LAB_14001db96;
            }
LAB_14001d8ad:
            puVar40 = &local_144;
            pvVar43 = (void *)::<u64>::_fmt(uVar34);
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in(&local_370);
            lVar31 = CONCAT71(uStack_367,uStack_368);
            if ((int)local_370 == 1) goto LAB_14001db54;
            pvVar41 = (void *)CONCAT44(uStack_35c,uStack_360);
            if (puVar40 != (undefined4 *)0x0) {
              memcpy(pvVar41,pvVar43,(size_t)puVar40);
            }
            if (DAT_140699288 != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_140699290,DAT_140699288,1);
              return;
            }
            DAT_140699288 = lVar31;
            DAT_140699290 = pvVar41;
            DAT_140699298 = puVar40;
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in
                      (&local_370,pauVar60,0,1,1);
            lVar31 = CONCAT71(uStack_367,uStack_368);
            if ((byte)local_370 != '\0') goto LAB_14001db54;
            pcVar35 = (char *)CONCAT44(uStack_35c,uStack_360);
            if (pauVar60 != (undefined1 (*) [16])0x0) {
              memcpy(pcVar35,pauVar61,(size_t)pauVar60);
            }
            if (DAT_1406992a0 != 0) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_1406992a8,DAT_1406992a0,1);
              return;
            }
            pauVar61 = (undefined1 (*) [16])&DAT_00000008;
            pauVar33 = (undefined1 (*) [16])0x0;
            pauVar42 = (undefined1 (*) [16])0x0;
            DAT_1406992a0 = lVar31;
            DAT_1406992a8 = pcVar35;
            DAT_1406992b0 = pauVar60;
LAB_14001d9c3:
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (&local_318);
          }
          else {
LAB_14001aa76:
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (local_258);
            pauVar61 = (undefined1 (*) [16])&DAT_00000008;
            pauVar33 = (undefined1 (*) [16])0x0;
            pauVar42 = (undefined1 (*) [16])0x0;
          }
          uStack_300 = pauVar61 + (longlong)pauVar42 * 2;
          local_318 = (byte)pauVar61;
          bStack_317 = (byte)((ulonglong)pauVar61 >> 8);
          sStack_316 = (short)((ulonglong)pauVar61 >> 0x10);
          uStack_314 = (undefined4)((ulonglong)pauVar61 >> 0x20);
          uStack_308 = SUB81(pauVar33,0);
          uStack_307 = (undefined1)((ulonglong)pauVar33 >> 8);
          sStack_306 = (short)((ulonglong)pauVar33 >> 0x10);
          uStack_304 = (undefined4)((ulonglong)pauVar33 >> 0x20);
          uStack_310._0_4_ = (uint)pauVar61;
          uStack_310._4_4_ = uStack_314;
          <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>>
          ::spec_extend(&local_1d8,&local_318);
        }
      }
      else {
        if ((1 < ((uint)uVar38 & 3) - 2) && ((uVar38 & 3) != 0)) {
          uStack_310 = (undefined1 (*) [16])(uVar38 - 1);
          local_318 = 3;
          <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
          ::drop(&uStack_310);
        }
        if (local_258[0] != 0xff) {
          core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                    (local_258);
        }
      }
    }
    if (DAT_1406993e8 == DAT_1406993f0) {
      <std[3bf9d48a0c3997f0]::path::Path>::_join(&local_370,&DAT_1406a1ab0,1,&DAT_1406a0c38,0x15);
      uVar56 = CONCAT71(uStack_367,uStack_368);
      uVar57 = CONCAT44(uStack_35c,uStack_360);
      std[3bf9d48a0c3997f0]::sys::fs::metadata(&local_318,uVar56);
      if (CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)) == 2) {
        SVar22 = local_370;
        if ((1 < ((uint)uStack_310 & 3) - 2) && (((ulonglong)uStack_310 & 3) != 0)) {
          uStack_310 = (undefined1 (*) [16])(uStack_310[-1] + 0xf);
          local_318 = 3;
          <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
          ::drop(&uStack_310);
          SVar22 = local_370;
        }
      }
      else {
        read_json(local_258,uVar56,uVar57,0x800);
        uVar38 = std[3bf9d48a0c3997f0]::sys::fs::remove_file(uVar56);
        uVar47 = (undefined4)uVar57;
        if (uVar38 == 0) {
          SVar22 = local_370;
          if (local_258[0] != 0xff) {
            uStack_314 = CONCAT22(sStack_252,sStack_254);
            uStack_310._0_4_ = CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250));
            uStack_304 = CONCAT13(uStack_241,CONCAT12(uStack_242,sStack_244));
            uVar57 = CONCAT26(sStack_23e,CONCAT15(uStack_23f,CONCAT14(uStack_240,uStack_304)));
            auVar21._8_2_ = sStack_23c;
            auVar21._0_8_ = uVar57;
            auVar21[10] = uStack_23a;
            auVar21[0xb] = uStack_239;
            uStack_308 = local_248;
            uStack_307 = uStack_247;
            sStack_306 = sStack_246;
            uStack_300._0_4_ = (undefined4)((ulonglong)uVar57 >> 0x20);
            uStack_300._4_4_ = auVar21._8_4_;
            local_318 = local_258[0];
            bStack_317 = local_258[1];
            sStack_316 = sStack_256;
            uStack_310._4_4_ =
                 (undefined4)
                 (CONCAT17(uStack_249,CONCAT16(uStack_24a,CONCAT24(sStack_24c,(uint)uStack_310))) >>
                 0x20);
            local_144 = <std[3bf9d48a0c3997f0]::time::SystemTime>::now();
            local_140 = uVar47;
            <std[3bf9d48a0c3997f0]::time::SystemTime>::duration_since
                      (&local_330,&local_144,0xd53e8000,0x19db1de);
            uVar38 = 0;
            if ((char)local_330 == '\0') {
              uVar38 = ((ulonglong)local_320 & 0xffffffff) / 1000000 + (longlong)local_328 * 1000;
            }
            pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                        (&DAT_1406a0bdf,7);
            if (pcVar35 == (char *)0x0) {
              pcVar35 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            if ((*pcVar35 == '\x03') && (uVar55 = *(ulonglong *)(pcVar35 + 0x18), uVar55 != 0)) {
              pcVar35 = *(char **)(pcVar35 + 0x10);
              if (uVar55 == 1) {
                cVar26 = *pcVar35;
                if ((cVar26 == '+') || (cVar26 == '-')) goto LAB_14001aeb0;
              }
              else {
                cVar26 = *pcVar35;
              }
              uVar34 = (ulonglong)(cVar26 == '+');
              if (uVar55 - uVar34 < 0x11) {
                if (uVar55 == uVar34) goto LAB_14001aeb0;
                uVar52 = 0;
                lVar31 = 0;
                do {
                  if (9 < (byte)pcVar35[lVar31 + uVar34] - 0x30) goto LAB_14001aeb0;
                  uVar52 = (ulonglong)((byte)pcVar35[lVar31 + uVar34] - 0x30) + uVar52 * 10;
                  lVar31 = lVar31 + 1;
                } while (lVar31 != uVar55 + -uVar34);
              }
              else {
                uVar52 = 0;
                lVar31 = 0;
                do {
                  auVar4._8_8_ = 0;
                  auVar4._0_8_ = uVar52;
                  uVar37 = SUB168(auVar4 * ZEXT816(10),0);
                  if (SUB168(auVar4 * ZEXT816(10),8) != 0) goto LAB_14001aeb0;
                  uVar66 = (byte)pcVar35[lVar31 + uVar34] - 0x30;
                  uVar52 = uVar37 + uVar66;
                  if ((9 < uVar66) || (CARRY8(uVar37,(ulonglong)uVar66))) goto LAB_14001aeb0;
                  lVar31 = lVar31 + 1;
                } while (lVar31 != uVar55 + -uVar34);
              }
              if (uVar52 <= DAT_1406994e0) goto LAB_14001aeb0;
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into(&DAT_1406a0be6,7);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              if ((*pcVar35 != '\x02') || (*(longlong *)(pcVar35 + 8) == 2)) goto LAB_14001aeb0;
              if ((int)*(longlong *)(pcVar35 + 8) == 1) {
                lVar31 = *(longlong *)(pcVar35 + 0x10);
              }
              else {
                lVar31 = *(longlong *)(pcVar35 + 0x10);
                if (lVar31 < 0) goto LAB_14001aeb0;
              }
              if (lVar31 != 1) goto LAB_14001aeb0;
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into(&DAT_1406a0bed,5);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              if ((*pcVar35 != '\x03') || (*(size_t *)(pcVar35 + 0x18) != DAT_140699098))
              goto LAB_14001aeb0;
              iVar29 = memcmp(*(void **)(pcVar35 + 0x10),DAT_140699090,DAT_140699098);
              if (iVar29 != 0) goto LAB_14001aeb0;
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into("expires_unix_ms",0xf);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              if ((((*pcVar35 != '\x02') || (*(longlong *)(pcVar35 + 8) != 0)) ||
                  (*(ulonglong *)(pcVar35 + 0x10) < uVar38)) ||
                 (5000 < *(ulonglong *)(pcVar35 + 0x10) - uVar38)) goto LAB_14001aeb0;
              DAT_1406994e0 = uVar52;
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into(&DAT_1406a0bf2,7);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              if (*pcVar35 != '\x03') goto LAB_14001aeb0;
              piVar2 = *(int **)(pcVar35 + 0x10);
              lVar31 = *(longlong *)(pcVar35 + 0x18);
              if (lVar31 == 6) {
                if ((short)piVar2[1] == 0x6574 && *piVar2 == 0x756d6e75) {
LAB_14001da10:
                  pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                    index_into(&DAT_1406a0bfc,4);
                  if (pcVar35 == (char *)0x0) {
                    pcVar35 = 
                    __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                    ;
                  }
                  if (*pcVar35 == '\x03') {
                    ::<u64>::from_ascii_bytes_radix_impl(&local_330,*(undefined8 *)(pcVar35 + 0x10))
                    ;
                    pauVar61 = local_328;
                    if ((char)local_330 != '\x01') {
                      <str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                (&DAT_1406a0bf2,7);
                      if (DAT_1406993e8 == DAT_1406993f0) {
                        <reach_directory[4b72b9694f6c3c08]::chat::HostRelay>::set_muted
                                  (&DAT_1406990f0,pauVar61);
                      }
                    }
                  }
                }
                goto LAB_14001aeb0;
              }
              if (lVar31 == 4) {
                if (*piVar2 == 0x6574756d) goto LAB_14001da10;
                goto LAB_14001aeb0;
              }
              if ((lVar31 != 3) ||
                 (*(char *)((longlong)piVar2 + 2) != 'y' || (short)*piVar2 != 0x6173))
              goto LAB_14001aeb0;
              pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                index_into("text",4,&local_318);
              if (pcVar35 == (char *)0x0) {
                pcVar35 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              if (*pcVar35 == '\x03') {
                uVar57 = *(undefined8 *)(pcVar35 + 0x10);
                uVar58 = *(undefined8 *)(pcVar35 + 0x18);
              }
              else {
                uVar57 = 1;
                uVar58 = 0;
              }
              <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::announce
                        (&local_330,&DAT_140699030,uVar57,uVar58,local_1c0,
                         CONCAT44(uVar78,local_334));
            }
            else {
LAB_14001aeb0:
              local_330 = (undefined1 (*) [16])0x0;
              local_328 = (undefined1 (*) [16])&DAT_00000008;
              local_320 = (undefined1 (*) [16])0x0;
            }
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (&local_318);
            uStack_300 = local_328 + (longlong)local_320 * 2;
            local_318 = (byte)local_328;
            bStack_317 = (byte)((ulonglong)local_328 >> 8);
            sStack_316 = (short)((ulonglong)local_328 >> 0x10);
            uStack_314 = (undefined4)((ulonglong)local_328 >> 0x20);
            uStack_308 = SUB81(local_330,0);
            uStack_307 = (undefined1)((ulonglong)local_330 >> 8);
            sStack_306 = (short)((ulonglong)local_330 >> 0x10);
            uStack_304 = (undefined4)((ulonglong)local_330 >> 0x20);
            uStack_310._0_4_ = (uint)local_328;
            uStack_310._4_4_ = uStack_314;
            <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>>
            ::spec_extend(&local_1d8,&local_318);
            SVar22 = local_370;
          }
        }
        else {
          if ((1 < ((uint)uVar38 & 3) - 2) && ((uVar38 & 3) != 0)) {
            uStack_310 = (undefined1 (*) [16])(uVar38 - 1);
            local_318 = 3;
            <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
            ::drop(&uStack_310);
          }
          SVar22 = local_370;
          if (local_258[0] != 0xff) {
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (local_258);
            SVar22 = local_370;
          }
        }
      }
      local_370 = 0;
      if (SVar22 != 0) {
        local_370 = SVar22;
        __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar56,SVar22,1);
        return;
      }
    }
    if (local_278 != (undefined8 *)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar39,local_278,1);
      return;
    }
    uStack_300 = (undefined1 (*) [16])(local_1d0 + (longlong)local_1c8 * 4);
    local_318 = (byte)local_1d0;
    bStack_317 = (byte)((ulonglong)local_1d0 >> 8);
    sStack_316 = (short)((ulonglong)local_1d0 >> 0x10);
    uStack_314 = (undefined4)((ulonglong)local_1d0 >> 0x20);
    uStack_308 = SUB81(local_1d8,0);
    uStack_307 = (undefined1)((ulonglong)local_1d8 >> 8);
    sStack_306 = (short)((ulonglong)local_1d8 >> 0x10);
    uStack_304 = (undefined4)((ulonglong)local_1d8 >> 0x20);
    uStack_310._0_4_ = (uint)local_1d0;
    uStack_310._4_4_ = uStack_314;
    <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>>
    ::spec_extend(&local_190,&local_318);
  }
  else {
    pauVar39 = DAT_140699460;
    lVar31 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&local_178);
    if ((lVar31 != 0) || (99999999 < (uint)pauVar39)) goto LAB_14001a28f;
  }
  pauVar33 = DAT_140699240;
  pauVar61 = DAT_140699238;
  pauVar39 = DAT_140699228;
  local_1d8 = local_1c0;
  local_1d0 = (undefined8 *)CONCAT44(local_1d0._4_4_,local_334);
  local_330 = (undefined1 (*) [16])0x0;
  local_328 = (undefined1 (*) [16])&DAT_00000008;
  local_320 = (undefined1 (*) [16])0x0;
  if (DAT_140699240 == (undefined1 (*) [16])0x0) {
    pauVar42 = (undefined1 (*) [16])0x0;
    pauVar39 = (undefined1 (*) [16])0x0;
    goto LAB_14001b1e9;
  }
  pauVar60 = DAT_140699230 + (longlong)DAT_140699238 * 3 + 2;
  pauVar42 = (undefined1 (*) [16])0x0;
  do {
    pauVar64 = (undefined1 (*) [16])0x0;
    if (pauVar39 <= (undefined1 (*) [16])((longlong)*pauVar42 + (longlong)*pauVar61)) {
      pauVar64 = pauVar39;
    }
    uVar38 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                       (&local_1d8,
                        *(undefined8 *)((longlong)pauVar60[(longlong)pauVar64 * -3 + -1] + 8));
    pauVar53 = DAT_140699238;
    pauVar64 = DAT_140699228;
    if (1 < uVar38) {
      pauVar39 = (undefined1 (*) [16])((longlong)*pauVar42 + 1);
      if (pauVar33 <= pauVar39) goto LAB_14001b1e9;
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      local_348 = pauVar33;
      if (pauVar33 < pauVar42) {
        local_348 = pauVar42;
      }
      local_340 = DAT_140699230;
      pauVar61 = uStack_300;
      goto LAB_14001b0d0;
    }
    pauVar42 = (undefined1 (*) [16])((longlong)*pauVar42 + 1);
    pauVar60 = pauVar60 + 3;
  } while (pauVar33 != pauVar42);
  goto LAB_14001b298;
LAB_140019435:
  do {
    if (*(longlong *)((longlong)*pauVar33 + pauVar39 * 8) ==
        *(longlong *)((longlong)pauVar33[-1] + (undefined1 *)((longlong)*local_268 + 1) * 8)) {
      lVar31 = *(longlong *)((longlong)*pauVar33 + (undefined1 *)((longlong)*pauVar39 + 1) * 8);
      if (lVar31 != *(longlong *)
                     ((longlong)pauVar33[-1] + (undefined1 *)((longlong)*local_268 + 1) * 8)) {
LAB_140019461:
        *(longlong *)((longlong)*pauVar33 + local_268 * 8) = lVar31;
        local_268 = (undefined1 (*) [16])((longlong)*local_268 + 1);
      }
    }
    else {
      *(longlong *)((longlong)*pauVar33 + local_268 * 8) =
           *(longlong *)((longlong)*pauVar33 + pauVar39 * 8);
      puVar44 = (undefined8 *)*local_268;
      local_268 = (undefined1 (*) [16])((longlong)puVar44 + 1);
      lVar31 = *(longlong *)((longlong)*pauVar33 + (undefined1 *)((longlong)*pauVar39 + 1) * 8);
      if (lVar31 != *(longlong *)((longlong)*pauVar33 + puVar44 * 8)) goto LAB_140019461;
    }
    pauVar39 = (undefined1 (*) [16])((longlong)*pauVar39 + 2);
    pauVar61 = local_268;
  } while (pauVar60 != pauVar39);
LAB_14001940d:
  pauVar42 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310);
joined_r0x000140019421:
  if (pauVar61 == (undefined1 (*) [16])0x1) {
    local_370._0_4_ = 0;
    local_370._4_4_ = 0;
    pauVar39 = (undefined1 (*) [16])0xffffffffffffffff;
    BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,puVar51 + 0x20,&local_318,0x20,&local_370)
    ;
    pauVar42 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310);
    if ((BVar28 != 0) &&
       (pauVar42 = (undefined1 (*) [16])CONCAT44(uStack_310._4_4_,(uint)uStack_310),
       CONCAT44(local_370._4_4_,(int)local_370) == 0x20)) {
      local_248 = uStack_308;
      uStack_247 = uStack_307;
      sStack_246 = sStack_306;
      sStack_244 = (short)uStack_304;
      uStack_242 = (undefined1)((uint)uStack_304 >> 0x10);
      uStack_241 = (undefined1)((uint)uStack_304 >> 0x18);
      uStack_240 = (undefined1)(undefined4)uStack_300;
      uStack_23f = (undefined1)((uint)(undefined4)uStack_300 >> 8);
      sStack_23e = (short)((uint)(undefined4)uStack_300 >> 0x10);
      sStack_23c = (short)uStack_300._4_4_;
      uStack_23a = (undefined1)((uint)uStack_300._4_4_ >> 0x10);
      uStack_239 = (undefined1)((uint)uStack_300._4_4_ >> 0x18);
      local_258[0] = local_318;
      local_258[1] = bStack_317;
      sStack_256 = sStack_316;
      sStack_254 = (short)uStack_314;
      sStack_252 = (short)((uint)uStack_314 >> 0x10);
      bStack_250 = (byte)(uint)uStack_310;
      uStack_24f = (undefined1)((uint)uStack_310 >> 8);
      sStack_24e = (short)((uint)uStack_310 >> 0x10);
      sStack_24c = (short)uStack_310._4_4_;
      uStack_24a = (undefined1)((uint)uStack_310._4_4_ >> 0x10);
      uStack_249 = (undefined1)((uint)uStack_310._4_4_ >> 0x18);
      if (CONCAT11(bStack_317,local_318) == 0) {
        lVar31 = 0;
      }
      else if (sStack_316 == 0) {
        lVar31 = 1;
      }
      else if (sStack_254 == 0) {
        lVar31 = 2;
      }
      else if (sStack_252 == 0) {
        lVar31 = 3;
      }
      else if ((short)(uint)uStack_310 == 0) {
        lVar31 = 4;
      }
      else if (sStack_24e == 0) {
        lVar31 = 5;
      }
      else if (sStack_24c == 0) {
        lVar31 = 6;
      }
      else if ((short)((uint)uStack_310._4_4_ >> 0x10) == 0) {
        lVar31 = 7;
      }
      else if (CONCAT11(uStack_307,uStack_308) == 0) {
        lVar31 = 8;
      }
      else if (sStack_306 == 0) {
        lVar31 = 9;
      }
      else if (sStack_244 == 0) {
        lVar31 = 10;
      }
      else if ((short)((uint)uStack_304 >> 0x10) == 0) {
        lVar31 = 0xb;
      }
      else if ((short)(undefined4)uStack_300 == 0) {
        lVar31 = 0xc;
      }
      else if (sStack_23e == 0) {
        lVar31 = 0xd;
      }
      else if (sStack_23c == 0) {
        lVar31 = 0xe;
      }
      else {
        lVar31 = 0x10 - (ulonglong)((short)((uint)uStack_300._4_4_ >> 0x10) == 0);
      }
      uStack_310 = (undefined1 (*) [16])(local_258 + lVar31 * 2);
      local_318 = (byte)local_258;
      bStack_317 = (byte)((ulonglong)local_258 >> 8);
      sStack_316 = (short)((ulonglong)local_258 >> 0x10);
      uStack_314 = (undefined4)((ulonglong)local_258 >> 0x20);
      uStack_308 = 0;
      uStack_307 = 0;
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::FromIterator<char>>
      ::from_iter::
      <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::char::decode::DecodeUtf16<core[505b25137b8ba7f]::iter::adapters::cloned::Cloned<core[505b25137b8ba7f]::slice::iter::Iter<u16>>>,<alloc[246c2e7857c81348]::string::String>::from_utf16_lossy::_closure_0_>>
                (&local_370,&local_318);
      uVar56 = CONCAT71(uStack_367,uStack_368);
      reach_directory[4b72b9694f6c3c08]::chat::clean
                (&local_318,uVar56,CONCAT44(uStack_35c,uStack_360));
      pauVar39 = (undefined1 (*) [16])
                 CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)));
      if (pauVar39 == (undefined1 (*) [16])0xffffffffffffffff) {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        pauVar61 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_alloc(6,1);
        if (pauVar61 == (undefined1 (*) [16])0x0) {
          alloc[246c2e7857c81348]::raw_vec::handle_error(1,6);
          goto LAB_14001db96;
        }
        *(undefined2 *)(*pauVar61 + 4) = 0x7265;
        *(undefined4 *)*pauVar61 = 0x79616c50;
        uVar57 = 6;
        local_1e0 = (undefined1 (*) [16])&DAT_00000006;
      }
      else {
        uVar57 = CONCAT44(uStack_304,CONCAT22(sStack_306,CONCAT11(uStack_307,uStack_308)));
        pauVar61 = uStack_310;
        local_1e0 = pauVar39;
      }
      if (CONCAT44(local_370._4_4_,(int)local_370) != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar56,CONCAT44(local_370._4_4_,(int)local_370),1)
        ;
        return;
      }
      local_318 = 0;
      bStack_317 = 0;
      sStack_316 = 0;
      uStack_314 = 0;
      BVar28 = ReadProcessMemory((HANDLE)0xffffffffffffffff,puVar51 + 0x98,&local_370,1,
                                 (SIZE_T *)&local_318);
      pauVar39 = local_320;
      bVar27 = 0xff;
      if ((byte)local_370 < 8 &&
          (CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318))) == 1 &&
          BVar28 != 0)) {
        bVar27 = -((~matchrules::COLORS & 0x81) != 0) | (byte)local_370;
      }
      uVar56 = *(undefined8 *)*pauStack_270;
      if (local_320 == local_330) {
        <alloc[246c2e7857c81348]::raw_vec::RawVec<reach_directory[4b72b9694f6c3c08]::chat::Player>>
        ::grow_one(&local_330);
      }
      *(undefined1 (**) [16])((longlong)local_328 + (longlong)pauVar39 * 0x28) = local_1e0;
      *(undefined1 (**) [16])((longlong)local_328 + (longlong)pauVar39 * 0x28 + 8) = pauVar61;
      *(undefined8 *)((longlong)local_328 + (longlong)pauVar39 * 0x28 + 0x10) = uVar57;
      *(undefined8 *)((longlong)local_328 + (longlong)pauVar39 * 0x28 + 0x18) = uVar56;
      *(int *)((longlong)local_328 + (longlong)pauVar39 * 0x28 + 0x20) = (int)uVar55 + 1;
      *(byte *)((longlong)local_328 + (longlong)pauVar39 * 0x28 + 0x24) = bVar27;
      local_320 = (undefined1 (*) [16])((longlong)*pauVar39 + 1);
      pauVar39 = local_328;
      pauVar42 = uStack_310;
    }
  }
  if (local_278 != (undefined8 *)0x0) {
    uStack_310 = pauVar42;
    __rustc[9d087a5ab36ea756]::__rust_dealloc(pauStack_270,(longlong)local_278 << 3,8);
    return;
  }
LAB_140018d80:
  uVar55 = uVar55 + 1;
  pauVar60 = local_330;
  pauVar33 = local_320;
  pauVar61 = local_328;
  if (uVar55 == 0x40) goto LAB_1400194a2;
  goto LAB_140018d8d;
  while( true ) {
    puVar48 = (undefined1 *)((longlong)*pauVar33 + lVar49);
    puVar46 = (undefined1 *)0x0;
    if (puVar51 <= puVar48) {
      puVar46 = puVar51;
    }
    pvVar43 = (void *)(((longlong)puVar48 - (longlong)puVar46) * 0xa0 + local_1b8);
    local_150 = lVar49;
    memcpy(&local_318,pvVar43,0xa0);
    memmove(pvVar43,puVar44,0xa0);
    lVar49 = local_150;
    memcpy(puVar44,&local_318,0xa0);
    pauVar42 = (undefined1 (*) [16])((longlong)*pauVar60 + 1);
    pauVar33 = (undefined1 (*) [16])((longlong)*pauVar33 + 1);
    if (local_348 <= pauVar42) break;
LAB_14001baf8:
    lVar31 = (longlong)((longlong)*pauVar42 + lVar49) * 0xa0 + lVar65;
    while( true ) {
      pauVar60 = pauVar42;
      puVar48 = (undefined1 *)0x0;
      if (puVar51 <= (undefined1 *)((longlong)*pauVar60 + lVar49)) {
        puVar48 = puVar51;
      }
      puVar44 = (undefined8 *)(lVar31 + (longlong)puVar48 * -0xa0);
      uVar38 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                         (&local_1d8,*puVar44,*(undefined4 *)(puVar44 + 1));
      lVar65 = local_1b8;
      if (uVar38 < 4) break;
      pauVar42 = (undefined1 (*) [16])((longlong)*pauVar60 + 1);
      lVar31 = lVar31 + 0xa0;
      if (local_348 <= pauVar42) goto LAB_14001bc10;
    }
    if (pauVar33 == local_1e0) goto LAB_14001d367;
  }
LAB_14001bc10:
  pauVar61 = local_1a0;
  lVar31 = local_1e8;
  if ((undefined1 (*) [16])((longlong)*pauVar60 + 1) != pauVar33) {
LAB_14001bc47:
    <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>
    ::truncate();
  }
LAB_14001bc5c:
  uVar38 = *(ulonglong *)((longlong)local_1b0[-2] + 8);
  if (uVar38 == 0) {
    lVar49 = 0;
    uVar55 = 0;
    lVar65 = 0;
  }
  else {
    uVar55 = *(ulonglong *)local_1b0[-3];
    uVar34 = 0;
    if (uVar55 <= *(ulonglong *)local_1b0[-2]) {
      uVar34 = uVar55;
    }
    lVar49 = *(ulonglong *)local_1b0[-2] - uVar34;
    lVar65 = uVar38 - (uVar55 - lVar49);
    if (uVar38 < uVar55 - lVar49 || lVar65 == 0) {
      uVar55 = uVar38 + lVar49;
      lVar65 = 0;
    }
  }
  uVar66 = uVar66 - 1 & uVar66;
  local_1e8 = lVar31 + -1;
  local_348 = *(undefined1 (**) [16])((longlong)local_1b0[-3] + 8);
  pauVar33 = local_348 + lVar49 * 10;
  pauVar42 = local_348 + uVar55 * 10;
  pauVar60 = local_348 + lVar65 * 10;
  local_340 = (undefined1 (*) [16])&DAT_00000020;
LAB_14001bd73:
  pauVar53 = local_348;
  for (pauVar64 = pauVar33; local_348 = pauVar53, pauVar64 != pauVar42; pauVar64 = pauVar64 + 10) {
    if (*(byte *)((longlong)pauVar64[9] + 8) < 5) {
      uVar56 = *(undefined8 *)pauVar64[1];
      lVar31 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                         (&local_1d8,uVar56,*(undefined4 *)((longlong)pauVar64[1] + 8));
      uVar78 = (undefined4)((ulonglong)in_stack_fffffffffffffc80 >> 0x20);
      if ((lVar31 != 0) || (299999999 < (uint)uVar56)) {
        pauVar33 = pauVar64 + 10;
        pauVar53 = pauVar64;
        goto LAB_14001be25;
      }
    }
    pauVar53 = local_348;
  }
  if (pauVar53 != pauVar60) {
    do {
      if (*(byte *)((longlong)pauVar53[9] + 8) < 5) {
        uVar56 = *(undefined8 *)pauVar53[1];
        lVar31 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                           (&local_1d8,uVar56,*(undefined4 *)((longlong)pauVar53[1] + 8));
        uVar78 = (undefined4)((ulonglong)in_stack_fffffffffffffc80 >> 0x20);
        if ((lVar31 != 0) || (299999999 < (uint)uVar56)) goto LAB_14001be16;
      }
      pauVar53 = pauVar53 + 10;
      if (pauVar53 == pauVar60) break;
    } while( true );
  }
  goto LAB_14001b9c0;
LAB_14001d367:
  core[505b25137b8ba7f]::panicking::panic
            (&anon_d5c34e88a06ee720b116585eb143da4b_235_llvm_14435704873730135342,0x20,
             &anon_d5c34e88a06ee720b116585eb143da4b_236_llvm_14435704873730135342);
  goto LAB_14001db96;
LAB_14001be16:
  local_348 = pauVar53 + 10;
  pauVar33 = pauVar42;
LAB_14001be25:
  *(char *)((longlong)pauVar53[9] + 8) = *(char *)((longlong)pauVar53[9] + 8) + '\x01';
  *(undefined1 (**) [16])pauVar53[1] = local_1c0;
  *(int *)((longlong)pauVar53[1] + 8) = local_334;
  uVar56 = *(undefined8 *)local_1b0[-5];
  in_stack_fffffffffffffc80 = (undefined1 (*) [16])CONCAT44(uVar78,local_334);
  <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::delivery
            (&local_318,DAT_140699090,DAT_140699098,*(undefined8 *)local_1b0[-4],
             *(undefined8 *)((longlong)local_1b0[-4] + 8),pauVar53,local_1c0,
             in_stack_fffffffffffffc80);
  pauVar64 = local_320;
  local_1e0 = (undefined1 (*) [16])
              CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)));
  local_1a0 = uStack_310;
  local_1b8 = CONCAT44(uStack_304,CONCAT22(sStack_306,CONCAT11(uStack_307,uStack_308)));
  if (local_320 == local_330) {
    <alloc[246c2e7857c81348]::raw_vec::RawVec<(usize,[i32;6usize])>>::grow_one(&local_330);
  }
  local_340 = (undefined1 (*) [16])((longlong)local_340[-1] + 0xf);
  *(undefined8 *)local_328[(longlong)pauVar64 * 2] = uVar56;
  *(undefined1 (**) [16])((longlong)local_328[(longlong)pauVar64 * 2] + 8) = local_1e0;
  *(undefined1 (**) [16])local_328[(longlong)pauVar64 * 2 + 1] = local_1a0;
  *(longlong *)((longlong)local_328[(longlong)pauVar64 * 2 + 1] + 8) = local_1b8;
  local_320 = (undefined1 (*) [16])((longlong)*pauVar64 + 1);
  if (local_340 == (undefined1 (*) [16])0x0) goto LAB_14001b9c0;
  goto LAB_14001bd73;
LAB_14001b9c0:
  lVar31 = local_1e8;
  if (local_1e8 == 0) goto LAB_14001bede;
  goto LAB_14001b9d1;
code_r0x00014001cced:
  if (lVar31 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar56,lVar31,1);
    return;
  }
  pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_or_insert
                              ("lines",5,&local_370);
  if (*pcVar35 == '\x04') {
    if (*(longlong *)(pcVar35 + 0x18) == 0) {
LAB_14001cf60:
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                (&local_370);
      goto LAB_14001cf6a;
    }
    _Dst = *(char **)(pcVar35 + 0x10);
    cVar26 = *_Dst;
    uVar56 = *(undefined8 *)(_Dst + 0x10);
    uVar57 = *(undefined8 *)(_Dst + 0x18);
    local_248 = (undefined1)((ulonglong)uVar56 >> 8);
    uStack_247 = (undefined1)((ulonglong)uVar56 >> 0x10);
    sStack_246 = (short)((ulonglong)uVar56 >> 0x18);
    sStack_244 = (short)((ulonglong)uVar56 >> 0x28);
    uStack_242 = (undefined1)((ulonglong)uVar56 >> 0x38);
    uStack_241 = (undefined1)uVar57;
    uStack_240 = (undefined1)((ulonglong)uVar57 >> 8);
    uStack_23f = (undefined1)((ulonglong)uVar57 >> 0x10);
    sStack_23e = (short)((ulonglong)uVar57 >> 0x18);
    sStack_23c = (short)((ulonglong)uVar57 >> 0x28);
    uStack_23a = (undefined1)((ulonglong)uVar57 >> 0x38);
    uVar56 = *(undefined8 *)(_Dst + 1);
    uVar57 = *(undefined8 *)(_Dst + 9);
    local_258[0] = (byte)uVar56;
    local_258[1] = (byte)((ulonglong)uVar56 >> 8);
    sStack_256 = (short)((ulonglong)uVar56 >> 0x10);
    sStack_254 = (short)((ulonglong)uVar56 >> 0x20);
    sStack_252 = (short)((ulonglong)uVar56 >> 0x30);
    bStack_250 = (byte)uVar57;
    uStack_24f = (undefined1)((ulonglong)uVar57 >> 8);
    sStack_24e = (short)((ulonglong)uVar57 >> 0x10);
    sStack_24c = (short)((ulonglong)uVar57 >> 0x20);
    uStack_24a = (undefined1)((ulonglong)uVar57 >> 0x30);
    uStack_249 = (undefined1)((ulonglong)uVar57 >> 0x38);
    lVar31 = *(longlong *)(pcVar35 + 0x18) + -1;
    memmove(_Dst,_Dst + 0x20,lVar31 * 0x20);
    *(longlong *)(pcVar35 + 0x18) = lVar31;
    if (cVar26 == -1) {
      <alloc[246c2e7857c81348]::vec::Vec<_,_>>::remove::assert_failed(0,lVar31,&DAT_1406a0d48);
      goto LAB_14001db96;
    }
    uVar19 = CONCAT23(sStack_23e,CONCAT12(uStack_23f,CONCAT11(uStack_240,uStack_241)));
    uStack_307 = local_248;
    sStack_306 = (short)CONCAT21(sStack_246,uStack_247);
    uStack_304 = (undefined4)
                 (CONCAT15(uStack_242,CONCAT23(sStack_244,CONCAT21(sStack_246,uStack_247))) >> 0x10)
    ;
    uStack_300._0_4_ = (undefined4)uVar19;
    uStack_300._4_4_ = (undefined4)(CONCAT17(uStack_23a,CONCAT25(sStack_23c,uVar19)) >> 0x20);
    uVar78 = CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]));
    uVar47 = CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250));
    bStack_317 = local_258[0];
    sStack_316 = (short)((uint)uVar78 >> 8);
    uStack_314 = (undefined4)(CONCAT26(sStack_252,CONCAT24(sStack_254,uVar78)) >> 0x18);
    uStack_310._0_1_ = (byte)((ushort)sStack_252 >> 8);
    uStack_310._1_3_ = (undefined3)uVar47;
    uStack_310._4_4_ = (undefined4)(CONCAT16(uStack_24a,CONCAT24(sStack_24c,uVar47)) >> 0x18);
    uStack_308 = uStack_249;
    local_318 = cVar26;
    core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(&local_318);
  }
  goto LAB_14001cc78;
  while( true ) {
    pauVar61 = (undefined1 (*) [16])((longlong)*pauVar53 + (longlong)*pauVar42);
    pauVar60 = (undefined1 (*) [16])0x0;
    if (pauVar64 <= pauVar61) {
      pauVar60 = pauVar64;
    }
    lVar31 = (longlong)pauVar61 - (longlong)pauVar60;
    uVar56 = *(undefined8 *)local_340[lVar31 * 3];
    uStack_310 = *(undefined1 (**) [16])((longlong)local_340[lVar31 * 3] + 8);
    pauVar60 = local_340 + lVar31 * 3 + 1;
    uVar57 = *(undefined8 *)*pauVar60;
    pauVar61 = *(undefined1 (**) [16])((longlong)*pauVar60 + 8);
    auVar20 = *(undefined1 (*) [12])*pauVar60;
    pauVar60 = local_340 + lVar31 * 3 + 2;
    local_2f8 = *(byte **)*pauVar60;
    auVar21 = *(undefined1 (*) [12])*pauVar60;
    uStack_2f0._0_4_ = (undefined4)*(undefined8 *)((longlong)*pauVar60 + 8);
    uStack_2f0._4_4_ = (uint)((ulonglong)*(undefined8 *)((longlong)*pauVar60 + 8) >> 0x20);
    uStack_308 = (undefined1)uVar57;
    uStack_307 = (undefined1)((ulonglong)uVar57 >> 8);
    sStack_306 = (short)((ulonglong)uVar57 >> 0x10);
    uStack_304 = (undefined4)((ulonglong)uVar57 >> 0x20);
    uStack_300._4_4_ = (undefined4)((ulonglong)pauVar61 >> 0x20);
    local_318 = (byte)uVar56;
    bStack_317 = (byte)((ulonglong)uVar56 >> 8);
    sStack_316 = (short)((ulonglong)uVar56 >> 0x10);
    uStack_314 = (undefined4)((ulonglong)uVar56 >> 0x20);
    uVar57 = *(undefined8 *)((longlong)*pauVar39 + 8);
    uVar58 = *(undefined8 *)pauVar39[1];
    uVar13 = *(undefined8 *)((longlong)pauVar39[1] + 8);
    uVar14 = *(undefined8 *)pauVar39[2];
    uVar15 = *(undefined8 *)((longlong)pauVar39[2] + 8);
    *(undefined8 *)local_340[lVar31 * 3] = *(undefined8 *)*pauVar39;
    *(undefined8 *)((longlong)local_340[lVar31 * 3] + 8) = uVar57;
    *(undefined8 *)local_340[lVar31 * 3 + 1] = uVar58;
    *(undefined8 *)((longlong)local_340[lVar31 * 3 + 1] + 8) = uVar13;
    *(undefined8 *)local_340[lVar31 * 3 + 2] = uVar14;
    *(undefined8 *)((longlong)local_340[lVar31 * 3 + 2] + 8) = uVar15;
    auVar17._12_4_ = uStack_300._4_4_;
    auVar17._0_12_ = auVar20;
    auVar18._12_4_ = uStack_2f0._4_4_;
    auVar18._0_12_ = auVar21;
    pauVar39[2] = auVar18;
    pauVar39[1] = auVar17;
    *(undefined8 *)*pauVar39 = uVar56;
    *(undefined1 (**) [16])((longlong)*pauVar39 + 8) = uStack_310;
    pauVar39 = (undefined1 (*) [16])((longlong)*pauVar68 + 1);
    pauVar42 = (undefined1 (*) [16])((longlong)*pauVar42 + 1);
    uStack_300 = pauVar61;
    if (pauVar33 <= pauVar39) break;
LAB_14001b0d0:
    pauVar60 = local_340 + (longlong)((longlong)*pauVar39 + (longlong)*pauVar53) * 3;
    uStack_300 = pauVar61;
    while( true ) {
      pauVar68 = pauVar39;
      pauVar39 = pauVar64;
      if ((undefined1 (*) [16])((longlong)*pauVar68 + (longlong)*pauVar53) < pauVar64) {
        pauVar39 = (undefined1 (*) [16])0x0;
      }
      pauVar39 = pauVar60 + (longlong)pauVar39 * -3;
      uVar38 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                         (&local_1d8,*(undefined8 *)((longlong)pauVar39[1] + 8));
      if (uVar38 < 2) break;
      pauVar39 = (undefined1 (*) [16])((longlong)*pauVar68 + 1);
      pauVar60 = pauVar60 + 3;
      if (pauVar33 <= pauVar39) goto LAB_14001b1e6;
    }
    if (pauVar42 == local_348) goto LAB_14001d367;
  }
LAB_14001b1e6:
  pauVar39 = (undefined1 (*) [16])((longlong)*pauVar68 + 1);
LAB_14001b1e9:
  if ((pauVar39 != pauVar42) && (pauVar42 < pauVar33)) {
    pauVar39 = DAT_140699228;
    if (DAT_140699238 < DAT_140699228) {
      pauVar39 = (undefined1 (*) [16])0x0;
    }
    lVar31 = (longlong)DAT_140699238 - (longlong)pauVar39;
    pauVar60 = (undefined1 (*) [16])((longlong)DAT_140699228 - lVar31);
    pauVar61 = (undefined1 (*) [16])((longlong)pauVar33 - (longlong)pauVar60);
    if (pauVar33 < pauVar60) {
      pauVar61 = (undefined1 (*) [16])0x0;
    }
    pauVar64 = (undefined1 (*) [16])(lVar31 + (longlong)pauVar33);
    if (pauVar33 >= pauVar60 &&
        (undefined1 (*) [16])((longlong)pauVar33 - (longlong)pauVar60) != (undefined1 (*) [16])0x0)
    {
      pauVar64 = DAT_140699228;
    }
    pauVar64 = (undefined1 (*) [16])((longlong)pauVar64 - lVar31);
    lVar31 = (longlong)pauVar42 - (longlong)pauVar64;
    DAT_140699240 = pauVar42;
    if (pauVar42 < pauVar64 || lVar31 == 0) {
      lVar31 = (longlong)pauVar64 - (longlong)pauVar42;
      pauVar33 = DAT_140699230;
      if (lVar31 != 0) {
        puVar44 = (undefined8 *)
                  ((longlong)
                   DAT_140699230
                   [(longlong)pauVar39 * -3 + (longlong)pauVar42 * 3 + (longlong)DAT_140699238 * 3]
                  + 8);
        do {
          lVar49 = puVar44[-1];
          if ((lVar49 != -1) && (lVar49 != 0)) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar44,lVar49,1);
            return;
          }
          puVar44 = puVar44 + 6;
          lVar31 = lVar31 + -1;
        } while (lVar31 != 0);
      }
    }
    else {
      pauVar61 = (undefined1 (*) [16])((longlong)pauVar61 - lVar31);
      pauVar33 = DAT_140699230 + lVar31 * 3;
    }
    if (pauVar61 != (undefined1 (*) [16])0x0) {
      puVar44 = (undefined8 *)((longlong)*pauVar33 + 8);
      do {
        lVar31 = puVar44[-1];
        if ((lVar31 != -1) && (lVar31 != 0)) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar44,lVar31,1);
          return;
        }
        puVar44 = puVar44 + 6;
        pauVar61 = (undefined1 (*) [16])((longlong)pauVar61[-1] + 0xf);
      } while (pauVar61 != (undefined1 (*) [16])0x0);
    }
  }
LAB_14001b298:
  if (DAT_1406993e8 != DAT_1406993f0) {
    if (DAT_140699370 != -1) {
      pauVar39 = DAT_140699368;
      lVar31 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&local_1d8);
      if ((lVar31 == 0) && ((uint)pauVar39 < 500000000)) goto LAB_14001b6b1;
    }
    DAT_140699368 = local_1c0;
    DAT_140699370 = local_334;
    lVar31 = DAT_1406993f8 + 1;
    DAT_1406993f8 = lVar31;
    if (DAT_140699240 == DAT_140699228) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Probe>>
      ::grow(&DAT_140699228);
    }
    pauVar39 = DAT_140699230;
    pauVar33 = (undefined1 (*) [16])((longlong)*DAT_140699238 + (longlong)*DAT_140699240);
    pauVar61 = (undefined1 (*) [16])0x0;
    if (DAT_140699228 <= pauVar33) {
      pauVar61 = DAT_140699228;
    }
    lVar49 = (longlong)pauVar33 - (longlong)pauVar61;
    DAT_140699240 = (undefined1 (*) [16])((longlong)*DAT_140699240 + 1);
    *(undefined8 *)DAT_140699230[lVar49 * 3] = 0xffffffffffffffff;
    *(undefined1 (**) [16])((longlong)pauVar39[lVar49 * 3 + 1] + 8) = local_1c0;
    *(int *)pauVar39[lVar49 * 3 + 2] = local_334;
    *(longlong *)((longlong)pauVar39[lVar49 * 3 + 2] + 8) = lVar31;
    pauVar39 = DAT_1406993f0;
    local_278 = (undefined8 *)0x0;
    local_268 = (undefined1 (*) [16])0x0;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar56 = 4;
    puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
    if (puVar40 != (undefined4 *)0x0) {
      *puVar40 = 0x646e696b;
      local_370._0_4_ = 4;
      local_370._4_4_ = 0;
      uStack_368 = SUB81(puVar40,0);
      uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
      uStack_360 = 4;
      uStack_35c = 0;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
      if (puVar40 == (undefined4 *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(1,5);
        goto LAB_14001db96;
      }
      *(undefined1 *)(puVar40 + 1) = 0x65;
      *puVar40 = 0x626f7270;
      local_318 = 3;
      uStack_310._0_4_ = 5;
      uStack_310._4_4_ = 0;
      uStack_308 = SUB81(puVar40,0);
      uStack_307 = (undefined1)((ulonglong)puVar40 >> 8);
      sStack_306 = (short)((ulonglong)puVar40 >> 0x10);
      uStack_304 = (undefined4)((ulonglong)puVar40 >> 0x20);
      uStack_300._0_4_ = 5;
      uStack_300._4_4_ = 0;
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
      ::insert(local_258,&local_278,&local_370,&local_318);
      if (local_258[0] != 0xff) {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                  (local_258);
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar56 = 5;
      puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
      if (puVar40 != (undefined4 *)0x0) {
        *(undefined1 *)(puVar40 + 1) = 0x65;
        *puVar40 = 0x636e6f6e;
        sVar1 = DAT_1406990d0;
        pvVar43 = DAT_1406990c8;
        local_370._0_4_ = 5;
        local_370._4_4_ = 0;
        uStack_368 = SUB81(puVar40,0);
        uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
        uStack_360 = 5;
        uStack_35c = 0;
        if ((longlong)DAT_1406990d0 < 0) {
          uVar56 = 0;
LAB_14001b4c8:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uVar56,sVar1);
          goto LAB_14001db96;
        }
        if (DAT_1406990d0 == 0) {
          pvVar41 = (void *)0x1;
        }
        else {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar56 = 1;
          pvVar41 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
          if (pvVar41 == (void *)0x0) goto LAB_14001b4c8;
          memcpy(pvVar41,pvVar43,sVar1);
        }
        local_318 = 3;
        uStack_310._0_4_ = (uint)sVar1;
        uStack_310._4_4_ = (undefined4)(sVar1 >> 0x20);
        uStack_308 = SUB81(pvVar41,0);
        uStack_307 = (undefined1)((ulonglong)pvVar41 >> 8);
        sStack_306 = (short)((ulonglong)pvVar41 >> 0x10);
        uStack_304 = (undefined4)((ulonglong)pvVar41 >> 0x20);
        uStack_300._0_4_ = (uint)uStack_310;
        uStack_300._4_4_ = uStack_310._4_4_;
        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
        ::insert(local_258,&local_278,&local_370,&local_318);
        if (local_258[0] != 0xff) {
          core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                    (local_258);
        }
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar56 = 5;
        puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
        if (puVar40 != (undefined4 *)0x0) {
          *(undefined1 *)(puVar40 + 1) = 0x65;
          *puVar40 = 0x626f7270;
          local_370._0_4_ = 5;
          local_370._4_4_ = 0;
          uStack_368 = SUB81(puVar40,0);
          uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
          uStack_360 = 5;
          uStack_35c = 0;
          local_318 = 2;
          uStack_310._0_4_ = 0;
          uStack_310._4_4_ = 0;
          uStack_308 = (undefined1)DAT_1406993f8;
          uStack_307 = (undefined1)((ulonglong)DAT_1406993f8 >> 8);
          sStack_306 = (short)((ulonglong)DAT_1406993f8 >> 0x10);
          uStack_304 = (undefined4)((ulonglong)DAT_1406993f8 >> 0x20);
          <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
          ::insert(local_258,&local_278,&local_370,&local_318);
          if (local_258[0] != 0xff) {
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (local_258);
          }
          uStack_310._0_4_ = (uint)local_278;
          uStack_310._4_4_ = (undefined4)((ulonglong)local_278 >> 0x20);
          uStack_308 = SUB81(pauStack_270,0);
          uStack_307 = (undefined1)((ulonglong)pauStack_270 >> 8);
          sStack_306 = (short)((ulonglong)pauStack_270 >> 0x10);
          uStack_304 = (undefined4)((ulonglong)pauStack_270 >> 0x20);
          uStack_300._0_4_ = SUB84(local_268,0);
          uStack_300._4_4_ = (undefined4)((ulonglong)local_268 >> 0x20);
          local_318 = 5;
          transport::packet(local_258,&local_318);
          pauVar61 = local_320;
          uVar56 = CONCAT26(sStack_252,
                            CONCAT24(sStack_254,
                                     CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]))));
          uVar57 = CONCAT17(uStack_249,
                            CONCAT16(uStack_24a,
                                     CONCAT24(sStack_24c,
                                              CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250))))
                           );
          uVar58 = CONCAT17(uStack_241,
                            CONCAT16(uStack_242,
                                     CONCAT24(sStack_244,
                                              CONCAT22(sStack_246,CONCAT11(uStack_247,local_248)))))
          ;
          if (local_320 == local_330) {
            <alloc[246c2e7857c81348]::raw_vec::RawVec<(usize,[i32;6usize])>>::grow_one(&local_330);
          }
          *(undefined1 (**) [16])local_328[(longlong)pauVar61 * 2] = pauVar39;
          *(undefined8 *)((longlong)local_328[(longlong)pauVar61 * 2] + 8) = uVar56;
          *(undefined8 *)local_328[(longlong)pauVar61 * 2 + 1] = uVar57;
          *(undefined8 *)((longlong)local_328[(longlong)pauVar61 * 2 + 1] + 8) = uVar58;
          local_320 = (undefined1 (*) [16])((longlong)*pauVar61 + 1);
          goto LAB_14001b6b1;
        }
      }
    }
    alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar56);
    goto LAB_14001db96;
  }
LAB_14001b6b1:
  if (DAT_1406992b8 != -1) {
    uVar38 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                       (&local_1d8,DAT_1406992d0,DAT_1406992d8);
    lVar31 = DAT_1406992b8;
    if (3 < uVar38) {
      DAT_1406992b8 = -1;
      if (lVar31 == -1) {
        core[505b25137b8ba7f]::option::unwrap_failed(&PTR_s_src_ingame_chat_transport_rs_1406a12c0);
        goto LAB_14001db96;
      }
      local_118 = lVar31;
      memcpy(&pvStack_110,&DAT_1406992c0,0xa8);
      if (DAT_140699288 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_140699290,DAT_140699288,1);
        return;
      }
      DAT_140699298 = local_108;
      DAT_140699288 = local_118;
      DAT_140699290 = pvStack_110;
      core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                (local_e0);
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      pcVar35 = (char *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x3c,1);
      if (pcVar35 == (char *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x3c);
        goto LAB_14001db96;
      }
      builtin_strncpy(pcVar35,"Delivery is unconfirmed. Check history before sending again.",0x3c);
      if (DAT_1406992a0 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_1406992a8,DAT_1406992a0,1);
        return;
      }
      DAT_1406992a0 = 0x3c;
      DAT_1406992b0 = (undefined1 (*) [16])&DAT_0000003c;
      DAT_1406992a8 = pcVar35;
    }
    if ((DAT_1406992b8 != -1) && (DAT_140699364 < 5)) {
      pauVar39 = DAT_1406992e0;
      lVar31 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                         (&local_1d8,DAT_1406992e0,DAT_1406992e8);
      if ((lVar31 != 0) || (299999999 < (uint)pauVar39)) {
        DAT_140699364 = DAT_140699364 + 1;
        DAT_1406992e0 = local_1c0;
        DAT_1406992e8 = local_334;
        <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_core[505b25137b8ba7f]::clone::Clone>::
        clone(&local_318,&DAT_1406992f0);
        pauVar39 = DAT_1406993f0;
        uStack_1f0 = uStack_2b0;
        uStack_207 = uStack_2c7;
        local_217 = CONCAT17(uStack_2d0,uStack_2d7);
        uStack_20f = uStack_2cf;
        uStack_224 = CONCAT14((undefined1)uStack_2e0,uStack_2e4);
        uStack_21f = uStack_2e0._1_3_;
        uStack_21c = (undefined5)
                     (CONCAT17(uStack_2d8,CONCAT43(uStack_2dc,uStack_2e0._1_3_)) >> 0x18);
        uStack_237 = (undefined7)((ulonglong)local_2f8 >> 8);
        uStack_230 = (undefined4)uStack_2f0;
        uStack_22c = uStack_2f0._4_4_;
        uStack_228 = uStack_2e8;
        uStack_247 = uStack_307;
        sStack_246 = sStack_306;
        sStack_244 = (short)uStack_304;
        uStack_242 = (undefined1)((uint)uStack_304 >> 0x10);
        uStack_241 = (undefined1)((uint)uStack_304 >> 0x18);
        uStack_240 = (undefined1)uStack_300;
        uStack_23f = (undefined1)((ulonglong)uStack_300 >> 8);
        sStack_23e = (short)((ulonglong)uStack_300 >> 0x10);
        sStack_23c = (short)((ulonglong)uStack_300 >> 0x20);
        uStack_23a = (undefined1)((ulonglong)uStack_300 >> 0x30);
        uStack_239 = (undefined1)((ulonglong)uStack_300 >> 0x38);
        local_238 = (byte)local_2f8;
        local_258[1] = bStack_317;
        sStack_256 = sStack_316;
        sStack_254 = (short)uStack_314;
        sStack_252 = (short)((uint)uStack_314 >> 0x10);
        bStack_250 = (byte)uStack_310;
        uStack_24f = (undefined1)((ulonglong)uStack_310 >> 8);
        sStack_24e = (short)((ulonglong)uStack_310 >> 0x10);
        sStack_24c = (short)((ulonglong)uStack_310 >> 0x20);
        uStack_24a = (undefined1)((ulonglong)uStack_310 >> 0x30);
        uStack_249 = (undefined1)((ulonglong)uStack_310 >> 0x38);
        local_248 = uStack_308;
        local_258[0] = local_318;
        if (DAT_1406993e8 != DAT_1406993f0) {
          <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::say_packet
                    (&local_318,&DAT_140699030,local_258);
          pauVar33 = uStack_310;
          pauVar61 = local_320;
          uVar56 = CONCAT44(uStack_314,CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)));
          uVar57 = CONCAT44(uStack_304,CONCAT22(sStack_306,CONCAT11(uStack_307,uStack_308)));
          if (local_320 == local_330) {
            <alloc[246c2e7857c81348]::raw_vec::RawVec<(usize,[i32;6usize])>>::grow_one(&local_330);
          }
          *(undefined1 (**) [16])local_328[(longlong)pauVar61 * 2] = pauVar39;
          *(undefined8 *)((longlong)local_328[(longlong)pauVar61 * 2] + 8) = uVar56;
          *(undefined1 (**) [16])local_328[(longlong)pauVar61 * 2 + 1] = pauVar33;
          *(undefined8 *)((longlong)local_328[(longlong)pauVar61 * 2 + 1] + 8) = uVar57;
          local_320 = (undefined1 (*) [16])((longlong)*pauVar61 + 1);
        }
        core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                  (local_258);
      }
    }
  }
  if (DAT_1406993a0 != 0) {
    auVar71 = *DAT_140699388;
    uVar66 = ~(uint)(ushort)((ushort)(SUB161(auVar71 >> 7,0) & 1) |
                             (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                             (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                             (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                             (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                             (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                             (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                             (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                             (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                             (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                             (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                             (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                             (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                             (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                             (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
                            (ushort)(byte)(auVar71[0xf] >> 7) << 0xf);
    pauVar39 = DAT_140699388 + 1;
    pauVar61 = DAT_140699388;
    lVar31 = DAT_1406993a0;
LAB_14001b9d1:
    uVar59 = (ushort)uVar66;
    while (uVar59 == 0) {
      auVar71 = *pauVar39;
      pauVar61 = pauVar61 + -0x50;
      pauVar39 = pauVar39 + 1;
      uVar59 = ((ushort)(SUB161(auVar71 >> 7,0) & 1) | (ushort)(SUB161(auVar71 >> 0xf,0) & 1) << 1 |
                (ushort)(SUB161(auVar71 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar71 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar71 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar71 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar71 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar71 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar71 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar71 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar71 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar71 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar71 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar71 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar71 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar71[0xf] >> 7) << 0xf) ^ 0xffff;
      uVar66 = (uint)uVar59;
    }
    uVar62 = 0;
    for (uVar8 = uVar66; (uVar8 & 1) == 0; uVar8 = uVar8 >> 1 | 0x80000000) {
      uVar62 = uVar62 + 1;
    }
    local_340 = (undefined1 (*) [16])((ulonglong)uVar62 * -0x50);
    local_1b0 = (undefined1 (*) [16])(*pauVar61 + (longlong)*local_340);
    local_348 = *(undefined1 (**) [16])(pauVar61[-2] + (ulonglong)uVar62 * -0x50 + 8);
    if (local_348 != (undefined1 (*) [16])0x0) {
      lVar49 = *(longlong *)local_1b0[-2];
      puVar51 = *(undefined1 **)local_1b0[-3];
      lVar65 = *(longlong *)((longlong)local_1b0[-3] + 8) + lVar49 * 0xa0 + 8;
      pauVar33 = (undefined1 (*) [16])0x0;
      do {
        puVar48 = (undefined1 *)0x0;
        if (puVar51 <= (undefined1 *)((longlong)*pauVar33 + lVar49)) {
          puVar48 = puVar51;
        }
        puVar40 = (undefined4 *)(lVar65 + (longlong)puVar48 * -0xa0);
        uVar38 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                           (&local_1d8,*(undefined8 *)(puVar40 + -2),*puVar40);
        if (3 < uVar38) {
          pauVar42 = (undefined1 (*) [16])((longlong)*pauVar33 + 1);
          if (local_348 <= pauVar42) goto LAB_14001bc42;
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
          puVar44 = (undefined8 *)*local_340;
          lVar49 = *(longlong *)(pauVar61[-2] + (longlong)puVar44);
          puVar51 = *(undefined1 **)(pauVar61[-3] + (longlong)puVar44);
          lVar65 = *(longlong *)(pauVar61[-3] + (longlong)(puVar44 + 1));
          local_1e8 = lVar31;
          local_1e0 = local_348;
          local_1b8 = lVar65;
          local_1a0 = pauVar61;
          if (local_348 < pauVar33) {
            local_1e0 = pauVar33;
          }
          goto LAB_14001baf8;
        }
        pauVar33 = (undefined1 (*) [16])((longlong)*pauVar33 + 1);
        lVar65 = lVar65 + 0xa0;
      } while (local_348 != pauVar33);
      goto LAB_14001bc5c;
    }
    pauVar33 = (undefined1 (*) [16])0x0;
    pauVar42 = (undefined1 (*) [16])0x0;
LAB_14001bc42:
    if (pauVar42 == pauVar33) goto LAB_14001bc5c;
    goto LAB_14001bc47;
  }
LAB_14001bede:
  uStack_300 = local_328 + (longlong)local_320 * 2;
  local_318 = (byte)local_328;
  bStack_317 = (byte)((ulonglong)local_328 >> 8);
  sStack_316 = (short)((ulonglong)local_328 >> 0x10);
  uStack_314 = (undefined4)((ulonglong)local_328 >> 0x20);
  uStack_308 = SUB81(local_330,0);
  uStack_307 = (undefined1)((ulonglong)local_330 >> 8);
  sStack_306 = (short)((ulonglong)local_330 >> 0x10);
  uStack_304 = (undefined4)((ulonglong)local_330 >> 0x20);
  uStack_310._0_4_ = (uint)local_328;
  uStack_310._4_4_ = uStack_314;
  <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>>
  ::spec_extend(&local_190);
  if (DAT_140699478 != -1) {
    pauVar39 = DAT_140699470;
    lVar31 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&local_178);
    if ((lVar31 == 0) && ((uint)pauVar39 < 500000000)) {
LAB_14001cf6a:
      if (((char)local_1a4 == '\0') &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        local_194 = 0;
        cVar26 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar26 == '\0') {
          DAT_140699029 = '\x01';
        }
      }
      cVar26 = STATE;
      LOCK();
      STATE = '\0';
      UNLOCK();
      if (cVar26 == '\x02') {
        local_194 = 0;
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&STATE);
      }
      pauVar33 = local_188 + local_180 * 2;
      local_370._0_4_ = (int)local_188;
      local_370._4_4_ = (undefined4)((ulonglong)local_188 >> 0x20);
      uStack_368 = SUB81(local_188,0);
      uStack_367 = (undefined7)((ulonglong)local_188 >> 8);
      uStack_360 = (uint)local_190;
      uStack_35c = (undefined4)((ulonglong)local_190 >> 0x20);
      local_348 = local_188;
      pauVar39 = local_190;
      pauVar61 = local_188;
      pauStack_358 = pauVar33;
      if (local_180 != 0) {
        local_340 = local_190;
        iVar29 = -(uint)(CONCAT13(unaff_XMM6_Bd,
                                  CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))) ==
                        CONCAT13(unaff_XMM6_Bd,
                                 CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))));
        iVar23 = -(uint)(CONCAT13(unaff_XMM6_Bh,
                                  CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))) ==
                        CONCAT13(unaff_XMM6_Bh,
                                 CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))));
        iVar9 = -(uint)(CONCAT13(unaff_XMM6_Bl,
                                 CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))) ==
                       CONCAT13(unaff_XMM6_Bl,
                                CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))));
        iVar10 = -(uint)(CONCAT13(unaff_XMM6_Bp,
                                  CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))) ==
                        CONCAT13(unaff_XMM6_Bp,
                                 CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))));
        pauVar39 = local_188;
        do {
          pauVar42 = pauVar39 + 2;
          lVar31 = *(longlong *)((longlong)*pauVar39 + 8);
          pauVar61 = pauVar42;
          if (lVar31 == -1) break;
          puVar44 = *(undefined8 **)*pauVar39;
          uVar56 = *(undefined8 *)pauVar39[1];
          uVar57 = *(undefined8 *)((longlong)pauVar39[1] + 8);
          local_318 = 2;
          bStack_317 = 0;
          local_278 = puVar44;
          cVar26 = net::is_blocked(puVar44,&local_318);
          if ((cVar26 == '\0') && (DAT_140699990 == 0)) {
            LOCK();
            bVar69 = DAT_140699948 == '\0';
            if (bVar69) {
              DAT_140699948 = '\x01';
            }
            UNLOCK();
            if (!bVar69) {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                        (&DAT_140699948);
            }
            if ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) == 0) {
              bVar27 = 0;
              lVar49 = (longlong)uStack_310;
            }
            else {
              bVar27 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              bVar27 = bVar27 ^ 1;
              lVar49 = (longlong)uStack_310;
            }
            if (DAT_140699949 != '\0') {
              uStack_310._4_4_ = (undefined4)((ulonglong)lVar49 >> 0x20);
              uStack_368 = SUB81(pauVar42,0);
              uStack_367 = (undefined7)((ulonglong)pauVar42 >> 8);
              local_318 = 0x48;
              bStack_317 = 0x99;
              sStack_316 = 0x4069;
              uStack_314 = 1;
              uStack_310._1_3_ = (undefined3)((ulonglong)lVar49 >> 8);
              uStack_310._0_4_ = CONCAT31(uStack_310._1_3_,bVar27);
              core[505b25137b8ba7f]::result::unwrap_failed
                        ("called `Result::unwrap()` on an `Err` value",0x2b,&local_318,
                         &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                         &
                         PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2e88
                        );
              goto LAB_14001db96;
            }
            uStack_310 = (undefined1 (*) [16])lVar49;
            if (DAT_140699968 != 0) {
              uVar38 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                       ::hash_one::<&usize>(&DAT_140699970,&local_278);
              bVar70 = (byte)(uVar38 >> 0x39);
              auVar71 = ZEXT216(CONCAT11(bVar70,bVar70));
              auVar71 = pshuflw(auVar71,auVar71,0);
              lVar49 = 0;
              while( true ) {
                uVar38 = uVar38 & DAT_140699958;
                auVar72 = *(undefined1 (*) [16])(DAT_140699950 + uVar38);
                auVar77[0] = -(auVar72[0] == auVar71[0]);
                auVar77[1] = -(auVar72[1] == auVar71[1]);
                auVar77[2] = -(auVar72[2] == auVar71[2]);
                auVar77[3] = -(auVar72[3] == auVar71[3]);
                auVar77[4] = -(auVar72[4] == auVar71[4]);
                auVar77[5] = -(auVar72[5] == auVar71[5]);
                auVar77[6] = -(auVar72[6] == auVar71[6]);
                auVar77[7] = -(auVar72[7] == auVar71[7]);
                auVar77[8] = -(auVar72[8] == auVar71[0]);
                auVar77[9] = -(auVar72[9] == auVar71[1]);
                auVar77[10] = -(auVar72[10] == auVar71[2]);
                auVar77[0xb] = -(auVar72[0xb] == auVar71[3]);
                auVar77[0xc] = -(auVar72[0xc] == auVar71[4]);
                auVar77[0xd] = -(auVar72[0xd] == auVar71[5]);
                auVar77[0xe] = -(auVar72[0xe] == auVar71[6]);
                auVar77[0xf] = -(auVar72[0xf] == auVar71[7]);
                uVar59 = (ushort)(SUB161(auVar77 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar77 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar77 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar77 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar77 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar77 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar77 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar77 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar77 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar77 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar77 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar77 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar77 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar77 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar77 >> 0x77,0) & 1) << 0xe |
                         (ushort)(auVar77[0xf] >> 7) << 0xf;
                uVar66 = (uint)uVar59;
                while (uVar59 != 0) {
                  uVar62 = 0;
                  for (uVar8 = uVar66; (uVar8 & 1) == 0; uVar8 = uVar8 >> 1 | 0x80000000) {
                    uVar62 = uVar62 + 1;
                  }
                  lVar65 = (uVar62 + uVar38 & DAT_140699958) * -0x50;
                  if (puVar44 == *(undefined8 **)(DAT_140699950 + -0x50 + lVar65)) {
                    lVar65 = DAT_140699950 + lVar65;
                    uVar58 = *(undefined8 *)(lVar65 + -0x48);
                    uVar78 = *(undefined4 *)(lVar65 + -0x40);
                    uStack_228 = (undefined4)((ulonglong)*(undefined8 *)(lVar65 + -0x10) >> 0x20);
                    uStack_224 = (undefined5)*(undefined8 *)(lVar65 + -8);
                    uStack_21f = (undefined3)((ulonglong)*(undefined8 *)(lVar65 + -8) >> 0x28);
                    local_238 = (byte)*(undefined8 *)(lVar65 + -0x1c);
                    uStack_237 = (undefined7)((ulonglong)*(undefined8 *)(lVar65 + -0x1c) >> 8);
                    uStack_230 = (undefined4)*(undefined8 *)(lVar65 + -0x14);
                    uStack_22c = (uint)((ulonglong)*(undefined8 *)(lVar65 + -0x14) >> 0x20);
                    uVar13 = *(undefined8 *)(lVar65 + -0x2c);
                    uVar14 = *(undefined8 *)(lVar65 + -0x24);
                    local_248 = (undefined1)uVar13;
                    uStack_247 = (undefined1)((ulonglong)uVar13 >> 8);
                    sStack_246 = (short)((ulonglong)uVar13 >> 0x10);
                    sStack_244 = (short)((ulonglong)uVar13 >> 0x20);
                    uStack_242 = (undefined1)((ulonglong)uVar13 >> 0x30);
                    uStack_241 = (undefined1)((ulonglong)uVar13 >> 0x38);
                    uStack_240 = (undefined1)uVar14;
                    uStack_23f = (undefined1)((ulonglong)uVar14 >> 8);
                    sStack_23e = (short)((ulonglong)uVar14 >> 0x10);
                    sStack_23c = (short)((ulonglong)uVar14 >> 0x20);
                    uStack_23a = (undefined1)((ulonglong)uVar14 >> 0x30);
                    uStack_239 = (undefined1)((ulonglong)uVar14 >> 0x38);
                    uVar13 = *(undefined8 *)(lVar65 + -0x3c);
                    uVar14 = *(undefined8 *)(lVar65 + -0x34);
                    local_258[0] = (byte)uVar13;
                    local_258[1] = (byte)((ulonglong)uVar13 >> 8);
                    sStack_256 = (short)((ulonglong)uVar13 >> 0x10);
                    sStack_254 = (short)((ulonglong)uVar13 >> 0x20);
                    sStack_252 = (short)((ulonglong)uVar13 >> 0x30);
                    bStack_250 = (byte)uVar14;
                    uStack_24f = (undefined1)((ulonglong)uVar14 >> 8);
                    sStack_24e = (short)((ulonglong)uVar14 >> 0x10);
                    sStack_24c = (short)((ulonglong)uVar14 >> 0x20);
                    uStack_24a = (undefined1)((ulonglong)uVar14 >> 0x30);
                    uStack_249 = (undefined1)((ulonglong)uVar14 >> 0x38);
                    if ((bVar27 == 0) &&
                       ((*(ulonglong *)
                          __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
                        & 0x7fffffffffffffff) != 0)) {
                      cVar26 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                      if (cVar26 == '\0') {
                        DAT_140699949 = '\x01';
                      }
                    }
                    cVar26 = DAT_140699948;
                    LOCK();
                    DAT_140699948 = '\0';
                    UNLOCK();
                    if (cVar26 == '\x02') {
                      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
                    }
                    local_318 = (byte)uVar58;
                    bStack_317 = (byte)((ulonglong)uVar58 >> 8);
                    sStack_316 = (short)((ulonglong)uVar58 >> 0x10);
                    uStack_314 = (undefined4)((ulonglong)uVar58 >> 0x20);
                    uStack_2dc = uStack_228;
                    uStack_2d8 = (undefined1)uStack_224;
                    uStack_2d7 = (undefined7)(CONCAT35(uStack_21f,uStack_224) >> 8);
                    uStack_310._4_4_ = CONCAT22(sStack_256,CONCAT11(local_258[1],local_258[0]));
                    uStack_304 = CONCAT22(sStack_24e,CONCAT11(uStack_24f,bStack_250));
                    uStack_300._4_4_ = CONCAT22(sStack_246,CONCAT11(uStack_247,local_248));
                    local_2f8._4_4_ = CONCAT22(sStack_23e,CONCAT11(uStack_23f,uStack_240));
                    uStack_2f0._4_4_ = (uint)CONCAT71(uStack_237,local_238);
                    uStack_2e8 = (undefined4)((uint7)uStack_237 >> 0x18);
                    uStack_2e4 = uStack_230;
                    uStack_2e0 = uStack_22c;
                    local_2f8._0_4_ =
                         (uint)(CONCAT17(uStack_241,
                                         CONCAT16(uStack_242,CONCAT24(sStack_244,uStack_300._4_4_)))
                               >> 0x20);
                    uStack_2f0._0_4_ =
                         (undefined4)
                         (CONCAT17(uStack_239,
                                   CONCAT16(uStack_23a,CONCAT24(sStack_23c,local_2f8._4_4_))) >>
                         0x20);
                    uStack_308 = (undefined1)sStack_254;
                    uStack_307 = (undefined1)((ushort)sStack_254 >> 8);
                    sStack_306 = sStack_252;
                    uStack_300._0_4_ =
                         (undefined4)
                         (CONCAT17(uStack_249,CONCAT16(uStack_24a,CONCAT24(sStack_24c,uStack_304)))
                         >> 0x20);
                    uStack_310._0_4_ = uVar78;
                    net::send_route_kind(&net::TRANSPORT,&local_318,uVar56,uVar57,1);
                    goto LAB_14001d270;
                  }
                  uVar59 = (ushort)(uVar66 - 1) & (ushort)uVar66;
                  uVar66 = CONCAT22((short)(uVar66 - 1 >> 0x10),uVar59);
                }
                auVar75[0] = -(auVar72[0] == (char)iVar29);
                auVar75[1] = -(auVar72[1] == (char)((uint)iVar29 >> 8));
                auVar75[2] = -(auVar72[2] == (char)((uint)iVar29 >> 0x10));
                auVar75[3] = -(auVar72[3] == (char)((uint)iVar29 >> 0x18));
                auVar75[4] = -(auVar72[4] == (char)iVar23);
                auVar75[5] = -(auVar72[5] == (char)((uint)iVar23 >> 8));
                auVar75[6] = -(auVar72[6] == (char)((uint)iVar23 >> 0x10));
                auVar75[7] = -(auVar72[7] == (char)((uint)iVar23 >> 0x18));
                auVar75[8] = -(auVar72[8] == (char)iVar9);
                auVar75[9] = -(auVar72[9] == (char)((uint)iVar9 >> 8));
                auVar75[10] = -(auVar72[10] == (char)((uint)iVar9 >> 0x10));
                auVar75[0xb] = -(auVar72[0xb] == (char)((uint)iVar9 >> 0x18));
                auVar75[0xc] = -(auVar72[0xc] == (char)iVar10);
                auVar75[0xd] = -(auVar72[0xd] == (char)((uint)iVar10 >> 8));
                auVar75[0xe] = -(auVar72[0xe] == (char)((uint)iVar10 >> 0x10));
                auVar75[0xf] = -(auVar72[0xf] == (char)((uint)iVar10 >> 0x18));
                if ((((((((((((((((SUB161(auVar75 >> 7,0) & 1) != 0 ||
                                 (SUB161(auVar75 >> 0xf,0) & 1) != 0) ||
                                (SUB161(auVar75 >> 0x17,0) & 1) != 0) ||
                               (SUB161(auVar75 >> 0x1f,0) & 1) != 0) ||
                              (SUB161(auVar75 >> 0x27,0) & 1) != 0) ||
                             (SUB161(auVar75 >> 0x2f,0) & 1) != 0) ||
                            (SUB161(auVar75 >> 0x37,0) & 1) != 0) ||
                           (SUB161(auVar75 >> 0x3f,0) & 1) != 0) ||
                          (SUB161(auVar75 >> 0x47,0) & 1) != 0) ||
                         (SUB161(auVar75 >> 0x4f,0) & 1) != 0) ||
                        (SUB161(auVar75 >> 0x57,0) & 1) != 0) ||
                       (SUB161(auVar75 >> 0x5f,0) & 1) != 0) || (SUB161(auVar75 >> 0x67,0) & 1) != 0
                      ) || (SUB161(auVar75 >> 0x6f,0) & 1) != 0) ||
                    (SUB161(auVar75 >> 0x77,0) & 1) != 0) || auVar75[0xf] < '\0') break;
                uVar38 = uVar38 + lVar49 + 0x10;
                lVar49 = lVar49 + 0x10;
              }
            }
            if ((bVar27 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar26 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar26 == '\0') {
                DAT_140699949 = '\x01';
              }
            }
            cVar26 = DAT_140699948;
            LOCK();
            DAT_140699948 = '\0';
            UNLOCK();
            if (cVar26 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            }
          }
LAB_14001d270:
          if (lVar31 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar56,lVar31,1);
            return;
          }
          pauVar39 = pauVar42;
          pauVar61 = pauVar33;
        } while (pauVar42 != pauVar33);
        uStack_368 = SUB81(pauVar61,0);
        uStack_367 = (undefined7)((ulonglong)pauVar61 >> 8);
        pauVar39 = local_340;
      }
      if ((longlong)pauVar33 - (longlong)pauVar61 != 0) {
        uVar38 = (ulonglong)((longlong)pauVar33 - (longlong)pauVar61) >> 5;
        pauVar61 = pauVar61 + 1;
        do {
          if (*(longlong *)((longlong)pauVar61[-1] + 8) != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      (*(undefined8 *)*pauVar61,*(longlong *)((longlong)pauVar61[-1] + 8),1);
            return;
          }
          pauVar61 = pauVar61 + 2;
          uVar38 = uVar38 - 1;
        } while (uVar38 != 0);
      }
      if (pauVar39 == (undefined1 (*) [16])0x0) {
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
        return;
      }
      __rustc[9d087a5ab36ea756]::__rust_dealloc(local_348,(longlong)pauVar39 << 5,8);
      return;
    }
  }
  sVar1 = DAT_140699430;
  pauVar39 = DAT_140699428;
  DAT_140699470 = local_1c0;
  DAT_140699478 = local_334;
  lVar31 = DAT_1406994e8 + 1;
  local_1d8 = local_1c0;
  local_1d0 = (undefined8 *)CONCAT44(local_1d0._4_4_,local_334);
  if (DAT_140699260 == 0) {
    lVar49 = 0;
    uVar38 = 0;
    lVar65 = 0;
  }
  else {
    uVar38 = 0;
    if (DAT_140699248 <= DAT_140699258) {
      uVar38 = DAT_140699248;
    }
    lVar49 = DAT_140699258 - uVar38;
    lVar65 = DAT_140699260 - (DAT_140699248 - lVar49);
    uVar38 = DAT_140699248;
    if (DAT_140699260 < DAT_140699248 - lVar49 || lVar65 == 0) {
      uVar38 = DAT_140699260 + lVar49;
      lVar65 = 0;
    }
  }
  lVar49 = lVar49 * 0x80 + DAT_140699250;
  uStack_310 = (undefined1 (*) [16])(uVar38 * 0x80 + DAT_140699250);
  uStack_300 = (undefined1 (*) [16])(lVar65 * 0x80 + DAT_140699250);
  local_318 = (byte)lVar49;
  bStack_317 = (byte)((ulonglong)lVar49 >> 8);
  sStack_316 = (short)((ulonglong)lVar49 >> 0x10);
  uStack_314 = (undefined4)((ulonglong)lVar49 >> 0x20);
  uStack_308 = (undefined1)DAT_140699250;
  uStack_307 = (undefined1)((ulonglong)DAT_140699250 >> 8);
  sStack_306 = (short)((ulonglong)DAT_140699250 >> 0x10);
  uStack_304 = (undefined4)((ulonglong)DAT_140699250 >> 0x20);
  local_2f8._0_4_ = 0x40699030;
  local_2f8._4_4_ = 1;
  uStack_2f0 = &local_1d8;
  DAT_1406994e8 = lVar31;
  <alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<serde_json[7404bcab4dc139c7]::value::Value,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>>>
  ::from_iter(&local_330,&local_318);
  local_278 = (undefined8 *)0x0;
  local_268 = (undefined1 (*) [16])0x0;
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  uVar56 = 7;
  puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(7,1);
  if (puVar40 != (undefined4 *)0x0) {
    *(undefined4 *)((longlong)puVar40 + 3) = 0x6e6f6973;
    *puVar40 = 0x73726576;
    local_370._0_4_ = 7;
    local_370._4_4_ = 0;
    uStack_368 = SUB81(puVar40,0);
    uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
    uStack_360 = 7;
    uStack_35c = 0;
    local_318 = 2;
    uStack_310._0_4_ = 0;
    uStack_310._4_4_ = 0;
    uStack_308 = 1;
    uStack_307 = 0;
    sStack_306 = 0;
    uStack_304 = 0;
    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
    ::insert(local_258,&local_278,&local_370,&local_318);
    if (local_258[0] != 0xff) {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(local_258)
      ;
    }
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar56 = 7;
    puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(7,1);
    if (puVar40 != (undefined4 *)0x0) {
      *(undefined4 *)((longlong)puVar40 + 3) = 0x6e6f6973;
      *puVar40 = 0x73736573;
      local_370._0_4_ = 7;
      local_370._4_4_ = 0;
      uStack_368 = SUB81(puVar40,0);
      uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
      uStack_360 = 7;
      uStack_35c = 0;
      if ((longlong)sVar1 < 0) {
        uVar56 = 0;
LAB_14001c16a:
        alloc[246c2e7857c81348]::raw_vec::handle_error(uVar56,sVar1);
        goto LAB_14001db96;
      }
      if (sVar1 == 0) {
        pvVar43 = (void *)0x1;
      }
      else {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar56 = 1;
        pvVar43 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
        if (pvVar43 == (void *)0x0) goto LAB_14001c16a;
        memcpy(pvVar43,pauVar39,sVar1);
      }
      local_318 = 3;
      uStack_310._0_4_ = (uint)sVar1;
      uStack_310._4_4_ = (undefined4)(sVar1 >> 0x20);
      uStack_308 = SUB81(pvVar43,0);
      uStack_307 = (undefined1)((ulonglong)pvVar43 >> 8);
      sStack_306 = (short)((ulonglong)pvVar43 >> 0x10);
      uStack_304 = (undefined4)((ulonglong)pvVar43 >> 0x20);
      uStack_300._0_4_ = (uint)uStack_310;
      uStack_300._4_4_ = uStack_310._4_4_;
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
      ::insert(local_258,&local_278,&local_370,&local_318);
      if (local_258[0] != 0xff) {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                  (local_258);
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar56 = 4;
      puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
      if (puVar40 == (undefined4 *)0x0) goto LAB_14001d74c;
      *puVar40 = 0x6d6f6f72;
      sVar1 = DAT_140699040;
      pvVar43 = DAT_140699038;
      local_370._0_4_ = 4;
      local_370._4_4_ = 0;
      uStack_368 = SUB81(puVar40,0);
      uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
      uStack_360 = 4;
      uStack_35c = 0;
      if ((longlong)DAT_140699040 < 0) {
        uVar56 = 0;
LAB_14001c25b:
        alloc[246c2e7857c81348]::raw_vec::handle_error(uVar56,sVar1);
        goto LAB_14001db96;
      }
      if (DAT_140699040 == 0) {
        pvVar41 = (void *)0x1;
      }
      else {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar56 = 1;
        pvVar41 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
        if (pvVar41 == (void *)0x0) goto LAB_14001c25b;
        memcpy(pvVar41,pvVar43,sVar1);
      }
      local_318 = 3;
      uStack_310._0_4_ = (uint)sVar1;
      uStack_310._4_4_ = (undefined4)(sVar1 >> 0x20);
      uStack_308 = SUB81(pvVar41,0);
      uStack_307 = (undefined1)((ulonglong)pvVar41 >> 8);
      sStack_306 = (short)((ulonglong)pvVar41 >> 0x10);
      uStack_304 = (undefined4)((ulonglong)pvVar41 >> 0x20);
      uStack_300._0_4_ = (uint)uStack_310;
      uStack_300._4_4_ = uStack_310._4_4_;
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
      ::insert(local_258,&local_278,&local_370,&local_318);
      if (local_258[0] != 0xff) {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                  (local_258);
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar56 = 5;
      puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
      if (puVar40 == (undefined4 *)0x0) goto LAB_14001d74c;
      *(undefined1 *)(puVar40 + 1) = 0x68;
      *puVar40 = 0x636f7065;
      sVar1 = DAT_140699098;
      pvVar43 = DAT_140699090;
      local_370._0_4_ = 5;
      local_370._4_4_ = 0;
      uStack_368 = SUB81(puVar40,0);
      uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
      uStack_360 = 5;
      uStack_35c = 0;
      if ((longlong)DAT_140699098 < 0) {
        uVar56 = 0;
LAB_14001c357:
        alloc[246c2e7857c81348]::raw_vec::handle_error(uVar56,sVar1);
        goto LAB_14001db96;
      }
      if (DAT_140699098 == 0) {
        pvVar41 = (void *)0x1;
      }
      else {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar56 = 1;
        pvVar41 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
        if (pvVar41 == (void *)0x0) goto LAB_14001c357;
        memcpy(pvVar41,pvVar43,sVar1);
      }
      local_318 = 3;
      uStack_310._0_4_ = (uint)sVar1;
      uStack_310._4_4_ = (undefined4)(sVar1 >> 0x20);
      uStack_308 = SUB81(pvVar41,0);
      uStack_307 = (undefined1)((ulonglong)pvVar41 >> 8);
      sStack_306 = (short)((ulonglong)pvVar41 >> 0x10);
      uStack_304 = (undefined4)((ulonglong)pvVar41 >> 0x20);
      uStack_300._0_4_ = (uint)uStack_310;
      uStack_300._4_4_ = uStack_310._4_4_;
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
      ::insert(local_258,&local_278,&local_370,&local_318);
      if (local_258[0] != 0xff) {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                  (local_258);
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar56 = 9;
      puVar44 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(9,1);
      if (puVar44 != (undefined8 *)0x0) {
        *puVar44 = 0x6165627472616568;
        *(undefined1 *)(puVar44 + 1) = 0x74;
        local_370._0_4_ = 9;
        local_370._4_4_ = 0;
        uStack_368 = SUB81(puVar44,0);
        uStack_367 = (undefined7)((ulonglong)puVar44 >> 8);
        uStack_360 = 9;
        uStack_35c = 0;
        local_318 = 2;
        uStack_310._0_4_ = 0;
        uStack_310._4_4_ = 0;
        uStack_308 = (undefined1)lVar31;
        uStack_307 = (undefined1)((ulonglong)lVar31 >> 8);
        sStack_306 = (short)((ulonglong)lVar31 >> 0x10);
        uStack_304 = (undefined4)((ulonglong)lVar31 >> 0x20);
        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
        ::insert(local_258,&local_278,&local_370,&local_318);
        if (local_258[0] != 0xff) {
          core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                    (local_258);
        }
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar56 = 5;
        puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
        if (puVar40 != (undefined4 *)0x0) {
          *(undefined1 *)(puVar40 + 1) = 0x79;
          *puVar40 = 0x64616572;
          pauVar61 = DAT_1406993f0;
          pauVar39 = DAT_1406993e8;
          local_370._0_4_ = 5;
          local_370._4_4_ = 0;
          uStack_368 = SUB81(puVar40,0);
          uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
          uStack_360 = 5;
          uStack_35c = 0;
          local_318 = (byte)local_1d8;
          bStack_317 = (byte)((ulonglong)local_1d8 >> 8);
          sStack_316 = (short)((ulonglong)local_1d8 >> 0x10);
          uStack_314 = (undefined4)((ulonglong)local_1d8 >> 0x20);
          uStack_310._0_4_ = local_1d0._0_4_;
          if (DAT_1406993e8 == DAT_1406993f0) {
            if (DAT_1406990e8 != (undefined1 (*) [16])0x0) {
              lVar31 = 0;
              do {
                if (*(undefined1 (**) [16])((longlong)DAT_1406990e0[1] + lVar31 + 8) ==
                    DAT_1406993e8) {
                  bStack_317 = true;
                  goto LAB_14001c5cf;
                }
                lVar31 = lVar31 + 0x28;
              } while ((longlong)DAT_1406990e8 * 0x28 != lVar31);
            }
LAB_14001c5c9:
            bStack_317 = false;
          }
          else {
            if (DAT_140699380 == -1) goto LAB_14001c5c9;
            uVar38 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                               (&local_318,DAT_140699378);
            bStack_317 = uVar38 < 2;
          }
LAB_14001c5cf:
          local_318 = 1;
          <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
          ::insert(local_258,&local_278,&local_370,&local_318);
          if (local_258[0] != 0xff) {
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (local_258);
          }
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar56 = 4;
          puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4);
          if (puVar40 != (undefined4 *)0x0) {
            *puVar40 = 0x6d616574;
            local_370._0_4_ = 4;
            local_370._4_4_ = 0;
            uStack_368 = SUB81(puVar40,0);
            uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
            uStack_360 = 4;
            uStack_35c = 0;
            bStack_317 = DAT_14069941c;
            if (pauVar39 == pauVar61) {
              if (DAT_1406990e8 != (undefined1 (*) [16])0x0) {
                lVar31 = 0;
                do {
                  if ((*(undefined1 (**) [16])((longlong)DAT_1406990e0[1] + lVar31 + 8) == pauVar39)
                     && (-1 < *(char *)((longlong)DAT_1406990e0[2] + lVar31 + 4))) {
                    bStack_317 = 1;
                    goto LAB_14001c6a0;
                  }
                  lVar31 = lVar31 + 0x28;
                } while ((longlong)DAT_1406990e8 * 0x28 != lVar31);
              }
              bStack_317 = 0;
            }
LAB_14001c6a0:
            local_318 = 1;
            <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
            ::insert(local_258,&local_278,&local_370,&local_318);
            if (local_258[0] != 0xff) {
              core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                        (local_258);
            }
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            uVar56 = 3;
            puVar45 = (undefined2 *)__rustc[9d087a5ab36ea756]::__rust_alloc(3,1);
            if (puVar45 != (undefined2 *)0x0) {
              *(undefined1 *)(puVar45 + 1) = 0x6b;
              *puVar45 = 0x6361;
              puVar40 = DAT_140699298;
              pvVar43 = DAT_140699290;
              local_370._0_4_ = 3;
              local_370._4_4_ = 0;
              uStack_368 = SUB81(puVar45,0);
              uStack_367 = (undefined7)((ulonglong)puVar45 >> 8);
              uStack_360 = 3;
              uStack_35c = 0;
              if ((longlong)DAT_140699298 < 0) {
                uVar56 = 0;
LAB_14001c73c:
                alloc[246c2e7857c81348]::raw_vec::handle_error(uVar56,puVar40);
                goto LAB_14001db96;
              }
              if (DAT_140699298 == (undefined4 *)0x0) {
                pvVar41 = (void *)0x1;
              }
              else {
                __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                uVar56 = 1;
                pvVar41 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(puVar40,1);
                if (pvVar41 == (void *)0x0) goto LAB_14001c73c;
                memcpy(pvVar41,pvVar43,(size_t)puVar40);
              }
              local_318 = 3;
              uStack_310._0_4_ = (uint)puVar40;
              uStack_310._4_4_ = (undefined4)((ulonglong)puVar40 >> 0x20);
              uStack_308 = SUB81(pvVar41,0);
              uStack_307 = (undefined1)((ulonglong)pvVar41 >> 8);
              sStack_306 = (short)((ulonglong)pvVar41 >> 0x10);
              uStack_304 = (undefined4)((ulonglong)pvVar41 >> 0x20);
              uStack_300._0_4_ = (uint)uStack_310;
              uStack_300._4_4_ = uStack_310._4_4_;
              <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
              ::insert(local_258,&local_278,&local_370,&local_318);
              if (local_258[0] != 0xff) {
                core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                          (local_258);
              }
              __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
              uVar56 = 5;
              puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
              if (puVar40 != (undefined4 *)0x0) {
                *(undefined1 *)(puVar40 + 1) = 0x72;
                *puVar40 = 0x6f727265;
                pauVar39 = DAT_1406992b0;
                pcVar35 = DAT_1406992a8;
                local_370._0_4_ = 5;
                local_370._4_4_ = 0;
                uStack_368 = SUB81(puVar40,0);
                uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
                uStack_360 = 5;
                uStack_35c = 0;
                if ((longlong)DAT_1406992b0 < 0) {
                  uVar56 = 0;
LAB_14001c838:
                  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar56,pauVar39);
                  goto LAB_14001db96;
                }
                if (DAT_1406992b0 == (undefined1 (*) [16])0x0) {
                  pvVar43 = (void *)0x1;
                }
                else {
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  uVar56 = 1;
                  pvVar43 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(pauVar39,1);
                  if (pvVar43 == (void *)0x0) goto LAB_14001c838;
                  memcpy(pvVar43,pcVar35,(size_t)pauVar39);
                }
                local_318 = 3;
                uStack_310._0_4_ = (uint)pauVar39;
                uStack_310._4_4_ = (undefined4)((ulonglong)pauVar39 >> 0x20);
                uStack_308 = SUB81(pvVar43,0);
                uStack_307 = (undefined1)((ulonglong)pvVar43 >> 8);
                sStack_306 = (short)((ulonglong)pvVar43 >> 0x10);
                uStack_304 = (undefined4)((ulonglong)pvVar43 >> 0x20);
                uStack_300._0_4_ = (uint)uStack_310;
                uStack_300._4_4_ = uStack_310._4_4_;
                <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                ::insert(local_258,&local_278,&local_370,&local_318);
                if (local_258[0] != 0xff) {
                  core[505b25137b8ba7f]::ptr::drop_glue::
                  <serde_json[7404bcab4dc139c7]::value::Value>(local_258);
                }
                __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                uVar56 = 5;
                puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                if (puVar40 != (undefined4 *)0x0) {
                  *(undefined1 *)(puVar40 + 1) = 0x73;
                  *puVar40 = 0x656e696c;
                  local_370._0_4_ = 5;
                  local_370._4_4_ = 0;
                  uStack_368 = SUB81(puVar40,0);
                  uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
                  uStack_360 = 5;
                  uStack_35c = 0;
                  <serde_json[7404bcab4dc139c7]::value::ser::Serializer_as_serde_core[7f01a81d286c67f3]::ser::Serializer>
                  ::collect_seq::
                  <&alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>>
                            (&local_318,&local_330);
                  sVar25 = sStack_24c;
                  sVar7 = sStack_24e;
                  uVar50 = uStack_24f;
                  bVar27 = bStack_250;
                  sStack_24e = (short)((uint)uStack_310 >> 0x10);
                  bStack_250 = (byte)(uint)uStack_310;
                  uStack_24f = (undefined1)((uint)uStack_310 >> 8);
                  sStack_24c = (short)uStack_310._4_4_;
                  if (local_318 == 0xff) {
                    sStack_252 = (short)((uint)uStack_310._4_4_ >> 0x10);
                    local_258[0] = bStack_250;
                    local_258[1] = uStack_24f;
                    sStack_256 = sStack_24e;
                    sStack_254 = sStack_24c;
                    bStack_250 = bVar27;
                    uStack_24f = uVar50;
                    sStack_24e = sVar7;
                    sStack_24c = sVar25;
                    core[505b25137b8ba7f]::result::unwrap_failed
                              ("called `Result::unwrap()` on an `Err` value",0x2b,local_258,
                               &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                               &PTR_s_src_ingame_chat_transport_rs_1406a1568);
                    goto LAB_14001db96;
                  }
                  local_248 = uStack_308;
                  uStack_247 = uStack_307;
                  sStack_246 = sStack_306;
                  sStack_244 = (short)uStack_304;
                  uStack_242 = (undefined1)((uint)uStack_304 >> 0x10);
                  uStack_241 = (undefined1)((uint)uStack_304 >> 0x18);
                  uStack_240 = (undefined1)(undefined4)uStack_300;
                  uStack_23f = (undefined1)((uint)(undefined4)uStack_300 >> 8);
                  sStack_23e = (short)((uint)(undefined4)uStack_300 >> 0x10);
                  sStack_23c = (short)uStack_300._4_4_;
                  uStack_23a = (undefined1)((uint)uStack_300._4_4_ >> 0x10);
                  uStack_239 = (undefined1)((uint)uStack_300._4_4_ >> 0x18);
                  local_258[0] = local_318;
                  local_258[1] = bStack_317;
                  sStack_256 = sStack_316;
                  sStack_254 = (short)uStack_314;
                  sStack_252 = (short)((uint)uStack_314 >> 0x10);
                  uStack_24a = (undefined1)((uint)uStack_310._4_4_ >> 0x10);
                  uStack_249 = (undefined1)((uint)uStack_310._4_4_ >> 0x18);
                  <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                  ::insert(&local_318,&local_278,&local_370,local_258);
                  if (local_318 != 0xff) {
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <serde_json[7404bcab4dc139c7]::value::Value>(&local_318);
                  }
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  uVar56 = 7;
                  puVar40 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(7,1);
                  if (puVar40 != (undefined4 *)0x0) {
                    *(undefined4 *)((longlong)puVar40 + 3) = 0x676e6974;
                    *puVar40 = 0x74756f72;
                    local_370._0_4_ = 7;
                    local_370._4_4_ = 0;
                    uStack_368 = SUB81(puVar40,0);
                    uStack_367 = (undefined7)((ulonglong)puVar40 >> 8);
                    uStack_360 = 7;
                    uStack_35c = 0;
                    <serde_json[7404bcab4dc139c7]::value::ser::Serializer_as_serde_core[7f01a81d286c67f3]::ser::Serializer>
                    ::collect_seq::
                    <&alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>>
                              (&local_318,&DAT_140699268);
                    sVar25 = sStack_24c;
                    sVar7 = sStack_24e;
                    uVar50 = uStack_24f;
                    bVar27 = bStack_250;
                    sStack_24e = (short)((uint)uStack_310 >> 0x10);
                    bStack_250 = (byte)(uint)uStack_310;
                    uStack_24f = (undefined1)((uint)uStack_310 >> 8);
                    sStack_24c = (short)uStack_310._4_4_;
                    if (local_318 == 0xff) {
                      sStack_252 = (short)((uint)uStack_310._4_4_ >> 0x10);
                      local_258[0] = bStack_250;
                      local_258[1] = uStack_24f;
                      sStack_256 = sStack_24e;
                      sStack_254 = sStack_24c;
                      bStack_250 = bVar27;
                      uStack_24f = uVar50;
                      sStack_24e = sVar7;
                      sStack_24c = sVar25;
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("called `Result::unwrap()` on an `Err` value",0x2b,local_258,
                                 &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                                 &PTR_s_src_ingame_chat_transport_rs_1406a1568);
                      goto LAB_14001db96;
                    }
                    local_248 = uStack_308;
                    uStack_247 = uStack_307;
                    sStack_246 = sStack_306;
                    sStack_244 = (short)uStack_304;
                    uStack_242 = (undefined1)((uint)uStack_304 >> 0x10);
                    uStack_241 = (undefined1)((uint)uStack_304 >> 0x18);
                    uStack_240 = (undefined1)(undefined4)uStack_300;
                    uStack_23f = (undefined1)((uint)(undefined4)uStack_300 >> 8);
                    sStack_23e = (short)((uint)(undefined4)uStack_300 >> 0x10);
                    sStack_23c = (short)uStack_300._4_4_;
                    uStack_23a = (undefined1)((uint)uStack_300._4_4_ >> 0x10);
                    uStack_239 = (undefined1)((uint)uStack_300._4_4_ >> 0x18);
                    local_258[0] = local_318;
                    local_258[1] = bStack_317;
                    sStack_256 = sStack_316;
                    sStack_254 = (short)uStack_314;
                    sStack_252 = (short)((uint)uStack_314 >> 0x10);
                    uStack_24a = (undefined1)((uint)uStack_310._4_4_ >> 0x10);
                    uStack_249 = (undefined1)((uint)uStack_310._4_4_ >> 0x18);
                    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                    ::insert(&local_318,&local_278,&local_370,local_258);
                    if (local_318 != 0xff) {
                      core[505b25137b8ba7f]::ptr::drop_glue::
                      <serde_json[7404bcab4dc139c7]::value::Value>(&local_318);
                    }
                    uStack_368 = SUB81(local_278,0);
                    uStack_367 = (undefined7)((ulonglong)local_278 >> 8);
                    uStack_360 = (uint)pauStack_270;
                    uStack_35c = (undefined4)((ulonglong)pauStack_270 >> 0x20);
                    pauStack_358 = local_268;
                    local_370._0_4_ = CONCAT31(local_370._1_3_,5);
                    if (local_320 != (undefined1 (*) [16])0x0) {
                      lVar31 = 1 - (longlong)local_320;
                      pauVar39 = local_328;
                      do {
                        core[505b25137b8ba7f]::ptr::drop_glue::
                        <serde_json[7404bcab4dc139c7]::value::Value>(pauVar39);
                        pauVar39 = pauVar39 + 2;
                        lVar31 = lVar31 + 1;
                      } while (lVar31 != 1);
                    }
                    if (local_330 != (undefined1 (*) [16])0x0) {
                      __rustc[9d087a5ab36ea756]::__rust_dealloc
                                (local_328,(longlong)local_330 << 5,8);
                      return;
                    }
                    pcVar35 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                      index_into("ready",5,&local_370);
                    cVar26 = LOGGED;
                    if (pcVar35 == (char *)0x0) {
                      pcVar35 = 
                      __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                      ;
                    }
                    if ((*pcVar35 == '\x01') && (pcVar35[1] != '\0')) {
                      LOCK();
                      LOGGED = '\x02';
                      UNLOCK();
                      if (cVar26 == '\x02') goto LAB_14001cc5d;
                      local_278 = (undefined8 *)&DAT_1406a0cb9;
                      if (DAT_1406993e8 == DAT_1406993f0) {
                        local_278 = (undefined8 *)&DAT_1406a0cbe;
                      }
                      pauStack_270 = (undefined1 (*) [16])
                                     ((ulonglong)(DAT_1406993e8 == DAT_1406993f0) ^ 5);
                      local_318 = (byte)&local_278;
                      bStack_317 = (byte)((ulonglong)&local_278 >> 8);
                      sStack_316 = (short)((ulonglong)&local_278 >> 0x10);
                      uStack_314 = (undefined4)((ulonglong)&local_278 >> 0x20);
                      uStack_310._0_4_ = 0x402428d0;
                      uStack_310._4_4_ = 1;
                      uStack_308 = 0x30;
                      uStack_307 = 0x90;
                      sStack_306 = 0x4069;
                      uStack_304 = 1;
                      uStack_300._0_4_ = 0x40041f60;
                      uStack_300._4_4_ = 1;
                      alloc[246c2e7857c81348]::fmt::format::format_inner
                                (local_258,&DAT_1406a0cc2,&local_318);
                      lVar31 = CONCAT26(sStack_252,
                                        CONCAT24(sStack_254,
                                                 CONCAT22(sStack_256,
                                                          CONCAT11(local_258[1],local_258[0]))));
                      pcVar35 = (char *)CONCAT17(uStack_249,
                                                 CONCAT16(uStack_24a,
                                                          CONCAT24(sStack_24c,
                                                                   CONCAT22(sStack_24e,
                                                                            CONCAT11(uStack_24f,
                                                                                     bStack_250)))))
                      ;
                      uVar56 = CONCAT17(uStack_241,
                                        CONCAT16(uStack_242,
                                                 CONCAT24(sStack_244,
                                                          CONCAT22(sStack_246,
                                                                   CONCAT11(uStack_247,local_248))))
                                       );
                    }
                    else {
                      LOCK();
                      LOGGED = '\x01';
                      UNLOCK();
                      if (cVar26 == '\x01') goto LAB_14001cc5d;
                      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                      lVar31 = 0x4e;
                      pcVar35 = (char *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x4e,1);
                      if (pcVar35 == (char *)0x0) {
                        alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x4e);
                        goto LAB_14001db96;
                      }
                      builtin_strncpy(pcVar35,
                                      "match chat: waiting for the online session (an offline game has no match chat)"
                                      ,0x4e);
                      uVar56 = 0x4e;
                    }
                    host::log(pcVar35,uVar56);
                    if (lVar31 != 0) {
                      __rustc[9d087a5ab36ea756]::__rust_dealloc(pcVar35,lVar31,1);
                      return;
                    }
LAB_14001cc5d:
LAB_14001cc78:
                    local_258[0] = 0;
                    local_258[1] = 0;
                    sStack_256 = 0;
                    sStack_254 = 0;
                    sStack_252 = 0;
                    bStack_250 = 1;
                    uStack_24f = 0;
                    sStack_24e = 0;
                    sStack_24c = 0;
                    uStack_24a = 0;
                    uStack_249 = 0;
                    local_248 = 0;
                    uStack_247 = 0;
                    sStack_246 = 0;
                    sStack_244 = 0;
                    uStack_242 = 0;
                    uStack_241 = 0;
                    uStack_308 = 0x20;
                    uStack_307 = 0;
                    sStack_306 = 0x6000;
                    uStack_304 = 0;
                    local_318 = (byte)local_258;
                    bStack_317 = (byte)((ulonglong)local_258 >> 8);
                    sStack_316 = (short)((ulonglong)local_258 >> 0x10);
                    uStack_314 = (undefined4)((ulonglong)local_258 >> 0x20);
                    uStack_310._0_4_ = 0x406a3830;
                    uStack_310._4_4_ = 1;
                    cVar26 = <serde_json[7404bcab4dc139c7]::value::Value_as_core[505b25137b8ba7f]::fmt::Display>
                             ::fmt(&local_370,&local_318);
                    if (cVar26 == '\0') {
                      lVar31 = CONCAT26(sStack_252,
                                        CONCAT24(sStack_254,
                                                 CONCAT22(sStack_256,
                                                          CONCAT11(local_258[1],local_258[0]))));
                      uVar56 = CONCAT17(uStack_249,
                                        CONCAT16(uStack_24a,
                                                 CONCAT24(sStack_24c,
                                                          CONCAT22(sStack_24e,
                                                                   CONCAT11(uStack_24f,bStack_250)))
                                                ));
                      if (0x20000 < CONCAT17(uStack_241,
                                             CONCAT16(uStack_242,
                                                      CONCAT24(sStack_244,
                                                               CONCAT22(sStack_246,
                                                                        CONCAT11(uStack_247,
                                                                                 local_248))))))
                      goto code_r0x00014001cced;
                      if (lVar31 != 0) {
                        __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar56,lVar31,1);
                        return;
                      }
                      <std[3bf9d48a0c3997f0]::path::Path>::_join
                                (local_258,&DAT_1406a1ab0,1,"match-chat.json",0xf);
                      uVar56 = CONCAT17(uStack_249,
                                        CONCAT16(uStack_24a,
                                                 CONCAT24(sStack_24c,
                                                          CONCAT22(sStack_24e,
                                                                   CONCAT11(uStack_24f,bStack_250)))
                                                ));
                      uVar57 = CONCAT17(uStack_241,
                                        CONCAT16(uStack_242,
                                                 CONCAT24(sStack_244,
                                                          CONCAT22(sStack_246,
                                                                   CONCAT11(uStack_247,local_248))))
                                       );
                      <std[3bf9d48a0c3997f0]::path::Path>::_with_extension
                                (&local_318,uVar56,uVar57,"tmp",3);
                      local_330 = (undefined1 (*) [16])0x0;
                      local_328 = (undefined1 (*) [16])0x1;
                      local_320 = (undefined1 (*) [16])0x0;
                      local_268 = (undefined1 (*) [16])0x60000020;
                      local_278 = &local_330;
                      pauStack_270 = (undefined1 (*) [16])
                                     &PTR_<alloc[246c2e7857c81348]::string::String>_1406a3830;
                      cVar26 = <serde_json[7404bcab4dc139c7]::value::Value_as_core[505b25137b8ba7f]::fmt::Display>
                               ::fmt(&local_370,&local_278);
                      pauVar61 = local_328;
                      pauVar39 = local_330;
                      if (cVar26 == '\0') {
                        uVar58 = CONCAT44(uStack_310._4_4_,(uint)uStack_310);
                        uVar13 = CONCAT44(uStack_304,
                                          CONCAT22(sStack_306,CONCAT11(uStack_307,uStack_308)));
                        uVar38 = std[3bf9d48a0c3997f0]::fs::write::inner
                                           (uVar58,uVar13,local_328,local_320);
                        if (pauVar39 != (undefined1 (*) [16])0x0) {
                          __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar61,pauVar39,1);
                          return;
                        }
                        if (uVar38 == 0) {
                          lVar31 = CONCAT44(uStack_314,
                                            CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)));
                          uVar38 = std[3bf9d48a0c3997f0]::sys::fs::rename
                                             (uVar58,uVar13,uVar56,uVar57);
                          if (lVar31 != 0) {
                            __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar58,lVar31,1);
                            return;
                          }
                          if (uVar38 != 0) goto LAB_14001cf13;
                        }
                        else {
                          lVar31 = CONCAT44(uStack_314,
                                            CONCAT22(sStack_316,CONCAT11(bStack_317,local_318)));
                          if (lVar31 != 0) {
                            __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar58,lVar31,1);
                            return;
                          }
LAB_14001cf13:
                          uStack_310 = (undefined1 (*) [16])
                                       CONCAT44(uStack_310._4_4_,(uint)uStack_310);
                          if ((1 < ((uint)uVar38 & 3) - 2) &&
                             (uStack_310 = (undefined1 (*) [16])
                                           CONCAT44(uStack_310._4_4_,(uint)uStack_310),
                             (uVar38 & 3) != 0)) {
                            uStack_310 = (undefined1 (*) [16])(uVar38 - 1);
                            local_318 = 3;
                            <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                            ::drop(&uStack_310);
                          }
                        }
                        lVar31 = CONCAT26(sStack_252,
                                          CONCAT24(sStack_254,
                                                   CONCAT22(sStack_256,
                                                            CONCAT11(local_258[1],local_258[0]))));
                        if (lVar31 != 0) {
                          __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar56,lVar31,1);
                          return;
                        }
                        goto LAB_14001cf60;
                      }
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("a Display implementation returned an error unexpectedly",0x37,
                                 &local_349,&DAT_1406a1170,
                                 &PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
                    }
                    else {
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("a Display implementation returned an error unexpectedly",0x37,
                                 &local_349,&DAT_1406a1170,
                                 &PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
                    }
                    goto LAB_14001db96;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
LAB_14001d74c:
  alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar56);
LAB_14001db96:
                    /* WARNING: Does not return */
  pcVar5 = (code *)invalidInstructionException();
  (*pcVar5)();
}

