// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>>::remove
// address: 0x140047bd0
// body: available
// range: 0x140047bd0-0x140047cb6 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>>::remove
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>>::remove
          (longlong *param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  code *pcVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  longlong lVar14;
  ulonglong uVar15;
  
  uVar15 = *(ulonglong *)(param_2 + 0x10);
  if (param_3 < uVar15) {
    lVar2 = *(longlong *)(param_2 + 8);
    lVar14 = param_3 * 0x50;
    lVar3 = *(longlong *)(lVar2 + lVar14);
    lVar4 = *(longlong *)(lVar2 + 0x48 + lVar14);
    plVar1 = (longlong *)(lVar2 + 0x38 + lVar14);
    lVar6 = *plVar1;
    lVar7 = plVar1[1];
    plVar1 = (longlong *)(lVar2 + 0x28 + lVar14);
    lVar8 = *plVar1;
    lVar9 = plVar1[1];
    plVar1 = (longlong *)(lVar2 + 0x18 + lVar14);
    lVar10 = *plVar1;
    lVar11 = plVar1[1];
    plVar1 = (longlong *)(lVar2 + 8 + lVar14);
    lVar12 = *plVar1;
    lVar13 = plVar1[1];
    memmove((void *)(lVar2 + lVar14),(void *)(lVar14 + lVar2 + 0x50),(~param_3 + uVar15) * 0x50);
    uVar15 = uVar15 - 1;
    *(ulonglong *)(param_2 + 0x10) = uVar15;
    if (lVar3 != -1) {
      *param_1 = lVar3;
      param_1[1] = lVar12;
      param_1[2] = lVar13;
      param_1[3] = lVar10;
      param_1[4] = lVar11;
      param_1[5] = lVar8;
      param_1[6] = lVar9;
      param_1[7] = lVar6;
      param_1[8] = lVar7;
      param_1[9] = lVar4;
      return param_1;
    }
  }
  <alloc[246c2e7857c81348]::vec::Vec<_,_>>::remove::assert_failed(param_3,uVar15,param_4);
                    /* WARNING: Does not return */
  pcVar5 = (code *)invalidInstructionException();
  (*pcVar5)();
}

