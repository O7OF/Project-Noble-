// rea decompile_all
// name: <u64>::from_ascii_bytes_radix_impl
// address: 0x140016260
// body: available
// range: 0x140016260-0x14001638c inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <u64>::from_ascii_bytes_radix_impl */

void __rustcall
<u64>::from_ascii_bytes_radix_impl(undefined1 *param_1,char *param_2,ulonglong param_3)

{
  byte bVar1;
  char cVar2;
  ulonglong uVar3;
  longlong lVar4;
  uint uVar5;
  ulonglong uVar6;
  
  if (param_3 == 1) {
    cVar2 = *param_2;
    if ((cVar2 != '-') && (cVar2 != '+')) goto LAB_14001628e;
LAB_140016280:
    param_1[1] = 1;
  }
  else {
    if (param_3 != 0) {
      cVar2 = *param_2;
LAB_14001628e:
      uVar6 = (ulonglong)(cVar2 == '+');
      if (param_3 - uVar6 < 0x11) {
        if (param_3 == uVar6) {
          uVar3 = 0;
        }
        else {
          uVar3 = 0;
          lVar4 = 0;
          do {
            bVar1 = param_2[lVar4 + uVar6];
            uVar5 = bVar1 - 0x30;
            if (0x39 < bVar1) {
              uVar5 = (bVar1 - 0x41 & 0xffffffdf) + 10;
            }
            if (0xf < uVar5) goto LAB_140016280;
            uVar3 = (ulonglong)uVar5 | uVar3 << 4;
            lVar4 = lVar4 + 1;
          } while (lVar4 != param_3 + -uVar6);
        }
      }
      else {
        uVar3 = 0;
        lVar4 = 0;
        do {
          bVar1 = param_2[lVar4 + uVar6];
          if (uVar3 >> 0x3c != 0) {
            uVar5 = bVar1 - 0x30;
            if (0x39 < bVar1) {
              uVar5 = (bVar1 - 0x41 & 0xffffffde) + 10;
            }
            if (0xf < uVar5) goto LAB_140016280;
            param_1[1] = 2;
            goto LAB_140016284;
          }
          uVar5 = bVar1 - 0x30;
          if (0x39 < bVar1) {
            uVar5 = (bVar1 - 0x41 & 0xffffffdf) + 10;
          }
          if (0xf < uVar5) goto LAB_140016280;
          uVar3 = (ulonglong)uVar5 | uVar3 << 4;
          lVar4 = lVar4 + 1;
        } while (lVar4 != param_3 + -uVar6);
      }
      *(ulonglong *)(param_1 + 8) = uVar3;
      *param_1 = 0;
      return;
    }
    param_1[1] = 0;
  }
LAB_140016284:
  *param_1 = 1;
  return;
}

