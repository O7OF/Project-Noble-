// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::unfocused
// address: 0x1400203a0
// body: available
// range: 0x1400203a0-0x1400204a3 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140020486 to 0x140610d80 <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::unfocused */

void __rustcall host_probe[b94139f9089eb1d8]::ingame_chat::unfocused(void)

{
  code *pcVar1;
  undefined *puVar2;
  char cVar3;
  bool bVar4;
  undefined1 *local_18;
  byte local_10;
  
  if (ENABLED_0_llvm_14435704873730135342 != '\0') {
    LOCK();
    bVar4 = STATE == '\0';
    if (bVar4) {
      STATE = '\x01';
    }
    UNLOCK();
    if (!bVar4) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&STATE);
    }
    puVar2 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      local_10 = 0;
    }
    else {
      local_10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      local_10 = local_10 ^ 1;
    }
    if (DAT_140699029 != '\0') {
      local_18 = &STATE;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_18,
                 &anon_d5c34e88a06ee720b116585eb143da4b_137_llvm_14435704873730135342,
                 &anon_d5c34e88a06ee720b116585eb143da4b_330_llvm_14435704873730135342);
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    if (DAT_140699030 != -1) {
      DAT_14069949a = 0;
      _DAT_140699498 = 0;
    }
    if (((local_10 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
       (cVar3 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar3 == '\0'))
    {
      DAT_140699029 = '\x01';
    }
    cVar3 = STATE;
    LOCK();
    STATE = '\0';
    UNLOCK();
    if (cVar3 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&STATE);
      return;
    }
  }
  return;
}

