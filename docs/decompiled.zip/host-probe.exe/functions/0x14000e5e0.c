// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::drop_team_lines
// address: 0x14000e5e0
// body: available
// range: 0x14000e5e0-0x14000e632 inclusive
// range: 0x14000e640-0x14000e705 inclusive
// range: 0x14000e710-0x14000e8c6 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000e8a8 to 0x140015a20 <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>::truncate (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::drop_team_lines */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::drop_team_lines(longlong param_1)

{
  undefined8 *puVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong lVar4;
  code *pcVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  undefined8 uVar26;
  undefined8 uVar27;
  undefined8 uVar28;
  undefined8 uVar29;
  undefined8 uVar30;
  undefined8 uVar31;
  undefined8 uVar32;
  undefined8 uVar33;
  undefined8 uVar34;
  undefined8 uVar35;
  undefined8 uVar36;
  ulonglong uVar37;
  ulonglong uVar38;
  ulonglong uVar39;
  longlong lVar40;
  char *pcVar41;
  ulonglong uVar42;
  ulonglong uVar43;
  longlong lVar44;
  undefined4 local_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  
  uVar2 = *(ulonglong *)(param_1 + 0x230);
  if (uVar2 == 0) {
    uVar37 = 0;
    uVar38 = 0;
LAB_14000e85b:
    if (uVar38 != uVar37) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
      ::truncate(param_1 + 0x218);
      return;
    }
  }
  else {
    lVar40 = *(longlong *)(param_1 + 0x228) * 0x80 + *(longlong *)(param_1 + 0x220) + 2;
    uVar37 = 0;
    do {
      uVar38 = 0;
      if (*(ulonglong *)(param_1 + 0x218) <= *(longlong *)(param_1 + 0x228) + uVar37) {
        uVar38 = *(ulonglong *)(param_1 + 0x218);
      }
      pcVar41 = (char *)(lVar40 + uVar38 * -0x80);
      if ((pcVar41[-2] == '\x01') && (*pcVar41 == '\x04')) {
        uVar38 = uVar37 + 1;
        if (uVar38 < uVar2) {
          lVar40 = *(longlong *)(param_1 + 0x228);
          uVar3 = *(ulonglong *)(param_1 + 0x218);
          lVar4 = *(longlong *)(param_1 + 0x220);
          uVar42 = uVar2;
          if (uVar2 < uVar37) {
            uVar42 = uVar37;
          }
          do {
            lVar44 = (lVar40 + uVar38) * 0x80 + lVar4;
            uVar39 = uVar38;
            while( true ) {
              uVar43 = uVar3;
              if (lVar40 + uVar39 < uVar3) {
                uVar43 = 0;
              }
              pcVar41 = (char *)(lVar44 + uVar43 * -0x80);
              if ((*pcVar41 != '\x01') || (pcVar41[2] != '\x04')) break;
              uVar39 = uVar39 + 1;
              lVar44 = lVar44 + 0x80;
              if (uVar2 <= uVar39) {
                uVar38 = uVar38 + 1;
                if (uVar38 < uVar2) {
                  uVar38 = uVar2;
                }
                goto LAB_14000e85b;
              }
            }
            if (uVar37 == uVar42) {
              core[505b25137b8ba7f]::panicking::panic
                        (&anon_d5c34e88a06ee720b116585eb143da4b_235_llvm_14435704873730135342,0x20,
                         &anon_d5c34e88a06ee720b116585eb143da4b_236_llvm_14435704873730135342);
                    /* WARNING: Does not return */
              pcVar5 = (code *)invalidInstructionException();
              (*pcVar5)();
            }
            uVar38 = 0;
            if (uVar3 <= uVar37 + lVar40) {
              uVar38 = uVar3;
            }
            lVar44 = ((uVar37 + lVar40) - uVar38) * 0x80;
            puVar1 = (undefined8 *)(lVar4 + 0x70 + lVar44);
            uVar6 = *puVar1;
            uVar7 = puVar1[1];
            puVar1 = (undefined8 *)(lVar4 + 0x60 + lVar44);
            uVar8 = *puVar1;
            uVar9 = puVar1[1];
            puVar1 = (undefined8 *)(lVar4 + 0x50 + lVar44);
            uVar10 = *puVar1;
            uVar11 = puVar1[1];
            puVar1 = (undefined8 *)(lVar4 + 0x40 + lVar44);
            uVar12 = *puVar1;
            uVar13 = puVar1[1];
            uVar14 = *(undefined8 *)(lVar4 + lVar44);
            uVar15 = ((undefined8 *)(lVar4 + lVar44))[1];
            puVar1 = (undefined8 *)(lVar4 + 0x10 + lVar44);
            uVar16 = *puVar1;
            uVar17 = puVar1[1];
            puVar1 = (undefined8 *)(lVar4 + 0x20 + lVar44);
            uVar18 = *puVar1;
            uVar19 = puVar1[1];
            puVar1 = (undefined8 *)(lVar4 + 0x30 + lVar44);
            uVar20 = *puVar1;
            uVar21 = puVar1[1];
            uVar22 = *(undefined8 *)(pcVar41 + 0x40);
            uVar23 = *(undefined8 *)(pcVar41 + 0x48);
            uVar24 = *(undefined8 *)(pcVar41 + 0x50);
            uVar25 = *(undefined8 *)(pcVar41 + 0x58);
            uVar26 = *(undefined8 *)(pcVar41 + 0x60);
            uVar27 = *(undefined8 *)(pcVar41 + 0x68);
            uVar28 = *(undefined8 *)(pcVar41 + 0x70);
            uVar29 = *(undefined8 *)(pcVar41 + 0x78);
            uVar30 = *(undefined8 *)(pcVar41 + 8);
            uVar31 = *(undefined8 *)(pcVar41 + 0x10);
            uVar32 = *(undefined8 *)(pcVar41 + 0x18);
            uVar33 = *(undefined8 *)(pcVar41 + 0x20);
            uVar34 = *(undefined8 *)(pcVar41 + 0x28);
            uVar35 = *(undefined8 *)(pcVar41 + 0x30);
            uVar36 = *(undefined8 *)(pcVar41 + 0x38);
            *(undefined8 *)(lVar4 + lVar44) = *(undefined8 *)pcVar41;
            ((undefined8 *)(lVar4 + lVar44))[1] = uVar30;
            puVar1 = (undefined8 *)(lVar4 + 0x70 + lVar44);
            *puVar1 = uVar28;
            puVar1[1] = uVar29;
            puVar1 = (undefined8 *)(lVar4 + 0x60 + lVar44);
            *puVar1 = uVar26;
            puVar1[1] = uVar27;
            puVar1 = (undefined8 *)(lVar4 + 0x50 + lVar44);
            *puVar1 = uVar24;
            puVar1[1] = uVar25;
            puVar1 = (undefined8 *)(lVar4 + 0x40 + lVar44);
            *puVar1 = uVar22;
            puVar1[1] = uVar23;
            puVar1 = (undefined8 *)(lVar4 + 0x30 + lVar44);
            *puVar1 = uVar35;
            puVar1[1] = uVar36;
            puVar1 = (undefined8 *)(lVar4 + 0x20 + lVar44);
            *puVar1 = uVar33;
            puVar1[1] = uVar34;
            puVar1 = (undefined8 *)(lVar4 + 0x10 + lVar44);
            *puVar1 = uVar31;
            puVar1[1] = uVar32;
            *(undefined8 *)(pcVar41 + 0x70) = uVar6;
            *(undefined8 *)(pcVar41 + 0x78) = uVar7;
            *(undefined8 *)(pcVar41 + 0x60) = uVar8;
            *(undefined8 *)(pcVar41 + 0x68) = uVar9;
            *(undefined8 *)(pcVar41 + 0x50) = uVar10;
            *(undefined8 *)(pcVar41 + 0x58) = uVar11;
            *(undefined8 *)(pcVar41 + 0x40) = uVar12;
            *(undefined8 *)(pcVar41 + 0x48) = uVar13;
            local_d8 = (undefined4)uVar14;
            uStack_d4 = (undefined4)((ulonglong)uVar14 >> 0x20);
            uStack_d0 = (undefined4)uVar15;
            uStack_cc = (undefined4)((ulonglong)uVar15 >> 0x20);
            local_c8 = (undefined4)uVar16;
            uStack_c4 = (undefined4)((ulonglong)uVar16 >> 0x20);
            uStack_c0 = (undefined4)uVar17;
            uStack_bc = (undefined4)((ulonglong)uVar17 >> 0x20);
            local_b8 = (undefined4)uVar18;
            uStack_b4 = (undefined4)((ulonglong)uVar18 >> 0x20);
            uStack_b0 = (undefined4)uVar19;
            uStack_ac = (undefined4)((ulonglong)uVar19 >> 0x20);
            local_a8 = (undefined4)uVar20;
            uStack_a4 = (undefined4)((ulonglong)uVar20 >> 0x20);
            uStack_a0 = (undefined4)uVar21;
            uStack_9c = (undefined4)((ulonglong)uVar21 >> 0x20);
            *(undefined4 *)(pcVar41 + 0x30) = local_a8;
            *(undefined4 *)(pcVar41 + 0x34) = uStack_a4;
            *(undefined4 *)(pcVar41 + 0x38) = uStack_a0;
            *(undefined4 *)(pcVar41 + 0x3c) = uStack_9c;
            *(undefined4 *)(pcVar41 + 0x20) = local_b8;
            *(undefined4 *)(pcVar41 + 0x24) = uStack_b4;
            *(undefined4 *)(pcVar41 + 0x28) = uStack_b0;
            *(undefined4 *)(pcVar41 + 0x2c) = uStack_ac;
            *(undefined4 *)(pcVar41 + 0x10) = local_c8;
            *(undefined4 *)(pcVar41 + 0x14) = uStack_c4;
            *(undefined4 *)(pcVar41 + 0x18) = uStack_c0;
            *(undefined4 *)(pcVar41 + 0x1c) = uStack_bc;
            *(undefined4 *)pcVar41 = local_d8;
            *(undefined4 *)(pcVar41 + 4) = uStack_d4;
            *(undefined4 *)(pcVar41 + 8) = uStack_d0;
            *(undefined4 *)(pcVar41 + 0xc) = uStack_cc;
            uVar38 = uVar39 + 1;
            uVar37 = uVar37 + 1;
          } while (uVar38 < uVar2);
          uVar38 = uVar39 + 1;
        }
        goto LAB_14000e85b;
      }
      uVar37 = uVar37 + 1;
      lVar40 = lVar40 + 0x80;
    } while (uVar2 != uVar37);
  }
  return;
}

