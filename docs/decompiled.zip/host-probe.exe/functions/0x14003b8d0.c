// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::vote_idle
// address: 0x14003b8d0
// body: available
// range: 0x14003b8d0-0x14003b9bd inclusive
// range: 0x14003b9c0-0x14003bae4 inclusive
// range: 0x14003baf0-0x14003c0ac inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003be1c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Function: ___chkstk_ms replaced with injection: alloca_probe */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::vote_idle */

void __rustcall host_probe[b94139f9089eb1d8]::net::vote_idle(undefined8 param_1,undefined4 param_2)

{
  code *pcVar1;
  ulonglong _Size;
  undefined1 *puVar2;
  void *_Src;
  byte bVar3;
  char cVar4;
  byte bVar5;
  longlong *_Dst;
  longlong lVar6;
  short *psVar7;
  undefined1 uVar8;
  longlong lVar9;
  ulonglong _Size_00;
  bool bVar10;
  longlong *plStack_100d0;
  undefined1 *puStack_100c8;
  longlong lStack_100c0;
  void *pvStack_100b8;
  size_t sStack_100b0;
  undefined4 uStack_100a8;
  undefined1 auStack_100a1 [17];
  longlong lStack_10090;
  undefined1 *puStack_10088;
  undefined8 uStack_10080;
  undefined1 *puStack_10078;
  byte bStack_10070;
  ulonglong uStack_10068;
  short asStack_10060 [16];
  undefined1 auStack_10040 [65528];
  undefined8 uStack_48;
  
  uStack_48 = 0x14003b8e6;
  if (DAT_140699990 == 0) {
    uStack_100a8 = param_2;
    uStack_10080 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    share_vote(uStack_10080);
    memset(auStack_10040,0,0x10000);
    <std[3bf9d48a0c3997f0]::net::udp::UdpSocket>::recv_from
              (&uStack_10068,&DAT_140699980,auStack_10040,0x10000);
    if (asStack_10060[0] != 2) {
      do {
        _Size_00 = uStack_10068;
        if (0x10000 < uStack_10068) {
          core[505b25137b8ba7f]::slice::index::slice_index_fail
                    (0,uStack_10068,0x10000,
                     &
                     PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a3230
                    );
                    /* WARNING: Does not return */
          pcVar1 = (code *)invalidInstructionException();
          (*pcVar1)();
        }
        reach_directory[4b72b9694f6c3c08]::rendezvous::relay_unwrap(&puStack_100c8,auStack_10040);
        _Size = sStack_100b0;
        _Src = pvStack_100b8;
        lVar6 = lStack_100c0;
        puVar2 = puStack_100c8;
        if (pvStack_100b8 == (void *)0x0) {
          if (_Size_00 == 0) {
            auStack_100a1[0] = 0;
          }
          else {
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            _Dst = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size_00,1);
            if (_Dst == (longlong *)0x0) {
LAB_14003c099:
              alloc[246c2e7857c81348]::raw_vec::handle_error(1,_Size_00);
                    /* WARNING: Does not return */
              pcVar1 = (code *)invalidInstructionException();
              (*pcVar1)();
            }
            memcpy(_Dst,auStack_10040,_Size_00);
            uVar8 = 0;
            auStack_100a1[0] = 0;
            _Size = _Size_00;
joined_r0x00014003bb35:
            if (7 < _Size) {
              if ((_Size < 0x10 || *_Dst != 0x31524545502d5252) || (_Dst[1] != 0x3145544f562d5252))
              {
LAB_14003be10:
                __rustc[9d087a5ab36ea756]::__rust_dealloc(_Dst,_Size,1);
                return;
              }
              LOCK();
              bVar10 = DAT_140699948 == '\0';
              if (bVar10) {
                DAT_140699948 = '\x01';
              }
              UNLOCK();
              if (!bVar10) {
                <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                          (&DAT_140699948);
              }
              if ((*(ulonglong *)
                    __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                  0x7fffffffffffffff) == 0) {
                bVar5 = 0;
              }
              else {
                bVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                bVar5 = bVar5 ^ 1;
              }
              if (DAT_140699949 == '\0') {
                if (IS_HOST_0_llvm_14435704873730135342 == '\0') {
                  cVar4 = is_host_route(&DAT_140699950,HOST_ID_0_llvm_14435704873730135342 != 0,
                                        HOST_ID_0_llvm_14435704873730135342,asStack_10060,uVar8,
                                        puStack_10088,lStack_10090);
                  if (cVar4 != '\0') {
                    if (((bVar5 == 0) &&
                        ((*(ulonglong *)
                           __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
                         & 0x7fffffffffffffff) != 0)) &&
                       (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
                       cVar4 == '\0')) {
                      DAT_140699949 = '\x01';
                    }
                    cVar4 = DAT_140699948;
                    LOCK();
                    DAT_140699948 = '\0';
                    UNLOCK();
                    if (cVar4 == '\x02') {
                      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
                    }
                    LOCK();
                    bVar10 = HOST_HEARD == '\0';
                    if (bVar10) {
                      HOST_HEARD = '\x01';
                    }
                    UNLOCK();
                    if (!bVar10) {
                      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                                (&HOST_HEARD);
                    }
                    if ((*(ulonglong *)
                          __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
                        & 0x7fffffffffffffff) == 0) {
                      bVar5 = 0;
                    }
                    else {
                      bVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                      bVar5 = bVar5 ^ 1;
                    }
                    if (DAT_140699511 != '\0') {
                      puStack_100c8 = &HOST_HEARD;
                      lStack_100c0._1_7_ = (undefined7)((ulonglong)lStack_100c0 >> 8);
                      lStack_100c0 = CONCAT71(lStack_100c0._1_7_,bVar5);
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("called `Result::unwrap()` on an `Err` value",0x2b,&puStack_100c8,
                                 &
                                 anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342
                                 ,&
                                  PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a3218
                                );
                      goto LAB_14003c097;
                    }
                    DAT_140699518 = uStack_10080;
                    DAT_140699520 = uStack_100a8;
                    if (((bVar5 == 0) &&
                        ((*(ulonglong *)
                           __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
                         & 0x7fffffffffffffff) != 0)) &&
                       (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
                       cVar4 == '\0')) {
                      DAT_140699511 = '\x01';
                    }
                    cVar4 = HOST_HEARD;
                    LOCK();
                    HOST_HEARD = '\0';
                    UNLOCK();
                    if (cVar4 == '\x02') {
                      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&HOST_HEARD);
                    }
                    vote::from_host(_Dst,_Size);
                    goto LAB_14003be10;
                  }
                }
                else {
                  psVar7 = asStack_10060;
                  lVar6 = route_peer(&DAT_140699950,psVar7,auStack_100a1);
                  if ((lVar6 == 1) && (cVar4 = is_blocked(psVar7,asStack_10060), cVar4 == '\0')) {
                    if ((bVar5 == 0) &&
                       (((*(ulonglong *)
                           __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
                         & 0x7fffffffffffffff) != 0 &&
                        (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
                        cVar4 == '\0')))) {
                      DAT_140699949 = '\x01';
                    }
                    cVar4 = DAT_140699948;
                    LOCK();
                    DAT_140699948 = '\0';
                    UNLOCK();
                    if (cVar4 == '\x02') {
                      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
                    }
                    vote::ballot_from(psVar7,_Dst,_Size);
                    goto LAB_14003be10;
                  }
                }
                if (((bVar5 == 0) &&
                    ((*(ulonglong *)
                       __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                     0x7fffffffffffffff) != 0)) &&
                   (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
                   cVar4 == '\0')) {
                  DAT_140699949 = '\x01';
                }
                cVar4 = DAT_140699948;
                LOCK();
                DAT_140699948 = '\0';
                UNLOCK();
                if (cVar4 == '\x02') {
                  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
                }
                goto LAB_14003be10;
              }
              puStack_100c8 = &DAT_140699948;
              lStack_100c0._1_7_ = (undefined7)((ulonglong)lStack_100c0 >> 8);
              lStack_100c0 = CONCAT71(lStack_100c0._1_7_,bVar5);
              core[505b25137b8ba7f]::result::unwrap_failed
                        ("called `Result::unwrap()` on an `Err` value",0x2b,&puStack_100c8,
                         &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                         &
                         PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a3200
                        );
              goto LAB_14003c097;
            }
            if (_Size != 0) goto LAB_14003be10;
          }
        }
        else {
          LOCK();
          bVar10 = RELAY_SESSIONS == '\0';
          if (bVar10) {
            RELAY_SESSIONS = '\x01';
          }
          UNLOCK();
          if (bVar10) {
            if ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) == 0) goto LAB_14003ba5d;
LAB_14003be51:
            bVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar3 = bVar5 ^ 1;
            bVar5 = bStack_10070;
          }
          else {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&RELAY_SESSIONS)
            ;
            if ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0) goto LAB_14003be51;
LAB_14003ba5d:
            bVar3 = 0;
            bVar5 = bStack_10070;
          }
          bStack_10070 = bVar3;
          if (DAT_140699611 != '\0') {
            puStack_10078 = &RELAY_SESSIONS;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&puStack_10078,
                       &
                       PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0fb0
                       ,&
                        PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a31e8
                      );
LAB_14003c097:
                    /* WARNING: Does not return */
            pcVar1 = (code *)invalidInstructionException();
            (*pcVar1)();
          }
          if (DAT_140699628 != 0) {
            lVar9 = 0;
            do {
              if (*(longlong *)(DAT_140699620 + 8 + lVar9) == lVar6 &&
                  *(undefined1 **)(DAT_140699620 + lVar9) == puVar2) {
                bVar10 = bStack_10070 == 0;
                bStack_10070 = bVar5;
                if (((bVar10) &&
                    ((*(ulonglong *)
                       __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                     0x7fffffffffffffff) != 0)) &&
                   (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
                   cVar4 == '\0')) {
                  DAT_140699611 = '\x01';
                }
                cVar4 = RELAY_SESSIONS;
                LOCK();
                RELAY_SESSIONS = '\0';
                UNLOCK();
                if (cVar4 == '\x02') {
                  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&RELAY_SESSIONS);
                }
                if ((longlong)_Size < 0) {
                  alloc[246c2e7857c81348]::raw_vec::handle_error(0,plStack_100d0);
                    /* WARNING: Does not return */
                  pcVar1 = (code *)invalidInstructionException();
                  (*pcVar1)();
                }
                if (_Size == 0) {
                  plStack_100d0 = (longlong *)0x1;
                }
                else {
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  plStack_100d0 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size,1);
                  _Size_00 = _Size;
                  if (plStack_100d0 == (longlong *)0x0) goto LAB_14003c099;
                  memcpy(plStack_100d0,_Src,_Size);
                }
                uVar8 = 1;
                auStack_100a1[0] = 1;
                _Dst = plStack_100d0;
                lStack_10090 = lVar6;
                puStack_10088 = puVar2;
                goto joined_r0x00014003bb35;
              }
              lVar9 = lVar9 + 0x10;
            } while (DAT_140699628 * 0x10 != lVar9);
          }
          bVar10 = bStack_10070 == 0;
          bStack_10070 = bVar5;
          if (((bVar10) &&
              ((*(ulonglong *)
                 __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
               0x7fffffffffffffff) != 0)) &&
             (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
             cVar4 == '\0')) {
            DAT_140699611 = '\x01';
          }
          cVar4 = RELAY_SESSIONS;
          LOCK();
          RELAY_SESSIONS = '\0';
          UNLOCK();
          if (cVar4 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&RELAY_SESSIONS);
          }
        }
        <std[3bf9d48a0c3997f0]::net::udp::UdpSocket>::recv_from
                  (&uStack_10068,&DAT_140699980,auStack_10040,0x10000);
      } while (asStack_10060[0] != 2);
    }
    if ((1 < ((uint)uStack_10068 & 3) - 2) && ((uStack_10068 & 3) != 0)) {
      lStack_100c0 = uStack_10068 - 1;
      puStack_100c8 = (undefined1 *)CONCAT71(puStack_100c8._1_7_,3);
      <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
      drop(&lStack_100c0);
    }
  }
  return;
}

