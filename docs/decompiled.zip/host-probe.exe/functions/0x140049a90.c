// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<usize>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<usize,core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::tally<host_probe[b94139f9089eb1d8]::server_admin::pick_tied>::{closure#0}>>>::from_iter
// address: 0x140049a90
// body: available
// range: 0x140049a90-0x140049c42 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<usize> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<usize,
   core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::vote::tally<host_probe[b94139f9089eb1d8]::server_admin::pick_tied>::{closure#0}>>>::from_iter
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<usize>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<usize,core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::tally<host_probe[b94139f9089eb1d8]::server_admin::pick_tied>::{closure#0}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong *plVar4;
  code *pcVar5;
  ulonglong uVar6;
  ulonglong *puVar7;
  ulonglong uVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong local_58;
  ulonglong *local_50;
  longlong local_48;
  
  uVar1 = param_2[4];
  uVar10 = param_2[3];
  uVar6 = uVar10;
  if (uVar10 < uVar1) {
    uVar6 = uVar1;
  }
  uVar2 = param_2[1];
  uVar8 = uVar2;
  if (uVar2 < uVar10) {
    uVar8 = uVar10;
  }
  if (uVar10 < uVar1) {
    lVar3 = *param_2;
    plVar4 = (longlong *)param_2[2];
    do {
      if (uVar8 == uVar10) {
        core[505b25137b8ba7f]::panicking::panic_bounds_check
                  (uVar8,uVar2,&anon_553b4e5fea14f94d7b140aed25da7182_25_llvm_1181841624220042269);
                    /* WARNING: Does not return */
        pcVar5 = (code *)invalidInstructionException();
        (*pcVar5)();
      }
      if (*(longlong *)(lVar3 + uVar10 * 8) == *plVar4) {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        puVar7 = (ulonglong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x20,8);
        if (puVar7 == (ulonglong *)0x0) {
          alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x20);
                    /* WARNING: Does not return */
          pcVar5 = (code *)invalidInstructionException();
          (*pcVar5)();
        }
        *puVar7 = uVar10;
        uVar10 = uVar10 + 1;
        local_58 = 4;
        local_48 = 1;
        local_50 = puVar7;
        if (uVar1 <= uVar10) goto LAB_140049be2;
        uVar6 = uVar2;
        if (uVar2 < uVar10) {
          uVar6 = uVar10;
        }
        lVar9 = 1;
        uVar8 = uVar1;
        goto LAB_140049b70;
      }
      uVar10 = uVar10 + 1;
    } while (uVar6 != uVar10);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
LAB_140049b70:
  if (uVar6 == uVar10) {
    core[505b25137b8ba7f]::panicking::panic_bounds_check
              (uVar6,uVar2,&anon_553b4e5fea14f94d7b140aed25da7182_25_llvm_1181841624220042269);
                    /* WARNING: Does not return */
    pcVar5 = (code *)invalidInstructionException();
    (*pcVar5)();
  }
  if (*(longlong *)(lVar3 + uVar10 * 8) != *plVar4) {
    uVar10 = uVar10 + 1;
    if (uVar8 == uVar10) goto LAB_140049be2;
    goto LAB_140049b70;
  }
  if (lVar9 == local_58) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_58,lVar9,1,8,8);
    puVar7 = local_50;
  }
  puVar7[lVar9] = uVar10;
  uVar10 = uVar10 + 1;
  lVar9 = lVar9 + 1;
  uVar8 = uVar10;
  if (uVar10 < uVar1) {
    uVar8 = uVar1;
  }
  uVar6 = uVar2;
  if (uVar2 < uVar10) {
    uVar6 = uVar10;
  }
  local_48 = lVar9;
  if (uVar1 <= uVar10) {
LAB_140049be2:
    param_1[2] = local_48;
    *param_1 = local_58;
    param_1[1] = (longlong)local_50;
    return param_1;
  }
  goto LAB_140049b70;
}

