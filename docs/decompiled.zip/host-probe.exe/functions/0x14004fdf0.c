// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<&str>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&str,core[505b25137b8ba7f]::str::iter::Split<char>>>::from_iter
// address: 0x14004fdf0
// body: available
// range: 0x14004fdf0-0x14004fe45 inclusive
// range: 0x14004fe50-0x140050051 inclusive
// range: 0x140050060-0x1400500a9 inclusive
// range: 0x1400500b0-0x14005014b inclusive
// range: 0x140050150-0x140050185 inclusive
// range: 0x140050190-0x1400501da inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<&str> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&str,
   core[505b25137b8ba7f]::str::iter::Split<char>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<&str>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&str,core[505b25137b8ba7f]::str::iter::Split<char>>>
::from_iter(longlong *param_1,ulonglong *param_2)

{
  char cVar1;
  ulonglong uVar2;
  code *pcVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  ulonglong uVar7;
  longlong *plVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  longlong lVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  longlong local_c0;
  longlong *local_b8;
  longlong local_b0;
  ulonglong local_a8;
  longlong *local_a0;
  ulonglong local_98;
  ulonglong local_90;
  ulonglong local_88;
  ulonglong uStack_80;
  ulonglong local_78;
  ulonglong uStack_70;
  ulonglong local_68;
  undefined8 uStack_60;
  ulonglong local_58;
  ulonglong uStack_50;
  undefined8 local_48;
  
  if (*(char *)((longlong)param_2 + 0x41) == '\0') {
    uVar2 = param_2[2];
    uVar16 = param_2[3];
    uVar17 = param_2[5];
    uVar15 = param_2[4];
    local_a0 = param_1;
    if (uVar15 <= uVar17 && uVar17 <= uVar16) {
      uVar13 = (ulonglong)(byte)param_2[7];
      cVar1 = *(char *)((longlong)param_2 + uVar13 + 0x2f);
      do {
        if (uVar17 - uVar15 < 0x10) {
          if (uVar17 == uVar15) {
LAB_14004feca:
            param_2[4] = uVar17;
            break;
          }
          uVar11 = 0;
          while (*(char *)(uVar2 + uVar15 + uVar11) != cVar1) {
            uVar11 = uVar11 + 1;
            if (uVar17 - uVar15 == uVar11) goto LAB_14004feca;
          }
        }
        else {
          uVar11 = uVar2 + uVar15;
          uVar7 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(cVar1);
          if ((uVar7 & 1) == 0) goto LAB_14004feca;
        }
        uVar15 = uVar15 + uVar11 + 1;
        param_2[4] = uVar15;
        if ((uVar15 <= uVar16 && uVar13 <= uVar15) &&
           (iVar6 = memcmp((void *)(uVar2 + (uVar15 - uVar13)),param_2 + 6,uVar13), iVar6 == 0)) {
          uVar16 = *param_2;
          lVar14 = (uVar15 - uVar13) - uVar16;
          *param_2 = uVar15;
          goto LAB_14004feef;
        }
      } while (uVar15 <= uVar17);
    }
    *(undefined1 *)((longlong)param_2 + 0x41) = 1;
    uVar16 = *param_2;
    lVar14 = param_2[1] - uVar16;
    param_1 = local_a0;
    if ((byte)(lVar14 != 0 | (byte)param_2[8]) == 1) {
LAB_14004feef:
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      plVar8 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x40,8);
      if (plVar8 == (longlong *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x40);
                    /* WARNING: Does not return */
        pcVar3 = (code *)invalidInstructionException();
        (*pcVar3)();
      }
      *plVar8 = uVar2 + uVar16;
      plVar8[1] = lVar14;
      local_c0 = 4;
      local_b0 = 1;
      local_88 = *param_2;
      local_a8 = param_2[1];
      uVar16 = param_2[2];
      local_90 = param_2[3];
      uVar17 = param_2[4];
      uVar15 = param_2[5];
      uVar2 = param_2[8];
      local_48 = uVar2;
      local_58 = param_2[6];
      uStack_50 = param_2[7];
      local_b8 = plVar8;
      if ((uVar2 & 0x100) == 0) {
        if (local_90 < uVar15) {
          if ((uVar2 & 1) != 0 || local_a8 - local_88 != 0) {
            plVar8[2] = uVar16 + local_88;
            plVar8[3] = local_a8 - local_88;
            local_b0 = 2;
          }
        }
        else {
          local_98 = param_2[7] & 0xff;
          uVar13 = local_88;
          uStack_80 = local_a8;
          local_78 = uVar16;
          uStack_70 = local_90;
          local_68 = uVar17;
          uStack_60 = uVar15;
          do {
            uVar11 = local_98;
            lVar14 = local_b0;
            uVar7 = uVar17;
            if (uVar17 <= uVar15) {
              cVar1 = *(char *)((longlong)&uStack_60 + local_98 + 7);
              do {
                uVar9 = uVar16 + uVar17;
                uVar7 = uVar15;
                if (uVar15 - uVar17 < 0x10) {
                  if (uVar15 == uVar17) break;
                  uVar12 = 0;
                  while (*(char *)(uVar9 + uVar12) != cVar1) {
                    uVar12 = uVar12 + 1;
                    if (uVar15 - uVar17 == uVar12) goto LAB_140050153;
                  }
                }
                else {
                  uVar10 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(cVar1);
                  uVar12 = uVar9;
                  if ((uVar10 & 1) == 0) break;
                }
                uVar17 = uVar17 + uVar12 + 1;
                if ((uVar11 <= uVar17 && uVar17 <= local_90) &&
                   (iVar6 = memcmp((void *)(uVar16 + (uVar17 - uVar11)),&local_58,uVar11),
                   iVar6 == 0)) {
                  bVar5 = false;
                  bVar4 = false;
                  uVar9 = uVar17;
                  uVar11 = uVar17 - uVar11;
                  goto joined_r0x000140050144;
                }
                uVar7 = uVar17;
              } while (uVar17 <= uVar15);
            }
LAB_140050153:
            local_48._0_2_ = CONCAT11(1,(undefined1)local_48);
            bVar5 = true;
            if (((uVar2 & 1) == 0) && (local_a8 == uVar13)) break;
            bVar4 = true;
            uVar9 = uVar13;
            uVar17 = uVar7;
            uVar11 = local_a8;
joined_r0x000140050144:
            if (lVar14 == local_c0) {
              <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
              <alloc[246c2e7857c81348]::alloc::Global>(&local_c0,lVar14,1,8,0x10);
              plVar8 = local_b8;
              bVar4 = bVar5;
            }
            plVar8[lVar14 * 2] = uVar13 + uVar16;
            plVar8[lVar14 * 2 + 1] = uVar11 - uVar13;
            local_b0 = lVar14 + 1;
            uVar13 = uVar9;
          } while (!bVar4);
        }
      }
      local_a0[2] = local_b0;
      *local_a0 = local_c0;
      local_a0[1] = (longlong)local_b8;
      return local_a0;
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

