// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::modmaps::rotation_in::{closure#1}>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,alloc[246c2e7857c81348]::string::String>>>>::from_iter
// address: 0x140048650
// body: available
// range: 0x140048650-0x1400489f9 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry,
   core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,
   host_probe[b94139f9089eb1d8]::modmaps::rotation_in::{closure#1}>,
   core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,
   alloc[246c2e7857c81348]::string::String>>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::modmaps::rotation_in::{closure#1}>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,alloc[246c2e7857c81348]::string::String>>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong lVar14;
  undefined1 local_209;
  longlong local_208;
  longlong *plStack_200;
  longlong local_1f8;
  longlong *local_1f0;
  longlong local_1e8;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 local_1d0;
  undefined4 uStack_1cc;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 local_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 local_1b0;
  undefined4 uStack_1ac;
  longlong lStack_1a8;
  longlong local_1a0;
  longlong local_198;
  longlong lStack_190;
  longlong local_188;
  longlong lStack_180;
  longlong local_178;
  undefined8 uStack_170;
  undefined8 local_168;
  undefined8 uStack_160;
  undefined8 local_158;
  undefined8 uStack_150;
  undefined8 local_148;
  undefined8 uStack_140;
  longlong local_138;
  undefined8 local_130;
  undefined4 local_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 local_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 local_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 local_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  longlong local_e8;
  undefined4 local_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined8 local_98;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  
  <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::modmaps::rotation_in::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::try_fold::
  <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::modmaps::rotation_in::_closure_1_>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,alloc[246c2e7857c81348]::string::String>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>>>
            (&local_1e8,param_2 + 1,&local_209,*param_2);
  if (local_1e8 != -2) {
    local_138 = local_1a0;
    local_178 = CONCAT44(uStack_1dc,uStack_1e0);
    uStack_170 = CONCAT44(uStack_1d4,uStack_1d8);
    local_168 = CONCAT44(uStack_1cc,local_1d0);
    uStack_160 = CONCAT44(uStack_1c4,uStack_1c8);
    local_158 = CONCAT44(uStack_1bc,local_1c0);
    uStack_150 = CONCAT44(uStack_1b4,uStack_1b8);
    local_148 = CONCAT44(uStack_1ac,local_1b0);
    uStack_140 = lStack_1a8;
    uVar5 = uStack_140;
    if (local_1e8 != -1) {
      local_e8 = local_1a0;
      uStack_140._0_4_ = (undefined4)lStack_1a8;
      uStack_140._4_4_ = (undefined4)((ulonglong)lStack_1a8 >> 0x20);
      local_f8 = local_1b0;
      uStack_f4 = uStack_1ac;
      uStack_f0 = (undefined4)uStack_140;
      uStack_ec = uStack_140._4_4_;
      local_108 = local_1c0;
      uStack_104 = uStack_1bc;
      uStack_100 = uStack_1b8;
      uStack_fc = uStack_1b4;
      local_118 = local_1d0;
      uStack_114 = uStack_1cc;
      uStack_110 = uStack_1c8;
      uStack_10c = uStack_1c4;
      local_128 = uStack_1e0;
      uStack_124 = uStack_1dc;
      uStack_120 = uStack_1d8;
      uStack_11c = uStack_1d4;
      local_1f0 = param_1;
      uStack_140 = uVar5;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      plVar13 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x140,8);
      if (plVar13 == (longlong *)0x0) {
        alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x140);
                    /* WARNING: Does not return */
        pcVar2 = (code *)invalidInstructionException();
        (*pcVar2)();
      }
      *plVar13 = local_1e8;
      plVar13[1] = CONCAT44(uStack_124,local_128);
      plVar13[2] = CONCAT44(uStack_11c,uStack_120);
      plVar13[3] = CONCAT44(uStack_114,local_118);
      plVar13[4] = CONCAT44(uStack_10c,uStack_110);
      plVar13[5] = CONCAT44(uStack_104,local_108);
      plVar13[6] = CONCAT44(uStack_fc,uStack_100);
      plVar13[7] = CONCAT44(uStack_f4,local_f8);
      plVar13[8] = CONCAT44(uStack_ec,uStack_f0);
      plVar13[9] = local_e8;
      local_208 = 4;
      local_1f8 = 1;
      local_188 = param_2[0xc];
      lStack_180 = param_2[0xd];
      local_198 = param_2[10];
      lStack_190 = param_2[0xb];
      lStack_1a8 = param_2[8];
      local_1a0 = param_2[9];
      local_1e8 = *param_2;
      uStack_1e0 = (undefined4)param_2[1];
      uStack_1dc = *(undefined4 *)((longlong)param_2 + 0xc);
      uStack_1d8 = (undefined4)param_2[2];
      uStack_1d4 = *(undefined4 *)((longlong)param_2 + 0x14);
      local_1d0 = (undefined4)param_2[3];
      uStack_1cc = *(undefined4 *)((longlong)param_2 + 0x1c);
      uStack_1c8 = (undefined4)param_2[4];
      uStack_1c4 = *(undefined4 *)((longlong)param_2 + 0x24);
      local_1c0 = (undefined4)param_2[5];
      uStack_1bc = *(undefined4 *)((longlong)param_2 + 0x2c);
      uStack_1b8 = (undefined4)param_2[6];
      uStack_1b4 = *(undefined4 *)((longlong)param_2 + 0x34);
      local_1b0 = (undefined4)param_2[7];
      uStack_1ac = *(undefined4 *)((longlong)param_2 + 0x3c);
      lVar14 = 0x58;
      plStack_200 = plVar13;
      while (lVar3 = local_1f8,
            <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::modmaps::rotation_in::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
            ::try_fold::
            <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::modmaps::rotation_in::_closure_1_>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,alloc[246c2e7857c81348]::string::String>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<host_probe[b94139f9089eb1d8]::modmaps::RotationEntry>>>
                      (&local_178,&uStack_1e0,&local_209,local_1e8), lVar4 = local_178,
            local_178 != -2) {
        local_48 = local_130;
        local_58 = uStack_140;
        uVar11 = local_58;
        uStack_50 = local_138;
        lVar12 = uStack_50;
        local_68 = uStack_150;
        uVar9 = local_68;
        uStack_60 = local_148;
        uVar10 = uStack_60;
        local_78 = uStack_160;
        uVar7 = local_78;
        uStack_70 = local_158;
        uVar8 = uStack_70;
        local_88 = uStack_170;
        uVar5 = local_88;
        uStack_80 = local_168;
        uVar6 = uStack_80;
        if (local_178 == -1) break;
        local_98 = local_130;
        local_88._0_4_ = (undefined4)uStack_170;
        local_d8 = (undefined4)local_88;
        local_88._4_4_ = (undefined4)((ulonglong)uStack_170 >> 0x20);
        uStack_d4 = local_88._4_4_;
        uStack_80._0_4_ = (undefined4)local_168;
        uStack_d0 = (undefined4)uStack_80;
        uStack_80._4_4_ = (undefined4)((ulonglong)local_168 >> 0x20);
        uStack_cc = uStack_80._4_4_;
        local_78._0_4_ = (undefined4)uStack_160;
        local_c8 = (undefined4)local_78;
        local_78._4_4_ = (undefined4)((ulonglong)uStack_160 >> 0x20);
        uStack_c4 = local_78._4_4_;
        uStack_70._0_4_ = (undefined4)local_158;
        uStack_c0 = (undefined4)uStack_70;
        uStack_70._4_4_ = (undefined4)((ulonglong)local_158 >> 0x20);
        uStack_bc = uStack_70._4_4_;
        local_68._0_4_ = (undefined4)uStack_150;
        local_b8 = (undefined4)local_68;
        local_68._4_4_ = (undefined4)((ulonglong)uStack_150 >> 0x20);
        uStack_b4 = local_68._4_4_;
        uStack_60._0_4_ = (undefined4)local_148;
        uStack_b0 = (undefined4)uStack_60;
        uStack_60._4_4_ = (undefined4)((ulonglong)local_148 >> 0x20);
        uStack_ac = uStack_60._4_4_;
        local_58._0_4_ = (undefined4)uStack_140;
        local_a8 = (undefined4)local_58;
        local_58._4_4_ = (undefined4)((ulonglong)uStack_140 >> 0x20);
        uStack_a4 = local_58._4_4_;
        uStack_50._0_4_ = (undefined4)local_138;
        uStack_a0 = (undefined4)uStack_50;
        uStack_50._4_4_ = (undefined4)((ulonglong)local_138 >> 0x20);
        uStack_9c = uStack_50._4_4_;
        local_88 = uStack_170;
        uStack_80 = local_168;
        local_78 = uStack_160;
        uStack_70 = local_158;
        local_68 = uStack_150;
        uStack_60 = local_148;
        local_58 = uStack_140;
        uStack_50 = local_138;
        if (lVar3 == local_208) {
          local_88 = uVar5;
          uStack_80 = uVar6;
          local_78 = uVar7;
          uStack_70 = uVar8;
          local_68 = uVar9;
          uStack_60 = uVar10;
          local_58 = uVar11;
          uStack_50 = lVar12;
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>(&local_208,lVar3,1,8,0x50);
          plVar13 = plStack_200;
        }
        *(longlong *)((longlong)plVar13 + lVar14 + -8) = lVar4;
        puVar1 = (undefined4 *)((longlong)plVar13 + lVar14);
        *puVar1 = local_d8;
        puVar1[1] = uStack_d4;
        puVar1[2] = uStack_d0;
        puVar1[3] = uStack_cc;
        puVar1 = (undefined4 *)((longlong)plVar13 + lVar14 + 0x10);
        *puVar1 = local_c8;
        puVar1[1] = uStack_c4;
        puVar1[2] = uStack_c0;
        puVar1[3] = uStack_bc;
        puVar1 = (undefined4 *)((longlong)plVar13 + lVar14 + 0x20);
        *puVar1 = local_b8;
        puVar1[1] = uStack_b4;
        puVar1[2] = uStack_b0;
        puVar1[3] = uStack_ac;
        puVar1 = (undefined4 *)((longlong)plVar13 + lVar14 + 0x30);
        *puVar1 = local_a8;
        puVar1[1] = uStack_a4;
        puVar1[2] = uStack_a0;
        puVar1[3] = uStack_9c;
        *(undefined8 *)((longlong)plVar13 + lVar14 + 0x40) = local_98;
        local_1f8 = lVar3 + 1;
        lVar14 = lVar14 + 0x50;
      }
      local_1f0[2] = local_1f8;
      *local_1f0 = local_208;
      local_1f0[1] = (longlong)plStack_200;
      return local_1f0;
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

