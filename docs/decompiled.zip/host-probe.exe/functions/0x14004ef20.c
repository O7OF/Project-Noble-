// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::send_vote::{closure#0}>,host_probe[b94139f9089eb1d8]::net::send_vote::{closure#1}>>>::from_iter
// address: 0x14004ef20
// body: available
// range: 0x14004ef20-0x14004ef57 inclusive
// range: 0x14004ef60-0x14004f273 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,
   host_probe[b94139f9089eb1d8]::net::Route>,
   host_probe[b94139f9089eb1d8]::net::send_vote::{closure#0}>,
   host_probe[b94139f9089eb1d8]::net::send_vote::{closure#1}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::send_vote::{closure#0}>,host_probe[b94139f9089eb1d8]::net::send_vote::{closure#1}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  undefined8 *puVar1;
  undefined1 auVar2 [16];
  int iVar3;
  longlong lVar4;
  undefined8 uVar5;
  code *pcVar6;
  uint uVar7;
  uint uVar8;
  char cVar9;
  uint uVar10;
  ulonglong uVar11;
  undefined8 *puVar12;
  undefined1 (*pauVar13) [16];
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  ushort uVar17;
  longlong local_f8;
  longlong local_f0;
  undefined8 *local_e8;
  longlong local_e0;
  int local_d4;
  undefined8 local_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 local_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  
  lVar14 = param_2[4];
  if (lVar14 != 0) {
    lVar15 = *param_2;
    pauVar13 = (undefined1 (*) [16])param_2[1];
    lVar4 = param_2[5];
    uVar10 = (uint)*(ushort *)(param_2 + 3);
    do {
      if ((short)uVar10 == 0) {
        do {
          auVar2 = *pauVar13;
          lVar15 = lVar15 + -0x500;
          pauVar13 = pauVar13 + 1;
          uVar17 = ((ushort)(SUB161(auVar2 >> 7,0) & 1) | (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1
                    | (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
                   (ushort)(byte)(auVar2[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar10 = (uint)uVar17;
        } while (uVar17 == 0);
        param_2[1] = (longlong)pauVar13;
        *param_2 = lVar15;
      }
      uVar7 = 0;
      for (uVar8 = uVar10; (uVar8 & 1) == 0; uVar8 = uVar8 >> 1 | 0x80000000) {
        uVar7 = uVar7 + 1;
      }
      uVar10 = uVar10 - 1 & uVar10;
      *(short *)(param_2 + 3) = (short)uVar10;
      lVar16 = (ulonglong)uVar7 * -0x50;
      lVar14 = lVar14 + -1;
      param_2[4] = lVar14;
      uVar11 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                         (lVar4,*(undefined8 *)(lVar15 + -0x48 + lVar16),
                          *(undefined4 *)(lVar15 + -0x40 + lVar16));
      if (uVar11 < 0x3c) {
        lVar16 = lVar16 + lVar15;
        cVar9 = host_probe[b94139f9089eb1d8]::net::is_blocked
                          (*(undefined8 *)(lVar16 + -0x50),lVar16 + -0x38);
        if (cVar9 == '\0') {
          iVar3 = *(int *)(lVar16 + -0x40);
          if (iVar3 != -1) {
            uVar5 = *(undefined8 *)(lVar16 + -0x48);
            local_c8 = *(undefined8 *)(lVar16 + -0x3c);
            uStack_c0 = *(undefined8 *)(lVar16 + -0x34);
            local_b8 = *(undefined4 *)(lVar16 + -0x2c);
            uStack_b4 = *(undefined4 *)(lVar16 + -0x28);
            uStack_b0 = *(undefined4 *)(lVar16 + -0x24);
            uStack_ac = *(undefined4 *)(lVar16 + -0x20);
            uStack_a8 = *(undefined4 *)(lVar16 + -0x1c);
            uStack_a4 = *(undefined4 *)(lVar16 + -0x18);
            uStack_a0 = *(undefined4 *)(lVar16 + -0x14);
            local_9c = *(undefined4 *)(lVar16 + -0x10);
            uStack_98 = *(undefined4 *)(lVar16 + -0xc);
            uStack_94 = *(undefined4 *)(lVar16 + -8);
            uStack_90 = *(undefined4 *)(lVar16 + -4);
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            puVar12 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x120,8);
            if (puVar12 == (undefined8 *)0x0) {
              alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x120);
                    /* WARNING: Does not return */
              pcVar6 = (code *)invalidInstructionException();
              (*pcVar6)();
            }
            *puVar12 = uVar5;
            *(int *)(puVar12 + 1) = iVar3;
            *(undefined8 *)((longlong)puVar12 + 0xc) = local_c8;
            *(undefined8 *)((longlong)puVar12 + 0x14) = uStack_c0;
            *(ulonglong *)((longlong)puVar12 + 0x1c) = CONCAT44(uStack_b4,local_b8);
            *(ulonglong *)((longlong)puVar12 + 0x24) = CONCAT44(uStack_ac,uStack_b0);
            *(ulonglong *)((longlong)puVar12 + 0x2c) = CONCAT44(uStack_a4,uStack_a8);
            *(ulonglong *)((longlong)puVar12 + 0x34) = CONCAT44(local_9c,uStack_a0);
            puVar12[7] = CONCAT44(uStack_98,local_9c);
            puVar12[8] = CONCAT44(uStack_90,uStack_94);
            local_f0 = 4;
            local_e0 = 1;
            local_e8 = puVar12;
            if (lVar14 == 0) goto LAB_14004f244;
            local_f8 = 1;
            goto LAB_14004f149;
          }
          break;
        }
      }
    } while (lVar14 != 0);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
LAB_14004f149:
  do {
    uVar17 = (ushort)uVar10;
    while (uVar17 == 0) {
      auVar2 = *pauVar13;
      lVar15 = lVar15 + -0x500;
      pauVar13 = pauVar13 + 1;
      uVar17 = ((ushort)(SUB161(auVar2 >> 7,0) & 1) | (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
                (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar2[0xf] >> 7) << 0xf) ^ 0xffff;
      uVar10 = (uint)uVar17;
    }
    uVar7 = 0;
    for (uVar8 = uVar10; (uVar8 & 1) == 0; uVar8 = uVar8 >> 1 | 0x80000000) {
      uVar7 = uVar7 + 1;
    }
    lVar16 = (ulonglong)uVar7 * -0x50;
    uVar11 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                       (lVar4,*(undefined8 *)(lVar15 + -0x48 + lVar16),
                        *(undefined4 *)(lVar15 + -0x40 + lVar16));
    uVar10 = uVar10 - 1 & uVar10;
    lVar14 = lVar14 + -1;
    if (uVar11 < 0x3c) {
      lVar16 = lVar16 + lVar15;
      cVar9 = host_probe[b94139f9089eb1d8]::net::is_blocked
                        (*(undefined8 *)(lVar16 + -0x50),lVar16 + -0x38);
      if (cVar9 == '\0') {
        local_d4 = *(int *)(lVar16 + -0x40);
        if (local_d4 == -1) break;
        local_d0 = *(undefined8 *)(lVar16 + -0x48);
        local_88 = *(undefined8 *)(lVar16 + -0x3c);
        uStack_80 = *(undefined8 *)(lVar16 + -0x34);
        local_78 = *(undefined4 *)(lVar16 + -0x2c);
        uStack_74 = *(undefined4 *)(lVar16 + -0x28);
        uStack_70 = *(undefined4 *)(lVar16 + -0x24);
        uStack_6c = *(undefined4 *)(lVar16 + -0x20);
        uStack_68 = *(undefined4 *)(lVar16 + -0x1c);
        uStack_64 = *(undefined4 *)(lVar16 + -0x18);
        uStack_60 = *(undefined4 *)(lVar16 + -0x14);
        local_5c = *(undefined4 *)(lVar16 + -0x10);
        uStack_58 = *(undefined4 *)(lVar16 + -0xc);
        uStack_54 = *(undefined4 *)(lVar16 + -8);
        uStack_50 = *(undefined4 *)(lVar16 + -4);
        if (local_f8 == local_f0) {
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
          <alloc[246c2e7857c81348]::alloc::Global>(&local_f0,local_f8,1,8,0x48);
          puVar12 = local_e8;
        }
        puVar12[local_f8 * 9] = local_d0;
        *(int *)(puVar12 + local_f8 * 9 + 1) = local_d4;
        puVar1 = (undefined8 *)((longlong)puVar12 + local_f8 * 0x48 + 0xc);
        *puVar1 = local_88;
        puVar1[1] = uStack_80;
        puVar1 = (undefined8 *)((longlong)puVar12 + local_f8 * 0x48 + 0x1c);
        *puVar1 = CONCAT44(uStack_74,local_78);
        puVar1[1] = CONCAT44(uStack_6c,uStack_70);
        puVar1 = (undefined8 *)((longlong)puVar12 + local_f8 * 0x48 + 0x2c);
        *puVar1 = CONCAT44(uStack_64,uStack_68);
        puVar1[1] = CONCAT44(local_5c,uStack_60);
        puVar12[local_f8 * 9 + 7] = CONCAT44(uStack_58,local_5c);
        (puVar12 + local_f8 * 9 + 7)[1] = CONCAT44(uStack_50,uStack_54);
        local_f8 = local_f8 + 1;
        local_e0 = local_f8;
      }
    }
  } while (lVar14 != 0);
LAB_14004f244:
  param_1[2] = local_e0;
  *param_1 = local_f0;
  param_1[1] = (longlong)local_e8;
  return param_1;
}

