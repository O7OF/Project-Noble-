// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::say_packet
// address: 0x14000dad0
// body: available
// range: 0x14000dad0-0x14000dead inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::say_packet */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::say_packet
          (undefined8 param_1,longlong param_2,undefined8 param_3)

{
  size_t sVar1;
  void *pvVar2;
  code *pcVar3;
  undefined4 *puVar4;
  undefined2 *puVar5;
  undefined8 uVar6;
  undefined4 local_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined8 local_a0;
  undefined8 uStack_98;
  undefined8 local_90;
  undefined4 *local_88;
  undefined8 local_80;
  undefined8 local_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58 [2];
  undefined8 local_48;
  
  local_58[0] = 0;
  local_48 = 0;
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  uVar6 = 4;
  puVar4 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
  if (puVar4 != (undefined4 *)0x0) {
    *puVar4 = 0x646e696b;
    local_90 = 4;
    local_80 = 4;
    local_88 = puVar4;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    puVar5 = (undefined2 *)__rustc[9d087a5ab36ea756]::__rust_alloc(3,1);
    if (puVar5 == (undefined2 *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,3);
      goto LAB_14000deac;
    }
    *(undefined1 *)(puVar5 + 1) = 0x79;
    *puVar5 = 0x6173;
    local_b0 = CONCAT31(local_b0._1_3_,3);
    uStack_a8 = 3;
    uStack_98 = 3;
    local_a0 = puVar5;
    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
    ::insert(&local_78,local_58,&local_90,&local_b0);
    if ((char)local_78 != -1) {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(&local_78)
      ;
    }
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar6 = 5;
    puVar4 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
    if (puVar4 != (undefined4 *)0x0) {
      *(undefined1 *)(puVar4 + 1) = 0x68;
      *puVar4 = 0x636f7065;
      local_90 = 5;
      local_80 = 5;
      sVar1 = *(size_t *)(param_2 + 0x68);
      local_88 = puVar4;
      if ((longlong)sVar1 < 0) {
        uVar6 = 0;
LAB_14000dc08:
        alloc[246c2e7857c81348]::raw_vec::handle_error(uVar6,sVar1);
        goto LAB_14000deac;
      }
      if (sVar1 == 0) {
        puVar5 = (undefined2 *)0x1;
      }
      else {
        pvVar2 = *(void **)(param_2 + 0x60);
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar6 = 1;
        puVar5 = (undefined2 *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
        if (puVar5 == (undefined2 *)0x0) goto LAB_14000dc08;
        memcpy(puVar5,pvVar2,sVar1);
      }
      local_b0 = CONCAT31(local_b0._1_3_,3);
      uStack_a8 = sVar1;
      local_a0 = puVar5;
      uStack_98 = sVar1;
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
      ::insert(&local_78,local_58,&local_90,&local_b0);
      if ((char)local_78 != -1) {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                  (&local_78);
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar6 = 5;
      puVar4 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
      if (puVar4 != (undefined4 *)0x0) {
        *(undefined1 *)(puVar4 + 1) = 0x65;
        *puVar4 = 0x636e6f6e;
        local_90 = 5;
        local_80 = 5;
        sVar1 = *(size_t *)(param_2 + 0xa0);
        local_88 = puVar4;
        if ((longlong)sVar1 < 0) {
          uVar6 = 0;
LAB_14000dcea:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uVar6,sVar1);
          goto LAB_14000deac;
        }
        if (sVar1 == 0) {
          puVar5 = (undefined2 *)0x1;
        }
        else {
          pvVar2 = *(void **)(param_2 + 0x98);
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar6 = 1;
          puVar5 = (undefined2 *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar1,1);
          if (puVar5 == (undefined2 *)0x0) goto LAB_14000dcea;
          memcpy(puVar5,pvVar2,sVar1);
        }
        local_b0 = CONCAT31(local_b0._1_3_,3);
        uStack_a8 = sVar1;
        local_a0 = puVar5;
        uStack_98 = sVar1;
        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
        ::insert(&local_78,local_58,&local_90,&local_b0);
        if ((char)local_78 != -1) {
          core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                    (&local_78);
        }
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar6 = 3;
        puVar4 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(3,1);
        if (puVar4 != (undefined4 *)0x0) {
          *(undefined1 *)((longlong)puVar4 + 2) = 0x67;
          *(undefined2 *)puVar4 = 0x736d;
          local_90 = 3;
          local_80 = 3;
          local_88 = puVar4;
          <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_serde_core[7f01a81d286c67f3]::ser::Serialize>
          ::serialize::<serde_json[7404bcab4dc139c7]::value::ser::Serializer>(&local_b0,param_3);
          if ((char)local_b0 != -1) {
            local_68 = (undefined4)local_a0;
            uStack_64 = local_a0._4_4_;
            uStack_60 = (undefined4)uStack_98;
            uStack_5c = uStack_98._4_4_;
            local_78 = CONCAT44(uStack_ac,local_b0);
            uStack_70 = (undefined4)uStack_a8;
            uStack_6c = uStack_a8._4_4_;
            <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
            ::insert(&local_b0,local_58,&local_90,&local_78);
            if ((char)local_b0 != -1) {
              core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                        (&local_b0);
            }
            uStack_a8 = local_58[0];
            uStack_98 = local_48;
            local_b0 = CONCAT31(local_b0._1_3_,5);
            host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet(param_1,&local_b0);
            return;
          }
          local_78 = uStack_a8;
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,&local_78,
                     &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                     &PTR_s_src_ingame_chat_transport_rs_1406a1240);
          goto LAB_14000deac;
        }
      }
    }
  }
  alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar6);
LAB_14000deac:
                    /* WARNING: Does not return */
  pcVar3 = (code *)invalidInstructionException();
  (*pcVar3)();
}

