// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
// address: 0x140003540
// body: available
// range: 0x140003540-0x140003612 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400035f5 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
          (ulonglong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  ulonglong uVar8;
  
  uVar1 = *param_1;
  uVar2 = param_1[3];
  if (uVar2 == 0) {
    uVar3 = param_1[1];
  }
  else {
    uVar3 = param_1[1];
    uVar8 = uVar1;
    if (param_1[2] < uVar1) {
      uVar8 = 0;
    }
    lVar4 = param_1[2] - uVar8;
    uVar6 = uVar1 - lVar4;
    uVar8 = uVar2 - uVar6;
    if (uVar2 < uVar6) {
      uVar8 = 0;
    }
    uVar5 = lVar4 + uVar2;
    if (uVar2 >= uVar6 && uVar2 - uVar6 != 0) {
      uVar5 = uVar1;
    }
    lVar7 = uVar5 - lVar4;
    if (lVar7 != 0) {
      lVar4 = lVar4 * 0x80 + uVar3;
      do {
        <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(lVar4);
        lVar4 = lVar4 + 0x80;
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
    }
    uVar5 = uVar3;
    if (uVar6 < uVar2) {
      do {
        <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(uVar5);
        uVar8 = uVar8 - 1;
        uVar5 = uVar5 + 0x80;
      } while (uVar8 != 0);
    }
  }
  if (uVar1 == 0) {
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar3,uVar1 << 7,8);
  return;
}

