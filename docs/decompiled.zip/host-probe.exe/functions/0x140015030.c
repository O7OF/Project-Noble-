// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::net::Impairment>::fate
// address: 0x140015030
// body: available
// range: 0x140015030-0x140015180 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::net::Impairment>::fate */

void __rustcall
<host_probe[b94139f9089eb1d8]::net::Impairment>::fate
          (longlong param_1,undefined8 param_2,undefined4 param_3)

{
  uint uVar1;
  code *pcVar2;
  ulonglong uVar3;
  undefined **ppuVar4;
  int iVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  
  if (*(int *)(param_1 + 0x70) == 0) {
    uVar3 = *(ulonglong *)(param_1 + 0x58) << 0xd ^ *(ulonglong *)(param_1 + 0x58);
    uVar3 = uVar3 >> 7 ^ uVar3;
    uVar3 = uVar3 << 0x11 ^ uVar3;
    *(ulonglong *)(param_1 + 0x58) = uVar3;
    uVar1 = *(uint *)(param_1 + 0x6c);
    if ((ulonglong)uVar1 == 0) {
      core[505b25137b8ba7f]::panicking::panic_const::panic_const_rem_by_zero
                (&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a15b0);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    if ((ulonglong)*(uint *)(param_1 + 0x68) <= uVar3 % ((ulonglong)uVar1 * 100)) {
      uVar7 = (ulonglong)*(uint *)(param_1 + 0x50) / 1000 + *(longlong *)(param_1 + 0x48) * 1000000;
      if (uVar7 == 0) {
        uVar3 = *(ulonglong *)(param_1 + 0x38);
        iVar5 = *(int *)(param_1 + 0x40);
        ppuVar4 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a15c8;
      }
      else {
        uVar3 = uVar3 << 0xd ^ uVar3;
        uVar3 = uVar3 >> 7 ^ uVar3;
        uVar3 = uVar3 << 0x11 ^ uVar3;
        *(ulonglong *)(param_1 + 0x58) = uVar3;
        uVar3 = (ulonglong)*(uint *)(param_1 + 0x40) / 1000 +
                *(longlong *)(param_1 + 0x38) * 1000000 + uVar3 % (uVar7 * 2 + 1);
        uVar6 = uVar3 - uVar7;
        if (uVar3 < uVar7) {
          uVar6 = 0;
        }
        uVar3 = uVar6 / 1000000;
        iVar5 = ((int)uVar6 + (int)uVar3 * -1000000) * 1000;
        ppuVar4 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a15e0;
      }
      <std[3bf9d48a0c3997f0]::time::Instant_as_core[505b25137b8ba7f]::ops::arith::Add<core[505b25137b8ba7f]::time::Duration>>
      ::add(param_2,param_3,uVar3,iVar5,ppuVar4);
      return;
    }
    *(uint *)(param_1 + 0x70) = uVar1 - 1;
  }
  else {
    *(int *)(param_1 + 0x70) = *(int *)(param_1 + 0x70) + -1;
  }
  *(longlong *)(param_1 + 0x60) = *(longlong *)(param_1 + 0x60) + 1;
  return;
}

