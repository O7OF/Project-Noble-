// rea decompile_all
// name: <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold::<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find::check<core[505b25137b8ba7f]::net::socket_addr::SocketAddr,&mut_host_probe[b94139f9089eb1d8]::announce::prepare::{closure#15}::{closure#0}>::{closure#0},core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
// address: 0x140008f30
// body: available
// range: 0x140008f30-0x140008f56 inclusive
// range: 0x140008f60-0x140008fd6 inclusive
// range: 0x140008fe0-0x14000903c inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
   as core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold::<(),
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find::check<core[505b25137b8ba7f]::net::socket_addr::SocketAddr,
   &mut host_probe[b94139f9089eb1d8]::announce::prepare::{closure#15}::{closure#0}>::{closure#0},
   core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
    */

void __rustcall
<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
::try_fold::
<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find::check<core[505b25137b8ba7f]::net::socket_addr::SocketAddr,&mut_host_probe[b94139f9089eb1d8]::announce::prepare::_closure_15_::_closure_0_>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
          (short *param_1,longlong *param_2,undefined8 *param_3)

{
  short sVar1;
  short *psVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  short *psVar6;
  short sVar7;
  short sVar8;
  undefined1 auVar9 [16];
  undefined4 local_28;
  undefined2 uStack_24;
  char cStack_22;
  char cStack_21;
  char cStack_20;
  char cStack_1f;
  char cStack_1e;
  char cStack_1d;
  char cStack_1c;
  char cStack_1b;
  char cStack_1a;
  char cStack_19;
  char local_18;
  char cStack_17;
  
  psVar6 = (short *)*param_2;
  sVar8 = 2;
  if (psVar6 != (short *)param_2[1]) {
    psVar2 = (short *)*param_3;
    sVar1 = *psVar2;
    do {
      sVar7 = *psVar6;
      uVar3 = *(undefined8 *)(psVar6 + 1);
      uVar4 = *(undefined8 *)(psVar6 + 5);
      if (sVar7 != sVar1) {
        if (sVar7 == 2) goto LAB_140008f6a;
        *param_2 = (longlong)(psVar6 + 0x10);
LAB_14000901f:
        uVar3 = *(undefined8 *)(psVar6 + 1);
        uVar4 = *(undefined8 *)(psVar6 + 5);
        uVar5 = *(undefined8 *)(psVar6 + 0xc);
        *(undefined8 *)(param_1 + 8) = *(undefined8 *)(psVar6 + 8);
        *(undefined8 *)(param_1 + 0xc) = uVar5;
        *(undefined8 *)(param_1 + 1) = uVar3;
        *(undefined8 *)(param_1 + 5) = uVar4;
        sVar8 = sVar7;
        goto LAB_140009032;
      }
      if ((char)sVar1 == '\0') {
        uStack_24 = (short)((ulonglong)uVar3 >> 0x20);
        if (uStack_24 != psVar2[3]) {
          sVar7 = 0;
          goto LAB_140009015;
        }
        local_28 = (int)uVar3;
        if (local_28 != *(int *)(psVar2 + 1)) goto LAB_140008ff9;
      }
      else {
        sVar7 = 1;
        if (((psVar6[0xe] != psVar2[0xe]) || (*(int *)(psVar6 + 10) != *(int *)(psVar2 + 10))) ||
           (*(int *)(psVar6 + 0xc) != *(int *)(psVar2 + 0xc))) {
LAB_140009015:
          *param_2 = (longlong)(psVar6 + 0x10);
          goto LAB_14000901f;
        }
        local_28._2_1_ = (char)((ulonglong)uVar3 >> 0x10);
        local_28._3_1_ = (char)((ulonglong)uVar3 >> 0x18);
        uStack_24._0_1_ = (char)((ulonglong)uVar3 >> 0x20);
        uStack_24._1_1_ = (char)((ulonglong)uVar3 >> 0x28);
        cStack_22 = (char)((ulonglong)uVar3 >> 0x30);
        cStack_21 = (char)((ulonglong)uVar3 >> 0x38);
        cStack_20 = (char)uVar4;
        cStack_1f = (char)((ulonglong)uVar4 >> 8);
        cStack_1e = (char)((ulonglong)uVar4 >> 0x10);
        cStack_1d = (char)((ulonglong)uVar4 >> 0x18);
        cStack_1c = (char)((ulonglong)uVar4 >> 0x20);
        cStack_1b = (char)((ulonglong)uVar4 >> 0x28);
        cStack_1a = (char)((ulonglong)uVar4 >> 0x30);
        cStack_19 = (char)((ulonglong)uVar4 >> 0x38);
        local_18 = (char)psVar6[9];
        cStack_17 = (char)((ushort)psVar6[9] >> 8);
        auVar9[0] = -((char)psVar2[2] == local_28._2_1_);
        auVar9[1] = -(*(char *)((longlong)psVar2 + 5) == local_28._3_1_);
        auVar9[2] = -((char)psVar2[3] == (char)uStack_24);
        auVar9[3] = -(*(char *)((longlong)psVar2 + 7) == uStack_24._1_1_);
        auVar9[4] = -((char)psVar2[4] == cStack_22);
        auVar9[5] = -(*(char *)((longlong)psVar2 + 9) == cStack_21);
        auVar9[6] = -((char)psVar2[5] == cStack_20);
        auVar9[7] = -(*(char *)((longlong)psVar2 + 0xb) == cStack_1f);
        auVar9[8] = -((char)psVar2[6] == cStack_1e);
        auVar9[9] = -(*(char *)((longlong)psVar2 + 0xd) == cStack_1d);
        auVar9[10] = -((char)psVar2[7] == cStack_1c);
        auVar9[0xb] = -(*(char *)((longlong)psVar2 + 0xf) == cStack_1b);
        auVar9[0xc] = -((char)psVar2[8] == cStack_1a);
        auVar9[0xd] = -(*(char *)((longlong)psVar2 + 0x11) == cStack_19);
        auVar9[0xe] = -((char)psVar2[9] == local_18);
        auVar9[0xf] = -(*(char *)((longlong)psVar2 + 0x13) == cStack_17);
        if ((ushort)((ushort)(SUB161(auVar9 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar9 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar9 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar9 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar9 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar9 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar9 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar9 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar9 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar9 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar9 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar9 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar9 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar9 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar9 >> 0x77,0) & 1) << 0xe |
                    (ushort)(auVar9[0xf] >> 7) << 0xf) != 0xffff) {
LAB_140008ff9:
          *param_2 = (longlong)(psVar6 + 0x10);
          sVar7 = sVar1;
          goto LAB_14000901f;
        }
      }
LAB_140008f6a:
      psVar6 = psVar6 + 0x10;
    } while (psVar6 != (short *)param_2[1]);
    *param_2 = (longlong)psVar6;
  }
LAB_140009032:
  *param_1 = sVar8;
  return;
}

