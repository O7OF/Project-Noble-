// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::position::check<&host_probe[b94139f9089eb1d8]::fileshare::Part,<host_probe[b94139f9089eb1d8]::fileshare::Receiver>::chunk::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::fileshare::Part)>>::call_mut
// address: 0x14003f270
// body: available
// range: 0x14003f270-0x14003f2c5 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut 
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::position::check<&host_probe[b94139f9089eb1d8]::fileshare::Part,
   <host_probe[b94139f9089eb1d8]::fileshare::Receiver>::chunk::{closure#0}>::{closure#0} as
   core[505b25137b8ba7f]::ops::function::FnMut<((),
   &host_probe[b94139f9089eb1d8]::fileshare::Part)>>::call_mut */

undefined8 __rustcall
<&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::position::check<&host_probe[b94139f9089eb1d8]::fileshare::Part,<host_probe[b94139f9089eb1d8]::fileshare::Receiver>::chunk::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::fileshare::Part)>>
::call_mut(undefined8 *param_1,longlong param_2)

{
  char *pcVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  
  param_1 = (undefined8 *)*param_1;
  if (*(char *)(param_2 + 0x44) == *(char *)*param_1) {
    pcVar1 = (char *)param_1[1];
    auVar3[0] = -(*pcVar1 == *(char *)(param_2 + 0x18));
    auVar3[1] = -(pcVar1[1] == *(char *)(param_2 + 0x19));
    auVar3[2] = -(pcVar1[2] == *(char *)(param_2 + 0x1a));
    auVar3[3] = -(pcVar1[3] == *(char *)(param_2 + 0x1b));
    auVar3[4] = -(pcVar1[4] == *(char *)(param_2 + 0x1c));
    auVar3[5] = -(pcVar1[5] == *(char *)(param_2 + 0x1d));
    auVar3[6] = -(pcVar1[6] == *(char *)(param_2 + 0x1e));
    auVar3[7] = -(pcVar1[7] == *(char *)(param_2 + 0x1f));
    auVar3[8] = -(pcVar1[8] == *(char *)(param_2 + 0x20));
    auVar3[9] = -(pcVar1[9] == *(char *)(param_2 + 0x21));
    auVar3[10] = -(pcVar1[10] == *(char *)(param_2 + 0x22));
    auVar3[0xb] = -(pcVar1[0xb] == *(char *)(param_2 + 0x23));
    auVar3[0xc] = -(pcVar1[0xc] == *(char *)(param_2 + 0x24));
    auVar3[0xd] = -(pcVar1[0xd] == *(char *)(param_2 + 0x25));
    auVar3[0xe] = -(pcVar1[0xe] == *(char *)(param_2 + 0x26));
    auVar3[0xf] = -(pcVar1[0xf] == *(char *)(param_2 + 0x27));
    auVar2[0] = -(pcVar1[0x10] == *(char *)(param_2 + 0x28));
    auVar2[1] = -(pcVar1[0x11] == *(char *)(param_2 + 0x29));
    auVar2[2] = -(pcVar1[0x12] == *(char *)(param_2 + 0x2a));
    auVar2[3] = -(pcVar1[0x13] == *(char *)(param_2 + 0x2b));
    auVar2[4] = -(pcVar1[0x14] == *(char *)(param_2 + 0x2c));
    auVar2[5] = -(pcVar1[0x15] == *(char *)(param_2 + 0x2d));
    auVar2[6] = -(pcVar1[0x16] == *(char *)(param_2 + 0x2e));
    auVar2[7] = -(pcVar1[0x17] == *(char *)(param_2 + 0x2f));
    auVar2[8] = -(pcVar1[0x18] == *(char *)(param_2 + 0x30));
    auVar2[9] = -(pcVar1[0x19] == *(char *)(param_2 + 0x31));
    auVar2[10] = -(pcVar1[0x1a] == *(char *)(param_2 + 0x32));
    auVar2[0xb] = -(pcVar1[0x1b] == *(char *)(param_2 + 0x33));
    auVar2[0xc] = -(pcVar1[0x1c] == *(char *)(param_2 + 0x34));
    auVar2[0xd] = -(pcVar1[0x1d] == *(char *)(param_2 + 0x35));
    auVar2[0xe] = -(pcVar1[0x1e] == *(char *)(param_2 + 0x36));
    auVar2[0xf] = -(pcVar1[0x1f] == *(char *)(param_2 + 0x37));
    auVar2 = auVar2 & auVar3;
    if ((ushort)((ushort)(SUB161(auVar2 >> 7,0) & 1) | (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
                 (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
                (ushort)(byte)(auVar2[0xf] >> 7) << 0xf) == 0xffff) {
      return 1;
    }
  }
  *(longlong *)param_1[2] = *(longlong *)param_1[2] + 1;
  return 0;
}

