// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::peer_routed
// address: 0x140023ea0
// body: available
// range: 0x140023ea0-0x140024084 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::peer_routed */

ulonglong __rustcall host_probe[b94139f9089eb1d8]::net::peer_routed(longlong param_1)

{
  char *pcVar1;
  code *pcVar2;
  uint uVar3;
  uint uVar4;
  undefined *puVar5;
  char cVar6;
  ulonglong uVar7;
  ulonglong unaff_RBP;
  longlong lVar8;
  uint uVar9;
  ushort uVar10;
  bool bVar11;
  byte bVar12;
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  longlong local_38;
  undefined1 *local_30;
  byte local_28;
  
  if (DAT_140699990 == 0) {
    LOCK();
    bVar11 = DAT_140699948 == '\0';
    if (bVar11) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    local_38 = param_1;
    if (!bVar11) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    puVar5 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      local_28 = 0;
    }
    else {
      local_28 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      local_28 = local_28 ^ 1;
    }
    if (DAT_140699949 != '\0') {
      local_30 = &DAT_140699948;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_30,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &anon_d5c34e88a06ee720b116585eb143da4b_39_llvm_14435704873730135342);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    if (DAT_140699968 != 0) {
      uVar7 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
              ::hash_one::<&usize>(&DAT_140699970,&local_38);
      bVar12 = (byte)(uVar7 >> 0x39);
      auVar13 = ZEXT216(CONCAT11(bVar12,bVar12));
      auVar13 = pshuflw(auVar13,auVar13,0);
      lVar8 = 0;
      while( true ) {
        uVar7 = uVar7 & DAT_140699958;
        pcVar1 = (char *)(DAT_140699950 + uVar7);
        auVar15[0] = -(*pcVar1 == auVar13[0]);
        auVar15[1] = -(pcVar1[1] == auVar13[1]);
        auVar15[2] = -(pcVar1[2] == auVar13[2]);
        auVar15[3] = -(pcVar1[3] == auVar13[3]);
        auVar15[4] = -(pcVar1[4] == auVar13[4]);
        auVar15[5] = -(pcVar1[5] == auVar13[5]);
        auVar15[6] = -(pcVar1[6] == auVar13[6]);
        auVar15[7] = -(pcVar1[7] == auVar13[7]);
        auVar15[8] = -(pcVar1[8] == auVar13[0]);
        auVar15[9] = -(pcVar1[9] == auVar13[1]);
        auVar15[10] = -(pcVar1[10] == auVar13[2]);
        auVar15[0xb] = -(pcVar1[0xb] == auVar13[3]);
        auVar15[0xc] = -(pcVar1[0xc] == auVar13[4]);
        auVar15[0xd] = -(pcVar1[0xd] == auVar13[5]);
        auVar15[0xe] = -(pcVar1[0xe] == auVar13[6]);
        auVar15[0xf] = -(pcVar1[0xf] == auVar13[7]);
        uVar10 = (ushort)(SUB161(auVar15 >> 7,0) & 1) | (ushort)(SUB161(auVar15 >> 0xf,0) & 1) << 1
                 | (ushort)(SUB161(auVar15 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar15 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar15 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar15 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar15 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar15 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar15 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar15 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar15 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar15 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar15 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar15 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar15 >> 0x77,0) & 1) << 0xe | (ushort)(auVar15[0xf] >> 7) << 0xf
        ;
        uVar9 = (uint)uVar10;
        while (uVar10 != 0) {
          uVar3 = 0;
          for (uVar4 = uVar9; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
            uVar3 = uVar3 + 1;
          }
          unaff_RBP = CONCAT71((int7)(unaff_RBP >> 8),1);
          if (param_1 ==
              *(longlong *)(DAT_140699950 + -0x50 + (uVar3 + uVar7 & DAT_140699958) * -0x50))
          goto LAB_140023faf;
          uVar10 = (ushort)(uVar9 - 1) & (ushort)uVar9;
          uVar9 = CONCAT22((short)(uVar9 - 1 >> 0x10),uVar10);
        }
        auVar14[0] = -(*pcVar1 == -1);
        auVar14[1] = -(pcVar1[1] == -1);
        auVar14[2] = -(pcVar1[2] == -1);
        auVar14[3] = -(pcVar1[3] == -1);
        auVar14[4] = -(pcVar1[4] == -1);
        auVar14[5] = -(pcVar1[5] == -1);
        auVar14[6] = -(pcVar1[6] == -1);
        auVar14[7] = -(pcVar1[7] == -1);
        auVar14[8] = -(pcVar1[8] == -1);
        auVar14[9] = -(pcVar1[9] == -1);
        auVar14[10] = -(pcVar1[10] == -1);
        auVar14[0xb] = -(pcVar1[0xb] == -1);
        auVar14[0xc] = -(pcVar1[0xc] == -1);
        auVar14[0xd] = -(pcVar1[0xd] == -1);
        auVar14[0xe] = -(pcVar1[0xe] == -1);
        auVar14[0xf] = -(pcVar1[0xf] == -1);
        if ((((((((((((((((SUB161(auVar14 >> 7,0) & 1) != 0 || (SUB161(auVar14 >> 0xf,0) & 1) != 0)
                        || (SUB161(auVar14 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar14 >> 0x1f,0) & 1) != 0) || (SUB161(auVar14 >> 0x27,0) & 1) != 0
                      ) || (SUB161(auVar14 >> 0x2f,0) & 1) != 0) ||
                    (SUB161(auVar14 >> 0x37,0) & 1) != 0) || (SUB161(auVar14 >> 0x3f,0) & 1) != 0)
                  || (SUB161(auVar14 >> 0x47,0) & 1) != 0) || (SUB161(auVar14 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar14 >> 0x57,0) & 1) != 0) || (SUB161(auVar14 >> 0x5f,0) & 1) != 0) ||
              (SUB161(auVar14 >> 0x67,0) & 1) != 0) || (SUB161(auVar14 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar14 >> 0x77,0) & 1) != 0) || auVar14[0xf] < '\0') break;
        uVar7 = uVar7 + lVar8 + 0x10;
        lVar8 = lVar8 + 0x10;
      }
    }
    unaff_RBP = 0;
LAB_140023faf:
    if (((local_28 == 0) && ((*(ulonglong *)puVar5 & 0x7fffffffffffffff) != 0)) &&
       (cVar6 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar6 == '\0'))
    {
      DAT_140699949 = '\x01';
    }
    cVar6 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar6 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    uVar7 = unaff_RBP & 0xffffffff;
  }
  else {
    uVar7 = 0;
  }
  return uVar7;
}

