// rea decompile_all
// name: <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::hash::Hash>::hash::<std[3bf9d48a0c3997f0]::hash::random::DefaultHasher>
// address: 0x1400093a0
// body: available
// range: 0x1400093a0-0x140009472 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::net::socket_addr::SocketAddr as
   core[505b25137b8ba7f]::hash::Hash>::hash::<std[3bf9d48a0c3997f0]::hash::random::DefaultHasher> */

void __rustcall
<core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::hash::Hash>::hash::
<std[3bf9d48a0c3997f0]::hash::random::DefaultHasher>(ushort *param_1,undefined8 param_2)

{
  ushort uVar1;
  undefined8 uVar2;
  ulonglong local_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar1 = *param_1;
  local_28 = (ulonglong)uVar1;
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(param_2,&local_28,8);
  if ((ulonglong)uVar1 == 1) {
    local_28 = *(ulonglong *)(param_1 + 2);
    uStack_20 = *(undefined4 *)(param_1 + 6);
    uStack_1c = *(undefined4 *)(param_1 + 8);
    <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
    ::write(param_2,&local_28,0x10);
    local_28 = CONCAT62(local_28._2_6_,param_1[0xe]);
    <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
    ::write(param_2,&local_28,2);
    local_28._0_4_ = *(undefined4 *)(param_1 + 10);
    <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
    ::write(param_2,&local_28,4);
    local_28 = CONCAT44(local_28._4_4_,*(undefined4 *)(param_1 + 0xc));
    uVar2 = 4;
  }
  else {
    local_28 = CONCAT44(local_28._4_4_,*(undefined4 *)(param_1 + 1));
    <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
    ::write(param_2,&local_28,4);
    local_28 = CONCAT62(local_28._2_6_,param_1[3]);
    uVar2 = 2;
  }
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(param_2,&local_28,uVar2);
  return;
}

