// rea decompile_all
// name: <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnOnce<(core[505b25137b8ba7f]::option::Option<&mut_core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>>>,)>>::call_once
// address: 0x140041f80
// body: available
// range: 0x140041f80-0x140041fe5 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140041fe1 to 0x14027b5c0 <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>::try_initialize::<<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn> (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::{closure#0} as
   core[505b25137b8ba7f]::ops::function::FnOnce<(core[505b25137b8ba7f]::option::Option<&mut
   core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::cell::Cell<(u64,
   u64)>>>,)>>::call_once */

void __rustcall
<<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnOnce<(core[505b25137b8ba7f]::option::Option<&mut_core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>>>,)>>
::call_once(undefined8 param_1)

{
  undefined *puVar1;
  LPVOID pvVar2;
  DWORD dwTlsIndex;
  
  puVar1 = 
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
  ;
  if (*(longlong *)
       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
      != 0) {
    std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
  }
  if (*(int *)(puVar1 + 0x18) == 0) {
    dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                           (
                           __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                           );
    pvVar2 = TlsGetValue(dwTlsIndex);
  }
  else {
    dwTlsIndex = *(int *)(puVar1 + 0x18) - 1;
    pvVar2 = TlsGetValue(dwTlsIndex);
  }
  if ((LPVOID)0x1 < pvVar2) {
    return;
  }
  <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
  ::try_initialize::
  <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
            (dwTlsIndex,pvVar2,param_1);
  return;
}

