// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::peer_blocked
// address: 0x140024230
// body: available
// range: 0x140024230-0x140024486 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::peer_blocked */

void __rustcall host_probe[b94139f9089eb1d8]::net::peer_blocked(longlong param_1)

{
  char *pcVar1;
  code *pcVar2;
  uint uVar3;
  uint uVar4;
  undefined *puVar5;
  byte bVar6;
  char cVar7;
  ulonglong uVar8;
  longlong lVar9;
  uint uVar10;
  ushort uVar11;
  longlong lVar12;
  bool bVar13;
  byte bVar14;
  undefined1 auVar15 [16];
  undefined1 auVar16 [16];
  undefined1 auVar17 [16];
  undefined1 *local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  longlong local_50;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  
  local_50 = param_1;
  if (DAT_140699990 == 0) {
    LOCK();
    bVar13 = DAT_140699948 == '\0';
    if (bVar13) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar13) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    puVar5 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar6 = 0;
    }
    else {
      bVar6 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar6 = bVar6 ^ 1;
    }
    if (DAT_140699949 != '\0') {
      local_78 = &DAT_140699948;
      uVar8 = (ulonglong)uStack_70 >> 8;
      uStack_70 = CONCAT71((int7)uVar8,bVar6);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_78,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0728);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    bVar13 = true;
    if (DAT_140699968 != 0) {
      uVar8 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
              ::hash_one::<&usize>(&DAT_140699970,&local_50);
      bVar14 = (byte)(uVar8 >> 0x39);
      auVar15 = ZEXT216(CONCAT11(bVar14,bVar14));
      auVar15 = pshuflw(auVar15,auVar15,0);
      lVar9 = 0;
      while( true ) {
        uVar8 = uVar8 & DAT_140699958;
        pcVar1 = (char *)(DAT_140699950 + uVar8);
        auVar17[0] = -(*pcVar1 == auVar15[0]);
        auVar17[1] = -(pcVar1[1] == auVar15[1]);
        auVar17[2] = -(pcVar1[2] == auVar15[2]);
        auVar17[3] = -(pcVar1[3] == auVar15[3]);
        auVar17[4] = -(pcVar1[4] == auVar15[4]);
        auVar17[5] = -(pcVar1[5] == auVar15[5]);
        auVar17[6] = -(pcVar1[6] == auVar15[6]);
        auVar17[7] = -(pcVar1[7] == auVar15[7]);
        auVar17[8] = -(pcVar1[8] == auVar15[0]);
        auVar17[9] = -(pcVar1[9] == auVar15[1]);
        auVar17[10] = -(pcVar1[10] == auVar15[2]);
        auVar17[0xb] = -(pcVar1[0xb] == auVar15[3]);
        auVar17[0xc] = -(pcVar1[0xc] == auVar15[4]);
        auVar17[0xd] = -(pcVar1[0xd] == auVar15[5]);
        auVar17[0xe] = -(pcVar1[0xe] == auVar15[6]);
        auVar17[0xf] = -(pcVar1[0xf] == auVar15[7]);
        uVar11 = (ushort)(SUB161(auVar17 >> 7,0) & 1) | (ushort)(SUB161(auVar17 >> 0xf,0) & 1) << 1
                 | (ushort)(SUB161(auVar17 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar17 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar17 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar17 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar17 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar17 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar17 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar17 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar17 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar17 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar17 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar17 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar17 >> 0x77,0) & 1) << 0xe | (ushort)(auVar17[0xf] >> 7) << 0xf
        ;
        uVar10 = (uint)uVar11;
        while (uVar11 != 0) {
          uVar3 = 0;
          for (uVar4 = uVar10; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
            uVar3 = uVar3 + 1;
          }
          lVar12 = (uVar3 + uVar8 & DAT_140699958) * -0x50;
          if (param_1 == *(longlong *)(DAT_140699950 + -0x50 + lVar12)) {
            lVar12 = DAT_140699950 + lVar12;
            local_28 = *(undefined4 *)(lVar12 + -0x1c);
            local_38 = (undefined4)*(undefined8 *)(lVar12 + -0x2c);
            uStack_34 = (undefined4)((ulonglong)*(undefined8 *)(lVar12 + -0x2c) >> 0x20);
            uStack_30 = (undefined4)*(undefined8 *)(lVar12 + -0x24);
            uStack_2c = (undefined4)((ulonglong)*(undefined8 *)(lVar12 + -0x24) >> 0x20);
            local_48 = (undefined4)*(undefined8 *)(lVar12 + -0x3c);
            uStack_44 = (undefined4)((ulonglong)*(undefined8 *)(lVar12 + -0x3c) >> 0x20);
            uStack_40 = (undefined4)*(undefined8 *)(lVar12 + -0x34);
            uStack_3c = (undefined4)((ulonglong)*(undefined8 *)(lVar12 + -0x34) >> 0x20);
            bVar13 = *(int *)(lVar12 + -0x40) == -1;
            goto LAB_140024366;
          }
          uVar11 = (ushort)(uVar10 - 1) & (ushort)uVar10;
          uVar10 = CONCAT22((short)(uVar10 - 1 >> 0x10),uVar11);
        }
        auVar16[0] = -(*pcVar1 == -1);
        auVar16[1] = -(pcVar1[1] == -1);
        auVar16[2] = -(pcVar1[2] == -1);
        auVar16[3] = -(pcVar1[3] == -1);
        auVar16[4] = -(pcVar1[4] == -1);
        auVar16[5] = -(pcVar1[5] == -1);
        auVar16[6] = -(pcVar1[6] == -1);
        auVar16[7] = -(pcVar1[7] == -1);
        auVar16[8] = -(pcVar1[8] == -1);
        auVar16[9] = -(pcVar1[9] == -1);
        auVar16[10] = -(pcVar1[10] == -1);
        auVar16[0xb] = -(pcVar1[0xb] == -1);
        auVar16[0xc] = -(pcVar1[0xc] == -1);
        auVar16[0xd] = -(pcVar1[0xd] == -1);
        auVar16[0xe] = -(pcVar1[0xe] == -1);
        auVar16[0xf] = -(pcVar1[0xf] == -1);
        if ((((((((((((((((SUB161(auVar16 >> 7,0) & 1) != 0 || (SUB161(auVar16 >> 0xf,0) & 1) != 0)
                        || (SUB161(auVar16 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar16 >> 0x1f,0) & 1) != 0) || (SUB161(auVar16 >> 0x27,0) & 1) != 0
                      ) || (SUB161(auVar16 >> 0x2f,0) & 1) != 0) ||
                    (SUB161(auVar16 >> 0x37,0) & 1) != 0) || (SUB161(auVar16 >> 0x3f,0) & 1) != 0)
                  || (SUB161(auVar16 >> 0x47,0) & 1) != 0) || (SUB161(auVar16 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar16 >> 0x57,0) & 1) != 0) || (SUB161(auVar16 >> 0x5f,0) & 1) != 0) ||
              (SUB161(auVar16 >> 0x67,0) & 1) != 0) || (SUB161(auVar16 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar16 >> 0x77,0) & 1) != 0) || auVar16[0xf] < '\0') break;
        uVar8 = uVar8 + lVar9 + 0x10;
        lVar9 = lVar9 + 0x10;
      }
    }
LAB_140024366:
    if (((bVar6 == 0) && ((*(ulonglong *)puVar5 & 0x7fffffffffffffff) != 0)) &&
       (cVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar7 == '\0'))
    {
      DAT_140699949 = '\x01';
    }
    cVar7 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar7 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    if (!bVar13) {
      local_78 = (undefined1 *)CONCAT44(uStack_40,uStack_44);
      uStack_70 = CONCAT44(local_38,uStack_3c);
      local_68 = CONCAT44(uStack_30,uStack_34);
      uStack_60 = CONCAT44(local_28,uStack_2c);
      goto LAB_1400243a0;
    }
  }
  local_78 = (undefined1 *)CONCAT62(local_78._2_6_,2);
LAB_1400243a0:
  is_blocked(param_1,&local_78);
  return;
}

