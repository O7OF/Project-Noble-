// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::server_admin::bans::Ban>
// address: 0x1400461e0
// body: available
// range: 0x1400461e0-0x1400462f4 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400461fb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140046219 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004623d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140046255 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004626d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140046285 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::server_admin::bans::Ban>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::server_admin::bans::Ban>
          (longlong param_1)

{
  longlong lVar1;
  ulonglong local_50 [3];
  undefined8 local_38;
  ulonglong local_30;
  undefined8 local_28;
  longlong local_20;
  undefined8 local_18;
  undefined8 local_10;
  
  if (*(longlong *)(param_1 + 0x10) != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(undefined8 *)(param_1 + 0x18),*(longlong *)(param_1 + 0x10),1);
    return;
  }
  lVar1 = *(longlong *)(param_1 + 0x70);
  if ((lVar1 != -1) && (lVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(*(undefined8 *)(param_1 + 0x78),lVar1,1);
    return;
  }
  lVar1 = *(longlong *)(param_1 + 0x88);
  if ((lVar1 != -1) && (lVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(*(undefined8 *)(param_1 + 0x90),lVar1,1);
    return;
  }
  if (*(longlong *)(param_1 + 0x28) != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(undefined8 *)(param_1 + 0x30),*(longlong *)(param_1 + 0x28),1);
    return;
  }
  if (*(longlong *)(param_1 + 0x40) != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(undefined8 *)(param_1 + 0x48),*(longlong *)(param_1 + 0x40),1);
    return;
  }
  if (*(longlong *)(param_1 + 0x58) != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(undefined8 *)(param_1 + 0x60),*(longlong *)(param_1 + 0x58),1);
    return;
  }
  lVar1 = *(longlong *)(param_1 + 0xa8);
  if (lVar1 == 0) {
    local_10 = 0;
  }
  else {
    local_38 = *(undefined8 *)(param_1 + 0xb0);
    local_10 = *(undefined8 *)(param_1 + 0xb8);
    local_50[1] = 0;
    local_28 = 0;
    local_50[2] = lVar1;
    local_20 = lVar1;
    local_18 = local_38;
  }
  local_50[0] = (ulonglong)(lVar1 != 0);
  local_30 = local_50[0];
  <alloc[246c2e7857c81348]::collections::btree::map::IntoIter<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
            (local_50);
  return;
}

