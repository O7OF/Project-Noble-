// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<usize>>::dedup_by::<<alloc[246c2e7857c81348]::vec::Vec<usize>>::dedup::{closure#0}>
// address: 0x140042eb0
// body: available
// range: 0x140042eb0-0x140042f23 inclusive
// range: 0x140042f30-0x140042f51 inclusive
// range: 0x140042f60-0x140042f7b inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<usize>>::dedup_by::<<alloc[246c2e7857c81348]::vec::Vec<usize>>::dedup::{closure#0}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<usize>>::dedup_by::
<<alloc[246c2e7857c81348]::vec::Vec<usize>>::dedup::_closure_0_>(longlong param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  
  uVar1 = *(ulonglong *)(param_1 + 0x10);
  if (1 < uVar1) {
    lVar2 = *(longlong *)(param_1 + 8);
    lVar6 = 0;
    do {
      if (*(longlong *)(lVar2 + 8 + lVar6 * 8) == *(longlong *)(lVar2 + lVar6 * 8)) {
        uVar5 = lVar6 + 2;
        lVar4 = lVar6 + 1;
        if (uVar1 <= uVar5) goto LAB_140042f1e;
        if (((int)uVar1 - (int)lVar6 & 1U) != 0) {
          lVar3 = *(longlong *)(lVar2 + 0x10 + lVar6 * 8);
          if (lVar3 != *(longlong *)(lVar2 + lVar6 * 8)) {
            *(longlong *)(lVar2 + 8 + lVar6 * 8) = lVar3;
            lVar4 = lVar6 + 2;
          }
          uVar5 = lVar6 + 3;
        }
        if (uVar1 - 3 != lVar6) goto LAB_140042f39;
        goto LAB_140042f1e;
      }
      lVar6 = lVar6 + 1;
    } while (uVar1 - 1 != lVar6);
  }
  return;
LAB_140042f39:
  lVar6 = *(longlong *)(lVar2 + uVar5 * 8);
  if (lVar6 == *(longlong *)(lVar2 + -8 + lVar4 * 8)) {
    lVar6 = *(longlong *)(lVar2 + 8 + uVar5 * 8);
    if (lVar6 != *(longlong *)(lVar2 + -8 + lVar4 * 8)) {
LAB_140042f73:
      *(longlong *)(lVar2 + lVar4 * 8) = lVar6;
      lVar4 = lVar4 + 1;
    }
  }
  else {
    *(longlong *)(lVar2 + lVar4 * 8) = lVar6;
    lVar4 = lVar4 + 1;
    lVar6 = *(longlong *)(lVar2 + 8 + uVar5 * 8);
    if (lVar6 != *(longlong *)(lVar2 + -8 + lVar4 * 8)) goto LAB_140042f73;
  }
  uVar5 = uVar5 + 2;
  if (uVar1 == uVar5) {
LAB_140042f1e:
    *(longlong *)(param_1 + 0x10) = lVar4;
    return;
  }
  goto LAB_140042f39;
}

