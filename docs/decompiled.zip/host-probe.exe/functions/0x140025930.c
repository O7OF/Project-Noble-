// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::set_own_leases
// address: 0x140025930
// body: available
// range: 0x140025930-0x1400259af inclusive
// range: 0x1400259b2-0x140025ab6 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400259ab to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400259d3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140025a99 to 0x140610d80 <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::set_own_leases */

void __rustcall host_probe[b94139f9089eb1d8]::net::set_own_leases(undefined4 *param_1)

{
  code *pcVar1;
  undefined *puVar2;
  char cVar3;
  longlong lVar4;
  undefined8 *puVar5;
  bool bVar6;
  undefined1 *local_38;
  byte local_30;
  
  LOCK();
  bVar6 = OWN_LEASES == '\0';
  if (bVar6) {
    OWN_LEASES = '\x01';
  }
  UNLOCK();
  if (!bVar6) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&OWN_LEASES);
  }
  puVar2 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    local_30 = 0;
  }
  else {
    local_30 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_30 = local_30 ^ 1;
  }
  if (DAT_1406995a9 != '\0') {
    local_38 = &OWN_LEASES;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_38,
               &anon_d5c34e88a06ee720b116585eb143da4b_146_llvm_14435704873730135342,
               &anon_d5c34e88a06ee720b116585eb143da4b_409_llvm_14435704873730135342);
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  if (DAT_1406995c0 != 0) {
    puVar5 = (undefined8 *)(CONCAT44(DAT_1406995b8._4_4_,(undefined4)DAT_1406995b8) + 8);
    lVar4 = DAT_1406995c0;
    do {
      if (puVar5[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar5,puVar5[-1],1);
        return;
      }
      puVar5 = puVar5 + 3;
      lVar4 = lVar4 + -1;
    } while (lVar4 != 0);
  }
  if (CONCAT44(DAT_1406995b0._4_4_,(undefined4)DAT_1406995b0) != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (CONCAT44(DAT_1406995b8._4_4_,(undefined4)DAT_1406995b8),
               CONCAT44(DAT_1406995b0._4_4_,(undefined4)DAT_1406995b0) * 0x18,8);
    return;
  }
  DAT_1406995c0 = *(longlong *)(param_1 + 4);
  DAT_1406995b0._0_4_ = *param_1;
  DAT_1406995b0._4_4_ = param_1[1];
  DAT_1406995b8._0_4_ = param_1[2];
  DAT_1406995b8._4_4_ = param_1[3];
  if (((local_30 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
     (cVar3 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar3 == '\0')) {
    DAT_1406995a9 = '\x01';
  }
  cVar3 = OWN_LEASES;
  LOCK();
  OWN_LEASES = 0;
  UNLOCK();
  if (cVar3 != '\x02') {
    return;
  }
  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&OWN_LEASES);
  return;
}

