// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::share_vote
// address: 0x140023750
// body: available
// range: 0x140023750-0x140023847 inclusive
// range: 0x140023850-0x14002386f inclusive
// range: 0x140023872-0x1400238c6 inclusive
// range: 0x1400238c9-0x1400239ad inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14002386b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400238c2 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::share_vote */

void __rustcall host_probe[b94139f9089eb1d8]::net::share_vote(undefined8 param_1,int param_2)

{
  code *pcVar1;
  undefined *puVar2;
  byte bVar3;
  char cVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  bool bVar8;
  undefined1 *local_50;
  byte local_48;
  undefined7 uStack_47;
  longlong local_40;
  undefined8 local_38;
  int local_30;
  
  LOCK();
  bVar8 = LAST_VOTE == '\0';
  if (bVar8) {
    LAST_VOTE = '\x01';
  }
  UNLOCK();
  local_38 = param_1;
  local_30 = param_2;
  if (!bVar8) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LAST_VOTE);
  }
  puVar2 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar3 = 0;
  }
  else {
    bVar3 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar3 = bVar3 ^ 1;
  }
  if (DAT_1406997c9 != '\0') {
    local_50 = &LAST_VOTE;
    local_48 = bVar3;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_50,
               &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1e90);
                    /* WARNING: Does not return */
    pcVar1 = (code *)invalidInstructionException();
    (*pcVar1)();
  }
  if ((DAT_1406997d8 == -1) ||
     (lVar5 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&local_38,DAT_1406997d0),
     lVar5 != 0)) {
    DAT_1406997d0 = param_1;
    DAT_1406997d8 = param_2;
    if ((bVar3 == 0) &&
       (((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0 &&
        (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar4 == '\0'))
       )) {
      DAT_1406997c9 = '\x01';
    }
    cVar4 = LAST_VOTE;
    LOCK();
    LAST_VOTE = 0;
    UNLOCK();
    if (cVar4 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_VOTE);
    }
    if (IS_HOST_0_llvm_14435704873730135342 == '\0') {
      vote::guest_repeat(&local_50,param_1,param_2);
      if (local_50 != (undefined1 *)0xffffffffffffffff) {
        lVar5 = CONCAT71(uStack_47,local_48);
        vote_to_host(lVar5,local_40);
        if (local_50 != (undefined1 *)0x0) {
          uVar7 = 1;
          goto LAB_1400238c2;
        }
      }
    }
    else {
      vote::host_repeats();
      lVar5 = CONCAT71(uStack_47,local_48);
      if (local_40 != 0) {
        send_vote(&TRANSPORT,lVar5,local_40,1);
        puVar6 = (undefined8 *)(lVar5 + 8);
        do {
          if (puVar6[-1] != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar6,puVar6[-1],1);
            return;
          }
          puVar6 = puVar6 + 3;
          local_40 = local_40 + -1;
        } while (local_40 != 0);
      }
      if (local_50 != (undefined1 *)0x0) {
        local_50 = (undefined1 *)((longlong)local_50 * 0x18);
        uVar7 = 8;
LAB_1400238c2:
        __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar5,local_50,uVar7);
        return;
      }
    }
  }
  else {
    if (((bVar3 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
       (cVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar4 == '\0'))
    {
      DAT_1406997c9 = '\x01';
    }
    cVar4 = LAST_VOTE;
    LOCK();
    LAST_VOTE = 0;
    UNLOCK();
    if (cVar4 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_VOTE);
    }
  }
  return;
}

