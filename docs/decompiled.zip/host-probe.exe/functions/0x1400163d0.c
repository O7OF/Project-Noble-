// rea decompile_all
// name: reach_directory[4b72b9694f6c3c08]::lan::is_local
// address: 0x1400163d0
// body: available
// range: 0x1400163d0-0x140016436 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* reach_directory[4b72b9694f6c3c08]::lan::is_local */

bool __rustcall reach_directory[4b72b9694f6c3c08]::lan::is_local(char *param_1)

{
  char cVar1;
  byte bVar2;
  bool bVar3;
  undefined1 auVar4 [16];
  
  if (*param_1 == '\x01') {
    auVar4[0] = -(param_1[1] == '\0');
    auVar4[1] = -(param_1[2] == '\0');
    auVar4[2] = -(param_1[3] == '\0');
    auVar4[3] = -(param_1[4] == '\0');
    auVar4[4] = -(param_1[5] == '\0');
    auVar4[5] = -(param_1[6] == '\0');
    auVar4[6] = -(param_1[7] == '\0');
    auVar4[7] = -(param_1[8] == '\0');
    auVar4[8] = -(param_1[9] == '\0');
    auVar4[9] = -(param_1[10] == '\0');
    auVar4[10] = -(param_1[0xb] == '\0');
    auVar4[0xb] = -(param_1[0xc] == '\0');
    auVar4[0xc] = -(param_1[0xd] == '\0');
    auVar4[0xd] = -(param_1[0xe] == '\0');
    auVar4[0xe] = -(param_1[0xf] == '\0');
    auVar4[0xf] = -(param_1[0x10] == '\x01');
    return (ushort)((ushort)(SUB161(auVar4 >> 7,0) & 1) | (ushort)(SUB161(auVar4 >> 0xf,0) & 1) << 1
                    | (ushort)(SUB161(auVar4 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar4 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar4 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar4 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar4 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar4 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar4 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar4 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar4 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar4 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar4 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar4 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar4 >> 0x77,0) & 1) << 0xe |
                   (ushort)(auVar4[0xf] >> 7) << 0xf) == 0xffff;
  }
  cVar1 = param_1[1];
  bVar3 = true;
  if (cVar1 != '\n') {
    bVar2 = param_1[2];
    if (cVar1 == -0x40) {
      if (bVar2 == 0xa8) {
        return true;
      }
    }
    else if ((cVar1 == -0x54) && ((bVar2 & 0xf0) == 0x10)) {
      return true;
    }
    bVar3 = cVar1 == '\x7f' || bVar2 == 0xfe && cVar1 == -0x57;
  }
  return bVar3;
}

