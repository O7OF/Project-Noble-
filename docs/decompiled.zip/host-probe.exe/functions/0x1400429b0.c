// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u32,u32,i32)>>::retain::<<host_probe[b94139f9089eb1d8]::trades::Tracker>::expire::{closure#1}>
// address: 0x1400429b0
// body: available
// range: 0x1400429b0-0x1400429f8 inclusive
// range: 0x140042a00-0x140042a40 inclusive
// range: 0x140042a50-0x140042a79 inclusive
// range: 0x140042a80-0x140042abe inclusive
// range: 0x140042ac0-0x140042add inclusive
// range: 0x140042ae0-0x140042b12 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u32, u32,
   i32)>>::retain::<<host_probe[b94139f9089eb1d8]::trades::Tracker>::expire::{closure#1}> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u32,u32,i32)>>::retain::
<<host_probe[b94139f9089eb1d8]::trades::Tracker>::expire::_closure_1_>
          (longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  
  uVar2 = *(ulonglong *)(param_1 + 0x10);
  if (uVar2 != 0) {
    if (*(longlong *)(param_2 + 0x10) == 0) {
      uVar7 = 0;
    }
    else {
      lVar3 = *(longlong *)(param_1 + 8);
      lVar4 = *(longlong *)(param_2 + 8);
      lVar5 = *(longlong *)(param_2 + 0x10) * 0x14;
      if (uVar2 == 1) {
        uVar8 = 0;
      }
      else {
        uVar8 = 0;
        do {
          lVar6 = 0;
          while ((*(int *)(lVar4 + lVar6) != *(int *)(lVar3 + uVar8 * 0xc) ||
                 (*(int *)(lVar4 + 4 + lVar6) != *(int *)(lVar3 + 4 + uVar8 * 0xc)))) {
            lVar6 = lVar6 + 0x14;
            uVar7 = uVar8;
            if (lVar5 == lVar6) goto LAB_140042aac;
          }
          uVar7 = uVar8 + 1;
          lVar6 = 0;
          while ((*(int *)(lVar4 + lVar6) != *(int *)(lVar3 + uVar7 * 0xc) ||
                 (*(int *)(lVar4 + 4 + lVar6) != *(int *)(lVar3 + 4 + uVar7 * 0xc)))) {
            lVar6 = lVar6 + 0x14;
            if (lVar5 == lVar6) goto LAB_140042aac;
          }
          uVar8 = uVar8 + 2;
        } while (uVar8 != (uVar2 & 0xffffffffffffffe));
        if ((uVar2 & 1) == 0) {
          return;
        }
      }
      lVar6 = 0;
      do {
        if ((*(int *)(lVar4 + lVar6) == *(int *)(lVar3 + uVar8 * 0xc)) &&
           (*(int *)(lVar4 + 4 + lVar6) == *(int *)(lVar3 + 4 + uVar8 * 0xc))) {
          return;
        }
        lVar6 = lVar6 + 0x14;
        uVar7 = uVar8;
      } while (lVar5 != lVar6);
LAB_140042aac:
      uVar8 = uVar7 + 1;
      if (uVar8 < uVar2) {
        do {
          puVar1 = (undefined8 *)(lVar3 + uVar8 * 0xc);
          lVar6 = 0;
          do {
            if ((*(int *)(lVar4 + lVar6) == *(int *)(lVar3 + uVar8 * 0xc)) &&
               (*(int *)(lVar4 + 4 + lVar6) == *(int *)(lVar3 + 4 + uVar8 * 0xc))) {
              *(undefined4 *)(lVar3 + 8 + uVar7 * 0xc) = *(undefined4 *)(puVar1 + 1);
              *(undefined8 *)(lVar3 + uVar7 * 0xc) = *puVar1;
              uVar7 = uVar7 + 1;
              break;
            }
            lVar6 = lVar6 + 0x14;
          } while (lVar5 != lVar6);
          uVar8 = uVar8 + 1;
        } while (uVar8 != uVar2);
      }
    }
    *(ulonglong *)(param_1 + 0x10) = uVar7;
  }
  return;
}

