// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(i32,u32)>>::resize
// address: 0x140046ef0
// body: available
// range: 0x140046ef0-0x14004702f inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(i32, u32)>>::resize */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(i32,u32)>>::resize
          (longlong *param_1,ulonglong param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined4 *puVar6;
  longlong lVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  
  uVar2 = param_1[2];
  uVar5 = param_2 - uVar2;
  if (param_2 < uVar2 || uVar5 == 0) goto LAB_140046fd3;
  if (*param_1 - uVar2 < uVar5) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,uVar2,uVar5,4,8);
    lVar8 = param_1[1];
    puVar6 = (undefined4 *)(lVar8 + param_1[2] * 8);
    uVar3 = param_1[2];
  }
  else {
    lVar8 = param_1[1];
    puVar6 = (undefined4 *)(lVar8 + uVar2 * 8);
    uVar3 = uVar2;
  }
  if (1 < uVar5) {
    uVar4 = ~uVar2 + param_2;
    lVar7 = 1;
    if (uVar4 < 4) {
LAB_140046f9b:
      lVar8 = (lVar7 + uVar2) - param_2;
      do {
        *puVar6 = param_3;
        puVar6[1] = param_4;
        puVar6 = puVar6 + 2;
        lVar8 = lVar8 + 1;
      } while (lVar8 != 0);
    }
    else {
      uVar10 = uVar4 & 0xfffffffffffffffc;
      puVar6 = puVar6 + uVar10 * 2;
      lVar7 = uVar10 + 1;
      lVar8 = lVar8 + uVar3 * 8;
      uVar9 = 0;
      do {
        puVar1 = (undefined4 *)(lVar8 + uVar9 * 8);
        *puVar1 = param_3;
        puVar1[1] = param_4;
        puVar1[2] = param_3;
        puVar1[3] = param_4;
        puVar1 = (undefined4 *)(lVar8 + 0x10 + uVar9 * 8);
        *puVar1 = param_3;
        puVar1[1] = param_4;
        puVar1[2] = param_3;
        puVar1[3] = param_4;
        uVar9 = uVar9 + 4;
      } while (uVar10 != uVar9);
      if (uVar4 != uVar10) goto LAB_140046f9b;
    }
    uVar3 = (uVar3 + uVar5) - 1;
  }
  *puVar6 = param_3;
  puVar6[1] = param_4;
  param_2 = uVar3 + 1;
LAB_140046fd3:
  param_1[2] = param_2;
  return;
}

