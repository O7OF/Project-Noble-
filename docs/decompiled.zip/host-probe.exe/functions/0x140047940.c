// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<*mut_core[505b25137b8ba7f]::ffi::c_void>>::extend_with
// address: 0x140047940
// body: available
// range: 0x140047940-0x140047a23 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<*mut core[505b25137b8ba7f]::ffi::c_void>>::extend_with */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<*mut_core[505b25137b8ba7f]::ffi::c_void>>::extend_with
          (longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  ulonglong uVar9;
  
  uVar7 = (undefined4)((ulonglong)param_3 >> 0x20);
  uVar6 = (undefined4)param_3;
  lVar3 = param_1[2];
  if ((ulonglong)(*param_1 - lVar3) < param_2) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar3,param_2,8,8);
    lVar3 = param_1[2];
    lVar5 = param_1[1];
    puVar2 = (undefined4 *)(lVar5 + lVar3 * 8);
    if (param_2 < 2) goto LAB_140047a0d;
LAB_14004796b:
    lVar8 = 1;
    if (param_2 < 5) {
LAB_1400479b9:
      lVar8 = param_2 - lVar8;
      do {
        *puVar2 = uVar6;
        puVar2[1] = uVar7;
        puVar2 = puVar2 + 2;
        lVar8 = lVar8 + -1;
      } while (lVar8 != 0);
    }
    else {
      uVar9 = param_2 - 1 & 0xfffffffffffffffc;
      puVar2 = puVar2 + uVar9 * 2;
      lVar8 = uVar9 + 1;
      lVar5 = lVar5 + lVar3 * 8;
      uVar4 = 0;
      do {
        puVar1 = (undefined4 *)(lVar5 + uVar4 * 8);
        *puVar1 = uVar6;
        puVar1[1] = uVar7;
        puVar1[2] = uVar6;
        puVar1[3] = uVar7;
        puVar1 = (undefined4 *)(lVar5 + 0x10 + uVar4 * 8);
        *puVar1 = uVar6;
        puVar1[1] = uVar7;
        puVar1[2] = uVar6;
        puVar1[3] = uVar7;
        uVar4 = uVar4 + 4;
      } while (uVar9 != uVar4);
      if (param_2 - 1 != uVar9) goto LAB_1400479b9;
    }
    lVar3 = lVar3 + param_2 + -1;
  }
  else {
    lVar5 = param_1[1];
    puVar2 = (undefined4 *)(lVar5 + lVar3 * 8);
    if (1 < param_2) goto LAB_14004796b;
LAB_140047a0d:
    if (param_2 == 0) goto LAB_140047a18;
  }
  *puVar2 = uVar6;
  puVar2[1] = uVar7;
  lVar3 = lVar3 + 1;
LAB_140047a18:
  param_1[2] = lVar3;
  return;
}

