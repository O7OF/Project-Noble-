// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::hudx::install
// address: 0x14003c5f0
// body: available
// range: 0x14003c5f0-0x14003cce5 inclusive
// range: 0x14003ccf0-0x14003cd0f inclusive
// range: 0x14003cd12-0x14003d2f1 inclusive
// range: 0x14003d2f7-0x14003d49e inclusive
// range: 0x14003d4a1-0x14003d736 inclusive
// range: 0x14003d73c-0x14003d845 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003cd0b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003cd30 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d2ed to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d396 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d3ac to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d49a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d4ce to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d570 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d732 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d752 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003d813 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authentic
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::hudx::install */

undefined8 * __rustcall
host_probe[b94139f9089eb1d8]::hudx::install(undefined8 *param_1,longlong param_2)

{
  longlong *plVar1;
  longlong ****pppplVar2;
  code *pcVar3;
  longlong lVar4;
  int iVar5;
  code *pcVar6;
  undefined4 uVar7;
  longlong *****ppppplVar8;
  longlong *******ppppppplVar9;
  longlong ******pppppplVar10;
  int iVar11;
  int iVar12;
  uint uVar13;
  undefined8 *puVar14;
  longlong lVar15;
  undefined1 *puVar16;
  undefined4 *puVar17;
  undefined8 uVar18;
  longlong ******pppppplVar19;
  longlong *plVar20;
  code cVar21;
  ulonglong uVar22;
  int iVar23;
  uint uVar24;
  longlong *******ppppppplVar25;
  code *pcVar26;
  undefined8 local_258;
  undefined8 uStack_250;
  longlong local_248;
  undefined8 local_240;
  undefined8 uStack_238;
  undefined8 uStack_230;
  longlong ******local_228;
  longlong *****local_220;
  code *apcStack_218 [4];
  undefined8 local_1f8;
  undefined8 local_1f0;
  undefined8 *puStack_1e8;
  undefined8 local_1e0;
  undefined8 local_1d8;
  undefined8 uStack_1d0;
  undefined8 local_1c8;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined2 uStack_1b8;
  undefined2 uStack_1b6;
  undefined4 uStack_1b4;
  undefined8 uStack_1b0;
  undefined8 *puStack_1a8;
  undefined8 local_1a0;
  undefined8 local_198;
  undefined8 *puStack_190;
  undefined8 local_188;
  longlong *******local_180;
  longlong *local_178;
  longlong *******local_170;
  int local_164;
  longlong ******local_160;
  longlong *****local_158;
  longlong ******local_150;
  undefined4 local_148;
  undefined2 local_144;
  undefined1 local_142;
  longlong ******local_140;
  undefined4 local_138;
  undefined2 local_134;
  undefined1 local_132;
  int local_130;
  int local_12c;
  int local_128;
  int local_124;
  undefined8 local_120;
  undefined8 *puStack_118;
  undefined8 local_110;
  longlong ****local_108;
  undefined8 local_100;
  undefined4 local_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  longlong ******local_e8;
  code *local_d8;
  longlong *****local_d0;
  code *pcStack_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  undefined8 *puStack_b0;
  undefined8 local_a8;
  longlong *****local_a0;
  longlong *****local_98;
  undefined8 local_90;
  undefined8 local_88;
  undefined8 local_80;
  undefined8 local_78;
  undefined4 local_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  if (pools::ENABLED_0_llvm_9926003741679196139 != '\0') {
    local_180 = (longlong *******)0x46ab53;
    local_160 = (longlong ******)(param_2 + 0x46ab53);
    local_158 = (longlong *****)0x5;
    if (*(char *)(param_2 + 0x46ab57) == '\0' && *(int *)(param_2 + 0x46ab53) == 0x226000ba) {
      local_180 = (longlong *******)0x15feb2;
      local_160 = (longlong ******)(param_2 + 0x15feb2);
      local_158 = (longlong *****)0x4;
      if (*(int *)(param_2 + 0x15feb2) == 0x40518d41) goto LAB_14003c73a;
      local_258 = (longlong ******)
                  &anon_78f5a4a341bdef2ce7ac238d2c24ea85_1313_llvm_9926003741679196139;
      uStack_250 = &DAT_00000004;
    }
    else {
      local_258 = (longlong ******)
                  &anon_78f5a4a341bdef2ce7ac238d2c24ea85_1311_llvm_9926003741679196139;
      uStack_250 = &DAT_00000005;
    }
    local_240 = (longlong *******)&local_180;
    uStack_238 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    uStack_230 = (longlong ******)&local_160;
    local_228 = (longlong ******)<&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
    local_220 = (longlong *****)&local_258;
    apcStack_218[0] = <&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner
              (&local_1c8,&anon_78f5a4a341bdef2ce7ac238d2c24ea85_1315_llvm_9926003741679196139,
               &local_240);
    if (local_1c8 != (longlong *****)0xffffffffffffffff) {
      param_1[2] = CONCAT44(uStack_1b4,CONCAT22(uStack_1b6,uStack_1b8));
      goto LAB_14003c891;
    }
  }
LAB_14003c73a:
  iVar11 = coopx::objects_pool_growth();
  iVar5 = iVar11 + 0x240000;
  if (pools::ENABLED_0_llvm_9926003741679196139 == '\0') {
    iVar5 = iVar11;
  }
  if ((aix::ACTORS_0_llvm_4618389659541386029 == 0) &&
     (aix::AI_PLAYERS_0_llvm_4618389659541386029 == '\0')) {
    iVar11 = 0;
  }
  else {
    iVar11 = 0x10000;
  }
  iVar23 = 0x50000;
  if (aix::ACTORS_0_llvm_4618389659541386029 != 0xc0) {
    iVar23 = 0;
  }
  iVar12 = 0x20000;
  if (aix::ACTORS_0_llvm_4618389659541386029 != 0x80) {
    iVar12 = iVar23;
  }
  local_128 = (uint)(0x20 < capacity::PLAYERS_0_llvm_16945119018599968161) * 0x10000 + iVar12 +
              0x10000;
  local_12c = (uint)(0x20 < capacity::PLAYERS_0_llvm_16945119018599968161) * 0x40000 +
              iVar5 + iVar11 + 0x20000;
  uVar13 = (uint)capacity::PLAYERS_0_llvm_16945119018599968161;
  local_164 = uVar13 << 3;
  cVar21 = (code)0x5;
  do {
    cVar21 = (code)((char)cVar21 + 1);
  } while ((ulonglong)(1L << ((byte)cVar21 & 0x3f)) < (ulonglong)(uVar13 & 0x1fffffff));
  if ((0x80 < (uVar13 & 0x1fffffff)) || (0x1000 < (ulonglong)(4L << ((byte)cVar21 & 0x3f)))) {
    local_240 = (longlong *******)&local_164;
    uStack_238 = <u32_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(param_1,&DAT_1406a375d,&local_240);
    return param_1;
  }
  grow_game_state(&local_240,param_2);
  uStack_1c0 = SUB84(uStack_230,0);
  uStack_1bc = (undefined4)((ulonglong)uStack_230 >> 0x20);
  uStack_1b8 = SUB82(local_228,0);
  uStack_1b6 = (undefined2)((ulonglong)local_228 >> 0x10);
  uStack_1b4 = (undefined4)((ulonglong)local_228 >> 0x20);
  local_1c8._0_4_ = SUB84(uStack_238,0);
  local_1c8._4_4_ = (undefined4)((ulonglong)uStack_238 >> 0x20);
  if ((int)local_240 == 1) {
    param_1[2] = local_228;
LAB_14003c891:
    *(undefined4 *)param_1 = (undefined4)local_1c8;
    *(undefined4 *)((longlong)param_1 + 4) = local_1c8._4_4_;
    *(undefined4 *)(param_1 + 1) = uStack_1c0;
    *(undefined4 *)((longlong)param_1 + 0xc) = uStack_1bc;
    return param_1;
  }
  local_e8 = local_228;
  local_f8 = (undefined4)local_1c8;
  uStack_f4 = local_1c8._4_4_;
  uStack_f0 = uStack_1c0;
  uStack_ec = uStack_1bc;
  local_160 = (longlong ******)0x2be898;
  local_258 = &local_158;
  local_158 = (longlong *****)CONCAT17(local_158._7_1_,0x3750978409);
  local_150 = (longlong ******)0x2beba2;
  local_148 = 0x5083848b;
  local_144 = 0x37;
  local_142 = 0;
  local_140 = (longlong ******)0x2beee5;
  local_138 = 0x50838d48;
  local_134 = 0x37;
  local_132 = 0;
  local_1c8 = (longlong *****)(param_2 + 0x2be898);
  local_180 = &local_160;
  if (*(int7 *)(param_2 + 0x2be898) == 0x3750978409) {
    local_180 = &local_150;
    local_258 = (longlong ******)&local_148;
    local_1c8 = (longlong *****)(param_2 + 0x2beba2);
    if (*(int7 *)(param_2 + 0x2beba2) != 0x375083848b) goto LAB_14003cc53;
    local_180 = &local_140;
    local_258 = (longlong ******)&local_138;
    local_1c8 = (longlong *****)(param_2 + 0x2beee5);
    if (*(int7 *)(param_2 + 0x2beee5) != 0x3750838d48) goto LAB_14003cc53;
    local_258 = (longlong ******)0x12fcc;
    local_108 = (longlong ****)&DAT_1406a3683;
    local_100 = 5;
    uStack_1c0 = 5;
    local_1c8 = (longlong *****)(param_2 + 0x12fcc);
    if (*(char *)(param_2 + 0x12fd0) == '\b' && *(int *)(param_2 + 0x12fcc) == 0x245c8948) {
      local_258 = (longlong ******)0x2c063f;
      local_108 = (longlong ****)&DAT_1406a3688;
      local_100 = 6;
      uStack_1c0 = 6;
      local_1c8 = (longlong *****)(param_2 + 0x2c063f);
      if (*(short *)(param_2 + 0x2c0643) == 0 && *(int *)(param_2 + 0x2c063f) == -0x37af46bf) {
        local_258 = (longlong ******)0x2be38a;
        local_108 = (longlong ****)&DAT_1406a368e;
        local_100 = 6;
        local_1c8 = (longlong *****)(param_2 + 0x2be38a);
        uStack_1c0 = 6;
        uStack_1bc = 0;
        if (*(short *)(param_2 + 0x2be38e) == 0 && *(int *)(param_2 + 0x2be38a) == 0x11be41) {
          uVar18 = 0x1000;
          local_a0 = local_1c8;
          local_98 = (longlong *****)(param_2 + 0x2c063f);
          lVar15 = hook::alloc_after_image(param_2,0x1000,4);
          if (lVar15 == 1) {
            local_90 = uVar18;
            pcStack_c8 = (code *)alloc[246c2e7857c81348]::boxed::box_new_uninit(1,0x13);
            *(undefined8 *)pcStack_c8 = 0x4800001ea48f8b51;
            *(undefined2 *)(pcStack_c8 + 8) = 0xe1c1;
            pcStack_c8[10] = cVar21;
            *(undefined8 *)(pcStack_c8 + 0xb) = 0xbb495341910c8d48;
            local_d0 = (longlong *****)&DAT_00000013;
            local_c0 = 0x13;
            local_88 = 0;
            local_80 = 8;
            local_78 = uVar18;
            <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
            <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_d0,&local_88);
            local_240 = (longlong *******)0x0;
            uStack_238 = (code *)0x8;
            uStack_230 = (longlong ******)0xc3595b410b040941;
            <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
            <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_d0,&local_240);
            puStack_b0 = (undefined8 *)alloc[246c2e7857c81348]::boxed::box_new_uninit(1,0x13);
            *puStack_b0 = 0x4800001ea48b8b51;
            *(undefined2 *)(puStack_b0 + 1) = 0xe1c1;
            *(code *)((longlong)puStack_b0 + 10) = cVar21;
            *(undefined8 *)((longlong)puStack_b0 + 0xb) = 0xbb495341810c8d48;
            local_b8 = 0x13;
            local_a8 = 0x13;
            <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
            <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_b8,&local_88);
            local_240 = (longlong *******)0x0;
            uStack_238 = (code *)0x8;
            uStack_230 = (longlong ******)0xc3595b410b048b41;
            <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
            <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_b8,&local_240);
            puStack_118 = (undefined8 *)alloc[246c2e7857c81348]::boxed::box_new_uninit(1,0xd);
            *puStack_118 = 0x4800001ea48b8b51;
            *(undefined2 *)(puStack_118 + 1) = 0xe1c1;
            *(code *)((longlong)puStack_118 + 10) = cVar21;
            *(undefined2 *)((longlong)puStack_118 + 0xb) = 0xb848;
            local_120 = 0xd;
            local_110 = 0xd;
            <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
            <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_120,&local_88);
            local_240 = (longlong *******)0x0;
            uStack_238 = (code *)0x5;
            uStack_230 = (longlong ******)CONCAT35(uStack_230._5_3_,0xc931c80148);
            <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
            <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_120,&local_240);
            uVar24 = (uVar13 & 0x1fffffff) >> 3;
            if (uVar24 != 0) {
              uVar22 = 0;
              do {
                local_240 = (longlong *******)0x0;
                uStack_238 = (code *)0x4;
                uStack_230._0_4_ = CONCAT13((char)uVar22,0x488948);
                <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
                <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_120,&local_240);
                uVar22 = uVar22 + 8;
              } while (uVar24 << 3 != uVar22);
            }
            local_240 = (longlong *******)0x0;
            uStack_238 = (code *)0x2;
            uStack_230 = (longlong ******)CONCAT62(uStack_230._2_6_,0xc359);
            <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
            <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_120,&local_240);
            local_130 = uVar13 * 0xc60 + 0x250;
            uStack_238 = (code *)&local_130;
            local_180 = (longlong *******)0x0;
            local_178 = (longlong *)&DAT_00000008;
            local_170 = (longlong *******)0x0;
            uStack_1b8 = (undefined2)local_c0;
            uStack_1b6 = (undefined2)((ulonglong)local_c0 >> 0x10);
            uStack_1b4 = (undefined4)((ulonglong)local_c0 >> 0x20);
            local_1c8 = local_d0;
            uStack_1c0 = SUB84(pcStack_c8,0);
            uStack_1bc = (undefined4)((ulonglong)pcStack_c8 >> 0x20);
            uStack_1b0 = local_b8;
            puStack_1a8 = puStack_b0;
            local_1a0 = local_a8;
            local_198 = local_120;
            puStack_190 = puStack_118;
            local_188 = local_110;
            local_1e0 = local_110;
            local_1f0 = local_120;
            puStack_1e8 = puStack_118;
            apcStack_218[3] = (code *)puStack_b0;
            local_1f8 = local_a8;
            apcStack_218[1] = (code *)local_c0;
            apcStack_218[2] = (code *)local_b8;
            local_220 = local_d0;
            apcStack_218[0] = pcStack_c8;
            local_1d8 = 0;
            uStack_1d0 = 0;
            uStack_230 = (longlong ******)0x0;
            local_228 = (longlong ******)0x3;
            ppppppplVar25 = &local_160;
            do {
              local_240 = ppppppplVar25 + 2;
              pppppplVar19 = local_228;
              pppppplVar10 = uStack_230;
              if (local_228 == uStack_230) break;
              pppppplVar19 = (longlong ******)((longlong)uStack_230 + 1);
              pppplVar2 = (longlong ****)(&local_220)[(longlong)uStack_230 * 3];
              pppppplVar10 = pppppplVar19;
              if (pppplVar2 == (longlong ****)0xffffffffffffffff) break;
              pcVar3 = apcStack_218[(longlong)uStack_230 * 3];
              lVar15 = (longlong)uStack_230 * 3;
              uStack_230 = pppppplVar19;
              local_d8 = pcVar3;
              hook::place_code(&local_1c8,param_2,pcVar3,apcStack_218[lVar15 + 1]);
              uVar18 = CONCAT44(uStack_1bc,uStack_1c0);
              if (local_1c8 != (longlong *****)0xffffffffffffffff) {
                *param_1 = local_1c8;
                param_1[1] = uVar18;
                param_1[2] = CONCAT44(uStack_1b4,CONCAT22(uStack_1b6,uStack_1b8));
LAB_14003d39b:
                if (pppplVar2 != (longlong ****)0x0) {
                  puVar14 = (undefined8 *)
                            __rustc[9d087a5ab36ea756]::__rust_dealloc(pcVar3,pppplVar2,1);
                  return puVar14;
                }
                <[core[505b25137b8ba7f]::mem::maybe_uninit::MaybeUninit<alloc[246c2e7857c81348]::vec::Vec<u8>>;3usize]as_core[505b25137b8ba7f]::array::iter::iter_inner::PartialDrop>
                ::partial_drop(&local_220,uStack_230,local_228);
                core[505b25137b8ba7f]::ptr::drop_glue::
                <alloc[246c2e7857c81348]::vec::Vec<(usize,[u8_7usize],alloc[246c2e7857c81348]::vec::Vec<u8>)>>
                          (&local_180);
                goto LAB_14003cccb;
              }
              __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
              puVar16 = (undefined1 *)__rustc[9d087a5ab36ea756]::__rust_alloc(1,1);
              if (puVar16 == (undefined1 *)0x0) {
                alloc[246c2e7857c81348]::alloc::handle_alloc_error(1,1);
                goto LAB_14003d844;
              }
              *puVar16 = 0xe8;
              local_258 = (longlong ******)0x1;
              local_248 = 1;
              pppppplVar19 = *ppppppplVar25;
              uStack_250 = puVar16;
              hook::rel32(&local_1c8,param_2 + 5 + (longlong)pppppplVar19,uVar18);
              uVar7 = uStack_1c0;
              if (local_1c8 != (longlong *****)0xffffffffffffffff) {
                *(undefined4 *)((longlong)param_1 + 0x14) = uStack_1b4;
                *(ulonglong *)((longlong)param_1 + 0xc) =
                     CONCAT26(uStack_1b6,CONCAT24(uStack_1b8,uStack_1bc));
                *param_1 = local_1c8;
                *(undefined4 *)(param_1 + 1) = uStack_1c0;
                if (local_258 != (longlong ******)0x0) {
                  puVar14 = (undefined8 *)
                            __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_250,local_258,1);
                  return puVar14;
                }
                goto LAB_14003d39b;
              }
              local_1c8 = (longlong *****)0x0;
              uStack_1c0 = 4;
              uStack_1bc = 0;
              uStack_1b8 = (undefined2)uVar7;
              uStack_1b6 = (undefined2)((uint)uVar7 >> 0x10);
              <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
              <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_258,&local_1c8);
              local_1c8 = (longlong *****)0x0;
              uStack_1c0 = 2;
              uStack_1bc = 0;
              uStack_1b8 = 0x9090;
              <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
              <core[505b25137b8ba7f]::array::iter::IntoIter<u8,2usize>>(&local_258,&local_1c8);
              ppppppplVar9 = local_170;
              lVar15 = local_248;
              puVar16 = uStack_250;
              pppppplVar10 = local_258;
              local_1c8._4_4_ =
                   (undefined4)
                   (CONCAT14(local_1c8._7_1_,*(undefined4 *)((longlong)ppppppplVar25 + 0xb)) >> 8);
              local_1c8 = (longlong *****)
                          CONCAT44(local_1c8._4_4_,*(undefined4 *)(ppppppplVar25 + 1));
              if (local_170 == local_180) {
                <alloc[246c2e7857c81348]::raw_vec::RawVec<reach_directory[4b72b9694f6c3c08]::chat::Player>>
                ::grow_one(&local_180);
              }
              local_178[(longlong)ppppppplVar9 * 5] = (longlong)pppppplVar19;
              uVar7 = (undefined4)local_1c8;
              *(undefined4 *)(local_178 + (longlong)ppppppplVar9 * 5 + 1) = uVar7;
              *(undefined4 *)((longlong)local_178 + (longlong)ppppppplVar9 * 0x28 + 0xb) =
                   local_1c8._3_4_;
              local_178[(longlong)ppppppplVar9 * 5 + 2] = (longlong)pppppplVar10;
              local_178[(longlong)ppppppplVar9 * 5 + 3] = (longlong)puVar16;
              local_178[(longlong)ppppppplVar9 * 5 + 4] = lVar15;
              local_170 = (longlong *******)((longlong)ppppppplVar9 + 1);
              if (pppplVar2 != (longlong ****)0x0) {
                puVar14 = (undefined8 *)
                          __rustc[9d087a5ab36ea756]::__rust_dealloc(local_d8,pppplVar2,1);
                return puVar14;
              }
              pppppplVar19 = uStack_230;
              ppppppplVar25 = local_240;
              pppppplVar10 = uStack_230;
            } while (local_240 != (longlong *******)uStack_238);
            uStack_230 = pppppplVar10;
            <[core[505b25137b8ba7f]::mem::maybe_uninit::MaybeUninit<alloc[246c2e7857c81348]::vec::Vec<u8>>;3usize]as_core[505b25137b8ba7f]::array::iter::iter_inner::PartialDrop>
            ::partial_drop(&local_220,pppppplVar19,local_228);
            uStack_230 = (longlong ******)CONCAT44(uStack_f4,local_f8);
            local_240 = (longlong *******)CONCAT44(uStack_ec,uStack_f0);
            lVar15 = (longlong)local_e8 * 0x30;
            pcVar3 = (code *)((longlong)local_240 + (longlong)local_e8 * 0x30);
            pcVar26 = (code *)local_240;
            local_228 = (longlong ******)pcVar3;
            if (local_e8 != (longlong ******)0x0) {
              pcVar6 = (code *)local_240;
              uStack_238 = (code *)local_240;
              do {
                pcVar26 = pcVar6 + 0x30;
                lVar4 = *(longlong *)(pcVar6 + 0x18);
                if (lVar4 == -1) break;
                uVar18 = *(undefined8 *)(pcVar6 + 0x20);
                win::patch_code(&local_1c8,*(longlong *)(pcVar6 + 0x10) + param_2,
                                *(undefined8 *)pcVar6,*(undefined8 *)(pcVar6 + 8),uVar18,
                                *(undefined8 *)(pcVar6 + 0x28));
                if (local_1c8 != (longlong *****)0xffffffffffffffff) {
                  param_1[2] = CONCAT44(uStack_1b4,CONCAT22(uStack_1b6,uStack_1b8));
                  *(undefined4 *)param_1 = (undefined4)local_1c8;
                  *(undefined4 *)((longlong)param_1 + 4) = local_1c8._4_4_;
                  *(undefined4 *)(param_1 + 1) = uStack_1c0;
                  *(undefined4 *)((longlong)param_1 + 0xc) = uStack_1bc;
                  uStack_238 = pcVar26;
                  if (lVar4 != 0) {
                    puVar14 = (undefined8 *)
                              __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar18,lVar4,1);
                    return puVar14;
                  }
                  <alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(usize,&[u8],alloc[246c2e7857c81348]::vec::Vec<u8>)>as_core[505b25137b8ba7f]::ops::drop::Drop>
                  ::drop(&local_240);
                  goto LAB_14003d5b0;
                }
                if (lVar4 != 0) {
                  puVar14 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar18,lVar4,1);
                  return puVar14;
                }
                lVar15 = lVar15 + -0x30;
                pcVar6 = pcVar26;
                pcVar26 = pcVar3;
              } while (lVar15 != 0);
            }
            uStack_238 = pcVar26;
            <alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(usize,&[u8],alloc[246c2e7857c81348]::vec::Vec<u8>)>as_core[505b25137b8ba7f]::ops::drop::Drop>
            ::drop(&local_240);
            aix::HUDX_GREW_0_llvm_4618389659541386029 = 1;
            local_240 = (longlong *******)&local_12c;
            uStack_238 = <u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
            uStack_230 = (longlong ******)&local_128;
            local_228 = (longlong ******)<u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
            alloc[246c2e7857c81348]::fmt::format::format_inner(&local_1c8,&DAT_1406a36b7,&local_240)
            ;
            ppppplVar8 = local_1c8;
            uVar18 = CONCAT44(uStack_1bc,uStack_1c0);
            host::log(uVar18,CONCAT44(uStack_1b4,CONCAT22(uStack_1b6,uStack_1b8)));
            if (ppppplVar8 != (longlong *****)0x0) {
              puVar14 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar18,ppppplVar8,1)
              ;
              return puVar14;
            }
            coopx::objects_pool_install(&local_240,param_2);
            if ((local_240 == (longlong *******)0xffffffffffffffff) &&
               (pools::install(&local_240,param_2),
               local_240 == (longlong *******)0xffffffffffffffff)) {
              hook::install(&local_240,param_2,0x12fcc,&DAT_1406a3683,5,data_new);
              if (local_240 != (longlong *******)0xffffffffffffffff) {
                *param_1 = local_240;
                param_1[1] = uStack_238;
                param_1[2] = uStack_230;
                goto LAB_14003d5b0;
              }
              ORIG_DATA_NEW_0 = uStack_238;
              if (local_170 != (longlong *******)0x0) {
                plVar1 = local_178 + (longlong)local_170 * 5;
                plVar20 = local_178;
                do {
                  win::patch_code(&local_240,*plVar20 + param_2,plVar20 + 1,7,plVar20[3],plVar20[4])
                  ;
                  if (local_240 != (longlong *******)0xffffffffffffffff) goto LAB_14003d59f;
                  plVar20 = plVar20 + 5;
                } while (plVar20 != plVar1);
              }
              local_124 = local_130;
              local_240 = (longlong *******)&DAT_1406a3711;
              uStack_238 = (code *)0x2;
              uStack_230 = (longlong ******)&local_124;
              local_228 = (longlong ******)&DAT_00000004;
              <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat
                        (&local_1c8,&local_240,2);
              uVar18 = CONCAT44(uStack_1bc,uStack_1c0);
              win::patch_code(&local_258,local_98,&DAT_1406a3688,6,uVar18,
                              CONCAT44(uStack_1b4,CONCAT22(uStack_1b6,uStack_1b8)));
              if (local_258 != (longlong ******)0xffffffffffffffff) {
                param_1[2] = local_248;
                *(undefined4 *)param_1 = (undefined4)local_258;
                *(undefined4 *)((longlong)param_1 + 4) = local_258._4_4_;
                *(undefined4 *)(param_1 + 1) = (undefined4)uStack_250;
                *(undefined4 *)((longlong)param_1 + 0xc) = uStack_250._4_4_;
                if (local_1c8 != (longlong *****)0x0) {
                  puVar14 = (undefined8 *)
                            __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar18,local_1c8,1);
                  return puVar14;
                }
                goto LAB_14003d5b0;
              }
              if (local_1c8 != (longlong *****)0x0) {
                puVar14 = (undefined8 *)
                          __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar18,local_1c8,1);
                return puVar14;
              }
              win::patch_code(&local_240,local_a0,&DAT_1406a368e,6,&DAT_1406a3713,6);
              if (local_240 == (longlong *******)0xffffffffffffffff) {
                local_240 = (longlong *******)&local_164;
                uStack_238 = <u32_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
                uStack_230 = (longlong ******)&local_90;
                local_228 = (longlong ******)<usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
                alloc[246c2e7857c81348]::fmt::format::format_inner
                          (&local_1c8,&DAT_1406a3719,&local_240);
                ppppplVar8 = local_1c8;
                uVar18 = CONCAT44(uStack_1bc,uStack_1c0);
                host::log(uVar18,CONCAT44(uStack_1b4,CONCAT22(uStack_1b6,uStack_1b8)));
                if (ppppplVar8 != (longlong *****)0x0) {
                  puVar14 = (undefined8 *)
                            __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar18,ppppplVar8,1);
                  return puVar14;
                }
                *param_1 = 0xffffffffffffffff;
                goto LAB_14003d5b0;
              }
            }
LAB_14003d59f:
            param_1[2] = uStack_230;
            *(int *)param_1 = (int)local_240;
            *(undefined4 *)((longlong)param_1 + 4) = local_240._4_4_;
            *(undefined4 *)(param_1 + 1) = (undefined4)uStack_238;
            *(undefined4 *)((longlong)param_1 + 0xc) = uStack_238._4_4_;
LAB_14003d5b0:
            core[505b25137b8ba7f]::ptr::drop_glue::
            <alloc[246c2e7857c81348]::vec::Vec<(usize,[u8_7usize],alloc[246c2e7857c81348]::vec::Vec<u8>)>>
                      (&local_180);
            return param_1;
          }
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          puVar17 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x23,1);
          if (puVar17 == (undefined4 *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(1,0x23);
LAB_14003d844:
                    /* WARNING: Does not return */
            pcVar3 = (code *)invalidInstructionException();
            (*pcVar3)();
          }
          *(undefined8 *)(puVar17 + 4) = 0x6962204455482065;
          *(undefined8 *)(puVar17 + 6) = 0x6174206b73616d74;
          *puVar17 = 0x6d206f6e;
          puVar17[1] = 0x726f6d65;
          puVar17[2] = 0x6f662079;
          puVar17[3] = 0x68742072;
          *(undefined4 *)((longlong)puVar17 + 0x1f) = 0x656c6261;
          *param_1 = 0x23;
          param_1[1] = puVar17;
          param_1[2] = 0x23;
          goto LAB_14003cccb;
        }
      }
    }
    uStack_1bc = 0;
    local_240 = (longlong *******)&local_258;
    uStack_238 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    uStack_230 = (longlong ******)&local_1c8;
    local_228 = (longlong ******)<&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
    local_220 = &local_108;
    apcStack_218[0] = <&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a364d,&local_240);
    param_1[2] = local_48;
  }
  else {
LAB_14003cc53:
    uStack_1bc = 0;
    uStack_1c0 = 7;
    local_240 = (longlong *******)&local_180;
    uStack_238 = <&usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    uStack_230 = (longlong ******)&local_1c8;
    local_228 = (longlong ******)<&[u8]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
    local_220 = (longlong *****)&local_258;
    apcStack_218[0] = <&[u8;7usize]as_core[505b25137b8ba7f]::fmt::Debug>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_70,&DAT_1406a364d,&local_240);
    param_1[2] = local_60;
    local_58 = local_70;
    uStack_54 = uStack_6c;
    uStack_50 = uStack_68;
    uStack_4c = uStack_64;
  }
  *(undefined4 *)param_1 = local_58;
  *(undefined4 *)((longlong)param_1 + 4) = uStack_54;
  *(undefined4 *)(param_1 + 1) = uStack_50;
  *(undefined4 *)((longlong)param_1 + 0xc) = uStack_4c;
LAB_14003cccb:
  if (local_e8 != (longlong ******)0x0) {
    puVar14 = (undefined8 *)(CONCAT44(uStack_ec,uStack_f0) + 0x20);
    pppppplVar19 = local_e8;
    do {
      if (puVar14[-1] != 0) {
        puVar14 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar14,puVar14[-1],1);
        return puVar14;
      }
      puVar14 = puVar14 + 6;
      pppppplVar19 = (longlong ******)((longlong)pppppplVar19 + -1);
    } while (pppppplVar19 != (longlong ******)0x0);
  }
  if (CONCAT44(uStack_f4,local_f8) == 0) {
    return param_1;
  }
  puVar14 = (undefined8 *)
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      (CONCAT44(uStack_ec,uStack_f0),CONCAT44(uStack_f4,local_f8) * 0x30,8);
  return puVar14;
}

