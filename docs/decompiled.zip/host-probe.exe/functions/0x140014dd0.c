// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>::wrap_copy
// address: 0x140014dd0
// body: available
// range: 0x140014dd0-0x140015021 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14001501d to 0x1406968d8 memmove (external=false, thunk=true, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,
   alloc[246c2e7857c81348]::vec::Vec<u8>)>>::wrap_copy */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>
::wrap_copy(ulonglong *param_1,longlong param_2,longlong param_3,ulonglong param_4)

{
  ulonglong uVar1;
  ulonglong uVar2;
  void *pvVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  size_t sVar7;
  void *pvVar8;
  
  uVar6 = param_3 - param_2;
  if ((uVar6 != 0) && (param_4 != 0)) {
    uVar1 = *param_1;
    uVar2 = uVar1 + uVar6;
    if (!CARRY8(uVar1,uVar6)) {
      uVar2 = uVar6;
    }
    uVar5 = uVar1 - param_2;
    uVar6 = uVar1 - param_3;
    lVar4 = param_4 - uVar5;
    if (param_4 < uVar5 || lVar4 == 0) {
      lVar4 = param_4 - uVar6;
      if (param_4 < uVar6 || lVar4 == 0) {
        pvVar3 = (void *)(param_2 * 0x20 + param_1[1]);
        pvVar8 = (void *)(param_3 * 0x20 + param_1[1]);
        sVar7 = param_4 << 5;
      }
      else if (uVar2 < param_4) {
        pvVar8 = (void *)param_1[1];
        pvVar3 = (void *)(param_2 * 0x20 + (longlong)pvVar8);
        sVar7 = uVar6 * 0x20;
        memmove(pvVar8,(void *)((longlong)pvVar3 + sVar7),lVar4 * 0x20);
        pvVar8 = (void *)(param_3 * 0x20 + (longlong)pvVar8);
      }
      else {
        pvVar8 = (void *)param_1[1];
        pvVar3 = (void *)(param_2 * 0x20 + (longlong)pvVar8);
        memmove((void *)(param_3 * 0x20 + (longlong)pvVar8),pvVar3,uVar6 * 0x20);
        pvVar3 = (void *)(uVar6 * 0x20 + (longlong)pvVar3);
        sVar7 = lVar4 * 0x20;
      }
    }
    else if (uVar2 < param_4) {
      if (uVar6 < param_4) {
        pvVar8 = (void *)param_1[1];
        sVar7 = (uVar5 - uVar6) * 0x20;
        memmove((void *)((longlong)pvVar8 + sVar7),pvVar8,lVar4 * 0x20);
        memmove(pvVar8,(void *)((uVar1 - (uVar5 - uVar6)) * 0x20 + (longlong)pvVar8),sVar7);
        pvVar3 = (void *)(param_2 * 0x20 + (longlong)pvVar8);
        pvVar8 = (void *)(param_3 * 0x20 + (longlong)pvVar8);
        sVar7 = uVar6 * 0x20;
      }
      else {
        pvVar3 = (void *)param_1[1];
        pvVar8 = (void *)(param_3 * 0x20 + (longlong)pvVar3);
        sVar7 = uVar5 * 0x20;
        memmove((void *)((longlong)pvVar8 + sVar7),pvVar3,lVar4 * 0x20);
        pvVar3 = (void *)(param_2 * 0x20 + (longlong)pvVar3);
      }
    }
    else if (param_4 < uVar6 || param_4 - uVar6 == 0) {
      pvVar3 = (void *)param_1[1];
      pvVar8 = (void *)(param_3 * 0x20 + (longlong)pvVar3);
      memmove(pvVar8,(void *)(param_2 * 0x20 + (longlong)pvVar3),uVar5 * 0x20);
      pvVar8 = (void *)(uVar5 * 0x20 + (longlong)pvVar8);
      sVar7 = lVar4 * 0x20;
    }
    else {
      pvVar8 = (void *)param_1[1];
      pvVar3 = (void *)(param_3 * 0x20 + (longlong)pvVar8);
      memmove(pvVar3,(void *)(param_2 * 0x20 + (longlong)pvVar8),uVar5 * 0x20);
      sVar7 = (uVar6 - uVar5) * 0x20;
      memmove((void *)(uVar5 * 0x20 + (longlong)pvVar3),pvVar8,sVar7);
      pvVar3 = (void *)(sVar7 + (longlong)pvVar8);
      sVar7 = (param_4 - uVar6) * 0x20;
    }
    memmove(pvVar8,pvVar3,sVar7);
    return;
  }
  return;
}

