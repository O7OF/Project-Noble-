// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::add_relay_peer
// address: 0x140024dd0
// body: available
// range: 0x140024dd0-0x140025074 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14002503e to 0x140610d80 <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::add_relay_peer */

void __rustcall
host_probe[b94139f9089eb1d8]::net::add_relay_peer
          (undefined8 param_1,undefined8 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong lVar9;
  undefined *puVar10;
  char cVar11;
  longlong lVar12;
  bool bVar13;
  undefined1 *local_48;
  byte local_40;
  
  LOCK();
  bVar13 = RELAY_SESSIONS == '\0';
  if (bVar13) {
    RELAY_SESSIONS = '\x01';
  }
  UNLOCK();
  if (!bVar13) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&RELAY_SESSIONS);
  }
  puVar10 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    local_40 = 0;
    lVar8 = DAT_140699628;
  }
  else {
    local_40 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_40 = local_40 ^ 1;
    lVar8 = DAT_140699628;
  }
  DAT_140699628 = lVar8;
  if (DAT_140699611 != '\0') {
    local_48 = &RELAY_SESSIONS;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_48,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0fb0
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2288);
    goto LAB_140025027;
  }
  if (lVar8 == DAT_140699618) {
    <alloc[246c2e7857c81348]::raw_vec::RawVec<[u8;16usize]>>::grow_one(&DAT_140699618);
  }
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  puVar1 = (undefined4 *)(DAT_140699620 + lVar8 * 0x10);
  *puVar1 = *param_3;
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  DAT_140699628 = lVar8 + 1;
  if (((local_40 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
     (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0'))
  {
    DAT_140699611 = '\x01';
  }
  cVar11 = RELAY_SESSIONS;
  LOCK();
  RELAY_SESSIONS = '\0';
  UNLOCK();
  if (cVar11 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&RELAY_SESSIONS);
    LOCK();
    bVar13 = PENDING_RELAY_PEERS == '\0';
    if (bVar13) {
      PENDING_RELAY_PEERS = '\x01';
    }
    UNLOCK();
    if (!bVar13) goto LAB_140024fbb;
LAB_140024e98:
    if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) == 0) goto LAB_140024ea4;
LAB_140024fd3:
    local_40 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_40 = local_40 ^ 1;
    lVar8 = DAT_140699648;
  }
  else {
    LOCK();
    bVar13 = PENDING_RELAY_PEERS == '\0';
    if (bVar13) {
      PENDING_RELAY_PEERS = '\x01';
    }
    UNLOCK();
    if (bVar13) goto LAB_140024e98;
LAB_140024fbb:
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&PENDING_RELAY_PEERS);
    if ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0) goto LAB_140024fd3;
LAB_140024ea4:
    local_40 = 0;
    lVar8 = DAT_140699648;
  }
  DAT_140699648 = lVar8;
  if (DAT_140699631 == '\0') {
    if (lVar8 == DAT_140699638) {
      <alloc[246c2e7857c81348]::raw_vec::RawVec<reach_directory[4b72b9694f6c3c08]::server_admin::content::GameTypeItem>>
      ::grow_one(&DAT_140699638);
    }
    lVar9 = DAT_140699640;
    lVar12 = lVar8 * 0x38;
    uVar6 = *param_2;
    uVar7 = param_2[1];
    uVar3 = *(undefined4 *)((longlong)param_2 + 0x14);
    uVar4 = *(undefined4 *)(param_2 + 3);
    uVar5 = *(undefined4 *)((longlong)param_2 + 0x1c);
    puVar1 = (undefined4 *)(DAT_140699640 + 0x10 + lVar12);
    *puVar1 = *(undefined4 *)(param_2 + 2);
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    *(undefined8 *)(lVar9 + lVar12) = uVar6;
    ((undefined8 *)(lVar9 + lVar12))[1] = uVar7;
    *(undefined8 *)(lVar9 + 0x20 + lVar12) = param_1;
    uVar3 = param_3[1];
    uVar4 = param_3[2];
    uVar5 = param_3[3];
    puVar1 = (undefined4 *)(lVar9 + 0x28 + lVar12);
    *puVar1 = *param_3;
    puVar1[1] = uVar3;
    puVar1[2] = uVar4;
    puVar1[3] = uVar5;
    DAT_140699648 = lVar8 + 1;
    if (((local_40 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
       (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0')
       ) {
      DAT_140699631 = '\x01';
    }
    cVar11 = PENDING_RELAY_PEERS;
    LOCK();
    PENDING_RELAY_PEERS = 0;
    UNLOCK();
    if (cVar11 != '\x02') {
      return;
    }
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&PENDING_RELAY_PEERS);
    return;
  }
  local_48 = &PENDING_RELAY_PEERS;
  core[505b25137b8ba7f]::result::unwrap_failed
            ("called `Result::unwrap()` on an `Err` value",0x2b,&local_48,
             &
             PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1070
             ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a22a0);
LAB_140025027:
                    /* WARNING: Does not return */
  pcVar2 = (code *)invalidInstructionException();
  (*pcVar2)();
}

