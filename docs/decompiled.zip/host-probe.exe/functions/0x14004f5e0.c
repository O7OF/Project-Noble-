// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::iter::adapters::chain::Chain<core[505b25137b8ba7f]::iter::sources::once::Once<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>,core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>,host_probe[b94139f9089eb1d8]::announce::prepare::{closure#15}::{closure#0}>>>>::from_iter
// address: 0x14004f5e0
// body: available
// range: 0x14004f5e0-0x14004f63d inclusive
// range: 0x14004f640-0x14004f695 inclusive
// range: 0x14004f6a0-0x14004f80b inclusive
// range: 0x14004f810-0x14004f855 inclusive
// range: 0x14004f860-0x14004f8b6 inclusive
// range: 0x14004f8c0-0x14004f9d8 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<core[505b25137b8ba7f]::net::socket_addr::SocketAddr> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<core[505b25137b8ba7f]::net::socket_addr::SocketAddr,
   core[505b25137b8ba7f]::iter::adapters::chain::Chain<core[505b25137b8ba7f]::iter::sources::once::Once<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>,
   core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>,
   host_probe[b94139f9089eb1d8]::announce::prepare::{closure#15}::{closure#0}>>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::iter::adapters::chain::Chain<core[505b25137b8ba7f]::iter::sources::once::Once<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>,core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>,host_probe[b94139f9089eb1d8]::announce::prepare::{closure#15}::{closure#0}>>>>
::from_iter(longlong *param_1,short *param_2)

{
  short *psVar1;
  short *psVar2;
  code *pcVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  short *psVar8;
  short *psVar9;
  short sVar10;
  short sVar11;
  short *psVar12;
  bool bVar13;
  undefined1 auVar14 [16];
  undefined1 auVar15 [16];
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined2 local_88;
  undefined8 local_78;
  undefined6 uStack_70;
  undefined2 uStack_6a;
  undefined6 uStack_68;
  undefined8 uStack_62;
  undefined8 uStack_58;
  undefined6 uStack_50;
  undefined2 local_4a;
  undefined6 uStack_48;
  undefined8 uStack_42;
  
  sVar10 = *param_2;
  if ((sVar10 == -1) || (*param_2 = (ushort)(sVar10 != 2) * 3 + -1, sVar10 == 2)) {
    psVar8 = *(short **)(param_2 + 0x10);
    if ((psVar8 != (short *)0x0) && (psVar9 = *(short **)(param_2 + 0x14), psVar8 != psVar9)) {
      psVar1 = *(short **)(param_2 + 0x18);
      if (*psVar1 == 0) {
        do {
          sVar10 = *psVar8;
          local_a8 = CONCAT62(local_a8._2_6_,psVar8[9]);
          uVar4 = *(undefined8 *)(psVar8 + 1);
          uStack_b0 = *(short **)(psVar8 + 5);
          local_b8 = uVar4;
          if (sVar10 == 0) {
            local_b8._4_2_ = (short)((ulonglong)uVar4 >> 0x20);
            if (local_b8._4_2_ != psVar1[3]) {
              psVar9 = psVar8 + 1;
              psVar8 = psVar8 + 0x10;
              sVar10 = 0;
              goto LAB_14004f767;
            }
            local_b8._0_4_ = (int)uVar4;
            bVar13 = (int)local_b8 != *(int *)(psVar1 + 1);
            if (bVar13) goto LAB_14004f712;
          }
          else if (sVar10 != 2) goto LAB_14004f74c;
          psVar8 = psVar8 + 0x10;
        } while (psVar8 != psVar9);
      }
      else {
        do {
          sVar10 = *psVar8;
          sVar11 = psVar8[9];
          local_a8 = CONCAT62(local_a8._2_6_,sVar11);
          uVar6 = local_a8;
          uVar4 = *(undefined8 *)(psVar8 + 1);
          uVar5 = *(undefined8 *)(psVar8 + 5);
          local_b8 = uVar4;
          uStack_b0 = (short *)uVar5;
          if (sVar10 == 1) {
            if (((psVar8[0xe] != psVar1[0xe]) || (*(int *)(psVar8 + 10) != *(int *)(psVar1 + 10)))
               || (*(int *)(psVar8 + 0xc) != *(int *)(psVar1 + 0xc))) {
              psVar9 = psVar8 + 1;
              psVar8 = psVar8 + 0x10;
              sVar10 = 1;
              goto LAB_14004f767;
            }
            local_b8._2_1_ = (char)((ulonglong)uVar4 >> 0x10);
            local_b8._3_1_ = (char)((ulonglong)uVar4 >> 0x18);
            local_b8._4_1_ = (char)((ulonglong)uVar4 >> 0x20);
            local_b8._5_1_ = (char)((ulonglong)uVar4 >> 0x28);
            local_b8._6_1_ = (char)((ulonglong)uVar4 >> 0x30);
            local_b8._7_1_ = (char)((ulonglong)uVar4 >> 0x38);
            uStack_b0._0_1_ = (char)uVar5;
            uStack_b0._1_1_ = (char)((ulonglong)uVar5 >> 8);
            uStack_b0._2_1_ = (char)((ulonglong)uVar5 >> 0x10);
            uStack_b0._3_1_ = (char)((ulonglong)uVar5 >> 0x18);
            uStack_b0._4_1_ = (char)((ulonglong)uVar5 >> 0x20);
            uStack_b0._5_1_ = (char)((ulonglong)uVar5 >> 0x28);
            uStack_b0._6_1_ = (char)((ulonglong)uVar5 >> 0x30);
            uStack_b0._7_1_ = (char)((ulonglong)uVar5 >> 0x38);
            local_a8._0_1_ = (char)sVar11;
            local_a8._1_1_ = (char)((ushort)sVar11 >> 8);
            auVar14[0] = -((char)psVar1[2] == local_b8._2_1_);
            auVar14[1] = -(*(char *)((longlong)psVar1 + 5) == local_b8._3_1_);
            auVar14[2] = -((char)psVar1[3] == local_b8._4_1_);
            auVar14[3] = -(*(char *)((longlong)psVar1 + 7) == local_b8._5_1_);
            auVar14[4] = -((char)psVar1[4] == local_b8._6_1_);
            auVar14[5] = -(*(char *)((longlong)psVar1 + 9) == local_b8._7_1_);
            auVar14[6] = -((char)psVar1[5] == (char)uStack_b0);
            auVar14[7] = -(*(char *)((longlong)psVar1 + 0xb) == uStack_b0._1_1_);
            auVar14[8] = -((char)psVar1[6] == uStack_b0._2_1_);
            auVar14[9] = -(*(char *)((longlong)psVar1 + 0xd) == uStack_b0._3_1_);
            auVar14[10] = -((char)psVar1[7] == uStack_b0._4_1_);
            auVar14[0xb] = -(*(char *)((longlong)psVar1 + 0xf) == uStack_b0._5_1_);
            auVar14[0xc] = -((char)psVar1[8] == uStack_b0._6_1_);
            auVar14[0xd] = -(*(char *)((longlong)psVar1 + 0x11) == uStack_b0._7_1_);
            auVar14[0xe] = -((char)psVar1[9] == (char)local_a8);
            auVar14[0xf] = -(*(char *)((longlong)psVar1 + 0x13) == local_a8._1_1_);
            local_a8 = uVar6;
            if ((ushort)((ushort)(SUB161(auVar14 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar14 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar14 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar14 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar14 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar14 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar14 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar14 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar14 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar14 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar14 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar14 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar14 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar14 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar14 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar14[0xf] >> 7) << 0xf) != 0xffff) goto LAB_14004f712;
          }
          else if (sVar10 != 2) goto LAB_14004f74c;
          psVar8 = psVar8 + 0x10;
          local_a8 = uVar6;
        } while (psVar8 != psVar9);
      }
    }
    *param_1 = 0;
    param_1[1] = 4;
    param_1[2] = 0;
    return param_1;
  }
  psVar8 = param_2 + 1;
  goto LAB_14004f781;
LAB_14004f74c:
  psVar9 = psVar8 + 1;
  *(short **)(param_2 + 0x10) = psVar8 + 0x10;
  goto LAB_14004f76b;
LAB_14004f712:
  psVar9 = psVar8 + 1;
  psVar8 = psVar8 + 0x10;
  sVar10 = *psVar1;
LAB_14004f767:
  *(short **)(param_2 + 0x10) = psVar8;
LAB_14004f76b:
  uStack_68 = (undefined6)((ulonglong)*(undefined8 *)(psVar9 + 7) >> 0x10);
  uStack_62 = *(undefined8 *)(psVar9 + 0xb);
  local_78 = *(undefined8 *)psVar9;
  uStack_70 = (undefined6)*(undefined8 *)(psVar9 + 4);
  uStack_6a = (undefined2)((ulonglong)*(undefined8 *)(psVar9 + 4) >> 0x30);
  psVar8 = (short *)&local_78;
LAB_14004f781:
  uStack_58 = *(undefined8 *)psVar8;
  uStack_42 = *(undefined8 *)(psVar8 + 0xb);
  uStack_48 = (undefined6)((ulonglong)*(undefined8 *)(psVar8 + 7) >> 0x10);
  uStack_50 = (undefined6)*(undefined8 *)(psVar8 + 4);
  local_4a = (undefined2)((ulonglong)*(undefined8 *)(psVar8 + 4) >> 0x30);
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  psVar8 = (short *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x80,4);
  if (psVar8 == (short *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(4,0x80);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  *psVar8 = sVar10;
  *(undefined8 *)(psVar8 + 1) = uStack_58;
  *(ulonglong *)(psVar8 + 5) = CONCAT26(local_4a,uStack_50);
  *(ulonglong *)(psVar8 + 8) = CONCAT62(uStack_48,local_4a);
  *(undefined8 *)(psVar8 + 0xc) = uStack_42;
  local_b8 = 4;
  local_a8 = 1;
  psVar9 = *(short **)(param_2 + 0x10);
  uStack_b0 = psVar8;
  if (psVar9 == (short *)0x0) {
LAB_14004f999:
    param_1[2] = local_a8;
    *param_1 = local_b8;
    param_1[1] = (longlong)uStack_b0;
    return param_1;
  }
  psVar1 = *(short **)(param_2 + 0x14);
  psVar2 = *(short **)(param_2 + 0x18);
LAB_14004f83e:
  lVar7 = local_a8;
  if (psVar9 != psVar1) {
    sVar10 = *psVar2;
    if (sVar10 == 0) {
      do {
        sVar11 = *psVar9;
        local_88 = psVar9[9];
        uVar4 = *(undefined8 *)(psVar9 + 1);
        uStack_90 = *(undefined8 *)(psVar9 + 5);
        psVar12 = psVar9;
        local_98 = uVar4;
        if (sVar11 == 0) {
          local_98._4_2_ = (short)((ulonglong)uVar4 >> 0x20);
          if (local_98._4_2_ != psVar2[3]) {
            sVar11 = 0;
            goto LAB_14004f956;
          }
          local_98._0_4_ = (int)uVar4;
          bVar13 = (int)local_98 != *(int *)(psVar2 + 1);
          sVar11 = sVar10;
          if (bVar13) goto LAB_14004f956;
        }
        else if (sVar11 != 2) goto LAB_14004f956;
        psVar9 = psVar9 + 0x10;
        if (psVar9 == psVar1) goto LAB_14004f999;
      } while( true );
    }
    do {
      sVar11 = *psVar9;
      local_88 = psVar9[9];
      uVar4 = *(undefined8 *)(psVar9 + 1);
      uVar5 = *(undefined8 *)(psVar9 + 5);
      psVar12 = psVar9;
      local_98 = uVar4;
      uStack_90 = uVar5;
      if (sVar11 == 1) {
        sVar11 = 1;
        if (((psVar9[0xe] != psVar2[0xe]) || (*(int *)(psVar9 + 10) != *(int *)(psVar2 + 10))) ||
           (*(int *)(psVar9 + 0xc) != *(int *)(psVar2 + 0xc))) goto LAB_14004f956;
        local_98._2_1_ = (char)((ulonglong)uVar4 >> 0x10);
        local_98._3_1_ = (char)((ulonglong)uVar4 >> 0x18);
        local_98._4_1_ = (char)((ulonglong)uVar4 >> 0x20);
        local_98._5_1_ = (char)((ulonglong)uVar4 >> 0x28);
        local_98._6_1_ = (char)((ulonglong)uVar4 >> 0x30);
        local_98._7_1_ = (char)((ulonglong)uVar4 >> 0x38);
        uStack_90._0_1_ = (char)uVar5;
        uStack_90._1_1_ = (char)((ulonglong)uVar5 >> 8);
        uStack_90._2_1_ = (char)((ulonglong)uVar5 >> 0x10);
        uStack_90._3_1_ = (char)((ulonglong)uVar5 >> 0x18);
        uStack_90._4_1_ = (char)((ulonglong)uVar5 >> 0x20);
        uStack_90._5_1_ = (char)((ulonglong)uVar5 >> 0x28);
        uStack_90._6_1_ = (char)((ulonglong)uVar5 >> 0x30);
        uStack_90._7_1_ = (char)((ulonglong)uVar5 >> 0x38);
        local_88._1_1_ = (char)((ushort)local_88 >> 8);
        auVar15[0] = -((char)psVar2[2] == local_98._2_1_);
        auVar15[1] = -(*(char *)((longlong)psVar2 + 5) == local_98._3_1_);
        auVar15[2] = -((char)psVar2[3] == local_98._4_1_);
        auVar15[3] = -(*(char *)((longlong)psVar2 + 7) == local_98._5_1_);
        auVar15[4] = -((char)psVar2[4] == local_98._6_1_);
        auVar15[5] = -(*(char *)((longlong)psVar2 + 9) == local_98._7_1_);
        auVar15[6] = -((char)psVar2[5] == (char)uStack_90);
        auVar15[7] = -(*(char *)((longlong)psVar2 + 0xb) == uStack_90._1_1_);
        auVar15[8] = -((char)psVar2[6] == uStack_90._2_1_);
        auVar15[9] = -(*(char *)((longlong)psVar2 + 0xd) == uStack_90._3_1_);
        auVar15[10] = -((char)psVar2[7] == uStack_90._4_1_);
        auVar15[0xb] = -(*(char *)((longlong)psVar2 + 0xf) == uStack_90._5_1_);
        auVar15[0xc] = -((char)psVar2[8] == uStack_90._6_1_);
        auVar15[0xd] = -(*(char *)((longlong)psVar2 + 0x11) == uStack_90._7_1_);
        auVar15[0xe] = -((char)psVar2[9] == (char)local_88);
        auVar15[0xf] = -(*(char *)((longlong)psVar2 + 0x13) == local_88._1_1_);
        sVar11 = sVar10;
        if ((ushort)((ushort)(SUB161(auVar15 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar15 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar15 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar15 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar15 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar15 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar15 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar15 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar15 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar15 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar15 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar15 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar15 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar15 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar15 >> 0x77,0) & 1) << 0xe |
                    (ushort)(auVar15[0xf] >> 7) << 0xf) != 0xffff) goto LAB_14004f956;
      }
      else if (sVar11 != 2) goto LAB_14004f956;
      psVar9 = psVar9 + 0x10;
      if (psVar9 == psVar1) break;
    } while( true );
  }
  goto LAB_14004f999;
LAB_14004f956:
  psVar9 = psVar12 + 0x10;
  local_78 = *(undefined8 *)(psVar12 + 1);
  uStack_62 = *(undefined8 *)(psVar12 + 0xc);
  uStack_68 = (undefined6)((ulonglong)*(undefined8 *)(psVar12 + 8) >> 0x10);
  uStack_70 = (undefined6)*(undefined8 *)(psVar12 + 5);
  uStack_6a = (undefined2)((ulonglong)*(undefined8 *)(psVar12 + 5) >> 0x30);
  if (local_a8 == local_b8) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_b8,local_a8,1,4,0x20);
    psVar8 = uStack_b0;
  }
  psVar8[lVar7 * 0x10] = sVar11;
  *(undefined8 *)(psVar8 + lVar7 * 0x10 + 1) = local_78;
  *(ulonglong *)(psVar8 + lVar7 * 0x10 + 1 + 4) = CONCAT26(uStack_6a,uStack_70);
  *(ulonglong *)(psVar8 + lVar7 * 0x10 + 8) = CONCAT62(uStack_68,uStack_6a);
  *(undefined8 *)(psVar8 + lVar7 * 0x10 + 8 + 4) = uStack_62;
  local_a8 = lVar7 + 1;
  goto LAB_14004f83e;
}

