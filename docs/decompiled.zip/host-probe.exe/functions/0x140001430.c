// rea decompile_all
// name: <core[505b25137b8ba7f]::option::Option<&str>>::filter::<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#6}>
// address: 0x140001430
// body: available
// range: 0x140001430-0x140001457 inclusive
// range: 0x140001460-0x1400014b3 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::option::Option<&str>>::filter::<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#6}>
    */

longlong __rustcall
<core[505b25137b8ba7f]::option::Option<&str>>::filter::
<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_6_>
          (longlong param_1,longlong param_2)

{
  byte bVar1;
  bool bVar2;
  bool bVar3;
  longlong lVar4;
  
  if (0x5f < param_2 - 1U || param_1 == 0) {
    return 0;
  }
  if (param_2 != 0) {
    lVar4 = 0;
    do {
      bVar1 = *(byte *)(param_1 + lVar4);
      bVar3 = (byte)(bVar1 - 0x3a) < 0xf6;
      if (0x40 < bVar1) {
        bVar3 = 0x5a < bVar1;
      }
      bVar2 = 0x7a < bVar1;
      if (bVar1 < 0x61) {
        bVar2 = bVar3;
      }
      if ((bVar1 != 0x2d) && (bVar2)) {
        return 0;
      }
      lVar4 = lVar4 + 1;
    } while (param_2 != lVar4);
  }
  return param_1;
}

