// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u32,bool)>>::resize
// address: 0x140047190
// body: available
// range: 0x140047190-0x1400472c1 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u32, bool)>>::resize */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u32,bool)>>::resize
          (longlong *param_1,ulonglong param_2,undefined4 param_3,undefined1 param_4)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined4 *puVar4;
  ulonglong uVar5;
  
  uVar2 = param_1[2];
  uVar3 = param_2 - uVar2;
  if (uVar2 <= param_2 && uVar3 != 0) {
    if (*param_1 - uVar2 < uVar3) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(param_1,uVar2,uVar3,4,8);
      puVar4 = (undefined4 *)(param_1[2] * 8 + param_1[1]);
      uVar1 = param_1[2];
    }
    else {
      puVar4 = (undefined4 *)(uVar2 * 8 + param_1[1]);
      uVar1 = uVar2;
    }
    if (1 < uVar3) {
      uVar5 = (ulonglong)((uint)(param_2 + ~uVar2) & 7);
      if (uVar3 - 2 < 7) goto LAB_140047240;
      uVar2 = param_2 + ~uVar2 & 0xfffffffffffffff8;
      do {
        *puVar4 = param_3;
        *(undefined1 *)(puVar4 + 1) = param_4;
        puVar4[2] = param_3;
        *(undefined1 *)(puVar4 + 3) = param_4;
        puVar4[4] = param_3;
        *(undefined1 *)(puVar4 + 5) = param_4;
        puVar4[6] = param_3;
        *(undefined1 *)(puVar4 + 7) = param_4;
        puVar4[8] = param_3;
        *(undefined1 *)(puVar4 + 9) = param_4;
        puVar4[10] = param_3;
        *(undefined1 *)(puVar4 + 0xb) = param_4;
        puVar4[0xc] = param_3;
        *(undefined1 *)(puVar4 + 0xd) = param_4;
        puVar4[0xe] = param_3;
        *(undefined1 *)(puVar4 + 0xf) = param_4;
        puVar4 = puVar4 + 0x10;
        uVar2 = uVar2 - 8;
      } while (uVar2 != 0);
      for (; uVar5 != 0; uVar5 = uVar5 - 1) {
LAB_140047240:
        *puVar4 = param_3;
        *(undefined1 *)(puVar4 + 1) = param_4;
        puVar4 = puVar4 + 2;
      }
      uVar1 = (uVar1 + uVar3) - 1;
    }
    *puVar4 = param_3;
    *(undefined1 *)(puVar4 + 1) = param_4;
    param_2 = uVar1 + 1;
  }
  param_1[2] = param_2;
  return;
}

