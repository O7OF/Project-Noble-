// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::ready
// address: 0x14000e8d0
// body: available
// range: 0x14000e8d0-0x14000e958 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::ready */

bool __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::ready
          (longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong lVar3;
  bool bVar4;
  bool bVar5;
  undefined8 local_10;
  undefined4 local_8;
  
  lVar1 = *(longlong *)(param_1 + 0x3b8);
  if (lVar1 == *(longlong *)(param_1 + 0x3c0)) {
    if (*(longlong *)(param_1 + 0xb8) != 0) {
      lVar3 = 0;
      do {
        bVar4 = *(longlong *)(*(longlong *)(param_1 + 0xb0) + 0x18 + lVar3) == lVar1;
        if (bVar4) {
          return bVar4;
        }
        bVar5 = *(longlong *)(param_1 + 0xb8) * 0x28 + -0x28 != lVar3;
        lVar3 = lVar3 + 0x28;
      } while (bVar5);
      return bVar4;
    }
  }
  else if (*(int *)(param_1 + 0x350) != -1) {
    local_10 = param_2;
    local_8 = param_3;
    uVar2 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                      (&local_10,*(undefined8 *)(param_1 + 0x348));
    return uVar2 < 2;
  }
  return false;
}

