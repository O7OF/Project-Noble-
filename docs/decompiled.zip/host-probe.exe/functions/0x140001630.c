// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::retain::<<host_probe[b94139f9089eb1d8]::aiwave::Cohorts>::cancel_squad::{closure#0}>
// address: 0x140001630
// body: available
// range: 0x140001630-0x14000170a inclusive
// range: 0x140001710-0x140001878 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000185a to 0x140015460 <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::truncate (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>::retain::<<host_probe[b94139f9089eb1d8]::aiwave::Cohorts>::cancel_squad::{closure#0}>
    */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>
::retain::<<host_probe[b94139f9089eb1d8]::aiwave::Cohorts>::cancel_squad::_closure_0_>
          (ulonglong *param_1,short *param_2)

{
  undefined8 *puVar1;
  short sVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  code *pcVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 uVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  undefined8 uVar26;
  undefined8 uVar27;
  undefined8 uVar28;
  undefined8 uVar29;
  undefined8 uVar30;
  undefined8 uVar31;
  undefined8 uVar32;
  ulonglong uVar33;
  ulonglong uVar34;
  longlong lVar35;
  ulonglong uVar36;
  ulonglong uVar37;
  ulonglong uVar38;
  undefined8 *puVar39;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  
  uVar3 = param_1[3];
  if (uVar3 == 0) {
    uVar33 = 0;
    uVar34 = 0;
LAB_140001834:
    if (uVar34 != uVar33) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::aiwave::Cohort>>
      ::truncate();
      return;
    }
  }
  else {
    lVar35 = param_1[2] * 0x68 + param_1[1] + 0x5c;
    uVar33 = 0;
    do {
      uVar34 = 0;
      if (*param_1 <= param_1[2] + uVar33) {
        uVar34 = *param_1;
      }
      if (*(short *)(lVar35 + uVar34 * -0x68) == *param_2) {
        uVar38 = uVar33 + 1;
        uVar34 = uVar38;
        if (uVar38 < uVar3) {
          uVar4 = param_1[2];
          uVar36 = uVar3;
          if (uVar3 < uVar33) {
            uVar36 = uVar33;
          }
          uVar5 = *param_1;
          uVar6 = param_1[1];
          sVar2 = *param_2;
          do {
            lVar35 = (uVar4 + uVar38) * 0x68 + uVar6;
            uVar34 = uVar38;
            while( true ) {
              uVar37 = uVar5;
              if (uVar4 + uVar34 < uVar5) {
                uVar37 = 0;
              }
              if (*(short *)(lVar35 + 0x5c + uVar37 * -0x68) != sVar2) break;
              uVar34 = uVar34 + 1;
              lVar35 = lVar35 + 0x68;
              if (uVar3 <= uVar34) {
                uVar34 = uVar38 + 1;
                if (uVar38 + 1 < uVar3) {
                  uVar34 = uVar3;
                }
                goto LAB_140001834;
              }
            }
            if (uVar33 == uVar36) {
              core[505b25137b8ba7f]::panicking::panic
                        (&anon_d5c34e88a06ee720b116585eb143da4b_235_llvm_14435704873730135342,0x20,
                         &anon_d5c34e88a06ee720b116585eb143da4b_236_llvm_14435704873730135342);
                    /* WARNING: Does not return */
              pcVar9 = (code *)invalidInstructionException();
              (*pcVar9)();
            }
            puVar39 = (undefined8 *)(lVar35 + uVar37 * -0x68);
            uVar38 = 0;
            if (uVar5 <= uVar33 + uVar4) {
              uVar38 = uVar5;
            }
            lVar35 = ((uVar33 + uVar4) - uVar38) * 0x68;
            uVar7 = *(undefined8 *)(uVar6 + 0x60 + lVar35);
            puVar1 = (undefined8 *)(uVar6 + 0x50 + lVar35);
            uVar10 = *puVar1;
            uVar11 = puVar1[1];
            puVar1 = (undefined8 *)(uVar6 + 0x40 + lVar35);
            uVar12 = *puVar1;
            uVar13 = puVar1[1];
            uVar14 = *(undefined8 *)(uVar6 + lVar35);
            uVar15 = ((undefined8 *)(uVar6 + lVar35))[1];
            puVar1 = (undefined8 *)(uVar6 + 0x10 + lVar35);
            uVar16 = *puVar1;
            uVar17 = puVar1[1];
            puVar1 = (undefined8 *)(uVar6 + 0x20 + lVar35);
            uVar18 = *puVar1;
            uVar19 = puVar1[1];
            puVar1 = (undefined8 *)(uVar6 + 0x30 + lVar35);
            uVar20 = *puVar1;
            uVar21 = puVar1[1];
            uVar8 = puVar39[0xc];
            uVar22 = puVar39[10];
            uVar23 = puVar39[0xb];
            uVar24 = puVar39[8];
            uVar25 = puVar39[9];
            uVar26 = puVar39[1];
            uVar27 = puVar39[2];
            uVar28 = puVar39[3];
            uVar29 = puVar39[4];
            uVar30 = puVar39[5];
            uVar31 = puVar39[6];
            uVar32 = puVar39[7];
            *(undefined8 *)(uVar6 + lVar35) = *puVar39;
            ((undefined8 *)(uVar6 + lVar35))[1] = uVar26;
            puVar1 = (undefined8 *)(uVar6 + 0x10 + lVar35);
            *puVar1 = uVar27;
            puVar1[1] = uVar28;
            puVar1 = (undefined8 *)(uVar6 + 0x20 + lVar35);
            *puVar1 = uVar29;
            puVar1[1] = uVar30;
            puVar1 = (undefined8 *)(uVar6 + 0x30 + lVar35);
            *puVar1 = uVar31;
            puVar1[1] = uVar32;
            puVar1 = (undefined8 *)(uVar6 + 0x40 + lVar35);
            *puVar1 = uVar24;
            puVar1[1] = uVar25;
            puVar1 = (undefined8 *)(uVar6 + 0x50 + lVar35);
            *puVar1 = uVar22;
            puVar1[1] = uVar23;
            *(undefined8 *)(uVar6 + 0x60 + lVar35) = uVar8;
            puVar39[0xc] = uVar7;
            puVar39[10] = uVar10;
            puVar39[0xb] = uVar11;
            puVar39[8] = uVar12;
            puVar39[9] = uVar13;
            local_98 = (undefined4)uVar14;
            uStack_94 = (undefined4)((ulonglong)uVar14 >> 0x20);
            uStack_90 = (undefined4)uVar15;
            uStack_8c = (undefined4)((ulonglong)uVar15 >> 0x20);
            local_88 = (undefined4)uVar16;
            uStack_84 = (undefined4)((ulonglong)uVar16 >> 0x20);
            uStack_80 = (undefined4)uVar17;
            uStack_7c = (undefined4)((ulonglong)uVar17 >> 0x20);
            local_78 = (undefined4)uVar18;
            uStack_74 = (undefined4)((ulonglong)uVar18 >> 0x20);
            uStack_70 = (undefined4)uVar19;
            uStack_6c = (undefined4)((ulonglong)uVar19 >> 0x20);
            local_68 = (undefined4)uVar20;
            uStack_64 = (undefined4)((ulonglong)uVar20 >> 0x20);
            uStack_60 = (undefined4)uVar21;
            uStack_5c = (undefined4)((ulonglong)uVar21 >> 0x20);
            *(undefined4 *)(puVar39 + 6) = local_68;
            *(undefined4 *)((longlong)puVar39 + 0x34) = uStack_64;
            *(undefined4 *)(puVar39 + 7) = uStack_60;
            *(undefined4 *)((longlong)puVar39 + 0x3c) = uStack_5c;
            *(undefined4 *)(puVar39 + 4) = local_78;
            *(undefined4 *)((longlong)puVar39 + 0x24) = uStack_74;
            *(undefined4 *)(puVar39 + 5) = uStack_70;
            *(undefined4 *)((longlong)puVar39 + 0x2c) = uStack_6c;
            *(undefined4 *)(puVar39 + 2) = local_88;
            *(undefined4 *)((longlong)puVar39 + 0x14) = uStack_84;
            *(undefined4 *)(puVar39 + 3) = uStack_80;
            *(undefined4 *)((longlong)puVar39 + 0x1c) = uStack_7c;
            *(undefined4 *)puVar39 = local_98;
            *(undefined4 *)((longlong)puVar39 + 4) = uStack_94;
            *(undefined4 *)(puVar39 + 1) = uStack_90;
            *(undefined4 *)((longlong)puVar39 + 0xc) = uStack_8c;
            uVar38 = uVar34 + 1;
            uVar33 = uVar33 + 1;
          } while (uVar38 < uVar3);
          uVar34 = uVar34 + 1;
        }
        goto LAB_140001834;
      }
      uVar33 = uVar33 + 1;
      lVar35 = lVar35 + 0x68;
    } while (uVar3 != uVar33);
  }
  return;
}

