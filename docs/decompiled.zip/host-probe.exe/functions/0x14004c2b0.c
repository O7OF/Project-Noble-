// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#12}>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#13}>>>::from_iter
// address: 0x14004c2b0
// body: available
// range: 0x14004c2b0-0x14004c588 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#12}>,
   host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#13}>>>::from_iter */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#12}>,host_probe[b94139f9089eb1d8]::trace::log_motion::{closure#13}>>>
::from_iter(ulonglong *param_1,undefined8 *param_2)

{
  undefined4 *puVar1;
  ulonglong uVar2;
  longlong *plVar3;
  ulonglong *puVar4;
  ulonglong uVar5;
  code *pcVar6;
  ulonglong uVar7;
  undefined4 *puVar8;
  int *piVar9;
  ulonglong uVar10;
  ulonglong local_c0;
  undefined4 *local_b8;
  ulonglong local_b0;
  ulonglong *local_a8;
  code *local_a0;
  ulonglong *local_98;
  code *local_90;
  undefined8 local_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 local_78;
  ulonglong *local_70;
  ulonglong local_68;
  ulonglong local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  uVar2 = param_2[2];
  uVar10 = param_2[1];
  if (uVar10 < uVar2) {
    plVar3 = (longlong *)*param_2;
    piVar9 = (int *)(uVar10 * 4 + *plVar3);
    do {
      if (*piVar9 != -1) {
        puVar4 = (ulonglong *)param_2[3];
        local_88 = *puVar4;
        if (local_88 == 0) {
          core[505b25137b8ba7f]::panicking::panic_const::panic_const_div_by_zero
                    (&PTR_s_src_trace_rs_1406a3db8);
                    /* WARNING: Does not return */
          pcVar6 = (code *)invalidInstructionException();
          (*pcVar6)();
        }
        if ((uVar10 | local_88) >> 0x20 == 0) {
          local_c0 = (uVar10 & 0xffffffff) / (local_88 & 0xffffffff);
          local_88 = (uVar10 & 0xffffffff) % (local_88 & 0xffffffff);
        }
        else {
          local_c0 = uVar10 / local_88;
          local_88 = uVar10 % local_88;
        }
        local_a8 = &local_c0;
        local_a0 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_98 = &local_88;
        local_90 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a3dd0,&local_a8);
        if (CONCAT44(uStack_54,local_58) != -1) {
          local_70 = puVar4;
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          puVar8 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60);
          if (puVar8 == (undefined4 *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
            goto LAB_14004c587;
          }
          uVar10 = uVar10 + 1;
          *(undefined8 *)(puVar8 + 4) = local_48;
          *puVar8 = local_58;
          puVar8[1] = uStack_54;
          puVar8[2] = uStack_50;
          puVar8[3] = uStack_4c;
          local_c0 = 4;
          local_b0 = 1;
          local_b8 = puVar8;
          if (uVar2 <= uVar10) goto LAB_14004c512;
          goto LAB_14004c401;
        }
        break;
      }
      uVar10 = uVar10 + 1;
      piVar9 = piVar9 + 1;
    } while (uVar2 != uVar10);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
  while( true ) {
    if (uVar7 == local_c0) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_c0,uVar7,1,8,0x18);
      puVar8 = local_b8;
    }
    uVar10 = uVar10 + 1;
    *(undefined8 *)(puVar8 + uVar7 * 6 + 4) = local_78;
    puVar1 = puVar8 + uVar7 * 6;
    *puVar1 = (undefined4)local_88;
    puVar1[1] = local_88._4_4_;
    puVar1[2] = uStack_80;
    puVar1[3] = uStack_7c;
    local_b0 = uVar7 + 1;
    if (uVar2 <= uVar10) break;
LAB_14004c401:
    uVar7 = local_b0;
    piVar9 = (int *)(uVar10 * 4 + *plVar3);
    while (*piVar9 == -1) {
      uVar10 = uVar10 + 1;
      piVar9 = piVar9 + 1;
      if (uVar2 == uVar10) goto LAB_14004c512;
    }
    uVar5 = *local_70;
    if (uVar5 == 0) {
      core[505b25137b8ba7f]::panicking::panic_const::panic_const_div_by_zero
                (&PTR_s_src_trace_rs_1406a3db8);
LAB_14004c587:
                    /* WARNING: Does not return */
      pcVar6 = (code *)invalidInstructionException();
      (*pcVar6)();
    }
    if ((uVar10 | uVar5) >> 0x20 == 0) {
      local_68 = (uVar10 & 0xffffffff) / (uVar5 & 0xffffffff);
      local_60 = (uVar10 & 0xffffffff) % (uVar5 & 0xffffffff);
    }
    else {
      local_68 = uVar10 / uVar5;
      local_60 = uVar10 % uVar5;
    }
    local_a8 = &local_68;
    local_a0 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_98 = &local_60;
    local_90 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_88,&DAT_1406a3dd0,&local_a8);
    if (local_88 == 0xffffffffffffffff) break;
  }
LAB_14004c512:
  param_1[2] = local_b0;
  *param_1 = local_c0;
  param_1[1] = (ulonglong)local_b8;
  return param_1;
}

