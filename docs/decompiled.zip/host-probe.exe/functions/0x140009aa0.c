// rea decompile_all
// name: <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>::hash_one::<&core[505b25137b8ba7f]::net::ip_addr::IpAddr>
// address: 0x140009aa0
// body: available
// range: 0x140009aa0-0x140009c3c inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <std[3bf9d48a0c3997f0]::hash::random::RandomState as
   core[505b25137b8ba7f]::hash::BuildHasher>::hash_one::<&core[505b25137b8ba7f]::net::ip_addr::IpAddr>
    */

ulonglong __rustcall
<std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>::
hash_one::<&core[505b25137b8ba7f]::net::ip_addr::IpAddr>(undefined1 (*param_1) [16],byte *param_2)

{
  byte bVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined1 auVar9 [16];
  undefined1 auVar10 [16];
  ulonglong local_68;
  undefined8 uStack_60;
  undefined1 local_58 [16];
  undefined1 local_48 [16];
  undefined1 local_38 [16];
  undefined1 local_28 [16];
  undefined8 local_18;
  
  local_38 = *param_1;
  auVar9._0_8_ = local_38._0_8_;
  auVar9._8_4_ = local_38._0_4_;
  auVar9._12_4_ = local_38._4_4_;
  local_58 = auVar9 ^ (undefined1  [16])s_uespemosarenegyl_1406a00f0;
  auVar10._0_8_ = local_38._8_8_;
  auVar10._8_4_ = local_38._8_4_;
  auVar10._12_4_ = local_38._12_4_;
  local_48 = auVar10 ^ (undefined1  [16])s_modnarodsetybdet_1406a0100;
  local_28 = (undefined1  [16])0x0;
  local_18 = 0;
  bVar1 = *param_2;
  local_68 = (ulonglong)bVar1;
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_58,&local_68,8);
  if ((ulonglong)bVar1 == 1) {
    local_68 = *(ulonglong *)(param_2 + 1);
    uStack_60 = *(undefined8 *)(param_2 + 9);
    uVar6 = 0x10;
  }
  else {
    local_68 = CONCAT44(local_68._4_4_,*(undefined4 *)(param_2 + 1));
    uVar6 = 4;
  }
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_58,&local_68,uVar6);
  uVar8 = local_28._0_8_ << 0x38 | local_28._8_8_;
  uVar3 = local_48._8_8_ ^ uVar8;
  uVar2 = local_58._0_8_ + local_48._0_8_;
  uVar5 = (local_48._0_8_ << 0xd | (ulonglong)local_48._0_8_ >> 0x33) ^ uVar2;
  uVar4 = (uVar3 << 0x10 | uVar3 >> 0x30) ^ local_58._8_8_ + uVar3;
  uVar7 = local_58._8_8_ + uVar3 + uVar5;
  uVar2 = (uVar2 << 0x20 | uVar2 >> 0x20) + uVar4;
  uVar5 = (uVar5 << 0x11 | uVar5 >> 0x2f) ^ uVar7;
  uVar3 = (uVar4 << 0x15 | uVar4 >> 0x2b) ^ uVar2;
  uVar2 = (uVar2 ^ uVar8) + uVar5;
  uVar7 = ((uVar7 << 0x20 | uVar7 >> 0x20) ^ 0xff) + uVar3;
  uVar4 = (uVar5 << 0xd | uVar5 >> 0x33) ^ uVar2;
  uVar3 = (uVar3 << 0x10 | uVar3 >> 0x30) ^ uVar7;
  uVar7 = uVar7 + uVar4;
  uVar2 = (uVar2 << 0x20 | uVar2 >> 0x20) + uVar3;
  uVar4 = (uVar4 << 0x11 | uVar4 >> 0x2f) ^ uVar7;
  uVar3 = (uVar3 << 0x15 | uVar3 >> 0x2b) ^ uVar2;
  uVar2 = uVar2 + uVar4;
  uVar5 = (uVar7 << 0x20 | uVar7 >> 0x20) + uVar3;
  uVar4 = (uVar4 << 0xd | uVar4 >> 0x33) ^ uVar2;
  uVar3 = (uVar3 << 0x10 | uVar3 >> 0x30) ^ uVar5;
  uVar5 = uVar5 + uVar4;
  uVar2 = (uVar2 << 0x20 | uVar2 >> 0x20) + uVar3;
  uVar4 = (uVar4 << 0x11 | uVar4 >> 0x2f) ^ uVar5;
  uVar3 = (uVar3 << 0x15 | uVar3 >> 0x2b) ^ uVar2;
  uVar5 = (uVar5 << 0x20 | uVar5 >> 0x20) + uVar3;
  uVar4 = (uVar4 << 0xd | uVar4 >> 0x33) ^ uVar2 + uVar4;
  uVar2 = (uVar3 << 0x10 | uVar3 >> 0x30) ^ uVar5;
  uVar5 = uVar5 + uVar4;
  return (uVar5 << 0x20 | uVar5 >> 0x20) ^ (uVar4 << 0x11 | uVar4 >> 0x2f) ^
         (uVar2 << 0x15 | uVar2 >> 0x2b) ^ uVar5;
}

