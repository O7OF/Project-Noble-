// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value)>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value),core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(&str,usize,i32,i32)>,host_probe[b94139f9089eb1d8]::gametype::loadouts_of::{closure#0}::{closure#0}::{closure#0}>>>::from_iter
// address: 0x1400490f0
// body: available
// range: 0x1400490f0-0x1400491b6 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,
   serde_json[7404bcab4dc139c7]::value::Value)> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(alloc[246c2e7857c81348]::string::String,
   serde_json[7404bcab4dc139c7]::value::Value),
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(&str,
   usize, i32, i32)>,
   host_probe[b94139f9089eb1d8]::gametype::loadouts_of::{closure#0}::{closure#0}::{closure#0}>>>::from_iter
    */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value)>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value),core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(&str,usize,i32,i32)>,host_probe[b94139f9089eb1d8]::gametype::loadouts_of::{closure#0}::{closure#0}::{closure#0}>>>
::from_iter(ulonglong *param_1,longlong *param_2)

{
  code *pcVar1;
  ulonglong uVar2;
  undefined8 uVar3;
  longlong unaff_RDI;
  ulonglong uVar4;
  ulonglong local_48;
  ulonglong *local_40;
  undefined8 local_38;
  ulonglong local_30;
  
  if ((ulonglong)(param_2[1] - *param_2) < 0x4924924924924921) {
    uVar4 = (ulonglong)(param_2[1] - *param_2) >> 5;
    unaff_RDI = uVar4 * 0x38;
    if (unaff_RDI == 0) {
      uVar2 = 8;
      uVar4 = 0;
    }
    else {
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar3 = 8;
      uVar2 = __rustc[9d087a5ab36ea756]::__rust_alloc(unaff_RDI,8);
      if (uVar2 == 0) goto LAB_140049113;
    }
    local_40 = &local_48;
    local_48 = 0;
    local_38 = 0;
    local_30 = uVar2;
    <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(&str,usize,i32,i32)>,host_probe[b94139f9089eb1d8]::gametype::loadouts_of::{closure#0}::{closure#0}::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
    ::fold::
    <(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<(alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value),<alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value)>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(&str,usize,i32,i32)>,host_probe[b94139f9089eb1d8]::gametype::loadouts_of::_closure_0_::_closure_0_::_closure_0_>>::_closure_0_>::_closure_0_>
              (param_2,&local_40);
    param_1[2] = local_48;
    *param_1 = uVar4;
    param_1[1] = uVar2;
    return param_1;
  }
  uVar3 = 0;
LAB_140049113:
  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar3,unaff_RDI);
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

