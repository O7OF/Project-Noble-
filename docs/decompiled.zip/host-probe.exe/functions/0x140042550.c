// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(usize,[u32;2usize])>>::retain::<host_probe[b94139f9089eb1d8]::m64_readers::forget::{closure#0}>
// address: 0x140042550
// body: available
// range: 0x140042550-0x140042664 inclusive
// range: 0x140042670-0x1400426b7 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(usize, [u32;
   2usize])>>::retain::<host_probe[b94139f9089eb1d8]::m64_readers::forget::{closure#0}> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(usize,[u32;2usize])>>::retain::
<host_probe[b94139f9089eb1d8]::m64_readers::forget::_closure_0_>(longlong param_1,longlong *param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong *plVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  undefined8 *puVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  
  uVar3 = *(ulonglong *)(param_1 + 0x10);
  if (uVar3 != 0) {
    lVar4 = *(longlong *)(param_1 + 8);
    lVar5 = *param_2;
    uVar14 = (ulonglong)((uint)uVar3 & 3);
    if (uVar3 < 4) {
      uVar11 = 0;
    }
    else {
      plVar9 = (longlong *)(lVar4 + 0x30);
      uVar10 = 0;
      do {
        if (plVar9[-6] == lVar5) {
          uVar11 = uVar10 + 1;
          goto LAB_140042612;
        }
        if (plVar9[-4] == lVar5) {
          uVar11 = uVar10 + 2;
          uVar10 = uVar10 + 1;
          goto LAB_140042612;
        }
        if (plVar9[-2] == lVar5) {
          uVar11 = uVar10 + 3;
          uVar10 = uVar10 + 2;
          goto LAB_140042612;
        }
        uVar11 = uVar10 + 4;
        if (*plVar9 == lVar5) {
          uVar10 = uVar10 | 3;
          goto LAB_140042612;
        }
        plVar9 = plVar9 + 8;
        uVar10 = uVar11;
      } while ((uVar3 & 0x7fffffffffffffc) != uVar11);
      if (uVar14 == 0) {
        return;
      }
    }
    plVar9 = (longlong *)(uVar11 * 0x10 + lVar4);
    lVar8 = 0;
    do {
      if (*plVar9 == lVar5) {
        uVar10 = uVar11 - lVar8;
        uVar11 = uVar10 + 1;
LAB_140042612:
        if (uVar11 < uVar3) {
          uVar14 = uVar11 + 1;
          uVar13 = uVar11;
          if ((((uint)uVar3 - (int)uVar11 & 1) != 0) &&
             (uVar13 = uVar14, *(longlong *)(lVar4 + uVar11 * 0x10) != lVar5)) {
            puVar12 = (undefined8 *)(uVar11 * 0x10 + lVar4);
            uVar7 = puVar12[1];
            puVar1 = (undefined8 *)(lVar4 + uVar10 * 0x10);
            *puVar1 = *puVar12;
            puVar1[1] = uVar7;
            uVar10 = uVar10 + 1;
          }
          if (uVar3 != uVar14) {
            lVar8 = uVar3 - uVar13;
            plVar9 = (longlong *)(uVar13 * 0x10 + lVar4 + 0x10);
            do {
              if (plVar9[-2] == lVar5) {
                lVar6 = *plVar9;
              }
              else {
                lVar6 = plVar9[-1];
                plVar2 = (longlong *)(lVar4 + uVar10 * 0x10);
                *plVar2 = plVar9[-2];
                plVar2[1] = lVar6;
                uVar10 = uVar10 + 1;
                lVar6 = *plVar9;
              }
              if (lVar6 != lVar5) {
                lVar6 = plVar9[1];
                plVar2 = (longlong *)(lVar4 + uVar10 * 0x10);
                *plVar2 = *plVar9;
                plVar2[1] = lVar6;
                uVar10 = uVar10 + 1;
              }
              plVar9 = plVar9 + 4;
              lVar8 = lVar8 + -2;
            } while (lVar8 != 0);
          }
        }
        *(ulonglong *)(param_1 + 0x10) = uVar10;
        return;
      }
      lVar8 = lVar8 + -1;
      plVar9 = plVar9 + 2;
    } while (-lVar8 != uVar14);
  }
  return;
}

