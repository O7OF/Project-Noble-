// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::position::check<&core[505b25137b8ba7f]::net::socket_addr::SocketAddr,host_probe[b94139f9089eb1d8]::net::remember_direct::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&core[505b25137b8ba7f]::net::socket_addr::SocketAddr)>>::call_mut
// address: 0x14003f2d0
// body: available
// range: 0x14003f2d0-0x14003f348 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut 
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::position::check<&core[505b25137b8ba7f]::net::socket_addr::SocketAddr,
   host_probe[b94139f9089eb1d8]::net::remember_direct::{closure#0}>::{closure#0} as
   core[505b25137b8ba7f]::ops::function::FnMut<((),
   &core[505b25137b8ba7f]::net::socket_addr::SocketAddr)>>::call_mut */

undefined8 __rustcall
<&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::position::check<&core[505b25137b8ba7f]::net::socket_addr::SocketAddr,host_probe[b94139f9089eb1d8]::net::remember_direct::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&core[505b25137b8ba7f]::net::socket_addr::SocketAddr)>>
::call_mut(undefined8 *param_1,short *param_2)

{
  short *psVar1;
  longlong *plVar2;
  undefined1 auVar3 [16];
  
  psVar1 = *(short **)*param_1;
  plVar2 = (longlong *)((undefined8 *)*param_1)[1];
  if (*param_2 == *psVar1) {
    if (*param_2 == 0) {
      if ((param_2[3] == psVar1[3]) && (*(int *)(param_2 + 1) == *(int *)(psVar1 + 1))) {
        return 1;
      }
    }
    else if ((((param_2[0xe] == psVar1[0xe]) && (*(int *)(param_2 + 10) == *(int *)(psVar1 + 10)))
             && (*(int *)(param_2 + 0xc) == *(int *)(psVar1 + 0xc))) &&
            (auVar3[0] = -((char)psVar1[2] == (char)param_2[2]),
            auVar3[1] = -(*(char *)((longlong)psVar1 + 5) == *(char *)((longlong)param_2 + 5)),
            auVar3[2] = -((char)psVar1[3] == (char)param_2[3]),
            auVar3[3] = -(*(char *)((longlong)psVar1 + 7) == *(char *)((longlong)param_2 + 7)),
            auVar3[4] = -((char)psVar1[4] == (char)param_2[4]),
            auVar3[5] = -(*(char *)((longlong)psVar1 + 9) == *(char *)((longlong)param_2 + 9)),
            auVar3[6] = -((char)psVar1[5] == (char)param_2[5]),
            auVar3[7] = -(*(char *)((longlong)psVar1 + 0xb) == *(char *)((longlong)param_2 + 0xb)),
            auVar3[8] = -((char)psVar1[6] == (char)param_2[6]),
            auVar3[9] = -(*(char *)((longlong)psVar1 + 0xd) == *(char *)((longlong)param_2 + 0xd)),
            auVar3[10] = -((char)psVar1[7] == (char)param_2[7]),
            auVar3[0xb] = -(*(char *)((longlong)psVar1 + 0xf) == *(char *)((longlong)param_2 + 0xf))
            , auVar3[0xc] = -((char)psVar1[8] == (char)param_2[8]),
            auVar3[0xd] = -(*(char *)((longlong)psVar1 + 0x11) ==
                           *(char *)((longlong)param_2 + 0x11)),
            auVar3[0xe] = -((char)psVar1[9] == (char)param_2[9]),
            auVar3[0xf] = -(*(char *)((longlong)psVar1 + 0x13) ==
                           *(char *)((longlong)param_2 + 0x13)),
            (ushort)((ushort)(SUB161(auVar3 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar3 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar3 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar3 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar3 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar3 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar3 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar3 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar3 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar3 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar3 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar3 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar3 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar3 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar3 >> 0x77,0) & 1) << 0xe |
                    (ushort)(auVar3[0xf] >> 7) << 0xf) == 0xffff)) {
      return 1;
    }
  }
  *plVar2 = *plVar2 + 1;
  return 0;
}

