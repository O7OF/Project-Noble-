// rea decompile_all
// name: std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::net::watch_host,()>
// address: 0x140008900
// body: available
// range: 0x140008900-0x140008b5c inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140008acc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Unknown calling convention: __rustcall */
/* std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::net::watch_host,
   ()> */

void __rustcall
std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::
<host_probe[b94139f9089eb1d8]::net::watch_host,()>(void)

{
  code *pcVar1;
  longlong *plVar2;
  int iVar3;
  undefined *puVar4;
  byte bVar5;
  char cVar6;
  ulonglong uVar7;
  int iVar8;
  undefined8 uVar9;
  bool bVar10;
  longlong *local_80;
  undefined8 local_78;
  longlong *local_70;
  code *local_68;
  longlong local_60 [3];
  undefined8 local_48;
  undefined8 local_40;
  
  uVar9 = 0;
  std[3bf9d48a0c3997f0]::thread::functions::sleep(1);
  puVar4 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if (host_probe[b94139f9089eb1d8]::net::GAME_ENDED == '\0') {
    do {
      iVar8 = (int)uVar9;
      if ((host_probe[b94139f9089eb1d8]::net::HOST_ID_0_llvm_14435704873730135342 != 0) &&
         (host_probe[b94139f9089eb1d8]::net::IS_HOST_0_llvm_14435704873730135342 == '\0')) {
        local_60[0] = host_probe[b94139f9089eb1d8]::net::HOST_ID_0_llvm_14435704873730135342;
        LOCK();
        bVar10 = host_probe[b94139f9089eb1d8]::net::HOST_HEARD == '\0';
        if (bVar10) {
          host_probe[b94139f9089eb1d8]::net::HOST_HEARD = '\x01';
        }
        UNLOCK();
        if (bVar10) {
          if ((*(ulonglong *)puVar4 & 0x7fffffffffffffff) == 0) goto LAB_1400089a8;
LAB_140008a1d:
          bVar5 = panicking::panic_count::is_zero_slow_path();
          bVar5 = bVar5 ^ 1;
          plVar2 = DAT_140699518;
          iVar3 = DAT_140699520;
        }
        else {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                    (&host_probe[b94139f9089eb1d8]::net::HOST_HEARD);
          if ((*(ulonglong *)puVar4 & 0x7fffffffffffffff) != 0) goto LAB_140008a1d;
LAB_1400089a8:
          bVar5 = 0;
          plVar2 = DAT_140699518;
          iVar3 = DAT_140699520;
        }
        DAT_140699518 = plVar2;
        DAT_140699520 = iVar3;
        if (DAT_140699511 != '\0') {
          local_80 = (longlong *)&host_probe[b94139f9089eb1d8]::net::HOST_HEARD;
          uVar7 = (ulonglong)local_78 >> 8;
          local_78 = (code *)CONCAT71((int7)uVar7,bVar5);
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,&local_80,
                     &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
                     &
                     PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1ea8
                    );
                    /* WARNING: Does not return */
          pcVar1 = (code *)invalidInstructionException();
          (*pcVar1)();
        }
        if (((bVar5 == 0) && ((*(ulonglong *)puVar4 & 0x7fffffffffffffff) != 0)) &&
           (cVar6 = panicking::panic_count::is_zero_slow_path(), cVar6 == '\0')) {
          DAT_140699511 = '\x01';
        }
        cVar6 = host_probe[b94139f9089eb1d8]::net::HOST_HEARD;
        LOCK();
        host_probe[b94139f9089eb1d8]::net::HOST_HEARD = '\0';
        UNLOCK();
        if (cVar6 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake
                    (&host_probe[b94139f9089eb1d8]::net::HOST_HEARD);
        }
        if (iVar3 != -1) {
          uVar7 = (ulonglong)local_78 >> 0x20;
          local_78 = (code *)CONCAT44((int)uVar7,iVar3);
          local_80 = plVar2;
          uVar7 = <std[3bf9d48a0c3997f0]::time::Instant>::elapsed(&local_80);
          if (uVar7 == 0x1e) {
            if (iVar8 != 0) goto LAB_140008a5c;
          }
          else if (0x1e < uVar7) {
LAB_140008a5c:
            local_60[1] = 0x1e;
            local_80 = local_60;
            local_78 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
            local_70 = local_60 + 1;
            local_68 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
            alloc[246c2e7857c81348]::fmt::format::format_inner
                      (local_60 + 2,&DAT_1406a1ec0,&local_80);
            host_probe[b94139f9089eb1d8]::host::log(local_48,local_40);
            if (local_60[2] == 0) {
              uVar7 = std[3bf9d48a0c3997f0]::fs::write::inner
                                ("host-left.txt",0xd,"the host stopped answering",0x1a);
              if (((uVar7 != 0) && (1 < ((uint)uVar7 & 3) - 2)) && ((uVar7 & 3) != 0)) {
                local_78 = (code *)(uVar7 - 1);
                local_80 = (longlong *)CONCAT71(local_80._1_7_,3);
                <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                ::drop(&local_78);
              }
              host_probe[b94139f9089eb1d8]::win::LEAVE_REQUESTED = 1;
              return;
            }
            __rustc[9d087a5ab36ea756]::__rust_dealloc(local_48,local_60[2],1);
            return;
          }
        }
      }
      uVar9 = 0;
      std[3bf9d48a0c3997f0]::thread::functions::sleep(1);
    } while (host_probe[b94139f9089eb1d8]::net::GAME_ENDED == '\0');
  }
  return;
}

