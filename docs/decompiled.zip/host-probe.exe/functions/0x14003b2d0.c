// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::send_kick
// address: 0x14003b2d0
// body: available
// range: 0x14003b2d0-0x14003b43d inclusive
// range: 0x14003b43f-0x14003b45e inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003b439 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::send_kick */

void __rustcall
host_probe[b94139f9089eb1d8]::net::send_kick
          (undefined8 param_1,undefined8 param_2,undefined1 param_3)

{
  longlong lVar1;
  code *pcVar2;
  longlong *plVar3;
  size_t sVar4;
  longlong local_78;
  undefined8 *local_70;
  longlong local_68;
  undefined8 *local_60;
  undefined8 *local_58;
  longlong *local_50;
  longlong local_48;
  size_t local_40;
  undefined *local_38;
  undefined **local_30;
  
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  local_70 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(8,1);
  if (local_70 == (undefined8 *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(1,8);
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  local_78 = 8;
  *local_70 = param_2;
  local_68 = 0;
  local_48 = 0;
  local_40 = 8;
  local_50 = &local_78;
  local_38 = &DAT_1406a28c0;
  local_30 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a28c8;
  local_60 = local_70;
  local_58 = local_70;
  <alloc[246c2e7857c81348]::vec::splice::Splice<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<u8>>>as_core[505b25137b8ba7f]::ops::drop::Drop>
  ::drop(&local_60);
  sVar4 = local_40;
  plVar3 = local_50;
  if (local_40 != 0) {
    lVar1 = local_50[2];
    if (local_48 != lVar1) {
      memmove((void *)(local_50[1] + lVar1),(void *)(local_48 + local_50[1]),local_40);
    }
    plVar3[2] = lVar1 + sVar4;
  }
  lVar1 = local_68;
  if (local_68 == local_78) {
    <alloc[246c2e7857c81348]::raw_vec::RawVec<u8>>::grow_one(&local_78);
  }
  *(undefined1 *)((longlong)local_70 + lVar1) = param_3;
  local_68 = lVar1 + 1;
  send_route_kind(&TRANSPORT,param_1,local_70,local_68,1);
  send_route_kind(&TRANSPORT,param_1,local_70,local_68,1);
  send_route_kind(&TRANSPORT,param_1,local_70,local_68,1);
  if (local_78 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_70,local_78,1);
    return;
  }
  return;
}

