// rea decompile_all
// name: <std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>::or_try_insert_with::<<std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>::or_insert_with<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#2}>::{closure#0},!>
// address: 0x1400014c0
// body: available
// range: 0x1400014c0-0x14000162a inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,
   host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>::or_try_insert_with::<<std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,
   host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>::or_insert_with<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#2}>::{closure#0},
   !> */

undefined1 * __rustcall
<std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>
::or_try_insert_with::
<<std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>::or_insert_with<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_2_>::_closure_0_,_>
          (undefined8 *param_1,void *param_2,size_t param_3)

{
  undefined1 auVar1 [16];
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  undefined1 (*pauVar5) [16];
  ulonglong uVar6;
  code *pcVar7;
  ushort uVar8;
  void *_Dst;
  undefined1 (*pauVar9) [16];
  byte bVar10;
  uint uVar11;
  ulonglong uVar12;
  uint uVar13;
  longlong lVar14;
  byte bVar15;
  undefined8 uVar16;
  
  puVar2 = (undefined8 *)*param_1;
  if (puVar2 == (undefined8 *)0x0) {
    pauVar9 = (undefined1 (*) [16])param_1[1];
  }
  else {
    if ((longlong)param_3 < 0) {
      uVar16 = 0;
LAB_1400014e2:
      alloc[246c2e7857c81348]::raw_vec::handle_error(uVar16,param_3);
                    /* WARNING: Does not return */
      pcVar7 = (code *)invalidInstructionException();
      (*pcVar7)();
    }
    uVar3 = param_1[1];
    uVar4 = param_1[2];
    if (param_3 == 0) {
      _Dst = (void *)0x1;
    }
    else {
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar16 = 1;
      _Dst = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(param_3,1);
      if (_Dst == (void *)0x0) goto LAB_1400014e2;
      memcpy(_Dst,param_2,param_3);
    }
    pauVar5 = (undefined1 (*) [16])*puVar2;
    uVar6 = puVar2[1];
    uVar12 = uVar6 & uVar3;
    auVar1 = *(undefined1 (*) [16])(*pauVar5 + uVar12);
    uVar8 = (ushort)(SUB161(auVar1 >> 7,0) & 1) | (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
            (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
            (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
            (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
            (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
            (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
            (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
            (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
            (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
            (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
            (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
            (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
            (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
            (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe | (ushort)(byte)(auVar1[0xf] >> 7) << 0xf;
    uVar13 = (uint)uVar8;
    if (uVar8 == 0) {
      lVar14 = 0x10;
      do {
        uVar12 = uVar12 + lVar14 & uVar6;
        auVar1 = *(undefined1 (*) [16])(*pauVar5 + uVar12);
        lVar14 = lVar14 + 0x10;
        uVar13 = (uint)(ushort)((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                               (ushort)(byte)(auVar1[0xf] >> 7) << 0xf);
      } while (uVar13 == 0);
    }
    uVar11 = 0;
    for (; (uVar13 & 1) == 0; uVar13 = uVar13 >> 1 | 0x80000000) {
      uVar11 = uVar11 + 1;
    }
    uVar12 = uVar11 + uVar12 & uVar6;
    bVar10 = (*pauVar5)[uVar12];
    if (-1 < (char)bVar10) {
      auVar1 = *pauVar5;
      uVar13 = 0;
      for (uVar11 = (uint)(ushort)((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                                   (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                                   (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                                   (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                                   (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                                   (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                                   (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                                   (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                                   (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                                   (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                                   (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                                   (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                                   (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                                   (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                                   (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                                  (ushort)(byte)(auVar1[0xf] >> 7) << 0xf); (uVar11 & 1) == 0;
          uVar11 = uVar11 >> 1 | 0x80000000) {
        uVar13 = uVar13 + 1;
      }
      uVar12 = (ulonglong)uVar13;
      bVar10 = (*pauVar5)[uVar12];
    }
    bVar15 = (byte)(uVar3 >> 0x39);
    (*pauVar5)[uVar12] = bVar15;
    pauVar5[1][uVar12 - 0x10 & uVar6] = bVar15;
    pauVar9 = pauVar5 + uVar12 * -5;
    puVar2[2] = puVar2[2] - (ulonglong)(bVar10 & 1);
    *(undefined8 *)pauVar5[uVar12 * -5 + -5] = uVar4;
    *(size_t *)(pauVar5[uVar12 * -5 + -5] + 8) = param_3;
    *(void **)pauVar5[uVar12 * -5 + -4] = _Dst;
    *(size_t *)(pauVar5[uVar12 * -5 + -4] + 8) = param_3;
    *(undefined8 *)pauVar5[uVar12 * -5 + -3] = 0;
    *(undefined8 *)(pauVar5[uVar12 * -5 + -3] + 8) = 8;
    pauVar5[uVar12 * -5 + -2] = (undefined1  [16])0x0;
    *(undefined1 (*) [16])(pauVar5[uVar12 * -5 + -2] + 0xc) = (undefined1  [16])0x0;
    puVar2[3] = puVar2[3] + 1;
  }
  return pauVar9[-5] + 8;
}

