// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String),core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#0}>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
// address: 0x140048a40
// body: available
// range: 0x140048a40-0x140048b83 inclusive
// range: 0x140048b90-0x140048ce7 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,
   alloc[246c2e7857c81348]::string::String)> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(alloc[246c2e7857c81348]::string::String,
   alloc[246c2e7857c81348]::string::String),
   core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::vote::decode::{closure#0}>,
   core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>::from_iter
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String),core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#0}>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>
::from_iter(longlong *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined1 local_141;
  longlong local_140;
  longlong *plStack_138;
  longlong local_130;
  longlong local_128;
  undefined4 local_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 local_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  longlong local_100;
  longlong local_d8;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  longlong local_a8;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  longlong local_78;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  
  <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::try_fold::
  <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::decode::_closure_0_>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String),core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>>>
            (&local_128,param_2,&local_141,*(undefined8 *)(param_2 + 6));
  lVar6 = local_128;
  if ((local_128 == -2) || (local_d8 = local_100, local_128 == -1)) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
    return param_1;
  }
  local_a8 = local_100;
  local_b8 = local_110;
  uStack_b4 = uStack_10c;
  uStack_b0 = uStack_108;
  uStack_ac = uStack_104;
  local_c8 = local_120;
  uStack_c4 = uStack_11c;
  uStack_c0 = uStack_118;
  uStack_bc = uStack_114;
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  plVar5 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0xc0,8);
  if (plVar5 == (longlong *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(8,0xc0);
                    /* WARNING: Does not return */
    pcVar2 = (code *)invalidInstructionException();
    (*pcVar2)();
  }
  *plVar5 = lVar6;
  plVar5[1] = CONCAT44(uStack_c4,local_c8);
  plVar5[2] = CONCAT44(uStack_bc,uStack_c0);
  plVar5[3] = CONCAT44(uStack_b4,local_b8);
  plVar5[4] = CONCAT44(uStack_ac,uStack_b0);
  plVar5[5] = local_a8;
  local_140 = 4;
  local_130 = 1;
  local_68 = *param_2;
  uStack_64 = param_2[1];
  uStack_60 = param_2[2];
  uStack_5c = param_2[3];
  local_58 = param_2[4];
  uStack_54 = param_2[5];
  uStack_50 = param_2[6];
  uStack_4c = param_2[7];
  lVar6 = 0x38;
  plStack_138 = plVar5;
  while (lVar3 = local_130,
        <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::decode::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
        ::try_fold::
        <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::vote::decode::_closure_0_>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String),core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>>>
                  (&local_128,&local_68,&local_141,CONCAT44(uStack_4c,uStack_50)), lVar4 = local_128
        , local_128 != -2) {
    local_d8 = local_100;
    if (local_128 == -1) break;
    local_78 = local_100;
    local_98 = local_120;
    uStack_94 = uStack_11c;
    uStack_90 = uStack_118;
    uStack_8c = uStack_114;
    local_88 = local_110;
    uStack_84 = uStack_10c;
    uStack_80 = uStack_108;
    uStack_7c = uStack_104;
    if (lVar3 == local_140) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_140,lVar3,1,8,0x30);
      plVar5 = plStack_138;
    }
    *(longlong *)((longlong)plVar5 + lVar6 + -8) = lVar4;
    puVar1 = (undefined4 *)((longlong)plVar5 + lVar6);
    *puVar1 = local_98;
    puVar1[1] = uStack_94;
    puVar1[2] = uStack_90;
    puVar1[3] = uStack_8c;
    puVar1 = (undefined4 *)((longlong)plVar5 + lVar6 + 0x10);
    *puVar1 = local_88;
    puVar1[1] = uStack_84;
    puVar1[2] = uStack_80;
    puVar1[3] = uStack_7c;
    *(longlong *)((longlong)plVar5 + lVar6 + 0x20) = local_78;
    local_130 = lVar3 + 1;
    lVar6 = lVar6 + 0x30;
  }
  param_1[2] = local_130;
  *param_1 = local_140;
  param_1[1] = (longlong)plStack_138;
  return param_1;
}

