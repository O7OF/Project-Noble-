// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::vec::Vec<u8>,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,[core[505b25137b8ba7f]::option::Option<[f32;3usize]>;21usize]>>,host_probe[b94139f9089eb1d8]::host::looks::message3::{closure#0}>>>::from_iter
// address: 0x14004a0a0
// body: available
// range: 0x14004a0a0-0x14004a1e0 inclusive
// range: 0x14004a1f0-0x14004a2a1 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::vec::Vec<u8>,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,
   [core[505b25137b8ba7f]::option::Option<[f32; 3usize]>; 21usize]>>,
   host_probe[b94139f9089eb1d8]::host::looks::message3::{closure#0}>>>::from_iter */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::vec::Vec<u8>,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,[core[505b25137b8ba7f]::option::Option<[f32;3usize]>;21usize]>>,host_probe[b94139f9089eb1d8]::host::looks::message3::{closure#0}>>>
::from_iter(ulonglong *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  ulonglong uVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  undefined8 uVar8;
  ulonglong local_c8;
  longlong *plStack_c0;
  ulonglong local_b8;
  ulonglong *local_b0;
  longlong local_a8;
  longlong lStack_a0;
  longlong local_98;
  undefined4 local_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 local_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 local_68;
  undefined8 uStack_60;
  ulonglong local_58;
  ulonglong uStack_50;
  
  <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,[core[505b25137b8ba7f]::option::Option<[f32;3usize]>;21usize]>>,host_probe[b94139f9089eb1d8]::host::looks::message3::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::next(&local_a8);
  if (local_a8 == -1) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
    local_b0 = param_1;
  }
  else {
    uVar3 = *(ulonglong *)(param_2 + 8);
    if (*(ulonglong *)(param_2 + 10) < *(ulonglong *)(param_2 + 8)) {
      uVar3 = *(ulonglong *)(param_2 + 10);
    }
    uVar5 = 0xffffffffffffffff;
    if (uVar3 + 1 != 0) {
      uVar5 = uVar3 + 1;
    }
    uVar3 = 4;
    if (4 < uVar5) {
      uVar3 = uVar5;
    }
    lVar6 = uVar3 * 0x18;
    if (0x555555555555555 < uVar5) {
      uVar8 = 0;
LAB_14004a11b:
      alloc[246c2e7857c81348]::raw_vec::handle_error(uVar8,lVar6);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    if (lVar6 == 0) {
      plVar4 = (longlong *)&DAT_00000008;
      uVar3 = 0;
      local_b0 = param_1;
    }
    else {
      local_b0 = param_1;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar8 = 8;
      plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(lVar6,8);
      if (plVar4 == (longlong *)0x0) goto LAB_14004a11b;
    }
    plVar4[2] = local_98;
    *plVar4 = local_a8;
    plVar4[1] = lStack_a0;
    local_b8 = 1;
    local_78 = *param_2;
    uStack_74 = param_2[1];
    uStack_70 = param_2[2];
    uStack_6c = param_2[3];
    local_68 = *(undefined8 *)(param_2 + 4);
    uStack_60 = *(undefined8 *)(param_2 + 6);
    local_58 = *(ulonglong *)(param_2 + 8);
    uStack_50 = *(ulonglong *)(param_2 + 10);
    lVar6 = 0;
    local_c8 = uVar3;
    plStack_c0 = plVar4;
    while (uVar3 = local_b8,
          <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::take::Take<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,[core[505b25137b8ba7f]::option::Option<[f32;3usize]>;21usize]>>,host_probe[b94139f9089eb1d8]::host::looks::message3::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
          ::next(&local_90,&local_78), CONCAT44(uStack_8c,local_90) != -1) {
      if (uVar3 == local_c8) {
        uVar5 = local_58;
        if (uStack_50 < local_58) {
          uVar5 = uStack_50;
        }
        lVar7 = uVar5 + 1;
        if (lVar7 == 0) {
          lVar7 = -1;
        }
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_c8,uVar3,lVar7,8,0x18);
        plVar4 = plStack_c0;
      }
      *(undefined8 *)(lVar6 + 0x28 + (longlong)plVar4) = local_80;
      puVar1 = (undefined4 *)(lVar6 + 0x18 + (longlong)plVar4);
      *puVar1 = local_90;
      puVar1[1] = uStack_8c;
      puVar1[2] = uStack_88;
      puVar1[3] = uStack_84;
      local_b8 = uVar3 + 1;
      lVar6 = lVar6 + 0x18;
    }
    local_b0[2] = local_b8;
    *local_b0 = local_c8;
    local_b0[1] = (ulonglong)plStack_c0;
  }
  return local_b0;
}

