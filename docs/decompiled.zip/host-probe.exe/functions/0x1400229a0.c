// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::is_blocked
// address: 0x1400229a0
// body: available
// range: 0x1400229a0-0x140022a12 inclusive
// range: 0x140022a20-0x140022b1d inclusive
// range: 0x140022b20-0x140022b61 inclusive
// range: 0x140022b70-0x140022f41 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::is_blocked */

ulonglong __rustcall
host_probe[b94139f9089eb1d8]::net::is_blocked(ulonglong param_1,ushort *param_2)

{
  uint *puVar1;
  ushort uVar2;
  uint uVar3;
  ulonglong uVar4;
  code *pcVar5;
  uint uVar6;
  uint uVar7;
  bool bVar8;
  undefined *puVar9;
  byte bVar10;
  char cVar11;
  byte bVar12;
  uint uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  ushort *puVar16;
  longlong lVar17;
  undefined7 uVar18;
  undefined2 uVar19;
  uint *puVar20;
  ulonglong uVar21;
  longlong lVar22;
  bool bVar23;
  undefined1 *local_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined1 local_68;
  undefined1 local_62;
  undefined2 local_61;
  undefined2 uStack_5f;
  undefined4 uStack_5d;
  undefined2 uStack_59;
  undefined6 uStack_57;
  undefined1 local_51 [8];
  undefined4 uStack_49;
  undefined4 uStack_45;
  undefined1 local_41;
  
  puVar16 = param_2;
  uVar14 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  uVar13 = (uint)puVar16;
  LOCK();
  bVar23 = BLOCKED == '\0';
  if (bVar23) {
    BLOCKED = '\x01';
  }
  UNLOCK();
  if (!bVar23) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended();
  }
  puVar9 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar10 = 0;
    lVar17 = DAT_140699780;
  }
  else {
    bVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar10 = bVar10 ^ 1;
    lVar17 = DAT_140699780;
  }
  DAT_140699780 = lVar17;
  if (DAT_140699771 != '\0') {
    local_78 = &BLOCKED;
    uStack_70._1_3_ = (undefined3)((uint)uStack_70 >> 8);
    uStack_70 = CONCAT31(uStack_70._1_3_,bVar10);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_78,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1050
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1e60);
    goto LAB_140022f16;
  }
  uVar4 = DAT_140699788;
  if (DAT_140699788 == 0) {
    uVar21 = 0;
  }
  else {
    puVar20 = (uint *)(lVar17 + 0x28);
    uVar15 = 0;
    do {
      uVar3 = puVar20[-6];
      if (uVar3 != 0xffffffff) {
        uVar21 = *(ulonglong *)(puVar20 + -8);
        bVar23 = uVar21 < uVar14;
        if (uVar21 == uVar14) {
          bVar23 = uVar3 < uVar13;
        }
        if (bVar23 || uVar21 == uVar14 && uVar3 == uVar13) {
          uVar21 = uVar15;
          uVar4 = uVar15;
          if (uVar15 + 1 < DAT_140699788) {
            lVar22 = ~uVar15 + DAT_140699788;
            goto LAB_140022d47;
          }
          break;
        }
      }
      uVar15 = uVar15 + 1;
      puVar20 = puVar20 + 6;
      uVar21 = DAT_140699788;
    } while (DAT_140699788 != uVar15);
  }
  goto joined_r0x000140022d7b;
LAB_140022b87:
  bVar8 = true;
  bVar23 = true;
  goto joined_r0x000140022b8c;
LAB_140022d47:
  do {
    uVar3 = *puVar20;
    if (uVar3 == 0xffffffff) {
LAB_140022d21:
      *(undefined8 *)(lVar17 + 0x10 + uVar15 * 0x18) = *(undefined8 *)puVar20;
      uVar3 = puVar20[-3];
      uVar6 = puVar20[-2];
      uVar7 = puVar20[-1];
      puVar1 = (uint *)(lVar17 + uVar15 * 0x18);
      *puVar1 = puVar20[-4];
      puVar1[1] = uVar3;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      uVar15 = uVar15 + 1;
    }
    else {
      uVar4 = *(ulonglong *)(puVar20 + -2);
      bVar23 = uVar4 < uVar14;
      if (uVar4 == uVar14) {
        bVar23 = uVar3 < uVar13;
      }
      if (!bVar23 && (uVar4 != uVar14 || uVar3 != uVar13)) goto LAB_140022d21;
    }
    puVar20 = puVar20 + 6;
    lVar22 = lVar22 + -1;
    uVar21 = uVar15;
    uVar4 = uVar15;
  } while (lVar22 != 0);
joined_r0x000140022d7b:
  DAT_140699788 = uVar4;
  if (uVar21 != 0) {
    lVar17 = 0;
    do {
      if (*(ulonglong *)(DAT_140699780 + lVar17) == param_1) {
        uVar14 = CONCAT71((int7)(param_1 >> 8),1);
        goto LAB_140022cd8;
      }
      lVar17 = lVar17 + 0x18;
    } while (uVar21 * 0x18 != lVar17);
  }
  uVar2 = *param_2;
  if (uVar2 == 2) {
    uVar14 = 0;
    goto LAB_140022cd8;
  }
  uVar13 = *(uint *)(param_2 + 1);
  LOCK();
  bVar23 = BANNED_IPS == '\0';
  if (bVar23) {
    BANNED_IPS = '\x01';
  }
  UNLOCK();
  if (!bVar23) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&BANNED_IPS);
  }
  if ((*(ulonglong *)puVar9 & 0x7fffffffffffffff) == 0) {
    bVar12 = 0;
  }
  else {
    bVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar12 = bVar12 ^ 1;
  }
  if (DAT_1406994f1 != '\0') {
    local_78 = &BANNED_IPS;
    uStack_70._1_3_ = (undefined3)((uint)uStack_70 >> 8);
    uStack_70 = CONCAT31(uStack_70._1_3_,bVar12);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_78,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1010
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a06d8);
LAB_140022f16:
                    /* WARNING: Does not return */
    pcVar5 = (code *)invalidInstructionException();
    (*pcVar5)();
  }
  if (uVar2 == 1) {
    if (DAT_140699508 != 0) {
      uVar14 = *(ulonglong *)(param_2 + 3);
      lVar17 = 0;
      do {
        if ((*(char *)(DAT_140699500 + lVar17) != '\0') &&
           (param_1 = *(ulonglong *)(DAT_140699500 + 9 + lVar17) ^
                      ((ulonglong)*(uint6 *)(param_2 + 7) << 0x10 | uVar14 >> 0x30) |
                      *(ulonglong *)(DAT_140699500 + 1 + lVar17) ^
                      (uVar14 << 0x10 | (ulonglong)(uVar13 >> 0x10)), param_1 == 0))
        goto LAB_140022b87;
        lVar17 = lVar17 + 0x11;
      } while (DAT_140699508 * 0x11 != lVar17);
    }
  }
  else if (DAT_140699508 != 0) {
    lVar17 = 0;
    do {
      if ((*(char *)(DAT_140699500 + lVar17) == '\0') &&
         (*(uint *)(DAT_140699500 + 1 + lVar17) == uVar13)) goto LAB_140022b87;
      lVar17 = lVar17 + 0x11;
    } while (DAT_140699508 * 0x11 != lVar17);
  }
  bVar8 = false;
  bVar23 = false;
joined_r0x000140022b8c:
  if (((bVar12 == 0) && (bVar23 = bVar8, (*(ulonglong *)puVar9 & 0x7fffffffffffffff) != 0)) &&
     (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0'))
  {
    DAT_1406994f1 = '\x01';
  }
  cVar11 = BANNED_IPS;
  LOCK();
  BANNED_IPS = '\0';
  UNLOCK();
  if (cVar11 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&BANNED_IPS);
  }
  uVar18 = (undefined7)(param_1 >> 8);
  uVar14 = CONCAT71(uVar18,1);
  if (bVar23) goto LAB_140022cd8;
  bVar23 = (uVar2 & 1) == 0;
  uVar19 = (undefined2)(uVar13 >> 0x10);
  if (bVar23) {
    local_61 = (undefined2)uVar13;
    uStack_5f = uVar19;
  }
  else {
    uVar14 = *(ulonglong *)(param_2 + 3);
    uStack_57 = (undefined6)((ulonglong)*(undefined8 *)(param_2 + 6) >> 0x10);
    uStack_5f = (undefined2)uVar14;
    uStack_5d = (undefined4)(uVar14 >> 0x10);
    uStack_59 = (undefined2)(uVar14 >> 0x30);
    local_61 = uVar19;
  }
  local_62 = !bVar23;
  reach_directory[4b72b9694f6c3c08]::server_admin::bans::canonical_ip(local_51,&local_62);
  LOCK();
  bVar23 = SAVED_IPS == '\0';
  if (bVar23) {
    SAVED_IPS = '\x01';
  }
  UNLOCK();
  if (!bVar23) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&SAVED_IPS);
  }
  if ((*(ulonglong *)puVar9 & 0x7fffffffffffffff) == 0) {
    bVar12 = 0;
  }
  else {
    bVar12 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar12 = bVar12 ^ 1;
  }
  if (DAT_1406997e1 != '\0') {
    local_78 = &SAVED_IPS;
    uStack_70._1_3_ = (undefined3)((uint)uStack_70 >> 8);
    uStack_70 = CONCAT31(uStack_70._1_3_,bVar12);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_78,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0f90
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a31b8);
    goto LAB_140022f16;
  }
  if (DAT_140699818 == -1) {
joined_r0x000140022cb0:
    uVar14 = 0;
  }
  else {
    cVar11 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<core[505b25137b8ba7f]::net::ip_addr::IpAddr,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
             ::contains_key::<core[505b25137b8ba7f]::net::ip_addr::IpAddr>(&DAT_1406997e8,local_51);
    uVar14 = CONCAT71(uVar18,1);
    if (cVar11 == '\0') {
      if (DAT_140699828 == 0) goto joined_r0x000140022cb0;
      lVar17 = DAT_140699828 * 0x12;
      lVar22 = DAT_140699820;
      do {
        lVar17 = lVar17 + -0x12;
        local_68 = local_41;
        uStack_70 = uStack_49;
        uStack_6c = uStack_45;
        uVar13 = <reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>::contains
                           (lVar22,&local_78);
        uVar14 = (ulonglong)uVar13;
        lVar22 = lVar22 + 0x12;
      } while ((byte)(lVar17 == 0 | (byte)uVar13) != 1);
    }
  }
  if (((bVar12 == 0) && ((*(ulonglong *)puVar9 & 0x7fffffffffffffff) != 0)) &&
     (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0'))
  {
    DAT_1406997e1 = '\x01';
  }
  cVar11 = SAVED_IPS;
  LOCK();
  SAVED_IPS = '\0';
  UNLOCK();
  if (cVar11 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&SAVED_IPS);
  }
LAB_140022cd8:
  if (((bVar10 == 0) && ((*(ulonglong *)puVar9 & 0x7fffffffffffffff) != 0)) &&
     (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0'))
  {
    DAT_140699771 = '\x01';
  }
  cVar11 = BLOCKED;
  LOCK();
  BLOCKED = 0;
  UNLOCK();
  if (cVar11 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&BLOCKED);
  }
  return uVar14 & 0xffffffff;
}

