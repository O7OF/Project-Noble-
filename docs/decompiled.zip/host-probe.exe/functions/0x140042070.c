// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::retain::<host_probe[b94139f9089eb1d8]::live::poll::{closure#27}>
// address: 0x140042070
// body: available
// range: 0x140042070-0x1400420ce inclusive
// range: 0x1400420d0-0x1400420e5 inclusive
// range: 0x1400420f0-0x140042132 inclusive
// range: 0x140042140-0x140042277 inclusive
// range: 0x140042280-0x1400422c2 inclusive
// range: 0x1400422d0-0x1400423d0 inclusive
// range: 0x1400423d3-0x1400423db inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14004222f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400423cc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Removing unreachable block (ram,0x0001400421f8) */
/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::retain::<host_probe[b94139f9089eb1d8]::live::poll::{closure#27}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::retain::
<host_probe[b94139f9089eb1d8]::live::poll::_closure_27_>(longlong param_1)

{
  longlong *plVar1;
  undefined4 *puVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong *puVar5;
  longlong lVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  ushort uVar9;
  int iVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  ulonglong local_50;
  ulonglong local_48;
  
  uVar3 = *(ulonglong *)(param_1 + 0x10);
  if (uVar3 == 0) {
    return;
  }
  lVar4 = *(longlong *)(param_1 + 8);
  uVar17 = 0;
  local_50 = 0x7061642e6c61796f;
  do {
    plVar1 = (longlong *)(lVar4 + uVar17 * 0x18);
    puVar5 = *(ulonglong **)(lVar4 + 8 + uVar17 * 0x18);
    uVar16 = *(ulonglong *)(lVar4 + 0x10 + uVar17 * 0x18);
    uVar11 = 0;
    do {
      uVar13 = uVar11 + (longlong)puVar5;
      if (uVar16 - uVar11 < 0x10) {
        if (uVar16 == uVar11) break;
        uVar14 = 0;
        while (*(char *)(uVar13 + uVar14) != '=') {
          uVar14 = uVar14 + 1;
          if (uVar16 - uVar11 == uVar14) goto LAB_140042200;
        }
      }
      else {
        uVar15 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(0x3d);
        uVar14 = uVar13;
        if ((uVar15 & 1) == 0) break;
      }
      uVar13 = uVar14 + uVar11;
      if ((uVar13 < uVar16) && (*(char *)((longlong)puVar5 + uVar13) == '=')) {
        if ((uVar13 < 8) || (*puVar5 != 0x2e70616d2e646170)) {
          if (uVar13 == 10) {
            uVar16 = *puVar5;
            uVar11 = uVar16 >> 0x38 | (uVar16 & 0xff000000000000) >> 0x28 |
                     (uVar16 & 0xff0000000000) >> 0x18 | (uVar16 & 0xff00000000) >> 8 |
                     (uVar16 & 0xff000000) << 8 | (uVar16 & 0xff0000) << 0x18 |
                     (uVar16 & 0xff00) << 0x28 | uVar16 << 0x38;
            uVar16 = local_50;
            if (uVar11 == 0x7061642e6c61796f) {
              uVar9 = (ushort)puVar5[1] << 8 | (ushort)puVar5[1] >> 8;
              uVar11 = (ulonglong)uVar9;
              if (uVar9 == 0x7574) goto LAB_14004221d;
              uVar16 = 0x7574;
            }
          }
          else {
            if (uVar13 != 0xb) break;
            uVar16 = *puVar5;
            uVar11 = uVar16 >> 0x38 | (uVar16 & 0xff000000000000) >> 0x28 |
                     (uVar16 & 0xff0000000000) >> 0x18 | (uVar16 & 0xff00000000) >> 8 |
                     (uVar16 & 0xff000000) << 8 | (uVar16 & 0xff0000) << 0x18 |
                     (uVar16 & 0xff00) << 0x28 | uVar16 << 0x38;
            uVar16 = 0x7061642e62756d70;
            if (uVar11 == 0x7061642e62756d70) {
              uVar16 = *(ulonglong *)((longlong)puVar5 + 3);
              uVar11 = uVar16 >> 0x38 | (uVar16 & 0xff000000000000) >> 0x28 |
                       (uVar16 & 0xff0000000000) >> 0x18 | (uVar16 & 0xff00000000) >> 8 |
                       (uVar16 & 0xff000000) << 8 | (uVar16 & 0xff0000) << 0x18 |
                       (uVar16 & 0xff00) << 0x28 | uVar16 << 0x38;
              uVar16 = 0x2e62756d70657273;
              if (uVar11 == 0x2e62756d70657273) goto LAB_14004221d;
            }
          }
          if ((char)((uVar16 <= uVar11) * '\x02') != '\x01') break;
        }
LAB_14004221d:
        lVar6 = *plVar1;
        if (lVar6 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar1[1],lVar6,1);
          return;
        }
        uVar16 = uVar17 + 1;
        if (uVar3 <= uVar16) goto LAB_1400423d3;
        local_48 = 0x7061642e6c61796f;
        goto LAB_140042256;
      }
      uVar11 = uVar11 + uVar14 + 1;
    } while (uVar11 <= uVar16);
LAB_140042200:
    uVar17 = uVar17 + 1;
    if (uVar17 == uVar3) {
      return;
    }
  } while( true );
LAB_140042256:
  plVar1 = (longlong *)(lVar4 + uVar16 * 0x18);
  puVar5 = *(ulonglong **)(lVar4 + 8 + uVar16 * 0x18);
  uVar11 = *(ulonglong *)(lVar4 + 0x10 + uVar16 * 0x18);
  uVar13 = 0;
  do {
    uVar14 = (longlong)puVar5 + uVar13;
    if (uVar11 - uVar13 < 0x10) {
      if (uVar11 == uVar13) break;
      uVar15 = 0;
      while (*(char *)(uVar14 + uVar15) != '=') {
        uVar15 = uVar15 + 1;
        if (uVar11 - uVar13 == uVar15) goto LAB_14004238a;
      }
    }
    else {
      uVar12 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(0x3d);
      uVar15 = uVar14;
      if ((uVar12 & 1) == 0) break;
    }
    uVar14 = uVar15 + uVar13;
    if ((uVar14 < uVar11) && (*(char *)((longlong)puVar5 + uVar14) == '=')) {
      if ((uVar14 < 8) || (*puVar5 != 0x2e70616d2e646170)) {
        if (uVar14 == 10) {
          uVar11 = *puVar5;
          uVar13 = uVar11 >> 0x38 | (uVar11 & 0xff000000000000) >> 0x28 |
                   (uVar11 & 0xff0000000000) >> 0x18 | (uVar11 & 0xff00000000) >> 8 |
                   (uVar11 & 0xff000000) << 8 | (uVar11 & 0xff0000) << 0x18 |
                   (uVar11 & 0xff00) << 0x28 | uVar11 << 0x38;
          uVar11 = local_48;
          if (uVar13 == 0x7061642e6c61796f) {
            uVar9 = (ushort)puVar5[1] << 8 | (ushort)puVar5[1] >> 8;
            uVar13 = (ulonglong)uVar9;
            if (uVar9 == 0x7574) goto LAB_14004236e;
            uVar11 = 0x7574;
          }
LAB_140042377:
          iVar10 = (uint)(uVar11 <= uVar13) * 2 + -1;
        }
        else {
          if (uVar14 != 0xb) break;
          uVar11 = *puVar5;
          uVar13 = uVar11 >> 0x38 | (uVar11 & 0xff000000000000) >> 0x28 |
                   (uVar11 & 0xff0000000000) >> 0x18 | (uVar11 & 0xff00000000) >> 8 |
                   (uVar11 & 0xff000000) << 8 | (uVar11 & 0xff0000) << 0x18 |
                   (uVar11 & 0xff00) << 0x28 | uVar11 << 0x38;
          uVar11 = 0x7061642e62756d70;
          if (uVar13 != 0x7061642e62756d70) goto LAB_140042377;
          uVar11 = *(ulonglong *)((longlong)puVar5 + 3);
          uVar13 = uVar11 >> 0x38 | (uVar11 & 0xff000000000000) >> 0x28 |
                   (uVar11 & 0xff0000000000) >> 0x18 | (uVar11 & 0xff00000000) >> 8 |
                   (uVar11 & 0xff000000) << 8 | (uVar11 & 0xff0000) << 0x18 |
                   (uVar11 & 0xff00) << 0x28 | uVar11 << 0x38;
          uVar11 = 0x2e62756d70657273;
          if (uVar13 != 0x2e62756d70657273) goto LAB_140042377;
LAB_14004236e:
          iVar10 = 0;
        }
        if (iVar10 != 0) break;
      }
      if (*plVar1 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar1[1],*plVar1,1);
        return;
      }
      goto LAB_1400423a7;
    }
    uVar13 = uVar13 + uVar15 + 1;
  } while (uVar13 <= uVar11);
LAB_14004238a:
  *(longlong *)(lVar4 + 0x10 + uVar17 * 0x18) = plVar1[2];
  uVar7 = *(undefined4 *)((longlong)plVar1 + 4);
  lVar6 = plVar1[1];
  uVar8 = *(undefined4 *)((longlong)plVar1 + 0xc);
  puVar2 = (undefined4 *)(lVar4 + uVar17 * 0x18);
  *puVar2 = (int)*plVar1;
  puVar2[1] = uVar7;
  puVar2[2] = (int)lVar6;
  puVar2[3] = uVar8;
  uVar17 = uVar17 + 1;
LAB_1400423a7:
  uVar16 = uVar16 + 1;
  if (uVar16 == uVar3) {
LAB_1400423d3:
    *(ulonglong *)(param_1 + 0x10) = uVar17;
    return;
  }
  goto LAB_140042256;
}

