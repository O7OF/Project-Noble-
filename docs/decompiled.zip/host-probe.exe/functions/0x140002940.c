// rea decompile_all
// name: <[usize;2usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<bool>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<bool>>::wrap_mut_1<usize,host_probe[b94139f9089eb1d8]::pad::camera_pressed::{closure#0}>::{closure#0}>
// address: 0x140002940
// body: available
// range: 0x140002940-0x1400029be inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <[usize; 2usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<bool>,
   <core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<bool>>::wrap_mut_1<usize,
   host_probe[b94139f9089eb1d8]::pad::camera_pressed::{closure#0}>::{closure#0}> */

undefined2 __rustcall
<[usize;2usize]>::try_map::
<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<bool>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<bool>>::wrap_mut_1<usize,host_probe[b94139f9089eb1d8]::pad::camera_pressed::_closure_0_>::_closure_0_>
          (ulonglong *param_1,uint *param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  code *pcVar3;
  
  uVar1 = *param_1;
  if (1 < uVar1) {
    core[505b25137b8ba7f]::panicking::panic_bounds_check
              (uVar1,2,&anon_db112111b7c3e74b8e7e3f11be929c98_10_llvm_10439611301029776152);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  uVar2 = param_1[1];
  if (uVar2 < 2) {
    return CONCAT11((~*param_2 & (&host_probe[b94139f9089eb1d8]::pad::CAMERA_BUTTONS)[uVar2]) == 0
                    && (&host_probe[b94139f9089eb1d8]::pad::CAMERA_BUTTONS)[uVar2] != 0,
                    (~*param_2 & (&host_probe[b94139f9089eb1d8]::pad::CAMERA_BUTTONS)[uVar1]) == 0
                    && (&host_probe[b94139f9089eb1d8]::pad::CAMERA_BUTTONS)[uVar1] != 0);
  }
  core[505b25137b8ba7f]::panicking::panic_bounds_check
            (uVar2,2,&anon_db112111b7c3e74b8e7e3f11be929c98_10_llvm_10439611301029776152);
                    /* WARNING: Does not return */
  pcVar3 = (code *)invalidInstructionException();
  (*pcVar3)();
}

