// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive
// address: 0x140010c60
// body: available
// range: 0x140010c60-0x14001337a inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14001208a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140012b8f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140012ef2 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140012f8a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive
          (undefined8 *param_1,longlong *param_2,longlong param_3,longlong *param_4,
          ulonglong param_5,longlong param_6,int param_7)

{
  undefined8 *puVar1;
  code *pcVar2;
  void *_Dst;
  bool bVar3;
  longlong *plVar4;
  uint uVar5;
  byte bVar6;
  char cVar7;
  int iVar8;
  char *pcVar9;
  longlong *plVar10;
  undefined *puVar11;
  longlong *plVar12;
  ulonglong uVar13;
  undefined7 uVar20;
  ulonglong uVar14;
  longlong *plVar15;
  void *pvVar16;
  longlong *plVar17;
  longlong *plVar18;
  longlong lVar19;
  ulonglong uVar21;
  size_t _Size;
  longlong lVar22;
  undefined8 uVar23;
  undefined **ppuVar24;
  undefined8 uVar25;
  bool bVar26;
  undefined8 local_248;
  longlong *plStack_240;
  undefined8 local_238;
  undefined8 local_230;
  byte local_228;
  byte bStack_227;
  undefined2 uStack_226;
  uint uStack_224;
  undefined8 uStack_220;
  undefined8 uStack_218;
  undefined8 uStack_210;
  undefined4 local_208;
  undefined4 uStack_204;
  undefined4 uStack_200;
  undefined4 uStack_1fc;
  undefined4 local_1f8;
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined4 uStack_1ec;
  undefined8 local_1e8;
  undefined8 uStack_1e0;
  undefined8 local_1d8;
  undefined8 uStack_1d0;
  undefined8 local_1c8;
  undefined8 uStack_1c0;
  undefined8 local_1b0;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  longlong *local_1a0;
  undefined8 local_198;
  undefined8 uStack_190;
  undefined8 local_188;
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined4 local_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 local_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined8 local_158;
  undefined8 uStack_150;
  undefined8 local_148;
  undefined8 uStack_140;
  undefined8 local_138;
  undefined8 uStack_130;
  longlong *local_128;
  byte local_120;
  undefined4 uStack_11f;
  undefined4 uStack_11b;
  undefined4 uStack_117;
  undefined4 uStack_113;
  undefined3 uStack_10f;
  uint uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  longlong *local_100;
  longlong *local_f8;
  longlong local_f0;
  longlong local_e8;
  int local_e0;
  void *local_d8;
  longlong *local_d0;
  void *local_c8;
  size_t local_c0;
  undefined4 local_b8;
  uint uStack_b4;
  uint uStack_b0;
  uint uStack_ac;
  undefined8 local_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  
  local_e8 = param_6;
  local_e0 = param_7;
  if (((0x578 < param_5) || (param_5 < 8)) || (*param_4 != 0x32544148432d5252)) {
LAB_140010cc1:
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
    return;
  }
  uStack_190 = (longlong *)(param_5 - 8);
  local_198 = param_4 + 1;
  local_188 = (longlong *)0x0;
  local_f0 = param_3;
  serde_json[7404bcab4dc139c7]::de::from_trait::
  <serde_json[7404bcab4dc139c7]::read::SliceRead,serde_json[7404bcab4dc139c7]::value::Value>
            (&local_228,&local_198);
  if (local_228 == 0xff) {
    core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::error::Error>(&uStack_220)
    ;
    goto LAB_140010cc1;
  }
  uStack_11f = CONCAT13((undefined1)uStack_224,CONCAT21(uStack_226,bStack_227));
  uStack_11b = CONCAT13((undefined1)uStack_220,uStack_224._1_3_);
  uStack_117 = CONCAT13(uStack_220._4_1_,uStack_220._1_3_);
  uStack_113 = CONCAT13((undefined1)uStack_218,uStack_220._5_3_);
  uStack_10f = (undefined3)((uint)(undefined4)uStack_218 >> 8);
  uStack_10c = uStack_218._4_4_;
  uStack_108 = (undefined4)uStack_210;
  uStack_104 = uStack_210._4_4_;
  local_120 = local_228;
  pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                             ("nonce",5,&local_120);
  if (pcVar9 == (char *)0x0) {
    pcVar9 = 
    __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
    ;
  }
  uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
  uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
  if ((*pcVar9 == '\x03') &&
     (plVar15 = *(longlong **)(pcVar9 + 0x18),
     uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
     uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
     (longlong)plVar15 - 1U < 0x60)) {
    pvVar16 = *(void **)(pcVar9 + 0x10);
    if (plVar15 != (longlong *)0x0) {
      plVar10 = (longlong *)0x0;
      do {
        bVar6 = *(byte *)((longlong)pvVar16 + (longlong)plVar10);
        bVar26 = (byte)(bVar6 - 0x3a) < 0xf6;
        if (0x40 < bVar6) {
          bVar26 = 0x5a < bVar6;
        }
        bVar3 = 0x7a < bVar6;
        if (bVar6 < 0x61) {
          bVar3 = bVar26;
        }
        if ((bVar6 != 0x2d) &&
           (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
           uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220), bVar3))
        goto LAB_140012a76;
        plVar10 = (longlong *)((longlong)plVar10 + 1);
      } while (plVar15 != plVar10);
    }
    local_d8 = pvVar16;
    local_d0 = plVar15;
    if (param_2[0x77] == param_2[0x78]) {
      uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
      uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
      if (param_2[0x17] != 0) {
        local_230 = (longlong *)param_2[0x16];
        lVar22 = 0;
        do {
          if (*(longlong *)((longlong)local_230 + lVar22 + 0x18) == param_3) {
            pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                       ("kindsrc\\ingame_chat.rs",4,&local_120);
            if (pcVar9 == (char *)0x0) {
              pcVar9 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            if (((*pcVar9 == '\x03') && (*(longlong *)(pcVar9 + 0x18) == 5)) &&
               ((char)(*(int **)(pcVar9 + 0x10))[1] == 'e' &&
                **(int **)(pcVar9 + 0x10) == 0x626f7270)) {
              pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                               index_into("probe",5,&local_120);
              if (pcVar9 == (char *)0x0) {
                pcVar9 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
              uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
              if ((*pcVar9 == '\x02') &&
                 (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                 uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                 *(longlong *)(pcVar9 + 8) == 0)) {
                uVar23 = *(undefined8 *)(pcVar9 + 0x10);
                plVar15 = (longlong *)alloc[246c2e7857c81348]::boxed::box_new_uninit(8,0x20);
                local_1b0 = 0;
                local_1a0 = (longlong *)0x0;
                __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                uVar25 = 4;
                plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
                if (plVar10 != (longlong *)0x0) {
                  *(undefined4 *)plVar10 = 0x646e696b;
                  local_248 = 4;
                  local_238 = 4;
                  plStack_240 = plVar10;
                  serde_json[7404bcab4dc139c7]::value::to_value::<&&str>
                            (&local_228,&PTR_DAT_1406a1410);
                  if (local_228 == 0xff) {
                    local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                    core[505b25137b8ba7f]::result::unwrap_failed
                              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                               &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                               &PTR_s_src_ingame_chat_transport_rs_1406a1520);
                    goto LAB_140013379;
                  }
                  local_188 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                  uStack_180 = (undefined4)uStack_210;
                  uStack_17c = uStack_210._4_4_;
                  local_198 = (longlong *)
                              CONCAT44(uStack_224,
                                       CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                  uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                  <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                  ::insert(&local_228,&local_1b0,&local_248,&local_198);
                  if (local_228 != 0xff) {
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                  }
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  uVar25 = 5;
                  plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                  if (plVar10 != (longlong *)0x0) {
                    *(undefined1 *)((longlong)plVar10 + 4) = 0x65;
                    *(undefined4 *)plVar10 = 0x636e6f6e;
                    local_248 = 5;
                    local_238 = 5;
                    plStack_240 = plVar10;
                    serde_json[7404bcab4dc139c7]::value::to_value::<&&str>(&local_228,&local_d8);
                    if (local_228 == 0xff) {
                      local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                                 &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                                 &PTR_s_src_ingame_chat_transport_rs_1406a1520);
                      goto LAB_140013379;
                    }
                    local_188 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                    uStack_180 = (undefined4)uStack_210;
                    uStack_17c = uStack_210._4_4_;
                    local_198 = (longlong *)
                                CONCAT44(uStack_224,
                                         CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                    uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                    ::insert(&local_228,&local_1b0,&local_248,&local_198);
                    if (local_228 != 0xff) {
                      core[505b25137b8ba7f]::ptr::drop_glue::
                      <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                    }
                    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                    uVar25 = 5;
                    plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                    if (plVar10 != (longlong *)0x0) {
                      *(undefined1 *)((longlong)plVar10 + 4) = 0x65;
                      *(undefined4 *)plVar10 = 0x626f7270;
                      local_248 = 5;
                      local_238 = 5;
                      local_228 = 2;
                      uStack_220._0_4_ = 0;
                      uStack_220._4_4_ = 0;
                      uStack_218._0_4_ = (undefined4)uVar23;
                      uStack_218._4_4_ = (uint)((ulonglong)uVar23 >> 0x20);
                      plStack_240 = plVar10;
                      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                      ::insert(&local_198,&local_1b0,&local_248,&local_228);
                      if ((char)local_198 != -1) {
                        core[505b25137b8ba7f]::ptr::drop_glue::
                        <serde_json[7404bcab4dc139c7]::value::Value>(&local_198);
                      }
                      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                      uVar25 = 5;
                      plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                      if (plVar10 != (longlong *)0x0) {
                        *(undefined1 *)((longlong)plVar10 + 4) = 0x68;
                        *(undefined4 *)plVar10 = 0x636f7065;
                        local_248 = 5;
                        local_238 = 5;
                        plStack_240 = plVar10;
                        serde_json[7404bcab4dc139c7]::value::to_value::
                        <&alloc[246c2e7857c81348]::string::String>(&local_228,param_2 + 0xb);
                        if (local_228 == 0xff) {
                          local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                          core[505b25137b8ba7f]::result::unwrap_failed
                                    ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                                     &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                                     &PTR_s_src_ingame_chat_transport_rs_1406a1520);
                          goto LAB_140013379;
                        }
                        local_188 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                        uStack_180 = (undefined4)uStack_210;
                        uStack_17c = uStack_210._4_4_;
                        local_198 = (longlong *)
                                    CONCAT44(uStack_224,
                                             CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                        uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                        ::insert(&local_228,&local_1b0,&local_248,&local_198);
                        if (local_228 != 0xff) {
                          core[505b25137b8ba7f]::ptr::drop_glue::
                          <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                        }
                        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                        uVar25 = 4;
                        plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
                        if (plVar10 != (longlong *)0x0) {
                          *(undefined4 *)plVar10 = 0x6d616574;
                          local_248 = 4;
                          local_238 = 4;
                          bStack_227 = (byte)~*(byte *)((longlong)local_230 + lVar22 + 0x24) >> 7;
                          local_228 = 1;
                          plStack_240 = plVar10;
                          <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                          ::insert(&local_198,&local_1b0,&local_248,&local_228);
                          if ((char)local_198 != -1) {
                            core[505b25137b8ba7f]::ptr::drop_glue::
                            <serde_json[7404bcab4dc139c7]::value::Value>(&local_198);
                          }
                          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                          uVar25 = 4;
                          plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
                          if (plVar10 != (longlong *)0x0) {
                            *(undefined4 *)plVar10 = 0x6d6f6f72;
                            local_248 = 4;
                            local_238 = 4;
                            plStack_240 = plVar10;
                            serde_json[7404bcab4dc139c7]::value::to_value::
                            <&alloc[246c2e7857c81348]::string::String>(&local_228,param_2);
                            if (local_228 == 0xff) {
                              local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                              core[505b25137b8ba7f]::result::unwrap_failed
                                        ("called `Result::unwrap()` on an `Err` value",0x2b,
                                         &local_198,
                                         &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150
                                         ,&PTR_s_src_ingame_chat_transport_rs_1406a1520);
                              goto LAB_140013379;
                            }
                            local_188 = (longlong *)
                                        CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                            uStack_180 = (undefined4)uStack_210;
                            uStack_17c = uStack_210._4_4_;
                            local_198 = (longlong *)
                                        CONCAT44(uStack_224,
                                                 CONCAT22(uStack_226,CONCAT11(bStack_227,local_228))
                                                );
                            uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                            <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                            ::insert(&local_228,&local_1b0,&local_248,&local_198);
                            if (local_228 != 0xff) {
                              core[505b25137b8ba7f]::ptr::drop_glue::
                              <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                            }
                            uStack_220._0_4_ = (undefined4)local_1b0;
                            uStack_220._4_4_ = local_1b0._4_4_;
                            uStack_218._0_4_ = uStack_1a8;
                            uStack_218._4_4_ = uStack_1a4;
                            uStack_210 = local_1a0;
                            local_228 = 5;
                            host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet
                                      (&local_198,&local_228);
                            local_228 = (byte)local_198;
                            bStack_227 = (byte)((ulonglong)local_198 >> 8);
                            uStack_226 = (undefined2)((ulonglong)local_198 >> 0x10);
                            uStack_224 = (uint)((ulonglong)local_198 >> 0x20);
                            *plVar15 = param_3;
                            plVar15[1] = (longlong)local_198;
                            plVar15[2] = (longlong)uStack_190;
                            plVar15[3] = (longlong)local_188;
                            *param_1 = 1;
                            param_1[1] = plVar15;
                            param_1[2] = 1;
                            uStack_218 = local_188;
                            uStack_220 = uStack_190;
                            goto LAB_140012a8d;
                          }
                        }
                      }
                    }
                  }
                }
                alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar25);
                goto LAB_140013379;
              }
            }
            else {
              pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                               index_into(&DAT_1406a0bed,5,&local_120);
              if (pcVar9 == (char *)0x0) {
                pcVar9 = 
                __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                ;
              }
              uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
              uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
              if ((*pcVar9 == '\x03') &&
                 (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                 uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                 *(size_t *)(pcVar9 + 0x18) == param_2[0xd])) {
                iVar8 = memcmp(*(void **)(pcVar9 + 0x10),(void *)param_2[0xc],param_2[0xd]);
                uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                if (iVar8 == 0) {
                  pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                   index_into("kindsrc\\ingame_chat.rs",4,&local_120);
                  if (pcVar9 == (char *)0x0) {
                    pcVar9 = 
                    __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                    ;
                  }
                  if (((*pcVar9 == '\x03') && (*(longlong *)(pcVar9 + 0x18) == 4)) &&
                     (**(int **)(pcVar9 + 0x10) == 0x6e696f6a)) {
                    pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                     index_into("probe",5,&local_120);
                    if (pcVar9 == (char *)0x0) {
                      pcVar9 = 
                      __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                      ;
                    }
                    uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                    uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                    if ((*pcVar9 == '\x02') &&
                       (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                       uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                       *(longlong *)(pcVar9 + 8) == 0)) {
                      local_100 = *(longlong **)(pcVar9 + 0x10);
                      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                      ::rustc_entry(&local_228,param_2 + 0x6b,param_3);
                      if (CONCAT44(uStack_224,CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)))
                          == 0) {
                        local_198 = (longlong *)0x0;
                      }
                      else {
                        local_198 = (longlong *)
                                    CONCAT44(uStack_224,
                                             CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                      }
                      local_188 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                      uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                      lVar19 = <std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>
                               ::or_try_insert_with::
                               <<std[3bf9d48a0c3997f0]::collections::hash::map::Entry<u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection>>::or_insert_with<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_2_>::_closure_0_,_>
                                         (&local_198,pvVar16,plVar15);
                      uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                      uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                      if (*(longlong **)(lVar19 + 0x10) == plVar15) {
                        iVar8 = memcmp(*(void **)(lVar19 + 8),pvVar16,(size_t)plVar15);
                        uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                        uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                        if (iVar8 == 0) {
                          local_230 = (longlong *)
                                      (longlong)*(char *)((longlong)local_230 + lVar22 + 0x24);
                          local_f8 = (longlong *)
                                     alloc[246c2e7857c81348]::boxed::box_new_uninit(8,0x20);
                          local_1b0 = 0;
                          local_1a0 = (longlong *)0x0;
                          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                          uVar23 = 4;
                          local_128 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
                          if (local_128 != (longlong *)0x0) {
                            *(undefined4 *)local_128 = 0x646e696b;
                            local_248 = 4;
                            local_238 = 4;
                            plStack_240 = local_128;
                            serde_json[7404bcab4dc139c7]::value::to_value::<&&str>
                                      (&local_228,&PTR_s_ready_1406a05a0);
                            if (local_228 == 0xff) {
                              local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                              core[505b25137b8ba7f]::result::unwrap_failed
                                        ("called `Result::unwrap()` on an `Err` value",0x2b,
                                         &local_198,
                                         &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150
                                         ,&PTR_s_src_ingame_chat_transport_rs_1406a1538);
                              goto LAB_140013379;
                            }
                            local_188 = (longlong *)
                                        CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                            uStack_180 = (undefined4)uStack_210;
                            uStack_17c = uStack_210._4_4_;
                            local_198 = (longlong *)
                                        CONCAT44(uStack_224,
                                                 CONCAT22(uStack_226,CONCAT11(bStack_227,local_228))
                                                );
                            uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                            <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                            ::insert(&local_228,&local_1b0,&local_248,&local_198);
                            if (local_228 != 0xff) {
                              core[505b25137b8ba7f]::ptr::drop_glue::
                              <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                            }
                            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                            uVar23 = 5;
                            local_128 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                            if (local_128 != (longlong *)0x0) {
                              *(undefined1 *)((longlong)local_128 + 4) = 0x65;
                              *(undefined4 *)local_128 = 0x636e6f6e;
                              local_248 = 5;
                              local_238 = 5;
                              plStack_240 = local_128;
                              serde_json[7404bcab4dc139c7]::value::to_value::<&&str>
                                        (&local_228,&local_d8);
                              if (local_228 == 0xff) {
                                local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                core[505b25137b8ba7f]::result::unwrap_failed
                                          ("called `Result::unwrap()` on an `Err` value",0x2b,
                                           &local_198,
                                           &
                                           PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150
                                           ,&PTR_s_src_ingame_chat_transport_rs_1406a1538);
                                goto LAB_140013379;
                              }
                              local_188 = (longlong *)
                                          CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                              uStack_180 = (undefined4)uStack_210;
                              uStack_17c = uStack_210._4_4_;
                              local_198 = (longlong *)
                                          CONCAT44(uStack_224,
                                                   CONCAT22(uStack_226,
                                                            CONCAT11(bStack_227,local_228)));
                              uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                              <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                              ::insert(&local_228,&local_1b0,&local_248,&local_198);
                              if (local_228 != 0xff) {
                                core[505b25137b8ba7f]::ptr::drop_glue::
                                <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                              }
                              __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                              uVar23 = 5;
                              plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                              if (plVar10 != (longlong *)0x0) {
                                *(undefined1 *)((longlong)plVar10 + 4) = 0x65;
                                *(undefined4 *)plVar10 = 0x626f7270;
                                local_248 = 5;
                                local_238 = 5;
                                local_228 = 2;
                                uStack_220._0_4_ = 0;
                                uStack_220._4_4_ = 0;
                                uStack_218._0_4_ = SUB84(local_100,0);
                                uStack_218._4_4_ = (uint)((ulonglong)local_100 >> 0x20);
                                plStack_240 = plVar10;
                                <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                                ::insert(&local_198,&local_1b0,&local_248,&local_228);
                                if ((char)local_198 != -1) {
                                  core[505b25137b8ba7f]::ptr::drop_glue::
                                  <serde_json[7404bcab4dc139c7]::value::Value>(&local_198);
                                }
                                __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                                uVar23 = 5;
                                local_100 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1)
                                ;
                                if (local_100 != (longlong *)0x0) {
                                  *(undefined1 *)((longlong)local_100 + 4) = 0x68;
                                  *(undefined4 *)local_100 = 0x636f7065;
                                  local_248 = 5;
                                  local_238 = 5;
                                  plStack_240 = local_100;
                                  serde_json[7404bcab4dc139c7]::value::to_value::
                                  <&alloc[246c2e7857c81348]::string::String>
                                            (&local_228,param_2 + 0xb);
                                  if (local_228 == 0xff) {
                                    local_198 = (longlong *)
                                                CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                    core[505b25137b8ba7f]::result::unwrap_failed
                                              ("called `Result::unwrap()` on an `Err` value",0x2b,
                                               &local_198,
                                               &
                                               PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150
                                               ,&PTR_s_src_ingame_chat_transport_rs_1406a1538);
                                    goto LAB_140013379;
                                  }
                                  local_188 = (longlong *)
                                              CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                                  uStack_180 = (undefined4)uStack_210;
                                  uStack_17c = uStack_210._4_4_;
                                  local_198 = (longlong *)
                                              CONCAT44(uStack_224,
                                                       CONCAT22(uStack_226,
                                                                CONCAT11(bStack_227,local_228)));
                                  uStack_190 = (longlong *)
                                               CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                  <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                                  ::insert(&local_228,&local_1b0,&local_248,&local_198);
                                  if (local_228 != 0xff) {
                                    core[505b25137b8ba7f]::ptr::drop_glue::
                                    <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                                  }
                                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                                  uVar23 = 4;
                                  plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1)
                                  ;
                                  if (plVar10 != (longlong *)0x0) {
                                    *(undefined4 *)plVar10 = 0x6d616574;
                                    local_248 = 4;
                                    local_238 = 4;
                                    bStack_227 = (byte)~(byte)local_230 >> 7;
                                    local_228 = 1;
                                    plStack_240 = plVar10;
                                    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                                    ::insert(&local_198,&local_1b0,&local_248,&local_228);
                                    if ((char)local_198 != -1) {
                                      core[505b25137b8ba7f]::ptr::drop_glue::
                                      <serde_json[7404bcab4dc139c7]::value::Value>(&local_198);
                                    }
                                    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2()
                                    ;
                                    uVar23 = 7;
                                    plVar10 = (longlong *)
                                              __rustc[9d087a5ab36ea756]::__rust_alloc(7,1);
                                    if (plVar10 != (longlong *)0x0) {
                                      *(undefined4 *)((longlong)plVar10 + 3) = 0x64695f6d;
                                      *(undefined4 *)plVar10 = 0x6d616574;
                                      local_248 = 7;
                                      local_238 = 7;
                                      local_228 = 2;
                                      uStack_218._4_4_ = (uint)((ulonglong)local_230 >> 0x20);
                                      uStack_220._0_4_ = uStack_218._4_4_ >> 0x1f;
                                      uStack_220._4_4_ = 0;
                                      uStack_218._0_4_ = SUB84(local_230,0);
                                      plStack_240 = plVar10;
                                      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                                      ::insert(&local_198,&local_1b0,&local_248,&local_228);
                                      if ((char)local_198 != -1) {
                                        core[505b25137b8ba7f]::ptr::drop_glue::
                                        <serde_json[7404bcab4dc139c7]::value::Value>(&local_198);
                                      }
                                      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2
                                                ();
                                      uVar23 = 4;
                                      local_230 = (longlong *)
                                                  __rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
                                      if (local_230 != (longlong *)0x0) {
                                        *(undefined4 *)local_230 = 0x6d6f6f72;
                                        local_248 = 4;
                                        local_238 = 4;
                                        plStack_240 = local_230;
                                        serde_json[7404bcab4dc139c7]::value::to_value::
                                        <&alloc[246c2e7857c81348]::string::String>
                                                  (&local_228,param_2);
                                        if (local_228 == 0xff) {
                                          local_198 = (longlong *)
                                                      CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                          core[505b25137b8ba7f]::result::unwrap_failed
                                                    ("called `Result::unwrap()` on an `Err` value",
                                                     0x2b,&local_198,
                                                     &
                                                  PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150
                                                  ,&PTR_s_src_ingame_chat_transport_rs_1406a1538);
                                          goto LAB_140013379;
                                        }
                                        local_188 = (longlong *)
                                                    CONCAT44(uStack_218._4_4_,(undefined4)uStack_218
                                                            );
                                        uStack_180 = (undefined4)uStack_210;
                                        uStack_17c = uStack_210._4_4_;
                                        local_198 = (longlong *)
                                                    CONCAT44(uStack_224,
                                                             CONCAT22(uStack_226,
                                                                      CONCAT11(bStack_227,local_228)
                                                                     ));
                                        uStack_190 = (longlong *)
                                                     CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                                        ::insert(&local_228,&local_1b0,&local_248,&local_198);
                                        if (local_228 != 0xff) {
                                          core[505b25137b8ba7f]::ptr::drop_glue::
                                          <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                                        }
                                        uStack_220._0_4_ = (undefined4)local_1b0;
                                        uStack_220._4_4_ = local_1b0._4_4_;
                                        uStack_218._0_4_ = uStack_1a8;
                                        uStack_218._4_4_ = uStack_1a4;
                                        uStack_210 = local_1a0;
                                        local_228 = 5;
                                        host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet
                                                  (&local_198,&local_228);
                                        local_228 = (byte)local_198;
                                        bStack_227 = (byte)((ulonglong)local_198 >> 8);
                                        uStack_226 = (undefined2)((ulonglong)local_198 >> 0x10);
                                        uStack_224 = (uint)((ulonglong)local_198 >> 0x20);
                                        uStack_220._0_4_ = (uint)uStack_190;
                                        uStack_220._4_4_ = (uint)((ulonglong)uStack_190 >> 0x20);
                                        uStack_218._0_4_ = SUB84(local_188,0);
                                        uStack_218._4_4_ = (uint)((ulonglong)local_188 >> 0x20);
                                        *local_f8 = param_3;
                                        local_f8[3] = (longlong)local_188;
                                        *(int *)(local_f8 + 1) = (int)local_198;
                                        *(uint *)((longlong)local_f8 + 0xc) = uStack_224;
                                        *(uint *)(local_f8 + 2) = (uint)uStack_220;
                                        *(uint *)((longlong)local_f8 + 0x14) = uStack_220._4_4_;
                                        local_248 = 1;
                                        plStack_240 = local_f8;
                                        local_238 = 1;
                                        backfill(&local_198,param_2,param_3,pvVar16,plVar15,param_6,
                                                 param_7);
                                        uStack_210 = uStack_190 + (longlong)local_188 * 4;
                                        local_228 = (byte)uStack_190;
                                        bStack_227 = (byte)((ulonglong)uStack_190 >> 8);
                                        uStack_226 = (undefined2)((ulonglong)uStack_190 >> 0x10);
                                        uStack_224 = (uint)((ulonglong)uStack_190 >> 0x20);
                                        uStack_218._0_4_ = SUB84(local_198,0);
                                        uStack_218._4_4_ = (uint)((ulonglong)local_198 >> 0x20);
                                        uStack_220._0_4_ = (uint)uStack_190;
                                        uStack_220._4_4_ = uStack_224;
                                        <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>>
                                        ::spec_extend(&local_248,&local_228);
                                        param_1[2] = local_238;
                                        *param_1 = local_248;
                                        param_1[1] = plStack_240;
                                        uStack_218 = (longlong *)
                                                     CONCAT44(uStack_218._4_4_,
                                                              (undefined4)uStack_218);
                                        uStack_220 = (longlong *)
                                                     CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                        goto LAB_140012a8d;
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                          alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar23);
                          goto LAB_140013379;
                        }
                      }
                    }
                  }
                  else {
                    lVar22 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                             ::get_mut::<u64>(param_2 + 0x6b,&local_f0);
                    uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                    uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                    if ((lVar22 != 0) &&
                       (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                       uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                       *(longlong **)(lVar22 + 0x10) == plVar15)) {
                      iVar8 = memcmp(*(void **)(lVar22 + 8),pvVar16,(size_t)plVar15);
                      uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                      uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                      if (iVar8 == 0) {
                        pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>
                                         ::index_into("kindsrc\\ingame_chat.rs",4,&local_120);
                        if (pcVar9 == (char *)0x0) {
                          pcVar9 = 
                          __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                          ;
                        }
                        if (((*pcVar9 == '\x03') && (*(longlong *)(pcVar9 + 0x18) == 3)) &&
                           ((char)(*(short **)(pcVar9 + 0x10))[1] == 'k' &&
                            **(short **)(pcVar9 + 0x10) == 0x6361)) {
                          pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>
                                           ::index_into("id",2,&local_120);
                          if (pcVar9 == (char *)0x0) {
                            pcVar9 = 
                            __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                            ;
                          }
                          uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218)
                          ;
                          uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                          if ((*pcVar9 == '\x02') &&
                             (uStack_218 = (longlong *)
                                           CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                             uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                             *(longlong *)(pcVar9 + 8) == 0)) {
                            <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>
                            ::retain::
                            <<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_4_>
                                      (lVar22 + 0x18,*(undefined8 *)(pcVar9 + 0x10));
                            uStack_218 = (longlong *)
                                         CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                            uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                          }
                        }
                        else {
                          pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>
                                           ::index_into("kindsrc\\ingame_chat.rs",4,&local_120);
                          if (pcVar9 == (char *)0x0) {
                            pcVar9 = 
                            __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                            ;
                          }
                          uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218)
                          ;
                          uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                          if (((*pcVar9 == '\x03') &&
                              (uStack_218 = (longlong *)
                                            CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                              uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                              *(longlong *)(pcVar9 + 0x18) == 3)) &&
                             (uStack_218 = (longlong *)
                                           CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                             uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                             (char)(*(short **)(pcVar9 + 0x10))[1] == 'y' &&
                             **(short **)(pcVar9 + 0x10) == 0x6173)) {
                            puVar11 = (undefined *)
                                      <str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                      index_into("msg",3,&local_120);
                            if (puVar11 == (undefined *)0x0) {
                              puVar11 = 
                              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                              ;
                            }
                            <serde_json[7404bcab4dc139c7]::value::Value_as_core[505b25137b8ba7f]::clone::Clone>
                            ::clone(&local_198,puVar11);
                            <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_serde_core[7f01a81d286c67f3]::de::Deserialize>
                            ::deserialize::<serde_json[7404bcab4dc139c7]::value::Value>
                                      (&local_228,&local_198);
                            plVar15 = uStack_210;
                            uVar5 = uStack_224;
                            if (local_228 == 0xff) {
                              core[505b25137b8ba7f]::ptr::drop_glue::
                              <core[505b25137b8ba7f]::result::Result<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,serde_json[7404bcab4dc139c7]::error::Error>>
                                        (&local_228);
                              uStack_218 = (longlong *)
                                           CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                              uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                            }
                            else {
                              if (local_228 == 0) {
                                local_138 = local_1c8;
                                uStack_130 = uStack_1c0;
                                local_148 = local_1d8;
                                uStack_140 = uStack_1d0;
                                local_158 = local_1e8;
                                uStack_150 = uStack_1e0;
                                local_168 = local_1f8;
                                uStack_164 = uStack_1f4;
                                uStack_160 = uStack_1f0;
                                uStack_15c = uStack_1ec;
                                local_178 = local_208;
                                uStack_174 = uStack_204;
                                uStack_170 = uStack_200;
                                uStack_16c = uStack_1fc;
                                local_188 = (longlong *)
                                            CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                                uStack_180 = (undefined4)uStack_210;
                                uStack_17c = uStack_210._4_4_;
                                local_198 = (longlong *)
                                            ((ulonglong)
                                             CONCAT43(uStack_224,CONCAT21(uStack_226,bStack_227)) <<
                                            8);
                                uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220)
                                ;
                                if ((*(uint *)(lVar22 + 0x40) < uStack_224) &&
                                   ((byte)(bStack_227 - 3) < 2)) {
                                  local_100 = local_188;
                                  reach_directory[4b72b9694f6c3c08]::chat::clean
                                            (&local_228,local_188,uStack_210);
                                  local_230 = (longlong *)
                                              CONCAT44(uStack_224,
                                                       CONCAT22(uStack_226,
                                                                CONCAT11(bStack_227,local_228)));
                                  if (local_230 != (longlong *)0xffffffffffffffff) {
                                    if ((longlong *)
                                        CONCAT44(uStack_218._4_4_,(undefined4)uStack_218) == plVar15
                                       ) {
                                      local_128 = (longlong *)
                                                  CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                      iVar8 = memcmp(local_128,local_100,(size_t)plVar15);
                                      if (iVar8 == 0) {
                                        if (local_230 != (longlong *)0x0) {
                                          __rustc[9d087a5ab36ea756]::__rust_dealloc
                                                    (local_128,local_230,1);
                                          return;
                                        }
                                        *(uint *)(lVar22 + 0x40) = uVar5;
                                        local_1c8 = local_138;
                                        uStack_1c0 = uStack_130;
                                        local_1d8 = local_148;
                                        uStack_1d0 = uStack_140;
                                        local_1e8 = local_158;
                                        uStack_1e0 = uStack_150;
                                        local_1f8 = local_168;
                                        uStack_1f4 = uStack_164;
                                        uStack_1f0 = uStack_160;
                                        uStack_1ec = uStack_15c;
                                        local_208 = local_178;
                                        uStack_204 = uStack_174;
                                        uStack_200 = uStack_170;
                                        uStack_1fc = uStack_16c;
                                        uStack_218._0_4_ = (undefined4)local_188;
                                        uStack_218._4_4_ = local_188._4_4_;
                                        uStack_210 = (longlong *)CONCAT44(uStack_17c,uStack_180);
                                        local_228 = (byte)local_198;
                                        bStack_227 = (byte)((ulonglong)local_198 >> 8);
                                        uStack_226 = (undefined2)((ulonglong)local_198 >> 0x10);
                                        uStack_224 = local_198._4_4_;
                                        uStack_220._0_4_ = (undefined4)uStack_190;
                                        uStack_220._4_4_ = uStack_190._4_4_;
                                        relay_say(param_1,param_2,param_3,&local_228,param_6,param_7
                                                 );
                                        uStack_218 = (longlong *)
                                                     CONCAT44(uStack_218._4_4_,
                                                              (undefined4)uStack_218);
                                        uStack_220 = (longlong *)
                                                     CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                                        goto LAB_140012a8d;
                                      }
                                    }
                                    if (local_230 != (longlong *)0x0) {
                                      __rustc[9d087a5ab36ea756]::__rust_dealloc
                                                (CONCAT44(uStack_220._4_4_,(uint)uStack_220),
                                                 local_230,1);
                                      return;
                                    }
                                  }
                                }
                                *param_1 = 0;
                                param_1[1] = 8;
                                param_1[2] = 0;
                                core[505b25137b8ba7f]::ptr::drop_glue::
                                <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(&local_198);
                                uStack_218 = (longlong *)
                                             CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                                uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220)
                                ;
                                goto LAB_140012a8d;
                              }
                              core[505b25137b8ba7f]::ptr::drop_glue::
                              <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(&local_228);
                              uStack_218 = (longlong *)
                                           CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                              uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            break;
          }
          lVar22 = lVar22 + 0x28;
          uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
          uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
        } while (param_2[0x17] * 0x28 != lVar22);
      }
    }
    else {
      uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
      uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
      if ((param_3 == param_2[0x78]) &&
         (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
         uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
         plVar15 == (longlong *)param_2[0x14])) {
        iVar8 = memcmp(pvVar16,(void *)param_2[0x13],(size_t)plVar15);
        uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
        uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
        if (iVar8 != 0) goto LAB_140012a76;
        pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                   ("probe",5,&local_120);
        if (pcVar9 == (char *)0x0) {
          pcVar9 = 
          __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
          ;
        }
        if ((*pcVar9 == '\x02') && (*(longlong *)(pcVar9 + 8) == 0)) {
          plVar15 = &local_e8;
          bVar6 = receive::_closure_5_(param_2 + 0x3f,plVar15,*(undefined8 *)(pcVar9 + 0x10));
        }
        else {
          bVar6 = 0;
        }
        pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                   ("kindsrc\\ingame_chat.rs",4);
        plVar10 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
        if (pcVar9 == (char *)0x0) {
          pcVar9 = 
          __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
          ;
        }
        plVar18 = param_2 + 0x12;
        if (((*pcVar9 != '\x03') || (*(longlong *)(pcVar9 + 0x18) != 6)) ||
           ((((short)(*(int **)(pcVar9 + 0x10))[1] == 0x7375 &&
             **(int **)(pcVar9 + 0x10) == 0x74617473) & bVar6) == 0)) {
LAB_1400112d6:
          pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                     ("kindsrc\\ingame_chat.rs",4,&local_120);
          if (pcVar9 == (char *)0x0) {
            pcVar9 = 
            __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
            ;
          }
          uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
          if (((*pcVar9 == '\x03') &&
              (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
              *(longlong *)(pcVar9 + 0x18) == 5)) &&
             (uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
             (char)(*(int **)(pcVar9 + 0x10))[1] == 'y' && **(int **)(pcVar9 + 0x10) == 0x64616572))
          {
            pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                       (&DAT_1406a0bed,5);
            plVar10 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
            if (pcVar9 == (char *)0x0) {
              pcVar9 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
            if (*pcVar9 == '\x03') {
              local_230 = *(longlong **)(pcVar9 + 0x10);
              plVar17 = *(longlong **)(pcVar9 + 0x18);
              local_198 = local_230;
              uStack_190 = plVar17;
              uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
              if ((bVar6 & 1) != 0) {
                if ((longlong *)param_2[0x42] <= plVar15) {
                  ppuVar24 = &PTR_s_src_ingame_chat_transport_rs_1406a14b0;
                  goto LAB_140012d51;
                }
                uVar21 = 0;
                if ((ulonglong)param_2[0x3f] <= (ulonglong)(param_2[0x41] + (longlong)plVar15)) {
                  uVar21 = param_2[0x3f];
                }
                lVar22 = ((param_2[0x41] + (longlong)plVar15) - uVar21) * 0x30;
                uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                if ((((ulonglong)param_2[0x7b] < *(ulonglong *)(param_2[0x40] + 0x28 + lVar22)) &&
                    (plVar12 = (longlong *)(param_2[0x40] + lVar22),
                    uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218),
                    *plVar12 != -1)) && (uStack_218 = plVar10, (longlong *)plVar12[2] == plVar17)) {
                  iVar8 = memcmp((void *)plVar12[1],local_230,(size_t)plVar17);
                  uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                  if (iVar8 == 0) {
                    <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Probe>>
                    ::iter(&local_228,param_2 + 0x3f);
                    plVar10 = (longlong *)
                              CONCAT44(uStack_224,
                                       CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                    do {
                      plVar12 = plVar10;
                      if (plVar12 == (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220)) {
                        local_228 = (byte)plVar12;
                        bStack_227 = (byte)((ulonglong)plVar12 >> 8);
                        uStack_226 = (undefined2)((ulonglong)plVar12 >> 0x10);
                        uStack_224 = (uint)((ulonglong)plVar12 >> 0x20);
                        plVar10 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                        goto joined_r0x000140012bd3;
                      }
                      plVar10 = plVar12 + 6;
                    } while ((plVar10 == (longlong *)&DAT_00000030) || (plVar12[5] != param_2[0x7a])
                            );
                    local_228 = (byte)plVar10;
                    bStack_227 = (byte)((ulonglong)plVar10 >> 8);
                    uStack_226 = (undefined2)((ulonglong)plVar10 >> 0x10);
                    uStack_224 = (uint)((ulonglong)plVar10 >> 0x20);
                    plVar4 = uStack_218;
                    goto LAB_140012bfd;
                  }
                }
              }
            }
          }
          goto LAB_1400113ea;
        }
        if (plVar15 < (longlong *)param_2[0x42]) {
          uVar21 = 0;
          if ((ulonglong)param_2[0x3f] <= (ulonglong)(param_2[0x41] + (longlong)plVar15)) {
            uVar21 = param_2[0x3f];
          }
          if (*(ulonglong *)
               (param_2[0x40] + 0x28 + ((param_2[0x41] + (longlong)plVar15) - uVar21) * 0x30) <=
              (ulonglong)param_2[0x7a]) goto LAB_1400112d6;
          _Size = 5;
          pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                     (&DAT_1406a0bed);
          if (pcVar9 == (char *)0x0) {
            pcVar9 = 
            __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
            ;
          }
          if (*pcVar9 == '\x03') {
            uVar23 = *(undefined8 *)(pcVar9 + 0x10);
            _Size = *(size_t *)(pcVar9 + 0x18);
          }
          else {
            uVar23 = 0;
          }
          pvVar16 = (void *)<core[505b25137b8ba7f]::option::Option<&str>>::filter::
                            <<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_6_>
                                      (uVar23);
          uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
          uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
          if (pvVar16 == (void *)0x0) goto LAB_140012a76;
          local_c8 = pvVar16;
          local_c0 = _Size;
          <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<alloc[246c2e7857c81348]::string::String>>
          ::iter(&local_228,param_2 + 0xe);
          cVar7 = <alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<alloc[246c2e7857c81348]::string::String>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
                  ::try_fold::
                  <(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::any::check<&alloc[246c2e7857c81348]::string::String,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_7_>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<()>>
                            (&local_228);
          if (cVar7 != '\0') {
            plVar10 = (longlong *)&DAT_00000008;
            uVar23 = 0;
LAB_1400123fb:
            *param_1 = uVar23;
            param_1[1] = plVar10;
            param_1[2] = uVar23;
            uStack_218 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
            uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
            goto LAB_140012a8d;
          }
          if ((longlong *)param_2[0x42] <= plVar15) {
            ppuVar24 = &PTR_s_src_ingame_chat_transport_rs_1406a1438;
            plVar10 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
            goto LAB_140012d51;
          }
          uVar21 = 0;
          if ((ulonglong)param_2[0x3f] <= (ulonglong)(param_2[0x41] + (longlong)plVar15)) {
            uVar21 = param_2[0x3f];
          }
          param_2[0x7a] =
               *(longlong *)
                (param_2[0x40] + 0x28 + ((param_2[0x41] + (longlong)plVar15) - uVar21) * 0x30);
          if ((_Size != param_2[0xd]) ||
             (iVar8 = memcmp(pvVar16,(void *)param_2[0xc],_Size), iVar8 != 0)) {
            *(undefined4 *)(param_2 + 0x6a) = 0xffffffff;
          }
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in(&local_228,_Size,0,1,1);
          plVar10 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
          uStack_220 = plVar10;
          if (CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)) != 1) {
            _Dst = (void *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
            if (_Size != 0) {
              memcpy(_Dst,pvVar16,_Size);
            }
            if ((longlong *)param_2[0x42] <= plVar15) {
              core[505b25137b8ba7f]::option::expect_failed
                        ("out of bounds access/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library\\core\\src\\str\\pattern.rs"
                         ,0x14,&PTR_s_src_ingame_chat_transport_rs_1406a1450);
              goto LAB_140013379;
            }
            uVar21 = 0;
            if ((ulonglong)param_2[0x3f] <= (ulonglong)(param_2[0x41] + (longlong)plVar15)) {
              uVar21 = param_2[0x3f];
            }
            lVar22 = ((param_2[0x41] + (longlong)plVar15) - uVar21) * 0x30;
            puVar1 = (undefined8 *)(param_2[0x40] + lVar22);
            lVar22 = *(longlong *)(param_2[0x40] + lVar22);
            if (0 < lVar22) {
              __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar1[1],lVar22,1);
              return;
            }
            *puVar1 = plVar10;
            puVar1[1] = _Dst;
            puVar1[2] = _Size;
            plVar10 = (longlong *)alloc[246c2e7857c81348]::boxed::box_new_uninit(8,0x20);
            lVar22 = param_2[0x78];
            local_1b0 = 0;
            local_1a0 = (longlong *)0x0;
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            uVar23 = 4;
            plVar17 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
            if (plVar17 != (longlong *)0x0) {
              *(undefined4 *)plVar17 = 0x646e696b;
              local_248 = 4;
              local_238 = 4;
              plStack_240 = plVar17;
              serde_json[7404bcab4dc139c7]::value::to_value::<&&str>(&local_228,&PTR_DAT_1406a1470);
              if (local_228 == 0xff) {
                local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                core[505b25137b8ba7f]::result::unwrap_failed
                          ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                           &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                           &PTR_s_src_ingame_chat_transport_rs_1406a1480);
                goto LAB_140013379;
              }
              local_188 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
              uStack_180 = (undefined4)uStack_210;
              uStack_17c = uStack_210._4_4_;
              local_198 = (longlong *)
                          CONCAT44(uStack_224,CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
              uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
              <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
              ::insert(&local_228,&local_1b0,&local_248,&local_198);
              if (local_228 != 0xff) {
                core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                          (&local_228);
              }
              __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
              uVar23 = 5;
              plVar17 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
              if (plVar17 != (longlong *)0x0) {
                *(undefined1 *)((longlong)plVar17 + 4) = 0x65;
                *(undefined4 *)plVar17 = 0x636e6f6e;
                local_248 = 5;
                local_238 = 5;
                plStack_240 = plVar17;
                serde_json[7404bcab4dc139c7]::value::to_value::
                <&alloc[246c2e7857c81348]::string::String>(&local_228,plVar18);
                if (local_228 == 0xff) {
                  local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                  core[505b25137b8ba7f]::result::unwrap_failed
                            ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                             &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                             &PTR_s_src_ingame_chat_transport_rs_1406a1480);
                  goto LAB_140013379;
                }
                local_188 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                uStack_180 = (undefined4)uStack_210;
                uStack_17c = uStack_210._4_4_;
                local_198 = (longlong *)
                            CONCAT44(uStack_224,CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)))
                ;
                uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                ::insert(&local_228,&local_1b0,&local_248,&local_198);
                if (local_228 != 0xff) {
                  core[505b25137b8ba7f]::ptr::drop_glue::
                  <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                }
                __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                uVar23 = 5;
                plVar18 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                if (plVar18 != (longlong *)0x0) {
                  *(undefined1 *)((longlong)plVar18 + 4) = 0x65;
                  *(undefined4 *)plVar18 = 0x626f7270;
                  local_248 = 5;
                  local_238 = 5;
                  plStack_240 = plVar18;
                  if ((longlong *)param_2[0x42] <= plVar15) {
                    core[505b25137b8ba7f]::option::expect_failed
                              ("out of bounds access/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library\\core\\src\\str\\pattern.rs"
                               ,0x14,&PTR_s_src_ingame_chat_transport_rs_1406a1498);
                    goto LAB_140013379;
                  }
                  uVar21 = 0;
                  if ((ulonglong)param_2[0x3f] <= (ulonglong)((longlong)plVar15 + param_2[0x41])) {
                    uVar21 = param_2[0x3f];
                  }
                  uVar23 = *(undefined8 *)
                            (param_2[0x40] + 0x28 +
                            (((longlong)plVar15 + param_2[0x41]) - uVar21) * 0x30);
                  local_228 = 2;
                  uStack_220._0_4_ = 0;
                  uStack_220._4_4_ = 0;
                  uStack_218._0_4_ = (undefined4)uVar23;
                  uStack_218._4_4_ = (uint)((ulonglong)uVar23 >> 0x20);
                  <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                  ::insert(&local_198,&local_1b0,&local_248,&local_228);
                  if ((char)local_198 != -1) {
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <serde_json[7404bcab4dc139c7]::value::Value>(&local_198);
                  }
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  uVar23 = 5;
                  plVar15 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                  if (plVar15 != (longlong *)0x0) {
                    *(undefined1 *)((longlong)plVar15 + 4) = 0x68;
                    *(undefined4 *)plVar15 = 0x636f7065;
                    local_248 = 5;
                    local_238 = 5;
                    plStack_240 = plVar15;
                    serde_json[7404bcab4dc139c7]::value::to_value::<&&str>(&local_228,&local_c8);
                    if (local_228 == 0xff) {
                      local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                                 &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                                 &PTR_s_src_ingame_chat_transport_rs_1406a1480);
                      goto LAB_140013379;
                    }
                    local_188 = (longlong *)CONCAT44(uStack_218._4_4_,(undefined4)uStack_218);
                    uStack_180 = (undefined4)uStack_210;
                    uStack_17c = uStack_210._4_4_;
                    local_198 = (longlong *)
                                CONCAT44(uStack_224,
                                         CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                    uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                    ::insert(&local_228,&local_1b0,&local_248,&local_198);
                    if (local_228 != 0xff) {
                      core[505b25137b8ba7f]::ptr::drop_glue::
                      <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                    }
                    uStack_220._0_4_ = (undefined4)local_1b0;
                    uStack_220._4_4_ = local_1b0._4_4_;
                    uStack_218._0_4_ = uStack_1a8;
                    uStack_218._4_4_ = uStack_1a4;
                    uStack_210 = local_1a0;
                    local_228 = 5;
                    host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet
                              (&local_198,&local_228);
                    local_228 = (byte)local_198;
                    bStack_227 = (byte)((ulonglong)local_198 >> 8);
                    uStack_226 = (undefined2)((ulonglong)local_198 >> 0x10);
                    uStack_224 = (uint)((ulonglong)local_198 >> 0x20);
                    uStack_220._0_4_ = (uint)uStack_190;
                    uStack_220._4_4_ = (uint)((ulonglong)uStack_190 >> 0x20);
                    uStack_218._0_4_ = SUB84(local_188,0);
                    uStack_218._4_4_ = (uint)((ulonglong)local_188 >> 0x20);
                    *plVar10 = lVar22;
                    plVar10[1] = (longlong)local_198;
                    plVar10[2] = (longlong)uStack_190;
                    plVar10[3] = (longlong)local_188;
                    uVar23 = 1;
                    goto LAB_1400123fb;
                  }
                }
              }
            }
            alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar23);
            goto LAB_140013379;
          }
          goto LAB_140012fa4;
        }
        ppuVar24 = &PTR_s_src_ingame_chat_transport_rs_1406a1420;
        goto LAB_140012d51;
      }
    }
  }
  goto LAB_140012a76;
  while ((plVar10 = plVar12 + 6, plVar10 == (longlong *)&DAT_00000030 ||
         (plVar4 = plVar10, plVar12[5] != param_2[0x7a]))) {
joined_r0x000140012bd3:
    plVar12 = plVar10;
    if (plVar12 == uStack_210) goto LAB_1400113ea;
  }
LAB_140012bfd:
  uStack_218 = plVar4;
  if ((plVar10[-6] != -1) && ((longlong *)plVar10[-4] == plVar17)) {
    iVar8 = memcmp((void *)plVar10[-5],local_230,(size_t)plVar17);
    if (iVar8 == 0) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<alloc[246c2e7857c81348]::string::String>>
      ::iter(&local_228,param_2 + 0xe);
      cVar7 = <alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<alloc[246c2e7857c81348]::string::String>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
              ::try_fold::
              <(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::any::check<&alloc[246c2e7857c81348]::string::String,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_7_>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<()>>
                        (&local_228,&local_198);
      if (cVar7 == '\0') {
        if (plVar17 != (longlong *)param_2[0xd]) {
LAB_140012c72:
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in(&local_228,plVar17,0,1,1)
          ;
          plVar18 = uStack_218;
          if (local_228 == 0) {
            if (plVar17 != (longlong *)0x0) {
              memcpy(uStack_218,local_230,(size_t)plVar17);
            }
            local_228 = (byte)(uint)uStack_220;
            bStack_227 = (byte)((uint)uStack_220 >> 8);
            uStack_226 = (undefined2)((uint)uStack_220 >> 0x10);
            uStack_224 = uStack_220._4_4_;
            uStack_218._0_4_ = SUB84(plVar17,0);
            uStack_218._4_4_ = (uint)((ulonglong)plVar17 >> 0x20);
            uStack_220 = plVar18;
            change_epoch(param_2,&local_228);
            goto LAB_140012cd7;
          }
LAB_140012fa4:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uStack_220,uStack_218);
          goto LAB_140013379;
        }
        iVar8 = memcmp(local_230,(void *)param_2[0xc],(size_t)plVar17);
        if (iVar8 != 0) goto LAB_140012c72;
LAB_140012cd7:
        plVar10 = (longlong *)&DAT_00000004;
        pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                   ("room",4,&local_120);
        if (pcVar9 == (char *)0x0) {
          pcVar9 = 
          __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
          ;
        }
        if (*pcVar9 == '\x03') {
          uVar23 = *(undefined8 *)(pcVar9 + 0x10);
          plVar10 = *(longlong **)(pcVar9 + 0x18);
        }
        else {
          uVar23 = 0;
        }
        pvVar16 = (void *)<core[505b25137b8ba7f]::option::Option<&str>>::filter::
                          <<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_6_>
                                    (uVar23);
        if (pvVar16 != (void *)0x0) {
          plVar18 = plVar10;
          if (plVar10 == (longlong *)param_2[2]) {
            iVar8 = memcmp(pvVar16,(void *)param_2[1],(size_t)plVar10);
            if (iVar8 == 0) goto LAB_140012f20;
          }
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in(&local_228,plVar10,0,1,1)
          ;
          plVar17 = uStack_220;
          if (CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)) == 1) goto LAB_140012fa4;
          local_230 = uStack_218;
          if (plVar10 != (longlong *)0x0) {
            memcpy(uStack_218,pvVar16,(size_t)plVar10);
          }
          if (*param_2 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(param_2[1],*param_2,1);
            return;
          }
          *param_2 = (longlong)plVar17;
          param_2[1] = (longlong)local_230;
          param_2[2] = (longlong)plVar10;
          <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>>
          ::truncate(param_2 + 0x43,0);
          param_2[0x45] = 0;
        }
LAB_140012f20:
        pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                   ("team_id",7,&local_120);
        if (pcVar9 == (char *)0x0) {
          pcVar9 = 
          __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
          ;
        }
        if ((*pcVar9 == '\x02') && (*(longlong *)(pcVar9 + 8) != 2)) {
          if ((int)*(longlong *)(pcVar9 + 8) == 1) {
            plVar18 = *(longlong **)(pcVar9 + 0x10);
            bVar26 = true;
          }
          else {
            plVar18 = *(longlong **)(pcVar9 + 0x10);
            bVar26 = -1 < (longlong)plVar18;
          }
        }
        else {
          bVar26 = false;
        }
        cVar7 = (char)plVar18;
        if ((undefined1 *)0x8 < (undefined1 *)((longlong)plVar18 + 1)) {
          cVar7 = -1;
        }
        if (!bVar26) {
          cVar7 = -1;
        }
        if (cVar7 != *(char *)((longlong)param_2 + 0x3ed)) {
          drop_team_lines();
          *(char *)((longlong)param_2 + 0x3ed) = cVar7;
        }
        if ((longlong *)param_2[0x42] <= plVar15) {
          ppuVar24 = &PTR_s_src_ingame_chat_transport_rs_1406a14d8;
          plVar10 = uStack_218;
LAB_140012d51:
          uStack_218 = plVar10;
          core[505b25137b8ba7f]::option::expect_failed
                    ("out of bounds access/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library\\core\\src\\str\\pattern.rs"
                     ,0x14,ppuVar24);
          goto LAB_140013379;
        }
        uVar21 = 0;
        if ((ulonglong)param_2[0x3f] <= (ulonglong)((longlong)plVar15 + param_2[0x41])) {
          uVar21 = param_2[0x3f];
        }
        param_2[0x7b] =
             *(longlong *)
              (param_2[0x40] + 0x28 + (((longlong)plVar15 + param_2[0x41]) - uVar21) * 0x30);
        param_2[0x69] = param_6;
        *(int *)(param_2 + 0x6a) = param_7;
        pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                   ("team",4,&local_120);
        if (pcVar9 == (char *)0x0) {
          pcVar9 = 
          __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
          ;
        }
        if (*pcVar9 == '\x01') {
          *(char *)((longlong)param_2 + 0x3ec) = pcVar9[1];
        }
        else {
          *(undefined1 *)((longlong)param_2 + 0x3ec) = 0;
        }
        goto LAB_140012a76;
      }
    }
  }
LAB_1400113ea:
  pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                             ("kindsrc\\ingame_chat.rs",4,&local_120);
  if (pcVar9 == (char *)0x0) {
    pcVar9 = 
    __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
    ;
  }
  uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
  if (((*pcVar9 == '\x03') &&
      (uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
      *(longlong *)(pcVar9 + 0x18) == 4)) &&
     (uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
     **(int **)(pcVar9 + 0x10) == 0x656e696c)) {
    pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                               (&DAT_1406a0bed,5,&local_120);
    if (pcVar9 == (char *)0x0) {
      pcVar9 = 
      __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
      ;
    }
    uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
    if ((*pcVar9 == '\x03') &&
       (uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
       *(size_t *)(pcVar9 + 0x18) == param_2[0xd])) {
      iVar8 = memcmp(*(void **)(pcVar9 + 0x10),(void *)param_2[0xc],param_2[0xd]);
      uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
      if (iVar8 == 0) {
        cVar7 = ready(param_2,param_6,param_7);
        uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
        if (cVar7 != '\0') {
          pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                     ("id",2,&local_120);
          if (pcVar9 == (char *)0x0) {
            pcVar9 = 
            __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
            ;
          }
          uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
          if (((*pcVar9 == '\x02') &&
              (uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220),
              *(longlong *)(pcVar9 + 8) == 0)) &&
             (uVar21 = *(ulonglong *)(pcVar9 + 0x10),
             uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220), uVar21 != 0)) {
            puVar11 = (undefined *)
                      <str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::index_into
                                ("msg",3,&local_120);
            if (puVar11 == (undefined *)0x0) {
              puVar11 = 
              __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
              ;
            }
            <serde_json[7404bcab4dc139c7]::value::Value_as_core[505b25137b8ba7f]::clone::Clone>::
            clone(&local_198,puVar11);
            <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_serde_core[7f01a81d286c67f3]::de::Deserialize>
            ::deserialize::<serde_json[7404bcab4dc139c7]::value::Value>(&local_228,&local_198);
            if (local_228 != 0xff) {
              local_58 = local_1c8;
              uStack_50 = uStack_1c0;
              local_68 = local_1d8;
              uStack_60 = uStack_1d0;
              local_78 = local_1e8;
              uStack_70 = uStack_1e0;
              local_b8 = CONCAT22(uStack_226,CONCAT11(bStack_227,local_228));
              local_88 = local_1f8;
              uStack_84 = uStack_1f4;
              uStack_80 = uStack_1f0;
              uStack_7c = uStack_1ec;
              local_98 = local_208;
              uStack_94 = uStack_204;
              uStack_90 = uStack_200;
              uStack_8c = uStack_1fc;
              uStack_a0 = (undefined4)uStack_210;
              uStack_9c = uStack_210._4_4_;
              uStack_b4 = uStack_224;
              uStack_b0 = (uint)uStack_220;
              uStack_ac = uStack_220._4_4_;
              local_a8 = uStack_218;
              if ((local_228 | 2) == 3) {
                uVar13 = param_2[0x7c] - 0x200;
                uVar14 = 0;
                if (0x1ff < (ulonglong)param_2[0x7c]) {
                  uVar14 = uVar13;
                }
                uVar20 = (undefined7)(uVar13 >> 8);
                local_230 = (longlong *)CONCAT44(local_230._4_4_,(int)CONCAT71(uVar20,1));
                if (uVar14 < uVar21) {
                  plVar15 = param_2 + 0x71;
                  local_230._0_4_ = (undefined4)CONCAT71(uVar20,1);
                  plVar10 = plVar15;
                  cVar7 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                          ::insert(plVar15,uVar21);
                  local_230 = (longlong *)
                              CONCAT44(local_230._4_4_,
                                       (int)CONCAT71((int7)((ulonglong)plVar10 >> 8),1));
                  if (cVar7 == '\0') {
                    uVar14 = param_2[0x7c];
                    if (uVar14 < uVar21) {
                      uVar14 = uVar21;
                    }
                    param_2[0x7c] = uVar14;
                    local_230._0_4_ = (undefined4)CONCAT71((int7)(uVar14 >> 8),1);
                    <hashbrown[ad6d4a1843b2832d]::set::HashSet<u64,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                    ::retain::
                    <<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_14_>
                              (plVar15);
                    pcVar9 = (char *)<str_as_serde_json[7404bcab4dc139c7]::value::index::Index>::
                                     index_into("age_msPlayer",6,&local_120);
                    if (pcVar9 == (char *)0x0) {
                      pcVar9 = 
                      __imp__RNvNvXs3_NtNtCs9XyX93qmSLX_10serde_json5value5indexNtB9_5ValueINtNtNtCsqJsVa2bgD3_4core3ops5index5IndexpE5index4NULL
                      ;
                    }
                    uVar14 = 0;
                    if ((*pcVar9 == '\x02') && (*(longlong *)(pcVar9 + 8) == 0)) {
                      uVar14 = 600000;
                      if (*(ulonglong *)(pcVar9 + 0x10) < 600000) {
                        uVar14 = *(ulonglong *)(pcVar9 + 0x10);
                      }
                    }
                    uVar13 = (uVar14 & 0xffffffff) / 1000;
                    iVar8 = (int)uVar13;
                    lVar22 = <std[3bf9d48a0c3997f0]::time::Instant>::checked_sub
                                       (&local_e8,uVar13,
                                        ((int)uVar14 + (int)((uVar14 & 0xffffffff) / 1000) * -1000)
                                        * 1000000);
                    if (iVar8 == -1) {
                      lVar22 = param_6;
                      iVar8 = param_7;
                    }
                    accept(param_2,&local_b8,lVar22,iVar8);
                    local_230 = (longlong *)((ulonglong)local_230._4_4_ << 0x20);
                  }
                }
                plVar15 = (longlong *)alloc[246c2e7857c81348]::boxed::box_new_uninit(8,0x20);
                lVar22 = param_2[0x78];
                local_1b0 = 0;
                local_1a0 = (longlong *)0x0;
                __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                uVar23 = 4;
                plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
                if (plVar10 != (longlong *)0x0) {
                  *(undefined4 *)plVar10 = 0x646e696b;
                  local_248 = 4;
                  local_238 = 4;
                  plStack_240 = plVar10;
                  serde_json[7404bcab4dc139c7]::value::to_value::<&&str>
                            (&local_228,&PTR_DAT_1406a14f8);
                  if (local_228 == 0xff) {
                    local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                    core[505b25137b8ba7f]::result::unwrap_failed
                              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                               &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                               &PTR_s_src_ingame_chat_transport_rs_1406a1508);
                    goto LAB_140013379;
                  }
                  local_188 = uStack_218;
                  uStack_180 = (undefined4)uStack_210;
                  uStack_17c = uStack_210._4_4_;
                  local_198 = (longlong *)
                              CONCAT44(uStack_224,
                                       CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                  uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                  <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                  ::insert(&local_228,&local_1b0,&local_248,&local_198);
                  if (local_228 != 0xff) {
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                  }
                  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                  uVar23 = 5;
                  plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                  if (plVar10 != (longlong *)0x0) {
                    *(undefined1 *)((longlong)plVar10 + 4) = 0x68;
                    *(undefined4 *)plVar10 = 0x636f7065;
                    local_248 = 5;
                    local_238 = 5;
                    plStack_240 = plVar10;
                    serde_json[7404bcab4dc139c7]::value::to_value::
                    <&alloc[246c2e7857c81348]::string::String>(&local_228,param_2 + 0xb);
                    if (local_228 == 0xff) {
                      local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                                 &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                                 &PTR_s_src_ingame_chat_transport_rs_1406a1508);
                      goto LAB_140013379;
                    }
                    local_188 = uStack_218;
                    uStack_180 = (undefined4)uStack_210;
                    uStack_17c = uStack_210._4_4_;
                    local_198 = (longlong *)
                                CONCAT44(uStack_224,
                                         CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                    uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                    ::insert(&local_228,&local_1b0,&local_248,&local_198);
                    if (local_228 != 0xff) {
                      core[505b25137b8ba7f]::ptr::drop_glue::
                      <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                    }
                    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                    uVar23 = 5;
                    plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
                    if (plVar10 != (longlong *)0x0) {
                      *(undefined1 *)((longlong)plVar10 + 4) = 0x65;
                      *(undefined4 *)plVar10 = 0x636e6f6e;
                      local_248 = 5;
                      local_238 = 5;
                      plStack_240 = plVar10;
                      serde_json[7404bcab4dc139c7]::value::to_value::
                      <&alloc[246c2e7857c81348]::string::String>(&local_228,plVar18);
                      if (local_228 == 0xff) {
                        local_198 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                        core[505b25137b8ba7f]::result::unwrap_failed
                                  ("called `Result::unwrap()` on an `Err` value",0x2b,&local_198,
                                   &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                                   &PTR_s_src_ingame_chat_transport_rs_1406a1508);
                        goto LAB_140013379;
                      }
                      local_188 = uStack_218;
                      uStack_180 = (undefined4)uStack_210;
                      uStack_17c = uStack_210._4_4_;
                      local_198 = (longlong *)
                                  CONCAT44(uStack_224,
                                           CONCAT22(uStack_226,CONCAT11(bStack_227,local_228)));
                      uStack_190 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
                      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                      ::insert(&local_228,&local_1b0,&local_248,&local_198);
                      if (local_228 != 0xff) {
                        core[505b25137b8ba7f]::ptr::drop_glue::
                        <serde_json[7404bcab4dc139c7]::value::Value>(&local_228);
                      }
                      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
                      uVar23 = 2;
                      plVar10 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(2,1);
                      if (plVar10 != (longlong *)0x0) {
                        *(undefined2 *)plVar10 = 0x6469;
                        local_248 = 2;
                        local_238 = 2;
                        local_228 = 2;
                        uStack_220._0_4_ = 0;
                        uStack_220._4_4_ = 0;
                        uStack_218._0_4_ = (undefined4)uVar21;
                        uStack_218._4_4_ = (uint)(uVar21 >> 0x20);
                        plStack_240 = plVar10;
                        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                        ::insert(&local_198,&local_1b0,&local_248,&local_228);
                        if ((char)local_198 != -1) {
                          core[505b25137b8ba7f]::ptr::drop_glue::
                          <serde_json[7404bcab4dc139c7]::value::Value>(&local_198);
                        }
                        uStack_220._0_4_ = (undefined4)local_1b0;
                        uStack_220._4_4_ = local_1b0._4_4_;
                        uStack_218._0_4_ = uStack_1a8;
                        uStack_218._4_4_ = uStack_1a4;
                        uStack_210 = local_1a0;
                        local_228 = 5;
                        host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet
                                  (&local_198,&local_228);
                        local_228 = (byte)local_198;
                        bStack_227 = (byte)((ulonglong)local_198 >> 8);
                        uStack_226 = (undefined2)((ulonglong)local_198 >> 0x10);
                        uStack_224 = (uint)((ulonglong)local_198 >> 0x20);
                        *plVar15 = lVar22;
                        *(int *)(plVar15 + 1) = (int)local_198;
                        *(uint *)((longlong)plVar15 + 0xc) = uStack_224;
                        plVar15[2] = (longlong)uStack_190;
                        plVar15[3] = (longlong)local_188;
                        *param_1 = 1;
                        param_1[1] = plVar15;
                        param_1[2] = 1;
                        uStack_218 = local_188;
                        uStack_220 = uStack_190;
                        if ((char)local_230 == '\0') goto LAB_140012a8d;
                        goto LAB_140012d38;
                      }
                    }
                  }
                }
                alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar23);
LAB_140013379:
                    /* WARNING: Does not return */
                pcVar2 = (code *)invalidInstructionException();
                (*pcVar2)();
              }
              *param_1 = 0;
              param_1[1] = 8;
              param_1[2] = 0;
              uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
LAB_140012d38:
              core[505b25137b8ba7f]::ptr::drop_glue::
              <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(&local_b8);
              goto LAB_140012a8d;
            }
            core[505b25137b8ba7f]::ptr::drop_glue::
            <core[505b25137b8ba7f]::result::Result<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,serde_json[7404bcab4dc139c7]::error::Error>>
                      (&local_228);
            uStack_220 = (longlong *)CONCAT44(uStack_220._4_4_,(uint)uStack_220);
          }
        }
      }
    }
  }
LAB_140012a76:
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
LAB_140012a8d:
  core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(&local_120);
  return;
}

