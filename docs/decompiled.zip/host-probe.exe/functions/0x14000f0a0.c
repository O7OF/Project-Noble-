// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::submit
// address: 0x14000f0a0
// body: available
// range: 0x14000f0a0-0x14000f195 inclusive
// range: 0x14000f197-0x14000f5ca inclusive
// range: 0x14000f5d0-0x14000f5e0 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000f191 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000f5c6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::submit */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::submit
          (undefined8 *param_1,longlong param_2,longlong *param_3,char param_4,undefined8 param_5,
          undefined8 param_6,longlong param_7,undefined4 param_8)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  code *pcVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  longlong *plVar9;
  longlong lVar10;
  int iVar11;
  longlong local_1d8;
  longlong lStack_1d0;
  undefined4 local_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 local_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 local_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined4 uStack_19c;
  undefined8 local_198;
  undefined8 uStack_190;
  undefined8 local_188;
  undefined8 uStack_180;
  undefined8 local_178;
  undefined8 uStack_170;
  undefined1 local_160 [8];
  undefined8 local_158;
  undefined8 local_150;
  undefined8 local_148;
  undefined8 uStack_140;
  undefined1 local_128;
  char cStack_127;
  undefined2 uStack_126;
  int iStack_124;
  longlong lStack_120;
  undefined8 local_118;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 local_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 local_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined4 uStack_b4;
  undefined4 local_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 local_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 local_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 local_50;
  undefined8 uStack_48;
  
  local_1d8 = param_7;
  lStack_1d0 = CONCAT44(lStack_1d0._4_4_,param_8);
  lVar1 = *(longlong *)(param_2 + 0x3b8);
  lVar2 = *(longlong *)(param_2 + 0x3c0);
  if (lVar1 == lVar2) {
    if (*(longlong *)(param_2 + 0xb8) != 0) {
      lVar10 = 0;
      do {
        if (*(longlong *)(*(longlong *)(param_2 + 0xb0) + 0x18 + lVar10) == lVar1)
        goto LAB_14000f146;
        lVar10 = lVar10 + 0x28;
      } while (*(longlong *)(param_2 + 0xb8) * 0x28 != lVar10);
    }
LAB_14000f165:
    param_1[1] = "Match chat works in online games (hosted or joined), once the host is connected.";
    param_1[2] = 0x50;
  }
  else {
    if ((*(int *)(param_2 + 0x350) == -1) ||
       (uVar8 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&local_1d8), 1 < uVar8))
    goto LAB_14000f165;
LAB_14000f146:
    if (*(longlong *)(param_2 + 0x288) == -1) {
      if (param_4 == '\x03') {
LAB_14000f224:
        reach_directory[4b72b9694f6c3c08]::chat::clean(&local_1d8,param_5,param_6);
        if (local_1d8 != -1) {
          if (*(int *)(param_2 + 1000) != -1) {
            uStack_110 = local_1c8;
            uStack_10c = uStack_1c4;
            iVar11 = *(int *)(param_2 + 1000) + 1;
            *(int *)(param_2 + 1000) = iVar11;
            lStack_120 = local_1d8;
            local_118 = lStack_1d0;
            local_128 = 0;
            lVar10 = *param_3;
            lVar3 = param_3[1];
            lVar4 = param_3[2];
            cStack_127 = param_4;
            iStack_124 = iVar11;
            <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_core[505b25137b8ba7f]::clone::Clone>
            ::clone(&local_1d8,&local_128);
            local_50 = local_178;
            uVar6 = local_50;
            uStack_48 = uStack_170;
            uVar7 = uStack_48;
            local_60 = (undefined4)local_188;
            uStack_5c = (undefined4)((ulonglong)local_188 >> 0x20);
            uStack_58 = (undefined4)uStack_180;
            uStack_54 = (undefined4)((ulonglong)uStack_180 >> 0x20);
            local_70 = (undefined4)local_198;
            uStack_6c = (undefined4)((ulonglong)local_198 >> 0x20);
            uStack_68 = (undefined4)uStack_190;
            uStack_64 = (undefined4)((ulonglong)uStack_190 >> 0x20);
            local_b0 = (undefined4)local_1d8;
            uStack_ac = (undefined4)((ulonglong)local_1d8 >> 0x20);
            uStack_a8 = (undefined4)lStack_1d0;
            uStack_a4 = (undefined4)((ulonglong)lStack_1d0 >> 0x20);
            *(longlong *)(param_2 + 0x288) = lVar10;
            *(longlong *)(param_2 + 0x290) = lVar3;
            *(longlong *)(param_2 + 0x298) = lVar4;
            *(longlong *)(param_2 + 0x2a0) = param_7;
            *(undefined4 *)(param_2 + 0x2a8) = param_8;
            *(longlong *)(param_2 + 0x2b0) = param_7;
            *(undefined4 *)(param_2 + 0x2b8) = param_8;
            *(ulonglong *)(param_2 + 700) = CONCAT44(local_b0,uStack_b4);
            *(ulonglong *)(param_2 + 0x2c4) = CONCAT44(uStack_a8,uStack_ac);
            *(undefined4 *)(param_2 + 0x2cc) = uStack_a4;
            *(undefined4 *)(param_2 + 0x2d0) = local_1c8;
            *(undefined4 *)(param_2 + 0x2d4) = uStack_1c4;
            *(undefined4 *)(param_2 + 0x2d8) = uStack_1c0;
            *(undefined4 *)(param_2 + 0x2dc) = uStack_1bc;
            *(undefined4 *)(param_2 + 0x2e0) = local_1b8;
            *(undefined4 *)(param_2 + 0x2e4) = uStack_1b4;
            *(undefined4 *)(param_2 + 0x2e8) = uStack_1b0;
            *(undefined4 *)(param_2 + 0x2ec) = uStack_1ac;
            *(undefined4 *)(param_2 + 0x2f0) = local_1a8;
            *(undefined4 *)(param_2 + 0x2f4) = uStack_1a4;
            *(undefined4 *)(param_2 + 0x2f8) = uStack_1a0;
            *(ulonglong *)(param_2 + 0x2fc) = CONCAT44(local_70,uStack_19c);
            *(ulonglong *)(param_2 + 0x304) = CONCAT44(uStack_68,uStack_6c);
            *(ulonglong *)(param_2 + 0x30c) = CONCAT44(local_60,uStack_64);
            *(ulonglong *)(param_2 + 0x314) = CONCAT44(uStack_58,uStack_5c);
            local_50._0_4_ = (undefined4)local_178;
            local_50._4_4_ = (undefined4)((ulonglong)local_178 >> 0x20);
            uStack_48._0_4_ = (undefined4)uStack_170;
            *(undefined4 *)(param_2 + 0x31c) = uStack_54;
            *(undefined4 *)(param_2 + 800) = (undefined4)local_50;
            *(undefined4 *)(param_2 + 0x324) = local_50._4_4_;
            *(undefined4 *)(param_2 + 0x328) = (undefined4)uStack_48;
            uStack_48._4_4_ = (undefined4)((ulonglong)uStack_170 >> 0x20);
            *(undefined4 *)(param_2 + 0x32c) = uStack_48._4_4_;
            *(int *)(param_2 + 0x330) = iVar11;
            *(undefined1 *)(param_2 + 0x334) = 1;
            local_50 = uVar6;
            uStack_48 = uVar7;
            if (lVar1 == lVar2) {
              local_178 = local_c8;
              uStack_170 = uStack_c0;
              local_188 = local_d8;
              uStack_180 = uStack_d0;
              local_198 = local_e8;
              uStack_190 = uStack_e0;
              local_1d8 = CONCAT44(iStack_124,CONCAT22(uStack_126,CONCAT11(cStack_127,local_128)));
              local_1a8 = local_f8;
              uStack_1a4 = uStack_f4;
              uStack_1a0 = uStack_f0;
              uStack_19c = uStack_ec;
              local_1b8 = local_108;
              uStack_1b4 = uStack_104;
              uStack_1b0 = uStack_100;
              uStack_1ac = uStack_fc;
              local_1c8 = (undefined4)local_118;
              uStack_1c4 = local_118._4_4_;
              uStack_1c0 = uStack_110;
              uStack_1bc = uStack_10c;
              lStack_1d0 = lStack_120;
              <reach_directory[4b72b9694f6c3c08]::chat::HostRelay>::on_datagram
                        (local_160,param_2 + 0xc0,lVar1,&local_1d8,*(undefined4 *)(param_2 + 0xb0),
                         *(undefined4 *)(param_2 + 0xb8),param_7,param_8,0);
              keep_general(param_2,local_158,local_150,param_7,param_8);
              deliver(param_1,param_2,local_160,param_7,param_8);
              return;
            }
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            plVar9 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x20,8);
            if (plVar9 != (longlong *)0x0) {
              say_packet(&local_1d8,param_2,&local_128);
              local_148 = local_1d8;
              lVar1 = local_148;
              uStack_140 = lStack_1d0;
              uVar6 = uStack_140;
              *plVar9 = lVar2;
              local_148._0_4_ = (undefined4)local_1d8;
              local_148._4_4_ = (undefined4)((ulonglong)local_1d8 >> 0x20);
              uStack_140._0_4_ = (undefined4)lStack_1d0;
              uStack_140._4_4_ = (undefined4)((ulonglong)lStack_1d0 >> 0x20);
              *(undefined4 *)(plVar9 + 1) = (undefined4)local_148;
              *(undefined4 *)((longlong)plVar9 + 0xc) = local_148._4_4_;
              *(undefined4 *)(plVar9 + 2) = (undefined4)uStack_140;
              *(undefined4 *)((longlong)plVar9 + 0x14) = uStack_140._4_4_;
              plVar9[3] = CONCAT44(uStack_1c4,local_1c8);
              *param_1 = 1;
              param_1[1] = plVar9;
              param_1[2] = 1;
              local_148 = lVar1;
              uStack_140 = uVar6;
              core[505b25137b8ba7f]::ptr::drop_glue::
              <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(&local_128);
              return;
            }
            alloc[246c2e7857c81348]::alloc::handle_alloc_error(8,0x20);
                    /* WARNING: Does not return */
            pcVar5 = (code *)invalidInstructionException();
            (*pcVar5)();
          }
          param_1[1] = "Chat sequence exhausted; rejoin.";
          param_1[2] = 0x20;
          *param_1 = 0xffffffffffffffff;
          if (local_1d8 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(lStack_1d0,local_1d8,1);
            return;
          }
          goto LAB_14000f17f;
        }
        param_1[1] = "Type a message first.";
        param_1[2] = 0x15;
      }
      else if (param_4 == '\x04') {
        if (lVar1 == lVar2) {
          if (*(longlong *)(param_2 + 0xb8) != 0) {
            lVar10 = 0;
            do {
              if ((*(longlong *)(*(longlong *)(param_2 + 0xb0) + 0x18 + lVar10) == lVar1) &&
                 (-1 < *(char *)(*(longlong *)(param_2 + 0xb0) + 0x24 + lVar10)))
              goto LAB_14000f224;
              lVar10 = lVar10 + 0x28;
            } while (*(longlong *)(param_2 + 0xb8) * 0x28 != lVar10);
          }
        }
        else if (*(char *)(param_2 + 0x3ec) != '\0') goto LAB_14000f224;
        param_1[1] = "There are no teams in this game.";
        param_1[2] = 0x20;
      }
      else {
        param_1[1] = "Invalid channel.";
        param_1[2] = 0x10;
      }
    }
    else {
      param_1[1] = "A message is still being sent.";
      param_1[2] = 0x1e;
    }
  }
  *param_1 = 0xffffffffffffffff;
LAB_14000f17f:
  if (*param_3 == 0) {
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(param_3[1],*param_3,1);
  return;
}

