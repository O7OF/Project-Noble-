// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<[f32;16usize]>>::resize
// address: 0x140046d00
// body: available
// range: 0x140046d00-0x140046ee5 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<[f32; 16usize]>>::resize */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<[f32;16usize]>>::resize
          (longlong *param_1,ulonglong param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  ulonglong uVar12;
  
  uVar9 = param_1[2];
  uVar10 = param_2 - uVar9;
  if (uVar9 <= param_2 && uVar10 != 0) {
    uVar8 = uVar9;
    if (*param_1 - uVar9 < uVar10) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(param_1,uVar9,uVar10,4,0x40);
      uVar8 = param_1[2];
    }
    puVar11 = (undefined8 *)(uVar8 * 0x40 + param_1[1]);
    if (1 < uVar10) {
      uVar12 = (ulonglong)((uint)(param_2 + ~uVar9) & 3);
      if (uVar10 - 2 < 3) goto LAB_140046e40;
      uVar9 = param_2 + ~uVar9 & 0xfffffffffffffffc;
      do {
        uVar1 = *param_3;
        uVar2 = param_3[1];
        uVar3 = param_3[2];
        uVar4 = param_3[3];
        uVar5 = param_3[4];
        uVar6 = param_3[5];
        uVar7 = param_3[7];
        puVar11[6] = param_3[6];
        puVar11[7] = uVar7;
        puVar11[4] = uVar5;
        puVar11[5] = uVar6;
        puVar11[2] = uVar3;
        puVar11[3] = uVar4;
        *puVar11 = uVar1;
        puVar11[1] = uVar2;
        uVar1 = *param_3;
        uVar2 = param_3[1];
        uVar3 = param_3[2];
        uVar4 = param_3[3];
        uVar5 = param_3[4];
        uVar6 = param_3[5];
        uVar7 = param_3[7];
        puVar11[0xe] = param_3[6];
        puVar11[0xf] = uVar7;
        puVar11[0xc] = uVar5;
        puVar11[0xd] = uVar6;
        puVar11[10] = uVar3;
        puVar11[0xb] = uVar4;
        puVar11[8] = uVar1;
        puVar11[9] = uVar2;
        uVar1 = *param_3;
        uVar2 = param_3[1];
        uVar3 = param_3[2];
        uVar4 = param_3[3];
        uVar5 = param_3[4];
        uVar6 = param_3[5];
        uVar7 = param_3[7];
        puVar11[0x16] = param_3[6];
        puVar11[0x17] = uVar7;
        puVar11[0x14] = uVar5;
        puVar11[0x15] = uVar6;
        puVar11[0x12] = uVar3;
        puVar11[0x13] = uVar4;
        puVar11[0x10] = uVar1;
        puVar11[0x11] = uVar2;
        uVar1 = param_3[1];
        uVar2 = param_3[2];
        uVar3 = param_3[3];
        uVar4 = param_3[4];
        uVar5 = param_3[5];
        uVar6 = param_3[6];
        uVar7 = param_3[7];
        puVar11[0x18] = *param_3;
        puVar11[0x19] = uVar1;
        puVar11[0x1a] = uVar2;
        puVar11[0x1b] = uVar3;
        puVar11[0x1c] = uVar4;
        puVar11[0x1d] = uVar5;
        puVar11[0x1e] = uVar6;
        puVar11[0x1f] = uVar7;
        puVar11 = puVar11 + 0x20;
        uVar9 = uVar9 - 4;
      } while (uVar9 != 0);
      for (; uVar12 != 0; uVar12 = uVar12 - 1) {
LAB_140046e40:
        uVar1 = *param_3;
        uVar2 = param_3[1];
        uVar3 = param_3[2];
        uVar4 = param_3[3];
        uVar5 = param_3[4];
        uVar6 = param_3[5];
        uVar7 = param_3[7];
        puVar11[6] = param_3[6];
        puVar11[7] = uVar7;
        puVar11[4] = uVar5;
        puVar11[5] = uVar6;
        puVar11[2] = uVar3;
        puVar11[3] = uVar4;
        *puVar11 = uVar1;
        puVar11[1] = uVar2;
        puVar11 = puVar11 + 8;
      }
      uVar8 = (uVar8 + uVar10) - 1;
    }
    uVar1 = *param_3;
    uVar2 = param_3[1];
    uVar3 = param_3[2];
    uVar4 = param_3[3];
    uVar5 = param_3[4];
    uVar6 = param_3[5];
    uVar7 = param_3[7];
    puVar11[6] = param_3[6];
    puVar11[7] = uVar7;
    puVar11[4] = uVar5;
    puVar11[5] = uVar6;
    puVar11[2] = uVar3;
    puVar11[3] = uVar4;
    *puVar11 = uVar1;
    puVar11[1] = uVar2;
    param_2 = uVar8 + 1;
  }
  param_1[2] = param_2;
  return;
}

