// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::coopx::ff_message::{closure#1}>>
// address: 0x140044050
// body: available
// range: 0x140044050-0x14004413f inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::coopx::ff_message::{closure#1}>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::coopx::ff_message::_closure_1_>>
          (longlong *param_1,longlong *param_2)

{
  undefined1 *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong lVar7;
  uint uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  
  uVar10 = param_2[1];
  uVar2 = param_2[2];
  uVar6 = 0;
  if (uVar10 <= uVar2) {
    uVar6 = uVar2 - uVar10;
  }
  lVar4 = param_1[2];
  if ((ulonglong)(*param_1 - lVar4) < uVar6) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>();
    lVar4 = param_1[2];
  }
  if (uVar10 < uVar2) {
    uVar6 = uVar10 - uVar2;
    lVar3 = param_1[1];
    lVar5 = *param_2;
    uVar8 = (int)uVar2 - (int)uVar10 & 3;
    uVar9 = (ulonglong)uVar8;
    if (uVar8 != 0) {
      do {
        puVar1 = (undefined1 *)(lVar5 + uVar10);
        uVar10 = uVar10 + 1;
        *(undefined1 *)(lVar3 + lVar4) = *puVar1;
        lVar4 = lVar4 + 1;
        uVar9 = uVar9 - 1;
      } while (uVar9 != 0);
    }
    if (uVar6 < 0xfffffffffffffffd) {
      lVar3 = lVar3 + lVar4;
      lVar5 = lVar5 + uVar10;
      lVar7 = 0;
      do {
        *(undefined1 *)(lVar3 + lVar7) = *(undefined1 *)(lVar5 + lVar7);
        *(undefined1 *)(lVar3 + 1 + lVar7) = *(undefined1 *)(lVar5 + 1 + lVar7);
        *(undefined1 *)(lVar3 + 2 + lVar7) = *(undefined1 *)(lVar5 + 2 + lVar7);
        *(undefined1 *)(lVar3 + 3 + lVar7) = *(undefined1 *)(lVar5 + 3 + lVar7);
        lVar7 = lVar7 + 4;
      } while (uVar2 - uVar10 != lVar7);
      lVar4 = lVar4 + lVar7;
    }
  }
  param_1[2] = lVar4;
  return;
}

