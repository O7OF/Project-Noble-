// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
// address: 0x140003e60
// body: available
// range: 0x140003e60-0x140003eff inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140003e9f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003eb7 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003ecf to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003ee7 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
          (undefined1 *param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = 8;
  switch(*param_1) {
  case 0:
  case 3:
    lVar1 = *(longlong *)(param_1 + 8);
    break;
  case 2:
    goto switchD_140003e84_caseD_2;
  default:
    if (*(longlong *)(param_1 + 8) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (*(undefined8 *)(param_1 + 0x10),*(longlong *)(param_1 + 8),1);
      return;
    }
  case 1:
    if (*(longlong *)(param_1 + 0x20) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (*(undefined8 *)(param_1 + 0x28),*(longlong *)(param_1 + 0x20),1);
      return;
    }
    if (*(longlong *)(param_1 + 0x38) != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc
                (*(undefined8 *)(param_1 + 0x40),*(longlong *)(param_1 + 0x38),1);
      return;
    }
    lVar2 = 0x50;
    lVar1 = *(longlong *)(param_1 + 0x50);
  }
  if (lVar1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(*(undefined8 *)(param_1 + lVar2 + 8),lVar1,1);
    return;
  }
switchD_140003e84_caseD_2:
  return;
}

