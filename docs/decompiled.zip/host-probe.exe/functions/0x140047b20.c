// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>>::remove
// address: 0x140047b20
// body: available
// range: 0x140047b20-0x140047bc2 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>>::remove */

char * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>>::remove
          (char *param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  char cVar2;
  longlong lVar3;
  code *pcVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined8 uVar7;
  longlong lVar8;
  ulonglong uVar9;
  undefined1 local_49;
  undefined7 uStack_48;
  
  uVar9 = *(ulonglong *)(param_2 + 0x10);
  if (param_3 < uVar9) {
    lVar3 = *(longlong *)(param_2 + 8);
    lVar8 = param_3 * 0x20;
    cVar2 = *(char *)(lVar3 + lVar8);
    puVar1 = (undefined8 *)(lVar3 + 0x10 + lVar8);
    uVar5 = puVar1[1];
    uStack_48 = (undefined7)((ulonglong)*puVar1 >> 8);
    puVar1 = (undefined8 *)(lVar3 + 1 + lVar8);
    uVar6 = *puVar1;
    uVar7 = puVar1[1];
    local_49 = (undefined1)((ulonglong)uVar7 >> 0x38);
    memmove((void *)(lVar3 + lVar8),(void *)(lVar8 + lVar3 + 0x20),(~param_3 + uVar9) * 0x20);
    uVar9 = uVar9 - 1;
    *(ulonglong *)(param_2 + 0x10) = uVar9;
    if (cVar2 != -1) {
      *param_1 = cVar2;
      *(undefined8 *)(param_1 + 1) = uVar6;
      *(undefined8 *)(param_1 + 9) = uVar7;
      *(ulonglong *)(param_1 + 0x10) = CONCAT71(uStack_48,local_49);
      *(undefined8 *)(param_1 + 0x18) = uVar5;
      return param_1;
    }
  }
  <alloc[246c2e7857c81348]::vec::Vec<_,_>>::remove::assert_failed(param_3,uVar9,param_4);
                    /* WARNING: Does not return */
  pcVar4 = (code *)invalidInstructionException();
  (*pcVar4)();
}

