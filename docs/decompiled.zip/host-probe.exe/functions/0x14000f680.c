// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::deliver
// address: 0x14000f680
// body: available
// range: 0x14000f680-0x14000f794 inclusive
// range: 0x14000f7a0-0x14000fb83 inclusive
// range: 0x14000fb90-0x14000ff86 inclusive
// range: 0x14000ff90-0x14000ffaf inclusive
// range: 0x14000ffb2-0x1400104a6 inclusive
// range: 0x1400104b0-0x1400104cf inclusive
// range: 0x1400104e0-0x140010562 inclusive
// range: 0x140010570-0x1400107e0 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000fb7f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000feee to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000ffab to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000ffcb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001026d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400104cb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140010500 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::deliver */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::deliver
          (longlong *param_1,undefined1 (**param_2) [16],longlong *param_3,longlong param_4,
          undefined4 param_5)

{
  char *pcVar1;
  longlong ******pppppplVar2;
  longlong ******pppppplVar3;
  longlong lVar4;
  code *pcVar5;
  uint uVar6;
  int iVar7;
  undefined1 uVar8;
  undefined *puVar9;
  longlong *plVar10;
  longlong *******ppppppplVar11;
  ulonglong uVar12;
  undefined8 *puVar13;
  void *_Src;
  longlong *******ppppppplVar14;
  undefined1 (**_Dst) [16];
  undefined1 (*pauVar15) [16];
  undefined1 (*pauVar16) [16];
  longlong lVar17;
  undefined1 (**ppauVar18) [16];
  undefined1 (*pauVar19) [16];
  undefined8 uVar20;
  uint uVar21;
  longlong lVar22;
  ulonglong uVar23;
  longlong *******ppppppplVar24;
  undefined1 (*pauVar25) [16];
  DWORD dwTlsIndex;
  undefined1 (*pauVar26) [16];
  byte bVar27;
  ulonglong uVar28;
  ushort uVar29;
  ulonglong uVar30;
  undefined8 uVar31;
  undefined2 uVar32;
  uint uVar33;
  byte bVar34;
  undefined1 auVar35 [16];
  undefined1 auVar36 [16];
  undefined1 auVar37 [16];
  undefined1 auVar38 [16];
  undefined1 auVar39 [16];
  undefined1 auVar40 [16];
  undefined1 auVar41 [16];
  undefined1 unaff_XMM6_Ba;
  char cVar42;
  undefined1 unaff_XMM6_Bb;
  char cVar43;
  undefined1 unaff_XMM6_Bc;
  char cVar44;
  undefined1 unaff_XMM6_Bd;
  char cVar45;
  undefined1 unaff_XMM6_Be;
  char cVar46;
  undefined1 unaff_XMM6_Bf;
  char cVar47;
  undefined1 unaff_XMM6_Bg;
  char cVar48;
  undefined1 unaff_XMM6_Bh;
  char cVar49;
  undefined1 unaff_XMM6_Bi;
  char cVar50;
  undefined1 unaff_XMM6_Bj;
  char cVar51;
  undefined1 unaff_XMM6_Bk;
  char cVar52;
  undefined1 unaff_XMM6_Bl;
  char cVar53;
  undefined1 unaff_XMM6_Bm;
  char cVar54;
  undefined1 unaff_XMM6_Bn;
  char cVar55;
  undefined1 unaff_XMM6_Bo;
  char cVar56;
  undefined1 unaff_XMM6_Bp;
  char cVar57;
  undefined1 local_381;
  longlong *******local_380;
  longlong *******local_378;
  longlong *******ppppppplStack_370;
  undefined1 (**local_368) [16];
  longlong *******ppppppplStack_360;
  undefined1 (**local_358) [16];
  longlong local_350;
  longlong *******local_348;
  longlong *******ppppppplStack_340;
  undefined1 (**local_338) [16];
  longlong *******ppppppplStack_330;
  longlong local_328;
  longlong lStack_320;
  longlong local_318;
  longlong *******local_310;
  undefined8 local_308;
  undefined8 *local_300;
  undefined8 local_2f8;
  longlong local_2f0;
  undefined1 (**local_2e8) [16];
  longlong local_2e0;
  undefined1 (*local_2d8) [16];
  undefined1 (*local_2d0) [16];
  code *pcStack_2c8;
  undefined1 local_2c0 [16];
  undefined8 local_2b0;
  undefined8 uStack_2a8;
  undefined4 local_2a0;
  undefined4 uStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined8 local_290;
  undefined8 uStack_288;
  undefined8 local_280;
  undefined8 uStack_278;
  undefined8 local_270;
  undefined8 uStack_268;
  longlong local_260;
  undefined1 local_258;
  longlong local_250;
  longlong local_248;
  longlong lStack_240;
  longlong local_238;
  undefined8 uStack_230;
  undefined8 local_228;
  longlong *******local_220;
  undefined1 (*local_218) [16];
  longlong lStack_210;
  undefined8 uStack_208;
  undefined8 uStack_200;
  undefined1 local_1f8 [16];
  longlong local_1e8;
  longlong lStack_1e0;
  longlong local_1d8;
  longlong lStack_1d0;
  longlong *local_1c0;
  undefined1 (*local_1b8) [16];
  longlong *local_1b0;
  undefined1 (*local_1a8) [16];
  code *pcStack_1a0;
  undefined8 local_198;
  undefined8 uStack_190;
  undefined8 local_188;
  undefined8 uStack_180;
  undefined4 local_178;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined8 local_168;
  undefined8 uStack_160;
  undefined8 local_158;
  undefined8 uStack_150;
  undefined8 local_148;
  undefined8 uStack_140;
  undefined8 local_100;
  undefined8 uStack_f8;
  undefined8 local_f0;
  undefined8 local_e8;
  code *pcStack_e0;
  undefined1 local_d8 [16];
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  longlong local_78;
  longlong lStack_70;
  
  puVar9 = 
  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
  ;
  local_328 = 0;
  lStack_320 = 8;
  local_318 = 0;
  local_350 = param_4;
  local_1c0 = param_3;
  local_1b0 = param_1;
  if (*(longlong *)
       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
      != 0) {
    std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
  }
  if (*(int *)(puVar9 + 0x18) == 0) {
    dwTlsIndex = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                           (
                           __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                           );
    plVar10 = TlsGetValue(dwTlsIndex);
  }
  else {
    dwTlsIndex = *(int *)(puVar9 + 0x18) - 1;
    plVar10 = TlsGetValue(dwTlsIndex);
  }
  if (plVar10 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    plVar10 = (longlong *)
              <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
              ::try_initialize::
              <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                        (dwTlsIndex,plVar10);
  }
  if (plVar10 == (longlong *)0x0) {
    std[3bf9d48a0c3997f0]::thread::local::panic_access_error
              (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
LAB_1400107df:
                    /* WARNING: Does not return */
    pcVar5 = (code *)invalidInstructionException();
    (*pcVar5)();
  }
  local_1d8 = *plVar10;
  lStack_1d0 = plVar10[1];
  *plVar10 = *plVar10 + 1;
  local_1e8 = 0;
  lStack_1e0 = 0;
  local_1f8 = _PTR_DAT_1406a0550;
  ppauVar18 = (undefined1 (**) [16])*param_3;
  ppppppplVar24 = (longlong *******)param_3[1];
  ppppppplVar14 = ppppppplVar24 + param_3[2] * 4;
  local_380 = ppppppplVar24;
  local_378 = ppppppplVar24;
  local_368 = ppauVar18;
  ppppppplStack_360 = ppppppplVar14;
  local_358 = ppauVar18;
  if (param_3[2] == 0) {
LAB_14000ff78:
    if ((longlong)ppppppplVar14 - (longlong)ppppppplVar24 != 0) {
      uVar28 = (ulonglong)((longlong)ppppppplVar14 - (longlong)ppppppplVar24) >> 5;
      ppppppplVar24 = ppppppplVar24 + 2;
      do {
        if (ppppppplVar24[-1] != (longlong ******)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*ppppppplVar24,ppppppplVar24[-1],1);
          return;
        }
        ppppppplVar24 = ppppppplVar24 + 4;
        uVar28 = uVar28 - 1;
      } while (uVar28 != 0);
    }
  }
  else {
    iVar7 = -(uint)(CONCAT13(unaff_XMM6_Bd,
                             CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))) ==
                   CONCAT13(unaff_XMM6_Bd,
                            CONCAT12(unaff_XMM6_Bc,CONCAT11(unaff_XMM6_Bb,unaff_XMM6_Ba))));
    cVar42 = (char)iVar7;
    cVar43 = (char)((uint)iVar7 >> 8);
    cVar44 = (char)((uint)iVar7 >> 0x10);
    cVar45 = (char)((uint)iVar7 >> 0x18);
    iVar7 = -(uint)(CONCAT13(unaff_XMM6_Bh,
                             CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))) ==
                   CONCAT13(unaff_XMM6_Bh,
                            CONCAT12(unaff_XMM6_Bg,CONCAT11(unaff_XMM6_Bf,unaff_XMM6_Be))));
    cVar46 = (char)iVar7;
    cVar47 = (char)((uint)iVar7 >> 8);
    cVar48 = (char)((uint)iVar7 >> 0x10);
    cVar49 = (char)((uint)iVar7 >> 0x18);
    iVar7 = -(uint)(CONCAT13(unaff_XMM6_Bl,
                             CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))) ==
                   CONCAT13(unaff_XMM6_Bl,
                            CONCAT12(unaff_XMM6_Bk,CONCAT11(unaff_XMM6_Bj,unaff_XMM6_Bi))));
    cVar50 = (char)iVar7;
    cVar51 = (char)((uint)iVar7 >> 8);
    cVar52 = (char)((uint)iVar7 >> 0x10);
    cVar53 = (char)((uint)iVar7 >> 0x18);
    iVar7 = -(uint)(CONCAT13(unaff_XMM6_Bp,
                             CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))) ==
                   CONCAT13(unaff_XMM6_Bp,
                            CONCAT12(unaff_XMM6_Bo,CONCAT11(unaff_XMM6_Bn,unaff_XMM6_Bm))));
    cVar54 = (char)iVar7;
    cVar55 = (char)((uint)iVar7 >> 8);
    cVar56 = (char)((uint)iVar7 >> 0x10);
    cVar57 = (char)((uint)iVar7 >> 0x18);
    ppppppplVar11 = ppppppplVar24;
    do {
      ppppppplVar24 = ppppppplVar11 + 4;
      pppppplVar2 = ppppppplVar11[1];
      ppppppplStack_370 = ppppppplVar24;
      if (pppppplVar2 == (longlong ******)0xffffffffffffffff) goto LAB_14000ff78;
      pppppplVar3 = ppppppplVar11[2];
      local_218 = (undefined1 (*) [16])*ppppppplVar11;
      ppauVar18 = &local_1a8;
      reach_directory[4b72b9694f6c3c08]::chat::decode(ppauVar18,pppppplVar3);
      pauVar16 = local_218;
      if ((char)local_1a8 != -1) {
        local_88 = local_148;
        uStack_80 = uStack_140;
        local_98 = local_158;
        uStack_90 = uStack_150;
        local_a8 = local_168;
        uStack_a0 = uStack_160;
        local_d8._8_8_ = uStack_190;
        local_d8._0_8_ = local_198;
        local_b8 = local_178;
        uStack_b4 = uStack_174;
        uStack_b0 = uStack_170;
        uStack_ac = uStack_16c;
        local_c8 = local_188;
        uStack_c0 = uStack_180;
        local_e8 = local_1a8;
        pcStack_e0 = pcStack_1a0;
        pauVar26 = param_2[0x77];
        if ((char)local_1a8 == '\x01') {
          if (local_218 == pauVar26) {
LAB_14000f890:
            uVar20 = local_d8._0_8_;
            local_1a8 = (undefined1 (*) [16])local_d8._0_8_;
            uVar12 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                     ::hash_one::<&usize>(&local_1d8);
            bVar27 = (byte)(uVar12 >> 0x38);
            bVar34 = bVar27 >> 1;
            auVar35 = ZEXT216(CONCAT11(bVar34,bVar34));
            auVar35 = pshuflw(auVar35,auVar35,0);
            lVar22 = 0;
            uVar28 = uVar12;
            while( true ) {
              uVar28 = uVar28 & local_1f8._8_8_;
              auVar41 = *(undefined1 (*) [16])((undefined1 *)local_1f8._0_8_ + uVar28);
              auVar39[0] = -(auVar41[0] == auVar35[0]);
              auVar39[1] = -(auVar41[1] == auVar35[1]);
              auVar39[2] = -(auVar41[2] == auVar35[2]);
              auVar39[3] = -(auVar41[3] == auVar35[3]);
              auVar39[4] = -(auVar41[4] == auVar35[4]);
              auVar39[5] = -(auVar41[5] == auVar35[5]);
              auVar39[6] = -(auVar41[6] == auVar35[6]);
              auVar39[7] = -(auVar41[7] == auVar35[7]);
              auVar39[8] = -(auVar41[8] == auVar35[0]);
              auVar39[9] = -(auVar41[9] == auVar35[1]);
              auVar39[10] = -(auVar41[10] == auVar35[2]);
              auVar39[0xb] = -(auVar41[0xb] == auVar35[3]);
              auVar39[0xc] = -(auVar41[0xc] == auVar35[4]);
              auVar39[0xd] = -(auVar41[0xd] == auVar35[5]);
              auVar39[0xe] = -(auVar41[0xe] == auVar35[6]);
              auVar39[0xf] = -(auVar41[0xf] == auVar35[7]);
              uVar29 = (ushort)(SUB161(auVar39 >> 7,0) & 1) |
                       (ushort)(SUB161(auVar39 >> 0xf,0) & 1) << 1 |
                       (ushort)(SUB161(auVar39 >> 0x17,0) & 1) << 2 |
                       (ushort)(SUB161(auVar39 >> 0x1f,0) & 1) << 3 |
                       (ushort)(SUB161(auVar39 >> 0x27,0) & 1) << 4 |
                       (ushort)(SUB161(auVar39 >> 0x2f,0) & 1) << 5 |
                       (ushort)(SUB161(auVar39 >> 0x37,0) & 1) << 6 |
                       (ushort)(SUB161(auVar39 >> 0x3f,0) & 1) << 7 |
                       (ushort)(SUB161(auVar39 >> 0x47,0) & 1) << 8 |
                       (ushort)(SUB161(auVar39 >> 0x4f,0) & 1) << 9 |
                       (ushort)(SUB161(auVar39 >> 0x57,0) & 1) << 10 |
                       (ushort)(SUB161(auVar39 >> 0x5f,0) & 1) << 0xb |
                       (ushort)(SUB161(auVar39 >> 0x67,0) & 1) << 0xc |
                       (ushort)(SUB161(auVar39 >> 0x6f,0) & 1) << 0xd |
                       (ushort)(SUB161(auVar39 >> 0x77,0) & 1) << 0xe |
                       (ushort)(auVar39[0xf] >> 7) << 0xf;
              uVar33 = (uint)uVar29;
              while (uVar29 != 0) {
                uVar21 = 0;
                for (uVar6 = uVar33; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
                  uVar21 = uVar21 + 1;
                }
                uVar30 = uVar21 + uVar28 & local_1f8._8_8_;
                if (*(undefined1 (**) [16])(local_1f8._0_8_ + uVar30 * -0x28 + -0x28) ==
                    (undefined1 (*) [16])uVar20) {
                  lVar22 = local_1f8._0_8_ + uVar30 * -0x28;
                  goto LAB_14000fac1;
                }
                uVar29 = (ushort)(uVar33 - 1) & (ushort)uVar33;
                uVar33 = CONCAT22((short)(uVar33 - 1 >> 0x10),uVar29);
              }
              auVar36[0] = -(auVar41[0] == cVar42);
              auVar36[1] = -(auVar41[1] == cVar43);
              auVar36[2] = -(auVar41[2] == cVar44);
              auVar36[3] = -(auVar41[3] == cVar45);
              auVar36[4] = -(auVar41[4] == cVar46);
              auVar36[5] = -(auVar41[5] == cVar47);
              auVar36[6] = -(auVar41[6] == cVar48);
              auVar36[7] = -(auVar41[7] == cVar49);
              auVar36[8] = -(auVar41[8] == cVar50);
              auVar36[9] = -(auVar41[9] == cVar51);
              auVar36[10] = -(auVar41[10] == cVar52);
              auVar36[0xb] = -(auVar41[0xb] == cVar53);
              auVar36[0xc] = -(auVar41[0xc] == cVar54);
              auVar36[0xd] = -(auVar41[0xd] == cVar55);
              auVar36[0xe] = -(auVar41[0xe] == cVar56);
              auVar36[0xf] = -(auVar41[0xf] == cVar57);
              if ((((((((((((((((SUB161(auVar36 >> 7,0) & 1) != 0 ||
                               (SUB161(auVar36 >> 0xf,0) & 1) != 0) ||
                              (SUB161(auVar36 >> 0x17,0) & 1) != 0) ||
                             (SUB161(auVar36 >> 0x1f,0) & 1) != 0) ||
                            (SUB161(auVar36 >> 0x27,0) & 1) != 0) ||
                           (SUB161(auVar36 >> 0x2f,0) & 1) != 0) ||
                          (SUB161(auVar36 >> 0x37,0) & 1) != 0) ||
                         (SUB161(auVar36 >> 0x3f,0) & 1) != 0) ||
                        (SUB161(auVar36 >> 0x47,0) & 1) != 0) ||
                       (SUB161(auVar36 >> 0x4f,0) & 1) != 0) || (SUB161(auVar36 >> 0x57,0) & 1) != 0
                      ) || (SUB161(auVar36 >> 0x5f,0) & 1) != 0) ||
                    (SUB161(auVar36 >> 0x67,0) & 1) != 0) || (SUB161(auVar36 >> 0x6f,0) & 1) != 0)
                  || (SUB161(auVar36 >> 0x77,0) & 1) != 0) || auVar36[0xf] < '\0') break;
              uVar28 = uVar28 + lVar22 + 0x10;
              lVar22 = lVar22 + 0x10;
            }
            if (local_1e8 == 0) {
              <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr)>>
              ::reserve_rehash::
              <hashbrown[ad6d4a1843b2832d]::map::make_hasher<u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,std[3bf9d48a0c3997f0]::hash::random::RandomState>::_closure_0_>
                        (local_1f8,1,&local_1d8);
            }
            uVar12 = uVar12 & local_1f8._8_8_;
            auVar35 = *(undefined1 (*) [16])(*(undefined1 (*) [16])local_1f8._0_8_ + uVar12);
            uVar29 = (ushort)(SUB161(auVar35 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar35 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar35 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar35 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar35 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar35 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar35 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar35 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar35 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar35 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar35 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar35 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar35 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar35 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar35 >> 0x77,0) & 1) << 0xe |
                     (ushort)(byte)(auVar35[0xf] >> 7) << 0xf;
            uVar33 = (uint)uVar29;
            if (uVar29 == 0) {
              lVar22 = 0x10;
              do {
                uVar12 = uVar12 + lVar22 & local_1f8._8_8_;
                auVar35 = *(undefined1 (*) [16])(*(undefined1 (*) [16])local_1f8._0_8_ + uVar12);
                lVar22 = lVar22 + 0x10;
                uVar33 = (uint)(ushort)((ushort)(SUB161(auVar35 >> 7,0) & 1) |
                                        (ushort)(SUB161(auVar35 >> 0xf,0) & 1) << 1 |
                                        (ushort)(SUB161(auVar35 >> 0x17,0) & 1) << 2 |
                                        (ushort)(SUB161(auVar35 >> 0x1f,0) & 1) << 3 |
                                        (ushort)(SUB161(auVar35 >> 0x27,0) & 1) << 4 |
                                        (ushort)(SUB161(auVar35 >> 0x2f,0) & 1) << 5 |
                                        (ushort)(SUB161(auVar35 >> 0x37,0) & 1) << 6 |
                                        (ushort)(SUB161(auVar35 >> 0x3f,0) & 1) << 7 |
                                        (ushort)(SUB161(auVar35 >> 0x47,0) & 1) << 8 |
                                        (ushort)(SUB161(auVar35 >> 0x4f,0) & 1) << 9 |
                                        (ushort)(SUB161(auVar35 >> 0x57,0) & 1) << 10 |
                                        (ushort)(SUB161(auVar35 >> 0x5f,0) & 1) << 0xb |
                                        (ushort)(SUB161(auVar35 >> 0x67,0) & 1) << 0xc |
                                        (ushort)(SUB161(auVar35 >> 0x6f,0) & 1) << 0xd |
                                        (ushort)(SUB161(auVar35 >> 0x77,0) & 1) << 0xe |
                                       (ushort)(byte)(auVar35[0xf] >> 7) << 0xf);
              } while (uVar33 == 0);
            }
            uVar21 = 0;
            for (; (uVar33 & 1) == 0; uVar33 = uVar33 >> 1 | 0x80000000) {
              uVar21 = uVar21 + 1;
            }
            uVar28 = uVar21 + uVar12 & local_1f8._8_8_;
            bVar34 = (*(undefined1 (*) [16])local_1f8._0_8_)[uVar28];
            if (-1 < (char)bVar34) {
              auVar35 = *(undefined1 (*) [16])local_1f8._0_8_;
              uVar33 = 0;
              for (uVar21 = (uint)(ushort)((ushort)(SUB161(auVar35 >> 7,0) & 1) |
                                           (ushort)(SUB161(auVar35 >> 0xf,0) & 1) << 1 |
                                           (ushort)(SUB161(auVar35 >> 0x17,0) & 1) << 2 |
                                           (ushort)(SUB161(auVar35 >> 0x1f,0) & 1) << 3 |
                                           (ushort)(SUB161(auVar35 >> 0x27,0) & 1) << 4 |
                                           (ushort)(SUB161(auVar35 >> 0x2f,0) & 1) << 5 |
                                           (ushort)(SUB161(auVar35 >> 0x37,0) & 1) << 6 |
                                           (ushort)(SUB161(auVar35 >> 0x3f,0) & 1) << 7 |
                                           (ushort)(SUB161(auVar35 >> 0x47,0) & 1) << 8 |
                                           (ushort)(SUB161(auVar35 >> 0x4f,0) & 1) << 9 |
                                           (ushort)(SUB161(auVar35 >> 0x57,0) & 1) << 10 |
                                           (ushort)(SUB161(auVar35 >> 0x5f,0) & 1) << 0xb |
                                           (ushort)(SUB161(auVar35 >> 0x67,0) & 1) << 0xc |
                                           (ushort)(SUB161(auVar35 >> 0x6f,0) & 1) << 0xd |
                                           (ushort)(SUB161(auVar35 >> 0x77,0) & 1) << 0xe |
                                          (ushort)(byte)(auVar35[0xf] >> 7) << 0xf);
                  (uVar21 & 1) == 0; uVar21 = uVar21 >> 1 | 0x80000000) {
                uVar33 = uVar33 + 1;
              }
              uVar28 = (ulonglong)uVar33;
              bVar34 = (*(undefined1 (*) [16])local_1f8._0_8_)[uVar28];
            }
            bVar27 = bVar27 >> 1;
            (*(undefined1 (*) [16])local_1f8._0_8_)[uVar28] = bVar27;
            (*(undefined1 (*) [16])(local_1f8._0_8_ + 0x10))[uVar28 - 0x10 & local_1f8._8_8_] =
                 bVar27;
            lVar22 = local_1f8._0_8_ + uVar28 * -0x28;
            *(undefined8 *)(local_1f8._0_8_ + uVar28 * -0x28 + -0x28) = uVar20;
            *(undefined1 *)(local_1f8._0_8_ + uVar28 * -0x28 + -0x20) = local_e8._2_1_;
            *(undefined8 *)(local_1f8._0_8_ + uVar28 * -0x28 + -0x18) = 0;
            *(undefined8 *)(local_1f8._0_8_ + uVar28 * -0x28 + -0x10) = 8;
            *(undefined8 *)(local_1f8._0_8_ + uVar28 * -0x28 + -8) = 0;
            auVar35._0_8_ = CONCAT71(0,bVar34 & 1);
            auVar35._8_4_ = 0xffffffff;
            auVar35._12_4_ = 0xffffffff;
            local_1e8 = local_1e8 - auVar35._0_8_;
            lStack_1e0 = lStack_1e0 - auVar35._8_8_;
LAB_14000fac1:
            local_1a8 = (undefined1 (*) [16])&local_218;
            pcStack_1a0 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
            alloc[246c2e7857c81348]::fmt::format::format_inner(&local_100,&DAT_1406a067e);
            lVar17 = *(longlong *)(lVar22 + -8);
            if (lVar17 == *(longlong *)(lVar22 + -0x18)) {
              <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::string::String>>::
              grow_one(lVar22 + -0x18);
            }
            lVar4 = *(longlong *)(lVar22 + -0x10);
            *(undefined8 *)(lVar4 + 0x10 + lVar17 * 0x18) = local_f0;
            puVar13 = (undefined8 *)(lVar4 + lVar17 * 0x18);
            *puVar13 = local_100;
            puVar13[1] = uStack_f8;
            *(longlong *)(lVar22 + -8) = lVar17 + 1;
            pauVar26 = param_2[0x77];
            pauVar16 = local_218;
          }
          else if (param_2[0x6e] != (undefined1 (*) [16])0x0) {
            uVar28 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                     ::hash_one::<&usize>(param_2 + 0x6f,&local_218);
            bVar27 = (byte)(uVar28 >> 0x39);
            auVar35 = ZEXT216(CONCAT11(bVar27,bVar27));
            auVar35 = pshuflw(auVar35,auVar35,0);
            lVar22 = 0;
            while( true ) {
              uVar28 = uVar28 & (ulonglong)param_2[0x6c];
              auVar41 = *(undefined1 (*) [16])(*param_2[0x6b] + uVar28);
              auVar40[0] = -(auVar41[0] == auVar35[0]);
              auVar40[1] = -(auVar41[1] == auVar35[1]);
              auVar40[2] = -(auVar41[2] == auVar35[2]);
              auVar40[3] = -(auVar41[3] == auVar35[3]);
              auVar40[4] = -(auVar41[4] == auVar35[4]);
              auVar40[5] = -(auVar41[5] == auVar35[5]);
              auVar40[6] = -(auVar41[6] == auVar35[6]);
              auVar40[7] = -(auVar41[7] == auVar35[7]);
              auVar40[8] = -(auVar41[8] == auVar35[0]);
              auVar40[9] = -(auVar41[9] == auVar35[1]);
              auVar40[10] = -(auVar41[10] == auVar35[2]);
              auVar40[0xb] = -(auVar41[0xb] == auVar35[3]);
              auVar40[0xc] = -(auVar41[0xc] == auVar35[4]);
              auVar40[0xd] = -(auVar41[0xd] == auVar35[5]);
              auVar40[0xe] = -(auVar41[0xe] == auVar35[6]);
              auVar40[0xf] = -(auVar41[0xf] == auVar35[7]);
              uVar29 = (ushort)(SUB161(auVar40 >> 7,0) & 1) |
                       (ushort)(SUB161(auVar40 >> 0xf,0) & 1) << 1 |
                       (ushort)(SUB161(auVar40 >> 0x17,0) & 1) << 2 |
                       (ushort)(SUB161(auVar40 >> 0x1f,0) & 1) << 3 |
                       (ushort)(SUB161(auVar40 >> 0x27,0) & 1) << 4 |
                       (ushort)(SUB161(auVar40 >> 0x2f,0) & 1) << 5 |
                       (ushort)(SUB161(auVar40 >> 0x37,0) & 1) << 6 |
                       (ushort)(SUB161(auVar40 >> 0x3f,0) & 1) << 7 |
                       (ushort)(SUB161(auVar40 >> 0x47,0) & 1) << 8 |
                       (ushort)(SUB161(auVar40 >> 0x4f,0) & 1) << 9 |
                       (ushort)(SUB161(auVar40 >> 0x57,0) & 1) << 10 |
                       (ushort)(SUB161(auVar40 >> 0x5f,0) & 1) << 0xb |
                       (ushort)(SUB161(auVar40 >> 0x67,0) & 1) << 0xc |
                       (ushort)(SUB161(auVar40 >> 0x6f,0) & 1) << 0xd |
                       (ushort)(SUB161(auVar40 >> 0x77,0) & 1) << 0xe |
                       (ushort)(auVar40[0xf] >> 7) << 0xf;
              uVar33 = (uint)uVar29;
              while (uVar29 != 0) {
                uVar21 = 0;
                for (uVar6 = uVar33; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
                  uVar21 = uVar21 + 1;
                }
                if (pauVar16 ==
                    *(undefined1 (**) [16])
                     param_2[0x6b][(uVar21 + uVar28 & (ulonglong)param_2[0x6c]) * -5 + -5])
                goto LAB_14000f890;
                uVar29 = (ushort)(uVar33 - 1) & (ushort)uVar33;
                uVar33 = CONCAT22((short)(uVar33 - 1 >> 0x10),uVar29);
              }
              auVar37[0] = -(auVar41[0] == cVar42);
              auVar37[1] = -(auVar41[1] == cVar43);
              auVar37[2] = -(auVar41[2] == cVar44);
              auVar37[3] = -(auVar41[3] == cVar45);
              auVar37[4] = -(auVar41[4] == cVar46);
              auVar37[5] = -(auVar41[5] == cVar47);
              auVar37[6] = -(auVar41[6] == cVar48);
              auVar37[7] = -(auVar41[7] == cVar49);
              auVar37[8] = -(auVar41[8] == cVar50);
              auVar37[9] = -(auVar41[9] == cVar51);
              auVar37[10] = -(auVar41[10] == cVar52);
              auVar37[0xb] = -(auVar41[0xb] == cVar53);
              auVar37[0xc] = -(auVar41[0xc] == cVar54);
              auVar37[0xd] = -(auVar41[0xd] == cVar55);
              auVar37[0xe] = -(auVar41[0xe] == cVar56);
              auVar37[0xf] = -(auVar41[0xf] == cVar57);
              if ((((((((((((((((SUB161(auVar37 >> 7,0) & 1) != 0 ||
                               (SUB161(auVar37 >> 0xf,0) & 1) != 0) ||
                              (SUB161(auVar37 >> 0x17,0) & 1) != 0) ||
                             (SUB161(auVar37 >> 0x1f,0) & 1) != 0) ||
                            (SUB161(auVar37 >> 0x27,0) & 1) != 0) ||
                           (SUB161(auVar37 >> 0x2f,0) & 1) != 0) ||
                          (SUB161(auVar37 >> 0x37,0) & 1) != 0) ||
                         (SUB161(auVar37 >> 0x3f,0) & 1) != 0) ||
                        (SUB161(auVar37 >> 0x47,0) & 1) != 0) ||
                       (SUB161(auVar37 >> 0x4f,0) & 1) != 0) || (SUB161(auVar37 >> 0x57,0) & 1) != 0
                      ) || (SUB161(auVar37 >> 0x5f,0) & 1) != 0) ||
                    (SUB161(auVar37 >> 0x67,0) & 1) != 0) || (SUB161(auVar37 >> 0x6f,0) & 1) != 0)
                  || (SUB161(auVar37 >> 0x77,0) & 1) != 0) || auVar37[0xf] < '\0') break;
              uVar28 = uVar28 + lVar22 + 0x10;
              lVar22 = lVar22 + 0x10;
            }
          }
        }
        if (pauVar16 == pauVar26) {
          ppauVar18 = param_2;
          accept(param_2,&local_e8,local_350,param_5);
        }
        else {
          if (param_2[0x6e] != (undefined1 (*) [16])0x0) {
            uVar28 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                     ::hash_one::<&usize>(param_2 + 0x6f,&local_218);
            pauVar26 = param_2[0x6b];
            bVar27 = (byte)(uVar28 >> 0x39);
            auVar35 = ZEXT216(CONCAT11(bVar27,bVar27));
            auVar35 = pshuflw(auVar35,auVar35,0);
            lVar22 = 0;
            while( true ) {
              uVar28 = uVar28 & (ulonglong)param_2[0x6c];
              pcVar1 = *pauVar26 + uVar28;
              auVar41[0] = -(*pcVar1 == auVar35[0]);
              auVar41[1] = -(pcVar1[1] == auVar35[1]);
              auVar41[2] = -(pcVar1[2] == auVar35[2]);
              auVar41[3] = -(pcVar1[3] == auVar35[3]);
              auVar41[4] = -(pcVar1[4] == auVar35[4]);
              auVar41[5] = -(pcVar1[5] == auVar35[5]);
              auVar41[6] = -(pcVar1[6] == auVar35[6]);
              auVar41[7] = -(pcVar1[7] == auVar35[7]);
              auVar41[8] = -(pcVar1[8] == auVar35[0]);
              auVar41[9] = -(pcVar1[9] == auVar35[1]);
              auVar41[10] = -(pcVar1[10] == auVar35[2]);
              auVar41[0xb] = -(pcVar1[0xb] == auVar35[3]);
              auVar41[0xc] = -(pcVar1[0xc] == auVar35[4]);
              auVar41[0xd] = -(pcVar1[0xd] == auVar35[5]);
              auVar41[0xe] = -(pcVar1[0xe] == auVar35[6]);
              auVar41[0xf] = -(pcVar1[0xf] == auVar35[7]);
              uVar29 = (ushort)(SUB161(auVar41 >> 7,0) & 1) |
                       (ushort)(SUB161(auVar41 >> 0xf,0) & 1) << 1 |
                       (ushort)(SUB161(auVar41 >> 0x17,0) & 1) << 2 |
                       (ushort)(SUB161(auVar41 >> 0x1f,0) & 1) << 3 |
                       (ushort)(SUB161(auVar41 >> 0x27,0) & 1) << 4 |
                       (ushort)(SUB161(auVar41 >> 0x2f,0) & 1) << 5 |
                       (ushort)(SUB161(auVar41 >> 0x37,0) & 1) << 6 |
                       (ushort)(SUB161(auVar41 >> 0x3f,0) & 1) << 7 |
                       (ushort)(SUB161(auVar41 >> 0x47,0) & 1) << 8 |
                       (ushort)(SUB161(auVar41 >> 0x4f,0) & 1) << 9 |
                       (ushort)(SUB161(auVar41 >> 0x57,0) & 1) << 10 |
                       (ushort)(SUB161(auVar41 >> 0x5f,0) & 1) << 0xb |
                       (ushort)(SUB161(auVar41 >> 0x67,0) & 1) << 0xc |
                       (ushort)(SUB161(auVar41 >> 0x6f,0) & 1) << 0xd |
                       (ushort)(SUB161(auVar41 >> 0x77,0) & 1) << 0xe |
                       (ushort)(auVar41[0xf] >> 7) << 0xf;
              uVar33 = (uint)uVar29;
              while (uVar29 != 0) {
                uVar21 = 0;
                for (uVar6 = uVar33; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
                  uVar21 = uVar21 + 1;
                }
                uVar12 = uVar21 + uVar28 & (ulonglong)param_2[0x6c];
                if (pauVar16 == *(undefined1 (**) [16])pauVar26[uVar12 * -5 + -5]) {
                  if (*(longlong *)(pauVar26[uVar12 * -5 + -2] + 8) == 0x200) {
                    lVar22 = *(longlong *)pauVar26[uVar12 * -5 + -2];
                    uVar28 = 0;
                    if (*(ulonglong *)pauVar26[uVar12 * -5 + -3] <= lVar22 + 1U) {
                      uVar28 = *(ulonglong *)pauVar26[uVar12 * -5 + -3];
                    }
                    *(ulonglong *)pauVar26[uVar12 * -5 + -2] = (lVar22 - uVar28) + 1;
                    *(undefined8 *)(pauVar26[uVar12 * -5 + -2] + 8) = 0x1ff;
                    memcpy(&local_1a8,
                           (void *)(lVar22 * 0xa0 + *(longlong *)(pauVar26[uVar12 * -5 + -3] + 8)),
                           0xa0);
                    if ((int)pcStack_1a0 != -1) {
                      core[505b25137b8ba7f]::ptr::drop_glue::
                      <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(&local_188);
                    }
                  }
                  local_260 = *(longlong *)pauVar26[uVar12 * -5 + -1] + 1;
                  *(longlong *)pauVar26[uVar12 * -5 + -1] = local_260;
                  local_270 = local_88;
                  uStack_268 = uStack_80;
                  local_280 = local_98;
                  uStack_278 = uStack_90;
                  local_290 = local_a8;
                  uStack_288 = uStack_a0;
                  local_2a0 = local_b8;
                  uStack_29c = uStack_b4;
                  uStack_298 = uStack_b0;
                  uStack_294 = uStack_ac;
                  local_2b0 = local_c8;
                  uStack_2a8 = uStack_c0;
                  local_2c0 = local_d8;
                  local_2d0 = local_e8;
                  pcStack_2c8 = pcStack_e0;
                  local_2f0 = local_350;
                  local_2e8 = (undefined1 (**) [16])CONCAT44(local_2e8._4_4_,param_5);
                  local_2e0 = local_350;
                  local_2d8 = (undefined1 (*) [16])CONCAT44(local_2d8._4_4_,param_5);
                  local_258 = 1;
                  delivery(&local_348,param_2[0xc],param_2[0xd],
                           *(undefined8 *)pauVar26[uVar12 * -5 + -4],
                           *(undefined8 *)(pauVar26[uVar12 * -5 + -4] + 8),&local_2f0,local_350,
                           param_5);
                  lVar22 = local_318;
                  ppauVar18 = local_338;
                  if (local_338 < (undefined1 (**) [16])0x579) {
                    local_310 = local_348;
                    local_220 = ppppppplStack_340;
                    local_1b8 = local_218;
                    if (local_318 == local_328) {
                      <alloc[246c2e7857c81348]::raw_vec::RawVec<(usize,[i32;6usize])>>::grow_one
                                (&local_328);
                    }
                    lVar17 = lVar22 * 0x20;
                    *(undefined1 (**) [16])(lStack_320 + lVar17) = local_1b8;
                    *(longlong ********)(lStack_320 + 8 + lVar17) = local_310;
                    *(longlong ********)(lStack_320 + 0x10 + lVar17) = local_220;
                    *(undefined1 (***) [16])(lStack_320 + 0x18 + lVar17) = ppauVar18;
                    local_318 = lVar22 + 1;
                    memcpy(&local_1a8,&local_2f0,0xa0);
                    uVar28 = *(ulonglong *)pauVar26[uVar12 * -5 + -3];
                    uVar30 = *(ulonglong *)(pauVar26[uVar12 * -5 + -2] + 8);
                    if (uVar30 == uVar28) {
                      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>
                      ::grow(pauVar26 + uVar12 * -5 + -3);
                      uVar28 = *(ulonglong *)pauVar26[uVar12 * -5 + -3];
                      uVar30 = *(ulonglong *)(pauVar26[uVar12 * -5 + -2] + 8);
                    }
                    *(ulonglong *)(pauVar26[uVar12 * -5 + -2] + 8) = uVar30 + 1;
                    uVar30 = uVar30 + *(longlong *)pauVar26[uVar12 * -5 + -2];
                    uVar23 = 0;
                    if (uVar28 <= uVar30) {
                      uVar23 = uVar28;
                    }
                    ppauVar18 = (undefined1 (**) [16])
                                ((uVar30 - uVar23) * 0xa0 +
                                *(longlong *)(pauVar26[uVar12 * -5 + -3] + 8));
                    memcpy(ppauVar18,&local_1a8,0xa0);
                  }
                  else {
                    if (local_348 != (longlong *******)0x0) {
                      __rustc[9d087a5ab36ea756]::__rust_dealloc(ppppppplStack_340,local_348,1);
                      return;
                    }
                    ppauVar18 = &local_2d0;
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>();
                  }
                  goto joined_r0x00014000fec8;
                }
                uVar29 = (ushort)(uVar33 - 1) & (ushort)uVar33;
                uVar33 = CONCAT22((short)(uVar33 - 1 >> 0x10),uVar29);
              }
              auVar38[0] = -(*pcVar1 == cVar42);
              auVar38[1] = -(pcVar1[1] == cVar43);
              auVar38[2] = -(pcVar1[2] == cVar44);
              auVar38[3] = -(pcVar1[3] == cVar45);
              auVar38[4] = -(pcVar1[4] == cVar46);
              auVar38[5] = -(pcVar1[5] == cVar47);
              auVar38[6] = -(pcVar1[6] == cVar48);
              auVar38[7] = -(pcVar1[7] == cVar49);
              auVar38[8] = -(pcVar1[8] == cVar50);
              auVar38[9] = -(pcVar1[9] == cVar51);
              auVar38[10] = -(pcVar1[10] == cVar52);
              auVar38[0xb] = -(pcVar1[0xb] == cVar53);
              auVar38[0xc] = -(pcVar1[0xc] == cVar54);
              auVar38[0xd] = -(pcVar1[0xd] == cVar55);
              auVar38[0xe] = -(pcVar1[0xe] == cVar56);
              auVar38[0xf] = -(pcVar1[0xf] == cVar57);
              if ((((((((((((((((SUB161(auVar38 >> 7,0) & 1) != 0 ||
                               (SUB161(auVar38 >> 0xf,0) & 1) != 0) ||
                              (SUB161(auVar38 >> 0x17,0) & 1) != 0) ||
                             (SUB161(auVar38 >> 0x1f,0) & 1) != 0) ||
                            (SUB161(auVar38 >> 0x27,0) & 1) != 0) ||
                           (SUB161(auVar38 >> 0x2f,0) & 1) != 0) ||
                          (SUB161(auVar38 >> 0x37,0) & 1) != 0) ||
                         (SUB161(auVar38 >> 0x3f,0) & 1) != 0) ||
                        (SUB161(auVar38 >> 0x47,0) & 1) != 0) ||
                       (SUB161(auVar38 >> 0x4f,0) & 1) != 0) || (SUB161(auVar38 >> 0x57,0) & 1) != 0
                      ) || (SUB161(auVar38 >> 0x5f,0) & 1) != 0) ||
                    (SUB161(auVar38 >> 0x67,0) & 1) != 0) || (SUB161(auVar38 >> 0x6f,0) & 1) != 0)
                  || (SUB161(auVar38 >> 0x77,0) & 1) != 0) || auVar38[0xf] < '\0') break;
              uVar28 = uVar28 + lVar22 + 0x10;
              lVar22 = lVar22 + 0x10;
            }
          }
          ppauVar18 = (undefined1 (**) [16])&local_e8;
          core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>
                    ();
        }
      }
joined_r0x00014000fec8:
      if (pppppplVar2 != (longlong ******)0x0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(pppppplVar3,pppppplVar2,1);
        return;
      }
      ppppppplVar11 = ppppppplVar24;
    } while (ppppppplVar24 != ppppppplVar14);
  }
  if (local_358 != (undefined1 (**) [16])0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_380,(longlong)local_358 << 5,8);
    return;
  }
  auVar35 = *(undefined1 (*) [16])local_1f8._0_8_;
  if (local_1f8._8_8_ == 0) {
    local_2f0 = 0;
    local_2e0 = 0;
  }
  else {
    uVar28 = local_1f8._8_8_ * 0x28 & 0xfffffffffffffff0;
    ppauVar18 = (undefined1 (**) [16])(uVar28 + local_1f8._8_8_ + 0x41);
    local_2e0 = local_1f8._0_8_ + (-0x30 - uVar28);
    local_2f0 = 0x10;
  }
  local_2d0 = (undefined1 (*) [16])(local_1f8._0_8_ + 0x10);
  pcStack_2c8 = (code *)((undefined1 *)local_1f8._0_8_ + local_1f8._8_8_ + 1);
  uVar33 = ~(uint)(ushort)((ushort)(SUB161(auVar35 >> 7,0) & 1) |
                           (ushort)(SUB161(auVar35 >> 0xf,0) & 1) << 1 |
                           (ushort)(SUB161(auVar35 >> 0x17,0) & 1) << 2 |
                           (ushort)(SUB161(auVar35 >> 0x1f,0) & 1) << 3 |
                           (ushort)(SUB161(auVar35 >> 0x27,0) & 1) << 4 |
                           (ushort)(SUB161(auVar35 >> 0x2f,0) & 1) << 5 |
                           (ushort)(SUB161(auVar35 >> 0x37,0) & 1) << 6 |
                           (ushort)(SUB161(auVar35 >> 0x3f,0) & 1) << 7 |
                           (ushort)(SUB161(auVar35 >> 0x47,0) & 1) << 8 |
                           (ushort)(SUB161(auVar35 >> 0x4f,0) & 1) << 9 |
                           (ushort)(SUB161(auVar35 >> 0x57,0) & 1) << 10 |
                           (ushort)(SUB161(auVar35 >> 0x5f,0) & 1) << 0xb |
                           (ushort)(SUB161(auVar35 >> 0x67,0) & 1) << 0xc |
                           (ushort)(SUB161(auVar35 >> 0x6f,0) & 1) << 0xd |
                           (ushort)(SUB161(auVar35 >> 0x77,0) & 1) << 0xe |
                          (ushort)(byte)(auVar35[0xf] >> 7) << 0xf);
  local_2c0._0_2_ = (short)uVar33;
  local_2c0._8_8_ = lStack_1e0;
  local_358 = (undefined1 (**) [16])0x0;
  pauVar16 = local_2d0;
  local_2e8 = ppauVar18;
  pauVar26 = (undefined1 (*) [16])local_1f8._0_8_;
  local_2d8 = (undefined1 (*) [16])local_1f8._0_8_;
  uVar8 = local_381;
  lVar22 = local_350;
  uVar20 = local_2c0._0_8_;
  lVar17 = local_248;
  lVar4 = lStack_240;
  ppauVar18 = (undefined1 (**) [16])lStack_1e0;
  do {
    if (ppauVar18 == (undefined1 (**) [16])0x0) {
      ppauVar18 = (undefined1 (**) [16])0x0;
      local_2c0._0_8_ = uVar20;
LAB_140010518:
      local_2c0._8_8_ = ppauVar18;
      local_2c0._0_2_ = (short)uVar33;
      local_381 = uVar8;
      local_350 = lVar22;
      local_2d8 = pauVar26;
      local_2d0 = pauVar16;
      local_248 = lVar17;
      lStack_240 = lVar4;
      <hashbrown[ad6d4a1843b2832d]::raw::RawIntoIter<(u64,(reach_directory[4b72b9694f6c3c08]::chat::Channel,alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>))>as_core[505b25137b8ba7f]::ops::drop::Drop>
      ::drop(&local_2f0);
      pauVar16 = param_2[0x4a];
      if ((undefined1 (*) [16])0x20 < pauVar16) {
        do {
          pauVar26 = param_2[0x49];
          pauVar19 = param_2[0x47];
          if ((undefined1 (*) [16])(*pauVar26 + 1) < param_2[0x47]) {
            pauVar19 = (undefined1 (*) [16])0x0;
          }
          param_2[0x49] = (undefined1 (*) [16])((longlong)pauVar26 + (1 - (longlong)pauVar19));
          pauVar16 = (undefined1 (*) [16])(pauVar16[-1] + 0xf);
          param_2[0x4a] = pauVar16;
          pauVar19 = param_2[0x48] + (longlong)pauVar26 * 2;
          local_1a8 = *(undefined1 (**) [16])*pauVar19;
          pcStack_1a0 = *(code **)(*pauVar19 + 8);
          pauVar26 = param_2[0x48] + (longlong)pauVar26 * 2 + 1;
          local_198 = *(undefined8 *)*pauVar26;
          uStack_190 = *(undefined8 *)(*pauVar26 + 8);
          if ((char)local_1a8 != -1) {
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (&local_1a8);
            pauVar16 = param_2[0x4a];
          }
        } while ((undefined1 (*) [16])0x20 < pauVar16);
      }
      local_1b0[2] = local_318;
      *local_1b0 = local_328;
      local_1b0[1] = lStack_320;
      return;
    }
    uVar29 = (ushort)uVar33;
    while (uVar29 == 0) {
      auVar35 = *pauVar16;
      pauVar26 = pauVar26 + -0x28;
      pauVar16 = pauVar16 + 1;
      uVar29 = ((ushort)(SUB161(auVar35 >> 7,0) & 1) | (ushort)(SUB161(auVar35 >> 0xf,0) & 1) << 1 |
                (ushort)(SUB161(auVar35 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar35 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar35 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar35 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar35 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar35 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar35 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar35 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar35 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar35 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar35 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar35 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar35 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar35[0xf] >> 7) << 0xf) ^ 0xffff;
      uVar33 = (uint)uVar29;
    }
    uVar21 = 0;
    for (uVar6 = uVar33; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
      uVar21 = uVar21 + 1;
    }
    uVar28 = (ulonglong)uVar21;
    uVar33 = uVar33 - 1 & uVar33;
    ppauVar18 = (undefined1 (**) [16])((longlong)ppauVar18 + -1);
    uVar20 = *(undefined8 *)((longlong)pauVar26 + uVar28 * -0x28 + -0x28);
    local_381 = *(undefined1 *)((longlong)pauVar26 + uVar28 * -0x28 + -0x20);
    local_350 = *(longlong *)((longlong)pauVar26 + uVar28 * -0x28 + -0x18);
    plVar10 = (longlong *)((longlong)pauVar26 + uVar28 * -0x28 + -0x10);
    local_248 = *plVar10;
    lStack_240 = plVar10[1];
    local_78 = local_248;
    lStack_70 = lStack_240;
    if (local_350 == -1) goto LAB_140010518;
    local_238 = 0;
    local_228 = 0;
    local_250 = local_350;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar31 = 2;
    puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(2,1);
    uVar32 = (undefined2)uVar33;
    if (puVar13 == (undefined8 *)0x0) {
LAB_14001075a:
      local_2c0._8_8_ = ppauVar18;
      local_2c0._0_2_ = uVar32;
      local_2d8 = pauVar26;
      local_2d0 = pauVar16;
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar31);
      goto LAB_1400107df;
    }
    *(undefined2 *)puVar13 = 0x6469;
    local_308 = 2;
    local_2f8 = 2;
    ppppppplVar24 = (longlong *******)&local_378;
    local_300 = puVar13;
    _Src = (void *)::<u64>::_fmt(uVar20,ppppppplVar24,0x14);
    if ((longlong)ppppppplVar24 < 0) {
      uVar20 = 0;
LAB_1400105f8:
      local_2c0._8_8_ = ppauVar18;
      local_2c0._0_2_ = uVar32;
      local_2d8 = pauVar26;
      local_2d0 = pauVar16;
      alloc[246c2e7857c81348]::raw_vec::handle_error(uVar20,local_380);
      goto LAB_1400107df;
    }
    if (ppppppplVar24 == (longlong *******)0x0) {
      local_380 = (longlong *******)0x1;
      _Dst = (undefined1 (**) [16])0x1;
    }
    else {
      local_358 = ppauVar18;
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      ppppppplVar14 = (longlong *******)__rustc[9d087a5ab36ea756]::__rust_alloc(ppppppplVar24,1);
      if (ppppppplVar14 == (longlong *******)0x0) {
        uVar20 = 1;
        ppauVar18 = local_358;
        local_380 = ppppppplVar24;
        goto LAB_1400105f8;
      }
      memcpy(ppppppplVar14,_Src,(size_t)ppppppplVar24);
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      _Dst = (undefined1 (**) [16])__rustc[9d087a5ab36ea756]::__rust_alloc(ppppppplVar24,1);
      local_380 = ppppppplVar14;
      if (_Dst == (undefined1 (**) [16])0x0) {
        local_2c0._8_8_ = local_358;
        local_2c0._0_2_ = uVar32;
        local_2d8 = pauVar26;
        local_2d0 = pauVar16;
        alloc[246c2e7857c81348]::raw_vec::handle_error(1,ppppppplVar24);
        goto LAB_1400107df;
      }
      memcpy(_Dst,ppppppplVar14,(size_t)ppppppplVar24);
      ppauVar18 = local_358;
    }
    local_378 = (longlong *******)CONCAT71(local_378._1_7_,3);
    ppppppplStack_370 = ppppppplVar24;
    local_368 = _Dst;
    ppppppplStack_360 = ppppppplVar24;
    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
    ::insert(&local_348,&local_238,&local_308,&local_378);
    if ((char)local_348 != -1) {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                (&local_348);
    }
    if (ppppppplVar24 != (longlong *******)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(local_380,ppppppplVar24,1);
      return;
    }
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar31 = 7;
    puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(7,1);
    if (puVar13 == (undefined8 *)0x0) goto LAB_14001075a;
    *(undefined4 *)((longlong)puVar13 + 3) = 0x6c656e6e;
    *(undefined4 *)puVar13 = 0x6e616863;
    local_308 = 7;
    local_2f8 = 7;
    local_300 = puVar13;
    <reach_directory[4b72b9694f6c3c08]::chat::Channel_as_serde_core[7f01a81d286c67f3]::ser::Serialize>
    ::serialize::<serde_json[7404bcab4dc139c7]::value::ser::Serializer>(&local_378,&local_381);
    if ((char)local_378 == -1) {
      local_2c0._8_8_ = ppauVar18;
      local_2c0._0_2_ = uVar32;
      local_348 = ppppppplStack_370;
      local_2d8 = pauVar26;
      local_2d0 = pauVar16;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_348,
                 &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                 &PTR_s_src_ingame_chat_transport_rs_1406a13e8);
      goto LAB_1400107df;
    }
    local_338 = local_368;
    ppppppplStack_330 = ppppppplStack_360;
    local_348 = local_378;
    ppppppplStack_340 = ppppppplStack_370;
    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
    ::insert(&local_378,&local_238,&local_308,&local_348);
    if ((char)local_378 != -1) {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                (&local_378);
    }
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar31 = 10;
    puVar13 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(10,1);
    if (puVar13 == (undefined8 *)0x0) goto LAB_14001075a;
    *puVar13 = 0x6e65697069636572;
    *(undefined2 *)(puVar13 + 1) = 0x7374;
    local_308 = 10;
    local_2f8 = 10;
    local_300 = puVar13;
    <serde_json[7404bcab4dc139c7]::value::ser::Serializer_as_serde_core[7f01a81d286c67f3]::ser::Serializer>
    ::collect_seq::<&alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>
              (&local_378,&local_250);
    if ((char)local_378 == -1) {
      local_2c0._8_8_ = ppauVar18;
      local_2c0._0_2_ = uVar32;
      local_348 = ppppppplStack_370;
      local_2d8 = pauVar26;
      local_2d0 = pauVar16;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_348,
                 &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                 &PTR_s_src_ingame_chat_transport_rs_1406a13e8);
      goto LAB_1400107df;
    }
    local_338 = local_368;
    ppppppplStack_330 = ppppppplStack_360;
    local_348 = local_378;
    ppppppplStack_340 = ppppppplStack_370;
    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
    ::insert(&local_378,&local_238,&local_308,&local_348);
    if ((char)local_378 != -1) {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                (&local_378);
    }
    uStack_200 = local_228;
    lStack_210 = local_238;
    uStack_208 = uStack_230;
    local_218 = (undefined1 (*) [16])CONCAT71(local_218._1_7_,5);
    pauVar19 = param_2[0x47];
    pauVar15 = param_2[0x4a];
    if (pauVar15 == pauVar19) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>>
      ::grow(param_2 + 0x47);
      pauVar19 = param_2[0x47];
      pauVar15 = param_2[0x4a];
    }
    param_2[0x4a] = (undefined1 (*) [16])(*pauVar15 + 1);
    pauVar25 = (undefined1 (*) [16])0x0;
    if (pauVar19 <= (undefined1 (*) [16])(*param_2[0x49] + (longlong)*pauVar15)) {
      pauVar25 = pauVar19;
    }
    lVar22 = (longlong)(*param_2[0x49] + (longlong)*pauVar15) - (longlong)pauVar25;
    pauVar19 = param_2[0x48];
    pauVar15 = pauVar19 + lVar22 * 2 + 1;
    *(undefined8 *)*pauVar15 = uStack_208;
    *(undefined8 *)(*pauVar15 + 8) = uStack_200;
    pauVar19 = pauVar19 + lVar22 * 2;
    *(undefined1 (**) [16])*pauVar19 = local_218;
    *(longlong *)(*pauVar19 + 8) = lStack_210;
    if (lStack_240 != 0) {
      puVar13 = (undefined8 *)(local_248 + 8);
      lVar22 = lStack_240;
      do {
        if (puVar13[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar13,puVar13[-1],1);
          return;
        }
        puVar13 = puVar13 + 3;
        lVar22 = lVar22 + -1;
      } while (lVar22 != 0);
    }
    if (local_350 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(local_248,local_350 * 0x18,8);
      return;
    }
    lVar22 = 0;
    uVar8 = local_381;
    uVar20 = local_2c0._0_8_;
    lVar17 = local_248;
    lVar4 = lStack_240;
  } while( true );
}

