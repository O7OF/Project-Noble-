// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::send_route_kind
// address: 0x140025af0
// body: available
// range: 0x140025af0-0x140025c79 inclusive
// range: 0x140025c7c-0x140025cbe inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140025c75 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::send_route_kind */

void __rustcall
host_probe[b94139f9089eb1d8]::net::send_route_kind
          (longlong param_1,longlong param_2,undefined **param_3,undefined8 param_4,char param_5)

{
  short sVar1;
  ulonglong uVar2;
  undefined **ppuVar3;
  short local_58;
  undefined4 local_56;
  undefined2 local_52;
  undefined **local_50;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  longlong local_38;
  undefined **local_30;
  undefined8 local_28;
  
  if (*(char *)(param_2 + 0x30) != '\x01') {
    sVar1 = *(short *)(param_2 + 0x10);
    if (sVar1 == 2) {
      local_50 = &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
    }
    else {
      local_50 = *(undefined ***)(param_2 + 0x18);
      if (sVar1 != -1) {
        local_56 = *(undefined4 *)(param_2 + 0x12);
        local_52 = *(undefined2 *)(param_2 + 0x16);
        local_48 = *(undefined4 *)(param_2 + 0x20);
        uStack_44 = *(undefined4 *)(param_2 + 0x24);
        uStack_40 = *(undefined4 *)(param_2 + 0x28);
        uStack_3c = *(undefined4 *)(param_2 + 0x2c);
        local_58 = sVar1;
        uVar2 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                          (param_1 + 0x150,param_3,param_4,&local_58);
        local_50 = param_3;
        if ((uVar2 & 1) == 0) {
          LOCK();
          (&DAT_1407f1050)[(ulonglong)(param_5 == '\x02') * 0x10] =
               (&DAT_1407f1050)[(ulonglong)(param_5 == '\x02') * 0x10] + (longlong)param_3;
          UNLOCK();
          LOCK();
          (&DAT_1407f1058)[(ulonglong)(param_5 == '\x02') * 0x10] =
               (&DAT_1407f1058)[(ulonglong)(param_5 == '\x02') * 0x10] + 1;
          UNLOCK();
          return;
        }
      }
    }
    LOCK();
    DAT_1407f1080 = DAT_1407f1080 + 1;
    UNLOCK();
    if (((uint)local_50 & 3) - 2 < 2) {
      return;
    }
    if (((ulonglong)local_50 & 3) == 0) {
      return;
    }
    local_50 = (undefined **)((longlong)local_50 + -1);
    local_58 = CONCAT11(local_58._1_1_,3);
    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&local_50);
    return;
  }
  reach_directory[4b72b9694f6c3c08]::rendezvous::relay_wrap(&local_38,param_2 + 0x31);
  sVar1 = *(short *)(param_2 + 0x10);
  if (sVar1 == 2) {
    ppuVar3 = &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
  }
  else {
    ppuVar3 = *(undefined ***)(param_2 + 0x18);
    if (sVar1 != -1) {
      local_56 = *(undefined4 *)(param_2 + 0x12);
      local_52 = *(undefined2 *)(param_2 + 0x16);
      local_48 = *(undefined4 *)(param_2 + 0x20);
      uStack_44 = *(undefined4 *)(param_2 + 0x24);
      uStack_40 = *(undefined4 *)(param_2 + 0x28);
      uStack_3c = *(undefined4 *)(param_2 + 0x2c);
      ppuVar3 = local_30;
      local_58 = sVar1;
      local_50 = *(undefined ***)(param_2 + 0x18);
      uVar2 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                        (param_1 + 0x150,local_30,local_28,&local_58);
      if ((uVar2 & 1) == 0) {
        LOCK();
        (&DAT_1407f1050)[(ulonglong)(param_5 == '\x02') * 0x10] =
             (&DAT_1407f1050)[(ulonglong)(param_5 == '\x02') * 0x10] + (longlong)ppuVar3;
        UNLOCK();
        LOCK();
        (&DAT_1407f1058)[(ulonglong)(param_5 == '\x02') * 0x10] =
             (&DAT_1407f1058)[(ulonglong)(param_5 == '\x02') * 0x10] + 1;
        UNLOCK();
        goto LAB_140025c62;
      }
    }
  }
  LOCK();
  DAT_1407f1080 = DAT_1407f1080 + 1;
  UNLOCK();
  if ((1 < ((uint)ppuVar3 & 3) - 2) && (((ulonglong)ppuVar3 & 3) != 0)) {
    local_50 = (undefined **)((longlong)ppuVar3 + -1);
    local_58 = CONCAT11(local_58._1_1_,3);
    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&local_50);
  }
LAB_140025c62:
  if (local_38 == 0) {
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(local_30,local_38,1);
  return;
}

