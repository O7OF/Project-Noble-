// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::option::Option<(std[3bf9d48a0c3997f0]::collections::hash::set::HashSet<core[505b25137b8ba7f]::net::ip_addr::IpAddr>,alloc[246c2e7857c81348]::vec::Vec<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>)>>
// address: 0x140002bf0
// body: available
// range: 0x140002bf0-0x140002c3a inclusive
// range: 0x140002c3e-0x140002c65 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140002c36 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140002c5a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::option::Option<(std[3bf9d48a0c3997f0]::collections::hash::set::HashSet<core[505b25137b8ba7f]::net::ip_addr::IpAddr>,
   alloc[246c2e7857c81348]::vec::Vec<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>)>>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<core[505b25137b8ba7f]::option::Option<(std[3bf9d48a0c3997f0]::collections::hash::set::HashSet<core[505b25137b8ba7f]::net::ip_addr::IpAddr>,alloc[246c2e7857c81348]::vec::Vec<reach_directory[4b72b9694f6c3c08]::server_admin::bans::IpNet>)>>
          (longlong *param_1)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  lVar1 = param_1[6];
  if (lVar1 != -1) {
    lVar2 = param_1[1];
    if (lVar2 != 0) {
      uVar3 = lVar2 * 0x11 & 0xfffffffffffffff0;
      lVar2 = lVar2 + uVar3 + 0x31;
      if (lVar2 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc((*param_1 - uVar3) + -0x20,lVar2,0x10);
        return;
      }
    }
    if (lVar1 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[7],lVar1 * 0x12,1);
      return;
    }
  }
  return;
}

