// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::delivery
// address: 0x140013c70
// body: available
// range: 0x140013c70-0x1400141a4 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::delivery */

void __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::delivery
          (undefined8 param_1,void *param_2,size_t param_3,void *param_4,size_t param_5,
          ulonglong *param_6,undefined8 param_7,undefined4 param_8)

{
  code *pcVar1;
  undefined4 *puVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  undefined4 local_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  undefined8 local_b0;
  undefined8 uStack_a8;
  undefined8 local_a0;
  undefined4 *local_98;
  undefined8 local_90;
  undefined8 local_88;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 local_60 [2];
  undefined8 local_50;
  undefined8 local_48;
  undefined4 local_40;
  
  local_48 = param_7;
  local_40 = param_8;
  local_60[0] = 0;
  local_50 = 0;
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  uVar5 = 4;
  puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = 0x646e696b;
    local_a0 = 4;
    local_90 = 4;
    local_98 = puVar2;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(4,1);
    if (puVar2 == (undefined4 *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,4);
      goto LAB_1400141a3;
    }
    *puVar2 = 0x656e696c;
    local_c0 = CONCAT31(local_c0._1_3_,3);
    uStack_b8 = 4;
    uStack_a8 = 4;
    local_b0 = puVar2;
    <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
    ::insert(&local_88,local_60,&local_a0,&local_c0);
    if ((char)local_88 != -1) {
      core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(&local_88)
      ;
    }
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar5 = 5;
    puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
    if (puVar2 != (undefined4 *)0x0) {
      *(undefined1 *)(puVar2 + 1) = 0x68;
      *puVar2 = 0x636f7065;
      local_a0 = 5;
      local_90 = 5;
      local_98 = puVar2;
      if ((longlong)param_3 < 0) {
        uVar5 = 0;
LAB_140013dc2:
        alloc[246c2e7857c81348]::raw_vec::handle_error(uVar5,param_3);
        goto LAB_1400141a3;
      }
      if (param_3 == 0) {
        puVar2 = (undefined4 *)0x1;
      }
      else {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar5 = 1;
        puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(param_3,1);
        if (puVar2 == (undefined4 *)0x0) goto LAB_140013dc2;
        memcpy(puVar2,param_2,param_3);
      }
      local_c0 = CONCAT31(local_c0._1_3_,3);
      uStack_b8 = param_3;
      local_b0 = puVar2;
      uStack_a8 = param_3;
      <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
      ::insert(&local_88,local_60,&local_a0,&local_c0);
      if ((char)local_88 != -1) {
        core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                  (&local_88);
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar5 = 5;
      puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(5,1);
      if (puVar2 != (undefined4 *)0x0) {
        *(undefined1 *)(puVar2 + 1) = 0x65;
        *puVar2 = 0x636e6f6e;
        local_a0 = 5;
        local_90 = 5;
        local_98 = puVar2;
        if ((longlong)param_5 < 0) {
          uVar5 = 0;
LAB_140013ea2:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uVar5,param_5);
          goto LAB_1400141a3;
        }
        if (param_5 == 0) {
          puVar2 = (undefined4 *)0x1;
        }
        else {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar5 = 1;
          puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(param_5,1);
          if (puVar2 == (undefined4 *)0x0) goto LAB_140013ea2;
          memcpy(puVar2,param_4,param_5);
        }
        local_c0 = CONCAT31(local_c0._1_3_,3);
        uStack_b8 = param_5;
        uStack_a8 = param_5;
        local_b0 = puVar2;
        <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
        ::insert(&local_88,local_60,&local_a0,&local_c0);
        if ((char)local_88 != -1) {
          core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                    (&local_88);
        }
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        uVar5 = 2;
        puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(2,1);
        if (puVar2 != (undefined4 *)0x0) {
          *(undefined2 *)puVar2 = 0x6469;
          local_a0 = 2;
          local_90 = 2;
          local_b0 = (undefined4 *)param_6[0x12];
          local_c0 = CONCAT31(local_c0._1_3_,2);
          uStack_b8 = 0;
          local_98 = puVar2;
          <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
          ::insert(&local_88,local_60,&local_a0,&local_c0);
          if ((char)local_88 != -1) {
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                      (&local_88);
          }
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar5 = 6;
          puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(6,1);
          if (puVar2 != (undefined4 *)0x0) {
            *(undefined2 *)(puVar2 + 1) = 0x736d;
            *puVar2 = 0x5f656761;
            local_a0 = 6;
            local_90 = 6;
            uVar4 = *param_6;
            local_98 = puVar2;
            lVar3 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                              (&local_48,uVar4,(int)param_6[1]);
            local_b0 = (undefined4 *)((uVar4 & 0xffffffff) / 1000000 + lVar3 * 1000);
            local_c0 = CONCAT31(local_c0._1_3_,2);
            uStack_b8 = 0;
            <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
            ::insert(&local_88,local_60,&local_a0,&local_c0);
            if ((char)local_88 != -1) {
              core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
                        (&local_88);
            }
            __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
            uVar5 = 3;
            puVar2 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(3,1);
            if (puVar2 != (undefined4 *)0x0) {
              *(undefined1 *)((longlong)puVar2 + 2) = 0x67;
              *(undefined2 *)puVar2 = 0x736d;
              local_a0 = 3;
              local_90 = 3;
              local_98 = puVar2;
              <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg_as_serde_core[7f01a81d286c67f3]::ser::Serialize>
              ::serialize::<serde_json[7404bcab4dc139c7]::value::ser::Serializer>
                        (&local_c0,param_6 + 4);
              if ((char)local_c0 != -1) {
                local_78 = (undefined4)local_b0;
                uStack_74 = local_b0._4_4_;
                uStack_70 = (undefined4)uStack_a8;
                uStack_6c = uStack_a8._4_4_;
                local_88 = CONCAT44(uStack_bc,local_c0);
                uStack_80 = (undefined4)uStack_b8;
                uStack_7c = uStack_b8._4_4_;
                <alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                ::insert(&local_c0,local_60,&local_a0,&local_88);
                if ((char)local_c0 != -1) {
                  core[505b25137b8ba7f]::ptr::drop_glue::
                  <serde_json[7404bcab4dc139c7]::value::Value>(&local_c0);
                }
                uStack_b8 = local_60[0];
                uStack_a8 = local_50;
                local_c0 = CONCAT31(local_c0._1_3_,5);
                host_probe[b94139f9089eb1d8]::ingame_chat::transport::packet(param_1,&local_c0);
                return;
              }
              local_88 = uStack_b8;
              core[505b25137b8ba7f]::result::unwrap_failed
                        ("called `Result::unwrap()` on an `Err` value",0x2b,&local_88,
                         &PTR_<serde_json[7404bcab4dc139c7]::error::Error>_1406a1150,
                         &PTR_s_src_ingame_chat_transport_rs_1406a1550);
              goto LAB_1400141a3;
            }
          }
        }
      }
    }
  }
  alloc[246c2e7857c81348]::raw_vec::handle_error(1,uVar5);
LAB_1400141a3:
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

