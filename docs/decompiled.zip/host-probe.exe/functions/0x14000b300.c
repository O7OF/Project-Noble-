// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::netstats::start::{closure#1}::{closure#0}
// address: 0x14000b300
// body: available
// range: 0x14000b300-0x14000b789 inclusive
// range: 0x14000b790-0x14000bda5 inclusive
// range: 0x14000bdb0-0x14000bdf0 inclusive
// range: 0x14000be00-0x14000be4f inclusive
// range: 0x14000be60-0x14000c3ea inclusive
// range: 0x14000c3f0-0x14000c48c inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000bc2b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000bccc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000bd46 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000bdec to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000be4b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000be76 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000c3e6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::netstats::start::{closure#1}::{closure#0} */

void __rustcall
host_probe[b94139f9089eb1d8]::netstats::start::{closure#1}::_closure_0_(undefined8 param_1)

{
  longlong lVar1;
  longlong lVar2;
  code *pcVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  longlong lVar14;
  longlong lVar15;
  longlong lVar16;
  longlong lVar17;
  longlong lVar18;
  longlong lVar19;
  longlong lVar20;
  longlong lVar21;
  longlong *plVar22;
  longlong *plVar23;
  undefined8 uVar24;
  byte bVar25;
  char cVar26;
  int iVar27;
  undefined8 uVar28;
  undefined8 uVar29;
  undefined4 uVar30;
  longlong *plVar31;
  longlong *plVar32;
  longlong *plVar33;
  ulonglong uVar34;
  bool bVar35;
  undefined1 auVar36 [16];
  double dVar37;
  undefined8 uVar38;
  undefined8 uVar39;
  undefined8 uVar40;
  undefined8 uVar41;
  longlong local_568;
  longlong local_560;
  longlong local_558;
  longlong local_550;
  longlong local_548;
  longlong local_540;
  longlong local_538;
  longlong local_530;
  longlong local_528;
  longlong local_520;
  longlong local_518;
  longlong local_510;
  longlong local_508;
  longlong local_500;
  longlong local_4f8;
  longlong local_4f0;
  longlong local_4e8;
  longlong local_4e0;
  longlong local_4d8;
  undefined8 local_458;
  int local_450;
  longlong *local_448;
  longlong *local_440;
  longlong *local_438;
  longlong *local_430;
  longlong local_428;
  longlong local_420;
  longlong local_418;
  longlong local_410;
  longlong local_408;
  longlong local_400;
  longlong local_3f8;
  longlong local_3f0;
  longlong local_3e8;
  longlong local_3e0;
  longlong local_3d8;
  longlong local_3d0;
  longlong local_3c8;
  longlong local_3c0;
  longlong local_3b8;
  undefined8 local_3b0;
  undefined8 local_3a8;
  undefined8 local_3a0;
  undefined8 local_398;
  undefined8 local_390;
  undefined8 local_388;
  undefined8 local_380;
  undefined8 local_378;
  undefined8 local_370;
  undefined8 local_368;
  undefined8 local_360;
  undefined8 local_358;
  undefined8 local_350;
  undefined8 local_348;
  undefined8 local_340;
  undefined8 local_338;
  undefined8 local_330;
  undefined8 local_328;
  undefined8 local_320;
  undefined8 local_318;
  undefined8 local_310;
  undefined8 local_308;
  undefined8 local_300;
  undefined8 local_2f8;
  undefined8 local_2f0;
  undefined8 local_2e8;
  undefined8 local_2e0;
  undefined8 local_2d8;
  undefined8 local_2d0;
  undefined8 local_2c8;
  undefined8 local_2c0;
  undefined8 local_2b8;
  undefined8 local_2b0;
  longlong local_2a8;
  undefined8 local_2a0;
  undefined8 local_298;
  undefined8 local_290;
  undefined8 local_288;
  undefined8 local_280;
  undefined8 local_278;
  undefined8 local_270;
  undefined8 local_268;
  undefined8 local_260;
  undefined8 local_258;
  undefined8 local_250;
  undefined8 local_248;
  undefined8 local_240;
  undefined8 local_238;
  undefined8 local_230;
  undefined8 local_228;
  undefined8 local_220;
  undefined8 local_218;
  undefined8 local_210;
  undefined8 local_208;
  undefined8 local_200;
  undefined8 local_1f8;
  undefined8 local_1f0;
  undefined8 local_1e8;
  undefined8 local_1e0;
  undefined8 local_1d8;
  undefined8 local_1d0;
  undefined8 local_1c8;
  undefined8 local_1c0;
  undefined8 local_1b8;
  undefined8 local_1b0;
  undefined8 local_1a8;
  undefined8 local_1a0;
  undefined8 local_198;
  undefined8 local_190;
  undefined8 local_188;
  undefined8 local_180;
  undefined8 local_178;
  undefined8 local_170;
  undefined8 local_168;
  undefined8 local_160;
  undefined8 local_158;
  undefined8 local_150;
  undefined8 local_148;
  undefined8 local_140;
  undefined8 local_138;
  undefined8 local_130;
  undefined8 local_128;
  undefined8 local_120;
  undefined8 local_118;
  undefined8 local_110;
  undefined8 local_108;
  undefined8 local_100;
  undefined8 local_f8;
  undefined8 local_f0;
  undefined8 local_e8;
  undefined8 local_e0;
  undefined8 local_d8;
  undefined8 local_d0;
  undefined8 local_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  undefined8 local_98;
  undefined8 local_90;
  
  local_1f8 = C;
  local_1f0 = DAT_1407f1048;
  local_1e8 = DAT_1407f1050;
  local_1e0 = DAT_1407f1058;
  local_1d8 = DAT_1407f1060;
  local_1d0 = DAT_1407f1068;
  local_1c8 = DAT_1407f1070;
  local_1c0 = DAT_1407f1078;
  local_1b8 = DAT_1407f1080;
  local_1b0 = DAT_1407f1088;
  local_1a8 = DAT_1407f1090;
  local_1a0 = DAT_1407f1098;
  local_198 = DAT_1407f10a0;
  local_190 = DAT_1407f10a8;
  local_188 = DAT_1407f10b0;
  local_180 = DAT_1407f10b8;
  local_178 = DAT_1407f10c0;
  local_170 = DAT_1407f10c8;
  local_168 = DAT_1407f10d0;
  local_160 = DAT_1407f10d8;
  local_158 = DAT_1407f10e0;
  local_150 = DAT_1407f10e8;
  local_148 = DAT_1407f10f0;
  local_568 = CLASS_UPDATES;
  local_560 = DAT_1407f0f78;
  local_558 = DAT_1407f0f80;
  local_550 = DAT_1407f0f88;
  local_548 = DAT_1407f0f90;
  local_538 = DAT_1407f0f98;
  local_530 = DAT_1407f0fa0;
  local_528 = DAT_1407f0fa8;
  local_520 = DAT_1407f0fb0;
  local_518 = DAT_1407f0fb8;
  local_510 = DAT_1407f0fc0;
  local_508 = DAT_1407f0fc8;
  local_540 = DAT_1407f0fd0;
  local_500 = DAT_1407f0fd8;
  local_4f8 = DAT_1407f0fe0;
  local_4f0 = DAT_1407f0fe8;
  local_4e8 = DAT_1407f0ff0;
  local_4e0 = DAT_1407f0ff8;
  local_4d8 = DAT_1407f1000;
  local_3b0 = CLASS_BITS;
  local_3a8 = DAT_1407f0ee0;
  local_3a0 = DAT_1407f0ee8;
  local_398 = DAT_1407f0ef0;
  local_390 = DAT_1407f0ef8;
  local_388 = DAT_1407f0f00;
  local_380 = DAT_1407f0f08;
  local_378 = DAT_1407f0f10;
  local_370 = DAT_1407f0f18;
  local_368 = DAT_1407f0f20;
  local_360 = DAT_1407f0f28;
  local_358 = DAT_1407f0f30;
  local_350 = DAT_1407f0f38;
  local_348 = DAT_1407f0f40;
  local_340 = DAT_1407f0f48;
  local_338 = DAT_1407f0f50;
  local_330 = DAT_1407f0f58;
  local_328 = DAT_1407f0f60;
  local_320 = DAT_1407f0f68;
  uVar29 = DAT_1407f0ee8;
  local_318 = param_1;
  local_458 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  local_450 = (int)uVar29;
  do {
    std[3bf9d48a0c3997f0]::thread::functions::sleep(local_318,0);
    local_140 = C;
    local_138 = DAT_1407f1048;
    local_130 = DAT_1407f1050;
    local_128 = DAT_1407f1058;
    local_120 = DAT_1407f1060;
    local_118 = DAT_1407f1068;
    local_110 = DAT_1407f1070;
    local_108 = DAT_1407f1078;
    local_100 = DAT_1407f1080;
    local_f8 = DAT_1407f1088;
    local_f0 = DAT_1407f1090;
    local_e8 = DAT_1407f1098;
    local_e0 = DAT_1407f10a0;
    local_d8 = DAT_1407f10a8;
    local_d0 = DAT_1407f10b0;
    local_c8 = DAT_1407f10b8;
    local_c0 = DAT_1407f10c0;
    local_b8 = DAT_1407f10c8;
    local_b0 = DAT_1407f10d0;
    local_a8 = DAT_1407f10d8;
    local_a0 = DAT_1407f10e0;
    local_98 = DAT_1407f10e8;
    local_90 = DAT_1407f10f0;
    uVar29 = DAT_1407f1050;
    uVar28 = <std[3bf9d48a0c3997f0]::time::Instant>::elapsed(&local_458);
    auVar36._8_4_ = (int)((ulonglong)uVar28 >> 0x20);
    auVar36._0_8_ = uVar28;
    auVar36._12_4_ = 0x45300000;
    iVar27 = (int)uVar29;
    dVar37 = (double)iVar27 / 1000000000.0 +
             (auVar36._8_8_ - 1.9342813113834067e+25) +
             ((double)CONCAT44(0x43300000,(int)uVar28) - 4503599627370496.0);
    local_458 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    local_450 = iVar27;
    line(&local_448,&local_1f8,&local_140,dVar37);
    plVar31 = local_440;
    host::log(local_440,local_438);
    if (local_448 != (longlong *)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar31,local_448,1);
      return;
    }
    LOCK();
    bVar35 = ARRIVALS == '\0';
    if (bVar35) {
      ARRIVALS = '\x01';
    }
    UNLOCK();
    plVar31 = local_448;
    if (!bVar35) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&ARRIVALS);
    }
    uVar30 = SUB84(plVar31,0);
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar25 = 0;
    }
    else {
      bVar25 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar25 = bVar25 ^ 1;
    }
    if (DAT_1407f1009 != '\0') {
      local_448 = (longlong *)&ARRIVALS;
      uVar34 = (ulonglong)local_440 >> 8;
      local_440 = (longlong *)CONCAT71((int7)uVar34,bVar25);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&local_448,
                 &
                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0f30
                 ,&PTR_s_src_netstats_rs_1406a0628);
                    /* WARNING: Does not return */
      pcVar3 = (code *)invalidInstructionException();
      (*pcVar3)();
    }
    if (DAT_1407f1010 != 0) {
      uVar29 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
      <host_probe[b94139f9089eb1d8]::netstats::Arrivals>::take_line
                (&local_448,&DAT_1407f1010,uVar29,uVar30,4);
      plVar31 = local_440;
      host::log(local_440,local_438);
      if (local_448 != (longlong *)0x0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar31,local_448,1);
        return;
      }
    }
    if (((bVar25 == 0) &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar26 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar26 == '\0')
       ) {
      DAT_1407f1009 = '\x01';
    }
    cVar26 = ARRIVALS;
    LOCK();
    ARRIVALS = '\0';
    UNLOCK();
    if (cVar26 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&ARRIVALS);
    }
    rategate::report(&local_448,dVar37);
    plVar4 = local_440;
    plVar31 = local_448;
    if ((local_448 != (longlong *)0xffffffffffffffff) &&
       (host::log(local_440,local_438), plVar31 != (longlong *)0x0)) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar4,plVar31,1);
      return;
    }
    committed::report(&local_448,dVar37);
    plVar32 = local_438;
    plVar23 = local_440;
    plVar22 = local_448;
    plVar31 = local_440 + (longlong)local_438 * 3;
    local_448 = local_440;
    local_438 = plVar22;
    plVar33 = local_440;
    plVar4 = local_440;
    local_430 = plVar31;
    if (plVar32 != (longlong *)0x0) {
      do {
        plVar32 = plVar4 + 3;
        lVar1 = *plVar4;
        plVar33 = plVar32;
        if (lVar1 == -1) break;
        lVar2 = plVar4[1];
        host::log(lVar2,plVar4[2]);
        if (lVar1 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar2,lVar1,1);
          return;
        }
        plVar33 = plVar31;
        plVar4 = plVar32;
      } while (plVar32 != plVar31);
    }
    local_440 = plVar33;
    if (plVar31 != plVar33) {
      uVar34 = (ulonglong)((longlong)plVar31 - (longlong)plVar33) / 0x18;
      plVar33 = plVar33 + 1;
      do {
        if (plVar33[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*plVar33,plVar33[-1],1);
          return;
        }
        plVar33 = plVar33 + 3;
        uVar34 = uVar34 - 1;
      } while (uVar34 != 0);
    }
    if (plVar22 != (longlong *)0x0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(plVar23,(longlong)plVar22 * 0x18,8);
      return;
    }
    memcpy(&local_1f8,&local_140,0xb8);
    lVar21 = DAT_1407f1000;
    lVar20 = DAT_1407f0ff8;
    lVar19 = DAT_1407f0ff0;
    lVar18 = DAT_1407f0fe8;
    lVar17 = DAT_1407f0fe0;
    lVar16 = DAT_1407f0fd8;
    lVar15 = DAT_1407f0fd0;
    lVar14 = DAT_1407f0fc8;
    lVar13 = DAT_1407f0fc0;
    lVar12 = DAT_1407f0fb8;
    lVar11 = DAT_1407f0fb0;
    lVar10 = DAT_1407f0fa8;
    lVar9 = DAT_1407f0fa0;
    lVar8 = DAT_1407f0f98;
    lVar7 = DAT_1407f0f90;
    lVar6 = DAT_1407f0f88;
    lVar5 = DAT_1407f0f80;
    lVar2 = DAT_1407f0f78;
    lVar1 = CLASS_UPDATES;
    uVar29 = DAT_1407f0f68;
    local_290 = CLASS_BITS;
    local_2b0 = DAT_1407f0ee0;
    local_288 = DAT_1407f0ee0;
    local_2b8 = DAT_1407f0ee8;
    local_280 = DAT_1407f0ee8;
    local_2c0 = DAT_1407f0ef0;
    local_278 = DAT_1407f0ef0;
    local_2c8 = DAT_1407f0ef8;
    local_270 = DAT_1407f0ef8;
    local_2d0 = DAT_1407f0f00;
    local_268 = DAT_1407f0f00;
    local_2d8 = DAT_1407f0f08;
    local_260 = DAT_1407f0f08;
    local_2e0 = DAT_1407f0f10;
    local_258 = DAT_1407f0f10;
    local_2e8 = DAT_1407f0f18;
    local_250 = DAT_1407f0f18;
    local_2f0 = DAT_1407f0f20;
    local_248 = DAT_1407f0f20;
    local_240 = DAT_1407f0f28;
    local_2f8 = DAT_1407f0f30;
    local_238 = DAT_1407f0f30;
    local_300 = DAT_1407f0f38;
    local_230 = DAT_1407f0f38;
    local_308 = DAT_1407f0f40;
    local_228 = DAT_1407f0f40;
    local_310 = DAT_1407f0f48;
    local_220 = DAT_1407f0f48;
    local_218 = DAT_1407f0f50;
    local_210 = DAT_1407f0f58;
    local_208 = DAT_1407f0f60;
    local_200 = DAT_1407f0f68;
    uVar28 = DAT_1407f0f60;
    uVar38 = DAT_1407f0f58;
    uVar39 = DAT_1407f0f50;
    uVar40 = DAT_1407f0f28;
    uVar41 = CLASS_BITS;
    iVar27 = memcmp(&local_290,&local_3b0,0x98);
    if (iVar27 != 0) {
      local_448 = (longlong *)(lVar1 - local_568);
      local_440 = (longlong *)(lVar2 - local_560);
      local_438 = (longlong *)(lVar5 - local_558);
      local_430 = (longlong *)(lVar6 - local_550);
      local_428 = lVar7 - local_548;
      local_420 = lVar8 - local_538;
      local_418 = lVar9 - local_530;
      local_410 = lVar10 - local_528;
      local_408 = lVar11 - local_520;
      local_400 = lVar12 - local_518;
      local_3f8 = lVar13 - local_510;
      local_3f0 = lVar14 - local_508;
      local_3e8 = lVar15 - local_540;
      local_3e0 = lVar16 - local_500;
      local_3d8 = lVar17 - local_4f8;
      local_3d0 = lVar18 - local_4f0;
      local_3c8 = lVar19 - local_4e8;
      local_3c0 = lVar20 - local_4e0;
      local_3b8 = lVar21 - local_4d8;
      class_line(&local_2a8,&local_3b0,&local_290,&local_448,dVar37,uVar28,uVar38,uVar39,uVar40,
                 uVar41);
      uVar24 = local_2a0;
      host::log(local_2a0,local_298);
      if (local_2a8 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar24,local_2a8,1);
        return;
      }
    }
    local_508 = lVar14;
    local_510 = lVar13;
    local_540 = lVar15;
    local_528 = lVar10;
    local_530 = lVar9;
    local_4f8 = lVar17;
    local_518 = lVar12;
    local_3a8 = local_2b0;
    local_3a0 = local_2b8;
    local_398 = local_2c0;
    local_390 = local_2c8;
    local_388 = local_2d0;
    local_380 = local_2d8;
    local_378 = local_2e0;
    local_370 = local_2e8;
    local_368 = local_2f0;
    local_358 = local_2f8;
    local_350 = local_300;
    local_348 = local_308;
    local_340 = local_310;
    local_320 = uVar29;
    local_4d8 = lVar21;
    local_4e0 = lVar20;
    local_4e8 = lVar19;
    local_4f0 = lVar18;
    local_520 = lVar11;
    local_538 = lVar8;
    local_548 = lVar7;
    local_550 = lVar6;
    local_558 = lVar5;
    local_560 = lVar2;
    local_568 = lVar1;
    local_500 = lVar16;
    local_3b0 = uVar41;
    local_360 = uVar40;
    local_338 = uVar39;
    local_330 = uVar38;
    local_328 = uVar28;
  } while( true );
}

