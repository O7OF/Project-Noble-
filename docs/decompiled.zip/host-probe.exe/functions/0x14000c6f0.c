// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::server_admin::start::{closure#10}
// address: 0x14000c6f0
// body: available
// range: 0x14000c6f0-0x14000c71c inclusive
// range: 0x14000c720-0x14000c7e4 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::server_admin::start::{closure#10} */

void __rustcall
host_probe[b94139f9089eb1d8]::server_admin::start::_closure_10_(longlong param_1,longlong param_2)

{
  char *pcVar1;
  undefined *puVar2;
  char cVar3;
  byte bVar4;
  undefined8 uVar5;
  bool bVar6;
  
  puVar2 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  do {
    std[3bf9d48a0c3997f0]::thread::functions::sleep(2,0);
    uVar5 = reach_directory[4b72b9694f6c3c08]::identity::now_unix();
    pcVar1 = (char *)(param_1 + 0x10);
    LOCK();
    bVar6 = *(char *)(param_1 + 0x10) == '\0';
    if (bVar6) {
      *(char *)(param_1 + 0x10) = '\x01';
    }
    UNLOCK();
    if (!bVar6) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(pcVar1);
    }
    if ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) == 0) {
      bVar4 = 0;
    }
    else {
      bVar4 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar4 = bVar4 ^ 1;
    }
    <reach_directory[4b72b9694f6c3c08]::server_admin::Admin>::enforce
              (param_1 + 0x18,param_2 + 0x10,
               &PTR_<host_probe[b94139f9089eb1d8]::server_admin::Engine>_1406a05b0,uVar5);
    <reach_directory[4b72b9694f6c3c08]::server_admin::Admin>::heartbeat(param_1 + 0x18,uVar5);
    if (((bVar4 == 0) && ((*(ulonglong *)puVar2 & 0x7fffffffffffffff) != 0)) &&
       (cVar3 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar3 == '\0'))
    {
      *(undefined1 *)(param_1 + 0x11) = 1;
    }
    LOCK();
    cVar3 = *pcVar1;
    *pcVar1 = '\0';
    UNLOCK();
    if (cVar3 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar1);
    }
    publish::tick(pcVar1);
  } while( true );
}

