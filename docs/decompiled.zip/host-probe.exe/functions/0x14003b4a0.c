// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::send_vote
// address: 0x14003b4a0
// body: available
// range: 0x14003b4a0-0x14003b650 inclusive
// range: 0x14003b652-0x14003b6e7 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003b64c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::send_vote */

void __rustcall
host_probe[b94139f9089eb1d8]::net::send_vote
          (longlong param_1,longlong param_2,longlong param_3,longlong param_4)

{
  undefined1 (*pauVar1) [16];
  undefined1 auVar2 [16];
  code *pcVar3;
  ulonglong uVar4;
  undefined *puVar5;
  byte bVar6;
  char cVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  bool bVar13;
  longlong local_a0;
  longlong local_98;
  longlong local_90;
  longlong local_88;
  undefined1 (*local_80) [16];
  undefined1 (*local_78) [16];
  undefined1 *local_70;
  ushort local_68;
  undefined8 local_60;
  undefined8 *local_58;
  undefined8 local_50;
  undefined4 local_48;
  
  lVar8 = param_2;
  local_50 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  local_48 = (undefined4)lVar8;
  pauVar1 = (undefined1 (*) [16])(param_1 + 0x118);
  LOCK();
  bVar13 = *(char *)(param_1 + 0x118) == '\0';
  if (bVar13) {
    *(char *)(param_1 + 0x118) = '\x01';
  }
  UNLOCK();
  if (!bVar13) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(pauVar1);
  }
  puVar5 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar6 = 0;
    cVar7 = *(char *)(param_1 + 0x119);
  }
  else {
    bVar6 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar6 = bVar6 ^ 1;
    cVar7 = *(char *)(param_1 + 0x119);
  }
  if (cVar7 != '\0') {
    uVar4 = (ulonglong)local_78 >> 8;
    local_78 = (undefined1 (*) [16])CONCAT71((int7)uVar4,bVar6);
    local_80 = pauVar1;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_80,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a31d0);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  local_80 = *(undefined1 (**) [16])(param_1 + 0x120);
  local_70 = *local_80 + *(longlong *)(param_1 + 0x128) + 1;
  auVar2 = *local_80;
  local_68 = ~((ushort)(SUB161(auVar2 >> 7,0) & 1) | (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
               (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
               (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
               (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
               (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
               (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
               (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
               (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
               (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
               (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
               (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
               (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
               (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
               (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
              (ushort)(byte)(auVar2[0xf] >> 7) << 0xf);
  local_60 = *(undefined8 *)(param_1 + 0x138);
  local_78 = local_80 + 1;
  local_58 = &local_50;
  <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::send_vote::{closure#0}>,host_probe[b94139f9089eb1d8]::net::send_vote::{closure#1}>>>
  ::from_iter(&local_a0,&local_80);
  if (((bVar6 == 0) && ((*(ulonglong *)puVar5 & 0x7fffffffffffffff) != 0)) &&
     (cVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar7 == '\0')) {
    *(undefined1 *)(param_1 + 0x119) = 1;
  }
  LOCK();
  cVar7 = (*pauVar1)[0];
  (*pauVar1)[0] = 0;
  UNLOCK();
  if (cVar7 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pauVar1);
  }
  if (((param_4 != 0) && (local_90 != 0)) && (param_3 != 0)) {
    local_88 = local_98;
    lVar8 = local_98 + local_90 * 0x48;
    lVar9 = 0;
    do {
      lVar9 = lVar9 + 1;
      lVar11 = local_88;
      do {
        lVar12 = lVar11 + 0x48;
        lVar10 = 0;
        do {
          send_route_kind(param_1,lVar11,*(undefined8 *)(param_2 + 8 + lVar10),
                          *(undefined8 *)(param_2 + 0x10 + lVar10),1);
          lVar10 = lVar10 + 0x18;
        } while (param_3 * 0x18 != lVar10);
        lVar11 = lVar12;
      } while (lVar12 != lVar8);
    } while (lVar9 != param_4);
  }
  if (local_a0 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_98,local_a0 * 0x48,8);
    return;
  }
  return;
}

