// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::set_key
// address: 0x14001f670
// body: available
// range: 0x14001f670-0x14001fda5 inclusive
// range: 0x14001fdab-0x14001feff inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14001fc03 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001fc23 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001fc54 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001fc74 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001fd2c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001fd4c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001fd7d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001fda1 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::set_key */

ulonglong __rustcall
host_probe[b94139f9089eb1d8]::ingame_chat::set_key
          (longlong *param_1,longlong param_2,char *param_3,ulonglong param_4)

{
  ulonglong *puVar1;
  undefined1 auVar2 [16];
  code *pcVar3;
  undefined *puVar4;
  byte bVar5;
  byte bVar6;
  char cVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong *puVar10;
  ulonglong *puVar11;
  void *pvVar12;
  ulonglong uVar13;
  ulonglong *puVar14;
  uint uVar15;
  ulonglong uVar16;
  undefined1 *puVar17;
  undefined1 *_Size;
  ulonglong unaff_RBX;
  void *pvVar18;
  ulonglong *puVar19;
  ulonglong uVar20;
  undefined8 uVar21;
  bool bVar22;
  ulonglong local_140 [3];
  ulonglong local_128;
  ulonglong local_120;
  ulonglong local_118;
  undefined8 local_110;
  undefined8 uStack_108;
  undefined8 local_100;
  undefined8 uStack_f8;
  undefined8 local_f0;
  undefined8 uStack_e8;
  undefined1 *local_e0;
  void *local_d8;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined1 *local_98;
  void *local_90;
  undefined1 *local_88;
  undefined1 local_74 [20];
  longlong local_60 [4];
  
  if (param_2 == 0xc) {
    if ((int)param_1[1] == 0x6c617265 && *param_1 == 0x6e65672e74616863) {
      puVar1 = local_140 + 1;
      goto joined_r0x00014001f6e3;
    }
  }
  else if (param_2 == 0xb) {
    if (*(longlong *)((longlong)param_1 + 3) == 0x656c67676f742e74 && *param_1 == 0x676f742e74616863
       ) {
      puVar1 = local_140;
      goto joined_r0x00014001f6e3;
    }
  }
  else if ((param_2 == 9) && ((char)param_1[1] == 'm' && *param_1 == 0x6165742e74616863)) {
    puVar1 = local_140 + 2;
joined_r0x00014001f6e3:
    if (param_4 != 0) {
      if (param_4 == 1) {
        cVar7 = *param_3;
        unaff_RBX = 0;
        uVar13 = unaff_RBX;
        if ((cVar7 == '+') || (cVar7 == '-')) goto LAB_14001f705;
      }
      else {
        cVar7 = *param_3;
      }
      uVar16 = (ulonglong)(cVar7 == '+');
      if (param_4 - uVar16 < 0x11) {
        if (param_4 == uVar16) {
          uVar20 = 0;
        }
        else {
          uVar20 = 0;
          lVar8 = 0;
          do {
            if (9 < (byte)param_3[lVar8 + uVar16] - 0x30) goto LAB_14001f703;
            uVar20 = (ulonglong)((byte)param_3[lVar8 + uVar16] - 0x30) + uVar20 * 10;
            lVar8 = lVar8 + 1;
          } while (lVar8 != param_4 + -uVar16);
        }
      }
      else {
        uVar20 = 0;
        lVar8 = 0;
        do {
          auVar2._8_8_ = 0;
          auVar2._0_8_ = uVar20;
          uVar9 = SUB168(auVar2 * ZEXT816(10),0);
          if (SUB168(auVar2 * ZEXT816(10),8) != 0) goto LAB_14001f703;
          uVar15 = (byte)param_3[lVar8 + uVar16] - 0x30;
          uVar20 = uVar9 + uVar15;
          unaff_RBX = 0;
          uVar13 = unaff_RBX;
          if ((9 < uVar15) || (uVar13 = 0, CARRY8(uVar9,(ulonglong)uVar15))) goto LAB_14001f705;
          lVar8 = lVar8 + 1;
        } while (lVar8 != param_4 + -uVar16);
      }
      LOCK();
      bVar22 = STATE == '\0';
      if (bVar22) {
        STATE = '\x01';
      }
      UNLOCK();
      if (!bVar22) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&STATE);
      }
      puVar11 = (ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar5 = 0;
      }
      else {
        bVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar5 = bVar5 ^ 1;
      }
      if (DAT_140699029 != '\0') {
        local_110 = &STATE;
        uStack_108._1_7_ = (undefined7)((ulonglong)uStack_108 >> 8);
        uStack_108 = (void *)CONCAT71(uStack_108._1_7_,bVar5);
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&local_110,
                   &anon_d5c34e88a06ee720b116585eb143da4b_137_llvm_14435704873730135342,
                   &DAT_1406a1b18);
        goto LAB_14001fe78;
      }
      LOCK();
      bVar22 = LIVE_KEYS == '\0';
      if (bVar22) {
        LIVE_KEYS = '\x01';
      }
      UNLOCK();
      if (!bVar22) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LIVE_KEYS);
      }
      if ((*puVar11 & 0x7fffffffffffffff) == 0) {
        bVar6 = 0;
      }
      else {
        bVar6 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar6 = bVar6 ^ 1;
      }
      if (DAT_1407f0039 != '\0') {
        local_110 = &LIVE_KEYS;
        uStack_108._1_7_ = (undefined7)((ulonglong)uStack_108 >> 8);
        uStack_108 = (void *)CONCAT71(uStack_108._1_7_,bVar6);
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&local_110,
                   &
                   PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0dd0
                   ,&DAT_1406a1b30);
        goto LAB_14001fe78;
      }
      if ((_DAT_1407f0040 & 1) == 0) {
        if (DAT_140699030 != -1) {
          puVar10 = &DAT_140699480;
          puVar14 = &DAT_140699488;
          puVar19 = &DAT_140699490;
          goto LAB_14001f8b1;
        }
        local_140[0] = 0xbf;
        local_140[1] = 0x59;
        local_140[2] = 0x54;
      }
      else {
        puVar10 = &DAT_1407f0048;
        puVar14 = &DAT_1407f0050;
        puVar19 = &DAT_1407f0058;
LAB_14001f8b1:
        local_140[2] = *puVar10;
        local_140[1] = *puVar14;
        local_140[0] = *puVar19;
      }
      uVar16 = *puVar1;
      uVar13 = CONCAT71((int7)(unaff_RBX >> 8),uVar16 == uVar20);
      if (uVar16 == uVar20) {
LAB_14001f8d4:
        if (((bVar6 == 0) && ((*puVar11 & 0x7fffffffffffffff) != 0)) &&
           (cVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
           cVar7 == '\0')) {
          DAT_1407f0039 = '\x01';
        }
        cVar7 = LIVE_KEYS;
        LOCK();
        LIVE_KEYS = '\0';
        UNLOCK();
        if (cVar7 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LIVE_KEYS);
        }
        if (((bVar5 == 0) && ((*puVar11 & 0x7fffffffffffffff) != 0)) &&
           (cVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
           cVar7 == '\0')) {
          DAT_140699029 = '\x01';
        }
        LOCK();
        UNLOCK();
      }
      else {
        if (local_140[2] == uVar20) {
          puVar11 = local_140 + 2;
LAB_14001f960:
          *puVar11 = uVar16;
        }
        else {
          if (local_140[1] == uVar20) {
            puVar11 = local_140 + 1;
            goto LAB_14001f960;
          }
          if (local_140[0] == uVar20) {
            puVar11 = local_140;
            goto LAB_14001f960;
          }
        }
        *puVar1 = uVar20;
        uVar20 = local_140[2];
        uVar16 = local_140[1];
        local_118 = local_140[0];
        puVar17 = local_74;
        pvVar12 = (void *)::<u64>::_fmt(local_140[2],puVar17,0x14);
        if ((longlong)puVar17 < 0) {
          uVar21 = 0;
LAB_14001f9a1:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uVar21,puVar17);
          goto LAB_14001fe78;
        }
        local_120 = uVar16;
        pvVar18 = (void *)0x1;
        local_128 = uVar20;
        if (puVar17 != (undefined1 *)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar21 = 1;
          pvVar18 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(puVar17,1);
          if (pvVar18 == (void *)0x0) goto LAB_14001f9a1;
          memcpy(pvVar18,pvVar12,(size_t)puVar17);
        }
        uVar16 = local_128;
        _Size = local_74;
        local_110 = puVar17;
        uStack_108 = pvVar18;
        local_100 = puVar17;
        pvVar12 = (void *)::<u64>::_fmt(local_120,_Size,0x14);
        if ((longlong)_Size < 0) {
          uVar21 = 0;
LAB_14001fa42:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uVar21,_Size);
          goto LAB_14001fe78;
        }
        if (_Size == (undefined1 *)0x0) {
          pvVar18 = (void *)0x1;
        }
        else {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar21 = 1;
          pvVar18 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(_Size,1);
          if (pvVar18 == (void *)0x0) goto LAB_14001fa42;
          memcpy(pvVar18,pvVar12,(size_t)_Size);
          uVar16 = local_128;
        }
        puVar17 = local_74;
        uStack_f8 = _Size;
        local_f0 = pvVar18;
        uStack_e8 = _Size;
        pvVar12 = (void *)::<u64>::_fmt(local_118,puVar17,0x14);
        if ((longlong)puVar17 < 0) {
          uVar21 = 0;
LAB_14001fae3:
          alloc[246c2e7857c81348]::raw_vec::handle_error(uVar21,puVar17);
LAB_14001fe78:
                    /* WARNING: Does not return */
          pcVar3 = (code *)invalidInstructionException();
          (*pcVar3)();
        }
        if (puVar17 == (undefined1 *)0x0) {
          pvVar18 = (void *)0x1;
        }
        else {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar21 = 1;
          pvVar18 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(puVar17,1);
          if (pvVar18 == (void *)0x0) goto LAB_14001fae3;
          memcpy(pvVar18,pvVar12,(size_t)puVar17);
        }
        local_c8 = (undefined4)local_110;
        uStack_c4 = local_110._4_4_;
        uStack_c0 = (undefined4)uStack_108;
        uStack_bc = uStack_108._4_4_;
        local_b8 = (undefined4)local_100;
        uStack_b4 = local_100._4_4_;
        uStack_b0 = (undefined4)uStack_f8;
        uStack_ac = uStack_f8._4_4_;
        local_a8 = (undefined4)local_f0;
        uStack_a4 = local_f0._4_4_;
        uStack_a0 = (undefined4)uStack_e8;
        uStack_9c = uStack_e8._4_4_;
        local_e0 = puVar17;
        local_d8 = pvVar18;
        local_98 = puVar17;
        local_90 = pvVar18;
        local_88 = puVar17;
        alloc[246c2e7857c81348]::str::join_generic_copy::
        <str,u8,alloc[246c2e7857c81348]::string::String>(&local_110,&local_c8,3,&DAT_1406a1b48,1);
        pvVar12 = uStack_108;
        puVar17 = local_110;
        parse_keys(local_60,uStack_108,local_100);
        puVar4 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
        if (local_60[0] == 0) {
          if (puVar17 != (undefined1 *)0x0) {
            uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar12,puVar17,1);
            return uVar13;
          }
          if (CONCAT44(uStack_c4,local_c8) != 0) {
            uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc
                               (CONCAT44(uStack_bc,uStack_c0),CONCAT44(uStack_c4,local_c8),1);
            return uVar13;
          }
          if (CONCAT44(uStack_ac,uStack_b0) != 0) {
            uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc
                               (CONCAT44(uStack_a4,local_a8),CONCAT44(uStack_ac,uStack_b0),1);
            return uVar13;
          }
          puVar11 = (ulonglong *)
                    __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
          if (local_98 != (undefined1 *)0x0) {
            uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_90,local_98,1);
            return uVar13;
          }
          goto LAB_14001f8d4;
        }
        if (puVar17 != (undefined1 *)0x0) {
          uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar12,puVar17,1);
          return uVar13;
        }
        if (CONCAT44(uStack_c4,local_c8) != 0) {
          uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc
                             (CONCAT44(uStack_bc,uStack_c0),CONCAT44(uStack_c4,local_c8),1);
          return uVar13;
        }
        if (CONCAT44(uStack_ac,uStack_b0) != 0) {
          uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc
                             (CONCAT44(uStack_a4,local_a8),CONCAT44(uStack_ac,uStack_b0),1);
          return uVar13;
        }
        if (local_98 != (undefined1 *)0x0) {
          uVar13 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_90,local_98,1);
          return uVar13;
        }
        _DAT_1407f0040 = 1;
        DAT_1407f0050 = local_120;
        DAT_1407f0058 = local_118;
        if (DAT_140699030 != -1) {
          DAT_140699488 = local_120;
          DAT_140699490 = local_118;
          _DAT_140699498 = 0;
          DAT_14069949a = 0;
          DAT_140699480 = uVar16;
        }
        DAT_1407f0048 = uVar16;
        if (((bVar6 == 0) &&
            ((*(ulonglong *)
               __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
             0x7fffffffffffffff) != 0)) &&
           (cVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
           cVar7 == '\0')) {
          DAT_1407f0039 = '\x01';
        }
        cVar7 = LIVE_KEYS;
        LOCK();
        LIVE_KEYS = '\0';
        UNLOCK();
        if (cVar7 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LIVE_KEYS);
        }
        if (((bVar5 == 0) && ((*(ulonglong *)puVar4 & 0x7fffffffffffffff) != 0)) &&
           (cVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
           cVar7 == '\0')) {
          DAT_140699029 = '\x01';
        }
        LOCK();
        UNLOCK();
        uVar13 = 0x7fffffffffffff01;
      }
      bVar22 = STATE == '\x02';
      STATE = '\0';
      if (bVar22) {
        STATE = '\0';
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&STATE);
      }
      goto LAB_14001f705;
    }
  }
LAB_14001f703:
  uVar13 = 0;
LAB_14001f705:
  return uVar13 & 0xffffffff;
}

