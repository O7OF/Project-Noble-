// rea decompile_all
// name: <[f32;3usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<f32>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<f32>>::wrap_mut_1<f32,host_probe[b94139f9089eb1d8]::srgb::of::{closure#0}>::{closure#0}>
// address: 0x140002740
// body: available
// range: 0x140002740-0x140002931 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <[f32; 3usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<f32>,
   <core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<f32>>::wrap_mut_1<f32,
   host_probe[b94139f9089eb1d8]::srgb::of::{closure#0}>::{closure#0}> */

float * __rustcall
<[f32;3usize]>::try_map::
<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<f32>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<f32>>::wrap_mut_1<f32,host_probe[b94139f9089eb1d8]::srgb::of::_closure_0_>::_closure_0_>
          (float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  fVar4 = param_2[1];
  fVar2 = param_2[2];
  fVar3 = 0.0;
  if (0.0 <= *param_2) {
    fVar3 = *param_2;
  }
  fVar1 = 1.0;
  if (fVar3 <= 1.0) {
    fVar1 = fVar3;
  }
  fVar1 = (float)roundf(fVar1 * 255.0);
  fVar3 = 0.0;
  if (0.0 <= fVar1) {
    fVar3 = fVar1;
  }
  fVar1 = 255.0;
  if (fVar3 <= 255.0) {
    fVar1 = fVar3;
  }
  fVar3 = (float)((int)fVar1 & 0xff) / 255.0;
  if (fVar3 <= 0.04045) {
    fVar3 = fVar3 / 12.92;
  }
  else {
    fVar3 = powf((fVar3 + 0.055) / 1.055,2.4);
  }
  fVar1 = 0.0;
  if (0.0 <= fVar4) {
    fVar1 = fVar4;
  }
  fVar4 = 1.0;
  if (fVar1 <= 1.0) {
    fVar4 = fVar1;
  }
  fVar1 = (float)roundf(fVar4 * 255.0);
  fVar4 = 0.0;
  if (0.0 <= fVar1) {
    fVar4 = fVar1;
  }
  fVar1 = 255.0;
  if (fVar4 <= 255.0) {
    fVar1 = fVar4;
  }
  fVar4 = (float)((int)fVar1 & 0xff) / 255.0;
  if (fVar4 <= 0.04045) {
    fVar4 = fVar4 / 12.92;
  }
  else {
    fVar4 = powf((fVar4 + 0.055) / 1.055,2.4);
  }
  fVar1 = 0.0;
  if (0.0 <= fVar2) {
    fVar1 = fVar2;
  }
  fVar2 = 1.0;
  if (fVar1 <= 1.0) {
    fVar2 = fVar1;
  }
  fVar1 = (float)roundf(fVar2 * 255.0);
  fVar2 = 0.0;
  if (0.0 <= fVar1) {
    fVar2 = fVar1;
  }
  fVar1 = 255.0;
  if (fVar2 <= 255.0) {
    fVar1 = fVar2;
  }
  fVar2 = (float)((int)fVar1 & 0xff) / 255.0;
  if (fVar2 <= 0.04045) {
    fVar2 = fVar2 / 12.92;
  }
  else {
    fVar2 = powf((fVar2 + 0.055) / 1.055,2.4);
  }
  *param_1 = fVar3;
  param_1[1] = fVar4;
  param_1[2] = fVar2;
  return param_1;
}

