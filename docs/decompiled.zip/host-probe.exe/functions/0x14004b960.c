// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#0}>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#1}>>>::from_iter
// address: 0x14004b960
// body: available
// range: 0x14004b960-0x14004ba2e inclusive
// range: 0x14004ba30-0x14004baea inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,
   host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#0}>,
   host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#1}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#0}>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#1}>>>
::from_iter(longlong *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong local_e0;
  longlong *plStack_d8;
  longlong local_d0;
  longlong local_c8;
  longlong lStack_c0;
  longlong local_b8;
  undefined4 local_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 local_a0;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  
  <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#0}>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::next(&local_c8);
  if (local_c8 == -1) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
    if (plVar4 == (longlong *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    plVar4[2] = local_b8;
    *plVar4 = local_c8;
    plVar4[1] = lStack_c0;
    local_e0 = 4;
    local_d0 = 1;
    local_58 = *(undefined8 *)(param_2 + 0x10);
    uStack_50 = *(undefined8 *)(param_2 + 0x12);
    local_98 = *param_2;
    uStack_94 = param_2[1];
    uStack_90 = param_2[2];
    uStack_8c = param_2[3];
    local_88 = *(undefined8 *)(param_2 + 4);
    uStack_80 = *(undefined8 *)(param_2 + 6);
    local_78 = *(undefined8 *)(param_2 + 8);
    uStack_70 = *(undefined8 *)(param_2 + 10);
    local_68 = *(undefined8 *)(param_2 + 0xc);
    uStack_60 = *(undefined8 *)(param_2 + 0xe);
    lVar5 = 0;
    plStack_d8 = plVar4;
    while( true ) {
      lVar3 = local_d0;
      <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::str::iter::Split<char>>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#0}>,host_probe[b94139f9089eb1d8]::steam::quoted_tokens::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
      ::next(&local_b0,&local_98);
      if (CONCAT44(uStack_ac,local_b0) == -1) break;
      if (lVar3 == local_e0) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_e0,lVar3,1,8,0x18);
        plVar4 = plStack_d8;
      }
      *(undefined8 *)(lVar5 + 0x28 + (longlong)plVar4) = local_a0;
      puVar1 = (undefined4 *)(lVar5 + 0x18 + (longlong)plVar4);
      *puVar1 = local_b0;
      puVar1[1] = uStack_ac;
      puVar1[2] = uStack_a8;
      puVar1[3] = uStack_a4;
      local_d0 = lVar3 + 1;
      lVar5 = lVar5 + 0x18;
    }
    param_1[2] = local_d0;
    *param_1 = local_e0;
    param_1[1] = (longlong)plStack_d8;
  }
  return param_1;
}

