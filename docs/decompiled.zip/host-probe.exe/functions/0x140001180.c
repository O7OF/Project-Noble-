// rea decompile_all
// name: __tmainCRTStartup
// address: 0x140001180
// body: available
// range: 0x140001180-0x1400011a6 inclusive
// range: 0x1400011b0-0x140001317 inclusive
// range: 0x140001320-0x140001376 inclusive
// range: 0x140001380-0x140001395 inclusive
// range: 0x1400013a0-0x1400013bd inclusive
// range: 0x1400013c0-0x1400013ce inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400013ca to 0x1406984a0 exit (external=false, thunk=false, hasNoReturn=true); fallthrough is excluded by Ghidra's flow model. This records Ghidra's FunctionManager flag, not an independent verification that the callee cannot return.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


int __tmainCRTStartup(void)

{
  int iVar1;
  undefined8 *puVar2;
  longlong lVar3;
  int iVar4;
  longlong lVar5;
  char **ppcVar6;
  size_t sVar7;
  void *_Dst;
  longlong lVar8;
  size_t _Size;
  char **ppcVar9;
  longlong unaff_GS_OFFSET;
  bool bVar10;
  
  lVar3 = *(longlong *)(*(longlong *)(unaff_GS_OFFSET + 0x30) + 8);
  while( true ) {
    lVar8 = 0;
    LOCK();
    bVar10 = __native_startup_lock == 0;
    lVar5 = lVar3;
    if (!bVar10) {
      lVar8 = __native_startup_lock;
      lVar5 = __native_startup_lock;
    }
    __native_startup_lock = lVar5;
    UNLOCK();
    if (bVar10) break;
    if (lVar3 == lVar8) {
      bVar10 = true;
joined_r0x0001400011d7:
      if (__native_startup_state == 1) {
        _amsg_exit(0x1f);
      }
      else if (__native_startup_state == 0) {
        __native_startup_state = 1;
        _initterm(&___crt_xc_end__,&__xi_z);
      }
      else {
        has_cctor = 1;
      }
      if (__native_startup_state == 1) {
        _initterm(&__xc_a,&__xc_z);
        __native_startup_state = 2;
      }
      if (!bVar10) {
        LOCK();
        __native_startup_lock = 0;
        UNLOCK();
      }
      tls_callback_0(0,2,0);
      _pei386_runtime_relocator();
      __mingw_oldexcpt_handler = SetUnhandledExceptionFilter(_gnu_exception_handler);
      mingw_set_invalid_parameter_handler(FUN_140001000);
      _fpreset();
      iVar4 = argc;
      iVar1 = argc + 1;
      _Size = (longlong)iVar1 * 8;
      ppcVar6 = malloc(_Size);
      lVar3 = (longlong)argv;
      ppcVar9 = ppcVar6;
      if (0 < iVar4) {
        lVar8 = 0;
        do {
          sVar7 = strlen(*(char **)(lVar3 + lVar8));
          _Dst = malloc(sVar7 + 1);
          *(void **)((longlong)ppcVar6 + lVar8) = _Dst;
          puVar2 = (undefined8 *)(lVar3 + lVar8);
          lVar8 = lVar8 + 8;
          memcpy(_Dst,(void *)*puVar2,sVar7 + 1);
        } while (_Size - 8 != lVar8);
        ppcVar9 = ppcVar6 + (longlong)iVar1 + -1;
      }
      *ppcVar9 = (char *)0x0;
      argv = ppcVar6;
      __main();
      iVar1 = argc;
      ppcVar9 = envp;
      *(char ***)__initenv_exref = envp;
      mainret = main(iVar1,argv,ppcVar9);
      if (managedapp != 0) {
        if (has_cctor != 0) {
          return mainret;
        }
        _cexit();
        return mainret;
      }
                    /* WARNING: Subroutine does not return */
      exit(mainret);
    }
    Sleep(1000);
  }
  bVar10 = false;
  goto joined_r0x0001400011d7;
}

