// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::is_host_route
// address: 0x140024c40
// body: available
// range: 0x140024c40-0x140024dba inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::is_host_route */

byte __rustcall
host_probe[b94139f9089eb1d8]::net::is_host_route
          (longlong *param_1,longlong param_2,longlong param_3,short *param_4,byte param_5,
          longlong param_6,longlong param_7)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  ulonglong uVar4;
  longlong lVar5;
  longlong lVar6;
  uint uVar7;
  ushort uVar8;
  longlong lVar9;
  byte bVar10;
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  longlong local_40;
  
  if ((param_2 == 1) && (param_1[3] != 0)) {
    local_40 = param_3;
    uVar4 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
            ::hash_one::<&usize>(param_1 + 4,&local_40);
    lVar5 = *param_1;
    bVar10 = (byte)(uVar4 >> 0x39);
    auVar11 = ZEXT216(CONCAT11(bVar10,bVar10));
    auVar11 = pshuflw(auVar11,auVar11,0);
    lVar6 = 0;
    while( true ) {
      uVar4 = uVar4 & param_1[1];
      pcVar1 = (char *)(lVar5 + uVar4);
      auVar13[0] = -(*pcVar1 == auVar11[0]);
      auVar13[1] = -(pcVar1[1] == auVar11[1]);
      auVar13[2] = -(pcVar1[2] == auVar11[2]);
      auVar13[3] = -(pcVar1[3] == auVar11[3]);
      auVar13[4] = -(pcVar1[4] == auVar11[4]);
      auVar13[5] = -(pcVar1[5] == auVar11[5]);
      auVar13[6] = -(pcVar1[6] == auVar11[6]);
      auVar13[7] = -(pcVar1[7] == auVar11[7]);
      auVar13[8] = -(pcVar1[8] == auVar11[0]);
      auVar13[9] = -(pcVar1[9] == auVar11[1]);
      auVar13[10] = -(pcVar1[10] == auVar11[2]);
      auVar13[0xb] = -(pcVar1[0xb] == auVar11[3]);
      auVar13[0xc] = -(pcVar1[0xc] == auVar11[4]);
      auVar13[0xd] = -(pcVar1[0xd] == auVar11[5]);
      auVar13[0xe] = -(pcVar1[0xe] == auVar11[6]);
      auVar13[0xf] = -(pcVar1[0xf] == auVar11[7]);
      uVar8 = (ushort)(SUB161(auVar13 >> 7,0) & 1) | (ushort)(SUB161(auVar13 >> 0xf,0) & 1) << 1 |
              (ushort)(SUB161(auVar13 >> 0x17,0) & 1) << 2 |
              (ushort)(SUB161(auVar13 >> 0x1f,0) & 1) << 3 |
              (ushort)(SUB161(auVar13 >> 0x27,0) & 1) << 4 |
              (ushort)(SUB161(auVar13 >> 0x2f,0) & 1) << 5 |
              (ushort)(SUB161(auVar13 >> 0x37,0) & 1) << 6 |
              (ushort)(SUB161(auVar13 >> 0x3f,0) & 1) << 7 |
              (ushort)(SUB161(auVar13 >> 0x47,0) & 1) << 8 |
              (ushort)(SUB161(auVar13 >> 0x4f,0) & 1) << 9 |
              (ushort)(SUB161(auVar13 >> 0x57,0) & 1) << 10 |
              (ushort)(SUB161(auVar13 >> 0x5f,0) & 1) << 0xb |
              (ushort)(SUB161(auVar13 >> 0x67,0) & 1) << 0xc |
              (ushort)(SUB161(auVar13 >> 0x6f,0) & 1) << 0xd |
              (ushort)(SUB161(auVar13 >> 0x77,0) & 1) << 0xe | (ushort)(auVar13[0xf] >> 7) << 0xf;
      uVar7 = (uint)uVar8;
      while (uVar8 != 0) {
        uVar2 = 0;
        for (uVar3 = uVar7; (uVar3 & 1) == 0; uVar3 = uVar3 >> 1 | 0x80000000) {
          uVar2 = uVar2 + 1;
        }
        lVar9 = (uVar2 + uVar4 & param_1[1]) * -0x50;
        if (param_3 == *(longlong *)(lVar5 + -0x50 + lVar9)) {
          lVar5 = lVar5 + lVar9;
          if (*(short *)(lVar5 + -0x38) != *param_4) goto LAB_140024da4;
          if (*(short *)(lVar5 + -0x38) == 0) {
            if ((*(short *)(lVar5 + -0x32) != param_4[3]) ||
               (*(int *)(lVar5 + -0x36) != *(int *)(param_4 + 1))) goto LAB_140024da4;
          }
          else if ((*(short *)(lVar5 + -0x1c) != param_4[0xe]) ||
                  (((*(int *)(lVar5 + -0x24) != *(int *)(param_4 + 10) ||
                    (*(int *)(lVar5 + -0x20) != *(int *)(param_4 + 0xc))) ||
                   (auVar11[0] = -((char)param_4[2] == *(char *)(lVar5 + -0x34)),
                   auVar11[1] = -(*(char *)((longlong)param_4 + 5) == *(char *)(lVar5 + -0x33)),
                   auVar11[2] = -((char)param_4[3] == *(char *)(lVar5 + -0x32)),
                   auVar11[3] = -(*(char *)((longlong)param_4 + 7) == *(char *)(lVar5 + -0x31)),
                   auVar11[4] = -((char)param_4[4] == *(char *)(lVar5 + -0x30)),
                   auVar11[5] = -(*(char *)((longlong)param_4 + 9) == *(char *)(lVar5 + -0x2f)),
                   auVar11[6] = -((char)param_4[5] == *(char *)(lVar5 + -0x2e)),
                   auVar11[7] = -(*(char *)((longlong)param_4 + 0xb) == *(char *)(lVar5 + -0x2d)),
                   auVar11[8] = -((char)param_4[6] == *(char *)(lVar5 + -0x2c)),
                   auVar11[9] = -(*(char *)((longlong)param_4 + 0xd) == *(char *)(lVar5 + -0x2b)),
                   auVar11[10] = -((char)param_4[7] == *(char *)(lVar5 + -0x2a)),
                   auVar11[0xb] = -(*(char *)((longlong)param_4 + 0xf) == *(char *)(lVar5 + -0x29)),
                   auVar11[0xc] = -((char)param_4[8] == *(char *)(lVar5 + -0x28)),
                   auVar11[0xd] = -(*(char *)((longlong)param_4 + 0x11) == *(char *)(lVar5 + -0x27))
                   , auVar11[0xe] = -((char)param_4[9] == *(char *)(lVar5 + -0x26)),
                   auVar11[0xf] = -(*(char *)((longlong)param_4 + 0x13) == *(char *)(lVar5 + -0x25))
                   , (ushort)((ushort)(SUB161(auVar11 >> 7,0) & 1) |
                              (ushort)(SUB161(auVar11 >> 0xf,0) & 1) << 1 |
                              (ushort)(SUB161(auVar11 >> 0x17,0) & 1) << 2 |
                              (ushort)(SUB161(auVar11 >> 0x1f,0) & 1) << 3 |
                              (ushort)(SUB161(auVar11 >> 0x27,0) & 1) << 4 |
                              (ushort)(SUB161(auVar11 >> 0x2f,0) & 1) << 5 |
                              (ushort)(SUB161(auVar11 >> 0x37,0) & 1) << 6 |
                              (ushort)(SUB161(auVar11 >> 0x3f,0) & 1) << 7 |
                              (ushort)(SUB161(auVar11 >> 0x47,0) & 1) << 8 |
                              (ushort)(SUB161(auVar11 >> 0x4f,0) & 1) << 9 |
                              (ushort)(SUB161(auVar11 >> 0x57,0) & 1) << 10 |
                              (ushort)(SUB161(auVar11 >> 0x5f,0) & 1) << 0xb |
                              (ushort)(SUB161(auVar11 >> 0x67,0) & 1) << 0xc |
                              (ushort)(SUB161(auVar11 >> 0x6f,0) & 1) << 0xd |
                              (ushort)(SUB161(auVar11 >> 0x77,0) & 1) << 0xe |
                             (ushort)(auVar11[0xf] >> 7) << 0xf) != 0xffff)))) goto LAB_140024da4;
          if (*(char *)(lVar5 + -0x18) == '\x01') {
            if ((param_5 & 1) == 0) goto LAB_140024da4;
            param_5 = param_7 == *(longlong *)(lVar5 + -0xf) &&
                      param_6 == *(longlong *)(lVar5 + -0x17);
          }
          else {
            param_5 = param_5 ^ 1;
          }
          goto LAB_140024da6;
        }
        uVar8 = (ushort)(uVar7 - 1) & (ushort)uVar7;
        uVar7 = CONCAT22((short)(uVar7 - 1 >> 0x10),uVar8);
      }
      auVar12[0] = -(*pcVar1 == -1);
      auVar12[1] = -(pcVar1[1] == -1);
      auVar12[2] = -(pcVar1[2] == -1);
      auVar12[3] = -(pcVar1[3] == -1);
      auVar12[4] = -(pcVar1[4] == -1);
      auVar12[5] = -(pcVar1[5] == -1);
      auVar12[6] = -(pcVar1[6] == -1);
      auVar12[7] = -(pcVar1[7] == -1);
      auVar12[8] = -(pcVar1[8] == -1);
      auVar12[9] = -(pcVar1[9] == -1);
      auVar12[10] = -(pcVar1[10] == -1);
      auVar12[0xb] = -(pcVar1[0xb] == -1);
      auVar12[0xc] = -(pcVar1[0xc] == -1);
      auVar12[0xd] = -(pcVar1[0xd] == -1);
      auVar12[0xe] = -(pcVar1[0xe] == -1);
      auVar12[0xf] = -(pcVar1[0xf] == -1);
      if ((((((((((((((((SUB161(auVar12 >> 7,0) & 1) != 0 || (SUB161(auVar12 >> 0xf,0) & 1) != 0) ||
                      (SUB161(auVar12 >> 0x17,0) & 1) != 0) || (SUB161(auVar12 >> 0x1f,0) & 1) != 0)
                    || (SUB161(auVar12 >> 0x27,0) & 1) != 0) || (SUB161(auVar12 >> 0x2f,0) & 1) != 0
                   ) || (SUB161(auVar12 >> 0x37,0) & 1) != 0) ||
                 (SUB161(auVar12 >> 0x3f,0) & 1) != 0) || (SUB161(auVar12 >> 0x47,0) & 1) != 0) ||
               (SUB161(auVar12 >> 0x4f,0) & 1) != 0) || (SUB161(auVar12 >> 0x57,0) & 1) != 0) ||
             (SUB161(auVar12 >> 0x5f,0) & 1) != 0) || (SUB161(auVar12 >> 0x67,0) & 1) != 0) ||
           (SUB161(auVar12 >> 0x6f,0) & 1) != 0) || (SUB161(auVar12 >> 0x77,0) & 1) != 0) ||
          auVar12[0xf] < '\0') break;
      uVar4 = uVar4 + lVar6 + 0x10;
      lVar6 = lVar6 + 0x10;
    }
  }
LAB_140024da4:
  param_5 = 0;
LAB_140024da6:
  return param_5 & 1;
}

