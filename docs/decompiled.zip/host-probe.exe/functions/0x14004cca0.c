// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::netstats::committed::class_report::{closure#2}>,host_probe[b94139f9089eb1d8]::netstats::committed::class_report::{closure#3}>>>::from_iter
// address: 0x14004cca0
// body: available
// range: 0x14004cca0-0x14004d09f inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,
   host_probe[b94139f9089eb1d8]::netstats::committed::class_report::{closure#2}>,
   host_probe[b94139f9089eb1d8]::netstats::committed::class_report::{closure#3}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::netstats::committed::class_report::{closure#2}>,host_probe[b94139f9089eb1d8]::netstats::committed::class_report::{closure#3}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  undefined4 *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  code *pcVar5;
  ulonglong uVar6;
  undefined4 *puVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  longlong lVar12;
  longlong lVar13;
  longlong local_d8;
  undefined4 *local_d0;
  longlong local_c8;
  undefined **local_c0;
  ulonglong local_b8;
  undefined8 local_b0;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined8 local_a0;
  ulonglong *local_98;
  code *local_90;
  longlong local_88;
  code *local_80;
  longlong local_78;
  code *local_70;
  longlong local_68;
  longlong local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  uVar2 = param_2[3];
  uVar11 = param_2[2];
  uVar8 = uVar11;
  if (uVar11 < uVar2) {
    uVar8 = uVar2;
  }
  uVar9 = 0x44;
  if (0x44 < uVar11) {
    uVar9 = uVar11;
  }
  uVar6 = 0x40;
  if (0x40 < uVar11) {
    uVar6 = uVar11;
  }
  if (uVar11 < uVar2) {
    lVar3 = *param_2;
    lVar4 = param_2[1];
    local_78 = uVar11 * -8;
    do {
      if (uVar9 == uVar11) {
        core[505b25137b8ba7f]::panicking::panic_bounds_check
                  (uVar9,0x44,&anon_34f15a90fcba3ed6a32c120778b34e05_86_llvm_15918893398050881851);
                    /* WARNING: Does not return */
        pcVar5 = (code *)invalidInstructionException();
        (*pcVar5)();
      }
      local_b0 = uVar11;
      if (*(longlong *)(lVar3 + uVar11 * 8) != 0) {
        lVar13 = param_2[4];
        lVar12 = param_2[5];
        if (0x3f < uVar11) {
          core[505b25137b8ba7f]::panicking::panic_bounds_check
                    (uVar11,0x40,&PTR_s_src_netstats_rs_1406a3f48);
                    /* WARNING: Does not return */
          pcVar5 = (code *)invalidInstructionException();
          (*pcVar5)();
        }
LAB_14004cd69:
        local_88 = lVar13 - local_78;
        local_78 = lVar12 - local_78;
        local_98 = &local_b0;
        local_90 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_80 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_70 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_58,&DAT_1406a3f60,&local_98);
        if (CONCAT44(uStack_54,local_58) != -1) {
          local_68 = lVar12;
          local_60 = lVar13;
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          puVar7 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
          if (puVar7 == (undefined4 *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
LAB_14004d09e:
                    /* WARNING: Does not return */
            pcVar5 = (code *)invalidInstructionException();
            (*pcVar5)();
          }
          uVar11 = uVar11 + 1;
          *(undefined8 *)(puVar7 + 4) = local_48;
          *puVar7 = local_58;
          puVar7[1] = uStack_54;
          puVar7[2] = uStack_50;
          puVar7[3] = uStack_4c;
          local_d8 = 4;
          local_c8 = 1;
          local_d0 = puVar7;
          if (uVar2 <= uVar11) goto LAB_14004cff8;
          uVar8 = 0x40;
          if (0x40 < uVar11) {
            uVar8 = uVar11;
          }
          uVar9 = 0x44;
          if (0x44 < uVar11) {
            uVar9 = uVar11;
          }
          local_c0 = &anon_34f15a90fcba3ed6a32c120778b34e05_86_llvm_15918893398050881851;
          uVar6 = uVar2;
          goto LAB_14004ceed;
        }
        break;
      }
      if (uVar6 == uVar11) {
        core[505b25137b8ba7f]::panicking::panic_bounds_check
                  (uVar6,0x40,&anon_34f15a90fcba3ed6a32c120778b34e05_87_llvm_15918893398050881851);
                    /* WARNING: Does not return */
        pcVar5 = (code *)invalidInstructionException();
        (*pcVar5)();
      }
      if (*(longlong *)(lVar4 + uVar11 * 8) != 0) {
        lVar13 = param_2[4];
        lVar12 = param_2[5];
        goto LAB_14004cd69;
      }
      uVar11 = uVar11 + 1;
      local_78 = local_78 + -8;
    } while (uVar8 != uVar11);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
  while( true ) {
    if (lVar13 == local_d8) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_d8,lVar13,1,8,0x18);
      puVar7 = local_d0;
    }
    uVar11 = uVar11 + 1;
    *(undefined8 *)(puVar7 + lVar13 * 6 + 4) = local_a0;
    puVar1 = puVar7 + lVar13 * 6;
    *puVar1 = (undefined4)local_b0;
    puVar1[1] = local_b0._4_4_;
    puVar1[2] = uStack_a8;
    puVar1[3] = uStack_a4;
    local_c8 = lVar13 + 1;
    uVar6 = uVar11;
    if (uVar11 < uVar2) {
      uVar6 = uVar2;
    }
    uVar9 = 0x44;
    if (0x44 < uVar11) {
      uVar9 = uVar11;
    }
    uVar8 = 0x40;
    if (0x40 < uVar11) {
      uVar8 = uVar11;
    }
    if (uVar2 <= uVar11) break;
LAB_14004ceed:
    lVar13 = local_c8;
    lVar12 = uVar11 * -8;
LAB_14004cf00:
    if (uVar9 == uVar11) {
      uVar10 = 0x44;
LAB_14004d06d:
      core[505b25137b8ba7f]::panicking::panic_bounds_check(uVar9,uVar10,local_c0);
      goto LAB_14004d09e;
    }
    if (*(longlong *)(lVar3 + uVar11 * 8) == 0) {
      if (uVar8 == uVar11) {
        uVar10 = 0x40;
        local_c0 = &anon_34f15a90fcba3ed6a32c120778b34e05_87_llvm_15918893398050881851;
        uVar9 = uVar8;
        goto LAB_14004d06d;
      }
      if (*(longlong *)(lVar4 + uVar11 * 8) != 0) goto LAB_14004cf48;
      uVar11 = uVar11 + 1;
      lVar12 = lVar12 + -8;
      if (uVar6 == uVar11) break;
      goto LAB_14004cf00;
    }
    if (0x3f < uVar11) {
      local_b8 = uVar11;
      core[505b25137b8ba7f]::panicking::panic_bounds_check
                (uVar11,0x40,&PTR_s_src_netstats_rs_1406a3f48);
      goto LAB_14004d09e;
    }
LAB_14004cf48:
    local_88 = local_60 - lVar12;
    local_78 = local_68 - lVar12;
    local_98 = &local_b8;
    local_90 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_80 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_70 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
    local_b8 = uVar11;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_b0,&DAT_1406a3f60,&local_98);
    if (local_b0 == 0xffffffffffffffff) break;
  }
LAB_14004cff8:
  param_1[2] = local_c8;
  *param_1 = local_d8;
  param_1[1] = (longlong)local_d0;
  return param_1;
}

