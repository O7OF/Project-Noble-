// rea decompile_all
// name: <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<(host_probe[b94139f9089eb1d8]::vote::Voter,u8)>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold::<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find::check<(host_probe[b94139f9089eb1d8]::vote::Voter,u8),&mut<host_probe[b94139f9089eb1d8]::vote::Vote>::counted::{closure#4}>::{closure#0},core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(host_probe[b94139f9089eb1d8]::vote::Voter,u8)>>
// address: 0x140009040
// body: available
// range: 0x140009040-0x140009082 inclusive
// range: 0x140009090-0x1400090cb inclusive
// range: 0x1400090d0-0x1400091b6 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<(host_probe[b94139f9089eb1d8]::vote::Voter,
   u8)>> as core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold::<(),
   core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find::check<(host_probe[b94139f9089eb1d8]::vote::Voter,
   u8), &mut <host_probe[b94139f9089eb1d8]::vote::Vote>::counted::{closure#4}>::{closure#0},
   core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(host_probe[b94139f9089eb1d8]::vote::Voter,
   u8)>> */

undefined8 * __rustcall
<core[505b25137b8ba7f]::iter::adapters::copied::Copied<core[505b25137b8ba7f]::slice::iter::Iter<(host_probe[b94139f9089eb1d8]::vote::Voter,u8)>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
::try_fold::
<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find::check<(host_probe[b94139f9089eb1d8]::vote::Voter,u8),&mut<host_probe[b94139f9089eb1d8]::vote::Vote>::counted::_closure_4_>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<(host_probe[b94139f9089eb1d8]::vote::Voter,u8)>>
          (undefined8 *param_1,longlong *param_2,undefined8 *param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  ulonglong uVar7;
  char cVar8;
  undefined8 uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  longlong *plVar12;
  longlong *plVar13;
  
  plVar1 = (longlong *)param_2[1];
  uVar9 = 2;
  if ((longlong *)*param_2 != plVar1) {
    piVar2 = (int *)*param_3;
    lVar3 = param_3[1];
    plVar4 = (longlong *)param_3[2];
    plVar12 = (longlong *)*param_2;
    do {
      plVar13 = plVar12 + 3;
      *param_2 = (longlong)plVar13;
      if (*plVar12 != 1) {
        uVar9 = 0;
LAB_140009194:
        lVar3 = plVar12[2];
        param_1[1] = plVar12[1];
        param_1[2] = lVar3;
        break;
      }
      lVar5 = plVar12[1];
      if (((*piVar2 != 1) || (lVar5 != *(longlong *)(piVar2 + 2))) &&
         (cVar8 = (**(code **)(piVar2 + 0x3a))(), cVar8 == '\0')) {
        lVar6 = *(longlong *)(lVar3 + 8);
        uVar7 = *(ulonglong *)(lVar3 + 0x10);
        uVar10 = uVar7 & 0xffffffffffffff8;
        if (uVar10 != 0) {
          uVar11 = 0;
          do {
            uVar9 = 1;
            if (((((*(longlong *)(lVar6 + uVar11 * 8) == lVar5) ||
                  (*(longlong *)(lVar6 + 8 + uVar11 * 8) == lVar5)) ||
                 ((*(longlong *)(lVar6 + 0x10 + uVar11 * 8) == lVar5 ||
                  ((*(longlong *)(lVar6 + 0x18 + uVar11 * 8) == lVar5 ||
                   (*(longlong *)(lVar6 + 0x20 + uVar11 * 8) == lVar5)))))) ||
                (*(longlong *)(lVar6 + 0x28 + uVar11 * 8) == lVar5)) ||
               ((*(longlong *)(lVar6 + 0x30 + uVar11 * 8) == lVar5 ||
                (*(longlong *)(lVar6 + 0x38 + uVar11 * 8) == lVar5)))) goto LAB_140009194;
            uVar11 = uVar11 + 8;
          } while (uVar10 != uVar11);
        }
        if ((uVar7 & 7) != 0) {
          uVar11 = 0;
          do {
            if (*(longlong *)(lVar6 + uVar10 * 8 + uVar11) == lVar5) goto LAB_14000918b;
            uVar11 = uVar11 + 8;
          } while (((uint)uVar7 & 7) << 3 != uVar11);
        }
        lVar5 = *plVar4;
        if (lVar5 != 0) {
          *plVar4 = lVar5 + -1;
LAB_14000918b:
          uVar9 = 1;
          goto LAB_140009194;
        }
      }
      plVar12 = plVar13;
      uVar9 = 2;
    } while (plVar13 != plVar1);
  }
  *param_1 = uVar9;
  return param_1;
}

