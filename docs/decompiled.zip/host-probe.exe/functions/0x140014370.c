// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::net::Route>::live
// address: 0x140014370
// body: available
// range: 0x140014370-0x14001439a inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::net::Route>::live */

bool __rustcall
<host_probe[b94139f9089eb1d8]::net::Route>::live
          (undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  ulonglong uVar1;
  undefined8 local_10;
  undefined4 local_8;
  
  local_10 = param_2;
  local_8 = param_3;
  uVar1 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                    (&local_10,*param_1,*(undefined4 *)(param_1 + 1));
  return uVar1 < 0xf;
}

