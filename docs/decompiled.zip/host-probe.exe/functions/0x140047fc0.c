// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u64>>::into_boxed_slice
// address: 0x140047fc0
// body: available
// range: 0x140047fc0-0x140048028 inclusive
// range: 0x14004802e-0x14004803a inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140048024 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u64>>::into_boxed_slice */

ulonglong __rustcall <alloc[246c2e7857c81348]::vec::Vec<u64>>::into_boxed_slice(ulonglong *param_1)

{
  code *pcVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong lVar4;
  
  uVar3 = param_1[2];
  if (uVar3 < *param_1) {
    lVar4 = *param_1 << 3;
    if (uVar3 == 0) {
      uVar3 = __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],lVar4,8);
      return uVar3;
    }
    uVar2 = __rustc[9d087a5ab36ea756]::__rust_realloc(param_1[1],lVar4,8,uVar3 * 8);
    if (uVar2 == 0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(8,uVar3 * 8);
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
  }
  else {
    uVar2 = param_1[1];
  }
  return uVar2;
}

