// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>::retain::<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#4}>
// address: 0x140001b60
// body: available
// range: 0x140001b60-0x140001c58 inclusive
// range: 0x140001c60-0x140001d56 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140001d38 to 0x140015ce0 <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>::truncate (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>::retain::<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#4}>
    */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>
::retain::<<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_4_>
          (ulonglong *param_1,longlong param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  code *pcVar5;
  ulonglong uVar6;
  void *_Src;
  ulonglong uVar7;
  ulonglong uVar8;
  longlong lVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  void *_Src_00;
  undefined1 local_e0 [160];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar7 = 0;
    uVar8 = 0;
LAB_140001d09:
    if (uVar8 != uVar7) {
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Delivery>>
      ::truncate(param_1,uVar7);
      return;
    }
  }
  else {
    lVar9 = param_1[1] + param_1[2] * 0xa0 + 0x90;
    uVar7 = 0;
    do {
      uVar8 = 0;
      if (*param_1 <= param_1[2] + uVar7) {
        uVar8 = *param_1;
      }
      if (*(longlong *)(lVar9 + uVar8 * -0xa0) == param_2) {
        uVar6 = uVar7 + 1;
        uVar8 = uVar6;
        if (uVar6 < uVar1) {
          uVar2 = param_1[2];
          uVar11 = uVar1;
          if (uVar1 < uVar7) {
            uVar11 = uVar7;
          }
          uVar3 = *param_1;
          uVar4 = param_1[1];
          do {
            lVar9 = (uVar2 + uVar6) * 0xa0 + uVar4;
            uVar8 = uVar6;
            while( true ) {
              uVar10 = uVar3;
              if (uVar2 + uVar8 < uVar3) {
                uVar10 = 0;
              }
              _Src = (void *)(lVar9 + uVar10 * -0xa0);
              if (*(longlong *)((longlong)_Src + 0x90) != param_2) break;
              uVar8 = uVar8 + 1;
              lVar9 = lVar9 + 0xa0;
              if (uVar1 <= uVar8) {
                uVar8 = uVar6 + 1;
                if (uVar6 + 1 < uVar1) {
                  uVar8 = uVar1;
                }
                goto LAB_140001d09;
              }
            }
            if (uVar7 == uVar11) {
              core[505b25137b8ba7f]::panicking::panic
                        (&anon_d5c34e88a06ee720b116585eb143da4b_235_llvm_14435704873730135342,0x20,
                         &anon_d5c34e88a06ee720b116585eb143da4b_236_llvm_14435704873730135342);
                    /* WARNING: Does not return */
              pcVar5 = (code *)invalidInstructionException();
              (*pcVar5)();
            }
            uVar6 = 0;
            if (uVar3 <= uVar7 + uVar2) {
              uVar6 = uVar3;
            }
            _Src_00 = (void *)(((uVar7 + uVar2) - uVar6) * 0xa0 + uVar4);
            memcpy(local_e0,_Src_00,0xa0);
            memmove(_Src_00,_Src,0xa0);
            memcpy(_Src,local_e0,0xa0);
            uVar6 = uVar8 + 1;
            uVar7 = uVar7 + 1;
          } while (uVar6 < uVar1);
          uVar8 = uVar8 + 1;
        }
        goto LAB_140001d09;
      }
      uVar7 = uVar7 + 1;
      lVar9 = lVar9 + 0xa0;
    } while (uVar1 != uVar7);
  }
  return;
}

