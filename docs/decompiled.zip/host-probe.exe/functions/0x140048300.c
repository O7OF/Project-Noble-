// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>,host_probe[b94139f9089eb1d8]::announce::hand_over<host_probe[b94139f9089eb1d8]::announce::announce::{closure#26}::{closure#1}>::{closure#2}>>>::from_iter
// address: 0x140048300
// body: available
// range: 0x140048300-0x1400483fc inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,
   reach_directory[4b72b9694f6c3c08]::protocol::Lease)>,
   host_probe[b94139f9089eb1d8]::announce::hand_over<host_probe[b94139f9089eb1d8]::announce::announce::{closure#26}::{closure#1}>::{closure#2}>>>::from_iter
    */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<(alloc[246c2e7857c81348]::string::String,reach_directory[4b72b9694f6c3c08]::protocol::Lease)>,host_probe[b94139f9089eb1d8]::announce::hand_over<host_probe[b94139f9089eb1d8]::announce::announce::{closure#26}::{closure#1}>::{closure#2}>>>
::from_iter(ulonglong *param_1,longlong param_2,longlong param_3)

{
  code *pcVar1;
  ulonglong uVar2;
  undefined4 *puVar3;
  ulonglong local_60;
  undefined4 *local_58;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 local_38;
  
  local_60 = (ulonglong)(param_3 - param_2) / 0x70;
  if (param_3 == param_2) {
    local_60 = 0;
    local_58 = (undefined4 *)&DAT_00000008;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    local_58 = (undefined4 *)__rustc[9d087a5ab36ea756]::__rust_alloc(local_60 * 0x18,8);
    if (local_58 == (undefined4 *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(8,local_60 * 0x18);
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    param_2 = param_2 + 0x18;
    uVar2 = 0;
    puVar3 = local_58;
    do {
      <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                (&local_48,param_2);
      *(undefined8 *)(puVar3 + 4) = local_38;
      *puVar3 = local_48;
      puVar3[1] = uStack_44;
      puVar3[2] = uStack_40;
      puVar3[3] = uStack_3c;
      uVar2 = uVar2 + 1;
      param_2 = param_2 + 0x70;
      puVar3 = puVar3 + 6;
    } while (local_60 != uVar2);
  }
  param_1[2] = local_60;
  *param_1 = local_60;
  param_1[1] = (ulonglong)local_58;
  return param_1;
}

