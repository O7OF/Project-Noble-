// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Values<u64,host_probe[b94139f9089eb1d8]::net::Route>>>>::from_iter
// address: 0x14004f2b0
// body: available
// range: 0x14004f2b0-0x14004f458 inclusive
// range: 0x14004f460-0x14004f5a4 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,
   core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Values<u64,
   host_probe[b94139f9089eb1d8]::net::Route>>>>::from_iter */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Values<u64,host_probe[b94139f9089eb1d8]::net::Route>>>>
::from_iter(ulonglong *param_1,longlong *param_2)

{
  undefined4 *puVar1;
  undefined8 *puVar2;
  undefined1 auVar3 [16];
  int iVar4;
  ulonglong uVar5;
  code *pcVar6;
  uint uVar7;
  undefined8 *puVar8;
  ushort uVar9;
  uint uVar10;
  longlong lVar11;
  longlong lVar12;
  undefined1 (*pauVar13) [16];
  undefined8 uVar14;
  uint uVar15;
  ulonglong uVar16;
  undefined8 uVar17;
  longlong lVar18;
  ulonglong local_f0;
  undefined8 *local_e8;
  ulonglong local_e0;
  undefined8 local_d8;
  longlong *local_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 local_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 local_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  
  uVar5 = param_2[4];
  if (uVar5 != 0) {
    uVar9 = *(ushort *)(param_2 + 3);
    lVar18 = *param_2;
    if (uVar9 == 0) {
      pauVar13 = (undefined1 (*) [16])param_2[1];
      do {
        auVar3 = *pauVar13;
        lVar18 = lVar18 + -0x500;
        pauVar13 = pauVar13 + 1;
        uVar9 = ((ushort)(SUB161(auVar3 >> 7,0) & 1) | (ushort)(SUB161(auVar3 >> 0xf,0) & 1) << 1 |
                 (ushort)(SUB161(auVar3 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar3 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar3 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar3 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar3 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar3 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar3 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar3 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar3 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar3 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar3 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar3 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar3 >> 0x77,0) & 1) << 0xe |
                (ushort)(byte)(auVar3[0xf] >> 7) << 0xf) ^ 0xffff;
      } while (uVar9 == 0);
      param_2[1] = (longlong)pauVar13;
      *param_2 = lVar18;
    }
    uVar10 = (uint)uVar9;
    uVar15 = uVar10 - 1 & uVar10;
    *(short *)(param_2 + 3) = (short)uVar15;
    lVar12 = uVar5 - 1;
    param_2[4] = lVar12;
    uVar7 = 0;
    for (; (uVar10 & 1) == 0; uVar10 = uVar10 >> 1 | 0x80000000) {
      uVar7 = uVar7 + 1;
    }
    lVar11 = (ulonglong)uVar7 * -0x50;
    uVar14 = *(undefined8 *)(lVar18 + -0x48 + lVar11);
    iVar4 = *(int *)(lVar18 + -0x40 + lVar11);
    puVar8 = (undefined8 *)(lVar18 + -0x10 + lVar11);
    uStack_94 = puVar8[1];
    uStack_98 = (undefined4)((ulonglong)*puVar8 >> 0x20);
    puVar8 = (undefined8 *)(lVar18 + -0x1c + lVar11);
    uStack_a8 = *puVar8;
    uVar17 = puVar8[1];
    uStack_a0 = (undefined4)uVar17;
    local_9c = (undefined4)((ulonglong)uVar17 >> 0x20);
    puVar8 = (undefined8 *)(lVar18 + -0x2c + lVar11);
    local_b8 = *puVar8;
    uStack_b0 = puVar8[1];
    puVar8 = (undefined8 *)(lVar18 + -0x3c + lVar11);
    local_c8 = *puVar8;
    uStack_c0 = puVar8[1];
    if (iVar4 != -1) {
      uVar16 = 4;
      if (4 < uVar5) {
        uVar16 = uVar5;
      }
      lVar11 = uVar16 * 0x48;
      if (uVar5 < 0x1c71c71c71c71c8) {
        if (lVar11 == 0) {
          puVar8 = (undefined8 *)&DAT_00000008;
          uVar16 = 0;
        }
        else {
          local_d8 = uVar14;
          local_d0 = param_2;
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar17 = 8;
          puVar8 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(lVar11,8);
          param_2 = local_d0;
          uVar14 = local_d8;
          if (puVar8 == (undefined8 *)0x0) goto LAB_14004f39d;
        }
        *puVar8 = uVar14;
        *(int *)(puVar8 + 1) = iVar4;
        *(undefined8 *)((longlong)puVar8 + 0xc) = local_c8;
        *(undefined8 *)((longlong)puVar8 + 0x14) = uStack_c0;
        *(undefined4 *)((longlong)puVar8 + 0x1c) = (undefined4)local_b8;
        *(undefined4 *)(puVar8 + 4) = local_b8._4_4_;
        *(undefined4 *)((longlong)puVar8 + 0x24) = (undefined4)uStack_b0;
        *(undefined4 *)(puVar8 + 5) = uStack_b0._4_4_;
        *(undefined4 *)((longlong)puVar8 + 0x2c) = (undefined4)uStack_a8;
        *(undefined4 *)(puVar8 + 6) = uStack_a8._4_4_;
        *(undefined4 *)((longlong)puVar8 + 0x34) = uStack_a0;
        *(undefined4 *)(puVar8 + 7) = local_9c;
        puVar8[7] = CONCAT44(uStack_98,local_9c);
        puVar8[8] = uStack_94;
        local_e0 = 1;
        local_f0 = uVar16;
        local_e8 = puVar8;
        if (lVar12 != 0) {
          pauVar13 = (undefined1 (*) [16])param_2[1];
          do {
            uVar5 = local_e0;
            uVar9 = (ushort)uVar15;
            while (uVar9 == 0) {
              auVar3 = *pauVar13;
              lVar18 = lVar18 + -0x500;
              pauVar13 = pauVar13 + 1;
              uVar9 = ((ushort)(SUB161(auVar3 >> 7,0) & 1) |
                       (ushort)(SUB161(auVar3 >> 0xf,0) & 1) << 1 |
                       (ushort)(SUB161(auVar3 >> 0x17,0) & 1) << 2 |
                       (ushort)(SUB161(auVar3 >> 0x1f,0) & 1) << 3 |
                       (ushort)(SUB161(auVar3 >> 0x27,0) & 1) << 4 |
                       (ushort)(SUB161(auVar3 >> 0x2f,0) & 1) << 5 |
                       (ushort)(SUB161(auVar3 >> 0x37,0) & 1) << 6 |
                       (ushort)(SUB161(auVar3 >> 0x3f,0) & 1) << 7 |
                       (ushort)(SUB161(auVar3 >> 0x47,0) & 1) << 8 |
                       (ushort)(SUB161(auVar3 >> 0x4f,0) & 1) << 9 |
                       (ushort)(SUB161(auVar3 >> 0x57,0) & 1) << 10 |
                       (ushort)(SUB161(auVar3 >> 0x5f,0) & 1) << 0xb |
                       (ushort)(SUB161(auVar3 >> 0x67,0) & 1) << 0xc |
                       (ushort)(SUB161(auVar3 >> 0x6f,0) & 1) << 0xd |
                       (ushort)(SUB161(auVar3 >> 0x77,0) & 1) << 0xe |
                      (ushort)(byte)(auVar3[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar15 = (uint)uVar9;
            }
            uVar7 = 0;
            for (uVar10 = uVar15; (uVar10 & 1) == 0; uVar10 = uVar10 >> 1 | 0x80000000) {
              uVar7 = uVar7 + 1;
            }
            lVar11 = (ulonglong)uVar7 * -0x50;
            uVar14 = *(undefined8 *)(lVar18 + -0x48 + lVar11);
            iVar4 = *(int *)(lVar18 + -0x40 + lVar11);
            puVar2 = (undefined8 *)(lVar18 + -0x10 + lVar11);
            uStack_54 = puVar2[1];
            uStack_58 = (undefined4)((ulonglong)*puVar2 >> 0x20);
            puVar2 = (undefined8 *)(lVar18 + -0x1c + lVar11);
            uStack_68 = *puVar2;
            uVar17 = puVar2[1];
            uStack_60 = (undefined4)uVar17;
            local_5c = (undefined4)((ulonglong)uVar17 >> 0x20);
            puVar2 = (undefined8 *)(lVar18 + -0x2c + lVar11);
            local_78 = *puVar2;
            uStack_70 = puVar2[1];
            puVar2 = (undefined8 *)(lVar18 + -0x3c + lVar11);
            local_88 = *puVar2;
            uStack_80 = puVar2[1];
            if (iVar4 == -1) break;
            if (local_e0 == local_f0) {
              <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
              <alloc[246c2e7857c81348]::alloc::Global>(&local_f0,local_e0,lVar12,8,0x48);
              puVar8 = local_e8;
            }
            uVar15 = uVar15 - 1 & uVar15;
            lVar12 = lVar12 + -1;
            puVar8[uVar5 * 9] = uVar14;
            *(int *)(puVar8 + uVar5 * 9 + 1) = iVar4;
            puVar2 = (undefined8 *)((longlong)puVar8 + uVar5 * 0x48 + 0xc);
            *puVar2 = local_88;
            puVar2[1] = uStack_80;
            puVar1 = (undefined4 *)((longlong)puVar8 + uVar5 * 0x48 + 0x1c);
            *puVar1 = (undefined4)local_78;
            puVar1[1] = local_78._4_4_;
            puVar1[2] = (undefined4)uStack_70;
            puVar1[3] = uStack_70._4_4_;
            puVar1 = (undefined4 *)((longlong)puVar8 + uVar5 * 0x48 + 0x2c);
            *puVar1 = (undefined4)uStack_68;
            puVar1[1] = uStack_68._4_4_;
            puVar1[2] = uStack_60;
            puVar1[3] = local_5c;
            puVar8[uVar5 * 9 + 7] = CONCAT44(uStack_58,local_5c);
            (puVar8 + uVar5 * 9 + 7)[1] = uStack_54;
            local_e0 = uVar5 + 1;
          } while (lVar12 != 0);
        }
        param_1[2] = local_e0;
        *param_1 = local_f0;
        param_1[1] = (ulonglong)local_e8;
        return param_1;
      }
      uVar17 = 0;
LAB_14004f39d:
      alloc[246c2e7857c81348]::raw_vec::handle_error(uVar17,lVar11);
                    /* WARNING: Does not return */
      pcVar6 = (code *)invalidInstructionException();
      (*pcVar6)();
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

