// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<f32>,host_probe[b94139f9089eb1d8]::host::looks::message::{closure#1}>>
// address: 0x140044140
// body: available
// range: 0x140044140-0x1400443ab inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<f32>,
   host_probe[b94139f9089eb1d8]::host::looks::message::{closure#1}>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::
<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<f32>,host_probe[b94139f9089eb1d8]::host::looks::message::_closure_1_>>
          (longlong *param_1,ulonglong param_2,ulonglong param_3)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined1 auVar3 [16];
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined1 auVar13 [16];
  
  uVar4 = param_3 - param_2 >> 2;
  lVar7 = param_1[2];
  auVar3 = __rdata;
  if ((ulonglong)(*param_1 - lVar7) < uVar4) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar7,uVar4,1,1);
    lVar7 = param_1[2];
    auVar3 = __rdata;
  }
  __rdata = auVar3;
  if (param_2 != param_3) {
    lVar2 = param_1[1];
    if ((param_3 - param_2 < 0x10) ||
       (uVar1 = lVar2 + lVar7, uVar1 < param_3 && param_2 < uVar4 + uVar1)) {
      uVar6 = 0;
    }
    else {
      uVar6 = uVar4 & 0xfffffffffffffffc;
      lVar7 = lVar7 + uVar6;
      uVar5 = 0;
      do {
        auVar13 = maxps(ZEXT816(0),*(undefined1 (*) [16])(param_2 + uVar5 * 4));
        auVar13 = minps(auVar3,auVar13);
        fVar8 = (float)roundf(auVar13._12_4_ * 255.0);
        fVar9 = (float)roundf(auVar13._8_4_ * 255.0);
        fVar10 = (float)roundf(auVar13._4_4_ * 255.0);
        fVar11 = (float)roundf(auVar13._0_4_ * 255.0);
        fVar12 = 0.0;
        if (0.0 <= fVar11) {
          fVar12 = fVar11;
        }
        fVar11 = 255.0;
        if (fVar12 <= 255.0) {
          fVar11 = fVar12;
        }
        fVar12 = 0.0;
        if (0.0 <= fVar10) {
          fVar12 = fVar10;
        }
        fVar10 = 255.0;
        if (fVar12 <= 255.0) {
          fVar10 = fVar12;
        }
        fVar12 = 0.0;
        if (0.0 <= fVar9) {
          fVar12 = fVar9;
        }
        fVar9 = 255.0;
        if (fVar12 <= 255.0) {
          fVar9 = fVar12;
        }
        fVar12 = 0.0;
        if (0.0 <= fVar8) {
          fVar12 = fVar8;
        }
        fVar8 = 255.0;
        if (fVar12 <= 255.0) {
          fVar8 = fVar12;
        }
        *(uint *)(uVar1 + uVar5) =
             (int)fVar8 << 0x18 |
             ((int)fVar9 & 0xffU) << 0x10 | ((int)fVar10 & 0xffU) << 8 | (int)fVar11 & 0xffU;
        uVar5 = uVar5 + 4;
      } while (uVar6 != uVar5);
      if (uVar4 == uVar6) goto LAB_14004422a;
    }
    do {
      fVar12 = *(float *)(param_2 + uVar6 * 4);
      fVar8 = 0.0;
      if (0.0 <= fVar12) {
        fVar8 = fVar12;
      }
      fVar12 = 1.0;
      if (fVar8 <= 1.0) {
        fVar12 = fVar8;
      }
      fVar8 = (float)roundf(fVar12 * 255.0);
      fVar12 = 0.0;
      if (0.0 <= fVar8) {
        fVar12 = fVar8;
      }
      fVar8 = 255.0;
      if (fVar12 <= 255.0) {
        fVar8 = fVar12;
      }
      *(char *)(lVar2 + lVar7) = (char)(int)fVar8;
      lVar7 = lVar7 + 1;
      uVar6 = uVar6 + 1;
    } while (uVar4 != uVar6);
  }
LAB_14004422a:
  param_1[2] = lVar7;
  return;
}

