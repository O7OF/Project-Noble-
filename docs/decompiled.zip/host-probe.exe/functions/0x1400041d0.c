// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::host::Publisher>
// address: 0x1400041d0
// body: available
// range: 0x1400041d0-0x1400041ee inclusive
// range: 0x1400041f0-0x14000420f inclusive
// range: 0x140004212-0x140004273 inclusive
// range: 0x140004280-0x1400042d5 inclusive
// range: 0x1400042d8-0x14000431e inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14000420b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000422b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004249 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400042a2 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400042ba to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400042d1 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400042ef to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004310 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::host::Publisher> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::host::Publisher>
          (longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 *puVar4;
  
  lVar3 = param_1[2];
  if (lVar3 != 0) {
    puVar4 = (undefined8 *)(param_1[1] + 8);
    do {
      if (puVar4[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar4,puVar4[-1],1);
        return;
      }
      puVar4 = puVar4 + 3;
      lVar3 = lVar3 + -1;
    } while (lVar3 != 0);
  }
  if (*param_1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],*param_1 * 0x18,8);
    return;
  }
  lVar3 = param_1[9];
  if ((lVar3 != -1) && (lVar3 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[10],lVar3,1);
    return;
  }
  plVar1 = (longlong *)param_1[0xe];
  LOCK();
  *plVar1 = *plVar1 + -1;
  UNLOCK();
  if (*plVar1 == 0) {
    <alloc[246c2e7857c81348]::sync::Arc<reach_directory[4b72b9694f6c3c08]::identity::ServerKey>>::
    drop_slow(param_1 + 0xe);
  }
  lVar3 = param_1[5];
  if (lVar3 != 0) {
    puVar4 = (undefined8 *)(param_1[4] + 0x38);
    do {
      lVar2 = puVar4[-7];
      if (lVar2 != -1) {
        if (lVar2 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar4[-6],lVar2,1);
          return;
        }
        if (puVar4[-4] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar4[-3],puVar4[-4],1);
          return;
        }
        if (puVar4[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar4,puVar4[-1],1);
          return;
        }
      }
      puVar4 = puVar4 + 0xb;
      lVar3 = lVar3 + -1;
    } while (lVar3 != 0);
  }
  if (param_1[3] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[4],param_1[3] * 0x58,8);
    return;
  }
  if (param_1[6] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[7],param_1[6],1);
    return;
  }
  return;
}

