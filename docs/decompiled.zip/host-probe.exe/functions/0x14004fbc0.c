// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant),core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill::{closure#1}>>>::from_iter
// address: 0x14004fbc0
// body: available
// range: 0x14004fbc0-0x14004fd0b inclusive
// range: 0x14004fd10-0x14004fdbb inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,
   std[3bf9d48a0c3997f0]::time::Instant)> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,
   std[3bf9d48a0c3997f0]::time::Instant),
   core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,
   std[3bf9d48a0c3997f0]::time::Instant)>,
   <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill::{closure#1}>>>::from_iter
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<&(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant),core[505b25137b8ba7f]::iter::adapters::filter::Filter<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<(reach_directory[4b72b9694f6c3c08]::chat::MatchMsg,std[3bf9d48a0c3997f0]::time::Instant)>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::backfill::{closure#1}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  code *pcVar4;
  ulonglong uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  longlong local_60;
  longlong *plStack_58;
  longlong local_50;
  longlong *local_48;
  
  lVar2 = param_2[1];
  lVar3 = param_2[4];
  lVar9 = *param_2 + 0x80;
LAB_14004fbf0:
  lVar10 = lVar9;
  lVar1 = lVar10 + -0x80;
  if (lVar1 == lVar2) {
    lVar9 = param_2[3];
    lVar11 = param_2[2] + 0x80;
    do {
      lVar7 = lVar11;
      if (lVar7 + -0x80 == lVar9) {
        *param_1 = 0;
        param_1[1] = 8;
        param_1[2] = 0;
        return param_1;
      }
      param_2[2] = lVar7;
      uVar5 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                        (lVar3,*(undefined8 *)(lVar7 + -0x10),*(undefined4 *)(lVar7 + -8));
      lVar11 = lVar7 + 0x80;
    } while ((lVar7 == 0x80) || (lVar10 = lVar1, 0x77 < uVar5));
  }
  else {
    *param_2 = lVar10;
    uVar5 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                      (lVar3,*(undefined8 *)(lVar10 + -0x10),*(undefined4 *)(lVar10 + -8));
    lVar9 = lVar10 + 0x80;
    if ((lVar1 == 0) || (lVar7 = lVar10, 0x77 < uVar5)) goto LAB_14004fbf0;
  }
  local_48 = param_1;
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  plVar6 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x20,8);
  if (plVar6 == (longlong *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x20);
                    /* WARNING: Does not return */
    pcVar4 = (code *)invalidInstructionException();
    (*pcVar4)();
  }
  *plVar6 = lVar7 + -0x80;
  local_60 = 4;
  local_50 = 1;
  lVar9 = param_2[2];
  lVar1 = param_2[3];
  lVar7 = 1;
  plStack_58 = plVar6;
LAB_14004fce0:
  lVar11 = lVar10;
  if (lVar11 != lVar2) goto code_r0x00014004fce5;
  do {
    lVar8 = lVar9;
    if (lVar8 == lVar1) {
      local_48[2] = local_50;
      *local_48 = local_60;
      local_48[1] = (longlong)plStack_58;
      return local_48;
    }
    uVar5 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                      (lVar3,*(undefined8 *)(lVar8 + 0x70),*(undefined4 *)(lVar8 + 0x78));
    lVar9 = lVar8 + 0x80;
    lVar10 = lVar11;
  } while (0x77 < uVar5);
  goto joined_r0x00014004fd08;
code_r0x00014004fce5:
  uVar5 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                    (lVar3,*(undefined8 *)(lVar11 + 0x70),*(undefined4 *)(lVar11 + 0x78));
  lVar10 = lVar11 + 0x80;
  lVar8 = lVar11;
  if (uVar5 < 0x78) {
joined_r0x00014004fd08:
    if (lVar7 == local_60) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(&local_60,lVar7,1,8,8);
      plVar6 = plStack_58;
    }
    plVar6[lVar7] = lVar8;
    lVar7 = lVar7 + 1;
    local_50 = lVar7;
  }
  goto LAB_14004fce0;
}

