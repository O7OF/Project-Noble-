// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::slice::iter::Iter<alloc[246c2e7857c81348]::string::String>>,host_probe[b94139f9089eb1d8]::announce::prepare::{closure#3}>,host_probe[b94139f9089eb1d8]::announce::prepare::{closure#4}>>>::from_iter
// address: 0x14004a5c0
// body: available
// range: 0x14004a5c0-0x14004a609 inclusive
// range: 0x14004a610-0x14004a6e2 inclusive
// range: 0x14004a6f0-0x14004a823 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::slice::iter::Iter<alloc[246c2e7857c81348]::string::String>>,
   host_probe[b94139f9089eb1d8]::announce::prepare::{closure#3}>,
   host_probe[b94139f9089eb1d8]::announce::prepare::{closure#4}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::iter::adapters::enumerate::Enumerate<core[505b25137b8ba7f]::slice::iter::Iter<alloc[246c2e7857c81348]::string::String>>,host_probe[b94139f9089eb1d8]::announce::prepare::{closure#3}>,host_probe[b94139f9089eb1d8]::announce::prepare::{closure#4}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  code *pcVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong *local_88;
  longlong local_78;
  longlong *local_70;
  longlong local_68;
  longlong local_60;
  longlong local_58;
  longlong local_50;
  longlong local_48;
  
  lVar1 = param_2[1];
  if (*param_2 != lVar1) {
    uVar5 = param_2[2];
    lVar2 = param_2[3];
    lVar6 = uVar5 * 0x18;
    lVar7 = *param_2;
    do {
      lVar8 = lVar7 + 0x18;
      lVar6 = lVar6 + 0x18;
      uVar5 = uVar5 + 1;
      if ((((*(longlong *)(lVar7 + 0x10) == 10) &&
           ((short)(*(longlong **)(lVar7 + 8))[1] == 0x6563 &&
            **(longlong **)(lVar7 + 8) == 0x6e756f6e6e612d2d)) &&
          (uVar5 < *(ulonglong *)(lVar2 + 0x10))) &&
         (<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::clone
                    (&local_58,*(longlong *)(lVar2 + 8) + lVar6), lVar4 = local_48, lVar9 = local_50
         , lVar7 = local_58, local_58 != -1)) {
        __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
        local_88 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
        if (local_88 == (longlong *)0x0) {
          alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
          pcVar3 = (code *)invalidInstructionException();
          (*pcVar3)();
        }
        *local_88 = lVar7;
        local_88[1] = lVar9;
        local_88[2] = lVar4;
        local_78 = 4;
        local_68 = 1;
        local_70 = local_88;
        lVar6 = local_68;
        while (local_68 = lVar6, lVar8 != lVar1) {
          lVar7 = uVar5 * 0x18;
          lVar9 = lVar8;
          while( true ) {
            lVar8 = lVar9 + 0x18;
            lVar7 = lVar7 + 0x18;
            uVar5 = uVar5 + 1;
            if (((*(longlong *)(lVar9 + 0x10) == 10) &&
                ((short)(*(longlong **)(lVar9 + 8))[1] == 0x6563 &&
                 **(longlong **)(lVar9 + 8) == 0x6e756f6e6e612d2d)) &&
               ((uVar5 < *(ulonglong *)(lVar2 + 0x10) &&
                (<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::clone::Clone>::
                 clone(&local_58,*(longlong *)(lVar2 + 8) + lVar7), lVar4 = local_48,
                lVar9 = local_58, local_58 != -1)))) break;
            lVar9 = lVar8;
            if (lVar8 == lVar1) goto LAB_14004a7c7;
          }
          local_60 = local_50;
          if (lVar6 == local_78) {
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
            <alloc[246c2e7857c81348]::alloc::Global>(&local_78,lVar6,1,8,0x18);
            local_88 = local_70;
          }
          local_88[lVar6 * 3] = lVar9;
          local_88[lVar6 * 3 + 1] = local_60;
          local_88[lVar6 * 3 + 2] = lVar4;
          lVar6 = lVar6 + 1;
        }
LAB_14004a7c7:
        param_1[2] = local_68;
        *param_1 = local_78;
        param_1[1] = (longlong)local_70;
        return param_1;
      }
      lVar7 = lVar8;
    } while (lVar8 != lVar1);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

