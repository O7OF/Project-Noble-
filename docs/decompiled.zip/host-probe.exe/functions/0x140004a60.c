// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::net::Transport>
// address: 0x140004a60
// body: available
// range: 0x140004a60-0x140004b78 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140004aa8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004aca to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004b03 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004b36 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004b6e to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::net::Transport> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::net::Transport>
          (longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  closesocket(*(SOCKET *)(param_1 + 0x150));
  lVar1 = *(longlong *)(param_1 + 200);
  if ((lVar1 != 0) && (lVar2 = lVar1 * 0x51 + 0x61, lVar2 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(longlong *)(param_1 + 0xc0) + lVar1 * -0x50 + -0x50,lVar2,0x10);
    return;
  }
  if (*(longlong *)(param_1 + 0xf8) != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(undefined8 *)(param_1 + 0x100),*(longlong *)(param_1 + 0xf8) << 5,4);
    return;
  }
  lVar1 = *(longlong *)(param_1 + 0x128);
  if ((lVar1 != 0) && (lVar2 = lVar1 * 0x51 + 0x61, lVar2 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(longlong *)(param_1 + 0x120) + lVar1 * -0x50 + -0x50,lVar2,0x10);
    return;
  }
  lVar1 = *(longlong *)(param_1 + 0x40);
  if ((lVar1 != 0) && (lVar2 = lVar1 * 0x51 + 0x61, lVar2 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(longlong *)(param_1 + 0x38) + lVar1 * -0x50 + -0x50,lVar2,0x10);
    return;
  }
  lVar1 = *(longlong *)(param_1 + 0x70);
  if ((lVar1 != 0) && (lVar2 = lVar1 * 0x61 + 0x71, lVar2 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc
              (*(longlong *)(param_1 + 0x68) + lVar1 * -0x60 + -0x60,lVar2,0x10);
    return;
  }
  return;
}

