// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>,host_probe[b94139f9089eb1d8]::server_admin::content::on_disk::{closure#1}>>>::from_iter
// address: 0x14004a880
// body: available
// range: 0x14004a880-0x14004a928 inclusive
// range: 0x14004a930-0x14004a9fd inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>,
   host_probe[b94139f9089eb1d8]::server_admin::content::on_disk::{closure#1}>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>,host_probe[b94139f9089eb1d8]::server_admin::content::on_disk::{closure#1}>>>
::from_iter(longlong *param_1,void *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  longlong local_c98;
  longlong *plStack_c90;
  longlong local_c88;
  longlong local_c80;
  longlong lStack_c78;
  longlong local_c70;
  undefined4 local_c68;
  undefined4 uStack_c64;
  undefined4 uStack_c60;
  undefined4 uStack_c5c;
  undefined8 local_c58;
  undefined1 local_c50 [3088];
  
  <core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>,host_probe[b94139f9089eb1d8]::server_admin::content::on_disk::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::next(&local_c80);
  if (local_c80 == -1) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
    core[505b25137b8ba7f]::ptr::drop_glue::
    <core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>>
              (param_2);
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    plVar3 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x60,8);
    if (plVar3 == (longlong *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x60);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    plVar3[2] = local_c70;
    *plVar3 = local_c80;
    plVar3[1] = lStack_c78;
    local_c98 = 4;
    local_c88 = 1;
    plStack_c90 = plVar3;
    memcpy(local_c50,param_2,0xc10);
    lVar5 = 1;
    lVar4 = 0;
    while( true ) {
      <core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>,host_probe[b94139f9089eb1d8]::server_admin::content::on_disk::{closure#1}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
      ::next(&local_c68,local_c50);
      if (CONCAT44(uStack_c64,local_c68) == -1) break;
      if (lVar5 == local_c98) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_c98,lVar5,1,8,0x18);
        plVar3 = plStack_c90;
      }
      *(undefined8 *)(lVar4 + 0x28 + (longlong)plVar3) = local_c58;
      puVar1 = (undefined4 *)(lVar4 + 0x18 + (longlong)plVar3);
      *puVar1 = local_c68;
      puVar1[1] = uStack_c64;
      puVar1[2] = uStack_c60;
      puVar1[3] = uStack_c5c;
      lVar5 = lVar5 + 1;
      lVar4 = lVar4 + 0x18;
      local_c88 = lVar5;
    }
    core[505b25137b8ba7f]::ptr::drop_glue::
    <core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::result::IntoIter<std[3bf9d48a0c3997f0]::fs::ReadDir>>>>
              (local_c50);
    param_1[2] = local_c88;
    *param_1 = local_c98;
    param_1[1] = (longlong)plStack_c90;
  }
  return param_1;
}

