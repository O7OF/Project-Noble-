// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<usize>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<usize,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,<str>::parse<usize>>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,core[505b25137b8ba7f]::num::error::ParseIntError>>>>::from_iter
// address: 0x140049900
// body: available
// range: 0x140049900-0x1400499b5 inclusive
// range: 0x1400499c0-0x140049a61 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<usize> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<usize,
   core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,
   <str>::parse<usize>>,
   core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,
   core[505b25137b8ba7f]::num::error::ParseIntError>>>>::from_iter */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<usize>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<usize,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,<str>::parse<usize>>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,core[505b25137b8ba7f]::num::error::ParseIntError>>>>
::from_iter(longlong *param_1,undefined8 *param_2)

{
  code *pcVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong *plVar4;
  undefined1 *puVar5;
  undefined1 local_a1;
  longlong local_a0;
  longlong *plStack_98;
  longlong local_90;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  
  puVar5 = &local_a1;
  uVar3 = <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,<str>::parse<usize>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
          ::try_fold::
          <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,<str>::parse<usize>>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,core[505b25137b8ba7f]::num::error::ParseIntError>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<usize,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>>>
                    (param_2 + 1,puVar5,*param_2);
  if ((uVar3 & 1) == 0) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
  }
  else {
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    plVar4 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x20,8);
    if (plVar4 == (longlong *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x20);
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    *plVar4 = (longlong)puVar5;
    local_a0 = 4;
    local_90 = 1;
    local_48 = param_2[8];
    uStack_40 = param_2[9];
    local_88 = *(undefined4 *)param_2;
    uStack_84 = *(undefined4 *)((longlong)param_2 + 4);
    uStack_80 = *(undefined4 *)(param_2 + 1);
    uStack_7c = *(undefined4 *)((longlong)param_2 + 0xc);
    local_78 = param_2[2];
    uStack_70 = param_2[3];
    local_68 = param_2[4];
    uStack_60 = param_2[5];
    local_58 = param_2[6];
    uStack_50 = param_2[7];
    plStack_98 = plVar4;
    while( true ) {
      lVar2 = local_90;
      puVar5 = &local_a1;
      uVar3 = <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,<str>::parse<usize>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
              ::try_fold::
              <(),<core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::str::iter::Split<char>,<str>::parse<usize>>,core[505b25137b8ba7f]::result::Result<core[505b25137b8ba7f]::convert::Infallible,core[505b25137b8ba7f]::num::error::ParseIntError>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::try_fold<(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::try_for_each::call<usize,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>::Break>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>>>
                        (&uStack_80,&local_a1,CONCAT44(uStack_84,local_88));
      if ((uVar3 & 1) == 0) break;
      if (lVar2 == local_a0) {
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>(&local_a0,lVar2,1,8,8);
        plVar4 = plStack_98;
      }
      plVar4[lVar2] = (longlong)puVar5;
      local_90 = lVar2 + 1;
    }
    param_1[2] = local_90;
    *param_1 = local_a0;
    param_1[1] = (longlong)plStack_98;
  }
  return param_1;
}

