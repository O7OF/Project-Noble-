// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::add_master
// address: 0x140021840
// body: available
// range: 0x140021840-0x1400218c5 inclusive
// range: 0x1400218d0-0x140021919 inclusive
// range: 0x140021920-0x140021a4a inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140021a2d to 0x140610d80 <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::add_master */

void __rustcall host_probe[b94139f9089eb1d8]::net::add_master(char *param_1)

{
  undefined4 *puVar1;
  undefined8 *puVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  longlong lVar9;
  undefined *puVar10;
  char cVar11;
  longlong lVar12;
  longlong lVar13;
  bool bVar14;
  undefined1 *local_48;
  byte local_40;
  
  LOCK();
  bVar14 = MASTERS == '\0';
  if (bVar14) {
    MASTERS = '\x01';
  }
  UNLOCK();
  if (!bVar14) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&MASTERS);
  }
  puVar10 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    local_40 = 0;
    lVar9 = DAT_1406997a8;
  }
  else {
    local_40 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_40 = local_40 ^ 1;
    lVar9 = DAT_1406997a8;
  }
  DAT_1406997a8 = lVar9;
  if (DAT_140699791 != '\0') {
    local_48 = &MASTERS;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_48,
               &anon_d5c34e88a06ee720b116585eb143da4b_147_llvm_14435704873730135342,
               &anon_d5c34e88a06ee720b116585eb143da4b_361_llvm_14435704873730135342);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  lVar13 = lVar9 * 0x20;
  if (lVar9 != 0) {
    if (*param_1 == '\0') {
      lVar12 = 0;
      do {
        if (((*(char *)(DAT_1406997a0 + lVar12) == '\0') &&
            (*(short *)(DAT_1406997a0 + 6 + lVar12) == *(short *)(param_1 + 6))) &&
           (*(int *)(DAT_1406997a0 + 2 + lVar12) == *(int *)(param_1 + 2))) goto LAB_140021979;
        lVar12 = lVar12 + 0x20;
      } while (lVar13 != lVar12);
    }
    else {
      lVar12 = 0;
      do {
        if (((*(short *)(DAT_1406997a0 + lVar12) != 0) &&
            (*(short *)(DAT_1406997a0 + 0x1c + lVar12) == *(short *)(param_1 + 0x1c))) &&
           ((*(int *)(DAT_1406997a0 + 0x14 + lVar12) == *(int *)(param_1 + 0x14) &&
            ((*(int *)(DAT_1406997a0 + 0x18 + lVar12) == *(int *)(param_1 + 0x18) &&
             (*(longlong *)(DAT_1406997a0 + 0xc + lVar12) == *(longlong *)(param_1 + 0xc) &&
              *(longlong *)(DAT_1406997a0 + 4 + lVar12) == *(longlong *)(param_1 + 4)))))))
        goto LAB_140021979;
        lVar12 = lVar12 + 0x20;
      } while (lVar13 != lVar12);
    }
  }
  if (lVar9 == DAT_140699798) {
    <alloc[246c2e7857c81348]::raw_vec::RawVec<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
    ::grow_one(&DAT_140699798);
  }
  lVar12 = DAT_1406997a0;
  uVar4 = *(undefined4 *)param_1;
  uVar5 = *(undefined4 *)(param_1 + 4);
  uVar6 = *(undefined4 *)(param_1 + 8);
  uVar7 = *(undefined4 *)(param_1 + 0xc);
  uVar8 = *(undefined8 *)(param_1 + 0x18);
  puVar2 = (undefined8 *)(DAT_1406997a0 + 0x10 + lVar13);
  *puVar2 = *(undefined8 *)(param_1 + 0x10);
  puVar2[1] = uVar8;
  puVar1 = (undefined4 *)(lVar12 + lVar13);
  *puVar1 = uVar4;
  puVar1[1] = uVar5;
  puVar1[2] = uVar6;
  puVar1[3] = uVar7;
  DAT_1406997a8 = lVar9 + 1;
LAB_140021979:
  if (((local_40 == 0) && ((*(ulonglong *)puVar10 & 0x7fffffffffffffff) != 0)) &&
     (cVar11 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar11 == '\0'))
  {
    DAT_140699791 = '\x01';
  }
  cVar11 = MASTERS;
  LOCK();
  MASTERS = 0;
  UNLOCK();
  if (cVar11 != '\x02') {
    return;
  }
  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&MASTERS);
  return;
}

