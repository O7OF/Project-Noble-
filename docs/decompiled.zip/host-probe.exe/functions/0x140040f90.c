// rea decompile_all
// name: <alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Write>::write_char
// address: 0x140040f90
// body: available
// range: 0x140040f90-0x1400410d0 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::string::String as core[505b25137b8ba7f]::fmt::Write>::write_char */

undefined8 __rustcall
<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::fmt::Write>::write_char
          (longlong *param_1,uint param_2)

{
  longlong lVar1;
  byte bVar2;
  longlong lVar3;
  byte bVar4;
  ulonglong uVar5;
  byte bVar6;
  
  lVar1 = param_1[2];
  if (param_2 < 0x80) {
    if (*param_1 == lVar1) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar1,1,1,1);
    }
    *(byte *)(param_1[1] + lVar1) = (byte)param_2;
    lVar3 = 1;
  }
  else {
    uVar5 = 2;
    if (0x7ff < param_2) {
      uVar5 = 4 - (ulonglong)(param_2 < 0x10000);
    }
    if ((ulonglong)(*param_1 - lVar1) < uVar5) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar1,uVar5,1,1);
    }
    bVar2 = (byte)param_2 & 0x3f | 0x80;
    lVar3 = param_1[1];
    bVar4 = (byte)(param_2 >> 6);
    if (param_2 < 0x800) {
      *(byte *)(lVar3 + lVar1) = bVar4 | 0xc0;
      *(byte *)(lVar3 + 1 + lVar1) = bVar2;
      lVar3 = 2;
    }
    else {
      bVar4 = bVar4 & 0x3f | 0x80;
      bVar6 = (byte)(param_2 >> 0xc);
      if (param_2 < 0x10000) {
        *(byte *)(lVar3 + lVar1) = bVar6 | 0xe0;
        *(byte *)(lVar3 + 1 + lVar1) = bVar4;
        *(byte *)(lVar3 + 2 + lVar1) = bVar2;
        lVar3 = 3;
      }
      else {
        *(byte *)(lVar3 + lVar1) = (byte)(param_2 >> 0x12) | 0xf0;
        *(byte *)(lVar3 + 1 + lVar1) = bVar6 & 0x3f | 0x80;
        *(byte *)(lVar3 + 2 + lVar1) = bVar4;
        *(byte *)(lVar3 + 3 + lVar1) = bVar2;
        lVar3 = 4;
      }
    }
  }
  param_1[2] = lVar3 + lVar1;
  return 0;
}

