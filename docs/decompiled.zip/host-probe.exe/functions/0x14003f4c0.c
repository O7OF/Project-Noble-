// rea decompile_all
// name: <&mut_host_probe[b94139f9089eb1d8]::ingame_chat::engine_roster::{closure#2}as_core[505b25137b8ba7f]::ops::function::FnMut<(&u64,)>>::call_mut
// address: 0x14003f4c0
// body: available
// range: 0x14003f4c0-0x14003f565 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut host_probe[b94139f9089eb1d8]::ingame_chat::engine_roster::{closure#2} as
   core[505b25137b8ba7f]::ops::function::FnMut<(&u64,)>>::call_mut */

longlong __rustcall
<&mut_host_probe[b94139f9089eb1d8]::ingame_chat::engine_roster::{closure#2}as_core[505b25137b8ba7f]::ops::function::FnMut<(&u64,)>>
::call_mut(undefined8 *param_1,longlong *param_2)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  ulonglong uVar7;
  bool bVar8;
  
  lVar4 = *(longlong *)*param_1;
  lVar1 = *param_2;
  lVar2 = *(longlong *)(lVar4 + 8);
  uVar3 = *(ulonglong *)(lVar4 + 0x10);
  uVar5 = uVar3 & 0xffffffffffffff8;
  if (uVar5 != 0) {
    uVar7 = 0;
    do {
      lVar4 = CONCAT71((int7)((ulonglong)lVar4 >> 8),1);
      if (*(longlong *)(lVar2 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      if (*(longlong *)(lVar2 + 8 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      if (*(longlong *)(lVar2 + 0x10 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      if (*(longlong *)(lVar2 + 0x18 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      if (*(longlong *)(lVar2 + 0x20 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      if (*(longlong *)(lVar2 + 0x28 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      if (*(longlong *)(lVar2 + 0x30 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      if (*(longlong *)(lVar2 + 0x38 + uVar7 * 8) == lVar1) {
        return lVar4;
      }
      uVar7 = uVar7 + 8;
    } while (uVar5 != uVar7);
  }
  if ((uVar3 & 7) == 0) {
    return 0;
  }
  lVar6 = 0;
  do {
    bVar8 = *(longlong *)(lVar2 + uVar5 * 8 + lVar6) == lVar1;
    lVar4 = CONCAT71((int7)((ulonglong)lVar4 >> 8),bVar8);
    if (bVar8) {
      return lVar4;
    }
    bVar8 = (ulonglong)(((uint)uVar3 & 7) << 3) - 8 != lVar6;
    lVar6 = lVar6 + 8;
  } while (bVar8);
  return lVar4;
}

