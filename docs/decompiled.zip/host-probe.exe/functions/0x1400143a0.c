// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::net::Star>::supports
// address: 0x1400143a0
// body: available
// range: 0x1400143a0-0x1400144ef inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::net::Star>::supports */

ushort __rustcall
<host_probe[b94139f9089eb1d8]::net::Star>::supports
          (longlong param_1,longlong param_2,longlong param_3)

{
  char *pcVar1;
  uint uVar2;
  uint uVar3;
  ulonglong uVar4;
  longlong lVar5;
  longlong lVar6;
  uint uVar7;
  ushort uVar8;
  longlong lVar9;
  byte bVar10;
  undefined1 auVar11 [16];
  undefined1 auVar12 [16];
  undefined1 auVar13 [16];
  undefined1 auVar14 [16];
  longlong local_20;
  
  if (*(longlong *)(param_1 + 0x48) != 0) {
    local_20 = param_2;
    uVar4 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
            ::hash_one::<&usize>(param_1 + 0x50,&local_20);
    lVar5 = *(longlong *)(param_1 + 0x30);
    bVar10 = (byte)(uVar4 >> 0x39);
    auVar11 = ZEXT216(CONCAT11(bVar10,bVar10));
    auVar11 = pshuflw(auVar11,auVar11,0);
    lVar6 = 0;
    while( true ) {
      uVar4 = uVar4 & *(ulonglong *)(param_1 + 0x38);
      pcVar1 = (char *)(lVar5 + uVar4);
      auVar14[0] = -(*pcVar1 == auVar11[0]);
      auVar14[1] = -(pcVar1[1] == auVar11[1]);
      auVar14[2] = -(pcVar1[2] == auVar11[2]);
      auVar14[3] = -(pcVar1[3] == auVar11[3]);
      auVar14[4] = -(pcVar1[4] == auVar11[4]);
      auVar14[5] = -(pcVar1[5] == auVar11[5]);
      auVar14[6] = -(pcVar1[6] == auVar11[6]);
      auVar14[7] = -(pcVar1[7] == auVar11[7]);
      auVar14[8] = -(pcVar1[8] == auVar11[0]);
      auVar14[9] = -(pcVar1[9] == auVar11[1]);
      auVar14[10] = -(pcVar1[10] == auVar11[2]);
      auVar14[0xb] = -(pcVar1[0xb] == auVar11[3]);
      auVar14[0xc] = -(pcVar1[0xc] == auVar11[4]);
      auVar14[0xd] = -(pcVar1[0xd] == auVar11[5]);
      auVar14[0xe] = -(pcVar1[0xe] == auVar11[6]);
      auVar14[0xf] = -(pcVar1[0xf] == auVar11[7]);
      uVar8 = (ushort)(SUB161(auVar14 >> 7,0) & 1) | (ushort)(SUB161(auVar14 >> 0xf,0) & 1) << 1 |
              (ushort)(SUB161(auVar14 >> 0x17,0) & 1) << 2 |
              (ushort)(SUB161(auVar14 >> 0x1f,0) & 1) << 3 |
              (ushort)(SUB161(auVar14 >> 0x27,0) & 1) << 4 |
              (ushort)(SUB161(auVar14 >> 0x2f,0) & 1) << 5 |
              (ushort)(SUB161(auVar14 >> 0x37,0) & 1) << 6 |
              (ushort)(SUB161(auVar14 >> 0x3f,0) & 1) << 7 |
              (ushort)(SUB161(auVar14 >> 0x47,0) & 1) << 8 |
              (ushort)(SUB161(auVar14 >> 0x4f,0) & 1) << 9 |
              (ushort)(SUB161(auVar14 >> 0x57,0) & 1) << 10 |
              (ushort)(SUB161(auVar14 >> 0x5f,0) & 1) << 0xb |
              (ushort)(SUB161(auVar14 >> 0x67,0) & 1) << 0xc |
              (ushort)(SUB161(auVar14 >> 0x6f,0) & 1) << 0xd |
              (ushort)(SUB161(auVar14 >> 0x77,0) & 1) << 0xe | (ushort)(auVar14[0xf] >> 7) << 0xf;
      uVar7 = (uint)uVar8;
      while (uVar8 != 0) {
        uVar2 = 0;
        for (uVar3 = uVar7; (uVar3 & 1) == 0; uVar3 = uVar3 >> 1 | 0x80000000) {
          uVar2 = uVar2 + 1;
        }
        lVar9 = (uVar2 + uVar4 & *(ulonglong *)(param_1 + 0x38)) * -0x50;
        if (param_2 == *(longlong *)(lVar5 + -0x50 + lVar9)) {
          lVar5 = lVar5 + lVar9;
          if (*(short *)(lVar5 + -0x38) != *(short *)(param_3 + 0x10)) {
            return 0;
          }
          if (*(short *)(lVar5 + -0x38) == 0) {
            if (*(short *)(lVar5 + -0x32) != *(short *)(param_3 + 0x16)) {
              return 0;
            }
            if (*(int *)(lVar5 + -0x36) != *(int *)(param_3 + 0x12)) {
              return 0;
            }
          }
          else {
            if (*(short *)(lVar5 + -0x1c) != *(short *)(param_3 + 0x2c)) {
              return 0;
            }
            if (*(int *)(lVar5 + -0x24) != *(int *)(param_3 + 0x24)) {
              return 0;
            }
            if (*(int *)(lVar5 + -0x20) != *(int *)(param_3 + 0x28)) {
              return 0;
            }
            auVar11[0] = -(*(char *)(param_3 + 0x14) == *(char *)(lVar5 + -0x34));
            auVar11[1] = -(*(char *)(param_3 + 0x15) == *(char *)(lVar5 + -0x33));
            auVar11[2] = -(*(char *)(param_3 + 0x16) == *(char *)(lVar5 + -0x32));
            auVar11[3] = -(*(char *)(param_3 + 0x17) == *(char *)(lVar5 + -0x31));
            auVar11[4] = -(*(char *)(param_3 + 0x18) == *(char *)(lVar5 + -0x30));
            auVar11[5] = -(*(char *)(param_3 + 0x19) == *(char *)(lVar5 + -0x2f));
            auVar11[6] = -(*(char *)(param_3 + 0x1a) == *(char *)(lVar5 + -0x2e));
            auVar11[7] = -(*(char *)(param_3 + 0x1b) == *(char *)(lVar5 + -0x2d));
            auVar11[8] = -(*(char *)(param_3 + 0x1c) == *(char *)(lVar5 + -0x2c));
            auVar11[9] = -(*(char *)(param_3 + 0x1d) == *(char *)(lVar5 + -0x2b));
            auVar11[10] = -(*(char *)(param_3 + 0x1e) == *(char *)(lVar5 + -0x2a));
            auVar11[0xb] = -(*(char *)(param_3 + 0x1f) == *(char *)(lVar5 + -0x29));
            auVar11[0xc] = -(*(char *)(param_3 + 0x20) == *(char *)(lVar5 + -0x28));
            auVar11[0xd] = -(*(char *)(param_3 + 0x21) == *(char *)(lVar5 + -0x27));
            auVar11[0xe] = -(*(char *)(param_3 + 0x22) == *(char *)(lVar5 + -0x26));
            auVar11[0xf] = -(*(char *)(param_3 + 0x23) == *(char *)(lVar5 + -0x25));
            if ((ushort)((ushort)(SUB161(auVar11 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar11 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar11 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar11 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar11 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar11 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar11 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar11 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar11 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar11 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar11 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar11 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar11 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar11 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar11 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar11[0xf] >> 7) << 0xf) != 0xffff) {
              return 0;
            }
          }
          if (*(char *)(lVar5 + -0x18) != '\x01') {
            return (ushort)(*(byte *)(param_3 + 0x30) ^ 1);
          }
          if (*(byte *)(param_3 + 0x30) == 0) {
            return 0;
          }
          auVar12[0] = -(*(char *)(param_3 + 0x31) == *(char *)(lVar5 + -0x17));
          auVar12[1] = -(*(char *)(param_3 + 0x32) == *(char *)(lVar5 + -0x16));
          auVar12[2] = -(*(char *)(param_3 + 0x33) == *(char *)(lVar5 + -0x15));
          auVar12[3] = -(*(char *)(param_3 + 0x34) == *(char *)(lVar5 + -0x14));
          auVar12[4] = -(*(char *)(param_3 + 0x35) == *(char *)(lVar5 + -0x13));
          auVar12[5] = -(*(char *)(param_3 + 0x36) == *(char *)(lVar5 + -0x12));
          auVar12[6] = -(*(char *)(param_3 + 0x37) == *(char *)(lVar5 + -0x11));
          auVar12[7] = -(*(char *)(param_3 + 0x38) == *(char *)(lVar5 + -0x10));
          auVar12[8] = -(*(char *)(param_3 + 0x39) == *(char *)(lVar5 + -0xf));
          auVar12[9] = -(*(char *)(param_3 + 0x3a) == *(char *)(lVar5 + -0xe));
          auVar12[10] = -(*(char *)(param_3 + 0x3b) == *(char *)(lVar5 + -0xd));
          auVar12[0xb] = -(*(char *)(param_3 + 0x3c) == *(char *)(lVar5 + -0xc));
          auVar12[0xc] = -(*(char *)(param_3 + 0x3d) == *(char *)(lVar5 + -0xb));
          auVar12[0xd] = -(*(char *)(param_3 + 0x3e) == *(char *)(lVar5 + -10));
          auVar12[0xe] = -(*(char *)(param_3 + 0x3f) == *(char *)(lVar5 + -9));
          auVar12[0xf] = -(*(char *)(param_3 + 0x40) == *(char *)(lVar5 + -8));
          uVar8 = (ushort)(SUB161(auVar12 >> 7,0) & 1) | (ushort)(SUB161(auVar12 >> 0xf,0) & 1) << 1
                  | (ushort)(SUB161(auVar12 >> 0x17,0) & 1) << 2 |
                  (ushort)(SUB161(auVar12 >> 0x1f,0) & 1) << 3 |
                  (ushort)(SUB161(auVar12 >> 0x27,0) & 1) << 4 |
                  (ushort)(SUB161(auVar12 >> 0x2f,0) & 1) << 5 |
                  (ushort)(SUB161(auVar12 >> 0x37,0) & 1) << 6 |
                  (ushort)(SUB161(auVar12 >> 0x3f,0) & 1) << 7 |
                  (ushort)(SUB161(auVar12 >> 0x47,0) & 1) << 8 |
                  (ushort)(SUB161(auVar12 >> 0x4f,0) & 1) << 9 |
                  (ushort)(SUB161(auVar12 >> 0x57,0) & 1) << 10 |
                  (ushort)(SUB161(auVar12 >> 0x5f,0) & 1) << 0xb |
                  (ushort)(SUB161(auVar12 >> 0x67,0) & 1) << 0xc |
                  (ushort)(SUB161(auVar12 >> 0x6f,0) & 1) << 0xd |
                  (ushort)(SUB161(auVar12 >> 0x77,0) & 1) << 0xe |
                  (ushort)(auVar12[0xf] >> 7) << 0xf;
          return CONCAT11((char)(uVar8 >> 8),uVar8 == 0xffff);
        }
        uVar8 = (ushort)(uVar7 - 1) & (ushort)uVar7;
        uVar7 = CONCAT22((short)(uVar7 - 1 >> 0x10),uVar8);
      }
      auVar13[0] = -(*pcVar1 == -1);
      auVar13[1] = -(pcVar1[1] == -1);
      auVar13[2] = -(pcVar1[2] == -1);
      auVar13[3] = -(pcVar1[3] == -1);
      auVar13[4] = -(pcVar1[4] == -1);
      auVar13[5] = -(pcVar1[5] == -1);
      auVar13[6] = -(pcVar1[6] == -1);
      auVar13[7] = -(pcVar1[7] == -1);
      auVar13[8] = -(pcVar1[8] == -1);
      auVar13[9] = -(pcVar1[9] == -1);
      auVar13[10] = -(pcVar1[10] == -1);
      auVar13[0xb] = -(pcVar1[0xb] == -1);
      auVar13[0xc] = -(pcVar1[0xc] == -1);
      auVar13[0xd] = -(pcVar1[0xd] == -1);
      auVar13[0xe] = -(pcVar1[0xe] == -1);
      auVar13[0xf] = -(pcVar1[0xf] == -1);
      if ((((((((((((((((SUB161(auVar13 >> 7,0) & 1) != 0 || (SUB161(auVar13 >> 0xf,0) & 1) != 0) ||
                      (SUB161(auVar13 >> 0x17,0) & 1) != 0) || (SUB161(auVar13 >> 0x1f,0) & 1) != 0)
                    || (SUB161(auVar13 >> 0x27,0) & 1) != 0) || (SUB161(auVar13 >> 0x2f,0) & 1) != 0
                   ) || (SUB161(auVar13 >> 0x37,0) & 1) != 0) ||
                 (SUB161(auVar13 >> 0x3f,0) & 1) != 0) || (SUB161(auVar13 >> 0x47,0) & 1) != 0) ||
               (SUB161(auVar13 >> 0x4f,0) & 1) != 0) || (SUB161(auVar13 >> 0x57,0) & 1) != 0) ||
             (SUB161(auVar13 >> 0x5f,0) & 1) != 0) || (SUB161(auVar13 >> 0x67,0) & 1) != 0) ||
           (SUB161(auVar13 >> 0x6f,0) & 1) != 0) || (SUB161(auVar13 >> 0x77,0) & 1) != 0) ||
          auVar13[0xf] < '\0') break;
      uVar4 = uVar4 + lVar6 + 0x10;
      lVar6 = lVar6 + 0x10;
    }
  }
  return 0;
}

