// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::route_of
// address: 0x1400384e0
// body: available
// range: 0x1400384e0-0x14003865a inclusive
// range: 0x140038660-0x1400386c4 inclusive
// range: 0x1400386d0-0x14003888d inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::route_of */

undefined1 * __rustcall
host_probe[b94139f9089eb1d8]::net::route_of(undefined1 *param_1,longlong param_2)

{
  undefined1 auVar1 [16];
  undefined1 uVar2;
  code *pcVar3;
  uint uVar4;
  uint uVar5;
  undefined *puVar6;
  undefined *puVar7;
  char cVar8;
  ulonglong uVar9;
  undefined1 uVar10;
  undefined1 (*pauVar11) [16];
  uint uVar12;
  ushort uVar13;
  ulonglong uVar14;
  int iVar15;
  longlong lVar16;
  undefined1 (*pauVar17) [16];
  longlong lVar18;
  bool bVar19;
  byte bVar20;
  undefined1 auVar21 [16];
  undefined1 auVar22 [16];
  undefined1 auVar23 [16];
  undefined8 local_68;
  undefined4 local_60;
  longlong local_58;
  undefined1 *local_50;
  byte local_48;
  
  if (DAT_140699990 != 0) {
    *param_1 = 2;
    return param_1;
  }
  LOCK();
  bVar19 = DAT_140699948 == '\0';
  if (bVar19) {
    DAT_140699948 = '\x01';
  }
  UNLOCK();
  local_58 = param_2;
  if (!bVar19) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
  }
  puVar6 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    local_48 = 0;
    lVar18 = DAT_140699968;
  }
  else {
    local_48 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_48 = local_48 ^ 1;
    lVar18 = DAT_140699968;
  }
  DAT_140699968 = lVar18;
  if (DAT_140699949 != '\0') {
    local_50 = &DAT_140699948;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_50,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2e70);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  if (lVar18 != 0) {
    uVar9 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
            ::hash_one::<&usize>(&DAT_140699970,&local_58);
    puVar7 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
    bVar20 = (byte)(uVar9 >> 0x39);
    auVar21 = ZEXT216(CONCAT11(bVar20,bVar20));
    auVar21 = pshuflw(auVar21,auVar21,0);
    lVar16 = 0;
    while( true ) {
      uVar9 = uVar9 & DAT_140699958;
      auVar1 = *(undefined1 (*) [16])(*DAT_140699950 + uVar9);
      auVar23[0] = -(auVar1[0] == auVar21[0]);
      auVar23[1] = -(auVar1[1] == auVar21[1]);
      auVar23[2] = -(auVar1[2] == auVar21[2]);
      auVar23[3] = -(auVar1[3] == auVar21[3]);
      auVar23[4] = -(auVar1[4] == auVar21[4]);
      auVar23[5] = -(auVar1[5] == auVar21[5]);
      auVar23[6] = -(auVar1[6] == auVar21[6]);
      auVar23[7] = -(auVar1[7] == auVar21[7]);
      auVar23[8] = -(auVar1[8] == auVar21[0]);
      auVar23[9] = -(auVar1[9] == auVar21[1]);
      auVar23[10] = -(auVar1[10] == auVar21[2]);
      auVar23[0xb] = -(auVar1[0xb] == auVar21[3]);
      auVar23[0xc] = -(auVar1[0xc] == auVar21[4]);
      auVar23[0xd] = -(auVar1[0xd] == auVar21[5]);
      auVar23[0xe] = -(auVar1[0xe] == auVar21[6]);
      auVar23[0xf] = -(auVar1[0xf] == auVar21[7]);
      uVar13 = (ushort)(SUB161(auVar23 >> 7,0) & 1) | (ushort)(SUB161(auVar23 >> 0xf,0) & 1) << 1 |
               (ushort)(SUB161(auVar23 >> 0x17,0) & 1) << 2 |
               (ushort)(SUB161(auVar23 >> 0x1f,0) & 1) << 3 |
               (ushort)(SUB161(auVar23 >> 0x27,0) & 1) << 4 |
               (ushort)(SUB161(auVar23 >> 0x2f,0) & 1) << 5 |
               (ushort)(SUB161(auVar23 >> 0x37,0) & 1) << 6 |
               (ushort)(SUB161(auVar23 >> 0x3f,0) & 1) << 7 |
               (ushort)(SUB161(auVar23 >> 0x47,0) & 1) << 8 |
               (ushort)(SUB161(auVar23 >> 0x4f,0) & 1) << 9 |
               (ushort)(SUB161(auVar23 >> 0x57,0) & 1) << 10 |
               (ushort)(SUB161(auVar23 >> 0x5f,0) & 1) << 0xb |
               (ushort)(SUB161(auVar23 >> 0x67,0) & 1) << 0xc |
               (ushort)(SUB161(auVar23 >> 0x6f,0) & 1) << 0xd |
               (ushort)(SUB161(auVar23 >> 0x77,0) & 1) << 0xe | (ushort)(auVar23[0xf] >> 7) << 0xf;
      uVar12 = (uint)uVar13;
      while (uVar13 != 0) {
        uVar4 = 0;
        for (uVar5 = uVar12; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
          uVar4 = uVar4 + 1;
        }
        uVar14 = uVar4 + uVar9 & DAT_140699958;
        if (param_2 == *(longlong *)DAT_140699950[uVar14 * -5 + -5]) {
          auVar21 = *DAT_140699950;
          pauVar17 = DAT_140699950 + 1;
          uVar12 = ~(uint)(ushort)((ushort)(SUB161(auVar21 >> 7,0) & 1) |
                                   (ushort)(SUB161(auVar21 >> 0xf,0) & 1) << 1 |
                                   (ushort)(SUB161(auVar21 >> 0x17,0) & 1) << 2 |
                                   (ushort)(SUB161(auVar21 >> 0x1f,0) & 1) << 3 |
                                   (ushort)(SUB161(auVar21 >> 0x27,0) & 1) << 4 |
                                   (ushort)(SUB161(auVar21 >> 0x2f,0) & 1) << 5 |
                                   (ushort)(SUB161(auVar21 >> 0x37,0) & 1) << 6 |
                                   (ushort)(SUB161(auVar21 >> 0x3f,0) & 1) << 7 |
                                   (ushort)(SUB161(auVar21 >> 0x47,0) & 1) << 8 |
                                   (ushort)(SUB161(auVar21 >> 0x4f,0) & 1) << 9 |
                                   (ushort)(SUB161(auVar21 >> 0x57,0) & 1) << 10 |
                                   (ushort)(SUB161(auVar21 >> 0x5f,0) & 1) << 0xb |
                                   (ushort)(SUB161(auVar21 >> 0x67,0) & 1) << 0xc |
                                   (ushort)(SUB161(auVar21 >> 0x6f,0) & 1) << 0xd |
                                   (ushort)(SUB161(auVar21 >> 0x77,0) & 1) << 0xe |
                                  (ushort)(byte)(auVar21[0xf] >> 7) << 0xf);
          iVar15 = *(int *)(DAT_140699950[uVar14 * -5 + -4] + 10);
          pauVar11 = DAT_140699950;
          if ((DAT_140699950[uVar14 * -5 + -4][8] & 1) == 0) goto LAB_14003866e;
          goto LAB_1400386da;
        }
        uVar13 = (ushort)(uVar12 - 1) & (ushort)uVar12;
        uVar12 = CONCAT22((short)(uVar12 - 1 >> 0x10),uVar13);
      }
      auVar22[0] = -(auVar1[0] == -1);
      auVar22[1] = -(auVar1[1] == -1);
      auVar22[2] = -(auVar1[2] == -1);
      auVar22[3] = -(auVar1[3] == -1);
      auVar22[4] = -(auVar1[4] == -1);
      auVar22[5] = -(auVar1[5] == -1);
      auVar22[6] = -(auVar1[6] == -1);
      auVar22[7] = -(auVar1[7] == -1);
      auVar22[8] = -(auVar1[8] == -1);
      auVar22[9] = -(auVar1[9] == -1);
      auVar22[10] = -(auVar1[10] == -1);
      auVar22[0xb] = -(auVar1[0xb] == -1);
      auVar22[0xc] = -(auVar1[0xc] == -1);
      auVar22[0xd] = -(auVar1[0xd] == -1);
      auVar22[0xe] = -(auVar1[0xe] == -1);
      auVar22[0xf] = -(auVar1[0xf] == -1);
      if ((((((((((((((((SUB161(auVar22 >> 7,0) & 1) != 0 || (SUB161(auVar22 >> 0xf,0) & 1) != 0) ||
                      (SUB161(auVar22 >> 0x17,0) & 1) != 0) || (SUB161(auVar22 >> 0x1f,0) & 1) != 0)
                    || (SUB161(auVar22 >> 0x27,0) & 1) != 0) || (SUB161(auVar22 >> 0x2f,0) & 1) != 0
                   ) || (SUB161(auVar22 >> 0x37,0) & 1) != 0) ||
                 (SUB161(auVar22 >> 0x3f,0) & 1) != 0) || (SUB161(auVar22 >> 0x47,0) & 1) != 0) ||
               (SUB161(auVar22 >> 0x4f,0) & 1) != 0) || (SUB161(auVar22 >> 0x57,0) & 1) != 0) ||
             (SUB161(auVar22 >> 0x5f,0) & 1) != 0) || (SUB161(auVar22 >> 0x67,0) & 1) != 0) ||
           (SUB161(auVar22 >> 0x6f,0) & 1) != 0) || (SUB161(auVar22 >> 0x77,0) & 1) != 0) ||
          auVar22[0xf] < '\0') break;
      uVar9 = uVar9 + lVar16 + 0x10;
      lVar16 = lVar16 + 0x10;
    }
  }
  *param_1 = 2;
  if ((local_48 != 0) || ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) == 0)) goto LAB_1400387b2;
  cVar8 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
  goto LAB_14003887a;
  while( true ) {
    uVar12 = uVar12 - 1 & uVar12;
    lVar18 = lVar18 + -1;
    if (lVar18 == 0) break;
LAB_14003866e:
    uVar13 = (ushort)uVar12;
    while (uVar13 == 0) {
      auVar21 = *pauVar17;
      pauVar11 = pauVar11 + -0x50;
      pauVar17 = pauVar17 + 1;
      uVar13 = ((ushort)(SUB161(auVar21 >> 7,0) & 1) | (ushort)(SUB161(auVar21 >> 0xf,0) & 1) << 1 |
                (ushort)(SUB161(auVar21 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar21 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar21 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar21 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar21 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar21 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar21 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar21 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar21 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar21 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar21 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar21 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar21 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar21[0xf] >> 7) << 0xf) ^ 0xffff;
      uVar12 = (uint)uVar13;
    }
    uVar4 = 0;
    for (uVar5 = uVar12; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
      uVar4 = uVar4 + 1;
    }
    uVar9 = (ulonglong)uVar4;
    if (((*(longlong *)pauVar11[uVar9 * -5 + -5] != param_2) &&
        (pauVar11[uVar9 * -5 + -4][8] == '\0')) &&
       (*(int *)(pauVar11[uVar9 * -5 + -4] + 10) == iVar15)) goto LAB_140038731;
  }
  goto LAB_14003874f;
LAB_140038731:
  uVar10 = 1;
  goto joined_r0x000140038748;
  while( true ) {
    uVar12 = uVar12 - 1 & uVar12;
    lVar18 = lVar18 + -1;
    if (lVar18 == 0) break;
LAB_1400386da:
    uVar13 = (ushort)uVar12;
    while (uVar13 == 0) {
      auVar21 = *pauVar17;
      pauVar11 = pauVar11 + -0x50;
      pauVar17 = pauVar17 + 1;
      uVar13 = ((ushort)(SUB161(auVar21 >> 7,0) & 1) | (ushort)(SUB161(auVar21 >> 0xf,0) & 1) << 1 |
                (ushort)(SUB161(auVar21 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar21 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar21 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar21 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar21 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar21 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar21 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar21 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar21 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar21 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar21 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar21 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar21 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar21[0xf] >> 7) << 0xf) ^ 0xffff;
      uVar12 = (uint)uVar13;
    }
    uVar4 = 0;
    for (uVar5 = uVar12; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
      uVar4 = uVar4 + 1;
    }
    uVar9 = (ulonglong)uVar4;
    if (((*(longlong *)pauVar11[uVar9 * -5 + -5] != param_2) &&
        (*(short *)(pauVar11[uVar9 * -5 + -4] + 8) == 1)) &&
       (*(longlong *)(pauVar11[uVar9 * -5 + -3] + 4) ==
        *(longlong *)(DAT_140699950[uVar14 * -5 + -3] + 4) &&
        *(longlong *)(pauVar11[uVar9 * -5 + -4] + 0xc) ==
        *(longlong *)(DAT_140699950[uVar14 * -5 + -4] + 0xc))) goto LAB_140038731;
  }
LAB_14003874f:
  uVar10 = 0;
joined_r0x000140038748:
  bVar19 = (DAT_140699950[uVar14 * -5 + -4][8] & 1) != 0;
  if (bVar19) {
    local_60 = *(undefined4 *)(DAT_140699950[uVar14 * -5 + -3] + 8);
    local_68 = *(undefined8 *)DAT_140699950[uVar14 * -5 + -3];
    iVar15 = (int)*(longlong *)(DAT_140699950[uVar14 * -5 + -4] + 0xc);
  }
  uVar2 = DAT_140699950[uVar14 * -5 + -2][8];
  *param_1 = bVar19;
  *(int *)(param_1 + 1) = iVar15;
  *(undefined8 *)(param_1 + 5) = local_68;
  *(undefined4 *)(param_1 + 0xd) = local_60;
  param_1[0x11] = uVar2;
  param_1[0x12] = uVar10;
  if ((local_48 == 0) && ((*(ulonglong *)puVar7 & 0x7fffffffffffffff) != 0)) {
    cVar8 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
LAB_14003887a:
    if (cVar8 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
LAB_1400387b2:
  cVar8 = DAT_140699948;
  LOCK();
  DAT_140699948 = 0;
  UNLOCK();
  if (cVar8 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
  return param_1;
}

