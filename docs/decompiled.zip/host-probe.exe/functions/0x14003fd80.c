// rea decompile_all
// name: <&mut_host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#1}as_core[505b25137b8ba7f]::ops::function::FnMut<(&(&u64,&host_probe[b94139f9089eb1d8]::net::Route),)>>::call_mut
// address: 0x14003fd80
// body: available
// range: 0x14003fd80-0x14003fddf inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#1} as
   core[505b25137b8ba7f]::ops::function::FnMut<(&(&u64,
   &host_probe[b94139f9089eb1d8]::net::Route),)>>::call_mut */

ulonglong __rustcall
<&mut_host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#1}as_core[505b25137b8ba7f]::ops::function::FnMut<(&(&u64,&host_probe[b94139f9089eb1d8]::net::Route),)>>
::call_mut(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  ulonglong uVar2;
  undefined8 local_20;
  undefined4 local_18;
  
  puVar1 = (undefined8 *)param_2[1];
  if (*(char *)(puVar1 + 6) == '\0') {
    param_2 = (undefined8 *)*param_2;
    local_20 = **(undefined8 **)*param_1;
    local_18 = *(undefined4 *)(*(undefined8 **)*param_1 + 1);
    uVar2 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                      (&local_20,*puVar1,*(undefined4 *)(puVar1 + 1));
    if (uVar2 < 0xf) {
      uVar2 = host_probe[b94139f9089eb1d8]::net::is_blocked(*param_2,puVar1 + 2);
      return uVar2 ^ 1;
    }
  }
  return 0;
}

