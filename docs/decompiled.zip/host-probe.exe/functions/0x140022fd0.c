// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::master_ips
// address: 0x140022fd0
// body: available
// range: 0x140022fd0-0x14002307a inclusive
// range: 0x140023080-0x1400231d0 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::master_ips */

longlong * __rustcall host_probe[b94139f9089eb1d8]::net::master_ips(longlong *param_1)

{
  code *pcVar1;
  longlong lVar2;
  uint uVar3;
  undefined *puVar4;
  byte bVar5;
  char cVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  undefined4 uVar11;
  undefined8 *puVar12;
  bool bVar13;
  undefined1 *local_48;
  undefined4 local_40;
  
  LOCK();
  bVar13 = MASTERS == '\0';
  if (bVar13) {
    MASTERS = '\x01';
  }
  UNLOCK();
  if (!bVar13) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&MASTERS);
  }
  puVar4 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar5 = 0;
    lVar8 = DAT_1406997a0;
    lVar2 = DAT_1406997a8;
  }
  else {
    bVar5 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar5 = bVar5 ^ 1;
    lVar8 = DAT_1406997a0;
    lVar2 = DAT_1406997a8;
  }
  DAT_1406997a0 = lVar8;
  DAT_1406997a8 = lVar2;
  if (DAT_140699791 == '\0') {
    lVar10 = lVar2 * 0x11;
    if (lVar10 < 0) {
      uVar9 = 0;
    }
    else {
      if (lVar2 == 0) {
        lVar7 = 1;
LAB_1400230d9:
        *param_1 = lVar2;
        param_1[1] = lVar7;
        param_1[2] = lVar2;
        if (((bVar5 == 0) && ((*(ulonglong *)puVar4 & 0x7fffffffffffffff) != 0)) &&
           (cVar6 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(),
           cVar6 == '\0')) {
          DAT_140699791 = '\x01';
        }
        cVar6 = MASTERS;
        LOCK();
        MASTERS = 0;
        UNLOCK();
        if (cVar6 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&MASTERS);
        }
        return param_1;
      }
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar9 = 1;
      lVar7 = __rustc[9d087a5ab36ea756]::__rust_alloc(lVar10,1);
      if (lVar7 != 0) {
        puVar12 = (undefined8 *)(lVar8 + 8);
        lVar8 = lVar7;
        lVar10 = lVar2;
        do {
          if (*(short *)(puVar12 + -1) == 1) {
            uVar11 = *(undefined4 *)((longlong)puVar12 + -4);
            local_40 = *(undefined4 *)(puVar12 + 1);
            local_48 = (undefined1 *)*puVar12;
          }
          else {
            uVar11 = *(undefined4 *)((longlong)puVar12 + -6);
          }
          *(bool *)lVar8 = *(short *)(puVar12 + -1) == 1;
          *(undefined4 *)(lVar8 + 1) = uVar11;
          *(undefined1 **)(lVar8 + 5) = local_48;
          *(undefined4 *)(lVar8 + 0xd) = local_40;
          lVar8 = lVar8 + 0x11;
          puVar12 = puVar12 + 4;
          lVar10 = lVar10 + -1;
        } while (lVar10 != 0);
        goto LAB_1400230d9;
      }
    }
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar9,lVar10);
  }
  else {
    local_48 = &MASTERS;
    uVar3 = (uint)local_40 >> 8;
    local_40 = CONCAT31((int3)uVar3,bVar5);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_48,
               &anon_d5c34e88a06ee720b116585eb143da4b_147_llvm_14435704873730135342,
               &anon_d5c34e88a06ee720b116585eb143da4b_369_llvm_14435704873730135342);
  }
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

