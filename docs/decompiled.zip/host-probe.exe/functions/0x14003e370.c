// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,alloc[246c2e7857c81348]::string::String)>as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
// address: 0x14003e370
// body: available
// range: 0x14003e370-0x14003e3cb inclusive
// range: 0x14003e3d0-0x14003e3ef inclusive
// range: 0x14003e3f2-0x14003e41c inclusive
// range: 0x14003e420-0x14003e441 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14003e3eb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14003e43d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,
   alloc[246c2e7857c81348]::string::String)> as core[505b25137b8ba7f]::ops::drop::Drop>::drop */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(std[3bf9d48a0c3997f0]::time::Instant,alloc[246c2e7857c81348]::string::String)>as_core[505b25137b8ba7f]::ops::drop::Drop>
::drop(ulonglong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  longlong lVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  
  uVar1 = param_1[3];
  if (uVar1 != 0) {
    uVar2 = param_1[2];
    uVar3 = *param_1;
    uVar4 = uVar3;
    if (uVar2 < uVar3) {
      uVar4 = 0;
    }
    lVar7 = uVar2 - uVar4;
    uVar8 = uVar3 - lVar7;
    uVar6 = uVar1 - uVar8;
    if (uVar1 < uVar8) {
      uVar6 = 0;
    }
    uVar9 = lVar7 + uVar1;
    if (uVar1 >= uVar8 && uVar1 - uVar8 != 0) {
      uVar9 = uVar3;
    }
    lVar7 = uVar9 - lVar7;
    if (lVar7 != 0) {
      puVar5 = (undefined8 *)(uVar2 * 0x28 + uVar4 * -0x28 + param_1[1] + 0x18);
      do {
        if (puVar5[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar5,puVar5[-1],1);
          return;
        }
        puVar5 = puVar5 + 5;
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
    }
    if (uVar8 < uVar1) {
      puVar5 = (undefined8 *)(param_1[1] + 0x18);
      do {
        if (puVar5[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar5,puVar5[-1],1);
          return;
        }
        puVar5 = puVar5 + 5;
        uVar6 = uVar6 - 1;
      } while (uVar6 != 0);
    }
  }
  return;
}

