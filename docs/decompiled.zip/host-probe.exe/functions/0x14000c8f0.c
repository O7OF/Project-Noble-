// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::introduce_direct::{closure#2}
// address: 0x14000c8f0
// body: available
// range: 0x14000c8f0-0x14000c9ba inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::introduce_direct::{closure#2} */

void __rustcall
host_probe[b94139f9089eb1d8]::net::introduce_direct::_closure_2_
          (undefined4 *param_1,ulonglong param_2)

{
  code *pcVar1;
  char cVar2;
  undefined1 local_49;
  ulonglong local_48;
  undefined8 local_40;
  undefined8 uStack_38;
  undefined8 local_30;
  undefined8 *local_28;
  undefined **local_20;
  undefined8 local_18;
  
  local_40 = 0;
  uStack_38 = 1;
  local_30 = 0;
  local_18 = 0x60000020;
  local_28 = &local_40;
  local_20 = &PTR_<alloc[246c2e7857c81348]::string::String>_1406a3830;
  local_48 = param_2;
  cVar2 = <core[505b25137b8ba7f]::io::error::Error_as_core[505b25137b8ba7f]::fmt::Display>::fmt
                    (&local_48,&local_28);
  if (cVar2 == '\0') {
    *(undefined8 *)(param_1 + 4) = local_30;
    *param_1 = (undefined4)local_40;
    param_1[1] = local_40._4_4_;
    param_1[2] = (undefined4)uStack_38;
    param_1[3] = uStack_38._4_4_;
    if ((1 < ((uint)param_2 & 3) - 2) && ((param_2 & 3) != 0)) {
      local_20 = (undefined **)(param_2 - 1);
      local_28 = (undefined8 *)CONCAT71(local_28._1_7_,3);
      <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
      drop(&local_20);
    }
    return;
  }
  core[505b25137b8ba7f]::result::unwrap_failed
            ("a Display implementation returned an error unexpectedly",0x37,&local_49,&DAT_1406a1170
             ,&PTR_s__rustc_b940084d7eb6a299eb4bfeb8e_1406a38e8);
                    /* WARNING: Does not return */
  pcVar1 = (code *)invalidInstructionException();
  (*pcVar1)();
}

