// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::server_admin::Engine>
// address: 0x140004820
// body: available
// range: 0x140004820-0x140004933 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140004858 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004876 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000488d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400048ab to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400048cc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400048e4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000490e to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::server_admin::Engine> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::server_admin::Engine>
          (longlong *param_1)

{
  longlong lVar1;
  code *pcVar2;
  
  if (1 < (int)param_1[0x1a] - 2U) {
    if ((int)param_1[0x1a] != 0) {
      panicking::panic_fmt
                ("internal error: entered unreachable code: invalid Once state/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library\\std\\src\\sys\\sync\\once\\futex.rs"
                 ,0x79,&DAT_1406a1228);
                    /* WARNING: Does not return */
      pcVar2 = (code *)invalidInstructionException();
      (*pcVar2)();
    }
    if (param_1[0x16] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x17],param_1[0x16],1);
      return;
    }
  }
  lVar1 = param_1[8];
  if ((lVar1 != -1) && (lVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[9],lVar1,1);
    return;
  }
  if (*param_1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],*param_1,1);
    return;
  }
  lVar1 = param_1[0xb];
  if ((lVar1 != -1) && (lVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0xc],lVar1,1);
    return;
  }
  lVar1 = param_1[0xf];
  if ((lVar1 != -1) && (lVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x10],lVar1,1);
    return;
  }
  if (param_1[4] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[5],param_1[4],1);
    return;
  }
  lVar1 = param_1[0x13];
  if ((lVar1 != -1) && (lVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x14],lVar1,1);
    return;
  }
  return;
}

