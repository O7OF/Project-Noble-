// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::start
// address: 0x14001e4e0
// body: available
// range: 0x14001e4e0-0x14001e543 inclusive
// range: 0x14001e550-0x14001e652 inclusive
// range: 0x14001e660-0x14001e681 inclusive
// range: 0x14001e684-0x14001e7e3 inclusive
// range: 0x14001e7e6-0x14001e84d inclusive
// range: 0x14001e850-0x14001e9f6 inclusive
// range: 0x14001ea00-0x14001eff9 inclusive
// range: 0x14001f000-0x14001f48a inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14001e67d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001e7df to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14001f0ad to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Function: ___chkstk_ms replaced with injection: alloca_probe */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::start */

void __rustcall host_probe[b94139f9089eb1d8]::ingame_chat::start(longlong param_1,ulonglong param_2)

{
  code *pcVar1;
  longlong lVar2;
  ulonglong uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined8 uVar8;
  byte bVar9;
  char cVar10;
  longlong lVar11;
  longlong *plVar12;
  ulonglong uVar13;
  longlong lVar14;
  longlong lVar15;
  byte bVar16;
  ulonglong uVar17;
  DWORD DVar18;
  ulonglong uVar19;
  undefined1 *puVar20;
  longlong lVar21;
  undefined8 *puVar22;
  undefined1 *puVar23;
  ulonglong uVar24;
  bool bVar25;
  bool bVar26;
  int iVar27;
  uint uVar28;
  uint uVar29;
  uint uVar30;
  uint uVar31;
  byte local_13ec;
  undefined8 local_13e0;
  undefined1 *local_13d8;
  undefined8 local_13d0;
  undefined8 local_13c0;
  undefined1 local_13a0 [24];
  undefined1 local_1388 [24];
  undefined1 local_1370 [24];
  undefined8 local_1358;
  undefined8 uStack_1350;
  undefined8 local_1348;
  undefined8 uStack_1340;
  undefined8 local_1338;
  undefined8 uStack_1330;
  undefined8 local_1328;
  undefined8 uStack_1320;
  undefined8 local_1318;
  undefined8 uStack_1310;
  undefined8 local_1308;
  undefined8 uStack_1300;
  undefined8 local_12f8;
  undefined8 uStack_12f0;
  undefined1 local_12e8 [16];
  undefined *local_12d8;
  undefined8 uStack_12d0;
  undefined8 local_12c8;
  undefined8 uStack_12c0;
  longlong local_12b8;
  longlong lStack_12b0;
  undefined1 *local_12a8;
  uint local_12a0;
  uint uStack_129c;
  uint uStack_1298;
  uint uStack_1294;
  undefined8 local_1290;
  char local_10b8;
  longlong local_ef0;
  longlong local_ee8;
  undefined8 local_eb8;
  undefined8 local_eb0;
  undefined1 local_ea8 [16];
  undefined8 local_e98;
  undefined8 local_e90;
  undefined4 local_e80;
  undefined4 local_e70;
  undefined4 local_e60;
  undefined8 local_e58;
  undefined8 uStack_e50;
  undefined8 local_e48;
  undefined2 local_e40;
  undefined1 local_e3e;
  undefined *local_e38;
  undefined8 uStack_e30;
  undefined8 local_e28;
  undefined8 uStack_e20;
  longlong local_e18;
  longlong lStack_e10;
  undefined1 local_e08 [16];
  undefined1 local_df8 [16];
  undefined1 local_de8 [24];
  undefined8 local_dd0;
  undefined8 uStack_dc8;
  undefined8 local_dc0;
  undefined8 uStack_db8;
  undefined8 local_db0;
  undefined8 uStack_da8;
  undefined8 local_da0;
  undefined8 uStack_d98;
  undefined8 local_d78;
  undefined8 uStack_d70;
  undefined8 local_d68;
  undefined8 uStack_d60;
  undefined8 local_d40;
  undefined8 uStack_d38;
  undefined8 local_d30;
  undefined1 local_d28 [312];
  undefined8 local_bf0;
  undefined8 uStack_be8;
  undefined4 local_be0;
  undefined4 uStack_bdc;
  undefined4 uStack_bd8;
  undefined4 uStack_bd4;
  undefined8 local_bd0;
  undefined8 local_bc8;
  undefined1 local_bc0 [16];
  undefined8 local_bb0;
  undefined8 local_ba8;
  undefined1 local_ba0 [16];
  undefined8 local_b90;
  undefined8 local_b88;
  undefined1 local_b80 [16];
  undefined8 local_b70;
  undefined8 local_b68;
  undefined8 local_b60;
  undefined4 local_aa8;
  undefined4 local_a98;
  undefined *local_a90;
  undefined8 uStack_a88;
  undefined8 local_a80;
  undefined8 uStack_a78;
  longlong local_a70;
  longlong lStack_a68;
  undefined *local_a60;
  undefined8 uStack_a58;
  undefined8 local_a50;
  undefined8 uStack_a48;
  undefined4 local_a40;
  undefined4 uStack_a3c;
  undefined4 uStack_a38;
  undefined4 uStack_a34;
  longlong local_a30;
  longlong local_a28;
  undefined1 local_a20 [16];
  undefined8 local_a10;
  undefined8 local_a08;
  undefined4 local_a00;
  undefined1 local_9fc;
  undefined1 local_9fb;
  undefined1 *local_9f0;
  undefined1 local_9e8 [1208];
  undefined1 local_530 [1256];
  undefined8 uStack_48;
  
  uStack_48 = 0x14001e4f6;
  lVar2 = param_2 * 0x18;
  if (param_2 != 0) {
    lVar21 = 0;
    do {
      if ((*(longlong *)(param_1 + 0x10 + lVar21) == 0xd) &&
         (plVar12 = *(longlong **)(param_1 + 8 + lVar21),
         *(longlong *)((longlong)plVar12 + 5) == 0x746168632d656d61 &&
         *plVar12 == 0x656d61676e692d2d)) {
        if (DAT_14069ad70 != 0) {
          <std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::string::String>>>
          ::initialize::
          <<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::string::String>>>::get_or_init<host_probe[b94139f9089eb1d8]::host::menu_scene::_closure_0_>::_closure_0_,_>
                    (&host::menu_scene::MENU_SCENE);
        }
        bVar25 = host::menu_scene::MENU_SCENE == -1;
        goto LAB_14001e595;
      }
      lVar21 = lVar21 + 0x18;
    } while (lVar2 != lVar21);
  }
  bVar25 = false;
LAB_14001e595:
  LOCK();
  bVar26 = DAT_140699000 == '\0';
  if (bVar26) {
    DAT_140699000 = '\x01';
  }
  UNLOCK();
  ENABLED_0_llvm_14435704873730135342 = bVar25;
  if (!bVar26) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699000);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar9 = 0;
    uVar3 = DAT_140699020;
  }
  else {
    bVar9 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar9 = bVar9 ^ 1;
    uVar3 = DAT_140699020;
  }
  DAT_140699020 = uVar3;
  if (DAT_140699001 != '\0') {
    local_12a8 = &DAT_140699000;
    local_12a0._1_3_ = (undefined3)(local_12a0 >> 8);
    local_12a0 = CONCAT31(local_12a0._1_3_,bVar9);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_12a8,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a10d0
               ,&DAT_1406a1ab8);
    goto LAB_14001f489;
  }
  if (uVar3 != 0) {
    uVar13 = DAT_140699008;
    if (DAT_140699018 < DAT_140699008) {
      uVar13 = 0;
    }
    lVar21 = DAT_140699018 - uVar13;
    uVar19 = DAT_140699008 - lVar21;
    uVar24 = uVar3 - uVar19;
    if (uVar3 < uVar19) {
      uVar24 = 0;
    }
    uVar17 = lVar21 + uVar3;
    if (uVar3 >= uVar19 && uVar3 - uVar19 != 0) {
      uVar17 = DAT_140699008;
    }
    DAT_140699020 = 0;
    lVar21 = uVar17 - lVar21;
    if (lVar21 != 0) {
      puVar22 = (undefined8 *)(DAT_140699010 + DAT_140699018 * 0x20 + uVar13 * -0x20 + 0x10);
      do {
        if (puVar22[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar22,puVar22[-1],1);
          return;
        }
        puVar22 = puVar22 + 4;
        lVar21 = lVar21 + -1;
      } while (lVar21 != 0);
    }
    if (uVar19 < uVar3) {
      puVar22 = (undefined8 *)(DAT_140699010 + 0x10);
      do {
        if (puVar22[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar22,puVar22[-1],1);
          return;
        }
        puVar22 = puVar22 + 4;
        uVar24 = uVar24 - 1;
      } while (uVar24 != 0);
    }
  }
  DAT_140699018 = 0;
  if (((bVar9 == 0) &&
      ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
       0x7fffffffffffffff) != 0)) &&
     (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar10 == '\0'))
  {
    DAT_140699001 = '\x01';
  }
  cVar10 = DAT_140699000;
  LOCK();
  DAT_140699000 = '\0';
  UNLOCK();
  if (cVar10 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699000);
    LOCK();
    bVar26 = STATE == '\0';
    if (bVar26) {
      STATE = '\x01';
    }
    UNLOCK();
    if (!bVar26) goto LAB_14001f23c;
LAB_14001e6d3:
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) goto LAB_14001e6e6;
LAB_14001f25b:
    local_13ec = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    local_13ec = local_13ec ^ 1;
    puVar20 = DAT_140699030;
  }
  else {
    LOCK();
    bVar26 = STATE == '\0';
    if (bVar26) {
      STATE = '\x01';
    }
    UNLOCK();
    if (bVar26) goto LAB_14001e6d3;
LAB_14001f23c:
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&STATE);
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0) goto LAB_14001f25b;
LAB_14001e6e6:
    local_13ec = 0;
    puVar20 = DAT_140699030;
  }
  if (DAT_140699029 != '\0') {
    local_12a8 = &STATE;
    local_12a0._1_3_ = (undefined3)(local_12a0 >> 8);
    local_12a0 = CONCAT31(local_12a0._1_3_,local_13ec);
    DAT_140699030 = puVar20;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_12a8,
               &anon_d5c34e88a06ee720b116585eb143da4b_137_llvm_14435704873730135342,&DAT_1406a1ad0);
    goto LAB_14001f489;
  }
  lVar21 = DAT_1406998e0;
  if (DAT_140699990 != 0) {
    lVar21 = 0;
  }
  lVar15 = lVar21;
  if (net::IS_HOST_0_llvm_14435704873730135342 == '\0') {
    lVar15 = net::HOST_ID_0_llvm_14435704873730135342;
  }
  if (net::HOST_ID_0_llvm_14435704873730135342 == 0) {
    lVar15 = lVar21;
  }
  DAT_140699030 = (undefined1 *)0xffffffffffffffff;
  if (puVar20 == (undefined1 *)0xffffffffffffffff) {
LAB_14001e7f3:
    local_9f0 = (undefined1 *)0xffffffffffffffff;
    puVar20 = (undefined1 *)0xffffffffffffffff;
    if (bVar25 == false) {
      bVar16 = 0;
      bVar9 = 0;
      puVar23 = (undefined1 *)0xffffffffffffffff;
      goto joined_r0x00014001e98c;
    }
  }
  else {
    local_12a8 = puVar20;
    memcpy(&local_12a0,&DAT_140699038,0x4b8);
    if (((bVar25 == false) || (local_ef0 != lVar21)) || (local_ee8 != lVar15)) {
      core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::ingame_chat::Runtime>();
      goto LAB_14001e7f3;
    }
    local_9f0 = puVar20;
    memcpy(local_9e8,&DAT_140699038,0x4b8);
  }
  uVar28 = 0x54;
  uVar30 = 0;
  uVar29 = 0x59;
  uVar31 = 0;
  local_13d0 = 0xbf;
  if (param_2 != 0) {
    lVar14 = 0;
    lVar11 = 0;
    do {
      if ((*(longlong *)(param_1 + 0x10 + lVar11) == 0xb) &&
         (plVar12 = *(longlong **)(param_1 + 8 + lVar11),
         *(longlong *)((longlong)plVar12 + 3) == 0x7379656b2d746168 &&
         *plVar12 == 0x6b2d746168632d2d)) {
        if (lVar14 + 1U < param_2) {
          parse_keys(&local_12a8,*(undefined8 *)(param_1 + 0x20 + lVar11),
                     *(undefined8 *)(param_1 + 0x28 + lVar11));
          iVar27 = (int)local_12a8;
          uVar28 = (iVar27 << 0x1f) >> 0x1f;
          uVar29 = (iVar27 << 0x1f) >> 0x1f;
          uVar30 = uStack_129c & (iVar27 << 0x1f) >> 0x1f;
          uVar31 = uStack_1294 & (iVar27 << 0x1f) >> 0x1f;
          local_13d0 = 0xbf;
          if (local_12a8 != (undefined1 *)0x0) {
            local_13d0 = local_1290;
          }
          uVar28 = local_12a0 & uVar28 | ~uVar28 & 0x54;
          uVar29 = uStack_1298 & uVar29 | ~uVar29 & 0x59;
        }
        break;
      }
      lVar14 = lVar14 + 1;
      lVar11 = lVar11 + 0x18;
    } while (lVar2 != lVar11);
  }
  LOCK();
  bVar25 = LIVE_KEYS == '\0';
  if (bVar25) {
    LIVE_KEYS = '\x01';
  }
  UNLOCK();
  if (!bVar25) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LIVE_KEYS);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar9 = 0;
    uVar4 = (uint)DAT_1407f0048;
    uVar5 = DAT_1407f0048._4_4_;
    uVar6 = (uint)DAT_1407f0050;
    uVar7 = DAT_1407f0050._4_4_;
    uVar8 = DAT_1407f0058;
  }
  else {
    bVar9 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar9 = bVar9 ^ 1;
    uVar4 = (uint)DAT_1407f0048;
    uVar5 = DAT_1407f0048._4_4_;
    uVar6 = (uint)DAT_1407f0050;
    uVar7 = DAT_1407f0050._4_4_;
    uVar8 = DAT_1407f0058;
  }
  DAT_1407f0048._0_4_ = uVar4;
  DAT_1407f0048._4_4_ = uVar5;
  DAT_1407f0050._0_4_ = uVar6;
  DAT_1407f0050._4_4_ = uVar7;
  DAT_1407f0058 = uVar8;
  if (DAT_1407f0039 != '\0') {
    local_12a8 = &LIVE_KEYS;
    local_12a0._1_3_ = (undefined3)(local_12a0 >> 8);
    local_12a0 = CONCAT31(local_12a0._1_3_,bVar9);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&local_12a8,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0dd0
               ,&DAT_1406a1ae8);
    goto LAB_14001f489;
  }
  if (DAT_1407f0040 == 1) {
    if (((bVar9 == 0) &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar10 == '\0')
       ) {
      DAT_1407f0039 = '\x01';
    }
    cVar10 = LIVE_KEYS;
    LOCK();
    LIVE_KEYS = '\0';
    UNLOCK();
    uVar28 = uVar4;
    uVar30 = uVar5;
    uVar29 = uVar6;
    uVar31 = uVar7;
    local_13d0 = uVar8;
    if (cVar10 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake();
    }
  }
  else {
    if (((bVar9 == 0) &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar10 == '\0')
       ) {
      DAT_1407f0039 = '\x01';
    }
    cVar10 = LIVE_KEYS;
    LOCK();
    LIVE_KEYS = '\0';
    UNLOCK();
    if (cVar10 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake();
    }
  }
  local_13c0 = 1;
  if (param_2 == 0) {
LAB_14001ea85:
    local_13d8 = (undefined1 *)0x0;
    local_13e0 = 0;
    if (puVar20 == (undefined1 *)0xffffffffffffffff) goto LAB_14001eae0;
LAB_14001ea9d:
    local_12a8 = puVar20;
    memcpy(&local_12a0,local_9e8,0x4b8);
  }
  else {
    local_13d8 = (undefined1 *)0x0;
    lVar11 = 0;
    lVar14 = 0;
    do {
      if ((*(longlong *)(param_1 + 0x10 + lVar11) == 0xb) &&
         (plVar12 = *(longlong **)(param_1 + 8 + lVar11),
         *(longlong *)((longlong)plVar12 + 3) == 0x64746f6d2d746168 &&
         *plVar12 == 0x6d2d746168632d2d)) {
        if ((param_2 <= lVar14 + 1U) ||
           (reach_directory[4b72b9694f6c3c08]::chat::clean
                      (&local_12a8,*(undefined8 *)(param_1 + 0x20 + lVar11),
                       *(undefined8 *)(param_1 + 0x28 + lVar11)),
           local_12a8 == (undefined1 *)0xffffffffffffffff)) goto LAB_14001ea85;
        local_13c0 = CONCAT44(uStack_129c,local_12a0);
        local_13e0 = CONCAT44(uStack_1294,uStack_1298);
        local_13d8 = local_12a8;
        goto joined_r0x00014001ea81;
      }
      lVar14 = lVar14 + 1;
      lVar11 = lVar11 + 0x18;
    } while (lVar2 != lVar11);
    local_13e0 = 0;
joined_r0x00014001ea81:
    if (puVar20 != (undefined1 *)0xffffffffffffffff) goto LAB_14001ea9d;
LAB_14001eae0:
    reach_directory[4b72b9694f6c3c08]::registry::random_hex(local_13a0);
    local_1358 = 0;
    local_1348 = 0;
    uStack_1340 = 0;
    uStack_1350 = 8;
    local_1338 = 0;
    local_1328 = 0;
    uStack_1320 = 0;
    uStack_1330 = 8;
    reach_directory[4b72b9694f6c3c08]::registry::random_hex(local_1388);
    local_1318 = 0;
    local_1308 = 0;
    uStack_1300 = 0;
    uStack_1310 = 8;
    reach_directory[4b72b9694f6c3c08]::registry::random_hex(local_1370);
    <reach_directory[4b72b9694f6c3c08]::chat::HostRelay_as_core[505b25137b8ba7f]::default::Default>
    ::default(&local_12a8);
    if (*(longlong *)
         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
        != 0) {
      std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
    }
    if (*(int *)(
                __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                + 0x18) == 0) {
      DVar18 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                         (
                         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                         );
      plVar12 = TlsGetValue(DVar18);
    }
    else {
      DVar18 = *(int *)(
                       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                       + 0x18) - 1;
      plVar12 = TlsGetValue(DVar18);
    }
    if (plVar12 < (longlong *)0x2) {
      plVar12 = (longlong *)
                <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                ::try_initialize::
                <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                          (DVar18,plVar12,0);
    }
    if (plVar12 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
LAB_14001f489:
                    /* WARNING: Does not return */
      pcVar1 = (code *)invalidInstructionException();
      (*pcVar1)();
    }
    local_12c8 = 0;
    uStack_12c0 = 0;
    local_12d8 = &DAT_1406a0540;
    uStack_12d0 = 0;
    local_12b8 = *plVar12;
    lStack_12b0 = plVar12[1];
    *plVar12 = *plVar12 + 1;
    local_12f8 = 0;
    local_12e8 = (undefined1  [16])0x0;
    uStack_12f0 = 8;
    if (*(longlong *)
         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
        != 0) {
      std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
    }
    if (*(int *)(
                __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                + 0x18) == 0) {
      DVar18 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                         (
                         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                         );
    }
    else {
      DVar18 = *(int *)(
                       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                       + 0x18) - 1;
    }
    plVar12 = TlsGetValue(DVar18);
    if (plVar12 < (longlong *)0x2) {
      plVar12 = (longlong *)
                <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                ::try_initialize::
                <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                          (DVar18,plVar12,0);
    }
    if (plVar12 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
      goto LAB_14001f489;
    }
    local_9fb = 0xff;
    local_d40 = 0;
    uStack_d38 = 8;
    local_d30 = 0;
    local_dd0 = local_1358;
    uStack_dc8 = uStack_1350;
    local_dc0 = local_1348;
    uStack_db8 = uStack_1340;
    local_db0 = local_1338;
    uStack_da8 = uStack_1330;
    local_da0 = local_1328;
    uStack_d98 = uStack_1320;
    local_d78 = local_1318;
    uStack_d70 = uStack_1310;
    local_d68 = local_1308;
    uStack_d60 = uStack_1300;
    local_a30 = lVar21;
    local_a28 = lVar15;
    memcpy(local_d28,&local_12a8,0x138);
    local_a90 = local_12d8;
    uStack_a88 = uStack_12d0;
    local_a80 = local_12c8;
    uStack_a78 = uStack_12c0;
    local_a70 = local_12b8;
    lStack_a68 = lStack_12b0;
    local_a20 = (undefined1  [16])0x0;
    local_a10 = 0;
    local_aa8 = 0xffffffff;
    local_bf0 = local_12f8;
    uStack_be8 = uStack_12f0;
    local_be0 = local_12e8._0_4_;
    uStack_bdc = local_12e8._4_4_;
    uStack_bd8 = local_12e8._8_4_;
    uStack_bd4 = local_12e8._12_4_;
    local_a98 = 0xffffffff;
    local_9fc = 0;
    local_a60 = &DAT_1406a0540;
    uStack_a58 = 0;
    local_a50 = 0;
    uStack_a48 = 0;
    local_a40 = (undefined4)*plVar12;
    uStack_a3c = *(undefined4 *)((longlong)plVar12 + 4);
    uStack_a38 = (undefined4)plVar12[1];
    uStack_a34 = *(undefined4 *)((longlong)plVar12 + 0xc);
    *plVar12 = *plVar12 + 1;
    local_a08 = 0;
    local_a00 = 0;
    local_b60 = 0xffffffffffffffff;
    local_bd0 = 0;
    local_bc8 = 8;
    local_bc0 = (undefined1  [16])0x0;
    local_bb0 = 0;
    local_ba8 = 8;
    local_ba0 = (undefined1  [16])0x0;
    local_b90 = 0;
    local_b88 = 1;
    local_b80 = (undefined1  [16])0x0;
    local_b70 = 1;
    local_b68 = 0;
    if (*(longlong *)
         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
        != 0) {
      std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
    }
    if (*(int *)(
                __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                + 0x18) == 0) {
      DVar18 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                         (
                         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                         );
    }
    else {
      DVar18 = *(int *)(
                       __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                       + 0x18) - 1;
    }
    plVar12 = TlsGetValue(DVar18);
    if (plVar12 < (longlong *)0x2) {
      plVar12 = (longlong *)
                <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                ::try_initialize::
                <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                          (DVar18,plVar12,0);
    }
    if (plVar12 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
      goto LAB_14001f489;
    }
    local_e3e = 0;
    local_e40 = 0;
    memcpy(&local_12a8,local_de8,0x3f0);
    local_eb8 = 0;
    local_eb0 = 1;
    local_ea8 = (undefined1  [16])0x0;
    local_e08 = (undefined1  [16])0x0;
    local_df8 = (undefined1  [16])0x0;
    local_e80 = 0xffffffff;
    local_e70 = 0xffffffff;
    local_e60 = 0xffffffff;
    local_e98 = 1;
    local_e90 = 0;
    local_e38 = &DAT_1406a0540;
    uStack_e30 = 0;
    local_e28 = 0;
    uStack_e20 = 0;
    local_e18 = *plVar12;
    lStack_e10 = plVar12[1];
    *plVar12 = *plVar12 + 1;
    local_e58 = 0x54;
    uStack_e50 = 0x59;
    local_e48 = 0xbf;
  }
  if (param_2 != 0) {
    lVar15 = 0;
    lVar21 = 0;
    do {
      if ((*(longlong *)(param_1 + 0x10 + lVar21) == 0xb) &&
         (plVar12 = *(longlong **)(param_1 + 8 + lVar21),
         *(longlong *)((longlong)plVar12 + 3) == 0x65646f6d2d746168 &&
         *plVar12 == 0x6d2d746168632d2d)) {
        if (lVar15 + 1U < param_2) {
          local_10b8 = <reach_directory[4b72b9694f6c3c08]::chat::ChatMode>::parse
                                 (*(undefined8 *)(param_1 + 0x20 + lVar21),
                                  *(undefined8 *)(param_1 + 0x28 + lVar21));
          if (local_10b8 == -1) {
            local_10b8 = '\0';
          }
          goto LAB_14001f05c;
        }
        break;
      }
      lVar15 = lVar15 + 1;
      lVar21 = lVar21 + 0x18;
    } while (lVar2 != lVar21);
  }
  local_10b8 = '\0';
LAB_14001f05c:
  puVar23 = local_12a8;
  local_e58 = CONCAT44(uVar30,uVar28);
  uStack_e50 = CONCAT44(uVar31,uVar29);
  local_e48 = local_13d0;
  local_e40 = 0;
  local_e3e = 0;
  if (local_ea8._8_8_ != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_e98,local_ea8._8_8_,1);
    return;
  }
  local_ea8._8_8_ = local_13d8;
  local_e98 = local_13c0;
  local_e90 = local_13e0;
  memcpy(local_530,&local_12a0,0x4b8);
  bVar16 = 1;
  bVar9 = 1;
joined_r0x00014001e98c:
  if (DAT_140699030 != (undefined1 *)0xffffffffffffffff) {
    core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::ingame_chat::Runtime>
              (&DAT_140699030);
    bVar9 = bVar16;
  }
  DAT_140699030 = puVar23;
  memcpy(&DAT_140699038,local_530,0x4b8);
  if ((bool)(~bVar9 & puVar20 != (undefined1 *)0xffffffffffffffff)) {
    core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::ingame_chat::Runtime>
              (&local_9f0);
  }
  if (((local_13ec == 0) &&
      ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
       0x7fffffffffffffff) != 0)) &&
     (cVar10 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar10 == '\0'))
  {
    DAT_140699029 = '\x01';
  }
  cVar10 = STATE;
  LOCK();
  STATE = 0;
  UNLOCK();
  if (cVar10 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&STATE);
  }
  return;
}

