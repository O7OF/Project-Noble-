// rea decompile_all
// name: std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::host::armory::frame::{closure#0},()>
// address: 0x1400079e0
// body: available
// range: 0x1400079e0-0x140007adc inclusive
// range: 0x140007ae0-0x140007b41 inclusive
// range: 0x140007b44-0x140007c6c inclusive
// range: 0x140007c70-0x140007cd1 inclusive
// range: 0x140007cd4-0x140007d04 inclusive
// range: 0x140007d0a-0x140007eff inclusive
// range: 0x140007f02-0x140007fbe inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140007b3d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007bf2 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007ccd to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007d00 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007d2d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007dab to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007e2d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007e9d to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140007efb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain e
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::<host_probe[b94139f9089eb1d8]::host::armory::frame::{closure#0},
   ()> */

void __rustcall
std[3bf9d48a0c3997f0]::sys::backtrace::__rust_begin_short_backtrace::
<host_probe[b94139f9089eb1d8]::host::armory::frame::_closure_0_,()>(void)

{
  undefined1 auVar1 [16];
  longlong lVar2;
  code *pcVar3;
  uint uVar4;
  ulonglong uVar5;
  undefined *puVar6;
  undefined8 uVar7;
  byte bVar8;
  char cVar9;
  int iVar10;
  undefined1 (*pauVar11) [16];
  longlong lVar12;
  undefined1 (*pauVar13) [16];
  ushort uVar14;
  uint uVar15;
  bool bVar16;
  undefined1 (*local_f8) [16];
  code *pcStack_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  longlong local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  int local_ac;
  undefined1 (*local_a8) [16];
  longlong lStack_a0;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  longlong *local_78;
  longlong lStack_70;
  undefined8 local_68;
  undefined8 *local_60;
  code *local_58;
  int local_50 [2];
  longlong *local_48;
  longlong lStack_40;
  
  host_probe[b94139f9089eb1d8]::host::armory::load_string_ids(&local_f8);
  if (local_f8 == (undefined1 (*) [16])0x0) {
    host_probe[b94139f9089eb1d8]::host::log
              ("armory: no mainmenu_<scene>.string_ids.csv next to the menu maps; armor picks not applied"
               ,0x59);
  }
  else {
    local_88 = (undefined4)local_d8;
    uStack_84 = local_d8._4_4_;
    uStack_80 = (undefined4)uStack_d0;
    uStack_7c = uStack_d0._4_4_;
    local_98 = (undefined4)local_e8;
    uStack_94 = local_e8._4_4_;
    uStack_90 = (undefined4)uStack_e0;
    uStack_8c = uStack_e0._4_4_;
    local_a8 = local_f8;
    lStack_a0 = (longlong)pcStack_f0;
    host_probe[b94139f9089eb1d8]::host::log(&DAT_1406a0a45,0x26);
    iVar10 = 0;
    do {
      local_ac = iVar10;
      std[3bf9d48a0c3997f0]::thread::functions::sleep(1,0);
      host_probe[b94139f9089eb1d8]::host::armory::scan(local_50);
      if (local_50[0] == 1) {
        local_e8 = &lStack_70;
        local_78 = local_48;
        lStack_70 = lStack_40;
        local_f8 = (undefined1 (*) [16])&local_78;
        pcStack_f0 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
        uStack_e0 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        local_d8 = &local_ac;
        uStack_d0 = <i32_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_c8,&DAT_1406a0aa4,&local_f8);
        uVar7 = uStack_c0;
        lVar12 = local_c8;
        host_probe[b94139f9089eb1d8]::host::log(uStack_c0,local_b8);
        if (lVar12 != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar7,lVar12,1);
          return;
        }
        local_d8 = (int *)CONCAT44(uStack_84,local_88);
        uStack_d0 = (code *)CONCAT44(uStack_7c,uStack_80);
        local_e8 = (longlong *)CONCAT44(uStack_94,local_98);
        uStack_e0 = (code *)CONCAT44(uStack_8c,uStack_90);
        local_f8 = local_a8;
        pcStack_f0 = (code *)lStack_a0;
        if (DAT_14069bb98 != 0) {
          <std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<alloc[246c2e7857c81348]::string::String,u32>>>
          ::initialize::
          <<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<alloc[246c2e7857c81348]::string::String,u32>>>::get_or_init<<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<alloc[246c2e7857c81348]::string::String,u32>>>::try_insert::_closure_0_>::_closure_0_,_>
                    (&host_probe[b94139f9089eb1d8]::host::armory::STRING_IDS,&local_f8);
        }
        if ((local_f8 != (undefined1 (*) [16])0x0) && (pcStack_f0 != (code *)0x0)) {
          if (uStack_e0 != (code *)0x0) {
            auVar1 = *local_f8;
            pauVar13 = local_f8 + 1;
            uVar15 = ~(uint)(ushort)((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                                     (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                                     (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                                     (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                                     (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                                     (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                                     (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                                     (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                                     (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                                     (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                                     (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                                     (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                                     (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                                     (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                                     (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                                    (ushort)(byte)(auVar1[0xf] >> 7) << 0xf);
            lVar12 = (longlong)uStack_e0;
            pauVar11 = local_f8;
            do {
              uVar14 = (ushort)uVar15;
              while (uVar14 == 0) {
                auVar1 = *pauVar13;
                pauVar11 = pauVar11 + -0x20;
                pauVar13 = pauVar13 + 1;
                uVar14 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                          (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                          (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                          (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                          (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                          (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                          (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                          (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                          (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                          (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                          (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                          (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                          (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                          (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                          (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                         (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
                uVar15 = (uint)uVar14;
              }
              iVar10 = 0;
              for (uVar4 = uVar15; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
                iVar10 = iVar10 + 1;
              }
              lVar2 = *(longlong *)((longlong)pauVar11 + (-0x20 - (ulonglong)(uint)(iVar10 << 5)));
              if (lVar2 != 0) {
                __rustc[9d087a5ab36ea756]::__rust_dealloc
                          (*(undefined8 *)
                            ((longlong)pauVar11 + (-0x18 - (ulonglong)(uint)(iVar10 << 5))),lVar2,1)
                ;
                return;
              }
              lVar12 = lVar12 + -1;
              uVar15 = uVar15 - 1 & uVar15;
            } while (lVar12 != 0);
          }
          lVar12 = (longlong)pcStack_f0 * 0x21 + 0x31;
          if (lVar12 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      (local_f8 + (longlong)pcStack_f0 * -2 + -2,lVar12,0x10);
            return;
          }
        }
        pcStack_f0 = (code *)local_78;
        local_e8 = (longlong *)lStack_70;
        local_f8 = (undefined1 (*) [16])0x1;
        if (DAT_14069bbb0 != 0) {
          <std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<(usize,usize)>>::initialize::
          <<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<(usize,usize)>>::get_or_init<<std[3bf9d48a0c3997f0]::sync::once_lock::OnceLock<(usize,usize)>>::try_insert::_closure_0_>::_closure_0_,_>
                    (&host_probe[b94139f9089eb1d8]::host::armory::GLOBALS,&local_f8);
        }
        host_probe[b94139f9089eb1d8]::host::armory::scene(&local_f8);
        if (local_f8 != (undefined1 (*) [16])0xffffffffffffffff) {
          if ((local_e8 == (longlong *)0xc) &&
             ((int)*(longlong *)((longlong)pcStack_f0 + 8) == 0x6574696c &&
              *(longlong *)pcStack_f0 == 0x655f79726f6d7261)) {
            if (local_f8 == (undefined1 (*) [16])0x0) {
              return;
            }
            __rustc[9d087a5ab36ea756]::__rust_dealloc(pcStack_f0,local_f8,1);
            return;
          }
          if (local_f8 != (undefined1 (*) [16])0x0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(pcStack_f0,local_f8,1);
            return;
          }
        }
        host_probe[b94139f9089eb1d8]::host::armory::find_all(&local_c8,&DAT_1406a0ae0,4);
        local_68 = local_b8;
        local_60 = &local_68;
        local_58 = <u64_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
        alloc[246c2e7857c81348]::fmt::format::format_inner(&local_f8,&DAT_1406a0af0,&local_60);
        pcVar3 = pcStack_f0;
        pauVar13 = local_f8;
        host_probe[b94139f9089eb1d8]::host::log(pcStack_f0,local_e8);
        if (pauVar13 != (undefined1 (*) [16])0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(pcVar3,pauVar13,1);
          return;
        }
        LOCK();
        bVar16 = host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS == '\0';
        if (bVar16) {
          host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS = '\x01';
        }
        UNLOCK();
        if (!bVar16) {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                    (&host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS);
        }
        puVar6 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
        if ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) == 0) {
          bVar8 = 0;
        }
        else {
          bVar8 = panicking::panic_count::is_zero_slow_path();
          bVar8 = bVar8 ^ 1;
        }
        if (DAT_14069bbb9 == '\0') {
          if (DAT_14069bbc0 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc(DAT_14069bbc8,DAT_14069bbc0 << 3,8);
            return;
          }
          DAT_14069bbc0 = local_c8;
          DAT_14069bbc8 = uStack_c0;
          DAT_14069bbd0 = local_b8;
          if (((bVar8 == 0) && ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) != 0)) &&
             (cVar9 = panicking::panic_count::is_zero_slow_path(), cVar9 == '\0')) {
            DAT_14069bbb9 = '\x01';
          }
          cVar9 = host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS;
          LOCK();
          host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS = 0;
          UNLOCK();
          if (cVar9 != '\x02') {
            host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS = 0;
            return;
          }
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake
                    (&host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS);
          return;
        }
        local_f8 = (undefined1 (*) [16])&host_probe[b94139f9089eb1d8]::host::armory::COLOR_RECORDS;
        uVar5 = (ulonglong)pcStack_f0 >> 8;
        pcStack_f0 = (code *)CONCAT71((int7)uVar5,bVar8);
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&local_f8,
                   &
                   PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1090
                   ,&PTR_s_src_armory_rs_1406a0b20);
                    /* WARNING: Does not return */
        pcVar3 = (code *)invalidInstructionException();
        (*pcVar3)();
      }
      iVar10 = iVar10 + 1;
    } while (iVar10 != 0x3c);
    host_probe[b94139f9089eb1d8]::host::log(&DAT_1406a0a6b,0x39);
    if (lStack_a0 != 0) {
      lVar12 = CONCAT44(uStack_8c,uStack_90);
      if (lVar12 != 0) {
        auVar1 = *local_a8;
        pauVar13 = local_a8 + 1;
        uVar15 = ~(uint)(ushort)((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                                 (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                                 (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                                 (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                                 (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                                 (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                                 (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                                 (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                                 (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                                 (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                                 (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                                 (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                                 (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                                 (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                                 (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                                (ushort)(byte)(auVar1[0xf] >> 7) << 0xf);
        pauVar11 = local_a8;
        do {
          uVar14 = (ushort)uVar15;
          while (uVar14 == 0) {
            auVar1 = *pauVar13;
            pauVar11 = pauVar11 + -0x20;
            pauVar13 = pauVar13 + 1;
            uVar14 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                      (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                      (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                      (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                      (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                      (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                      (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                      (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                      (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                      (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                      (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                      (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                      (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                      (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                      (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                     (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
            uVar15 = (uint)uVar14;
          }
          iVar10 = 0;
          for (uVar4 = uVar15; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
            iVar10 = iVar10 + 1;
          }
          lVar2 = *(longlong *)((longlong)pauVar11 + (-0x20 - (ulonglong)(uint)(iVar10 << 5)));
          if (lVar2 != 0) {
            __rustc[9d087a5ab36ea756]::__rust_dealloc
                      (*(undefined8 *)
                        ((longlong)pauVar11 + (-0x18 - (ulonglong)(uint)(iVar10 << 5))),lVar2,1);
            return;
          }
          lVar12 = lVar12 + -1;
          uVar15 = uVar15 - 1 & uVar15;
        } while (lVar12 != 0);
      }
      lVar12 = lStack_a0 * 0x21 + 0x31;
      if (lVar12 != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(local_a8 + lStack_a0 * -2 + -2,lVar12,0x10);
        return;
      }
    }
  }
  return;
}

