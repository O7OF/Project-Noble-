// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>
// address: 0x140045cb0
// body: available
// range: 0x140045cb0-0x140045d25 inclusive
// range: 0x140045d30-0x140045d55 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140045ce6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140045d0b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140045d51 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,
   2usize>>> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>
          (longlong *param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if (*param_1 != 0) {
    lVar4 = param_1[2] - param_1[1];
    if (lVar4 != 0) {
      plVar3 = param_1 + param_1[1] * 3 + 4;
      do {
        lVar2 = plVar3[-1];
        if ((lVar2 != -1) && (lVar2 != 0)) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*plVar3,lVar2,1);
          return;
        }
        plVar3 = plVar3 + 3;
        lVar4 = lVar4 + -1;
      } while (lVar4 != 0);
    }
  }
  uVar1 = param_1[9];
  if ((uVar1 < 0xfffffffffffffffe) && (uVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[10],uVar1,1);
    return;
  }
  uVar1 = param_1[0xc];
  if ((uVar1 < 0xfffffffffffffffe) && (uVar1 != 0)) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0xd],uVar1,1);
    return;
  }
  return;
}

