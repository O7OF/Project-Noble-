// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Probe>>
// address: 0x140003620
// body: available
// range: 0x140003620-0x14000367c inclusive
// range: 0x140003680-0x1400036a5 inclusive
// range: 0x1400036a8-0x140003702 inclusive
// range: 0x140003710-0x14000373a inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400036a1 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400036d1 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140003736 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Probe>>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Probe>>
          (ulonglong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  longlong lVar8;
  ulonglong uVar9;
  undefined8 *puVar10;
  ulonglong uVar11;
  
  uVar1 = *param_1;
  uVar2 = param_1[3];
  if (uVar2 == 0) {
    uVar7 = param_1[1];
  }
  else {
    uVar7 = param_1[1];
    uVar3 = param_1[2];
    uVar5 = uVar1;
    if (uVar3 < uVar1) {
      uVar5 = 0;
    }
    lVar8 = uVar3 - uVar5;
    uVar11 = uVar1 - lVar8;
    uVar6 = uVar2 - uVar11;
    if (uVar2 < uVar11) {
      uVar6 = 0;
    }
    uVar9 = lVar8 + uVar2;
    if (uVar2 >= uVar11 && uVar2 - uVar11 != 0) {
      uVar9 = uVar1;
    }
    lVar8 = uVar9 - lVar8;
    if (lVar8 != 0) {
      puVar10 = (undefined8 *)(uVar7 + uVar3 * 0x30 + uVar5 * -0x30 + 8);
      do {
        lVar4 = puVar10[-1];
        if ((lVar4 != -1) && (lVar4 != 0)) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar10,lVar4,1);
          return;
        }
        puVar10 = puVar10 + 6;
        lVar8 = lVar8 + -1;
      } while (lVar8 != 0);
    }
    if (uVar11 < uVar2) {
      puVar10 = (undefined8 *)(uVar7 + 8);
      do {
        lVar8 = puVar10[-1];
        if ((lVar8 != -1) && (lVar8 != 0)) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar10,lVar8,1);
          return;
        }
        puVar10 = puVar10 + 6;
        uVar6 = uVar6 - 1;
      } while (uVar6 != 0);
    }
  }
  if (uVar1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar7,uVar1 * 0x30,8);
    return;
  }
  return;
}

