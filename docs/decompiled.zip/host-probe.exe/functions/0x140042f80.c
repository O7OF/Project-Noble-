// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u32>>::retain::<host_probe[b94139f9089eb1d8]::armorpack::mark_active::{closure#1}>
// address: 0x140042f80
// body: available
// range: 0x140042f80-0x140043055 inclusive
// range: 0x140043060-0x14004308d inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u32>>::retain::<host_probe[b94139f9089eb1d8]::armorpack::mark_active::{closure#1}>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<u32>>::retain::
<host_probe[b94139f9089eb1d8]::armorpack::mark_active::_closure_1_>(longlong param_1)

{
  int iVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  
  uVar2 = *(ulonglong *)(param_1 + 0x10);
  if (uVar2 != 0) {
    lVar3 = *(longlong *)(param_1 + 8);
    uVar7 = (ulonglong)((uint)uVar2 & 3);
    if (uVar2 < 4) {
      uVar5 = 0;
    }
    else {
      uVar4 = 0;
      do {
        uVar6 = uVar4;
        if (*(int *)(lVar3 + uVar4 * 4) == -1) goto LAB_140043000;
        if (*(int *)(lVar3 + 4 + uVar4 * 4) == -1) {
          uVar6 = uVar4 + 1;
          uVar5 = uVar4 + 2;
          goto LAB_140043023;
        }
        if (*(int *)(lVar3 + 8 + uVar4 * 4) == -1) {
          uVar6 = uVar4 + 2;
          uVar5 = uVar4 + 3;
          goto LAB_140043023;
        }
        uVar5 = uVar4 + 4;
        if (*(int *)(lVar3 + 0xc + uVar4 * 4) == -1) {
          uVar6 = uVar4 | 3;
          goto LAB_140043023;
        }
        uVar4 = uVar5;
      } while ((uVar2 & 0x1ffffffffffffffc) != uVar5);
      if (uVar7 == 0) {
        return;
      }
    }
    do {
      uVar6 = uVar5;
      if (*(int *)(lVar3 + uVar5 * 4) == -1) {
LAB_140043000:
        uVar5 = uVar6 + 1;
LAB_140043023:
        if (uVar5 < uVar2) {
          uVar7 = uVar5 + 1;
          if ((((uint)uVar2 - (int)uVar5 & 1) != 0) &&
             (iVar1 = *(int *)(lVar3 + uVar5 * 4), uVar5 = uVar7, iVar1 != -1)) {
            *(int *)(lVar3 + uVar6 * 4) = iVar1;
            uVar6 = uVar6 + 1;
          }
          while (uVar2 != uVar7) {
            iVar1 = *(int *)(lVar3 + uVar5 * 4);
            if (iVar1 != -1) {
              *(int *)(lVar3 + uVar6 * 4) = iVar1;
              uVar6 = uVar6 + 1;
            }
            iVar1 = *(int *)(lVar3 + 4 + uVar5 * 4);
            if (iVar1 != -1) {
              *(int *)(lVar3 + uVar6 * 4) = iVar1;
              uVar6 = uVar6 + 1;
            }
            uVar7 = uVar5 + 2;
            uVar5 = uVar7;
          }
        }
        *(ulonglong *)(param_1 + 0x10) = uVar6;
        return;
      }
      uVar5 = uVar5 + 1;
      uVar7 = uVar7 - 1;
    } while (uVar7 != 0);
  }
  return;
}

