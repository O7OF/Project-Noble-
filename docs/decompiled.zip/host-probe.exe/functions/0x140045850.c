// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::zip::Zip<core[505b25137b8ba7f]::iter::adapters::zip::Zip<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(usize,alloc[246c2e7857c81348]::string::String)>,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>>,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>>,host_probe[b94139f9089eb1d8]::server_admin::admin_cards::{closure#3}>>
// address: 0x140045850
// body: available
// range: 0x140045850-0x140045872 inclusive
// range: 0x140045880-0x14004589f inclusive
// range: 0x1400458a2-0x1400458e9 inclusive
// range: 0x1400458f0-0x140045927 inclusive
// range: 0x14004592a-0x14004596c inclusive
// range: 0x140045970-0x14004598f inclusive
// range: 0x140045992-0x1400459c4 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14004589b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400458b8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004590c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140045923 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140045945 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004598b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400459b6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::zip::Zip<core[505b25137b8ba7f]::iter::adapters::zip::Zip<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(usize,
   alloc[246c2e7857c81348]::string::String)>,
   alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(alloc[246c2e7857c81348]::string::String,
   alloc[246c2e7857c81348]::string::String)>>,
   alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>>,
   host_probe[b94139f9089eb1d8]::server_admin::admin_cards::{closure#3}>> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::zip::Zip<core[505b25137b8ba7f]::iter::adapters::zip::Zip<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(usize,alloc[246c2e7857c81348]::string::String)>,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>>,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>>,host_probe[b94139f9089eb1d8]::server_admin::admin_cards::_closure_3_>>
          (undefined8 *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  
  uVar2 = param_1[3] - param_1[1];
  if (uVar2 != 0) {
    uVar2 = uVar2 >> 5;
    puVar3 = (undefined8 *)(param_1[1] + 0x10);
    do {
      if (puVar3[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar3,puVar3[-1],1);
        return;
      }
      puVar3 = puVar3 + 4;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
  }
  if (param_1[2] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(*param_1,param_1[2] << 5,8);
    return;
  }
  lVar1 = param_1[5];
  if (param_1[7] != lVar1) {
    uVar2 = (ulonglong)(param_1[7] - lVar1) / 0x30;
    puVar3 = (undefined8 *)(lVar1 + 0x20);
    do {
      if (puVar3[-4] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar3[-3],puVar3[-4],1);
        return;
      }
      if (puVar3[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar3,puVar3[-1],1);
        return;
      }
      puVar3 = puVar3 + 6;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
  }
  if (param_1[6] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[4],param_1[6] * 0x30,8);
    return;
  }
  lVar1 = param_1[0xb];
  if (param_1[0xd] != lVar1) {
    uVar2 = (ulonglong)(param_1[0xd] - lVar1) / 0x18;
    puVar3 = (undefined8 *)(lVar1 + 8);
    do {
      if (puVar3[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar3,puVar3[-1],1);
        return;
      }
      puVar3 = puVar3 + 3;
      uVar2 = uVar2 - 1;
    } while (uVar2 != 0);
  }
  if (param_1[0xc] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[10],param_1[0xc] * 0x18,8);
    return;
  }
  return;
}

