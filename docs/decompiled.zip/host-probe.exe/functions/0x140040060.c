// rea decompile_all
// name: <char_as_core[505b25137b8ba7f]::str::pattern::Pattern>::is_contained_in
// address: 0x140040060
// body: available
// range: 0x140040060-0x1400408e9 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <char as core[505b25137b8ba7f]::str::pattern::Pattern>::is_contained_in */

ulonglong __rustcall
<char_as_core[505b25137b8ba7f]::str::pattern::Pattern>::is_contained_in
          (ulonglong param_1,void *param_2,ulonglong param_3)

{
  char *pcVar1;
  char *pcVar2;
  code *pcVar3;
  ushort uVar4;
  char cVar5;
  char cVar6;
  char cVar7;
  char cVar8;
  char cVar9;
  char cVar10;
  char cVar11;
  char cVar12;
  char cVar13;
  char cVar14;
  char cVar15;
  char cVar16;
  char cVar17;
  char cVar18;
  char cVar19;
  char cVar20;
  char cVar21;
  char cVar22;
  char cVar23;
  char cVar24;
  char cVar25;
  char cVar26;
  char cVar27;
  char cVar28;
  char cVar29;
  char cVar30;
  char cVar31;
  char cVar32;
  char cVar33;
  char cVar34;
  char cVar35;
  char cVar36;
  char cVar37;
  char cVar38;
  char cVar39;
  char cVar40;
  char cVar41;
  char cVar42;
  char cVar43;
  char cVar44;
  char cVar45;
  char cVar46;
  char cVar47;
  char cVar48;
  char cVar49;
  char cVar50;
  char cVar51;
  char cVar52;
  char cVar53;
  char cVar54;
  char cVar55;
  char cVar56;
  char cVar57;
  char cVar58;
  char cVar59;
  char cVar60;
  char cVar61;
  char cVar62;
  char cVar63;
  char cVar64;
  char cVar65;
  char cVar66;
  char cVar67;
  char cVar68;
  char cVar69;
  char cVar70;
  char cVar71;
  char cVar72;
  char cVar73;
  char cVar74;
  char cVar75;
  char cVar76;
  char cVar77;
  char cVar78;
  char cVar79;
  char cVar80;
  char cVar81;
  char cVar82;
  char cVar83;
  char cVar84;
  char cVar85;
  char cVar86;
  char cVar87;
  char cVar88;
  char cVar89;
  char cVar90;
  char cVar91;
  char cVar92;
  char cVar93;
  char cVar94;
  char cVar95;
  char cVar96;
  char cVar97;
  char cVar98;
  char cVar99;
  char cVar100;
  byte bVar101;
  byte bVar102;
  int iVar103;
  uint uVar104;
  ulonglong uVar105;
  undefined4 extraout_var;
  longlong lVar106;
  undefined4 extraout_var_00;
  undefined8 uVar107;
  ulonglong uVar108;
  byte bVar109;
  byte bVar110;
  ulonglong uVar111;
  ulonglong uVar112;
  uint uVar113;
  longlong lVar114;
  byte bVar115;
  longlong lVar116;
  longlong lVar117;
  undefined1 auVar118 [16];
  undefined1 auVar119 [16];
  undefined1 auVar120 [16];
  undefined1 auVar121 [16];
  undefined1 auVar122 [16];
  undefined1 auVar123 [16];
  char cVar124;
  char cVar125;
  char cVar126;
  char cVar127;
  char cVar128;
  char cVar129;
  char cVar130;
  char cVar131;
  char cVar132;
  char cVar133;
  char cVar134;
  char cVar135;
  char cVar136;
  char cVar137;
  char cVar138;
  char cVar139;
  undefined1 auVar140 [16];
  undefined1 auVar141 [16];
  undefined1 auVar142 [16];
  undefined1 auVar143 [16];
  undefined1 auVar144 [16];
  undefined1 auVar145 [16];
  byte abStack_140 [4];
  undefined4 local_13c;
  ulonglong local_138;
  void *local_130;
  ulonglong local_128;
  longlong local_120;
  undefined8 local_118;
  ulonglong local_110;
  longlong local_108;
  ulonglong local_f8;
  longlong local_e8;
  ulonglong local_e0;
  longlong local_d8;
  ulonglong local_d0;
  
  uVar104 = (uint)param_1;
  bVar102 = (byte)param_1;
  if (uVar104 < 0x80) {
    if (param_3 < 0x10) {
      if (param_3 != 0) {
        uVar105 = 0;
        do {
          if (*(byte *)((longlong)param_2 + uVar105) == bVar102) goto LAB_140040197;
          uVar105 = uVar105 + 1;
        } while (param_3 != uVar105);
      }
    }
    else {
      lVar106 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(param_1,param_2,param_3);
      uVar105 = 0;
      if (lVar106 == 1) {
LAB_140040197:
        uVar105 = CONCAT71((int7)(uVar105 >> 8),1);
        goto LAB_140040420;
      }
    }
  }
  else {
    bVar109 = bVar102 & 0x3f | 0x80;
    bVar110 = (byte)(param_1 >> 6);
    if (uVar104 < 0x800) {
      bVar101 = bVar110 | 0xc0;
      local_13c = (ushort)(CONCAT11(bVar102,bVar110) | 0xc0) & 0xffff3fff | 0x8000;
      uVar111 = 2;
      if (param_3 < 3) {
LAB_14004036a:
        if (uVar111 == param_3) {
          iVar103 = memcmp(&local_13c,param_2,param_3);
          uVar105 = CONCAT71((int7)(CONCAT44(extraout_var_00,iVar103) >> 8),iVar103 == 0);
          goto LAB_140040420;
        }
        goto LAB_14004041e;
      }
      lVar106 = 1;
      lVar114 = 1;
      if (0x10 < param_3) {
LAB_140040585:
        auVar118 = pshuflw(ZEXT216(CONCAT11(bVar101,bVar101)),ZEXT216(CONCAT11(bVar101,bVar101)),0);
        cVar124 = auVar118[0];
        cVar125 = auVar118[1];
        cVar126 = auVar118[2];
        cVar127 = auVar118[3];
        cVar128 = auVar118[4];
        cVar129 = auVar118[5];
        cVar130 = auVar118[6];
        cVar131 = auVar118[7];
        auVar118 = pshuflw(ZEXT216(CONCAT11(bVar109,bVar109)),ZEXT216(CONCAT11(bVar109,bVar109)),0);
        cVar132 = auVar118[0];
        cVar133 = auVar118[1];
        cVar134 = auVar118[2];
        cVar135 = auVar118[3];
        cVar136 = auVar118[4];
        cVar137 = auVar118[5];
        cVar138 = auVar118[6];
        cVar139 = auVar118[7];
        local_120 = (longlong)&local_13c + 1;
        local_138 = lVar114;
        local_130 = param_2;
        local_128 = param_3;
        local_118 = lVar106;
        if (uVar111 + 0x3f < param_3) {
          lVar116 = 0;
          do {
            pcVar1 = (char *)((longlong)param_2 + lVar116);
            pcVar2 = (char *)((longlong)param_2 + lVar116 + 0x10);
            cVar5 = *pcVar2;
            cVar6 = pcVar2[1];
            cVar7 = pcVar2[2];
            cVar8 = pcVar2[3];
            cVar9 = pcVar2[4];
            cVar10 = pcVar2[5];
            cVar11 = pcVar2[6];
            cVar12 = pcVar2[7];
            cVar13 = pcVar2[8];
            cVar14 = pcVar2[9];
            cVar15 = pcVar2[10];
            cVar16 = pcVar2[0xb];
            cVar17 = pcVar2[0xc];
            cVar18 = pcVar2[0xd];
            cVar19 = pcVar2[0xe];
            cVar20 = pcVar2[0xf];
            pcVar2 = (char *)((longlong)param_2 + lVar116 + 0x20);
            cVar21 = *pcVar2;
            cVar22 = pcVar2[1];
            cVar23 = pcVar2[2];
            cVar24 = pcVar2[3];
            cVar25 = pcVar2[4];
            cVar26 = pcVar2[5];
            cVar27 = pcVar2[6];
            cVar28 = pcVar2[7];
            cVar29 = pcVar2[8];
            cVar30 = pcVar2[9];
            cVar31 = pcVar2[10];
            cVar32 = pcVar2[0xb];
            cVar33 = pcVar2[0xc];
            cVar34 = pcVar2[0xd];
            cVar35 = pcVar2[0xe];
            cVar36 = pcVar2[0xf];
            pcVar2 = (char *)((longlong)param_2 + lVar116 + 0x30);
            cVar37 = *pcVar2;
            cVar38 = pcVar2[1];
            cVar39 = pcVar2[2];
            cVar40 = pcVar2[3];
            cVar41 = pcVar2[4];
            cVar42 = pcVar2[5];
            cVar43 = pcVar2[6];
            cVar44 = pcVar2[7];
            cVar45 = pcVar2[8];
            cVar46 = pcVar2[9];
            cVar47 = pcVar2[10];
            cVar48 = pcVar2[0xb];
            cVar49 = pcVar2[0xc];
            cVar50 = pcVar2[0xd];
            cVar51 = pcVar2[0xe];
            cVar52 = pcVar2[0xf];
            auVar118[0] = -(*pcVar1 == cVar124);
            auVar118[1] = -(pcVar1[1] == cVar125);
            auVar118[2] = -(pcVar1[2] == cVar126);
            auVar118[3] = -(pcVar1[3] == cVar127);
            auVar118[4] = -(pcVar1[4] == cVar128);
            auVar118[5] = -(pcVar1[5] == cVar129);
            auVar118[6] = -(pcVar1[6] == cVar130);
            auVar118[7] = -(pcVar1[7] == cVar131);
            auVar118[8] = -(pcVar1[8] == cVar124);
            auVar118[9] = -(pcVar1[9] == cVar125);
            auVar118[10] = -(pcVar1[10] == cVar126);
            auVar118[0xb] = -(pcVar1[0xb] == cVar127);
            auVar118[0xc] = -(pcVar1[0xc] == cVar128);
            auVar118[0xd] = -(pcVar1[0xd] == cVar129);
            auVar118[0xe] = -(pcVar1[0xe] == cVar130);
            auVar118[0xf] = -(pcVar1[0xf] == cVar131);
            pcVar2 = (char *)((longlong)param_2 + lVar116 + lVar114);
            pcVar1 = (char *)((longlong)param_2 + lVar116 + lVar114 + 0x10);
            cVar53 = *pcVar1;
            cVar54 = pcVar1[1];
            cVar55 = pcVar1[2];
            cVar56 = pcVar1[3];
            cVar57 = pcVar1[4];
            cVar58 = pcVar1[5];
            cVar59 = pcVar1[6];
            cVar60 = pcVar1[7];
            cVar61 = pcVar1[8];
            cVar62 = pcVar1[9];
            cVar63 = pcVar1[10];
            cVar64 = pcVar1[0xb];
            cVar65 = pcVar1[0xc];
            cVar66 = pcVar1[0xd];
            cVar67 = pcVar1[0xe];
            cVar68 = pcVar1[0xf];
            pcVar1 = (char *)((longlong)param_2 + lVar116 + lVar114 + 0x20);
            cVar69 = *pcVar1;
            cVar70 = pcVar1[1];
            cVar71 = pcVar1[2];
            cVar72 = pcVar1[3];
            cVar73 = pcVar1[4];
            cVar74 = pcVar1[5];
            cVar75 = pcVar1[6];
            cVar76 = pcVar1[7];
            cVar77 = pcVar1[8];
            cVar78 = pcVar1[9];
            cVar79 = pcVar1[10];
            cVar80 = pcVar1[0xb];
            cVar81 = pcVar1[0xc];
            cVar82 = pcVar1[0xd];
            cVar83 = pcVar1[0xe];
            cVar84 = pcVar1[0xf];
            pcVar1 = (char *)((longlong)param_2 + lVar116 + lVar114 + 0x30);
            cVar85 = *pcVar1;
            cVar86 = pcVar1[1];
            cVar87 = pcVar1[2];
            cVar88 = pcVar1[3];
            cVar89 = pcVar1[4];
            cVar90 = pcVar1[5];
            cVar91 = pcVar1[6];
            cVar92 = pcVar1[7];
            cVar93 = pcVar1[8];
            cVar94 = pcVar1[9];
            cVar95 = pcVar1[10];
            cVar96 = pcVar1[0xb];
            cVar97 = pcVar1[0xc];
            cVar98 = pcVar1[0xd];
            cVar99 = pcVar1[0xe];
            cVar100 = pcVar1[0xf];
            auVar121[0] = -(*pcVar2 == cVar132);
            auVar121[1] = -(pcVar2[1] == cVar133);
            auVar121[2] = -(pcVar2[2] == cVar134);
            auVar121[3] = -(pcVar2[3] == cVar135);
            auVar121[4] = -(pcVar2[4] == cVar136);
            auVar121[5] = -(pcVar2[5] == cVar137);
            auVar121[6] = -(pcVar2[6] == cVar138);
            auVar121[7] = -(pcVar2[7] == cVar139);
            auVar121[8] = -(pcVar2[8] == cVar132);
            auVar121[9] = -(pcVar2[9] == cVar133);
            auVar121[10] = -(pcVar2[10] == cVar134);
            auVar121[0xb] = -(pcVar2[0xb] == cVar135);
            auVar121[0xc] = -(pcVar2[0xc] == cVar136);
            auVar121[0xd] = -(pcVar2[0xd] == cVar137);
            auVar121[0xe] = -(pcVar2[0xe] == cVar138);
            auVar121[0xf] = -(pcVar2[0xf] == cVar139);
            auVar121 = auVar121 & auVar118;
            uVar4 = (ushort)(SUB161(auVar121 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar121 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar121 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar121 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar121 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar121 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar121 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar121 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar121 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar121 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar121 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar121 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar121 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar121 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar121 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar121[0xf] >> 7) << 0xf;
            if (uVar4 == 0) {
              uVar105 = 0;
            }
            else {
              uVar105 = core[505b25137b8ba7f]::str::pattern::simd_contains::_closure_2_
                                  (&local_130,lVar116,uVar4,0);
            }
            auVar144[0] = -(cVar5 == cVar124);
            auVar144[1] = -(cVar6 == cVar125);
            auVar144[2] = -(cVar7 == cVar126);
            auVar144[3] = -(cVar8 == cVar127);
            auVar144[4] = -(cVar9 == cVar128);
            auVar144[5] = -(cVar10 == cVar129);
            auVar144[6] = -(cVar11 == cVar130);
            auVar144[7] = -(cVar12 == cVar131);
            auVar144[8] = -(cVar13 == cVar124);
            auVar144[9] = -(cVar14 == cVar125);
            auVar144[10] = -(cVar15 == cVar126);
            auVar144[0xb] = -(cVar16 == cVar127);
            auVar144[0xc] = -(cVar17 == cVar128);
            auVar144[0xd] = -(cVar18 == cVar129);
            auVar144[0xe] = -(cVar19 == cVar130);
            auVar144[0xf] = -(cVar20 == cVar131);
            auVar145[0] = -(cVar53 == cVar132);
            auVar145[1] = -(cVar54 == cVar133);
            auVar145[2] = -(cVar55 == cVar134);
            auVar145[3] = -(cVar56 == cVar135);
            auVar145[4] = -(cVar57 == cVar136);
            auVar145[5] = -(cVar58 == cVar137);
            auVar145[6] = -(cVar59 == cVar138);
            auVar145[7] = -(cVar60 == cVar139);
            auVar145[8] = -(cVar61 == cVar132);
            auVar145[9] = -(cVar62 == cVar133);
            auVar145[10] = -(cVar63 == cVar134);
            auVar145[0xb] = -(cVar64 == cVar135);
            auVar145[0xc] = -(cVar65 == cVar136);
            auVar145[0xd] = -(cVar66 == cVar137);
            auVar145[0xe] = -(cVar67 == cVar138);
            auVar145[0xf] = -(cVar68 == cVar139);
            auVar145 = auVar145 & auVar144;
            uVar4 = (ushort)(SUB161(auVar145 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar145 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar145 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar145 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar145 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar145 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar145 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar145 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar145 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar145 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar145 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar145 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar145 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar145 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar145 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar145[0xf] >> 7) << 0xf;
            if (uVar4 != 0) {
              uVar107 = core[505b25137b8ba7f]::str::pattern::simd_contains::_closure_2_
                                  (&local_130,lVar116 + 0x10,uVar4,uVar105 & 0xffffffff);
              uVar105 = CONCAT71((int7)((ulonglong)uVar107 >> 8),(byte)uVar107 | (byte)uVar105);
            }
            auVar142[0] = -(cVar21 == cVar124);
            auVar142[1] = -(cVar22 == cVar125);
            auVar142[2] = -(cVar23 == cVar126);
            auVar142[3] = -(cVar24 == cVar127);
            auVar142[4] = -(cVar25 == cVar128);
            auVar142[5] = -(cVar26 == cVar129);
            auVar142[6] = -(cVar27 == cVar130);
            auVar142[7] = -(cVar28 == cVar131);
            auVar142[8] = -(cVar29 == cVar124);
            auVar142[9] = -(cVar30 == cVar125);
            auVar142[10] = -(cVar31 == cVar126);
            auVar142[0xb] = -(cVar32 == cVar127);
            auVar142[0xc] = -(cVar33 == cVar128);
            auVar142[0xd] = -(cVar34 == cVar129);
            auVar142[0xe] = -(cVar35 == cVar130);
            auVar142[0xf] = -(cVar36 == cVar131);
            auVar143[0] = -(cVar69 == cVar132);
            auVar143[1] = -(cVar70 == cVar133);
            auVar143[2] = -(cVar71 == cVar134);
            auVar143[3] = -(cVar72 == cVar135);
            auVar143[4] = -(cVar73 == cVar136);
            auVar143[5] = -(cVar74 == cVar137);
            auVar143[6] = -(cVar75 == cVar138);
            auVar143[7] = -(cVar76 == cVar139);
            auVar143[8] = -(cVar77 == cVar132);
            auVar143[9] = -(cVar78 == cVar133);
            auVar143[10] = -(cVar79 == cVar134);
            auVar143[0xb] = -(cVar80 == cVar135);
            auVar143[0xc] = -(cVar81 == cVar136);
            auVar143[0xd] = -(cVar82 == cVar137);
            auVar143[0xe] = -(cVar83 == cVar138);
            auVar143[0xf] = -(cVar84 == cVar139);
            auVar143 = auVar143 & auVar142;
            uVar4 = (ushort)(SUB161(auVar143 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar143 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar143 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar143 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar143 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar143 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar143 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar143 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar143 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar143 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar143 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar143 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar143 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar143 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar143 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar143[0xf] >> 7) << 0xf;
            if (uVar4 != 0) {
              uVar107 = core[505b25137b8ba7f]::str::pattern::simd_contains::_closure_2_
                                  (&local_130,lVar116 + 0x20,uVar4,uVar105 & 0xffffffff);
              uVar105 = CONCAT71((int7)((ulonglong)uVar107 >> 8),(byte)uVar107 | (byte)uVar105);
            }
            auVar140[0] = -(cVar37 == cVar124);
            auVar140[1] = -(cVar38 == cVar125);
            auVar140[2] = -(cVar39 == cVar126);
            auVar140[3] = -(cVar40 == cVar127);
            auVar140[4] = -(cVar41 == cVar128);
            auVar140[5] = -(cVar42 == cVar129);
            auVar140[6] = -(cVar43 == cVar130);
            auVar140[7] = -(cVar44 == cVar131);
            auVar140[8] = -(cVar45 == cVar124);
            auVar140[9] = -(cVar46 == cVar125);
            auVar140[10] = -(cVar47 == cVar126);
            auVar140[0xb] = -(cVar48 == cVar127);
            auVar140[0xc] = -(cVar49 == cVar128);
            auVar140[0xd] = -(cVar50 == cVar129);
            auVar140[0xe] = -(cVar51 == cVar130);
            auVar140[0xf] = -(cVar52 == cVar131);
            auVar141[0] = -(cVar85 == cVar132);
            auVar141[1] = -(cVar86 == cVar133);
            auVar141[2] = -(cVar87 == cVar134);
            auVar141[3] = -(cVar88 == cVar135);
            auVar141[4] = -(cVar89 == cVar136);
            auVar141[5] = -(cVar90 == cVar137);
            auVar141[6] = -(cVar91 == cVar138);
            auVar141[7] = -(cVar92 == cVar139);
            auVar141[8] = -(cVar93 == cVar132);
            auVar141[9] = -(cVar94 == cVar133);
            auVar141[10] = -(cVar95 == cVar134);
            auVar141[0xb] = -(cVar96 == cVar135);
            auVar141[0xc] = -(cVar97 == cVar136);
            auVar141[0xd] = -(cVar98 == cVar137);
            auVar141[0xe] = -(cVar99 == cVar138);
            auVar141[0xf] = -(cVar100 == cVar139);
            auVar141 = auVar141 & auVar140;
            uVar4 = (ushort)(SUB161(auVar141 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar141 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar141 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar141 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar141 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar141 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar141 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar141 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar141 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar141 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar141 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar141 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar141 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar141 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar141 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar141[0xf] >> 7) << 0xf;
            if (uVar4 != 0) {
              uVar107 = core[505b25137b8ba7f]::str::pattern::simd_contains::_closure_2_
                                  (&local_130,lVar116 + 0x30,uVar4,uVar105 & 0xffffffff);
              uVar105 = CONCAT71((int7)((ulonglong)uVar107 >> 8),(byte)uVar107 | (byte)uVar105);
            }
            lVar117 = lVar116 + 0x40;
          } while ((lVar116 + uVar111 + 0x7f < param_3) &&
                  (lVar117 = lVar116 + 0x40, lVar116 = lVar117, (char)uVar105 == '\0'));
        }
        else {
          lVar117 = 0;
          uVar105 = 0;
        }
        uVar112 = local_138;
        if ((uVar111 + lVar117 + 0xf < param_3) && ((char)uVar105 == '\0')) {
          do {
            pcVar1 = (char *)((longlong)param_2 + lVar117);
            pcVar2 = (char *)((longlong)param_2 + lVar117 + uVar112);
            auVar119[0] = -(*pcVar1 == cVar124);
            auVar119[1] = -(pcVar1[1] == cVar125);
            auVar119[2] = -(pcVar1[2] == cVar126);
            auVar119[3] = -(pcVar1[3] == cVar127);
            auVar119[4] = -(pcVar1[4] == cVar128);
            auVar119[5] = -(pcVar1[5] == cVar129);
            auVar119[6] = -(pcVar1[6] == cVar130);
            auVar119[7] = -(pcVar1[7] == cVar131);
            auVar119[8] = -(pcVar1[8] == cVar124);
            auVar119[9] = -(pcVar1[9] == cVar125);
            auVar119[10] = -(pcVar1[10] == cVar126);
            auVar119[0xb] = -(pcVar1[0xb] == cVar127);
            auVar119[0xc] = -(pcVar1[0xc] == cVar128);
            auVar119[0xd] = -(pcVar1[0xd] == cVar129);
            auVar119[0xe] = -(pcVar1[0xe] == cVar130);
            auVar119[0xf] = -(pcVar1[0xf] == cVar131);
            auVar122[0] = -(*pcVar2 == cVar132);
            auVar122[1] = -(pcVar2[1] == cVar133);
            auVar122[2] = -(pcVar2[2] == cVar134);
            auVar122[3] = -(pcVar2[3] == cVar135);
            auVar122[4] = -(pcVar2[4] == cVar136);
            auVar122[5] = -(pcVar2[5] == cVar137);
            auVar122[6] = -(pcVar2[6] == cVar138);
            auVar122[7] = -(pcVar2[7] == cVar139);
            auVar122[8] = -(pcVar2[8] == cVar132);
            auVar122[9] = -(pcVar2[9] == cVar133);
            auVar122[10] = -(pcVar2[10] == cVar134);
            auVar122[0xb] = -(pcVar2[0xb] == cVar135);
            auVar122[0xc] = -(pcVar2[0xc] == cVar136);
            auVar122[0xd] = -(pcVar2[0xd] == cVar137);
            auVar122[0xe] = -(pcVar2[0xe] == cVar138);
            auVar122[0xf] = -(pcVar2[0xf] == cVar139);
            auVar122 = auVar122 & auVar119;
            uVar4 = (ushort)(SUB161(auVar122 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar122 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar122 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar122 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar122 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar122 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar122 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar122 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar122 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar122 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar122 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar122 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar122 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar122 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar122 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar122[0xf] >> 7) << 0xf;
            if (uVar4 == 0) {
              uVar105 = 0;
            }
            else {
              uVar105 = core[505b25137b8ba7f]::str::pattern::simd_contains::_closure_2_
                                  (&local_130,lVar117,uVar4,0);
            }
          } while ((uVar111 + 0x1f + lVar117 < param_3) &&
                  (lVar117 = lVar117 + 0x10, (char)uVar105 == '\0'));
        }
        lVar106 = param_3 - lVar106;
        pcVar2 = (char *)((longlong)param_2 + lVar106 + -0x10);
        pcVar1 = (char *)((longlong)param_2 + local_138 + lVar106 + -0x10);
        auVar120[0] = -(*pcVar2 == cVar124);
        auVar120[1] = -(pcVar2[1] == cVar125);
        auVar120[2] = -(pcVar2[2] == cVar126);
        auVar120[3] = -(pcVar2[3] == cVar127);
        auVar120[4] = -(pcVar2[4] == cVar128);
        auVar120[5] = -(pcVar2[5] == cVar129);
        auVar120[6] = -(pcVar2[6] == cVar130);
        auVar120[7] = -(pcVar2[7] == cVar131);
        auVar120[8] = -(pcVar2[8] == cVar124);
        auVar120[9] = -(pcVar2[9] == cVar125);
        auVar120[10] = -(pcVar2[10] == cVar126);
        auVar120[0xb] = -(pcVar2[0xb] == cVar127);
        auVar120[0xc] = -(pcVar2[0xc] == cVar128);
        auVar120[0xd] = -(pcVar2[0xd] == cVar129);
        auVar120[0xe] = -(pcVar2[0xe] == cVar130);
        auVar120[0xf] = -(pcVar2[0xf] == cVar131);
        auVar123[0] = -(*pcVar1 == cVar132);
        auVar123[1] = -(pcVar1[1] == cVar133);
        auVar123[2] = -(pcVar1[2] == cVar134);
        auVar123[3] = -(pcVar1[3] == cVar135);
        auVar123[4] = -(pcVar1[4] == cVar136);
        auVar123[5] = -(pcVar1[5] == cVar137);
        auVar123[6] = -(pcVar1[6] == cVar138);
        auVar123[7] = -(pcVar1[7] == cVar139);
        auVar123[8] = -(pcVar1[8] == cVar132);
        auVar123[9] = -(pcVar1[9] == cVar133);
        auVar123[10] = -(pcVar1[10] == cVar134);
        auVar123[0xb] = -(pcVar1[0xb] == cVar135);
        auVar123[0xc] = -(pcVar1[0xc] == cVar136);
        auVar123[0xd] = -(pcVar1[0xd] == cVar137);
        auVar123[0xe] = -(pcVar1[0xe] == cVar138);
        auVar123[0xf] = -(pcVar1[0xf] == cVar139);
        auVar123 = auVar123 & auVar120;
        uVar4 = (ushort)(SUB161(auVar123 >> 7,0) & 1) | (ushort)(SUB161(auVar123 >> 0xf,0) & 1) << 1
                | (ushort)(SUB161(auVar123 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar123 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar123 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar123 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar123 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar123 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar123 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar123 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar123 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar123 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar123 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar123 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar123 >> 0x77,0) & 1) << 0xe |
                (ushort)(byte)(auVar123[0xf] >> 7) << 0xf;
        if (uVar4 != 0) {
          bVar102 = core[505b25137b8ba7f]::str::pattern::simd_contains::_closure_2_
                              (&local_130,lVar106 + -0x10,uVar4,uVar105 & 0xffffffff);
          uVar105 = CONCAT71((int7)((uVar105 & 0xffffffff) >> 8),
                             (byte)(uVar105 & 0xffffffff) | bVar102);
        }
        goto LAB_140040420;
      }
    }
    else {
      bVar102 = bVar110 & 0x3f | 0x80;
      bVar101 = (byte)(param_1 >> 0xc);
      if (uVar104 < 0x10000) {
        bVar101 = bVar101 | 0xe0;
        uVar111 = 3;
        bVar110 = bVar109;
        bVar109 = 0;
        bVar115 = bVar102;
      }
      else {
        bVar115 = bVar101 & 0x3f | 0x80;
        bVar101 = (byte)(uVar104 >> 0x12) | 0xf0;
        uVar111 = 4;
        bVar110 = bVar102;
      }
      local_13c = CONCAT13(bVar109,CONCAT12(bVar110,CONCAT11(bVar115,bVar101)));
      if (param_3 <= uVar111) goto LAB_14004036a;
      lVar106 = uVar111 - 1;
      bVar109 = abStack_140[uVar111 + 3];
      lVar114 = lVar106;
      if (bVar109 == bVar101) {
        if (lVar106 == 0) {
LAB_140040245:
          uVar111 = <core[505b25137b8ba7f]::str::pattern::StrSearcher>::new
                              (&local_130,param_2,param_3,&local_13c,uVar111);
          if ((char)local_130 == '\0') {
            if (local_118._2_1_ == '\0') {
              uVar105 = local_118 & 0xff;
              if (local_128 != 0) {
                if (local_128 < local_e0) {
                  if (*(char *)(local_e8 + local_128) < -0x40) goto LAB_1400408b4;
                }
                else if (local_128 != local_e0) goto LAB_1400408b4;
              }
              if (local_128 != local_e0) {
                bVar102 = *(byte *)(local_e8 + local_128);
                uVar104 = (uint)bVar102;
                if ((char)bVar102 < '\0') {
                  uVar113 = *(byte *)(local_e8 + 1 + local_128) & 0x3f;
                  if (bVar102 < 0xe0) {
                    uVar104 = (uVar104 & 0x1f) << 6 | uVar113;
                    uVar111 = (ulonglong)uVar104;
                  }
                  else {
                    uVar113 = *(byte *)(local_e8 + 2 + local_128) & 0x3f | uVar113 << 6;
                    if (bVar102 < 0xf0) {
                      uVar104 = (uVar104 & 0x1f) << 0xc;
                      uVar111 = (ulonglong)uVar104;
                      uVar104 = uVar113 | uVar104;
                    }
                    else {
                      uVar104 = (uVar104 & 7) << 0x12;
                      uVar111 = (ulonglong)uVar104;
                      uVar104 = *(byte *)(local_e8 + 3 + local_128) & 0x3f | uVar113 << 6 | uVar104;
                    }
                  }
                }
                uVar105 = CONCAT71((int7)(uVar111 >> 8),1);
                if ((local_118 & 1) == 0) {
                  lVar106 = 1;
                  if ((0x7f < uVar104) && (lVar106 = 2, 0x7ff < uVar104)) {
                    lVar106 = 4 - (ulonglong)(uVar104 < 0x10000);
                  }
                  local_128 = local_128 + lVar106;
                  if (local_128 != 0) {
                    if (local_128 < local_e0) {
                      if (*(char *)(local_e8 + local_128) < -0x40) {
LAB_1400408b4:
                        core[505b25137b8ba7f]::str::slice_error_fail
                                  (local_e8,local_e0,local_128,local_e0,&DAT_1406a3938);
                    /* WARNING: Does not return */
                        pcVar3 = (code *)invalidInstructionException();
                        (*pcVar3)();
                      }
                    }
                    else if (local_128 != local_e0) goto LAB_1400408b4;
                  }
                }
              }
              goto LAB_140040420;
            }
          }
          else {
            lVar106 = local_d0 - 1;
            if (local_f8 == 0xffffffffffffffff) {
              uVar111 = local_108 + lVar106;
              if (uVar111 < local_e0) {
                uVar112 = local_d0;
                if (local_d0 < local_128) {
                  uVar112 = local_128;
                }
                uVar108 = local_128 - 1;
                if (uVar108 < local_d0) {
                  do {
                    uVar111 = (ulonglong)*(byte *)(local_e8 + uVar111);
                    if ((local_110 >> (uVar111 & 0x3f) & 1) == 0) {
                      local_108 = local_108 + local_d0;
                    }
                    else {
                      if (local_128 < local_d0) {
                        uVar111 = local_e8 + local_128 + local_108;
                        lVar114 = 0;
                        do {
                          if (*(char *)(local_d8 + local_128 + lVar114) !=
                              *(char *)(uVar111 + lVar114)) {
                            local_108 = local_108 + lVar114 + 1;
                            goto LAB_1400404ef;
                          }
                          lVar114 = lVar114 + 1;
                        } while (uVar112 - local_128 != lVar114);
                      }
                      uVar105 = CONCAT71((int7)(uVar111 >> 8),1);
                      if (local_128 == 0) break;
                      uVar111 = local_128;
                      while (*(char *)(local_d8 + -1 + uVar111) ==
                             *(char *)(local_e8 + -1 + local_108 + uVar111)) {
                        uVar111 = uVar111 - 1;
                        if (uVar111 == 0) goto LAB_140040420;
                      }
                      local_108 = local_108 + local_118;
                    }
LAB_1400404ef:
                    uVar111 = local_108 + lVar106;
                    uVar105 = 0;
                  } while (uVar111 < local_e0);
                }
                else {
                  do {
                    uVar111 = (ulonglong)*(byte *)(local_e8 + uVar111);
                    if ((local_110 >> (uVar111 & 0x3f) & 1) == 0) {
                      local_108 = local_108 + local_d0;
                    }
                    else {
                      if (local_d0 <= local_128) {
LAB_14004083c:
                        uVar105 = CONCAT71((int7)(uVar111 >> 8),1);
                        if (local_128 != 0) {
LAB_140040847:
                          core[505b25137b8ba7f]::panicking::panic_bounds_check
                                    (uVar108,local_d0,&DAT_1406a0510);
                    /* WARNING: Does not return */
                          pcVar3 = (code *)invalidInstructionException();
                          (*pcVar3)();
                        }
                        break;
                      }
                      uVar111 = local_e8 + local_128 + local_108;
                      lVar114 = 0;
                      while (*(char *)(local_d8 + local_128 + lVar114) ==
                             *(char *)(uVar111 + lVar114)) {
                        lVar114 = lVar114 + 1;
                        if (uVar112 - local_128 == lVar114) goto LAB_14004083c;
                      }
                      local_108 = local_108 + lVar114 + 1;
                    }
                    uVar111 = local_108 + lVar106;
                    uVar105 = 0;
                  } while (uVar111 < local_e0);
                }
                goto LAB_140040420;
              }
            }
            else {
              uVar111 = local_108 + lVar106;
              if (uVar111 < local_e0) {
                local_138 = local_118;
                do {
                  if ((local_110 >> ((ulonglong)*(byte *)(local_e8 + uVar111) & 0x3f) & 1) == 0) {
                    local_108 = local_108 + local_d0;
LAB_140040354:
                    local_f8 = 0;
                  }
                  else {
                    uVar111 = local_128;
                    if (local_128 < local_f8) {
                      uVar111 = local_f8;
                    }
                    if (uVar111 < local_d0) {
                      do {
                        if (*(char *)(local_d8 + uVar111) !=
                            *(char *)(local_e8 + local_108 + uVar111)) {
                          local_108 = local_108 + (1 - local_128) + uVar111;
                          goto LAB_140040354;
                        }
                        uVar111 = uVar111 + 1;
                      } while (uVar111 < local_d0);
                    }
                    uVar105 = CONCAT71((int7)(uVar111 >> 8),1);
                    if (local_128 <= local_f8) break;
                    uVar108 = local_128;
                    while( true ) {
                      uVar108 = uVar108 - 1;
                      if (local_d0 <= uVar108) goto LAB_140040847;
                      if (*(char *)(local_d8 + uVar108) != *(char *)(local_e8 + local_108 + uVar108)
                         ) break;
                      if (uVar108 <= local_f8) goto LAB_140040420;
                    }
                    local_108 = local_108 + local_118;
                    local_f8 = local_d0 - local_118;
                  }
                  uVar111 = local_108 + lVar106;
                  uVar105 = 0;
                } while (uVar111 < local_e0);
                goto LAB_140040420;
              }
            }
          }
          goto LAB_14004041e;
        }
        lVar114 = uVar111 - 2;
        bVar109 = abStack_140[uVar111 + 2];
        if (bVar109 == bVar101) {
          if (lVar114 == 0) goto LAB_140040245;
          lVar114 = uVar111 - 3;
          bVar109 = abStack_140[uVar111 + 1];
          if (bVar109 == bVar101) {
            if ((lVar114 == 0) || (bVar109 = abStack_140[uVar111], bVar109 == bVar101))
            goto LAB_140040245;
            lVar114 = uVar111 - 4;
          }
        }
      }
      if (uVar111 + 0xf <= param_3) goto LAB_140040585;
    }
    do {
      iVar103 = memcmp(param_2,&local_13c,uVar111);
      uVar105 = CONCAT44(extraout_var,iVar103);
      if (iVar103 == 0) goto LAB_140040197;
      param_2 = (void *)((longlong)param_2 + 1);
      param_3 = param_3 - 1;
    } while (uVar111 <= param_3);
  }
LAB_14004041e:
  uVar105 = 0;
LAB_140040420:
  return uVar105 & 0xffffffffffffff01;
}

