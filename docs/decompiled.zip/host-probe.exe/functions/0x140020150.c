// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::ingame_chat::read_json
// address: 0x140020150
// body: available
// range: 0x140020150-0x140020346 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140020342 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::ingame_chat::read_json */

void __rustcall
host_probe[b94139f9089eb1d8]::ingame_chat::read_json
          (undefined8 *param_1,HANDLE param_2,undefined8 param_3,ulonglong param_4)

{
  longlong lVar1;
  longlong *plVar2;
  longlong local_a8;
  undefined8 local_a0;
  ulonglong local_98;
  undefined8 local_90;
  ulonglong local_88 [2];
  HANDLE local_78;
  ulonglong uStack_70;
  undefined8 local_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined1 uStack_58;
  ulonglong local_40;
  HANDLE local_20;
  
  local_78 = (HANDLE)((ulonglong)local_78 & 0xffffffff00000000);
  uStack_70 = 0;
  local_68._0_4_ = 7;
  local_68._4_4_ = 0;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_60 = 1;
  lVar1 = <std[3bf9d48a0c3997f0]::fs::OpenOptions>::_open(&local_78);
  if (lVar1 == 1) {
    if ((1 < ((uint)param_2 & 3) - 2) && (((ulonglong)param_2 & 3) != 0)) {
      uStack_70 = (longlong)param_2 - 1;
      local_78 = (HANDLE)CONCAT71(local_78._1_7_,3);
      <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
      drop(&uStack_70);
    }
    *(undefined1 *)param_1 = 0xff;
  }
  else {
    local_20 = param_2;
    <std[3bf9d48a0c3997f0]::fs::File>::metadata(&local_78,&local_20);
    if ((int)local_78 == 2) {
      if ((1 < ((uint)uStack_70 & 3) - 2) && ((uStack_70 & 3) != 0)) {
        local_88[0] = uStack_70 - 1;
        local_90 = CONCAT71(local_90._1_7_,3);
        <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::
        drop(local_88);
      }
    }
    else if (local_40 <= param_4) {
      local_a8 = 0;
      local_a0 = 1;
      local_98 = 0;
      uStack_70 = param_4 + 1;
      plVar2 = &local_a8;
      local_78 = param_2;
      local_68 = uStack_70;
      lVar1 = alloc[246c2e7857c81348]::io::read::default_read_to_end::
              <core[505b25137b8ba7f]::io::util::Take<std[3bf9d48a0c3997f0]::fs::File>>
                        (&local_78,plVar2,0);
      if (lVar1 == 1) {
        if ((1 < ((uint)plVar2 & 3) - 2) && (((ulonglong)plVar2 & 3) != 0)) {
          local_88[0] = (longlong)plVar2 - 1;
          local_90 = CONCAT71(local_90._1_7_,3);
          <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
          ::drop(local_88);
        }
        *(undefined1 *)param_1 = 0xff;
        CloseHandle(local_78);
      }
      else {
        CloseHandle(local_78);
        if (param_4 < local_98) {
          *(undefined1 *)param_1 = 0xff;
        }
        else {
          local_90 = local_a0;
          local_88[0] = local_98;
          local_88[1] = 0;
          serde_json[7404bcab4dc139c7]::de::from_trait::
          <serde_json[7404bcab4dc139c7]::read::SliceRead,serde_json[7404bcab4dc139c7]::value::Value>
                    (&local_78,&local_90);
          if ((char)local_78 == -1) {
            *(undefined1 *)param_1 = 0xff;
            core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::error::Error>
                      (&uStack_70);
          }
          else {
            param_1[2] = local_68;
            param_1[3] = CONCAT44(uStack_5c,uStack_60);
            *param_1 = local_78;
            param_1[1] = uStack_70;
          }
        }
      }
      if (local_a8 == 0) {
        return;
      }
      __rustc[9d087a5ab36ea756]::__rust_dealloc(local_a0,local_a8,1);
      return;
    }
    *(undefined1 *)param_1 = 0xff;
    CloseHandle(param_2);
  }
  return;
}

