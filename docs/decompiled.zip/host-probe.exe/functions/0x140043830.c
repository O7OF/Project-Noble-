// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>,host_probe[b94139f9089eb1d8]::server_admin::check::mode_names::{closure#2}>>
// address: 0x140043830
// body: available
// range: 0x140043830-0x1400438c1 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::<core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>,
   host_probe[b94139f9089eb1d8]::server_admin::check::mode_names::{closure#2}>> */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted::
<core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>,host_probe[b94139f9089eb1d8]::server_admin::check::mode_names::_closure_2_>>
          (longlong *param_1,undefined4 *param_2)

{
  ulonglong uVar1;
  longlong *local_50;
  longlong local_48;
  longlong local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar1 = ((ulonglong)(*(longlong *)(param_2 + 6) - *(longlong *)(param_2 + 2)) >> 3) *
          -0x5555555555555555;
  local_48 = param_1[2];
  if ((ulonglong)(*param_1 - local_48) <= uVar1 && uVar1 - (*param_1 - local_48) != 0) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,local_48,uVar1,8,0x18);
    local_48 = param_1[2];
  }
  local_40 = param_1[1];
  local_38 = *param_2;
  uStack_34 = param_2[1];
  uStack_30 = param_2[2];
  uStack_2c = param_2[3];
  local_28 = param_2[4];
  uStack_24 = param_2[5];
  uStack_20 = param_2[6];
  uStack_1c = param_2[7];
  local_50 = param_1 + 2;
  <alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
  ::fold::
  <(),core[505b25137b8ba7f]::iter::adapters::map::map_fold<alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String,(),host_probe[b94139f9089eb1d8]::server_admin::check::mode_names::_closure_2_,core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<alloc[246c2e7857c81348]::string::String,<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>>::extend_trusted<core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::string::String>,host_probe[b94139f9089eb1d8]::server_admin::check::mode_names::_closure_2_>>::_closure_0_>::_closure_0_>::_closure_0_>
            (&local_38,&local_50);
  return;
}

