// rea decompile_all
// name: <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<char,<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::Extend<char>>::extend<core[505b25137b8ba7f]::iter::adapters::flatten::FlatMap<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::str::iter::Chars,host_probe[b94139f9089eb1d8]::vote::take_won::{closure#0}::{closure#0}>,core[505b25137b8ba7f]::char::ToLowercase,<char>::to_lowercase>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),char)>>::call_mut
// address: 0x14003f110
// body: available
// range: 0x14003f110-0x14003f249 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <&mut core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<char,
   <alloc[246c2e7857c81348]::string::String as
   core[505b25137b8ba7f]::iter::traits::collect::Extend<char>>::extend<core[505b25137b8ba7f]::iter::adapters::flatten::FlatMap<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::str::iter::Chars,
   host_probe[b94139f9089eb1d8]::vote::take_won::{closure#0}::{closure#0}>,
   core[505b25137b8ba7f]::char::ToLowercase, <char>::to_lowercase>>::{closure#0}>::{closure#0} as
   core[505b25137b8ba7f]::ops::function::FnMut<((), char)>>::call_mut */

void __rustcall
<&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<char,<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::Extend<char>>::extend<core[505b25137b8ba7f]::iter::adapters::flatten::FlatMap<core[505b25137b8ba7f]::iter::adapters::filter::Filter<core[505b25137b8ba7f]::str::iter::Chars,host_probe[b94139f9089eb1d8]::vote::take_won::{closure#0}::{closure#0}>,core[505b25137b8ba7f]::char::ToLowercase,<char>::to_lowercase>>::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),char)>>
::call_mut(undefined8 *param_1,uint param_2)

{
  longlong *plVar1;
  longlong lVar2;
  byte bVar3;
  longlong lVar4;
  byte bVar5;
  ulonglong uVar6;
  byte bVar7;
  
  plVar1 = *(longlong **)*param_1;
  lVar2 = plVar1[2];
  if (param_2 < 0x80) {
    if (*plVar1 == lVar2) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(plVar1,lVar2,1,1,1);
    }
    *(byte *)(plVar1[1] + lVar2) = (byte)param_2;
    lVar4 = 1;
  }
  else {
    uVar6 = 2;
    if (0x7ff < param_2) {
      uVar6 = 4 - (ulonglong)(param_2 < 0x10000);
    }
    if ((ulonglong)(*plVar1 - lVar2) < uVar6) {
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
      <alloc[246c2e7857c81348]::alloc::Global>(plVar1,lVar2,uVar6,1,1);
    }
    bVar3 = (byte)param_2 & 0x3f | 0x80;
    lVar4 = plVar1[1];
    bVar5 = (byte)(param_2 >> 6);
    if (param_2 < 0x800) {
      *(byte *)(lVar4 + lVar2) = bVar5 | 0xc0;
      *(byte *)(lVar4 + 1 + lVar2) = bVar3;
      lVar4 = 2;
    }
    else {
      bVar5 = bVar5 & 0x3f | 0x80;
      bVar7 = (byte)(param_2 >> 0xc);
      if (param_2 < 0x10000) {
        *(byte *)(lVar4 + lVar2) = bVar7 | 0xe0;
        *(byte *)(lVar4 + 1 + lVar2) = bVar5;
        *(byte *)(lVar4 + 2 + lVar2) = bVar3;
        lVar4 = 3;
      }
      else {
        *(byte *)(lVar4 + lVar2) = (byte)(param_2 >> 0x12) | 0xf0;
        *(byte *)(lVar4 + 1 + lVar2) = bVar7 & 0x3f | 0x80;
        *(byte *)(lVar4 + 2 + lVar2) = bVar5;
        *(byte *)(lVar4 + 3 + lVar2) = bVar3;
        lVar4 = 4;
      }
    }
  }
  plVar1[2] = lVar4 + lVar2;
  return;
}

