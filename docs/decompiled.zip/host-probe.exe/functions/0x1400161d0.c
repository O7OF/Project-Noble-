// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<u64>>::grow
// address: 0x1400161d0
// body: available
// range: 0x1400161d0-0x14001625b inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140016257 to 0x1406968d0 memcpy (external=false, thunk=true, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<u64>>::grow */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<u64>>::grow(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  
  lVar3 = *param_1;
  <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<reach_directory[4b72b9694f6c3c08]::rendezvous::State>>>>
  ::grow_one();
  uVar1 = param_1[2];
  if ((ulonglong)(lVar3 - param_1[3]) < uVar1) {
    uVar2 = lVar3 - uVar1;
    uVar4 = param_1[3] - uVar2;
    if (uVar4 <= (ulonglong)(*param_1 - lVar3) && uVar4 < uVar2) {
      memcpy((void *)(param_1[1] + lVar3 * 8),(void *)param_1[1],uVar4 * 8);
      return;
    }
    lVar3 = *param_1 - uVar2;
    memmove((void *)(param_1[1] + lVar3 * 8),(void *)(param_1[1] + uVar1 * 8),uVar2 * 8);
    param_1[2] = lVar3;
  }
  return;
}

