// rea decompile_all
// name: <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#5}
// address: 0x14000c5b0
// body: available
// range: 0x14000c5b0-0x14000c627 inclusive
// range: 0x14000c630-0x14000c691 inclusive
// range: 0x14000c6a0-0x14000c6ea inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::{closure#5} */

undefined8 __rustcall
<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::receive::_closure_5_
          (ulonglong *param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  
  uVar10 = param_1[3];
  if (uVar10 != 0) {
    uVar4 = param_1[2];
    uVar2 = *param_1;
    uVar8 = uVar2;
    if (uVar4 < uVar2) {
      uVar8 = 0;
    }
    uVar9 = uVar4 - uVar8;
    uVar6 = uVar2 - uVar9;
    uVar11 = (uVar10 - uVar6) * 0x30;
    if (uVar10 <= uVar6) {
      uVar11 = 0;
    }
    uVar3 = param_1[1];
    uVar5 = uVar9 + uVar10;
    if (uVar6 < uVar10) {
      uVar5 = uVar2;
    }
    if (uVar9 != uVar5) {
      lVar1 = uVar4 * 0x30 + uVar8 * -0x30 + uVar3;
      if (uVar10 < uVar6) {
        uVar6 = uVar10;
      }
      lVar7 = 0;
      do {
        if ((*(longlong *)(lVar1 + 0x28 + lVar7) == param_3) &&
           (uVar10 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                               (param_2,*(undefined8 *)(lVar1 + 0x18 + lVar7),
                                *(undefined4 *)(lVar1 + 0x20 + lVar7)), uVar10 < 2)) {
          return 1;
        }
        lVar7 = lVar7 + 0x30;
      } while (uVar6 * 0x30 != lVar7);
    }
    if (uVar11 != 0) {
      uVar10 = 0;
      do {
        if ((*(longlong *)(uVar3 + 0x28 + uVar10) == param_3) &&
           (uVar4 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                              (param_2,*(undefined8 *)(uVar3 + 0x18 + uVar10),
                               *(undefined4 *)(uVar3 + 0x20 + uVar10)), uVar4 < 2)) {
          return 1;
        }
        uVar10 = uVar10 + 0x30;
      } while (uVar11 != uVar10);
    }
  }
  return 0;
}

