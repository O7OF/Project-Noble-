// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::receive
// address: 0x140028df0
// body: available
// range: 0x140028df0-0x140028ff6 inclusive
// range: 0x140029000-0x14002906a inclusive
// range: 0x140029070-0x14002955b inclusive
// range: 0x140029560-0x1400295ce inclusive
// range: 0x1400295d0-0x140029728 inclusive
// range: 0x140029730-0x1400298f5 inclusive
// range: 0x140029900-0x140029d1b inclusive
// range: 0x140029d20-0x140029d5e inclusive
// range: 0x140029d60-0x14002a22b inclusive
// range: 0x14002a230-0x14002a448 inclusive
// range: 0x14002a450-0x14002a4a4 inclusive
// range: 0x14002a4b0-0x14002a50b inclusive
// range: 0x14002a510-0x14002a624 inclusive
// range: 0x14002a630-0x14002a65e inclusive
// range: 0x14002a660-0x14002a67f inclusive
// range: 0x14002a690-0x14002a6bd inclusive
// range: 0x14002a6c0-0x14002a6df inclusive
// range: 0x14002a6f0-0x14002a712 inclusive
// range: 0x14002a718-0x14002aa7e inclusive
// range: 0x14002aa80-0x14002aec2 inclusive
// range: 0x14002aed0-0x14002af69 inclusive
// range: 0x14002af6f-0x14002b555 inclusive
// range: 0x14002b560-0x14002b74d inclusive
// range: 0x14002b750-0x14002b97d inclusive
// range: 0x14002b980-0x14002b9e4 inclusive
// range: 0x14002b9f0-0x14002bb86 inclusive
// range: 0x14002bb90-0x14002bbc7 inclusive
// range: 0x14002bbd0-0x14002bbe9 inclusive
// range: 0x14002bbf0-0x14002bd65 inclusive
// range: 0x14002bd70-0x14002bd8f inclusive
// range: 0x14002bd92-0x14002c13b inclusive
// range: 0x14002c140-0x14002c208 inclusive
// range: 0x14002c210-0x14002c247 inclusive
// range: 0x14002c24d-0x14002c276 inclusive
// range: 0x14002c280-0x14002c29f inclusive
// range: 0x14002c2a2-0x14002c52e inclusive
// range: 0x14002c530-0x14002c7dd inclusive
// range: 0x14002c7e0-0x14002cad1 inclusive
// range: 0x14002cae0-0x14002cbfe inclusive
// range: 0x14002cc00-0x14002d68e inclusive
// range: 0x14002d690-0x14002d7d9 inclusive
// range: 0x14002d7e0-0x14002d873 inclusive
// range: 0x14002d880-0x14002d8da inclusive
// range: 0x14002d8e0-0x14002d92b inclusive
// range: 0x14002d930-0x140030f89 inclusive
// range: 0x140030f95-0x140031f7e inclusive
// range: 0x140031f84-0x140032d96 inclusive
// range: 0x140032d9c-0x140033199 inclusive
// range: 0x14003319f-0x140033722 inclusive
// range: 0x140033728-0x1400346ac inclusive
// range: 0x1400346af-0x1400347ce inclusive
// range: 0x1400347d1-0x14003491f inclusive
// range: 0x140034922-0x140034c8a inclusive
// range: 0x140034c90-0x140034e70 inclusive
// range: 0x140034e80-0x140034f85 inclusive
// range: 0x140034f8b-0x140034faa inclusive
// range: 0x140034fad-0x14003526a inclusive
// range: 0x140035270-0x14003538e inclusive
// range: 0x140035394-0x140036cf1 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400294fc to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140029724 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002a4d0 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002a521 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002a67b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002a6a6 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002a6db to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002a70e to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002a8cd to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002abba to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002abd4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14002af65 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Function: ___chkstk_ms replaced with injection: alloca_probe */
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::receive */

undefined1 (*) [16] __rustcall
host_probe[b94139f9089eb1d8]::net::receive
          (void *param_1,undefined1 (*param_2) [16],undefined8 *param_3)

{
  undefined1 (*pauVar1) [12];
  undefined2 uVar2;
  undefined1 (**ppauVar3) [16];
  undefined8 uVar4;
  undefined *puVar5;
  undefined **ppuVar6;
  code *pcVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined *puVar11;
  undefined *puVar12;
  undefined *puVar13;
  undefined *puVar14;
  undefined8 uVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  undefined8 uVar25;
  undefined7 uVar26;
  undefined6 uVar27;
  undefined7 uVar28;
  uint3 uVar29;
  undefined1 auVar30 [16];
  undefined1 auVar31 [16];
  undefined1 auVar32 [16];
  undefined1 auVar33 [12];
  undefined1 auVar34 [12];
  uint6 uVar35;
  byte bVar36;
  byte bVar37;
  byte bVar38;
  byte bVar39;
  byte bVar40;
  byte bVar41;
  byte bVar42;
  byte bVar43;
  byte bVar44;
  byte bVar45;
  byte bVar46;
  byte bVar47;
  byte bVar48;
  byte bVar49;
  byte bVar50;
  byte bVar51;
  byte bVar52;
  byte bVar53;
  byte bVar54;
  byte bVar55;
  byte bVar56;
  byte bVar57;
  byte bVar58;
  byte bVar59;
  byte bVar60;
  byte bVar61;
  byte bVar62;
  byte bVar63;
  byte bVar64;
  byte bVar65;
  byte bVar66;
  byte bVar67;
  ushort uVar68;
  ushort uVar69;
  undefined **ppuVar70;
  undefined **ppuVar71;
  char cVar72;
  byte bVar73;
  char cVar74;
  byte bVar75;
  byte bVar76;
  byte bVar77;
  undefined4 uVar78;
  undefined1 (*pauVar79) [16];
  longlong lVar80;
  ulonglong uVar81;
  undefined1 (*pauVar82) [16];
  ulonglong uVar83;
  undefined1 (*pauVar84) [16];
  undefined8 uVar85;
  undefined8 *puVar86;
  void *pvVar87;
  undefined *puVar88;
  undefined1 (*pauVar89) [16];
  undefined1 *puVar90;
  ushort uVar91;
  undefined1 (*pauVar92) [16];
  char *pcVar93;
  longlong *plVar94;
  uint uVar95;
  uint uVar96;
  undefined4 uVar97;
  longlong lVar98;
  undefined1 *puVar99;
  size_t sVar100;
  byte *pbVar101;
  byte *pbVar102;
  undefined **ppuVar103;
  undefined1 (*pauVar104) [16];
  undefined **ppuVar105;
  longlong *plVar106;
  undefined1 *puVar107;
  DWORD DVar108;
  char *pcVar109;
  undefined1 *puVar110;
  undefined8 *puVar111;
  ushort uVar112;
  uint uVar113;
  uint uVar114;
  char *pcVar115;
  short sVar116;
  ulonglong uVar117;
  ulonglong uVar118;
  size_t sVar119;
  longlong lVar120;
  ulonglong uVar121;
  ulonglong uVar122;
  undefined1 (*pauVar123) [16];
  undefined1 uVar124;
  ulonglong uVar125;
  ulonglong uVar126;
  int iVar127;
  undefined1 (*unaff_R15) [16];
  longlong lVar128;
  bool bVar129;
  bool bVar130;
  bool bVar131;
  byte bVar132;
  undefined1 auVar133 [16];
  undefined1 auVar134 [16];
  undefined1 auVar135 [16];
  undefined1 auVar136 [16];
  undefined1 auVar137 [16];
  undefined1 auVar138 [16];
  undefined1 auVar139 [16];
  undefined1 auVar140 [16];
  undefined1 auVar141 [16];
  undefined1 auVar142 [16];
  undefined1 auVar143 [16];
  undefined1 auVar144 [16];
  undefined1 auVar145 [16];
  undefined1 auVar146 [16];
  undefined1 auVar147 [16];
  undefined1 auVar148 [16];
  undefined1 auVar149 [16];
  undefined1 auVar150 [16];
  undefined1 auVar151 [16];
  undefined1 auVar152 [16];
  undefined1 auVar153 [16];
  undefined1 auVar154 [16];
  undefined1 auVar155 [16];
  undefined1 auVar156 [16];
  undefined1 auVar157 [16];
  undefined1 auVar158 [16];
  undefined1 auVar159 [16];
  undefined1 auVar160 [16];
  undefined1 auVar161 [16];
  undefined1 auVar162 [16];
  undefined1 auVar163 [16];
  undefined1 auVar164 [16];
  undefined1 auVar165 [16];
  undefined1 auVar166 [16];
  undefined1 auVar167 [16];
  undefined1 auVar168 [16];
  undefined1 auVar169 [16];
  undefined1 auVar170 [16];
  undefined1 auVar171 [16];
  undefined1 auVar172 [16];
  undefined1 auVar173 [16];
  undefined1 auVar174 [16];
  undefined1 auVar175 [16];
  undefined1 auVar176 [16];
  undefined1 auVar177 [16];
  undefined1 auVar178 [16];
  undefined1 auVar179 [16];
  undefined1 auVar180 [16];
  undefined1 unaff_XMM7_Ba;
  undefined1 unaff_XMM7_Bb;
  char cVar181;
  undefined1 unaff_XMM7_Bc;
  char cVar182;
  undefined1 unaff_XMM7_Bd;
  char cVar183;
  undefined1 unaff_XMM7_Be;
  char cVar184;
  undefined1 unaff_XMM7_Bf;
  char cVar185;
  undefined1 unaff_XMM7_Bg;
  char cVar186;
  undefined1 unaff_XMM7_Bh;
  char cVar187;
  undefined1 unaff_XMM7_Bi;
  char cVar188;
  undefined1 unaff_XMM7_Bj;
  char cVar189;
  undefined1 unaff_XMM7_Bk;
  char cVar190;
  undefined1 unaff_XMM7_Bl;
  char cVar191;
  undefined1 unaff_XMM7_Bm;
  char cVar192;
  undefined1 unaff_XMM7_Bn;
  char cVar193;
  undefined1 unaff_XMM7_Bo;
  char cVar194;
  undefined1 unaff_XMM7_Bp;
  char cVar195;
  undefined **in_stack_fffffffffffefaa8;
  undefined1 (*pauStack_10538) [16];
  char cStack_10530;
  byte bStack_10528;
  byte bStack_10527;
  byte bStack_10526;
  byte bStack_10525;
  byte bStack_10524;
  byte bStack_10523;
  byte bStack_10522;
  byte bStack_10521;
  byte bStack_10520;
  byte bStack_1051f;
  byte bStack_1051e;
  byte bStack_1051d;
  byte bStack_1051c;
  byte bStack_1051b;
  byte bStack_1051a;
  byte bStack_10519;
  byte bStack_10518;
  byte bStack_10517;
  ushort uStack_10516;
  uint uStack_10514;
  ushort uStack_10510;
  ushort uStack_1050e;
  ushort uStack_1050c;
  ushort uStack_1050a;
  undefined8 uStack_10508;
  undefined8 uStack_10500;
  undefined8 uStack_104f8;
  uint uStack_104f0;
  uint uStack_104ec;
  uint uStack_104e8;
  uint uStack_104e4;
  undefined *puStack_104e0;
  undefined8 uStack_104d8;
  undefined8 uStack_104d0;
  undefined8 uStack_104c0;
  undefined8 uStack_104b8;
  undefined8 uStack_104b0;
  byte bStack_104a8;
  byte bStack_104a7;
  ushort uStack_104a6;
  ushort uStack_104a4;
  ushort uStack_104a2;
  ushort uStack_104a0;
  ushort uStack_1049e;
  uint uStack_1049c;
  ushort uStack_10498;
  ushort uStack_10496;
  uint uStack_10494;
  undefined8 uStack_10490;
  byte bStack_10485;
  ushort uStack_10484;
  ushort uStack_10482;
  undefined1 (*pauStack_10480) [16];
  byte bStack_10471;
  undefined7 uStack_10470;
  byte bStack_10469;
  undefined7 uStack_10468;
  byte bStack_10461;
  undefined8 uStack_10460;
  undefined8 uStack_10458;
  undefined1 (*pauStack_10450) [16];
  undefined1 (*pauStack_10448) [16];
  undefined1 (*pauStack_10440) [16];
  undefined8 uStack_10438;
  byte bStack_10430;
  byte bStack_1042f;
  ushort uStack_1042e;
  uint uStack_1042c;
  byte bStack_10428;
  byte bStack_10427;
  ushort uStack_10426;
  uint uStack_10424;
  uint uStack_10420;
  ushort uStack_1041c;
  ushort uStack_1041a;
  uint uStack_10418;
  undefined4 uStack_10414;
  undefined4 uStack_10410;
  uint uStack_1040c;
  uint uStack_10408;
  uint uStack_10404;
  uint uStack_10400;
  uint uStack_103fc;
  undefined *puStack_103f8;
  undefined *puStack_103f0;
  char cStack_103dc;
  char cStack_103db;
  char cStack_103da;
  char cStack_103d9;
  longlong lStack_103d8;
  int iStack_103d0;
  uint uStack_103cc;
  undefined8 uStack_103c8;
  undefined **ppuStack_103c0;
  undefined1 (*pauStack_103b8) [16];
  undefined *puStack_103b0;
  ushort uStack_103a8;
  ushort uStack_103a6;
  ushort uStack_103a4;
  ushort uStack_103a2;
  ushort uStack_103a0;
  ushort uStack_1039e;
  uint uStack_1039c;
  ushort uStack_10398;
  ushort uStack_10396;
  uint uStack_10394;
  undefined8 uStack_10390;
  undefined8 uStack_10388;
  uint uStack_10380;
  uint uStack_1037c;
  uint uStack_10378;
  undefined *puStack_10374;
  undefined4 uStack_1036c;
  undefined8 uStack_10368;
  undefined8 uStack_10360;
  uint uStack_10354;
  undefined1 (*pauStack_10350) [16];
  undefined8 uStack_10348;
  undefined8 uStack_10340;
  undefined2 uStack_10338;
  ushort uStack_1032c;
  undefined1 uStack_10329;
  byte bStack_10328;
  byte bStack_10327;
  int iStack_10326;
  ushort uStack_10322;
  byte bStack_10320;
  undefined5 uStack_1031f;
  ushort uStack_1031a;
  byte bStack_10318;
  byte bStack_10317;
  uint uStack_10316;
  ushort uStack_10312;
  undefined6 uStack_10310;
  undefined2 uStack_1030a;
  undefined *puStack_10308;
  undefined *puStack_10300;
  undefined *puStack_102f8;
  undefined *puStack_102f0;
  undefined *puStack_102e8;
  undefined2 uStack_102d8;
  undefined2 uStack_102d6;
  ushort uStack_102d4;
  undefined2 uStack_102d2;
  undefined8 uStack_102d0;
  ushort uStack_102c8;
  undefined1 (*pauStack_102b8) [16];
  ulonglong uStack_102b0;
  undefined1 (*pauStack_102a8) [16];
  undefined *puStack_102a0;
  undefined4 uStack_10298;
  short sStack_10294;
  undefined4 uStack_10290;
  undefined2 uStack_1028c;
  undefined8 uStack_10288;
  undefined1 (*pauStack_10280) [16];
  undefined2 uStack_10278;
  ushort uStack_10276;
  ushort uStack_10274;
  ushort uStack_10272;
  uint auStack_10270 [2];
  uint uStack_10268;
  undefined2 uStack_10264;
  undefined2 uStack_10262;
  undefined6 uStack_10260;
  undefined2 uStack_1025a;
  undefined1 auStack_10258 [16];
  undefined1 auStack_10248 [16];
  undefined8 uStack_10238;
  undefined8 uStack_10230;
  undefined8 uStack_10228;
  undefined8 uStack_10220;
  undefined8 uStack_10218;
  undefined **ppuStack_10210;
  longlong lStack_10200;
  longlong lStack_101f8;
  undefined1 (*pauStack_101f0) [16];
  undefined8 *puStack_101e8;
  undefined8 *puStack_101e0;
  undefined **ppuStack_101d8;
  undefined **ppuStack_101d0;
  ushort uStack_101c8;
  undefined6 uStack_101c6;
  undefined1 (*pauStack_101b8) [16];
  short sStack_101b0;
  ushort uStack_101ae;
  undefined4 uStack_101ac;
  undefined8 uStack_101a8;
  undefined8 uStack_101a0;
  ulonglong uStack_10198;
  undefined1 (*pauStack_10190) [16];
  undefined **ppuStack_10188;
  undefined1 (*pauStack_10180) [16];
  undefined8 uStack_10178;
  ulonglong uStack_10170;
  longlong lStack_10168;
  ulonglong uStack_10160;
  ulonglong uStack_10158;
  undefined8 *puStack_10150;
  void *pvStack_10148;
  short sStack_1012c;
  uint uStack_1012a;
  ushort uStack_10126;
  undefined8 uStack_10124;
  undefined4 uStack_1011c;
  char cStack_10109;
  undefined8 uStack_10108;
  undefined8 uStack_10100;
  undefined8 uStack_100f8;
  undefined8 uStack_100f0;
  undefined1 (**ppauStack_100e8) [16];
  undefined1 (*pauStack_100e0) [16];
  undefined1 (*pauStack_100d8) [16];
  undefined8 uStack_100c8;
  undefined7 uStack_100c0;
  byte bStack_100b9;
  undefined7 uStack_100b8;
  short sStack_100a8;
  undefined6 uStack_100a6;
  undefined8 uStack_100a0;
  undefined8 uStack_10098;
  undefined8 uStack_10090;
  undefined8 uStack_10088;
  undefined1 (*pauStack_10080) [16];
  undefined8 uStack_10078;
  byte abStack_10070 [2];
  undefined6 uStack_1006e;
  undefined1 (*pauStack_10068) [16];
  undefined1 (**ppauStack_10060) [16];
  undefined1 (*pauStack_10058) [16];
  undefined1 (*pauStack_10050) [16];
  undefined1 (*pauStack_10048) [16];
  ulonglong uStack_10040;
  undefined8 uStack_10028;
  
  if (DAT_140699990 != 0) {
    return (undefined1 (*) [16])0x0;
  }
  pauStack_101f0 = param_2;
  puStack_10150 = param_3;
  pvStack_10148 = param_1;
  flush_held();
  LOCK();
  bVar129 = DAT_140699948 == '\0';
  if (bVar129) {
    DAT_140699948 = '\x01';
  }
  UNLOCK();
  if (!bVar129) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    uVar113 = 0;
  }
  else {
    uVar113 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    uVar113 = uVar113 ^ 1;
  }
  if (DAT_140699949 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10088 = (undefined1 (*) [16])&DAT_140699948;
    pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
    pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,(char)uVar113);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2150);
    goto LAB_140036cf0;
  }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  LOCK();
  bVar129 = TRANSPORT == '\0';
  if (bVar129) {
    TRANSPORT = '\x01';
  }
  UNLOCK();
  if (!bVar129) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&TRANSPORT);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    uVar114 = 0;
  }
  else {
    uVar114 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    uVar114 = uVar114 ^ 1;
  }
  if (DAT_140699831 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10088 = (undefined1 (*) [16])&TRANSPORT;
    pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
    pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,(char)uVar114);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2168);
    goto LAB_140036cf0;
  }
  uVar117 = (ulonglong)uStack_104b0 >> 0x20;
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  uStack_104b0 = (undefined1 (*) [16])CONCAT44((int)uVar117,uVar114);
  pauVar79 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
  pauVar82 = HOST_ID_0_llvm_14435704873730135342;
  uVar114 = (uint)param_2;
  uStack_103a8 = (ushort)pauVar79;
  uStack_103a6 = (ushort)((ulonglong)pauVar79 >> 0x10);
  uStack_103a4 = (ushort)((ulonglong)pauVar79 >> 0x20);
  uStack_103a2 = (ushort)((ulonglong)pauVar79 >> 0x30);
  uStack_103a0 = (ushort)param_2;
  uStack_1039e = (ushort)((ulonglong)param_2 >> 0x10);
  uVar112 = uStack_1039e;
  if (IS_HOST_0_llvm_14435704873730135342 == '\0') {
    uStack_104c0 = (undefined1 (*) [16])CONCAT44(uStack_104c0._4_4_,uVar113);
    uStack_10078 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
    if ((HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0) &&
       (uStack_10088 = HOST_ID_0_llvm_14435704873730135342,
       uStack_10078 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078),
       DAT_140699968 != 0)) {
      puVar99 = (undefined1 *)
                <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                ::hash_one::<&usize>(&DAT_140699970,&uStack_10088);
      unaff_R15 = DAT_140699950;
      bVar76 = (byte)((ulonglong)puVar99 >> 0x39);
      auVar133 = ZEXT216(CONCAT11(bVar76,bVar76));
      auVar133 = pshuflw(auVar133,auVar133,0);
      param_2 = (undefined1 (*) [16])0x0;
      while( true ) {
        uVar117 = (ulonglong)puVar99 & DAT_140699958;
        auVar137 = *(undefined1 (*) [16])(*DAT_140699950 + uVar117);
        auVar180[0] = -(auVar137[0] == auVar133[0]);
        auVar180[1] = -(auVar137[1] == auVar133[1]);
        auVar180[2] = -(auVar137[2] == auVar133[2]);
        auVar180[3] = -(auVar137[3] == auVar133[3]);
        auVar180[4] = -(auVar137[4] == auVar133[4]);
        auVar180[5] = -(auVar137[5] == auVar133[5]);
        auVar180[6] = -(auVar137[6] == auVar133[6]);
        auVar180[7] = -(auVar137[7] == auVar133[7]);
        auVar180[8] = -(auVar137[8] == auVar133[0]);
        auVar180[9] = -(auVar137[9] == auVar133[1]);
        auVar180[10] = -(auVar137[10] == auVar133[2]);
        auVar180[0xb] = -(auVar137[0xb] == auVar133[3]);
        auVar180[0xc] = -(auVar137[0xc] == auVar133[4]);
        auVar180[0xd] = -(auVar137[0xd] == auVar133[5]);
        auVar180[0xe] = -(auVar137[0xe] == auVar133[6]);
        auVar180[0xf] = -(auVar137[0xf] == auVar133[7]);
        uVar112 = (ushort)(SUB161(auVar180 >> 7,0) & 1) |
                  (ushort)(SUB161(auVar180 >> 0xf,0) & 1) << 1 |
                  (ushort)(SUB161(auVar180 >> 0x17,0) & 1) << 2 |
                  (ushort)(SUB161(auVar180 >> 0x1f,0) & 1) << 3 |
                  (ushort)(SUB161(auVar180 >> 0x27,0) & 1) << 4 |
                  (ushort)(SUB161(auVar180 >> 0x2f,0) & 1) << 5 |
                  (ushort)(SUB161(auVar180 >> 0x37,0) & 1) << 6 |
                  (ushort)(SUB161(auVar180 >> 0x3f,0) & 1) << 7 |
                  (ushort)(SUB161(auVar180 >> 0x47,0) & 1) << 8 |
                  (ushort)(SUB161(auVar180 >> 0x4f,0) & 1) << 9 |
                  (ushort)(SUB161(auVar180 >> 0x57,0) & 1) << 10 |
                  (ushort)(SUB161(auVar180 >> 0x5f,0) & 1) << 0xb |
                  (ushort)(SUB161(auVar180 >> 0x67,0) & 1) << 0xc |
                  (ushort)(SUB161(auVar180 >> 0x6f,0) & 1) << 0xd |
                  (ushort)(SUB161(auVar180 >> 0x77,0) & 1) << 0xe |
                  (ushort)(auVar180[0xf] >> 7) << 0xf;
        uVar113 = (uint)uVar112;
        while (uVar112 != 0) {
          uVar96 = 0;
          for (uVar95 = uVar113; (uVar95 & 1) == 0; uVar95 = uVar95 >> 1 | 0x80000000) {
            uVar96 = uVar96 + 1;
          }
          uVar81 = uVar96 + uVar117 & DAT_140699958;
          if (pauVar82 == *(undefined1 (**) [16])DAT_140699950[uVar81 * -5 + -5]) {
            pauStack_10080 = (undefined1 (*) [16])CONCAT44(pauStack_10080._4_4_,uVar114);
            uStack_10088 = pauVar79;
            uStack_10078 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
            if ((DAT_1406998da != '\x01') ||
               (uStack_10078 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078),
               DAT_140699860 != 2)) goto LAB_140029909;
            if (DAT_140699850 != 0xffffffff) {
              param_2 = DAT_140699848;
              lVar80 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&uStack_10088);
              if ((lVar80 == 0) && ((uint)param_2 < 500000000)) goto LAB_140029909;
            }
            pauStack_10080 = DAT_1406998e0;
            uStack_10088 = (undefined1 (*) [16])((ulonglong)uStack_10088 & 0xffffffffffffff00);
            DAT_140699848 = pauVar79;
            DAT_140699850 = uVar114;
            star_control_packet(&bStack_10528,&uStack_10088);
            unaff_R15 = (undefined1 (*) [16])(unaff_R15[uVar81 * -5 + -5] + 8);
            uVar85 = CONCAT17(bStack_10519,
                              CONCAT16(bStack_1051a,
                                       CONCAT15(bStack_1051b,
                                                CONCAT14(bStack_1051c,
                                                         CONCAT13(bStack_1051d,
                                                                  CONCAT12(bStack_1051e,
                                                                           CONCAT11(bStack_1051f,
                                                                                    bStack_10520))))
                                               )));
            in_stack_fffffffffffefaa8 =
                 (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),1);
            send_route_kind(&TRANSPORT,unaff_R15,uVar85,
                            CONCAT44(uStack_10514,
                                     CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518))),
                            in_stack_fffffffffffefaa8);
            lVar80 = CONCAT17(bStack_10521,
                              CONCAT16(bStack_10522,
                                       CONCAT15(bStack_10523,
                                                CONCAT14(bStack_10524,
                                                         CONCAT13(bStack_10525,
                                                                  CONCAT12(bStack_10526,
                                                                           CONCAT11(bStack_10527,
                                                                                    bStack_10528))))
                                               )));
            param_2 = (undefined1 (*) [16])0x0;
            if (lVar80 != 0) {
              pauVar82 = (undefined1 (*) [16])
                         __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar80,1);
              return pauVar82;
            }
            goto LAB_140029909;
          }
          uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
          uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
        }
        auVar166[0] = -(auVar137[0] == -1);
        auVar166[1] = -(auVar137[1] == -1);
        auVar166[2] = -(auVar137[2] == -1);
        auVar166[3] = -(auVar137[3] == -1);
        auVar166[4] = -(auVar137[4] == -1);
        auVar166[5] = -(auVar137[5] == -1);
        auVar166[6] = -(auVar137[6] == -1);
        auVar166[7] = -(auVar137[7] == -1);
        auVar166[8] = -(auVar137[8] == -1);
        auVar166[9] = -(auVar137[9] == -1);
        auVar166[10] = -(auVar137[10] == -1);
        auVar166[0xb] = -(auVar137[0xb] == -1);
        auVar166[0xc] = -(auVar137[0xc] == -1);
        auVar166[0xd] = -(auVar137[0xd] == -1);
        auVar166[0xe] = -(auVar137[0xe] == -1);
        auVar166[0xf] = -(auVar137[0xf] == -1);
        uStack_10078 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
        if ((((((((((((((((SUB161(auVar166 >> 7,0) & 1) != 0 || (SUB161(auVar166 >> 0xf,0) & 1) != 0
                         ) || (SUB161(auVar166 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar166 >> 0x1f,0) & 1) != 0) ||
                      (SUB161(auVar166 >> 0x27,0) & 1) != 0) ||
                     (SUB161(auVar166 >> 0x2f,0) & 1) != 0) || (SUB161(auVar166 >> 0x37,0) & 1) != 0
                    ) || (SUB161(auVar166 >> 0x3f,0) & 1) != 0) ||
                  (SUB161(auVar166 >> 0x47,0) & 1) != 0) || (SUB161(auVar166 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar166 >> 0x57,0) & 1) != 0) || (SUB161(auVar166 >> 0x5f,0) & 1) != 0)
              || (SUB161(auVar166 >> 0x67,0) & 1) != 0) || (SUB161(auVar166 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar166 >> 0x77,0) & 1) != 0) || auVar166[0xf] < '\0') break;
        puVar99 = param_2[1] + uVar117;
        param_2 = param_2 + 1;
      }
    }
LAB_140029909:
    uVar96 = (uint)param_2;
    if (((char)uStack_104b0 == '\0') &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699831 = '\x01';
      }
    }
    cVar72 = TRANSPORT;
    LOCK();
    TRANSPORT = '\0';
    UNLOCK();
    uVar113 = (uint)uStack_104c0;
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
    }
  }
  else {
    uVar96 = uVar114;
    if (DAT_1406998d8 != '\0') {
      if (DAT_140699840 != 0xffffffff) {
        pauVar82 = DAT_140699838;
        lVar80 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since(&uStack_103a8);
        uVar96 = (uint)pauVar82;
        if (lVar80 == 0) goto LAB_140029295;
      }
      pauVar82 = DAT_1406998c8;
      uStack_10438._0_1_ = (byte)pauVar79;
      uStack_10438._1_1_ = (byte)((ulonglong)pauVar79 >> 8);
      uStack_10438._2_1_ = (byte)((ulonglong)pauVar79 >> 0x10);
      uStack_10438._3_1_ = (byte)((ulonglong)pauVar79 >> 0x18);
      uStack_10438._4_4_ = (int)((ulonglong)pauVar79 >> 0x20);
      bStack_10430 = (byte)param_2;
      bStack_1042f = (byte)((ulonglong)param_2 >> 8);
      uStack_1042e = uVar112;
      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
      ::retain::
      <<host_probe[b94139f9089eb1d8]::net::Star>::refresh<host_probe[b94139f9089eb1d8]::net::route_blocked>::_closure_0_>
                (&DAT_140699868,&DAT_140699950);
      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::time::Instant),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
      ::retain::
      <<host_probe[b94139f9089eb1d8]::net::Star>::refresh<host_probe[b94139f9089eb1d8]::net::route_blocked>::_closure_1_>
                (&DAT_140699898,&DAT_140699950);
      auVar137 = _DAT_1406a0390;
      auVar133 = *DAT_140699950;
      uStack_104c0 = (undefined1 (*) [16])CONCAT44(uStack_104c0._4_4_,uVar113);
      pauStack_10448 = pauVar79;
      if (DAT_140699968 == 0) {
        lVar80 = 0;
      }
      else {
        uVar113 = ~(uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                  (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                  (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                  (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                  (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                  (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                  (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                  (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                  (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                  (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                  (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                  (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                  (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                  (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                  (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                 (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
        pauVar79 = DAT_140699950 + 1;
        unaff_XMM7_Ba = DAT_1406a0390;
        unaff_XMM7_Bb = DAT_1406a0390._1_1_;
        unaff_XMM7_Bc = DAT_1406a0390._2_1_;
        unaff_XMM7_Bd = DAT_1406a0390._3_1_;
        unaff_XMM7_Be = DAT_1406a0390._4_1_;
        unaff_XMM7_Bf = DAT_1406a0390._5_1_;
        unaff_XMM7_Bg = DAT_1406a0390._6_1_;
        unaff_XMM7_Bh = DAT_1406a0390._7_1_;
        unaff_XMM7_Bi = DAT_1406a0390._8_1_;
        unaff_XMM7_Bj = DAT_1406a0390._9_1_;
        unaff_XMM7_Bk = DAT_1406a0390._10_1_;
        unaff_XMM7_Bl = DAT_1406a0390._11_1_;
        unaff_XMM7_Bm = DAT_1406a0390._12_1_;
        unaff_XMM7_Bn = DAT_1406a0390._13_1_;
        unaff_XMM7_Bo = DAT_1406a0390._14_1_;
        unaff_XMM7_Bp = DAT_1406a0390._15_1_;
        pauVar123 = DAT_140699950;
        lVar80 = DAT_140699968;
        do {
          uVar112 = (ushort)uVar113;
          while (uVar112 == 0) {
            auVar133 = *pauVar79;
            pauVar123 = pauVar123 + -0x50;
            pauVar79 = pauVar79 + 1;
            uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                       (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                       (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                       (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                       (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                       (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                       (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                       (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                       (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                       (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                       (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                       (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                       (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                       (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                       (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                      (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
            uVar113 = (uint)uVar112;
          }
          uVar96 = 0;
          for (uVar95 = uVar113; (uVar95 & 1) == 0; uVar95 = uVar95 >> 1 | 0x80000000) {
            uVar96 = uVar96 + 1;
          }
          uVar83 = (ulonglong)uVar96;
          uVar113 = uVar113 - 1 & uVar113;
          lVar80 = lVar80 + -1;
          lVar120 = *(longlong *)pauVar123[uVar83 * -5 + -5];
          uStack_10088 = (undefined1 (*) [16])lVar120;
          uVar81 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                   ::hash_one::<&usize>(&DAT_1406998b8);
          unaff_R15 = (undefined1 (*) [16])(uVar81 >> 0x39);
          bVar76 = (byte)(uVar81 >> 0x38);
          bVar75 = bVar76 >> 1;
          auVar133 = ZEXT216(CONCAT11(bVar75,bVar75));
          auVar133 = pshuflw(auVar133,auVar133,0);
          lVar98 = 0;
          uVar117 = uVar81;
          while( true ) {
            uVar117 = uVar117 & DAT_1406998a0;
            auVar180 = *(undefined1 (*) [16])(*DAT_140699898 + uVar117);
            auVar165[0] = -(auVar180[0] == auVar133[0]);
            auVar165[1] = -(auVar180[1] == auVar133[1]);
            auVar165[2] = -(auVar180[2] == auVar133[2]);
            auVar165[3] = -(auVar180[3] == auVar133[3]);
            auVar165[4] = -(auVar180[4] == auVar133[4]);
            auVar165[5] = -(auVar180[5] == auVar133[5]);
            auVar165[6] = -(auVar180[6] == auVar133[6]);
            auVar165[7] = -(auVar180[7] == auVar133[7]);
            auVar165[8] = -(auVar180[8] == auVar133[0]);
            auVar165[9] = -(auVar180[9] == auVar133[1]);
            auVar165[10] = -(auVar180[10] == auVar133[2]);
            auVar165[0xb] = -(auVar180[0xb] == auVar133[3]);
            auVar165[0xc] = -(auVar180[0xc] == auVar133[4]);
            auVar165[0xd] = -(auVar180[0xd] == auVar133[5]);
            auVar165[0xe] = -(auVar180[0xe] == auVar133[6]);
            auVar165[0xf] = -(auVar180[0xf] == auVar133[7]);
            uVar112 = (ushort)(SUB161(auVar165 >> 7,0) & 1) |
                      (ushort)(SUB161(auVar165 >> 0xf,0) & 1) << 1 |
                      (ushort)(SUB161(auVar165 >> 0x17,0) & 1) << 2 |
                      (ushort)(SUB161(auVar165 >> 0x1f,0) & 1) << 3 |
                      (ushort)(SUB161(auVar165 >> 0x27,0) & 1) << 4 |
                      (ushort)(SUB161(auVar165 >> 0x2f,0) & 1) << 5 |
                      (ushort)(SUB161(auVar165 >> 0x37,0) & 1) << 6 |
                      (ushort)(SUB161(auVar165 >> 0x3f,0) & 1) << 7 |
                      (ushort)(SUB161(auVar165 >> 0x47,0) & 1) << 8 |
                      (ushort)(SUB161(auVar165 >> 0x4f,0) & 1) << 9 |
                      (ushort)(SUB161(auVar165 >> 0x57,0) & 1) << 10 |
                      (ushort)(SUB161(auVar165 >> 0x5f,0) & 1) << 0xb |
                      (ushort)(SUB161(auVar165 >> 0x67,0) & 1) << 0xc |
                      (ushort)(SUB161(auVar165 >> 0x6f,0) & 1) << 0xd |
                      (ushort)(SUB161(auVar165 >> 0x77,0) & 1) << 0xe |
                      (ushort)(auVar165[0xf] >> 7) << 0xf;
            uVar96 = (uint)uVar112;
            while (uVar112 != 0) {
              uVar95 = 0;
              for (uVar8 = uVar96; (uVar8 & 1) == 0; uVar8 = uVar8 >> 1 | 0x80000000) {
                uVar95 = uVar95 + 1;
              }
              if (*(longlong *)DAT_140699898[(uVar95 + uVar117 & DAT_1406998a0) * -6 + -6] ==
                  lVar120) goto LAB_140029190;
              uVar112 = (ushort)(uVar96 - 1) & (ushort)uVar96;
              uVar96 = CONCAT22((short)(uVar96 - 1 >> 0x10),uVar112);
            }
            auVar135[0] = -(auVar180[0] == -1);
            auVar135[1] = -(auVar180[1] == -1);
            auVar135[2] = -(auVar180[2] == -1);
            auVar135[3] = -(auVar180[3] == -1);
            auVar135[4] = -(auVar180[4] == -1);
            auVar135[5] = -(auVar180[5] == -1);
            auVar135[6] = -(auVar180[6] == -1);
            auVar135[7] = -(auVar180[7] == -1);
            auVar135[8] = -(auVar180[8] == -1);
            auVar135[9] = -(auVar180[9] == -1);
            auVar135[10] = -(auVar180[10] == -1);
            auVar135[0xb] = -(auVar180[0xb] == -1);
            auVar135[0xc] = -(auVar180[0xc] == -1);
            auVar135[0xd] = -(auVar180[0xd] == -1);
            auVar135[0xe] = -(auVar180[0xe] == -1);
            auVar135[0xf] = -(auVar180[0xf] == -1);
            if ((((((((((((((((SUB161(auVar135 >> 7,0) & 1) != 0 ||
                             (SUB161(auVar135 >> 0xf,0) & 1) != 0) ||
                            (SUB161(auVar135 >> 0x17,0) & 1) != 0) ||
                           (SUB161(auVar135 >> 0x1f,0) & 1) != 0) ||
                          (SUB161(auVar135 >> 0x27,0) & 1) != 0) ||
                         (SUB161(auVar135 >> 0x2f,0) & 1) != 0) ||
                        (SUB161(auVar135 >> 0x37,0) & 1) != 0) ||
                       (SUB161(auVar135 >> 0x3f,0) & 1) != 0) ||
                      (SUB161(auVar135 >> 0x47,0) & 1) != 0) ||
                     (SUB161(auVar135 >> 0x4f,0) & 1) != 0) || (SUB161(auVar135 >> 0x57,0) & 1) != 0
                    ) || (SUB161(auVar135 >> 0x5f,0) & 1) != 0) ||
                  (SUB161(auVar135 >> 0x67,0) & 1) != 0) || (SUB161(auVar135 >> 0x6f,0) & 1) != 0)
                || (SUB161(auVar135 >> 0x77,0) & 1) != 0) || auVar135[0xf] < '\0') break;
            uVar117 = uVar117 + lVar98 + 0x10;
            lVar98 = lVar98 + 0x10;
          }
          if (DAT_1406998a8 == 0) {
            <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,(host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::time::Instant))>>
            ::reserve_rehash::
            <hashbrown[ad6d4a1843b2832d]::map::make_hasher<u64,(host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::time::Instant),std[3bf9d48a0c3997f0]::hash::random::RandomState>::_closure_0_>
                      (&DAT_140699898,1,&DAT_1406998b8);
          }
          pauVar89 = DAT_140699898;
          pauStack_10048 = *(undefined1 (**) [16])(pauVar123[uVar83 * -5 + -1] + 8);
          uVar85 = *(undefined8 *)(pauVar123[uVar83 * -5 + -5] + 8);
          pauStack_10080 = *(undefined1 (**) [16])pauVar123[uVar83 * -5 + -4];
          uVar4 = *(undefined8 *)(pauVar123[uVar83 * -5 + -4] + 8);
          uVar9 = *(undefined8 *)pauVar123[uVar83 * -5 + -3];
          uVar10 = *(undefined8 *)*(undefined1 (*) [16])(pauVar123[uVar83 * -5 + -3] + 8);
          ppauStack_10060 = *(undefined1 (***) [16])pauVar123[uVar83 * -5 + -2];
          auVar180 = *(undefined1 (*) [16])(pauVar123[uVar83 * -5 + -3] + 8);
          pauStack_10058 =
               *(undefined1 (**) [16])*(undefined1 (*) [16])(pauVar123[uVar83 * -5 + -2] + 8);
          pauStack_10050 = *(undefined1 (**) [16])pauVar123[uVar83 * -5 + -1];
          auVar166 = *(undefined1 (*) [16])(pauVar123[uVar83 * -5 + -2] + 8);
          pauStack_10068._0_1_ = (byte)uVar10;
          pauStack_10068._1_7_ = (undefined7)((ulonglong)uVar10 >> 8);
          uStack_10078._0_4_ = (uint)uVar4;
          uStack_10078._4_4_ = (uint)((ulonglong)uVar4 >> 0x20);
          abStack_10070[0] = (byte)uVar9;
          abStack_10070[1] = (byte)((ulonglong)uVar9 >> 8);
          uStack_1006e = (undefined6)((ulonglong)uVar9 >> 0x10);
          uVar81 = uVar81 & DAT_1406998a0;
          auVar133 = *(undefined1 (*) [16])(*DAT_140699898 + uVar81);
          uVar112 = (ushort)(SUB161(auVar133 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar133[0xf] >> 7) << 0xf;
          uVar96 = (uint)uVar112;
          if (uVar112 == 0) {
            lVar98 = 0x10;
            do {
              uVar81 = uVar81 + lVar98 & DAT_1406998a0;
              auVar133 = *(undefined1 (*) [16])(*DAT_140699898 + uVar81);
              lVar98 = lVar98 + 0x10;
              uVar96 = (uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                      (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                      (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                      (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                      (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                      (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                      (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                      (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                      (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                      (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                      (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                      (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                      (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                      (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                      (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                     (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
            } while (uVar96 == 0);
          }
          uVar95 = 0;
          for (; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
            uVar95 = uVar95 + 1;
          }
          uVar117 = uVar95 + uVar81 & DAT_1406998a0;
          bVar75 = (*DAT_140699898)[uVar117];
          if (-1 < (char)bVar75) {
            auVar133 = *DAT_140699898;
            uVar96 = 0;
            for (uVar95 = (uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
                (uVar95 & 1) == 0; uVar95 = uVar95 >> 1 | 0x80000000) {
              uVar96 = uVar96 + 1;
            }
            uVar117 = (ulonglong)uVar96;
            bVar75 = (*DAT_140699898)[uVar117];
          }
          uVar81 = uVar117 - 0x10 & DAT_1406998a0;
          bVar76 = bVar76 >> 1;
          (*DAT_140699898)[uVar117] = bVar76;
          pauVar89[1][uVar81] = bVar76;
          *(longlong *)pauVar89[uVar117 * -6 + -6] = lVar120;
          *(undefined8 *)(pauVar89[uVar117 * -6 + -6] + 8) = uVar85;
          *(undefined1 (**) [16])((longlong)(pauVar89[uVar117 * -6 + -6] + 8) + 8) = pauStack_10080;
          *(undefined8 *)(pauVar89[uVar117 * -6 + -5] + 8) = uVar4;
          *(undefined8 *)((longlong)(pauVar89[uVar117 * -6 + -5] + 8) + 8) = uVar9;
          *(undefined1 (*) [16])(pauVar89[uVar117 * -6 + -4] + 8) = auVar180;
          *(undefined1 (*) [16])(pauVar89[uVar117 * -6 + -3] + 8) = auVar166;
          *(undefined1 (**) [16])(pauVar89[uVar117 * -6 + -2] + 8) = pauStack_10048;
          *(undefined1 (**) [16])pauVar89[uVar117 * -6 + -1] = pauStack_10448;
          *(uint *)(pauVar89[uVar117 * -6 + -1] + 8) = uVar114;
          auVar133._0_8_ = CONCAT71(0,bVar75 & 1);
          auVar133._8_4_ = auVar137._8_4_;
          auVar133._12_4_ = auVar137._12_4_;
          DAT_1406998a8 = DAT_1406998a8 - auVar133._0_8_;
          lRam00000001406998b0 = lRam00000001406998b0 - auVar133._8_8_;
LAB_140029190:
        } while (lVar80 != 0);
        auVar133 = *DAT_140699950;
        lVar80 = DAT_140699968;
      }
      uStack_10078 = (undefined1 (*) [16])(*DAT_140699950 + DAT_140699958 + 1);
      uVar112 = ~((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                  (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                  (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                  (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                  (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                  (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                  (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                  (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                  (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                  (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                  (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                  (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                  (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                  (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                  (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                 (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
      bStack_10528 = (byte)&uStack_10329;
      bStack_10527 = (byte)((ulonglong)&uStack_10329 >> 8);
      bStack_10526 = (byte)((ulonglong)&uStack_10329 >> 0x10);
      bStack_10525 = (byte)((ulonglong)&uStack_10329 >> 0x18);
      bStack_10524 = (byte)((ulonglong)&uStack_10329 >> 0x20);
      bStack_10523 = (byte)((ulonglong)&uStack_10329 >> 0x28);
      bStack_10522 = (byte)((ulonglong)&uStack_10329 >> 0x30);
      bStack_10521 = (byte)((ulonglong)&uStack_10329 >> 0x38);
      bStack_10520 = 0x38;
      bStack_1051f = 0x98;
      bStack_1051e = 0x69;
      bStack_1051d = 0x40;
      bStack_1051c = 1;
      bStack_1051b = 0;
      bStack_1051a = 0;
      bStack_10519 = 0;
      bStack_10518 = (byte)&uStack_10438;
      bStack_10517 = (byte)((ulonglong)&uStack_10438 >> 8);
      uStack_10516 = (ushort)((ulonglong)&uStack_10438 >> 0x10);
      uStack_10514 = (uint)((ulonglong)&uStack_10438 >> 0x20);
      uStack_10088 = DAT_140699950;
      pauStack_10080 = DAT_140699950 + 1;
      abStack_10070[0] = (byte)uVar112;
      abStack_10070[1] = (byte)(uVar112 >> 8);
      DAT_1406998c8 =
           (undefined1 (*) [16])
           <hashbrown[ad6d4a1843b2832d]::raw::RawIterRange<(u64,host_probe[b94139f9089eb1d8]::net::Route)>>
           ::fold_impl::
           <<hashbrown[ad6d4a1843b2832d]::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold<usize,core[505b25137b8ba7f]::iter::adapters::map::map_fold<(&u64,&host_probe[b94139f9089eb1d8]::net::Route),usize,usize,<core[505b25137b8ba7f]::iter::adapters::filter::Filter<_,_>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::count::to_usize<(&u64,&host_probe[b94139f9089eb1d8]::net::Route),<host_probe[b94139f9089eb1d8]::net::Star>::refresh<host_probe[b94139f9089eb1d8]::net::route_blocked>::_closure_2_>::_closure_0_,<usize_as_core[505b25137b8ba7f]::iter::traits::accum::Sum>::sum<core[505b25137b8ba7f]::iter::adapters::map::Map<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,<core[505b25137b8ba7f]::iter::adapters::filter::Filter<_,_>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::count::to_usize<(&u64,&host_probe[b94139f9089eb1d8]::net::Route),<host_probe[b94139f9089eb1d8]::net::Star>::refresh<host_probe[b94139f9089eb1d8]::net::route_blocked>::_closure_2_>::_closure_0_>>::_closure_0_>::_closure_0_>::_closure_0_,usize>
                     (&uStack_10088,lVar80,0,&bStack_10528);
      pauVar79 = pauStack_10448;
      if (DAT_1406998d8 != DAT_1406998d9) {
        DAT_1406998d9 = DAT_1406998d8;
        DAT_1406998d0 = DAT_1406998d0 + 1;
        DAT_140699840 = 0xffffffff;
      }
      param_2 = pauVar82;
      if (pauVar82 != DAT_1406998c8) {
        bStack_10528 = 200;
        bStack_10527 = 0x98;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = 0x80;
        bStack_1051f = 0x32;
        bStack_1051e = 0x69;
        bStack_1051d = 0x40;
        bStack_1051c = 1;
        bStack_1051b = 0;
        bStack_1051a = 0;
        bStack_10519 = 0;
        alloc[246c2e7857c81348]::fmt::format::format_inner
                  (&uStack_10088,&DAT_1406a2180,&bStack_10528);
        pauVar123 = pauStack_10080;
        pauVar82 = uStack_10088;
        param_2 = uStack_10078;
        host::log(pauStack_10080);
        unaff_R15 = (undefined1 (*) [16])0x0;
        if (pauVar82 != (undefined1 (*) [16])0x0) {
          pauVar82 = (undefined1 (*) [16])
                     __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar123,pauVar82,1);
          return pauVar82;
        }
      }
      DAT_140699838 = pauVar79;
      DAT_140699840 = uVar114;
      if (DAT_140699968 != 0) {
        unaff_R15 = (undefined1 (*) [16])0x0;
        auVar133 = *DAT_140699950;
        uVar113 = ~(uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                  (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                  (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                  (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                  (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                  (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                  (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                  (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                  (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                  (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                  (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                  (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                  (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                  (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                  (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                 (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
        pauVar82 = DAT_140699950 + 1;
        pauVar79 = DAT_140699950;
        lVar80 = DAT_140699968;
        do {
          uVar112 = (ushort)uVar113;
          uVar114 = uVar113;
          while (uVar112 == 0) {
            auVar133 = *pauVar82;
            pauVar79 = pauVar79 + -0x50;
            pauVar82 = pauVar82 + 1;
            uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                       (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                       (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                       (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                       (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                       (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                       (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                       (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                       (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                       (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                       (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                       (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                       (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                       (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                       (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                      (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
            uVar114 = (uint)uVar112;
          }
          uVar113 = uVar114 - 1 & uVar114;
          lVar80 = lVar80 + -1;
          if (DAT_140699880 != 0) {
            uVar96 = 0;
            for (; (uVar114 & 1) == 0; uVar114 = uVar114 >> 1 | 0x80000000) {
              uVar96 = uVar96 + 1;
            }
            uVar81 = (ulonglong)uVar96;
            uVar117 = *(ulonglong *)pauVar79[uVar81 * -5 + -5];
            uVar121 = DAT_140699890 ^ 0x646f72616e646f6d;
            uVar125 = DAT_140699890 ^ 0x7465646279746573 ^ uVar117;
            uVar118 = (DAT_140699888 ^ 0x736f6d6570736575) + uVar121;
            uVar83 = (DAT_140699888 ^ 0x6c7967656e657261) + uVar125;
            uVar121 = (uVar121 << 0xd | uVar121 >> 0x33) ^ uVar118;
            uVar126 = (uVar125 << 0x10 | uVar125 >> 0x30) ^ uVar83;
            uVar83 = uVar83 + uVar121;
            uVar118 = (uVar118 << 0x20 | uVar118 >> 0x20) + uVar126;
            uVar125 = (uVar121 << 0x11 | uVar121 >> 0x2f) ^ uVar83;
            uVar121 = uVar118 ^ 0x800000000000000 ^ (uVar126 << 0x15 | uVar126 >> 0x2b);
            uVar126 = (uVar118 ^ uVar117) + uVar125;
            uVar83 = (uVar83 << 0x20 | uVar83 >> 0x20) + uVar121;
            uVar125 = (uVar125 << 0xd | uVar125 >> 0x33) ^ uVar126;
            uVar118 = (uVar121 << 0x10 | uVar121 >> 0x30) ^ uVar83;
            uVar83 = uVar83 + uVar125;
            uVar126 = (uVar126 << 0x20 | uVar126 >> 0x20) + uVar118;
            uVar121 = (uVar125 << 0x11 | uVar125 >> 0x2f) ^ uVar83;
            uVar118 = (uVar118 << 0x15 | uVar118 >> 0x2b) ^ uVar126;
            uVar125 = (uVar126 ^ 0x800000000000000) + uVar121;
            uVar83 = ((uVar83 << 0x20 | uVar83 >> 0x20) ^ 0xff) + uVar118;
            uVar121 = (uVar121 << 0xd | uVar121 >> 0x33) ^ uVar125;
            uVar118 = (uVar118 << 0x10 | uVar118 >> 0x30) ^ uVar83;
            uVar83 = uVar83 + uVar121;
            uVar125 = (uVar125 << 0x20 | uVar125 >> 0x20) + uVar118;
            uVar121 = (uVar121 << 0x11 | uVar121 >> 0x2f) ^ uVar83;
            uVar118 = (uVar118 << 0x15 | uVar118 >> 0x2b) ^ uVar125;
            uVar125 = uVar125 + uVar121;
            uVar83 = (uVar83 << 0x20 | uVar83 >> 0x20) + uVar118;
            uVar121 = (uVar121 << 0xd | uVar121 >> 0x33) ^ uVar125;
            uVar118 = (uVar118 << 0x10 | uVar118 >> 0x30) ^ uVar83;
            uVar83 = uVar83 + uVar121;
            uVar125 = (uVar125 << 0x20 | uVar125 >> 0x20) + uVar118;
            uVar121 = (uVar121 << 0x11 | uVar121 >> 0x2f) ^ uVar83;
            uVar118 = (uVar118 << 0x15 | uVar118 >> 0x2b) ^ uVar125;
            uVar83 = (uVar83 << 0x20 | uVar83 >> 0x20) + uVar118;
            uVar121 = (uVar121 << 0xd | uVar121 >> 0x33) ^ uVar125 + uVar121;
            uVar118 = (uVar118 << 0x10 | uVar118 >> 0x30) ^ uVar83;
            uVar83 = uVar83 + uVar121;
            puVar99 = (undefined1 *)
                      ((uVar83 << 0x20 | uVar83 >> 0x20) ^ (uVar121 << 0x11 | uVar121 >> 0x2f) ^
                       (uVar118 << 0x15 | uVar118 >> 0x2b) ^ uVar83);
            bVar76 = (byte)((ulonglong)puVar99 >> 0x39);
            auVar133 = ZEXT216(CONCAT11(bVar76,bVar76));
            auVar133 = pshuflw(auVar133,auVar133,0);
            lVar120 = 0;
            while( true ) {
              param_2 = (undefined1 (*) [16])((ulonglong)puVar99 & DAT_140699870);
              auVar137 = *(undefined1 (*) [16])(*param_2 + DAT_140699868);
              auVar167[0] = -(auVar137[0] == auVar133[0]);
              auVar167[1] = -(auVar137[1] == auVar133[1]);
              auVar167[2] = -(auVar137[2] == auVar133[2]);
              auVar167[3] = -(auVar137[3] == auVar133[3]);
              auVar167[4] = -(auVar137[4] == auVar133[4]);
              auVar167[5] = -(auVar137[5] == auVar133[5]);
              auVar167[6] = -(auVar137[6] == auVar133[6]);
              auVar167[7] = -(auVar137[7] == auVar133[7]);
              auVar167[8] = -(auVar137[8] == auVar133[0]);
              auVar167[9] = -(auVar137[9] == auVar133[1]);
              auVar167[10] = -(auVar137[10] == auVar133[2]);
              auVar167[0xb] = -(auVar137[0xb] == auVar133[3]);
              auVar167[0xc] = -(auVar137[0xc] == auVar133[4]);
              auVar167[0xd] = -(auVar137[0xd] == auVar133[5]);
              auVar167[0xe] = -(auVar137[0xe] == auVar133[6]);
              auVar167[0xf] = -(auVar137[0xf] == auVar133[7]);
              uVar112 = (ushort)(SUB161(auVar167 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar167 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar167 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar167 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar167 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar167 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar167 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar167 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar167 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar167 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar167 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar167 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar167 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar167 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar167 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar167[0xf] >> 7) << 0xf;
              uVar114 = (uint)uVar112;
              while (uVar112 != 0) {
                uVar96 = 0;
                for (uVar95 = uVar114; (uVar95 & 1) == 0; uVar95 = uVar95 >> 1 | 0x80000000) {
                  uVar96 = uVar96 + 1;
                }
                lVar98 = ((ulonglong)(*param_2 + uVar96) & DAT_140699870) * -0x50;
                if (uVar117 == *(ulonglong *)(DAT_140699868 + -0x50 + lVar98)) {
                  lVar98 = DAT_140699868 + lVar98;
                  uVar112 = *(ushort *)(lVar98 + -0x38);
                  param_2 = (undefined1 (*) [16])(ulonglong)uVar112;
                  if (uVar112 != *(ushort *)(pauVar79[uVar81 * -5 + -4] + 8)) goto LAB_140029900;
                  if (uVar112 == 0) {
                    param_2 = (undefined1 (*) [16])(ulonglong)*(ushort *)(lVar98 + -0x32);
                    if ((*(ushort *)(lVar98 + -0x32) !=
                         *(ushort *)(pauVar79[uVar81 * -5 + -4] + 0xe)) ||
                       (param_2 = (undefined1 (*) [16])(ulonglong)*(uint *)(lVar98 + -0x36),
                       *(uint *)(lVar98 + -0x36) != *(uint *)(pauVar79[uVar81 * -5 + -4] + 10)))
                    goto LAB_140029900;
                  }
                  else {
                    param_2 = (undefined1 (*) [16])(ulonglong)*(ushort *)(lVar98 + -0x1c);
                    if ((*(ushort *)(lVar98 + -0x1c) != *(ushort *)(pauVar79[uVar81 * -5 + -2] + 4))
                       || ((param_2 = (undefined1 (*) [16])(ulonglong)*(uint *)(lVar98 + -0x24),
                           *(uint *)(lVar98 + -0x24) != *(uint *)(pauVar79[uVar81 * -5 + -3] + 0xc)
                           || (param_2 = (undefined1 (*) [16])(ulonglong)*(uint *)(lVar98 + -0x20),
                              *(uint *)(lVar98 + -0x20) != *(uint *)pauVar79[uVar81 * -5 + -2]))))
                    goto LAB_140029900;
                    auVar137[0] = -(pauVar79[uVar81 * -5 + -4][0xc] == *(char *)(lVar98 + -0x34));
                    auVar137[1] = -(pauVar79[uVar81 * -5 + -4][0xd] == *(char *)(lVar98 + -0x33));
                    auVar137[2] = -(pauVar79[uVar81 * -5 + -4][0xe] == *(char *)(lVar98 + -0x32));
                    auVar137[3] = -(pauVar79[uVar81 * -5 + -4][0xf] == *(char *)(lVar98 + -0x31));
                    auVar137[4] = -(pauVar79[uVar81 * -5 + -3][0] == *(char *)(lVar98 + -0x30));
                    auVar137[5] = -(pauVar79[uVar81 * -5 + -3][1] == *(char *)(lVar98 + -0x2f));
                    auVar137[6] = -(pauVar79[uVar81 * -5 + -3][2] == *(char *)(lVar98 + -0x2e));
                    auVar137[7] = -(pauVar79[uVar81 * -5 + -3][3] == *(char *)(lVar98 + -0x2d));
                    auVar137[8] = -(pauVar79[uVar81 * -5 + -3][4] == *(char *)(lVar98 + -0x2c));
                    auVar137[9] = -(pauVar79[uVar81 * -5 + -3][5] == *(char *)(lVar98 + -0x2b));
                    auVar137[10] = -(pauVar79[uVar81 * -5 + -3][6] == *(char *)(lVar98 + -0x2a));
                    auVar137[0xb] = -(pauVar79[uVar81 * -5 + -3][7] == *(char *)(lVar98 + -0x29));
                    auVar137[0xc] = -(pauVar79[uVar81 * -5 + -3][8] == *(char *)(lVar98 + -0x28));
                    auVar137[0xd] = -(pauVar79[uVar81 * -5 + -3][9] == *(char *)(lVar98 + -0x27));
                    auVar137[0xe] = -(pauVar79[uVar81 * -5 + -3][10] == *(char *)(lVar98 + -0x26));
                    auVar137[0xf] = -(pauVar79[uVar81 * -5 + -3][0xb] == *(char *)(lVar98 + -0x25));
                    uVar112 = (ushort)(SUB161(auVar137 >> 7,0) & 1) |
                              (ushort)(SUB161(auVar137 >> 0xf,0) & 1) << 1 |
                              (ushort)(SUB161(auVar137 >> 0x17,0) & 1) << 2 |
                              (ushort)(SUB161(auVar137 >> 0x1f,0) & 1) << 3 |
                              (ushort)(SUB161(auVar137 >> 0x27,0) & 1) << 4 |
                              (ushort)(SUB161(auVar137 >> 0x2f,0) & 1) << 5 |
                              (ushort)(SUB161(auVar137 >> 0x37,0) & 1) << 6 |
                              (ushort)(SUB161(auVar137 >> 0x3f,0) & 1) << 7 |
                              (ushort)(SUB161(auVar137 >> 0x47,0) & 1) << 8 |
                              (ushort)(SUB161(auVar137 >> 0x4f,0) & 1) << 9 |
                              (ushort)(SUB161(auVar137 >> 0x57,0) & 1) << 10 |
                              (ushort)(SUB161(auVar137 >> 0x5f,0) & 1) << 0xb |
                              (ushort)(SUB161(auVar137 >> 0x67,0) & 1) << 0xc |
                              (ushort)(SUB161(auVar137 >> 0x6f,0) & 1) << 0xd |
                              (ushort)(SUB161(auVar137 >> 0x77,0) & 1) << 0xe |
                              (ushort)(auVar137[0xf] >> 7) << 0xf;
                    param_2 = (undefined1 (*) [16])(ulonglong)uVar112;
                    if (uVar112 != 0xffff) goto LAB_140029900;
                  }
                  bVar76 = pauVar79[uVar81 * -5 + -2][8];
                  param_2 = (undefined1 (*) [16])(ulonglong)bVar76;
                  if (*(char *)(lVar98 + -0x18) == '\x01') {
                    if ((bVar76 == 0) ||
                       (auVar138[0] = -(pauVar79[uVar81 * -5 + -2][9] == *(char *)(lVar98 + -0x17)),
                       auVar138[1] = -(pauVar79[uVar81 * -5 + -2][10] == *(char *)(lVar98 + -0x16)),
                       auVar138[2] = -(pauVar79[uVar81 * -5 + -2][0xb] == *(char *)(lVar98 + -0x15))
                       , auVar138[3] = -(pauVar79[uVar81 * -5 + -2][0xc] ==
                                        *(char *)(lVar98 + -0x14)),
                       auVar138[4] = -(pauVar79[uVar81 * -5 + -2][0xd] == *(char *)(lVar98 + -0x13))
                       , auVar138[5] = -(pauVar79[uVar81 * -5 + -2][0xe] ==
                                        *(char *)(lVar98 + -0x12)),
                       auVar138[6] = -(pauVar79[uVar81 * -5 + -2][0xf] == *(char *)(lVar98 + -0x11))
                       , auVar138[7] = -(pauVar79[uVar81 * -5 + -1][0] == *(char *)(lVar98 + -0x10))
                       , auVar138[8] = -(pauVar79[uVar81 * -5 + -1][1] == *(char *)(lVar98 + -0xf)),
                       auVar138[9] = -(pauVar79[uVar81 * -5 + -1][2] == *(char *)(lVar98 + -0xe)),
                       auVar138[10] = -(pauVar79[uVar81 * -5 + -1][3] == *(char *)(lVar98 + -0xd)),
                       auVar138[0xb] = -(pauVar79[uVar81 * -5 + -1][4] == *(char *)(lVar98 + -0xc)),
                       auVar138[0xc] = -(pauVar79[uVar81 * -5 + -1][5] == *(char *)(lVar98 + -0xb)),
                       auVar138[0xd] = -(pauVar79[uVar81 * -5 + -1][6] == *(char *)(lVar98 + -10)),
                       auVar138[0xe] = -(pauVar79[uVar81 * -5 + -1][7] == *(char *)(lVar98 + -9)),
                       auVar138[0xf] = -(pauVar79[uVar81 * -5 + -1][8] == *(char *)(lVar98 + -8)),
                       (ushort)((ushort)(SUB161(auVar138 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar138 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar138 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar138 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar138 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar138 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar138 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar138 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar138 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar138 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar138 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar138 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar138 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar138 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar138 >> 0x77,0) & 1) << 0xe |
                               (ushort)(auVar138[0xf] >> 7) << 0xf) != 0xffff)) goto LAB_140029900;
                  }
                  else if (bVar76 != 0) goto LAB_140029900;
                  param_2 = (undefined1 (*) [16])(pauVar79[uVar81 * -5 + -4] + 8);
                  cVar72 = is_blocked();
                  if (cVar72 == '\0') {
                    pauStack_10080 = *(undefined1 (**) [16])pauVar79[uVar81 * -5 + -5];
                    uStack_10078._0_4_ = (uint)DAT_1406998d0;
                    uStack_10078._4_4_ = (uint)((ulonglong)DAT_1406998d0 >> 0x20);
                    uStack_10088 = (undefined1 (*) [16])
                                   CONCAT71(CONCAT61(uStack_10088._2_6_,DAT_1406998d9),1);
                    star_control_packet(&bStack_10528,&uStack_10088);
                    uVar85 = CONCAT17(bStack_10519,
                                      CONCAT16(bStack_1051a,
                                               CONCAT15(bStack_1051b,
                                                        CONCAT14(bStack_1051c,
                                                                 CONCAT13(bStack_1051d,
                                                                          CONCAT12(bStack_1051e,
                                                                                   CONCAT11(
                                                  bStack_1051f,bStack_10520)))))));
                    in_stack_fffffffffffefaa8 =
                         (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),1)
                    ;
                    send_route_kind(&TRANSPORT,pauVar79[uVar81 * -5 + -5] + 8,uVar85,
                                    CONCAT44(uStack_10514,
                                             CONCAT22(uStack_10516,
                                                      CONCAT11(bStack_10517,bStack_10518))),
                                    in_stack_fffffffffffefaa8);
                    param_2 = (undefined1 (*) [16])
                              CONCAT17(bStack_10521,
                                       CONCAT16(bStack_10522,
                                                CONCAT15(bStack_10523,
                                                         CONCAT14(bStack_10524,
                                                                  CONCAT13(bStack_10525,
                                                                           CONCAT12(bStack_10526,
                                                                                    CONCAT11(
                                                  bStack_10527,bStack_10528)))))));
                    if (param_2 != (undefined1 (*) [16])0x0) {
                      pauVar82 = (undefined1 (*) [16])
                                 __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,param_2,1);
                      return pauVar82;
                    }
                  }
                  goto LAB_140029900;
                }
                uVar112 = (ushort)(uVar114 - 1) & (ushort)uVar114;
                uVar114 = CONCAT22((short)(uVar114 - 1 >> 0x10),uVar112);
              }
              auVar136[0] = -(auVar137[0] == -1);
              auVar136[1] = -(auVar137[1] == -1);
              auVar136[2] = -(auVar137[2] == -1);
              auVar136[3] = -(auVar137[3] == -1);
              auVar136[4] = -(auVar137[4] == -1);
              auVar136[5] = -(auVar137[5] == -1);
              auVar136[6] = -(auVar137[6] == -1);
              auVar136[7] = -(auVar137[7] == -1);
              auVar136[8] = -(auVar137[8] == -1);
              auVar136[9] = -(auVar137[9] == -1);
              auVar136[10] = -(auVar137[10] == -1);
              auVar136[0xb] = -(auVar137[0xb] == -1);
              auVar136[0xc] = -(auVar137[0xc] == -1);
              auVar136[0xd] = -(auVar137[0xd] == -1);
              auVar136[0xe] = -(auVar137[0xe] == -1);
              auVar136[0xf] = -(auVar137[0xf] == -1);
              if ((((((((((((((((SUB161(auVar136 >> 7,0) & 1) != 0 ||
                               (SUB161(auVar136 >> 0xf,0) & 1) != 0) ||
                              (SUB161(auVar136 >> 0x17,0) & 1) != 0) ||
                             (SUB161(auVar136 >> 0x1f,0) & 1) != 0) ||
                            (SUB161(auVar136 >> 0x27,0) & 1) != 0) ||
                           (SUB161(auVar136 >> 0x2f,0) & 1) != 0) ||
                          (SUB161(auVar136 >> 0x37,0) & 1) != 0) ||
                         (SUB161(auVar136 >> 0x3f,0) & 1) != 0) ||
                        (SUB161(auVar136 >> 0x47,0) & 1) != 0) ||
                       (SUB161(auVar136 >> 0x4f,0) & 1) != 0) ||
                      (SUB161(auVar136 >> 0x57,0) & 1) != 0) ||
                     (SUB161(auVar136 >> 0x5f,0) & 1) != 0) || (SUB161(auVar136 >> 0x67,0) & 1) != 0
                    ) || (SUB161(auVar136 >> 0x6f,0) & 1) != 0) ||
                  (SUB161(auVar136 >> 0x77,0) & 1) != 0) || auVar136[0xf] < '\0') break;
              puVar99 = param_2[1] + lVar120;
              lVar120 = lVar120 + 0x10;
            }
          }
LAB_140029900:
        } while (lVar80 != 0);
      }
      goto LAB_140029909;
    }
LAB_140029295:
    if ((((char)uStack_104b0 == '\0') &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar72 == '\0')
       ) {
      DAT_140699831 = '\x01';
    }
    cVar72 = TRANSPORT;
    LOCK();
    TRANSPORT = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
    }
  }
  if (((char)uVar113 == '\0') &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar72 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
  cVar72 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar72 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
  if (IS_HOST_0_llvm_14435704873730135342 != '\0') {
    LOCK();
    bVar129 = LAST_SHARE == '\0';
    if (bVar129) {
      LAST_SHARE = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LAST_SHARE);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
    }
    if (DAT_140699591 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&LAST_SHARE;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2520);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    if (DAT_1406995a0 != 0xffffffff) {
      pauStack_10080._4_4_ = (undefined4)((ulonglong)pauStack_10080 >> 0x20);
      pauStack_10080 = (undefined1 (*) [16])CONCAT44(pauStack_10080._4_4_,DAT_1406995a0);
      uStack_10088 = DAT_140699598;
      lVar80 = <std[3bf9d48a0c3997f0]::time::Instant>::elapsed(&uStack_10088);
      if (lVar80 == 0) {
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar72 == '\0') {
            DAT_140699591 = '\x01';
          }
        }
        cVar72 = LAST_SHARE;
        LOCK();
        LAST_SHARE = '\0';
        UNLOCK();
        if (cVar72 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_SHARE);
        }
        goto LAB_14002a8d2;
      }
    }
    DAT_140699598 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
    DAT_1406995a0 = uVar96;
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699591 = '\x01';
      }
    }
    cVar72 = LAST_SHARE;
    LOCK();
    LAST_SHARE = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_SHARE);
    }
    pauStack_101b8 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
    sStack_101b0 = (short)uVar96;
    uStack_101ae = (ushort)(uVar96 >> 0x10);
    LOCK();
    bVar129 = DAT_140699948 == '\0';
    if (bVar129) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
    }
    if (DAT_140699949 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&DAT_140699948;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2538);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10078 = (undefined1 (*) [16])(*DAT_140699950 + DAT_140699958 + 1);
    auVar133 = *DAT_140699950;
    uVar112 = ~((ushort)(SUB161(auVar133 >> 7,0) & 1) | (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1
                | (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
    pauStack_10080 = DAT_140699950 + 1;
    abStack_10070[0] = (byte)uVar112;
    abStack_10070[1] = (byte)(uVar112 >> 8);
    pauStack_10068._0_1_ = (byte)DAT_140699968;
    pauStack_10068._1_7_ = (undefined7)((ulonglong)DAT_140699968 >> 8);
    ppauStack_10060 = &pauStack_101b8;
    uVar96 = (uint)&uStack_10088;
    uStack_10088 = DAT_140699950;
    <alloc[246c2e7857c81348]::vec::Vec<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr),core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#1}>,host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#2}>>>
    ::from_iter(&uStack_103a8);
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699949 = '\x01';
      }
    }
    cVar72 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    uVar117 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
    if (1 < uVar117) {
      LOCK();
      bVar129 = TRANSPORT == '\0';
      if (bVar129) {
        TRANSPORT = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&TRANSPORT);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar76 = 0;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar76 = bVar76 ^ 1;
      }
      if (DAT_140699831 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
        uStack_10088 = (undefined1 (*) [16])&TRANSPORT;
        pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
        pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                   &
                   PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
                   ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2550
                  );
        goto LAB_140036cf0;
      }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      if (DAT_1406998d8 != '\x01') {
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar72 == '\0') {
            DAT_140699831 = '\x01';
          }
        }
        cVar72 = TRANSPORT;
        LOCK();
        TRANSPORT = '\0';
        UNLOCK();
        if (cVar72 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
        }
        LOCK();
        bVar129 = PUBLIC_SELF == '\0';
        if (bVar129) {
          PUBLIC_SELF = '\x01';
        }
        UNLOCK();
        if (!bVar129) {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&PUBLIC_SELF);
        }
        if ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) == 0) {
          bVar76 = 0;
        }
        else {
          bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          bVar76 = bVar76 ^ 1;
        }
        if (DAT_1406995f9 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
          uStack_10088 = (undefined1 (*) [16])&PUBLIC_SELF;
          pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
          pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                     &
                     PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::net::ip_addr::IpAddr>>>>_1406a0f50
                     ,&
                      PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2568
                    );
          goto LAB_140036cf0;
        }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
        bStack_10328 = (byte)_DAT_1406995fa;
        bStack_10327 = (byte)((ulonglong)_DAT_1406995fa >> 8);
        iStack_10326 = (int)((ulonglong)_DAT_1406995fa >> 0x10);
        uStack_10322 = (ushort)((ulonglong)_DAT_1406995fa >> 0x30);
        bStack_10320 = (byte)uRam0000000140699602;
        uStack_1031f = (undefined5)((ulonglong)uRam0000000140699602 >> 8);
        uStack_1031a = (ushort)((ulonglong)uRam0000000140699602 >> 0x30);
        bStack_10318 = DAT_14069960a;
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar72 == '\0') {
            DAT_1406995f9 = '\x01';
          }
        }
        cVar72 = PUBLIC_SELF;
        LOCK();
        PUBLIC_SELF = '\0';
        UNLOCK();
        if (cVar72 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&PUBLIC_SELF);
        }
        pauVar82 = (undefined1 (*) [16])CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
        uStack_104b0 = (undefined1 (*) [16])(uVar117 * 0x28 + (longlong)pauVar82);
        do {
          uVar113 = (uint)*(uint6 *)(*pauVar82 + 10);
          uVar35 = *(uint6 *)(*pauVar82 + 10);
          pauVar123 = (undefined1 (*) [16])(ulonglong)*(ushort *)(*pauVar82 + 0xe);
          pauVar79 = *(undefined1 (**) [16])pauVar82[1];
          uVar85 = *(undefined8 *)(pauVar82[1] + 8);
          uVar4 = *(undefined8 *)pauVar82[2];
          uStack_10438._0_1_ = (byte)uVar85;
          uStack_10438._1_1_ = (byte)((ulonglong)uVar85 >> 8);
          uStack_10438._2_1_ = (byte)((ulonglong)uVar85 >> 0x10);
          uStack_10438._3_1_ = (byte)((ulonglong)uVar85 >> 0x18);
          uStack_10438._4_4_ = (int)((ulonglong)uVar85 >> 0x20);
          bStack_10430 = (byte)uVar4;
          bStack_1042f = (byte)((ulonglong)uVar4 >> 8);
          uStack_1042e = (ushort)((ulonglong)uVar4 >> 0x10);
          uStack_1042c = (uint)((ulonglong)uVar4 >> 0x20);
          if (((*pauVar82)[8] & 1) == 0) {
            bVar75 = (byte)uVar113;
            bVar76 = (byte)(uVar113 >> 8);
            if (bVar75 == 10) {
LAB_140029dae:
              if (bVar75 == 0x7f) goto LAB_140029d52;
            }
            else {
              if ((uVar113 & 0xff) == 0xc0) {
                if (bVar76 != 0xa8) goto LAB_140029d8a;
                goto LAB_140029dae;
              }
              if (((uVar113 & 0xff) == 0xac) && ((bVar76 & 0xf0) == 0x10)) goto LAB_140029dae;
LAB_140029d8a:
              if ((bVar75 == 0x7f) || (bVar75 != 0x7f && (bVar76 != 0xfe || bVar75 != 0xa9)))
              goto LAB_140029d52;
            }
            LOCK();
            bVar129 = LAN_SELF == '\0';
            if (bVar129) {
              LAN_SELF = '\x01';
            }
            UNLOCK();
            if (!bVar129) {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LAN_SELF);
            }
            if ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) == 0) {
              bVar73 = 0;
            }
            else {
              bVar73 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              bVar73 = bVar73 ^ 1;
            }
            if (DAT_1407f0129 != '\0') {
              uStack_10088 = (undefined1 (*) [16])&LAN_SELF;
              pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
              pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar73);
              core[505b25137b8ba7f]::result::unwrap_failed
                        ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                         &
                         PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0df0
                         ,&
                          PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2580
                        );
              goto LAB_140036cf0;
            }
            if (DAT_1407f0130 == 0) {
              if (*(longlong *)
                   __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                  != 0) {
                std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
              }
              if (*(int *)(
                          __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                          + 0x18) == 0) {
                DVar108 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                                    (
                                    __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                                    );
                plVar94 = TlsGetValue(DVar108);
              }
              else {
                DVar108 = *(int *)(
                                  __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                                  + 0x18) - 1;
                plVar94 = TlsGetValue(DVar108);
              }
              if (plVar94 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
                plVar94 = (longlong *)
                          <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                          ::try_initialize::
                          <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                                    (DVar108,plVar94,0);
              }
              if (plVar94 == (longlong *)0x0) {
                std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                          (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
                goto LAB_140036cf0;
              }
              _DAT_1407f0150 = *plVar94;
              lRam00000001407f0158 = plVar94[1];
              *plVar94 = *plVar94 + 1;
              _DAT_1407f0140 = 0;
              uRam00000001407f0148 = 0;
              _DAT_1407f0130 = _PTR_DAT_1406a0550;
            }
            bStack_10525 = (byte)(uVar113 >> 0x10);
            bStack_10524 = (byte)(uVar113 >> 0x18);
            bStack_10528 = 0;
            puVar86 = &DAT_1407f0130;
            bStack_10527 = bVar75;
            bStack_10526 = bVar76;
            <hashbrown[ad6d4a1843b2832d]::map::HashMap<core[505b25137b8ba7f]::net::ip_addr::IpAddr,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::net::ip_addr::IpAddr>,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
            ::rustc_entry(&uStack_10088);
            pauVar84 = pauStack_10080;
            pauVar92 = uStack_10088;
            cVar72 = (char)uStack_10078;
            pauVar89 = uStack_10088;
            if ((char)uStack_10078 != '\x02') {
              uStack_100c8 = CONCAT17(abStack_10070[0],(int7)((ulonglong)uStack_10078 >> 8));
              uStack_100c0 = CONCAT61(uStack_1006e,abStack_10070[1]);
              bStack_100b9 = (byte)pauStack_10068;
              uStack_100b8 = pauStack_10068._1_7_;
              if (*(int *)__imp__RNvNtNtNtNtCs59fwaEIuEkC_3std3sys3pal7windows7winsock8WSA_INIT != 0
                 ) {
                bStack_10528 = 1;
                uStack_10088 = (undefined1 (*) [16])&bStack_10528;
                in_stack_fffffffffffefaa8 =
                     &anon_abae67b6203ffecafa6256cb9d53fac3_5_llvm_5426317090953290063;
                puVar86 = (undefined8 *)CONCAT71((int7)((ulonglong)puVar86 >> 8),1);
                <std[3bf9d48a0c3997f0]::sys::sync::once::futex::Once>::call
                          (__imp__RNvNtNtNtNtCs59fwaEIuEkC_3std3sys3pal7windows7winsock8WSA_INIT,
                           puVar86,&uStack_10088,
                           &anon_abae67b6203ffecafa6256cb9d53fac3_3_llvm_5426317090953290063,
                           &anon_abae67b6203ffecafa6256cb9d53fac3_5_llvm_5426317090953290063);
              }
              uStack_10088 = (undefined1 (*) [16])0x0;
              lVar80 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::bind::inner
                                 (&uStack_10088);
              if (lVar80 == 1) {
                if ((1 < ((uint)puVar86 & 3) - 2) && (((ulonglong)puVar86 & 3) != 0)) {
                  pauStack_10080 = (undefined1 (*) [16])((longlong)puVar86 + -1);
                  uStack_10088 = (undefined1 (*) [16])CONCAT71(uStack_10088._1_7_,3);
                  <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                  ::drop(&pauStack_10080);
                }
                uVar124 = 2;
              }
              else {
                uVar124 = 2;
                if (puVar86 != (undefined8 *)0xffffffffffffffff) {
                  uStack_10278._0_1_ = (byte)puVar86;
                  uStack_10278._1_1_ = (byte)((ulonglong)puVar86 >> 8);
                  uStack_10276 = (ushort)((ulonglong)puVar86 >> 0x10);
                  uStack_10274 = (ushort)((ulonglong)puVar86 >> 0x20);
                  uStack_10272 = (ushort)((ulonglong)puVar86 >> 0x30);
                  uStack_10078._0_4_ =
                       CONCAT13(uStack_10438._3_1_,
                                CONCAT12(uStack_10438._2_1_,
                                         CONCAT11(uStack_10438._1_1_,(byte)uStack_10438)));
                  uStack_1006e = CONCAT42(uStack_1042c,uStack_1042e);
                  uStack_10078._4_4_ = uStack_10438._4_4_;
                  abStack_10070[0] = bStack_10430;
                  abStack_10070[1] = bStack_1042f;
                  uStack_10088 = (undefined1 (*) [16])((ulonglong)uVar35 << 0x10);
                  pauStack_10080 = pauVar79;
                  uVar117 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::
                            connect::inner(&uStack_10278,&uStack_10088);
                  if (uVar117 == 0) {
                    <std[3bf9d48a0c3997f0]::net::tcp::TcpStream>::local_addr
                              (&uStack_10088,&uStack_10278);
                    if ((short)uStack_10088 != 2) {
                      if ((short)uStack_10088 == 1) {
                        pauVar79 = (undefined1 (*) [16])(ulonglong)(uint)uStack_10078;
                        uVar113 = (uint)uStack_10088._6_2_ << 0x10 | uStack_10088._2_4_ >> 0x10;
                        uVar124 = 2;
                        pauVar123 = pauStack_10080;
                        if (((longlong)pauStack_10080 << 0x20) + (ulonglong)uVar113 != 0 ||
                            (((uint)uStack_10078 & 0xfeffffff) != 0 ||
                            (ulonglong)pauStack_10080 >> 0x20 != 0)) {
                          uVar124 = 1;
                        }
                      }
                      else {
                        uVar124 = 2;
                        if ((uStack_10088._2_4_ != 0) && ((uStack_10088._2_4_ & 0xff) != 0x7f)) {
                          uVar124 = 0;
                          uVar113 = uStack_10088._2_4_;
                        }
                      }
                      closesocket((SOCKET)puVar86);
                      goto LAB_14002a046;
                    }
                    if ((1 < ((uint)pauStack_10080 & 3) - 2) &&
                       (((ulonglong)pauStack_10080 & 3) != 0)) {
                      puVar99 = pauStack_10080[-1] + 0xf;
                      bStack_10520 = (byte)puVar99;
                      bStack_1051f = (byte)((ulonglong)puVar99 >> 8);
                      bStack_1051e = (byte)((ulonglong)puVar99 >> 0x10);
                      bStack_1051d = (byte)((ulonglong)puVar99 >> 0x18);
                      bStack_1051c = (byte)((ulonglong)puVar99 >> 0x20);
                      bStack_1051b = (byte)((ulonglong)puVar99 >> 0x28);
                      bStack_1051a = (byte)((ulonglong)puVar99 >> 0x30);
                      bStack_10519 = (byte)((ulonglong)puVar99 >> 0x38);
                      bStack_10528 = 3;
                      <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                      ::drop(&bStack_10520);
                    }
                  }
                  else if ((1 < ((uint)uVar117 & 3) - 2) && ((uVar117 & 3) != 0)) {
                    pauStack_10080 = (undefined1 (*) [16])(uVar117 - 1);
                    uStack_10088 = (undefined1 (*) [16])CONCAT71(uStack_10088._1_7_,3);
                    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                    ::drop(&pauStack_10080);
                  }
                  closesocket((SOCKET)puVar86);
                  uVar124 = 2;
                }
              }
LAB_14002a046:
              pauVar89 = *(undefined1 (**) [16])*pauVar92;
              uVar117 = *(ulonglong *)(*pauVar92 + 8);
              uVar81 = uVar117 & (ulonglong)pauVar84;
              auVar133 = *(undefined1 (*) [16])(*pauVar89 + uVar81);
              uVar112 = (ushort)(SUB161(auVar133 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf;
              uVar114 = (uint)uVar112;
              if (uVar112 == 0) {
                lVar80 = 0x10;
                do {
                  uVar81 = uVar81 + lVar80 & uVar117;
                  auVar133 = *(undefined1 (*) [16])(*pauVar89 + uVar81);
                  lVar80 = lVar80 + 0x10;
                  uVar114 = (uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                           (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                           (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                           (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                           (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                           (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                           (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                           (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                           (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                           (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                           (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                           (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                           (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                           (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                           (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                          (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
                } while (uVar114 == 0);
              }
              uVar96 = 0;
              for (; (uVar114 & 1) == 0; uVar114 = uVar114 >> 1 | 0x80000000) {
                uVar96 = uVar96 + 1;
              }
              uVar81 = uVar96 + uVar81 & uVar117;
              bVar76 = (*pauVar89)[uVar81];
              if (-1 < (char)bVar76) {
                auVar133 = *pauVar89;
                uVar114 = 0;
                for (uVar96 = (uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                             (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                             (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                             (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                             (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                             (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                             (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                             (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                             (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                             (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                             (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                             (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                             (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                             (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                             (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                            (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
                    (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
                  uVar114 = uVar114 + 1;
                }
                uVar81 = (ulonglong)uVar114;
                bVar76 = (*pauVar89)[uVar81];
              }
              bVar75 = (byte)((ulonglong)pauVar84 >> 0x39);
              (*pauVar89)[uVar81] = bVar75;
              pauVar89[1][uVar81 - 0x10 & uVar117] = bVar75;
              *(ulonglong *)pauVar92[1] = *(longlong *)pauVar92[1] - (ulonglong)(bVar76 & 1);
              lVar80 = uVar81 * -0x22;
              *(char *)((longlong)pauVar89 + lVar80 + -0x22) = cVar72;
              puVar86 = (undefined8 *)((longlong)pauVar89 + lVar80 + -0x21);
              *puVar86 = uStack_100c8;
              puVar86[1] = CONCAT17(bStack_100b9,uStack_100c0);
              *(undefined1 *)((longlong)pauVar89 + lVar80 + -0x11) = uVar124;
              *(uint *)((longlong)pauVar89 + lVar80 + -0x10) = uVar113;
              *(int *)((longlong)pauVar89 + lVar80 + -4) = (int)pauVar79;
              *(undefined1 (**) [16])((longlong)pauVar89 + lVar80 + -0xc) = pauVar123;
              *(longlong *)(pauVar92[1] + 8) = *(longlong *)(pauVar92[1] + 8) + 1;
              pauVar89 = (undefined1 (*) [16])((longlong)pauVar89 + lVar80);
            }
            uStack_10268 = CONCAT31(uStack_10268._1_3_,pauVar89[-1][0xf]);
            uVar85 = *(undefined8 *)(pauVar89[-2] + 0xf);
            uVar4 = *(undefined8 *)(pauVar89[-1] + 7);
            uStack_10278._0_1_ = (byte)uVar85;
            uStack_10278._1_1_ = (byte)((ulonglong)uVar85 >> 8);
            uStack_10276 = (ushort)((ulonglong)uVar85 >> 0x10);
            uStack_10274 = (ushort)((ulonglong)uVar85 >> 0x20);
            uStack_10272 = (ushort)((ulonglong)uVar85 >> 0x30);
            auStack_10270[0] = (uint)uVar4;
            auStack_10270[1]._0_2_ = (undefined2)((ulonglong)uVar4 >> 0x20);
            auStack_10270[1]._2_2_ = (undefined2)((ulonglong)uVar4 >> 0x30);
            if ((bVar73 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                DAT_1407f0129 = '\x01';
              }
            }
            cVar72 = LAN_SELF;
            LOCK();
            LAN_SELF = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAN_SELF);
            }
          }
          else {
LAB_140029d52:
            uStack_10278._0_1_ = 2;
          }
          uStack_10078 = (undefined1 (*) [16])(*pauVar82 + 8);
          uStack_104c0 = (undefined1 (*) [16])
                         CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
          pauStack_10080 =
               (undefined1 (*) [16])
               ((longlong)uStack_104c0 +
               CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398)) * 0x28);
          abStack_10070[0] = (byte)&uStack_10278;
          abStack_10070[1] = (byte)((ulonglong)&uStack_10278 >> 8);
          uStack_1006e = (undefined6)((ulonglong)&uStack_10278 >> 0x10);
          pauStack_10068._0_1_ = (byte)&bStack_10328;
          pauStack_10068._1_7_ = (undefined7)((ulonglong)&bStack_10328 >> 8);
          uStack_10088 = uStack_104c0;
          <alloc[246c2e7857c81348]::vec::Vec<(u64,alloc[246c2e7857c81348]::string::String)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(u64,alloc[246c2e7857c81348]::string::String),core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<core[505b25137b8ba7f]::slice::iter::Iter<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr)>,host_probe[b94139f9089eb1d8]::net::share_peer_table::{closure#3}>>>
          ::from_iter(&uStack_10438,&uStack_10088);
          lVar80 = CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)))
          ;
          pauVar79 = (undefined1 (*) [16])
                     CONCAT44(uStack_10424,
                              CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428)));
          bStack_10528 = 0;
          bStack_10527 = 0;
          bStack_10526 = 0;
          bStack_10525 = 0;
          bStack_10524 = 0;
          bStack_10523 = 0;
          bStack_10522 = 0;
          bStack_10521 = 0;
          bStack_10520 = 8;
          bStack_1051f = 0;
          bStack_1051e = 0;
          bStack_1051d = 0;
          bStack_1051c = 0;
          bStack_1051b = 0;
          bStack_1051a = 0;
          bStack_10519 = 0;
          bStack_10518 = 0;
          bStack_10517 = 0;
          uStack_10516 = 0;
          uStack_10514 = 0;
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          pauVar123 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_alloc(8,1);
          if (pauVar123 == (undefined1 (*) [16])0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(1,8);
            goto LAB_140036cf0;
          }
          uStack_10088 = (undefined1 (*) [16])&DAT_00000008;
          *(undefined8 *)*pauVar123 = 0x31524545502d5252;
          pauVar89 = (undefined1 (*) [16])&DAT_00000008;
          pauStack_10080 = pauVar123;
          if (pauVar79 == (undefined1 (*) [16])0x0) {
LAB_14002a4bf:
            uStack_10078 = pauVar89;
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(pauStack_10080,uStack_10088,1);
            return pauVar82;
          }
          pauVar89 = (undefined1 (*) [16])&DAT_00000008;
          lVar120 = 0;
          pauStack_10448 = pauVar79;
          do {
            uVar117 = *(ulonglong *)(lVar80 + 0x18 + lVar120);
            if ((undefined1 *)0x4b0 < *pauVar89 + uVar117 + 9 &&
                (undefined1 (*) [16])&DAT_00000008 < pauVar89) {
              uStack_10078 = pauVar89;
              __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
              pauVar84 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_alloc(8,1);
              pauVar92 = uStack_10078;
              pauVar89 = pauStack_10080;
              pauVar123 = uStack_10088;
              if (pauVar84 == (undefined1 (*) [16])0x0) {
                alloc[246c2e7857c81348]::raw_vec::handle_error(1,8);
                goto LAB_140036cf0;
              }
              *(undefined8 *)*pauVar84 = 0x31524545502d5252;
              uStack_10088 = (undefined1 (*) [16])&DAT_00000008;
              uStack_10078._0_4_ = 8;
              uStack_10078._4_4_ = 0;
              lVar98 = CONCAT44(uStack_10514,
                                CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518)));
              pauStack_10080 = pauVar84;
              if (lVar98 == CONCAT17(bStack_10521,
                                     CONCAT16(bStack_10522,
                                              CONCAT15(bStack_10523,
                                                       CONCAT14(bStack_10524,
                                                                CONCAT13(bStack_10525,
                                                                         CONCAT12(bStack_10526,
                                                                                  CONCAT11(
                                                  bStack_10527,bStack_10528)))))))) {
                <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::vec::Vec<u8>>>::
                grow_one(&bStack_10528);
              }
              lVar128 = CONCAT17(bStack_10519,
                                 CONCAT16(bStack_1051a,
                                          CONCAT15(bStack_1051b,
                                                   CONCAT14(bStack_1051c,
                                                            CONCAT13(bStack_1051d,
                                                                     CONCAT12(bStack_1051e,
                                                                              CONCAT11(bStack_1051f,
                                                                                       bStack_10520)
                                                                             ))))));
              *(undefined1 (**) [16])(lVar128 + lVar98 * 0x18) = pauVar123;
              *(undefined1 (**) [16])(lVar128 + 8 + lVar98 * 0x18) = pauVar89;
              *(undefined1 (**) [16])(lVar128 + 0x10 + lVar98 * 0x18) = pauVar92;
              lVar98 = lVar98 + 1;
              bStack_10518 = (byte)lVar98;
              bStack_10517 = (byte)((ulonglong)lVar98 >> 8);
              uStack_10516 = (ushort)((ulonglong)lVar98 >> 0x10);
              uStack_10514 = (uint)((ulonglong)lVar98 >> 0x20);
              pauVar89 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
            }
            uVar85 = *(undefined8 *)(lVar80 + lVar120);
            if ((ulonglong)((longlong)uStack_10088 - (longlong)pauVar89) < 8) {
              in_stack_fffffffffffefaa8 = (undefined **)0x0;
              uStack_10078 = pauVar89;
              <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
              <alloc[246c2e7857c81348]::alloc::Global>(&uStack_10088,pauVar89,8,1,1);
              pauVar89 = uStack_10078;
            }
            *(undefined8 *)(*pauVar89 + (longlong)*pauStack_10080) = uVar85;
            uStack_10078 = (undefined1 (*) [16])(*pauVar89 + 8);
            if (uStack_10078 == uStack_10088) {
              <alloc[246c2e7857c81348]::raw_vec::RawVec<u8>>::grow_one(&uStack_10088);
            }
            (*pauStack_10080 + 8)[(longlong)pauVar89] = (char)uVar117;
            uStack_10078 = (undefined1 (*) [16])(*pauVar89 + 9);
            pvVar87 = *(void **)(lVar80 + 0x10 + lVar120);
            if ((ulonglong)((longlong)uStack_10088 - (longlong)uStack_10078) < uVar117) {
              in_stack_fffffffffffefaa8 = (undefined **)0x0;
              <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
              <alloc[246c2e7857c81348]::alloc::Global>(&uStack_10088,uStack_10078,uVar117,1,1);
LAB_14002a280:
              memcpy((undefined1 *)((longlong)uStack_10078 + (longlong)pauStack_10080),pvVar87,
                     uVar117);
            }
            else if (uVar117 != 0) goto LAB_14002a280;
            pauVar92 = pauStack_10080;
            pauVar123 = uStack_10088;
            pauVar89 = (undefined1 (*) [16])((longlong)uStack_10078 + uVar117);
            lVar120 = lVar120 + 0x20;
          } while ((longlong)pauVar79 << 5 != lVar120);
          lVar120 = CONCAT17(bStack_10521,
                             CONCAT16(bStack_10522,
                                      CONCAT15(bStack_10523,
                                               CONCAT14(bStack_10524,
                                                        CONCAT13(bStack_10525,
                                                                 CONCAT12(bStack_10526,
                                                                          CONCAT11(bStack_10527,
                                                                                   bStack_10528)))))
                                     ));
          if (pauVar89 < (undefined1 (*) [16])&DAT_00000009) {
            unaff_R15 = (undefined1 (*) [16])
                        CONCAT17(bStack_10519,
                                 CONCAT16(bStack_1051a,
                                          CONCAT15(bStack_1051b,
                                                   CONCAT14(bStack_1051c,
                                                            CONCAT13(bStack_1051d,
                                                                     CONCAT12(bStack_1051e,
                                                                              CONCAT11(bStack_1051f,
                                                                                       bStack_10520)
                                                                             ))))));
            lVar98 = CONCAT44(uStack_10514,
                              CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518)));
            if (uStack_10088 != (undefined1 (*) [16])0x0) goto LAB_14002a4bf;
          }
          else {
            lVar98 = CONCAT44(uStack_10514,
                              CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518)));
            uStack_10078 = pauVar89;
            if (lVar98 == lVar120) {
              <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::vec::Vec<u8>>>::
              grow_one(&bStack_10528);
            }
            lVar120 = CONCAT17(bStack_10519,
                               CONCAT16(bStack_1051a,
                                        CONCAT15(bStack_1051b,
                                                 CONCAT14(bStack_1051c,
                                                          CONCAT13(bStack_1051d,
                                                                   CONCAT12(bStack_1051e,
                                                                            CONCAT11(bStack_1051f,
                                                                                     bStack_10520)))
                                                         ))));
            *(undefined1 (**) [16])(lVar120 + lVar98 * 0x18) = pauVar123;
            *(undefined1 (**) [16])(lVar120 + 8 + lVar98 * 0x18) = pauVar92;
            *(undefined1 (**) [16])(lVar120 + 0x10 + lVar98 * 0x18) = pauVar89;
            lVar98 = lVar98 + 1;
            lVar120 = CONCAT17(bStack_10521,
                               CONCAT16(bStack_10522,
                                        CONCAT15(bStack_10523,
                                                 CONCAT14(bStack_10524,
                                                          CONCAT13(bStack_10525,
                                                                   CONCAT12(bStack_10526,
                                                                            CONCAT11(bStack_10527,
                                                                                     bStack_10528)))
                                                         ))));
            unaff_R15 = (undefined1 (*) [16])
                        CONCAT17(bStack_10519,
                                 CONCAT16(bStack_1051a,
                                          CONCAT15(bStack_1051b,
                                                   CONCAT14(bStack_1051c,
                                                            CONCAT13(bStack_1051d,
                                                                     CONCAT12(bStack_1051e,
                                                                              CONCAT11(bStack_1051f,
                                                                                       bStack_10520)
                                                                             ))))));
            pauVar89 = uStack_10078;
          }
          pauVar79 = (undefined1 (*) [16])((longlong)unaff_R15 + lVar98 * 0x18);
          bStack_10528 = (byte)unaff_R15;
          bStack_10527 = (byte)((ulonglong)unaff_R15 >> 8);
          bStack_10526 = (byte)((ulonglong)unaff_R15 >> 0x10);
          bStack_10525 = (byte)((ulonglong)unaff_R15 >> 0x18);
          bStack_10524 = (byte)((ulonglong)unaff_R15 >> 0x20);
          bStack_10523 = (byte)((ulonglong)unaff_R15 >> 0x28);
          bStack_10522 = (byte)((ulonglong)unaff_R15 >> 0x30);
          bStack_10521 = (byte)((ulonglong)unaff_R15 >> 0x38);
          bStack_10518 = (byte)lVar120;
          bStack_10517 = (byte)((ulonglong)lVar120 >> 8);
          uStack_10516 = (ushort)((ulonglong)lVar120 >> 0x10);
          uStack_10514 = (uint)((ulonglong)lVar120 >> 0x20);
          uStack_10510 = (ushort)pauVar79;
          uStack_1050e = (ushort)((ulonglong)pauVar79 >> 0x10);
          uStack_1050c = (ushort)((ulonglong)pauVar79 >> 0x20);
          uStack_1050a = (ushort)((ulonglong)pauVar79 >> 0x30);
          pauVar123 = unaff_R15;
          bStack_10520 = bStack_10528;
          bStack_1051f = bStack_10527;
          bStack_1051e = bStack_10526;
          bStack_1051d = bStack_10525;
          bStack_1051c = bStack_10524;
          bStack_1051b = bStack_10523;
          bStack_1051a = bStack_10522;
          bStack_10519 = bStack_10521;
          uStack_10078 = pauVar89;
          if (lVar98 != 0) {
            pauVar92 = unaff_R15;
            do {
              pauVar123 = (undefined1 (*) [16])(pauVar92[1] + 8);
              lVar98 = *(longlong *)*pauVar92;
              uStack_10078 = pauVar89;
              if (lVar98 == -1) break;
              pauVar84 = *(undefined1 (**) [16])(*pauVar92 + 8);
              sVar116 = *(short *)(*pauVar82 + 8);
              pauVar104 = (undefined1 (*) [16])
                          &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
              if ((sVar116 == 2) || (pauVar104 = *(undefined1 (**) [16])pauVar82[1], sVar116 == -1))
              {
LAB_14002a5c0:
                LOCK();
                DAT_1407f1080 = DAT_1407f1080 + 1;
                UNLOCK();
                if ((1 < ((uint)pauVar104 & 3) - 2) && (((ulonglong)pauVar104 & 3) != 0)) {
                  pauStack_10080 = (undefined1 (*) [16])(pauVar104[-1] + 0xf);
                  uStack_10088 = (undefined1 (*) [16])CONCAT71(uStack_10088._1_7_,3);
                  uStack_10078 = pauVar89;
                  <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                  ::drop(&pauStack_10080);
                  pauVar89 = uStack_10078;
                }
              }
              else {
                uStack_10088._0_6_ = CONCAT42(*(undefined4 *)(*pauVar82 + 10),sVar116);
                uStack_10088 = (undefined1 (*) [16])
                               CONCAT26(*(undefined2 *)(*pauVar82 + 0xe),(undefined6)uStack_10088);
                uVar85 = *(undefined8 *)pauVar82[2];
                uStack_10078._0_4_ = (uint)*(undefined8 *)(pauVar82[1] + 8);
                uStack_10078._4_4_ = (uint)((ulonglong)*(undefined8 *)(pauVar82[1] + 8) >> 0x20);
                abStack_10070[0] = (byte)uVar85;
                abStack_10070[1] = (byte)((ulonglong)uVar85 >> 8);
                uStack_1006e = (undefined6)((ulonglong)uVar85 >> 0x10);
                pauVar104 = pauVar84;
                pauStack_10080 = *(undefined1 (**) [16])pauVar82[1];
                uVar117 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                                    (&DAT_140699980,pauVar84,*(undefined8 *)pauVar92[1],
                                     &uStack_10088);
                pauVar89 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
                if ((uVar117 & 1) != 0) goto LAB_14002a5c0;
                LOCK();
                DAT_1407f1050 = *pauVar104 + (longlong)DAT_1407f1050;
                UNLOCK();
                LOCK();
                DAT_1407f1058 = DAT_1407f1058 + 1;
                UNLOCK();
              }
              uStack_10078 = pauVar89;
              if (lVar98 != 0) {
                pauVar82 = (undefined1 (*) [16])
                           __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar84,lVar98,1);
                return pauVar82;
              }
              pauVar92 = pauVar123;
            } while (pauVar123 != pauVar79);
            bStack_10520 = (byte)pauVar123;
            bStack_1051f = (byte)((ulonglong)pauVar123 >> 8);
            bStack_1051e = (byte)((ulonglong)pauVar123 >> 0x10);
            bStack_1051d = (byte)((ulonglong)pauVar123 >> 0x18);
            bStack_1051c = (byte)((ulonglong)pauVar123 >> 0x20);
            bStack_1051b = (byte)((ulonglong)pauVar123 >> 0x28);
            bStack_1051a = (byte)((ulonglong)pauVar123 >> 0x30);
            bStack_10519 = (byte)((ulonglong)pauVar123 >> 0x38);
          }
          if (pauVar79 != pauVar123) {
            uVar117 = (ulonglong)((longlong)pauVar79 - (longlong)pauVar123) / 0x18;
            puVar86 = (undefined8 *)(*pauVar123 + 8);
            do {
              if (puVar86[-1] != 0) {
                pauVar82 = (undefined1 (*) [16])
                           __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar86,puVar86[-1],1);
                return pauVar82;
              }
              puVar86 = puVar86 + 3;
              uVar117 = uVar117 - 1;
            } while (uVar117 != 0);
          }
          if (lVar120 != 0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(unaff_R15,lVar120 * 0x18,8);
            return pauVar82;
          }
          if (pauStack_10448 != (undefined1 (*) [16])0x0) {
            puVar86 = (undefined8 *)(lVar80 + 0x10);
            pauVar79 = pauStack_10448;
            do {
              if (puVar86[-1] != 0) {
                pauVar82 = (undefined1 (*) [16])
                           __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar86,puVar86[-1],1);
                return pauVar82;
              }
              puVar86 = puVar86 + 4;
              pauVar79 = (undefined1 (*) [16])(pauVar79[-1] + 0xf);
            } while (pauVar79 != (undefined1 (*) [16])0x0);
          }
          lVar120 = CONCAT44(uStack_10438._4_4_,
                             CONCAT13(uStack_10438._3_1_,
                                      CONCAT12(uStack_10438._2_1_,
                                               CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))));
          if (lVar120 != 0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar80,lVar120 << 5,8);
            return pauVar82;
          }
          pauVar82 = (undefined1 (*) [16])(pauVar82[2] + 8);
        } while (pauVar82 != uStack_104b0);
        lVar80 = CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
        uVar96 = 0;
        pauVar82 = uStack_104c0;
        if (lVar80 != 0) goto LAB_14002a8cd;
        goto LAB_14002a8d2;
      }
      if ((bVar76 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar72 == '\0') {
          DAT_140699831 = '\x01';
        }
      }
      cVar72 = TRANSPORT;
      LOCK();
      TRANSPORT = '\0';
      UNLOCK();
      if (cVar72 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
      }
    }
    lVar80 = CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
LAB_14002a8cd:
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar82,lVar80 * 0x28,8);
      return pauVar82;
    }
  }
LAB_14002a8d2:
  LOCK();
  bVar129 = GREETING == '\0';
  if (bVar129) {
    GREETING = '\x01';
  }
  UNLOCK();
  if (!bVar129) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&GREETING);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar76 = 0;
  }
  else {
    bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar76 = bVar76 ^ 1;
  }
  if (DAT_1407f00e9 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10088 = (undefined1 (*) [16])&GREETING;
    pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
    pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0f10
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1f68);
    goto LAB_140036cf0;
  }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  if ((DAT_1407f00f0 == 0) || (DAT_1407f0108 == 0)) {
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_1407f00e9 = '\x01';
      }
    }
    cVar72 = GREETING;
    LOCK();
    GREETING = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&GREETING);
    }
  }
  else {
    uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    bStack_10528 = (byte)uVar85;
    bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
    bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
    bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
    bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
    bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
    bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
    bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
    bStack_10520 = (byte)uVar96;
    bStack_1051f = (byte)(uVar96 >> 8);
    bStack_1051e = (byte)(uVar96 >> 0x10);
    bStack_1051d = (byte)(uVar96 >> 0x18);
    uStack_10088 = (undefined1 (*) [16])0x0;
    pauStack_10080 = (undefined1 (*) [16])&DAT_00000004;
    uStack_10078._0_4_ = 0;
    uStack_10078._4_4_ = 0;
    <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,u32,std[3bf9d48a0c3997f0]::time::Instant),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
    ::retain::<<host_probe[b94139f9089eb1d8]::net::Greeting>::due::_closure_0_>
              (&DAT_1407f00f0,&bStack_10528,&uStack_10088);
    pauVar79 = pauStack_10080;
    pauVar82 = uStack_10088;
    lVar80 = CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
    if (((bVar76 == 0) &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar72 == '\0')
       ) {
      DAT_1407f00e9 = '\x01';
    }
    cVar72 = GREETING;
    LOCK();
    GREETING = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&GREETING);
    }
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    puVar86 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(8,1);
    if (puVar86 == (undefined8 *)0x0) {
      alloc[246c2e7857c81348]::raw_vec::handle_error(1,8);
      goto LAB_140036cf0;
    }
    *puVar86 = 0x74656572672d7272;
    pauStack_10080 = (undefined1 (*) [16])&DAT_00000008;
    uStack_10078._0_4_ = (uint)puVar86;
    uStack_10078._4_4_ = (uint)((ulonglong)puVar86 >> 0x20);
    abStack_10070[0] = 8;
    abStack_10070[1] = 0;
    uStack_1006e = 0;
    uStack_10088 = (undefined1 (*) [16])0x8000000000000003;
    reach_directory[4b72b9694f6c3c08]::rendezvous::encode(&bStack_10528,&uStack_10088);
    core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::rendezvous::Message>
              (&uStack_10088);
    if (lVar80 != 0) {
      pauVar123 = (undefined1 (*) [16])
                  CONCAT17(bStack_10519,
                           CONCAT16(bStack_1051a,
                                    CONCAT15(bStack_1051b,
                                             CONCAT14(bStack_1051c,
                                                      CONCAT13(bStack_1051d,
                                                               CONCAT12(bStack_1051e,
                                                                        CONCAT11(bStack_1051f,
                                                                                 bStack_10520)))))))
      ;
      unaff_R15 = (undefined1 (*) [16])
                  CONCAT44(uStack_10514,CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518)));
      pauVar89 = pauVar79;
      do {
        sVar116 = *(short *)*pauVar89;
        if (sVar116 == 2) break;
        uVar78 = *(undefined4 *)(*pauVar89 + 2);
        uStack_103a8 = (ushort)uVar78;
        uStack_103a6 = (ushort)((uint)uVar78 >> 0x10);
        uStack_103a4 = *(ushort *)(*pauVar89 + 6);
        uVar85 = *(undefined8 *)pauVar89[1];
        uVar4 = *(undefined8 *)(pauVar89[1] + 8);
        uStack_10438._0_1_ = (byte)uVar85;
        uStack_10438._1_1_ = (byte)((ulonglong)uVar85 >> 8);
        uStack_10438._2_1_ = (byte)((ulonglong)uVar85 >> 0x10);
        uStack_10438._3_1_ = (byte)((ulonglong)uVar85 >> 0x18);
        uStack_10438._4_4_ = (int)((ulonglong)uVar85 >> 0x20);
        bStack_10430 = (byte)uVar4;
        bStack_1042f = (byte)((ulonglong)uVar4 >> 8);
        uStack_1042e = (ushort)((ulonglong)uVar4 >> 0x10);
        uStack_1042c = (uint)((ulonglong)uVar4 >> 0x20);
        pauVar92 = *(undefined1 (**) [16])(*pauVar89 + 8);
        if (sVar116 == -1) {
LAB_14002ab25:
          LOCK();
          DAT_1407f1080 = DAT_1407f1080 + 1;
          UNLOCK();
          if ((1 < ((uint)pauVar92 & 3) - 2) && (((ulonglong)pauVar92 & 3) != 0)) {
            pauStack_10080 = (undefined1 (*) [16])(pauVar92[-1] + 0xf);
            uStack_10088 = (undefined1 (*) [16])CONCAT71(uStack_10088._1_7_,3);
            <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
            ::drop(&pauStack_10080);
          }
        }
        else {
          uStack_10088._0_6_ = CONCAT42(uVar78,sVar116);
          uStack_10088 = (undefined1 (*) [16])CONCAT26(uStack_103a4,(undefined6)uStack_10088);
          uStack_10078._0_4_ = (uint)uVar85;
          uStack_1006e = (undefined6)((ulonglong)uVar4 >> 0x10);
          pauVar92 = pauVar123;
          pauStack_10080 = *(undefined1 (**) [16])(*pauVar89 + 8);
          uStack_10078._4_4_ = uStack_10438._4_4_;
          abStack_10070[0] = bStack_10430;
          abStack_10070[1] = bStack_1042f;
          uVar117 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                              (&DAT_140699980,pauVar123,unaff_R15,&uStack_10088);
          if ((uVar117 & 1) != 0) goto LAB_14002ab25;
          LOCK();
          DAT_1407f1050 = *pauVar92 + (longlong)DAT_1407f1050;
          UNLOCK();
          LOCK();
          DAT_1407f1058 = DAT_1407f1058 + 1;
          UNLOCK();
        }
        pauVar89 = pauVar89 + 2;
      } while (pauVar89 != pauVar79 + lVar80 * 2);
    }
    if (pauVar82 != (undefined1 (*) [16])0x0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar79,(longlong)pauVar82 << 5,4);
      return pauVar82;
    }
    lVar80 = CONCAT17(bStack_10521,
                      CONCAT16(bStack_10522,
                               CONCAT15(bStack_10523,
                                        CONCAT14(bStack_10524,
                                                 CONCAT13(bStack_10525,
                                                          CONCAT12(bStack_10526,
                                                                   CONCAT11(bStack_10527,
                                                                            bStack_10528)))))));
    uVar96 = 0;
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc
                           (CONCAT17(bStack_10519,
                                     CONCAT16(bStack_1051a,
                                              CONCAT15(bStack_1051b,
                                                       CONCAT14(bStack_1051c,
                                                                CONCAT13(bStack_1051d,
                                                                         CONCAT12(bStack_1051e,
                                                                                  CONCAT11(
                                                  bStack_1051f,bStack_10520))))))),lVar80,1);
      return pauVar82;
    }
  }
  if (IS_HOST_0_llvm_14435704873730135342 != '\0') {
    LOCK();
    bVar129 = LAST_SCORES == '\0';
    if (bVar129) {
      LAST_SCORES = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LAST_SCORES);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
    }
    if (DAT_1406995e1 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&LAST_SCORES;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2108);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    if (DAT_1406995f0 != 0xffffffff) {
      pauStack_10080._4_4_ = (undefined4)((ulonglong)pauStack_10080 >> 0x20);
      pauStack_10080 = (undefined1 (*) [16])CONCAT44(pauStack_10080._4_4_,DAT_1406995f0);
      uStack_10088 = DAT_1406995e8;
      lVar80 = <std[3bf9d48a0c3997f0]::time::Instant>::elapsed(&uStack_10088);
      if ((lVar80 == 0) && (uVar96 < 250000000)) {
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar72 == '\0') {
            DAT_1406995e1 = '\x01';
          }
        }
        cVar72 = LAST_SCORES;
        LOCK();
        LAST_SCORES = '\0';
        UNLOCK();
        if (cVar72 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_SCORES);
        }
        goto LAB_14002afb1;
      }
    }
    DAT_1406995e8 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
    DAT_1406995f0 = uVar96;
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_1406995e1 = '\x01';
      }
    }
    cVar72 = LAST_SCORES;
    LOCK();
    LAST_SCORES = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_SCORES);
      LOCK();
      bVar129 = DAT_140699948 == '\0';
      if (bVar129) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
    }
    else {
      LOCK();
      bVar129 = DAT_140699948 == '\0';
      if (bVar129) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
    }
    if (!bVar129) {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
    }
    if (DAT_140699949 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&DAT_140699948;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2120);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10078 = (undefined1 (*) [16])(*DAT_140699950 + DAT_140699958 + 1);
    auVar133 = *DAT_140699950;
    uVar112 = ~((ushort)(SUB161(auVar133 >> 7,0) & 1) | (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1
                | (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
    pauStack_10080 = DAT_140699950 + 1;
    abStack_10070[0] = (byte)uVar112;
    abStack_10070[1] = (byte)(uVar112 >> 8);
    pauStack_10068._0_1_ = (byte)DAT_140699968;
    pauStack_10068._1_7_ = (undefined7)((ulonglong)DAT_140699968 >> 8);
    pauVar82 = (undefined1 (*) [16])&uStack_10088;
    uStack_10088 = DAT_140699950;
    <alloc[246c2e7857c81348]::vec::Vec<host_probe[b94139f9089eb1d8]::net::Route>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<host_probe[b94139f9089eb1d8]::net::Route,core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Values<u64,host_probe[b94139f9089eb1d8]::net::Route>>>>
    ::from_iter(&uStack_103a8);
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699949 = '\x01';
      }
    }
    cVar72 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    scorex::message(&uStack_10438);
    coopx::ff_message(&uStack_10088);
    uStack_10500 = uStack_10078;
    pauStack_10058 = uStack_10088;
    bStack_10518 = bStack_10428;
    bStack_10517 = bStack_10427;
    uStack_10516 = uStack_10426;
    uStack_10514 = uStack_10424;
    bStack_10528 = (byte)uStack_10438;
    bStack_10527 = uStack_10438._1_1_;
    bStack_10526 = uStack_10438._2_1_;
    bStack_10525 = uStack_10438._3_1_;
    bStack_10524 = (byte)uStack_10438._4_4_;
    bStack_10523 = (byte)((uint)uStack_10438._4_4_ >> 8);
    bStack_10522 = (byte)((uint)uStack_10438._4_4_ >> 0x10);
    bStack_10521 = (byte)((uint)uStack_10438._4_4_ >> 0x18);
    bStack_10520 = bStack_10430;
    bStack_1051f = bStack_1042f;
    bStack_1051e = (byte)uStack_1042e;
    bStack_1051d = (byte)(uStack_1042e >> 8);
    bStack_1051c = (byte)uStack_1042c;
    bStack_1051b = (byte)(uStack_1042c >> 8);
    bStack_1051a = (byte)(uStack_1042c >> 0x10);
    bStack_10519 = (byte)(uStack_1042c >> 0x18);
    uStack_10510 = (ushort)uStack_10088;
    uStack_1050e = (ushort)((ulonglong)uStack_10088 >> 0x10);
    uStack_1050c = (ushort)((ulonglong)uStack_10088 >> 0x20);
    uStack_1050a = (ushort)((ulonglong)uStack_10088 >> 0x30);
    uStack_10508._0_4_ = (uint)pauStack_10080;
    uStack_10508._4_4_ = (uint)((ulonglong)pauStack_10080 >> 0x20);
    uStack_10088 = (undefined1 (*) [16])0x1;
    uStack_10078._0_4_ = 2;
    uStack_10078._4_4_ = 0;
    uStack_1006e = CONCAT42(uStack_10438._4_4_,CONCAT11(uStack_10438._3_1_,uStack_10438._2_1_));
    pauStack_10068._1_7_ =
         (undefined7)
         (CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430))) >> 8);
    ppauStack_10060 =
         (undefined1 (**) [16])
         CONCAT44(uStack_10424,CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428)));
    pauStack_10050 = pauStack_10080;
    pauStack_10048 = uStack_10500;
    uStack_10040 = 0xfffffffffffffffe;
    uStack_10028 = 0xfffffffffffffffe;
    pauStack_10448 = (undefined1 (*) [16])CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0))
    ;
    lVar80 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
    uStack_104b0 = (undefined1 (*) [16])(lVar80 * 0x48);
    lVar120 = 0;
    abStack_10070[0] = bStack_10528;
    abStack_10070[1] = bStack_10527;
    pauStack_10068._0_1_ = bStack_10520;
    do {
      uVar96 = (uint)pauVar82;
      pauVar79 = (undefined1 (*) [16])(lVar120 + 1);
      lVar98 = *(longlong *)(abStack_10070 + lVar120 * 0x18);
      if (lVar98 != -1) {
        if (lVar98 == -2) goto LAB_14002af74;
        ppauVar3 = (&ppauStack_10060)[lVar120 * 3 + -1];
        if (lVar80 != 0) {
          unaff_R15 = (undefined1 (*) [16])(&ppauStack_10060)[lVar120 * 3];
          pauVar123 = uStack_104b0;
          pauVar89 = pauStack_10448;
          do {
            in_stack_fffffffffffefaa8 =
                 (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),1);
            pauVar82 = pauVar89;
            send_route_kind(&TRANSPORT,pauVar89,ppauVar3,unaff_R15,in_stack_fffffffffffefaa8);
            pauVar89 = (undefined1 (*) [16])(pauVar89[4] + 8);
            pauVar123 = (undefined1 (*) [16])(pauVar123[-5] + 8);
          } while (pauVar123 != (undefined1 (*) [16])0x0);
        }
        if (lVar98 != 0) {
          pauVar82 = (undefined1 (*) [16])
                     __rustc[9d087a5ab36ea756]::__rust_dealloc(ppauVar3,lVar98,1);
          return pauVar82;
        }
      }
      uVar96 = (uint)pauVar82;
      lVar120 = 1;
    } while (pauVar79 != (undefined1 (*) [16])0x2);
    pauVar79 = (undefined1 (*) [16])0x2;
LAB_14002af74:
    pauStack_10080 = pauVar79;
    core[505b25137b8ba7f]::ptr::drop_glue::
    <core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>
              (&uStack_10088);
    lVar80 = CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc(pauStack_10448,lVar80 * 0x48,8);
      return pauVar82;
    }
  }
LAB_14002afb1:
  LOCK();
  bVar129 = LAST_LOOKS == '\0';
  if (bVar129) {
    LAST_LOOKS = '\x01';
  }
  UNLOCK();
  if (!bVar129) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LAST_LOOKS);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar76 = 0;
  }
  else {
    bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar76 = bVar76 ^ 1;
  }
  if (DAT_140699561 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10088 = (undefined1 (*) [16])&LAST_LOOKS;
    pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
    pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
               &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1fb0);
    goto LAB_140036cf0;
  }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  if (DAT_140699570 == 0xffffffff) {
LAB_14002b068:
    DAT_140699568 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
    DAT_140699570 = uVar96;
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699561 = '\x01';
      }
    }
    cVar72 = LAST_LOOKS;
    LOCK();
    LAST_LOOKS = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_LOOKS);
    }
    host::looks::message((undefined1 (*) [16])&uStack_10438);
    emblem::message(&uStack_10088);
    pauVar82 = uStack_10078;
    bStack_10518 = bStack_10428;
    bStack_10517 = bStack_10427;
    uStack_10516 = uStack_10426;
    uStack_10514 = uStack_10424;
    uStack_1006e = CONCAT42(uStack_10438._4_4_,CONCAT11(uStack_10438._3_1_,uStack_10438._2_1_));
    uStack_10510 = (ushort)uStack_10088;
    uStack_1050e = (ushort)((ulonglong)uStack_10088 >> 0x10);
    uStack_1050c = (ushort)((ulonglong)uStack_10088 >> 0x20);
    uStack_1050a = (ushort)((ulonglong)uStack_10088 >> 0x30);
    uStack_10508._0_4_ = (uint)pauStack_10080;
    uStack_10508._4_4_ = (uint)((ulonglong)pauStack_10080 >> 0x20);
    abStack_10070[0] = (byte)uStack_10438;
    abStack_10070[1] = uStack_10438._1_1_;
    pauStack_10068._0_1_ = bStack_10430;
    pauStack_10068._1_7_ =
         (undefined7)
         (CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430))) >> 8);
    ppauStack_10060 =
         (undefined1 (**) [16])
         CONCAT44(uStack_10424,CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428)));
    pauStack_10058 = uStack_10088;
    pauStack_10050 = pauStack_10080;
    pauStack_10048 = uStack_10078;
    uStack_10088 = (undefined1 (*) [16])0x1;
    pauStack_10080 = (undefined1 (*) [16])0x0;
    uStack_10078._0_4_ = 2;
    uStack_10078._4_4_ = 0;
    uStack_10040 = 0xfffffffffffffffe;
    uStack_10028 = 0xfffffffffffffffe;
    uStack_10500 = pauVar82;
    <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::vec::Vec<u8>,core[505b25137b8ba7f]::iter::adapters::flatten::Flatten<core[505b25137b8ba7f]::array::iter::IntoIter<core[505b25137b8ba7f]::option::Option<alloc[246c2e7857c81348]::vec::Vec<u8>>,2usize>>>>
    ::from_iter(&uStack_103a8,&uStack_10088);
    host::looks::message3(&bStack_10528);
    uStack_10078._0_4_ =
         CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528)));
    uStack_10088 = (undefined1 (*) [16])
                   CONCAT17(bStack_10519,
                            CONCAT16(bStack_1051a,
                                     CONCAT15(bStack_1051b,
                                              CONCAT14(bStack_1051c,
                                                       CONCAT13(bStack_1051d,
                                                                CONCAT12(bStack_1051e,
                                                                         CONCAT11(bStack_1051f,
                                                                                  bStack_10520))))))
                           );
    puVar88 = (undefined *)
              ((longlong)uStack_10088 +
              CONCAT44(uStack_10514,CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518))) *
              0x18);
    uStack_10078._4_4_ =
         (uint)(CONCAT17(bStack_10521,
                         CONCAT16(bStack_10522,
                                  CONCAT15(bStack_10523,CONCAT14(bStack_10524,(uint)uStack_10078))))
               >> 0x20);
    abStack_10070[0] = (byte)puVar88;
    abStack_10070[1] = (byte)((ulonglong)puVar88 >> 8);
    uStack_1006e = (undefined6)((ulonglong)puVar88 >> 0x10);
    pauStack_10080 = uStack_10088;
    <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::vec::Vec<u8>>as_alloc[246c2e7857c81348]::vec::spec_extend::SpecExtend<alloc[246c2e7857c81348]::vec::Vec<u8>,alloc[246c2e7857c81348]::vec::into_iter::IntoIter<alloc[246c2e7857c81348]::vec::Vec<u8>>>>
    ::spec_extend(&uStack_103a8,&uStack_10088);
    if (IS_HOST_0_llvm_14435704873730135342 != '\0') {
      lVar80 = -1;
      if ((char)matchrules::COLORS < '\0') {
        uStack_10438._1_1_ = matchrules::CAMERA;
        uStack_10438._2_1_ = matchrules::ELITES != '\0';
        uStack_10438._3_1_ = matchrules::EVEN_ACTIVE != '\0';
        uStack_10438._0_1_ = matchrules::COLORS;
        uStack_10088 = (undefined1 (*) [16])
                       &anon_553b4e5fea14f94d7b140aed25da7182_30_llvm_1181841624220042269;
        pauStack_10080 = (undefined1 (*) [16])0x8;
        abStack_10070[0] = 4;
        abStack_10070[1] = 0;
        uStack_1006e = 0;
        uStack_10078 = (undefined1 (*) [16])&uStack_10438;
        <[&[u8]]as_alloc[246c2e7857c81348]::slice::Concat<u8>>::concat
                  (&bStack_10528,&uStack_10088,2);
        lVar80 = CONCAT17(bStack_10521,
                          CONCAT16(bStack_10522,
                                   CONCAT15(bStack_10523,
                                            CONCAT14(bStack_10524,
                                                     CONCAT13(bStack_10525,
                                                              CONCAT12(bStack_10526,
                                                                       CONCAT11(bStack_10527,
                                                                                bStack_10528)))))));
      }
      uVar85 = CONCAT17(bStack_10519,
                        CONCAT16(bStack_1051a,
                                 CONCAT15(bStack_1051b,
                                          CONCAT14(bStack_1051c,
                                                   CONCAT13(bStack_1051d,
                                                            CONCAT12(bStack_1051e,
                                                                     CONCAT11(bStack_1051f,
                                                                              bStack_10520)))))));
      uVar4 = CONCAT44(uStack_10514,CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518)));
      lVar120 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
      if ((ulonglong)
          (CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8))) -
          lVar120) < (ulonglong)(lVar80 != -1)) {
        in_stack_fffffffffffefaa8 = (undefined **)0x0;
        <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
        <alloc[246c2e7857c81348]::alloc::Global>
                  (&uStack_103a8,lVar120,(ulonglong)(lVar80 != -1),8,0x18);
        lVar120 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
      }
      if (lVar80 != -1) {
        lVar98 = CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
        *(longlong *)(lVar98 + lVar120 * 0x18) = lVar80;
        *(undefined8 *)(lVar98 + 8 + lVar120 * 0x18) = uVar85;
        *(undefined8 *)(lVar98 + 0x10 + lVar120 * 0x18) = uVar4;
        lVar120 = lVar120 + 1;
      }
      uStack_10398 = (ushort)lVar120;
      uStack_10396 = (ushort)((ulonglong)lVar120 >> 0x10);
      uStack_10394 = (uint)((ulonglong)lVar120 >> 0x20);
    }
    LOCK();
    bVar129 = DAT_140699948 == '\0';
    if (bVar129) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
    }
    if (DAT_140699949 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&DAT_140699948;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1fc8);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10078 = (undefined1 (*) [16])(*DAT_140699950 + DAT_140699958 + 1);
    auVar133 = *DAT_140699950;
    uVar112 = ~((ushort)(SUB161(auVar133 >> 7,0) & 1) | (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1
                | (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
    pauStack_10080 = DAT_140699950 + 1;
    abStack_10070[0] = (byte)uVar112;
    abStack_10070[1] = (byte)(uVar112 >> 8);
    pauStack_10068._0_1_ = (byte)DAT_140699968;
    pauStack_10068._1_7_ = (undefined7)((ulonglong)DAT_140699968 >> 8);
    uVar78 = SUB84(&uStack_10088,0);
    uStack_10088 = DAT_140699950;
    <alloc[246c2e7857c81348]::vec::Vec<((u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>),host_probe[b94139f9089eb1d8]::net::Route)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<((u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>),host_probe[b94139f9089eb1d8]::net::Route),core[505b25137b8ba7f]::iter::adapters::map::Map<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::share_looks::{closure#1}>>>
    ::from_iter(&uStack_10438);
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699949 = '\x01';
      }
    }
    cVar72 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    uStack_104b0 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
    uStack_104c0 = (undefined1 (*) [16])CONCAT44(uStack_104c0._4_4_,uVar78);
    LOCK();
    bVar129 = LOOKS_SENT == '\0';
    if (bVar129) {
      LOOKS_SENT = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LOOKS_SENT);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      uStack_10460 = (undefined1 (*) [16])((ulonglong)uStack_10460 & 0xffffffff00000000);
      plVar94 = (longlong *)
                __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
      ;
    }
    else {
      uVar78 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      uStack_10460 = (undefined1 (*) [16])(CONCAT44(uStack_10460._4_4_,uVar78) ^ 1);
      plVar94 = (longlong *)
                __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
      ;
    }
    __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
         = (undefined *)plVar94;
    if (DAT_1407f0069 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&LOOKS_SENT;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,(char)uStack_10460);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &
                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0e30
                 ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1fe0);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    if (DAT_1407f0070 == (undefined *)0x0) {
      if (*plVar94 != 0) {
        std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
      }
      if ((int)plVar94[3] == 0) {
        DVar108 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                            (
                            __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                            );
        plVar94 = TlsGetValue(DVar108);
      }
      else {
        DVar108 = (int)plVar94[3] - 1;
        plVar94 = TlsGetValue(DVar108);
      }
      if (plVar94 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
        plVar94 = (longlong *)
                  <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                  ::try_initialize::
                  <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                            (DVar108,plVar94,0);
      }
      if (plVar94 == (longlong *)0x0) {
        std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                  (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
        goto LAB_140036cf0;
      }
      _DAT_1407f0090 = *plVar94;
      lRam00000001407f0098 = plVar94[1];
      *plVar94 = *plVar94 + 1;
      _DAT_1407f0080 = 0;
      uRam00000001407f0088 = 0;
      DAT_1407f0070 = &DAT_1406a0540;
      uRam00000001407f0078 = 0;
    }
    uVar96 = (uint)&uStack_10438;
    <hashbrown[ad6d4a1843b2832d]::map::HashMap<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>),host_probe[b94139f9089eb1d8]::net::LooksSent,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
    ::retain::<host_probe[b94139f9089eb1d8]::net::share_looks::_closure_2_>(&DAT_1407f0070);
    lVar80 = CONCAT44(uStack_10424,CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428)));
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])
                 CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
      uStack_10458 = (undefined1 (*) [16])(lVar80 * 0x88 + (longlong)pauVar82);
      do {
        uVar85 = *(undefined8 *)*pauVar82;
        uVar4 = *(undefined8 *)(*pauVar82 + 8);
        uVar9 = *(undefined8 *)pauVar82[1];
        uVar10 = *(undefined8 *)(pauVar82[1] + 8);
        auVar133 = pauVar82[3];
        uStack_104f8._0_4_ = auVar133._0_4_;
        uStack_104f8._4_4_ = auVar133._4_4_;
        uStack_104f0 = auVar133._8_4_;
        uStack_104ec = auVar133._12_4_;
        uStack_10508._0_4_ = (uint)*(undefined8 *)pauVar82[2];
        uStack_10508._4_4_ = (uint)((ulonglong)*(undefined8 *)pauVar82[2] >> 0x20);
        uStack_10500._0_4_ = (uint)*(undefined8 *)(pauVar82[2] + 8);
        uStack_10500._4_4_ = (uint)((ulonglong)*(undefined8 *)(pauVar82[2] + 8) >> 0x20);
        bStack_10518 = (byte)uVar9;
        bStack_10517 = (byte)((ulonglong)uVar9 >> 8);
        uStack_10516 = (ushort)((ulonglong)uVar9 >> 0x10);
        uStack_10514 = (uint)((ulonglong)uVar9 >> 0x20);
        uStack_10510 = (ushort)uVar10;
        uStack_1050e = (ushort)((ulonglong)uVar10 >> 0x10);
        uStack_1050c = (ushort)((ulonglong)uVar10 >> 0x20);
        uStack_1050a = (ushort)((ulonglong)uVar10 >> 0x30);
        bStack_10528 = (byte)uVar85;
        bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
        bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
        bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
        bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
        bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
        bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
        bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
        bStack_10520 = (byte)uVar4;
        bStack_1051f = (byte)((ulonglong)uVar4 >> 8);
        bStack_1051e = (byte)((ulonglong)uVar4 >> 0x10);
        bStack_1051d = (byte)((ulonglong)uVar4 >> 0x18);
        bStack_1051c = (byte)((ulonglong)uVar4 >> 0x20);
        bStack_1051b = (byte)((ulonglong)uVar4 >> 0x28);
        bStack_1051a = (byte)((ulonglong)uVar4 >> 0x30);
        bStack_10519 = (byte)((ulonglong)uVar4 >> 0x38);
        pauStack_10448 = pauVar82;
        <hashbrown[ad6d4a1843b2832d]::map::HashMap<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>),host_probe[b94139f9089eb1d8]::net::LooksSent,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
        ::rustc_entry(&uStack_10088,&DAT_1407f0070,&bStack_10528);
        uVar117 = uStack_10040;
        pauVar79 = pauStack_10048;
        pauVar82 = uStack_10078;
        sVar116 = (short)uStack_10088;
        pauVar123 = pauStack_10080;
        if ((short)uStack_10088 != 2) {
          uStack_1028c = uStack_10088._6_2_;
          uStack_10290 = uStack_10088._2_4_;
          uVar78 = pauStack_10080._0_4_;
          uVar97 = pauStack_10080._4_4_;
          uStack_100f8 = CONCAT62(uStack_1006e,CONCAT11(abStack_10070[1],abStack_10070[0]));
          uStack_100f0 = CONCAT71(pauStack_10068._1_7_,(byte)pauStack_10068);
          ppauStack_100e8 = ppauStack_10060;
          pauStack_100e0 = pauStack_10058;
          pauStack_100d8 = pauStack_10050;
          if (*(longlong *)
               __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
              != 0) {
            std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
          }
          if (*(int *)(
                      __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                      + 0x18) == 0) {
            DVar108 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                                (
                                __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                                );
            plVar94 = TlsGetValue(DVar108);
          }
          else {
            DVar108 = *(int *)(
                              __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                              + 0x18) - 1;
            plVar94 = TlsGetValue(DVar108);
          }
          if (plVar94 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
            plVar94 = (longlong *)
                      <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                      ::try_initialize::
                      <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                                (DVar108,plVar94,0);
          }
          if (plVar94 == (longlong *)0x0) {
            std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                      (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
            goto LAB_140036cf0;
          }
          lVar80 = *plVar94;
          lVar120 = plVar94[1];
          *plVar94 = *plVar94 + 1;
          pauVar89 = *(undefined1 (**) [16])*pauVar79;
          uVar81 = *(ulonglong *)(*pauVar79 + 8);
          uVar83 = uVar81 & uVar117;
          auVar133 = *(undefined1 (*) [16])(*pauVar89 + uVar83);
          uVar112 = (ushort)(SUB161(auVar133 >> 7,0) & 1) |
                    (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                    (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                    (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                    (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                    (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                    (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                    (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                    (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                    (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                    (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                    (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                    (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                    (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                    (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar133[0xf] >> 7) << 0xf;
          uVar113 = (uint)uVar112;
          if (uVar112 == 0) {
            lVar98 = 0x10;
            do {
              uVar83 = uVar83 + lVar98 & uVar81;
              auVar133 = *(undefined1 (*) [16])(*pauVar89 + uVar83);
              lVar98 = lVar98 + 0x10;
              uVar113 = (uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                       (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                       (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                       (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                       (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                       (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                       (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                       (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                       (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                       (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                       (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                       (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                       (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                       (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                       (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                      (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
            } while (uVar113 == 0);
          }
          uVar114 = 0;
          for (; (uVar113 & 1) == 0; uVar113 = uVar113 >> 1 | 0x80000000) {
            uVar114 = uVar114 + 1;
          }
          uVar83 = uVar114 + uVar83 & uVar81;
          bVar76 = (*pauVar89)[uVar83];
          if (-1 < (char)bVar76) {
            auVar133 = *pauVar89;
            uVar113 = 0;
            for (uVar114 = (uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                          (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                          (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                          (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                          (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                          (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                          (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                          (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                          (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                          (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                          (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                          (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                          (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                          (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                          (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                                         (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
                (uVar114 & 1) == 0; uVar114 = uVar114 >> 1 | 0x80000000) {
              uVar113 = uVar113 + 1;
            }
            uVar83 = (ulonglong)uVar113;
            bVar76 = (*pauVar89)[uVar83];
          }
          bVar75 = (byte)(uVar117 >> 0x39);
          (*pauVar89)[uVar83] = bVar75;
          pauVar89[1][uVar83 - 0x10 & uVar81] = bVar75;
          *(ulonglong *)pauVar79[1] = *(longlong *)pauVar79[1] - (ulonglong)(bVar76 & 1);
          pauVar123 = pauVar89 + uVar83 * -8;
          *(short *)pauVar123[-8] = sVar116;
          *(undefined4 *)(pauVar123[-8] + 2) = uStack_10290;
          *(undefined2 *)(pauVar123[-8] + 6) = uStack_1028c;
          *(undefined4 *)(pauVar123[-8] + 8) = uVar78;
          *(undefined4 *)(pauVar123[-8] + 0xc) = uVar97;
          *(undefined1 (**) [16])pauVar123[-7] = pauVar82;
          *(undefined8 *)(pauVar123[-7] + 8) = uStack_100f8;
          *(undefined8 *)pauVar123[-6] = uStack_100f0;
          *(undefined1 (***) [16])(pauVar123[-6] + 8) = ppauStack_100e8;
          *(undefined1 (**) [16])pauVar123[-5] = pauStack_100e0;
          *(undefined1 (**) [16])(pauVar123[-5] + 8) = pauStack_100d8;
          *(undefined **)pauVar123[-4] = &DAT_1406a0540;
          *(undefined8 *)(pauVar123[-4] + 8) = 0;
          *(undefined8 *)pauVar123[-3] = 0;
          *(undefined8 *)(pauVar123[-3] + 8) = 0;
          *(longlong *)pauVar123[-2] = lVar80;
          *(longlong *)(pauVar123[-2] + 8) = lVar120;
          *(undefined4 *)(pauVar89[uVar83 * -8 + -1] + 8) = 0xffffffff;
          *(longlong *)(pauVar79[1] + 8) = *(longlong *)(pauVar79[1] + 8) + 1;
        }
        uVar113 = uStack_10394;
        uVar91 = uStack_10396;
        uVar112 = uStack_10398;
        lVar80 = CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
        sVar119 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
        uStack_10278._0_1_ = (byte)uStack_104b0;
        uStack_10278._1_1_ = (byte)((ulonglong)uStack_104b0 >> 8);
        uStack_10276 = (ushort)((ulonglong)uStack_104b0 >> 0x10);
        uStack_10274 = (ushort)((ulonglong)uStack_104b0 >> 0x20);
        uStack_10272 = (ushort)((ulonglong)uStack_104b0 >> 0x30);
        auStack_10270[0] = (uint)uStack_104c0;
        if (sVar119 == 0) {
          unaff_R15 = (undefined1 (*) [16])&DAT_00000008;
          if (*(int *)(pauVar123[-1] + 8) != -1) goto LAB_14002b98f;
LAB_14002ba00:
          bVar129 = true;
          if (sVar119 == 0) goto LAB_14002ba0b;
LAB_14002b9b0:
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          uVar85 = 0;
          pvVar87 = (void *)__rustc[9d087a5ab36ea756]::__rust_alloc(sVar119,1);
          if (pvVar87 == (void *)0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(1,sVar119);
            goto LAB_140036cf0;
          }
          if (bVar129) {
            memset(pvVar87,(int)CONCAT71((int7)((ulonglong)uVar85 >> 8),1),sVar119);
LAB_14002ba15:
            *(undefined1 (**) [16])pauVar123[-1] = uStack_104b0;
            *(uint *)(pauVar123[-1] + 8) = (uint)uStack_104c0;
          }
          else {
            sVar100 = 0;
            pauVar82 = unaff_R15;
            do {
              bVar76 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                       ::contains_key::<u64>(pauVar123 + -4,pauVar82);
              *(byte *)((longlong)pvVar87 + sVar100) = bVar76 ^ 1;
              sVar100 = sVar100 + 1;
              pauVar82 = (undefined1 (*) [16])(*pauVar82 + 8);
            } while (sVar119 != sVar100);
          }
        }
        else {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          unaff_R15 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_alloc(sVar119 * 8);
          if (unaff_R15 == (undefined1 (*) [16])0x0) {
            alloc[246c2e7857c81348]::raw_vec::handle_error(8,sVar119 * 8);
            goto LAB_140036cf0;
          }
          sVar100 = 0;
          do {
            lVar120 = *(longlong *)(lVar80 + 8 + sVar100 * 0x18);
            uVar117 = *(ulonglong *)(lVar80 + 0x10 + sVar100 * 0x18);
            uVar81 = uVar117 ^ 0x7465646279746573;
            uVar118 = (uVar81 << 0x10 | uVar81 >> 0x30) ^ uVar81 + 0x6c7967656e657261;
            uVar81 = uVar81 + 0xa60c596fc19fead0;
            uVar121 = uVar81 ^ 0xe414a674f0de7325;
            uVar81 = uVar81 << 0x20 | uVar81 >> 0x20;
            uVar83 = (uVar118 << 0x15 | uVar118 >> 0x2b) ^ uVar118 + 0xded7d4e2d7dedfc6;
            uVar118 = uVar118 + 0xded7d4e2d7dedfc6 ^ uVar117;
            uVar125 = uVar117 & 0xfffffffffffffff8;
            uVar114 = (uint)uVar117;
            if (uVar125 == 0) {
              uVar125 = 0;
              if ((uVar114 & 7) < 4) goto LAB_14002b92e;
LAB_14002b90e:
              uVar122 = (ulonglong)*(uint *)(lVar120 + uVar125);
              uVar126 = 4;
              if (5 < (uVar114 & 7)) {
LAB_14002b939:
                uVar122 = uVar122 | (ulonglong)*(ushort *)(uVar126 + lVar120 + uVar125) <<
                                    (char)uVar126 * '\b';
                uVar126 = uVar126 | 2;
              }
            }
            else {
              uVar126 = 0;
              do {
                uVar83 = uVar83 ^ *(ulonglong *)(lVar120 + uVar126);
                uVar118 = uVar118 + uVar121;
                uVar121 = (uVar121 << 0xd | uVar121 >> 0x33) ^ uVar118;
                uVar122 = (uVar83 << 0x10 | uVar83 >> 0x30) ^ uVar81 + uVar83;
                uVar81 = uVar81 + uVar83 + uVar121;
                uVar118 = (uVar118 << 0x20 | uVar118 >> 0x20) + uVar122;
                uVar121 = (uVar121 << 0x11 | uVar121 >> 0x2f) ^ uVar81;
                uVar81 = uVar81 << 0x20 | uVar81 >> 0x20;
                uVar83 = (uVar122 << 0x15 | uVar122 >> 0x2b) ^ uVar118;
                uVar118 = uVar118 ^ *(ulonglong *)(lVar120 + uVar126);
                uVar126 = uVar126 + 8;
              } while (uVar126 < uVar125);
              if (3 < (uVar114 & 7)) goto LAB_14002b90e;
LAB_14002b92e:
              uVar126 = 0;
              uVar122 = 0;
              if (1 < (uVar114 & 7)) goto LAB_14002b939;
            }
            if ((uint)uVar126 < (uVar114 & 7)) {
              uVar122 = uVar122 | (ulonglong)*(byte *)(lVar120 + uVar125 + uVar126) <<
                                  (sbyte)((uint)uVar126 << 3);
            }
            uVar122 = (uVar117 << 0x38) + 0x800000000000000 | uVar122;
            uVar83 = uVar83 ^ uVar122;
            uVar118 = uVar118 + uVar121;
            uVar125 = (uVar121 << 0xd | uVar121 >> 0x33) ^ uVar118;
            uVar121 = (uVar83 << 0x10 | uVar83 >> 0x30) ^ uVar81 + uVar83;
            uVar117 = uVar81 + uVar83 + uVar125;
            uVar118 = (uVar118 << 0x20 | uVar118 >> 0x20) + uVar121;
            uVar83 = (uVar125 << 0x11 | uVar125 >> 0x2f) ^ uVar117;
            uVar81 = (uVar121 << 0x15 | uVar121 >> 0x2b) ^ uVar118;
            uVar118 = (uVar118 ^ uVar122) + uVar83;
            uVar117 = ((uVar117 << 0x20 | uVar117 >> 0x20) ^ 0xff) + uVar81;
            uVar83 = (uVar83 << 0xd | uVar83 >> 0x33) ^ uVar118;
            uVar81 = (uVar81 << 0x10 | uVar81 >> 0x30) ^ uVar117;
            uVar117 = uVar117 + uVar83;
            uVar118 = (uVar118 << 0x20 | uVar118 >> 0x20) + uVar81;
            uVar83 = (uVar83 << 0x11 | uVar83 >> 0x2f) ^ uVar117;
            uVar81 = (uVar81 << 0x15 | uVar81 >> 0x2b) ^ uVar118;
            uVar118 = uVar118 + uVar83;
            uVar117 = (uVar117 << 0x20 | uVar117 >> 0x20) + uVar81;
            uVar83 = (uVar83 << 0xd | uVar83 >> 0x33) ^ uVar118;
            uVar81 = (uVar81 << 0x10 | uVar81 >> 0x30) ^ uVar117;
            uVar117 = uVar117 + uVar83;
            uVar118 = (uVar118 << 0x20 | uVar118 >> 0x20) + uVar81;
            uVar83 = (uVar83 << 0x11 | uVar83 >> 0x2f) ^ uVar117;
            uVar81 = (uVar81 << 0x15 | uVar81 >> 0x2b) ^ uVar118;
            uVar117 = (uVar117 << 0x20 | uVar117 >> 0x20) + uVar81;
            uVar83 = (uVar83 << 0xd | uVar83 >> 0x33) ^ uVar118 + uVar83;
            uVar81 = (uVar81 << 0x10 | uVar81 >> 0x30) ^ uVar117;
            uVar117 = uVar117 + uVar83;
            *(ulonglong *)(*unaff_R15 + sVar100 * 8) =
                 (uVar117 << 0x20 | uVar117 >> 0x20) ^ (uVar83 << 0x11 | uVar83 >> 0x2f) ^
                 (uVar81 << 0x15 | uVar81 >> 0x2b) ^ uVar117;
            sVar100 = sVar100 + 1;
          } while (sVar100 != sVar119);
          if (*(int *)(pauVar123[-1] + 8) == -1) goto LAB_14002ba00;
LAB_14002b98f:
          uVar117 = <std[3bf9d48a0c3997f0]::time::Instant>::duration_since
                              (&uStack_10278,*(undefined8 *)pauVar123[-1]);
          bVar129 = 9 < uVar117;
          if (sVar119 != 0) goto LAB_14002b9b0;
LAB_14002ba0b:
          pvVar87 = (void *)0x1;
          if (bVar129) goto LAB_14002ba15;
        }
        if (*(longlong *)
             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
            != 0) {
          std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
        }
        if (*(int *)(
                    __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                    + 0x18) == 0) {
          DVar108 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                              (
                              __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                              );
          plVar94 = TlsGetValue(DVar108);
        }
        else {
          DVar108 = *(int *)(
                            __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                            + 0x18) - 1;
          plVar94 = TlsGetValue(DVar108);
        }
        if (plVar94 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
          plVar94 = (longlong *)
                    <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                    ::try_initialize::
                    <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                              (DVar108,plVar94,0);
        }
        if (plVar94 == (longlong *)0x0) {
          std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                    (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
          goto LAB_140036cf0;
        }
        lVar80 = *plVar94;
        ppauStack_10060 = (undefined1 (**) [16])plVar94[1];
        *plVar94 = *plVar94 + 1;
        uStack_10078._0_4_ = 0;
        uStack_10078._4_4_ = 0;
        abStack_10070[0] = 0;
        abStack_10070[1] = 0;
        uStack_1006e = 0;
        uStack_10088 = (undefined1 (*) [16])&DAT_1406a0540;
        pauStack_10080 = (undefined1 (*) [16])0x0;
        pauStack_10068._0_1_ = (byte)lVar80;
        pauStack_10068._1_7_ = (undefined7)((ulonglong)lVar80 >> 8);
        if (sVar119 != 0) {
          <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,())>>::reserve_rehash::
          <hashbrown[ad6d4a1843b2832d]::map::make_hasher<u64,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>::_closure_0_>
                    (&uStack_10088,sVar119,&pauStack_10068,1);
        }
        puVar99 = *unaff_R15 + sVar119 * 8;
        bStack_10528 = (byte)unaff_R15;
        bStack_10527 = (byte)((ulonglong)unaff_R15 >> 8);
        bStack_10526 = (byte)((ulonglong)unaff_R15 >> 0x10);
        bStack_10525 = (byte)((ulonglong)unaff_R15 >> 0x18);
        bStack_10524 = (byte)((ulonglong)unaff_R15 >> 0x20);
        bStack_10523 = (byte)((ulonglong)unaff_R15 >> 0x28);
        bStack_10522 = (byte)((ulonglong)unaff_R15 >> 0x30);
        bStack_10521 = (byte)((ulonglong)unaff_R15 >> 0x38);
        bStack_10518 = (byte)uVar112;
        bStack_10517 = (byte)(uVar112 >> 8);
        uStack_10516 = uVar91;
        uStack_10514 = uVar113;
        uStack_10510 = (ushort)puVar99;
        uStack_1050e = (ushort)((ulonglong)puVar99 >> 0x10);
        uStack_1050c = (ushort)((ulonglong)puVar99 >> 0x20);
        uStack_1050a = (ushort)((ulonglong)puVar99 >> 0x30);
        bStack_10520 = bStack_10528;
        bStack_1051f = bStack_10527;
        bStack_1051e = bStack_10526;
        bStack_1051d = bStack_10525;
        bStack_1051c = bStack_10524;
        bStack_1051b = bStack_10523;
        bStack_1051a = bStack_10522;
        bStack_10519 = bStack_10521;
        <alloc[246c2e7857c81348]::vec::into_iter::IntoIter<u64>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
        ::fold::
        <(),core[505b25137b8ba7f]::iter::adapters::map::map_fold<u64,(u64,()),(),<hashbrown[ad6d4a1843b2832d]::set::HashSet<u64,std[3bf9d48a0c3997f0]::hash::random::RandomState>as_core[505b25137b8ba7f]::iter::traits::collect::Extend<u64>>::extend<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<u64>>::_closure_0_,core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<(u64,()),<hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(),std[3bf9d48a0c3997f0]::hash::random::RandomState>as_core[505b25137b8ba7f]::iter::traits::collect::Extend<(u64,())>>::extend<core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<u64>,<hashbrown[ad6d4a1843b2832d]::set::HashSet<u64,std[3bf9d48a0c3997f0]::hash::random::RandomState>as_core[505b25137b8ba7f]::iter::traits::collect::Extend<u64>>::extend<alloc[246c2e7857c81348]::vec::into_iter::IntoIter<u64>>::_closure_0_>>::_closure_0_>::_closure_0_>::_closure_0_>
                  (&bStack_10528,&uStack_10088);
        uStack_10510 = CONCAT11(abStack_10070[1],abStack_10070[0]);
        bStack_10528 = (byte)uStack_10088;
        bStack_10527 = (byte)((ulonglong)uStack_10088 >> 8);
        bStack_10526 = (byte)((ulonglong)uStack_10088 >> 0x10);
        bStack_10525 = (byte)((ulonglong)uStack_10088 >> 0x18);
        bStack_10524 = (byte)((ulonglong)uStack_10088 >> 0x20);
        bStack_10523 = (byte)((ulonglong)uStack_10088 >> 0x28);
        bStack_10522 = (byte)((ulonglong)uStack_10088 >> 0x30);
        bStack_10521 = (byte)((ulonglong)uStack_10088 >> 0x38);
        bStack_10520 = (byte)pauStack_10080;
        bStack_1051f = (byte)((ulonglong)pauStack_10080 >> 8);
        bStack_1051e = (byte)((ulonglong)pauStack_10080 >> 0x10);
        bStack_1051d = (byte)((ulonglong)pauStack_10080 >> 0x18);
        bStack_1051c = (byte)((ulonglong)pauStack_10080 >> 0x20);
        bStack_1051b = (byte)((ulonglong)pauStack_10080 >> 0x28);
        bStack_1051a = (byte)((ulonglong)pauStack_10080 >> 0x30);
        bStack_10519 = (byte)((ulonglong)pauStack_10080 >> 0x38);
        bStack_10518 = (byte)(uint)uStack_10078;
        bStack_10517 = (byte)((uint)uStack_10078 >> 8);
        uStack_10516 = (ushort)((uint)uStack_10078 >> 0x10);
        uStack_10514 = uStack_10078._4_4_;
        uStack_1050e = (ushort)uStack_1006e;
        uStack_1050c = (ushort)((uint6)uStack_1006e >> 0x10);
        uStack_1050a = (ushort)((uint6)uStack_1006e >> 0x20);
        uStack_10508._0_4_ = (uint)CONCAT71(pauStack_10068._1_7_,(byte)pauStack_10068);
        uStack_10508._4_4_ = (uint)((uint7)pauStack_10068._1_7_ >> 0x18);
        uStack_10500._0_4_ = (uint)ppauStack_10060;
        uStack_10500._4_4_ = (uint)((ulonglong)ppauStack_10060 >> 0x20);
        lVar80 = *(longlong *)(pauVar123[-4] + 8);
        if (lVar80 != 0) {
          uVar117 = lVar80 * 8 & 0xfffffffffffffff0;
          lVar80 = lVar80 + uVar117 + 0x21;
          if (lVar80 != 0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc
                                 ((*(longlong *)pauVar123[-4] - uVar117) + -0x10,lVar80,0x10);
            return pauVar82;
          }
        }
        pauVar82 = (undefined1 (*) [16])0x0;
        uVar96 = 0;
        auVar30._4_4_ = uStack_10508._4_4_;
        auVar30._0_4_ = (uint)uStack_10508;
        auVar30._8_4_ = (uint)uStack_10500;
        auVar30._12_4_ = uStack_10500._4_4_;
        pauVar123[-2] = auVar30;
        *(ulonglong *)pauVar123[-3] = CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
        *(ulonglong *)(pauVar123[-3] + 8) =
             CONCAT26(uStack_1050a,CONCAT24(uStack_1050c,CONCAT22(uStack_1050e,uStack_10510)));
        *(undefined1 (**) [16])pauVar123[-4] = uStack_10088;
        *(undefined1 (**) [16])(pauVar123[-4] + 8) = pauStack_10080;
        lVar80 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
        if (lVar80 != 0) {
          pauVar79 = pauStack_10448 + 4;
          lVar120 = CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
          unaff_R15 = (undefined1 (*) [16])0x0;
          sVar100 = 0;
          do {
            uVar96 = (uint)pauVar82;
            if (sVar119 == sVar100) break;
            if (*(char *)((longlong)pvVar87 + sVar100) != '\0') {
              in_stack_fffffffffffefaa8 =
                   (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),1);
              pauVar82 = pauVar79;
              send_route_kind(&TRANSPORT,pauVar79,*(undefined8 *)(*unaff_R15 + lVar120 + 8),
                              *(undefined8 *)(unaff_R15[1] + lVar120),in_stack_fffffffffffefaa8);
            }
            uVar96 = (uint)pauVar82;
            sVar100 = sVar100 + 1;
            unaff_R15 = (undefined1 (*) [16])(unaff_R15[1] + 8);
          } while ((undefined1 (*) [16])(lVar80 * 0x18) != unaff_R15);
        }
        if (sVar119 != 0) {
          pauVar82 = (undefined1 (*) [16])
                     __rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar87,sVar119,1);
          return pauVar82;
        }
        pauVar82 = (undefined1 (*) [16])(pauStack_10448[8] + 8);
      } while (pauVar82 != uStack_10458);
    }
    if (((char)uStack_10460 == '\0') &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_1407f0069 = '\x01';
      }
    }
    cVar72 = LOOKS_SENT;
    LOCK();
    LOOKS_SENT = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LOOKS_SENT);
    }
    lVar80 = CONCAT44(uStack_10438._4_4_,
                      CONCAT13(uStack_10438._3_1_,
                               CONCAT12(uStack_10438._2_1_,
                                        CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))));
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc
                           (CONCAT44(uStack_1042c,
                                     CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430))),
                            lVar80 * 0x88,8);
      return pauVar82;
    }
    lVar80 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
    if (lVar80 != 0) {
      puVar86 = (undefined8 *)(CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0)) + 8);
      do {
        if (puVar86[-1] != 0) {
          pauVar82 = (undefined1 (*) [16])
                     __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar86,puVar86[-1],1);
          return pauVar82;
        }
        puVar86 = puVar86 + 3;
        lVar80 = lVar80 + -1;
        uVar96 = 0;
      } while (lVar80 != 0);
    }
    lVar80 = CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc
                           (CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0)),lVar80 * 0x18
                            ,8);
      return pauVar82;
    }
  }
  else {
    pauStack_10080._4_4_ = (undefined4)((ulonglong)pauStack_10080 >> 0x20);
    pauStack_10080 = (undefined1 (*) [16])CONCAT44(pauStack_10080._4_4_,DAT_140699570);
    uStack_10088 = DAT_140699568;
    uVar117 = <std[3bf9d48a0c3997f0]::time::Instant>::elapsed(&uStack_10088);
    if (1 < uVar117) goto LAB_14002b068;
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699561 = '\x01';
      }
    }
    cVar72 = LAST_LOOKS;
    LOCK();
    LAST_LOOKS = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_LOOKS);
    }
  }
  if (IS_HOST_0_llvm_14435704873730135342 != '\0') {
    LOCK();
    bVar129 = LAST_FILES == '\0';
    if (bVar129) {
      LAST_FILES = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LAST_FILES);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
    }
    if (DAT_140699549 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&LAST_FILES;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1f80);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    if (DAT_140699558 != 0xffffffff) {
      pauStack_10080._4_4_ = (undefined4)((ulonglong)pauStack_10080 >> 0x20);
      pauStack_10080 = (undefined1 (*) [16])CONCAT44(pauStack_10080._4_4_,DAT_140699558);
      uStack_10088 = DAT_140699550;
      lVar80 = <std[3bf9d48a0c3997f0]::time::Instant>::elapsed(&uStack_10088);
      if ((lVar80 == 0) && (uVar96 < 100000000)) {
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar72 == '\0') {
            DAT_140699549 = '\x01';
          }
        }
        cVar72 = LAST_FILES;
        LOCK();
        LAST_FILES = '\0';
        UNLOCK();
        if (cVar72 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_FILES);
        }
        goto LAB_14002c311;
      }
    }
    uVar78 = (undefined4)((ulonglong)in_stack_fffffffffffefaa8 >> 0x20);
    DAT_140699550 = (undefined1 (*) [16])<std[3bf9d48a0c3997f0]::time::Instant>::now();
    DAT_140699558 = uVar96;
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699549 = '\x01';
      }
    }
    cVar72 = LAST_FILES;
    LOCK();
    LAST_FILES = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_FILES);
    }
    uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    uStack_103a8 = (ushort)uVar85;
    uStack_103a6 = (ushort)((ulonglong)uVar85 >> 0x10);
    uStack_103a4 = (ushort)((ulonglong)uVar85 >> 0x20);
    uStack_103a2 = (ushort)((ulonglong)uVar85 >> 0x30);
    uStack_103a0 = (ushort)uVar96;
    uStack_1039e = (ushort)(uVar96 >> 0x10);
    LOCK();
    bVar129 = DAT_140699948 == '\0';
    if (bVar129) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
      pauVar82 = DAT_140699950;
      uVar117 = DAT_140699958;
      lVar80 = DAT_140699968;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
      pauVar82 = DAT_140699950;
      uVar117 = DAT_140699958;
      lVar80 = DAT_140699968;
    }
    DAT_140699950 = pauVar82;
    DAT_140699958 = uVar117;
    DAT_140699968 = lVar80;
    if (DAT_140699949 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      uStack_10088 = (undefined1 (*) [16])&DAT_140699948;
      pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
      pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,bVar76);
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1f98);
      goto LAB_140036cf0;
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    auVar133 = *pauVar82;
    plVar94 = (longlong *)
              <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnOnce<(core[505b25137b8ba7f]::option::Option<&mut_core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>>>,)>>
              ::call_once(0);
    if (plVar94 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
      goto LAB_140036cf0;
    }
    puVar99 = *pauVar82 + uVar117 + 1;
    pauVar79 = pauVar82 + 1;
    uStack_10510 = ~((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
    lVar120 = *plVar94;
    ppauStack_10060 = (undefined1 (**) [16])plVar94[1];
    *plVar94 = *plVar94 + 1;
    uStack_10078._0_4_ = 0;
    uStack_10078._4_4_ = 0;
    abStack_10070[0] = 0;
    abStack_10070[1] = 0;
    uStack_1006e = 0;
    uStack_10088 = (undefined1 (*) [16])
                   &anon_1a1cfe3ac28698fadcb73c62956d839a_19_llvm_3977132774650517797;
    pauStack_10080 = (undefined1 (*) [16])0x0;
    pauStack_10068._0_1_ = (byte)lVar120;
    pauStack_10068._1_7_ = (undefined7)((ulonglong)lVar120 >> 8);
    uStack_10438._0_1_ = (byte)&uStack_103a8;
    uStack_10438._1_1_ = (byte)((ulonglong)&uStack_103a8 >> 8);
    uStack_10438._2_1_ = (byte)((ulonglong)&uStack_103a8 >> 0x10);
    uStack_10438._3_1_ = (byte)((ulonglong)&uStack_103a8 >> 0x18);
    uStack_10438._4_4_ = (int)((ulonglong)&uStack_103a8 >> 0x20);
    bStack_10430 = (byte)&uStack_10088;
    bStack_1042f = (byte)((ulonglong)&uStack_10088 >> 8);
    uStack_1042e = (ushort)((ulonglong)&uStack_10088 >> 0x10);
    uStack_1042c = (uint)((ulonglong)&uStack_10088 >> 0x20);
    bStack_10528 = (byte)pauVar82;
    bStack_10527 = (byte)((ulonglong)pauVar82 >> 8);
    bStack_10526 = (byte)((ulonglong)pauVar82 >> 0x10);
    bStack_10525 = (byte)((ulonglong)pauVar82 >> 0x18);
    bStack_10524 = (byte)((ulonglong)pauVar82 >> 0x20);
    bStack_10523 = (byte)((ulonglong)pauVar82 >> 0x28);
    bStack_10522 = (byte)((ulonglong)pauVar82 >> 0x30);
    bStack_10521 = (byte)((ulonglong)pauVar82 >> 0x38);
    bStack_10520 = (byte)pauVar79;
    bStack_1051f = (byte)((ulonglong)pauVar79 >> 8);
    bStack_1051e = (byte)((ulonglong)pauVar79 >> 0x10);
    bStack_1051d = (byte)((ulonglong)pauVar79 >> 0x18);
    bStack_1051c = (byte)((ulonglong)pauVar79 >> 0x20);
    bStack_1051b = (byte)((ulonglong)pauVar79 >> 0x28);
    bStack_1051a = (byte)((ulonglong)pauVar79 >> 0x30);
    bStack_10519 = (byte)((ulonglong)pauVar79 >> 0x38);
    bStack_10518 = (byte)puVar99;
    bStack_10517 = (byte)((ulonglong)puVar99 >> 8);
    uStack_10516 = (ushort)((ulonglong)puVar99 >> 0x10);
    uStack_10514 = (uint)((ulonglong)puVar99 >> 0x20);
    <hashbrown[ad6d4a1843b2832d]::raw::RawIterRange<(u64,host_probe[b94139f9089eb1d8]::net::Route)>>
    ::fold_impl::
    <<hashbrown[ad6d4a1843b2832d]::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::fold<(),core[505b25137b8ba7f]::iter::adapters::filter::filter_fold<(&u64,&host_probe[b94139f9089eb1d8]::net::Route),(),host_probe[b94139f9089eb1d8]::net::share_files::_closure_1_,core[505b25137b8ba7f]::iter::adapters::map::map_fold<(&u64,&host_probe[b94139f9089eb1d8]::net::Route),(u64,host_probe[b94139f9089eb1d8]::net::Route),(),host_probe[b94139f9089eb1d8]::net::share_files::_closure_2_,core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<(u64,host_probe[b94139f9089eb1d8]::net::Route),<hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>as_core[505b25137b8ba7f]::iter::traits::collect::Extend<(u64,host_probe[b94139f9089eb1d8]::net::Route)>>::extend<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::share_files::_closure_1_>,host_probe[b94139f9089eb1d8]::net::share_files::_closure_2_>>::_closure_0_>::_closure_0_>::_closure_0_>::_closure_0_>::_closure_0_,()>
              (&bStack_10528,lVar80,&uStack_10438);
    uStack_10510 = CONCAT11(abStack_10070[1],abStack_10070[0]);
    bStack_10528 = (byte)uStack_10088;
    bStack_10527 = (byte)((ulonglong)uStack_10088 >> 8);
    bStack_10526 = (byte)((ulonglong)uStack_10088 >> 0x10);
    bStack_10525 = (byte)((ulonglong)uStack_10088 >> 0x18);
    bStack_10524 = (byte)((ulonglong)uStack_10088 >> 0x20);
    bStack_10523 = (byte)((ulonglong)uStack_10088 >> 0x28);
    bStack_10522 = (byte)((ulonglong)uStack_10088 >> 0x30);
    bStack_10521 = (byte)((ulonglong)uStack_10088 >> 0x38);
    bStack_10520 = (byte)pauStack_10080;
    bStack_1051f = (byte)((ulonglong)pauStack_10080 >> 8);
    bStack_1051e = (byte)((ulonglong)pauStack_10080 >> 0x10);
    bStack_1051d = (byte)((ulonglong)pauStack_10080 >> 0x18);
    bStack_1051c = (byte)((ulonglong)pauStack_10080 >> 0x20);
    bStack_1051b = (byte)((ulonglong)pauStack_10080 >> 0x28);
    bStack_1051a = (byte)((ulonglong)pauStack_10080 >> 0x30);
    bStack_10519 = (byte)((ulonglong)pauStack_10080 >> 0x38);
    bStack_10518 = (byte)(uint)uStack_10078;
    bStack_10517 = (byte)((uint)uStack_10078 >> 8);
    uStack_10516 = (ushort)((uint)uStack_10078 >> 0x10);
    uStack_10514 = uStack_10078._4_4_;
    uStack_1050e = (ushort)uStack_1006e;
    uStack_1050c = (ushort)((uint6)uStack_1006e >> 0x10);
    uStack_1050a = (ushort)((uint6)uStack_1006e >> 0x20);
    uStack_10508._0_4_ = (uint)CONCAT71(pauStack_10068._1_7_,(byte)pauStack_10068);
    uStack_10508._4_4_ = (uint)((uint7)pauStack_10068._1_7_ >> 0x18);
    uStack_10500._0_4_ = (uint)ppauStack_10060;
    uStack_10500._4_4_ = (uint)((ulonglong)ppauStack_10060 >> 0x20);
    if (((bVar76 == 0) &&
        ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
         & 0x7fffffffffffffff) != 0)) &&
       (cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar72 == '\0')
       ) {
      DAT_140699949 = '\x01';
    }
    cVar72 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    pauVar82 = (undefined1 (*) [16])
               CONCAT17(bStack_10521,
                        CONCAT16(bStack_10522,
                                 CONCAT15(bStack_10523,
                                          CONCAT14(bStack_10524,
                                                   CONCAT13(bStack_10525,
                                                            CONCAT12(bStack_10526,
                                                                     CONCAT11(bStack_10527,
                                                                              bStack_10528)))))));
    uVar117 = CONCAT17(bStack_10519,
                       CONCAT16(bStack_1051a,
                                CONCAT15(bStack_1051b,
                                         CONCAT14(bStack_1051c,
                                                  CONCAT13(bStack_1051d,
                                                           CONCAT12(bStack_1051e,
                                                                    CONCAT11(bStack_1051f,
                                                                             bStack_10520)))))));
    uStack_10078 = (undefined1 (*) [16])(*pauVar82 + uVar117 + 1);
    auVar133 = *pauVar82;
    uVar112 = ~((ushort)(SUB161(auVar133 >> 7,0) & 1) | (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1
                | (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
    pauStack_10080 = pauVar82 + 1;
    lVar80 = CONCAT26(uStack_1050a,CONCAT24(uStack_1050c,CONCAT22(uStack_1050e,uStack_10510)));
    abStack_10070[0] = (byte)uVar112;
    abStack_10070[1] = (byte)(uVar112 >> 8);
    pauStack_10068._0_1_ = (byte)uStack_10510;
    pauStack_10068._1_7_ = (undefined7)((ulonglong)lVar80 >> 8);
    uStack_10088 = pauVar82;
    <alloc[246c2e7857c81348]::vec::Vec<(u64,(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>))>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(u64,(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>)),core[505b25137b8ba7f]::iter::adapters::map::Map<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::share_files::{closure#3}>>>
    ::from_iter(&uStack_10438,&uStack_10088);
    pauVar79 = (undefined1 (*) [16])
               CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
    in_stack_fffffffffffefaa8 = (undefined **)CONCAT44(uVar78,CONCAT22(uStack_1039e,uStack_103a0));
    fileshare::tick(&uStack_10088,pauVar79,
                    CONCAT44(uStack_10424,CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428))
                            ),
                    CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8))
                            ),in_stack_fffffffffffefaa8);
    puVar99 = *uStack_10078;
    pauVar123 = uStack_10088;
    pauVar92 = pauStack_10080 + (longlong)uStack_10078 * 2;
    uStack_10088 = pauStack_10080;
    uStack_10078._0_4_ = (uint)pauVar123;
    uStack_10078._4_4_ = (uint)((ulonglong)pauVar123 >> 0x20);
    abStack_10070[0] = (byte)pauVar92;
    abStack_10070[1] = (byte)((ulonglong)pauVar92 >> 8);
    uStack_1006e = (undefined6)((ulonglong)pauVar92 >> 0x10);
    pauStack_10448 = pauStack_10080;
    pauVar89 = pauStack_10080;
    if (puVar99 != (undefined1 *)0x0) {
      uStack_104c0 = pauVar123;
      pauVar84 = pauStack_10080;
      uStack_104b0 = pauVar79;
      do {
        pauVar104 = pauVar84 + 2;
        lVar120 = *(longlong *)(*pauVar84 + 8);
        pauVar79 = uStack_104b0;
        pauVar123 = uStack_104c0;
        pauVar89 = pauVar104;
        if (lVar120 == -1) break;
        lVar98 = *(longlong *)*pauVar84;
        uVar85 = *(undefined8 *)pauVar84[1];
        uVar4 = *(undefined8 *)(pauVar84[1] + 8);
        uStack_10278._0_1_ = (byte)lVar98;
        uStack_10278._1_1_ = (byte)((ulonglong)lVar98 >> 8);
        uStack_10276 = (ushort)((ulonglong)lVar98 >> 0x10);
        uStack_10274 = (ushort)((ulonglong)lVar98 >> 0x20);
        uStack_10272 = (ushort)((ulonglong)lVar98 >> 0x30);
        if (lVar80 != 0) {
          uVar81 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                   ::hash_one::<&usize>(&uStack_10508,&uStack_10278);
          bVar76 = (byte)(uVar81 >> 0x39);
          auVar133 = ZEXT216(CONCAT11(bVar76,bVar76));
          auVar133 = pshuflw(auVar133,auVar133,0);
          lVar128 = 0;
          while( true ) {
            uVar81 = uVar81 & uVar117;
            auVar137 = *(undefined1 (*) [16])(*pauVar82 + uVar81);
            auVar168[0] = -(auVar137[0] == auVar133[0]);
            auVar168[1] = -(auVar137[1] == auVar133[1]);
            auVar168[2] = -(auVar137[2] == auVar133[2]);
            auVar168[3] = -(auVar137[3] == auVar133[3]);
            auVar168[4] = -(auVar137[4] == auVar133[4]);
            auVar168[5] = -(auVar137[5] == auVar133[5]);
            auVar168[6] = -(auVar137[6] == auVar133[6]);
            auVar168[7] = -(auVar137[7] == auVar133[7]);
            auVar168[8] = -(auVar137[8] == auVar133[0]);
            auVar168[9] = -(auVar137[9] == auVar133[1]);
            auVar168[10] = -(auVar137[10] == auVar133[2]);
            auVar168[0xb] = -(auVar137[0xb] == auVar133[3]);
            auVar168[0xc] = -(auVar137[0xc] == auVar133[4]);
            auVar168[0xd] = -(auVar137[0xd] == auVar133[5]);
            auVar168[0xe] = -(auVar137[0xe] == auVar133[6]);
            auVar168[0xf] = -(auVar137[0xf] == auVar133[7]);
            uVar112 = (ushort)(SUB161(auVar168 >> 7,0) & 1) |
                      (ushort)(SUB161(auVar168 >> 0xf,0) & 1) << 1 |
                      (ushort)(SUB161(auVar168 >> 0x17,0) & 1) << 2 |
                      (ushort)(SUB161(auVar168 >> 0x1f,0) & 1) << 3 |
                      (ushort)(SUB161(auVar168 >> 0x27,0) & 1) << 4 |
                      (ushort)(SUB161(auVar168 >> 0x2f,0) & 1) << 5 |
                      (ushort)(SUB161(auVar168 >> 0x37,0) & 1) << 6 |
                      (ushort)(SUB161(auVar168 >> 0x3f,0) & 1) << 7 |
                      (ushort)(SUB161(auVar168 >> 0x47,0) & 1) << 8 |
                      (ushort)(SUB161(auVar168 >> 0x4f,0) & 1) << 9 |
                      (ushort)(SUB161(auVar168 >> 0x57,0) & 1) << 10 |
                      (ushort)(SUB161(auVar168 >> 0x5f,0) & 1) << 0xb |
                      (ushort)(SUB161(auVar168 >> 0x67,0) & 1) << 0xc |
                      (ushort)(SUB161(auVar168 >> 0x6f,0) & 1) << 0xd |
                      (ushort)(SUB161(auVar168 >> 0x77,0) & 1) << 0xe |
                      (ushort)(auVar168[0xf] >> 7) << 0xf;
            uVar113 = (uint)uVar112;
            while (uVar112 != 0) {
              uVar114 = 0;
              for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
                uVar114 = uVar114 + 1;
              }
              uVar83 = uVar114 + uVar81 & uVar117;
              if (lVar98 == *(longlong *)pauVar82[uVar83 * -5 + -5]) {
                in_stack_fffffffffffefaa8 =
                     (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),1);
                send_route_kind(&TRANSPORT,pauVar82[uVar83 * -5 + -5] + 8,uVar85,uVar4,
                                in_stack_fffffffffffefaa8);
                goto LAB_14002c22e;
              }
              uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
              uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
            }
            auVar139[0] = -(auVar137[0] == -1);
            auVar139[1] = -(auVar137[1] == -1);
            auVar139[2] = -(auVar137[2] == -1);
            auVar139[3] = -(auVar137[3] == -1);
            auVar139[4] = -(auVar137[4] == -1);
            auVar139[5] = -(auVar137[5] == -1);
            auVar139[6] = -(auVar137[6] == -1);
            auVar139[7] = -(auVar137[7] == -1);
            auVar139[8] = -(auVar137[8] == -1);
            auVar139[9] = -(auVar137[9] == -1);
            auVar139[10] = -(auVar137[10] == -1);
            auVar139[0xb] = -(auVar137[0xb] == -1);
            auVar139[0xc] = -(auVar137[0xc] == -1);
            auVar139[0xd] = -(auVar137[0xd] == -1);
            auVar139[0xe] = -(auVar137[0xe] == -1);
            auVar139[0xf] = -(auVar137[0xf] == -1);
            if ((((((((((((((((SUB161(auVar139 >> 7,0) & 1) != 0 ||
                             (SUB161(auVar139 >> 0xf,0) & 1) != 0) ||
                            (SUB161(auVar139 >> 0x17,0) & 1) != 0) ||
                           (SUB161(auVar139 >> 0x1f,0) & 1) != 0) ||
                          (SUB161(auVar139 >> 0x27,0) & 1) != 0) ||
                         (SUB161(auVar139 >> 0x2f,0) & 1) != 0) ||
                        (SUB161(auVar139 >> 0x37,0) & 1) != 0) ||
                       (SUB161(auVar139 >> 0x3f,0) & 1) != 0) ||
                      (SUB161(auVar139 >> 0x47,0) & 1) != 0) ||
                     (SUB161(auVar139 >> 0x4f,0) & 1) != 0) || (SUB161(auVar139 >> 0x57,0) & 1) != 0
                    ) || (SUB161(auVar139 >> 0x5f,0) & 1) != 0) ||
                  (SUB161(auVar139 >> 0x67,0) & 1) != 0) || (SUB161(auVar139 >> 0x6f,0) & 1) != 0)
                || (SUB161(auVar139 >> 0x77,0) & 1) != 0) || auVar139[0xf] < '\0') break;
            uVar81 = uVar81 + lVar128 + 0x10;
            lVar128 = lVar128 + 0x10;
          }
        }
LAB_14002c22e:
        if (lVar120 != 0) {
          pauVar82 = (undefined1 (*) [16])
                     __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar120,1);
          return pauVar82;
        }
        pauVar84 = pauVar104;
        pauVar79 = uStack_104b0;
        pauVar123 = uStack_104c0;
        pauVar89 = pauVar92;
      } while (pauVar104 != pauVar92);
    }
    unaff_R15 = pauVar89;
    pauStack_10080 = pauVar89;
    if ((longlong)pauVar92 - (longlong)pauVar89 != 0) {
      uVar81 = (ulonglong)((longlong)pauVar92 - (longlong)pauVar89) >> 5;
      unaff_R15 = pauVar89 + 1;
      do {
        if (*(longlong *)(unaff_R15[-1] + 8) != 0) {
          pauVar82 = (undefined1 (*) [16])
                     __rustc[9d087a5ab36ea756]::__rust_dealloc
                               (*(undefined8 *)*unaff_R15,*(longlong *)(unaff_R15[-1] + 8),1);
          return pauVar82;
        }
        unaff_R15 = unaff_R15 + 2;
        uVar81 = uVar81 - 1;
      } while (uVar81 != 0);
    }
    if (pauVar123 != (undefined1 (*) [16])0x0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc
                           (pauStack_10448,(longlong)pauVar123 << 5,8);
      return pauVar82;
    }
    lVar80 = CONCAT44(uStack_10438._4_4_,
                      CONCAT13(uStack_10438._3_1_,
                               CONCAT12(uStack_10438._2_1_,
                                        CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))));
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar79,lVar80 << 6,8);
      return pauVar82;
    }
    uStack_10500 = (undefined1 (*) [16])CONCAT44(uStack_10500._4_4_,(uint)uStack_10500);
    uStack_10078 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078);
    if ((uVar117 != 0) &&
       (lVar80 = uVar117 * 0x51 + 0x61,
       uStack_10500 = (undefined1 (*) [16])CONCAT44(uStack_10500._4_4_,(uint)uStack_10500),
       uStack_10078 = (undefined1 (*) [16])CONCAT44(uStack_10078._4_4_,(uint)uStack_10078),
       lVar80 != 0)) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc(pauVar82 + uVar117 * -5 + -5,lVar80,0x10)
      ;
      return pauVar82;
    }
  }
LAB_14002c311:
  uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
  share_vote(uVar85);
  LOCK();
  bVar129 = QUEUES == '\0';
  if (bVar129) {
    QUEUES = '\x01';
  }
  UNLOCK();
  if (!bVar129) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&QUEUES);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    uStack_10354 = 0;
  }
  else {
    uStack_10354 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    uStack_10354 = uStack_10354 ^ 1;
  }
  if (DAT_140699729 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    uStack_10088 = (undefined1 (*) [16])&QUEUES;
    pauStack_10080._1_7_ = (undefined7)((ulonglong)pauStack_10080 >> 8);
    pauStack_10080 = (undefined1 (*) [16])CONCAT71(pauStack_10080._1_7_,(char)uStack_10354);
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10088,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0db0
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2890);
    goto LAB_140036cf0;
  }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  memset(&uStack_10088,0,0x10000);
  iVar127 = -(uint)(CONCAT13(unaff_XMM7_Bd,
                             CONCAT12(unaff_XMM7_Bc,CONCAT11(unaff_XMM7_Bb,unaff_XMM7_Ba))) ==
                   CONCAT13(unaff_XMM7_Bd,
                            CONCAT12(unaff_XMM7_Bc,CONCAT11(unaff_XMM7_Bb,unaff_XMM7_Ba))));
  cVar72 = (char)iVar127;
  cVar181 = (char)((uint)iVar127 >> 8);
  cVar182 = (char)((uint)iVar127 >> 0x10);
  cVar183 = (char)((uint)iVar127 >> 0x18);
  iVar127 = -(uint)(CONCAT13(unaff_XMM7_Bh,
                             CONCAT12(unaff_XMM7_Bg,CONCAT11(unaff_XMM7_Bf,unaff_XMM7_Be))) ==
                   CONCAT13(unaff_XMM7_Bh,
                            CONCAT12(unaff_XMM7_Bg,CONCAT11(unaff_XMM7_Bf,unaff_XMM7_Be))));
  cVar184 = (char)iVar127;
  cVar185 = (char)((uint)iVar127 >> 8);
  cVar186 = (char)((uint)iVar127 >> 0x10);
  cVar187 = (char)((uint)iVar127 >> 0x18);
  iVar127 = -(uint)(CONCAT13(unaff_XMM7_Bl,
                             CONCAT12(unaff_XMM7_Bk,CONCAT11(unaff_XMM7_Bj,unaff_XMM7_Bi))) ==
                   CONCAT13(unaff_XMM7_Bl,
                            CONCAT12(unaff_XMM7_Bk,CONCAT11(unaff_XMM7_Bj,unaff_XMM7_Bi))));
  cVar188 = (char)iVar127;
  cVar189 = (char)((uint)iVar127 >> 8);
  cVar190 = (char)((uint)iVar127 >> 0x10);
  cVar191 = (char)((uint)iVar127 >> 0x18);
  iVar127 = -(uint)(CONCAT13(unaff_XMM7_Bp,
                             CONCAT12(unaff_XMM7_Bo,CONCAT11(unaff_XMM7_Bn,unaff_XMM7_Bm))) ==
                   CONCAT13(unaff_XMM7_Bp,
                            CONCAT12(unaff_XMM7_Bo,CONCAT11(unaff_XMM7_Bn,unaff_XMM7_Bm))));
  cVar192 = (char)iVar127;
  cVar193 = (char)((uint)iVar127 >> 8);
  cVar194 = (char)((uint)iVar127 >> 0x10);
  cVar195 = (char)((uint)iVar127 >> 0x18);
  puStack_101e0 = &DAT_1407f1070;
  puStack_101e8 = &DAT_1407f1078;
  ppuStack_10188 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0400;
LAB_14002c3ba:
  <std[3bf9d48a0c3997f0]::net::udp::UdpSocket>::recv_from
            (&pauStack_101b8,&DAT_140699980,&uStack_10088,0x10000);
  if (sStack_101b0 == 2) goto LAB_1400349cc;
  uStack_10498 = (ushort)uStack_101a0;
  uStack_10496 = (ushort)((ulonglong)uStack_101a0 >> 0x10);
  uStack_10494 = (uint)((ulonglong)uStack_101a0 >> 0x20);
  uStack_10490 = uStack_10198;
  bStack_104a8 = (byte)sStack_101b0;
  bStack_104a7 = (byte)((ushort)sStack_101b0 >> 8);
  uStack_104a6 = uStack_101ae;
  uStack_104a4 = (ushort)uStack_101ac;
  uStack_104a2 = (ushort)((uint)uStack_101ac >> 0x10);
  uStack_104a0 = (ushort)uStack_101a8;
  uStack_1049e = (ushort)((ulonglong)uStack_101a8 >> 0x10);
  uStack_1049c = (uint)((ulonglong)uStack_101a8 >> 0x20);
  bStack_10471 = 0;
  pauStack_10448 = pauStack_101b8;
  if ((undefined1 (*) [16])0x10000 < pauStack_101b8) {
    core[505b25137b8ba7f]::slice::index::slice_index_fail
              (0,pauStack_101b8,0x10000,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2e10);
    goto LAB_140036cf0;
  }
  reach_directory[4b72b9694f6c3c08]::rendezvous::relay_unwrap(&bStack_10528,&uStack_10088);
  pauStack_10538 = pauStack_10448;
  uVar112 = uStack_1050a;
  bVar75 = bStack_10519;
  bVar76 = bStack_10521;
  pvVar87 = (void *)CONCAT44(uStack_10514,CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518))
                            );
  if (pvVar87 != (void *)0x0) {
    uVar26 = CONCAT16(bStack_10522,
                      CONCAT15(bStack_10523,
                               CONCAT14(bStack_10524,
                                        CONCAT13(bStack_10525,
                                                 CONCAT12(bStack_10526,
                                                          CONCAT11(bStack_10527,bStack_10528))))));
    lVar80 = CONCAT17(bStack_10521,uVar26);
    uVar28 = CONCAT16(bStack_1051a,
                      CONCAT15(bStack_1051b,
                               CONCAT14(bStack_1051c,
                                        CONCAT13(bStack_1051d,
                                                 CONCAT12(bStack_1051e,
                                                          CONCAT11(bStack_1051f,bStack_10520))))));
    lVar120 = CONCAT17(bStack_10519,uVar28);
    pauStack_10538 =
         (undefined1 (*) [16])
         CONCAT26(uStack_1050a,CONCAT24(uStack_1050c,CONCAT22(uStack_1050e,uStack_10510)));
    LOCK();
    bVar129 = RELAY_SESSIONS == '\0';
    if (bVar129) {
      RELAY_SESSIONS = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&RELAY_SESSIONS);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0) {
      bVar73 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar73 = bVar73 ^ 1;
      if (DAT_140699611 == '\0') goto LAB_14002c4a2;
LAB_1400353c1:
      uStack_10438._0_1_ = 0x10;
      uStack_10438._1_1_ = 0x96;
      uStack_10438._2_1_ = 0x69;
      uStack_10438._3_1_ = 0x40;
      uStack_10438._4_4_ = 1;
      bStack_10430 = bVar73;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                 &
                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0fb0
                 ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a28a8);
      goto LAB_140036cf0;
    }
    bVar73 = 0;
    if (DAT_140699611 != '\0') goto LAB_1400353c1;
LAB_14002c4a2:
    if (DAT_140699628 != 0) {
      lVar98 = 0;
      do {
        if (*(longlong *)(DAT_140699620 + 8 + lVar98) == lVar120 &&
            *(longlong *)(DAT_140699620 + lVar98) == lVar80) {
          if ((bVar73 == 0) &&
             ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) != 0)) {
            cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            if (cVar74 == '\0') {
              DAT_140699611 = '\x01';
            }
          }
          cVar74 = RELAY_SESSIONS;
          LOCK();
          RELAY_SESSIONS = '\0';
          UNLOCK();
          if (cVar74 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&RELAY_SESSIONS);
          }
          bStack_10471 = 1;
          bStack_10469 = bVar76;
          bStack_10461 = bVar75;
          uStack_10470 = uVar26;
          uStack_10468 = uVar28;
          if ((short)uVar112 < 0) {
            uVar85 = 0;
            goto LAB_1400349a6;
          }
          if (pauStack_10538 == (undefined1 (*) [16])0x0) {
            pauStack_10280 = (undefined1 (*) [16])0x1;
            goto LAB_14002c763;
          }
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_alloc(pauStack_10538,1);
          if (pauVar82 == (undefined1 (*) [16])0x0) goto LAB_140036811;
          memcpy(pauVar82,pvVar87,(size_t)pauStack_10538);
          uStack_104b0 = pauVar82;
          pauStack_10280 = pauVar82;
          if ((undefined1 (*) [16])&DAT_00000007 < pauStack_10538) goto LAB_14002c64e;
          goto LAB_14002c58e;
        }
        lVar98 = lVar98 + 0x10;
      } while (DAT_140699628 * 0x10 != lVar98);
    }
    if ((bVar73 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar74 == '\0') {
        DAT_140699611 = '\x01';
      }
    }
    cVar74 = RELAY_SESSIONS;
    LOCK();
    RELAY_SESSIONS = '\0';
    UNLOCK();
    if (cVar74 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&RELAY_SESSIONS);
    }
    LOCK();
    DAT_1407f1070 = *pauStack_10448 + (longlong)DAT_1407f1070;
    UNLOCK();
    LOCK();
    DAT_1407f1078 = DAT_1407f1078 + 1;
    UNLOCK();
    goto LAB_14002c3ba;
  }
  if (pauStack_10448 == (undefined1 (*) [16])0x0) {
LAB_14002c763:
    bVar129 = true;
    uStack_104b0 = (undefined1 (*) [16])0x1;
    pauStack_10538 = (undefined1 (*) [16])0x0;
LAB_14002c76e:
    reach_directory[4b72b9694f6c3c08]::rendezvous::decode(&uStack_10278);
    uVar69 = uStack_1050a;
    uVar68 = uStack_1050c;
    uVar91 = uStack_1050e;
    uVar112 = uStack_10510;
    bVar66 = bStack_10517;
    bVar65 = bStack_10518;
    bVar64 = bStack_10519;
    bVar63 = bStack_1051a;
    bVar62 = bStack_1051b;
    bVar61 = bStack_1051c;
    bVar60 = bStack_1051d;
    bVar59 = bStack_1051e;
    bVar58 = bStack_1051f;
    bVar57 = bStack_10520;
    bVar56 = bStack_10521;
    bVar132 = bStack_10522;
    bVar55 = bStack_10523;
    bVar54 = bStack_10524;
    bVar73 = bStack_10525;
    bVar76 = bStack_10526;
    uStack_10510 = (ushort)uStack_10490;
    uStack_1050e = (ushort)(uStack_10490 >> 0x10);
    uStack_1050c = (ushort)(uStack_10490 >> 0x20);
    uStack_1050a = (ushort)(uStack_10490 >> 0x30);
    bStack_10522 = (byte)uStack_104a2;
    bStack_10521 = (byte)(uStack_104a2 >> 8);
    bStack_1051c = (byte)uStack_1049c;
    bStack_1051b = (byte)(uStack_1049c >> 8);
    bStack_1051a = (byte)(uStack_1049c >> 0x10);
    bStack_10519 = (byte)(uStack_1049c >> 0x18);
    bStack_10518 = (byte)uStack_10498;
    bStack_10517 = (byte)(uStack_10498 >> 8);
    bStack_10524 = (byte)uStack_104a4;
    bStack_10523 = (byte)(uStack_104a4 >> 8);
    bStack_10520 = (byte)uStack_104a0;
    bStack_1051f = (byte)(uStack_104a0 >> 8);
    bStack_1051e = (byte)uStack_1049e;
    bStack_1051d = (byte)(uStack_1049e >> 8);
    bStack_10526 = (byte)uStack_104a6;
    bStack_10525 = (byte)(uStack_104a6 >> 8);
    if (CONCAT26(uStack_10272,
                 CONCAT24(uStack_10274,
                          CONCAT22(uStack_10276,CONCAT11(uStack_10278._1_1_,(byte)uStack_10278))))
        == -1) {
      if (bVar129) goto LAB_1400331c4;
      uStack_103c8 = *(undefined1 (**) [16])*uStack_104b0;
      pauVar82 = (undefined1 (*) [16])(pauStack_10538[-1] + 8);
      pauVar79 = (undefined1 (*) [16])(*uStack_104b0 + 8);
      if (pauStack_10538 < (undefined1 (*) [16])&DAT_00000010) {
        if (DAT_140699988 == '\0') goto LAB_14002c840;
LAB_14002da29:
        LOCK();
        bVar129 = DAT_1406998e8 == '\0';
        if (bVar129) {
          DAT_1406998e8 = '\x01';
        }
        UNLOCK();
        bStack_10526 = bVar76;
        bStack_10525 = bVar73;
        bStack_10524 = bVar54;
        bStack_10523 = bVar55;
        bStack_10522 = bVar132;
        bStack_10521 = bVar56;
        bStack_10520 = bVar57;
        bStack_1051f = bVar58;
        bStack_1051e = bVar59;
        bStack_1051d = bVar60;
        bStack_1051c = bVar61;
        bStack_1051b = bVar62;
        bStack_1051a = bVar63;
        bStack_10519 = bVar64;
        bStack_10518 = bVar65;
        bStack_10517 = bVar66;
        uStack_10510 = uVar112;
        uStack_1050e = uVar91;
        uStack_1050c = uVar68;
        uStack_1050a = uVar69;
        if (!bVar129) {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_1406998e8);
        }
        if ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) == 0) {
          bVar76 = 0;
        }
        else {
          bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          bVar76 = bVar76 ^ 1;
        }
        if (DAT_1406998e9 == '\0') {
          <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
          ::retain::<host_probe[b94139f9089eb1d8]::net::receive::_closure_10_>
                    (&DAT_1406998f0,&bStack_104a8,&bStack_10471);
          if ((bVar76 == 0) &&
             ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) != 0)) {
            cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            if (cVar74 == '\0') {
              DAT_1406998e9 = '\x01';
            }
          }
          cVar74 = DAT_1406998e8;
          LOCK();
          DAT_1406998e8 = '\0';
          UNLOCK();
          bVar76 = bStack_10526;
          bVar73 = bStack_10525;
          bVar54 = bStack_10524;
          bVar55 = bStack_10523;
          bVar132 = bStack_10522;
          bVar56 = bStack_10521;
          bVar57 = bStack_10520;
          bVar58 = bStack_1051f;
          bVar59 = bStack_1051e;
          bVar60 = bStack_1051d;
          bVar61 = bStack_1051c;
          bVar62 = bStack_1051b;
          bVar63 = bStack_1051a;
          bVar64 = bStack_10519;
          bVar65 = bStack_10518;
          bVar66 = bStack_10517;
          uVar112 = uStack_10510;
          uVar91 = uStack_1050e;
          uVar68 = uStack_1050c;
          uVar69 = uStack_1050a;
          if (cVar74 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_1406998e8);
            bVar76 = bStack_10526;
            bVar73 = bStack_10525;
            bVar54 = bStack_10524;
            bVar55 = bStack_10523;
            bVar132 = bStack_10522;
            bVar56 = bStack_10521;
            bVar57 = bStack_10520;
            bVar58 = bStack_1051f;
            bVar59 = bStack_1051e;
            bVar60 = bStack_1051d;
            bVar61 = bStack_1051c;
            bVar62 = bStack_1051b;
            bVar63 = bStack_1051a;
            bVar64 = bStack_10519;
            bVar65 = bStack_10518;
            bVar66 = bStack_10517;
            uVar112 = uStack_10510;
            uVar91 = uStack_1050e;
            uVar68 = uStack_1050c;
            uVar69 = uStack_1050a;
          }
LAB_14002dab7:
          uStack_1050a = uVar69;
          uStack_1050c = uVar68;
          uStack_1050e = uVar91;
          uStack_10510 = uVar112;
          bStack_10517 = bVar66;
          bStack_10518 = bVar65;
          bStack_10519 = bVar64;
          bStack_1051a = bVar63;
          bStack_1051b = bVar62;
          bStack_1051c = bVar61;
          bStack_1051d = bVar60;
          bStack_1051e = bVar59;
          bStack_1051f = bVar58;
          bStack_10520 = bVar57;
          bStack_10521 = bVar56;
          bStack_10522 = bVar132;
          bStack_10523 = bVar55;
          bStack_10524 = bVar54;
          bStack_10525 = bVar73;
          bStack_10526 = bVar76;
          cVar74 = receive::NOTED;
          cStack_10530 = '\x01';
          LOCK();
          receive::NOTED = '\x01';
          UNLOCK();
          if (cVar74 == '\0') {
            host::log("net: lobby profile mismatch refused before engine decode; update and join through the Server Browser"
                      ,100);
          }
          goto LAB_1400331d0;
        }
        bStack_10528 = 0xe8;
        bStack_10527 = 0x98;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar76;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2ad0)
        ;
      }
      else {
        bVar129 = *(longlong *)*pauVar79 != 0x31304749422d5252;
        if (DAT_140699988 == '\0') {
          if (!bVar129) goto LAB_14002dab7;
        }
        else {
          if (((pauStack_10538 == (undefined1 (*) [16])&DAT_00000010) || (bVar129)) ||
             (uStack_104b0[1][0] != DAT_140699988)) goto LAB_14002da29;
          pauVar82 = (undefined1 (*) [16])(pauStack_10538[-2] + 0xf);
          pauVar79 = (undefined1 (*) [16])(uStack_104b0[1] + 1);
        }
LAB_14002c840:
        cStack_10530 = '\x01';
        uStack_10516 = uStack_10496;
        uStack_10514 = uStack_10494;
        bStack_10528 = bStack_104a8;
        bStack_10527 = bStack_104a7;
        uStack_10460 = pauVar79;
        uStack_10458 = pauVar82;
        cVar74 = is_blocked();
        if (cVar74 != '\0') goto LAB_1400331d0;
        LOCK();
        bVar129 = DAT_140699948 == '\0';
        if (bVar129) {
          DAT_140699948 = '\x01';
        }
        UNLOCK();
        if (!bVar129) {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
        }
        if ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) == 0) {
          uStack_104c0 = (undefined1 (*) [16])((ulonglong)uStack_104c0 & 0xffffffff00000000);
        }
        else {
          uVar78 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          uStack_104c0 = (undefined1 (*) [16])(CONCAT44(uStack_104c0._4_4_,uVar78) ^ 1);
        }
        if (DAT_140699949 == '\0') {
          LOCK();
          bVar129 = TRANSPORT == '\0';
          if (bVar129) {
            TRANSPORT = '\x01';
          }
          UNLOCK();
          if (!bVar129) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&TRANSPORT);
          }
          if ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) == 0) {
            bVar75 = 0;
            bVar76 = bStack_10520;
          }
          else {
            bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar75 = bVar76 ^ 1;
            bVar76 = bStack_10520;
          }
          bStack_10520 = bVar75;
          if (DAT_140699831 == '\0') {
            if ((DAT_140699860 & 1) != 0) {
              bVar129 = bStack_10520 == 0;
              bStack_10520 = bVar76;
              if ((bVar129) &&
                 ((*(ulonglong *)
                    __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                  0x7fffffffffffffff) != 0)) {
                cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                if (cVar74 == '\0') {
                  DAT_140699831 = '\x01';
                }
              }
              cVar74 = TRANSPORT;
              LOCK();
              TRANSPORT = '\0';
              UNLOCK();
              if (cVar74 == '\x02') {
                <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
              }
              if ((HOST_ID_0_llvm_14435704873730135342 == uStack_103c8 ||
                  HOST_ID_0_llvm_14435704873730135342 == (undefined1 (*) [16])0x0) ||
                  IS_HOST_0_llvm_14435704873730135342 != '\0') goto LAB_14002c9b1;
              goto LAB_14002dfa3;
            }
            bVar129 = bStack_10520 == 0;
            bStack_10520 = bVar76;
            if ((bVar129) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar74 == '\0') {
                DAT_140699831 = '\x01';
              }
            }
            cVar74 = TRANSPORT;
            LOCK();
            TRANSPORT = '\0';
            UNLOCK();
            if (cVar74 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
            }
LAB_14002c9b1:
            pauVar82 = uStack_103c8;
            bVar76 = bStack_10471;
            uVar113 = uStack_10494;
            lVar120 = CONCAT17(bStack_10461,uStack_10468);
            lVar80 = CONCAT17(bStack_10469,uStack_10470);
            sVar116 = CONCAT11(bStack_104a7,bStack_104a8);
            bStack_10528 = (byte)uStack_104a6;
            bStack_10527 = (byte)(uStack_104a6 >> 8);
            bStack_10526 = (byte)uStack_104a4;
            bStack_10525 = (byte)(uStack_104a4 >> 8);
            bStack_10524 = (byte)uStack_104a2;
            bStack_10523 = (byte)(uStack_104a2 >> 8);
            bStack_10522 = (byte)uStack_104a0;
            bStack_10521 = (byte)(uStack_104a0 >> 8);
            bStack_10520 = (byte)uStack_1049e;
            bStack_1051f = (byte)(uStack_1049e >> 8);
            bStack_1051e = (byte)uStack_1049c;
            bStack_1051d = (byte)(uStack_1049c >> 8);
            bStack_1051c = (byte)(uStack_1049c >> 0x10);
            bStack_1051b = (byte)(uStack_1049c >> 0x18);
            bStack_1051a = (byte)uStack_10498;
            bStack_10519 = (byte)(uStack_10498 >> 8);
            bStack_10518 = (byte)uStack_10496;
            bStack_10517 = (byte)(uStack_10496 >> 8);
            iVar127 = (int)uStack_10490;
            uVar112 = uStack_10490._4_2_;
            unaff_R15 = (undefined1 (*) [16])(ulonglong)uStack_10490._4_2_;
            uStack_10438._0_1_ = (byte)uStack_103c8;
            bVar75 = (byte)uStack_10438;
            uStack_10438._1_1_ = (byte)((ulonglong)uStack_103c8 >> 8);
            bVar73 = uStack_10438._1_1_;
            uStack_10438._2_1_ = (byte)((ulonglong)uStack_103c8 >> 0x10);
            bVar54 = uStack_10438._2_1_;
            uStack_10438._3_1_ = (byte)((ulonglong)uStack_103c8 >> 0x18);
            bVar55 = uStack_10438._3_1_;
            uStack_10438._4_4_ = (int)((ulonglong)uStack_103c8 >> 0x20);
            if (DAT_140699968 != 0) {
              uVar81 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                       ::hash_one::<&usize>(&DAT_140699970);
              uVar117 = DAT_140699958;
              bVar132 = (byte)(uVar81 >> 0x39);
              auVar133 = ZEXT216(CONCAT11(bVar132,bVar132));
              auVar133 = pshuflw(auVar133,auVar133,0);
              lVar98 = 0;
              uStack_104b8 = DAT_140699950;
              do {
                uVar81 = uVar81 & DAT_140699958;
                pcVar109 = *DAT_140699950 + uVar81;
                auVar169[0] = -(*pcVar109 == auVar133[0]);
                auVar169[1] = -(pcVar109[1] == auVar133[1]);
                auVar169[2] = -(pcVar109[2] == auVar133[2]);
                auVar169[3] = -(pcVar109[3] == auVar133[3]);
                auVar169[4] = -(pcVar109[4] == auVar133[4]);
                auVar169[5] = -(pcVar109[5] == auVar133[5]);
                auVar169[6] = -(pcVar109[6] == auVar133[6]);
                auVar169[7] = -(pcVar109[7] == auVar133[7]);
                auVar169[8] = -(pcVar109[8] == auVar133[0]);
                auVar169[9] = -(pcVar109[9] == auVar133[1]);
                auVar169[10] = -(pcVar109[10] == auVar133[2]);
                auVar169[0xb] = -(pcVar109[0xb] == auVar133[3]);
                auVar169[0xc] = -(pcVar109[0xc] == auVar133[4]);
                auVar169[0xd] = -(pcVar109[0xd] == auVar133[5]);
                auVar169[0xe] = -(pcVar109[0xe] == auVar133[6]);
                auVar169[0xf] = -(pcVar109[0xf] == auVar133[7]);
                uVar91 = (ushort)(SUB161(auVar169 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar169 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar169 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar169 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar169 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar169 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar169 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar169 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar169 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar169 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar169 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar169 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar169 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar169 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar169 >> 0x77,0) & 1) << 0xe |
                         (ushort)(auVar169[0xf] >> 7) << 0xf;
                uVar114 = (uint)uVar91;
                while (uVar91 != 0) {
                  uVar96 = 0;
                  for (uVar95 = uVar114; (uVar95 & 1) == 0; uVar95 = uVar95 >> 1 | 0x80000000) {
                    uVar96 = uVar96 + 1;
                  }
                  uVar83 = uVar96 + uVar81 & DAT_140699958;
                  if (pauVar82 == *(undefined1 (**) [16])DAT_140699950[uVar83 * -5 + -5]) {
                    if (*(short *)(DAT_140699950[uVar83 * -5 + -4] + 8) == sVar116) {
                      if (sVar116 == 1) {
                        if ((*(ushort *)(DAT_140699950[uVar83 * -5 + -2] + 4) == uVar112) &&
                           (((*(uint *)(DAT_140699950[uVar83 * -5 + -3] + 0xc) == uVar113 &&
                             (*(int *)DAT_140699950[uVar83 * -5 + -2] == iVar127)) &&
                            (auVar141[0] = -(bStack_10526 == DAT_140699950[uVar83 * -5 + -4][0xc]),
                            auVar141[1] = -(bStack_10525 == DAT_140699950[uVar83 * -5 + -4][0xd]),
                            auVar141[2] = -(bStack_10524 == DAT_140699950[uVar83 * -5 + -4][0xe]),
                            auVar141[3] = -(bStack_10523 == DAT_140699950[uVar83 * -5 + -4][0xf]),
                            auVar141[4] = -(bStack_10522 == DAT_140699950[uVar83 * -5 + -3][0]),
                            auVar141[5] = -(bStack_10521 == DAT_140699950[uVar83 * -5 + -3][1]),
                            auVar141[6] = -(bStack_10520 == DAT_140699950[uVar83 * -5 + -3][2]),
                            auVar141[7] = -(bStack_1051f == DAT_140699950[uVar83 * -5 + -3][3]),
                            auVar141[8] = -(bStack_1051e == DAT_140699950[uVar83 * -5 + -3][4]),
                            auVar141[9] = -(bStack_1051d == DAT_140699950[uVar83 * -5 + -3][5]),
                            auVar141[10] = -(bStack_1051c == DAT_140699950[uVar83 * -5 + -3][6]),
                            auVar141[0xb] = -(bStack_1051b == DAT_140699950[uVar83 * -5 + -3][7]),
                            auVar141[0xc] = -(bStack_1051a == DAT_140699950[uVar83 * -5 + -3][8]),
                            auVar141[0xd] = -(bStack_10519 == DAT_140699950[uVar83 * -5 + -3][9]),
                            auVar141[0xe] = -(bStack_10518 == DAT_140699950[uVar83 * -5 + -3][10]),
                            auVar141[0xf] = -(bStack_10517 == DAT_140699950[uVar83 * -5 + -3][0xb]),
                            (ushort)((ushort)(SUB161(auVar141 >> 7,0) & 1) |
                                     (ushort)(SUB161(auVar141 >> 0xf,0) & 1) << 1 |
                                     (ushort)(SUB161(auVar141 >> 0x17,0) & 1) << 2 |
                                     (ushort)(SUB161(auVar141 >> 0x1f,0) & 1) << 3 |
                                     (ushort)(SUB161(auVar141 >> 0x27,0) & 1) << 4 |
                                     (ushort)(SUB161(auVar141 >> 0x2f,0) & 1) << 5 |
                                     (ushort)(SUB161(auVar141 >> 0x37,0) & 1) << 6 |
                                     (ushort)(SUB161(auVar141 >> 0x3f,0) & 1) << 7 |
                                     (ushort)(SUB161(auVar141 >> 0x47,0) & 1) << 8 |
                                     (ushort)(SUB161(auVar141 >> 0x4f,0) & 1) << 9 |
                                     (ushort)(SUB161(auVar141 >> 0x57,0) & 1) << 10 |
                                     (ushort)(SUB161(auVar141 >> 0x5f,0) & 1) << 0xb |
                                     (ushort)(SUB161(auVar141 >> 0x67,0) & 1) << 0xc |
                                     (ushort)(SUB161(auVar141 >> 0x6f,0) & 1) << 0xd |
                                     (ushort)(SUB161(auVar141 >> 0x77,0) & 1) << 0xe |
                                    (ushort)(auVar141[0xf] >> 7) << 0xf) == 0xffff)))) {
LAB_14002cc95:
                          if (DAT_140699950[uVar83 * -5 + -2][8] == '\x01') {
                            if (((bVar76 & 1) != 0) &&
                               (lVar120 == *(longlong *)(DAT_140699950[uVar83 * -5 + -1] + 1) &&
                                lVar80 == *(longlong *)(DAT_140699950[uVar83 * -5 + -2] + 9))) {
LAB_14002cd60:
                              uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
                              if (DAT_140699968 == 0) goto LAB_1400349bb;
                              uVar117 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                                        ::hash_one::<&usize>(&DAT_140699970,&uStack_103c8);
                              pauVar82 = DAT_140699950;
                              bVar76 = (byte)(uVar117 >> 0x39);
                              auVar133 = ZEXT216(CONCAT11(bVar76,bVar76));
                              auVar133 = pshuflw(auVar133,auVar133,0);
                              lVar80 = 0;
                              goto LAB_14002cdc2;
                            }
                          }
                          else if ((bVar76 & 1) == 0) goto LAB_14002cd60;
                        }
                      }
                      else if ((*(short *)(DAT_140699950[uVar83 * -5 + -4] + 0xe) ==
                                CONCAT11(bStack_10523,bStack_10524)) &&
                              (*(int *)(DAT_140699950[uVar83 * -5 + -4] + 10) ==
                               CONCAT13(bStack_10525,
                                        CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))))
                              ) goto LAB_14002cc95;
                    }
                    uVar81 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                             ::hash_one::<&usize>(&DAT_140699970,&uStack_103c8);
                    pauVar79 = uStack_104b8;
                    bVar76 = (byte)(uVar81 >> 0x39);
                    auVar133 = ZEXT216(CONCAT11(bVar76,bVar76));
                    auVar133 = pshuflw(auVar133,auVar133,0);
                    lVar80 = 0;
                    goto LAB_14002cce8;
                  }
                  uVar91 = (ushort)(uVar114 - 1) & (ushort)uVar114;
                  uVar114 = CONCAT22((short)(uVar114 - 1 >> 0x10),uVar91);
                }
                auVar140[0] = -(*pcVar109 == cVar72);
                auVar140[1] = -(pcVar109[1] == cVar181);
                auVar140[2] = -(pcVar109[2] == cVar182);
                auVar140[3] = -(pcVar109[3] == cVar183);
                auVar140[4] = -(pcVar109[4] == cVar184);
                auVar140[5] = -(pcVar109[5] == cVar185);
                auVar140[6] = -(pcVar109[6] == cVar186);
                auVar140[7] = -(pcVar109[7] == cVar187);
                auVar140[8] = -(pcVar109[8] == cVar188);
                auVar140[9] = -(pcVar109[9] == cVar189);
                auVar140[10] = -(pcVar109[10] == cVar190);
                auVar140[0xb] = -(pcVar109[0xb] == cVar191);
                auVar140[0xc] = -(pcVar109[0xc] == cVar192);
                auVar140[0xd] = -(pcVar109[0xd] == cVar193);
                auVar140[0xe] = -(pcVar109[0xe] == cVar194);
                auVar140[0xf] = -(pcVar109[0xf] == cVar195);
                if ((((((((((((((((SUB161(auVar140 >> 7,0) & 1) != 0 ||
                                 (SUB161(auVar140 >> 0xf,0) & 1) != 0) ||
                                (SUB161(auVar140 >> 0x17,0) & 1) != 0) ||
                               (SUB161(auVar140 >> 0x1f,0) & 1) != 0) ||
                              (SUB161(auVar140 >> 0x27,0) & 1) != 0) ||
                             (SUB161(auVar140 >> 0x2f,0) & 1) != 0) ||
                            (SUB161(auVar140 >> 0x37,0) & 1) != 0) ||
                           (SUB161(auVar140 >> 0x3f,0) & 1) != 0) ||
                          (SUB161(auVar140 >> 0x47,0) & 1) != 0) ||
                         (SUB161(auVar140 >> 0x4f,0) & 1) != 0) ||
                        (SUB161(auVar140 >> 0x57,0) & 1) != 0) ||
                       (SUB161(auVar140 >> 0x5f,0) & 1) != 0) ||
                      (SUB161(auVar140 >> 0x67,0) & 1) != 0) ||
                     (SUB161(auVar140 >> 0x6f,0) & 1) != 0) || (SUB161(auVar140 >> 0x77,0) & 1) != 0
                    ) || auVar140[0xf] < '\0') break;
                uVar81 = uVar81 + lVar98 + 0x10;
                lVar98 = lVar98 + 0x10;
              } while( true );
            }
            if ((bVar76 & 1) != 0) goto LAB_14002ce9d;
            LOCK();
            bVar129 = MASTERS == '\0';
            if (bVar129) {
              MASTERS = '\x01';
            }
            UNLOCK();
            if (!bVar129) {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&MASTERS);
            }
            if ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) == 0) {
              bVar75 = 0;
              bVar76 = bStack_10520;
            }
            else {
              bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              bVar75 = bVar76 ^ 1;
              bVar76 = bStack_10520;
            }
            bStack_10520 = bVar75;
            if (DAT_140699791 == '\0') {
              if (DAT_1406997a8 == 0) {
                pcVar109 = &MASTERS;
                bVar75 = bStack_10520;
                goto joined_r0x00014002ce72;
              }
              bVar129 = bStack_10520 == 0;
              bStack_10520 = bVar76;
              if ((bVar129) &&
                 ((*(ulonglong *)
                    __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                  0x7fffffffffffffff) != 0)) {
                cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                if (cVar74 == '\0') {
                  DAT_140699791 = '\x01';
                }
              }
              cVar74 = MASTERS;
              LOCK();
              MASTERS = '\0';
              UNLOCK();
              if (cVar74 == '\x02') {
                <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&MASTERS);
              }
              LOCK();
              bVar129 = INTRODUCED == '\0';
              if (bVar129) {
                INTRODUCED = '\x01';
              }
              UNLOCK();
              if (!bVar129) {
                <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&INTRODUCED)
                ;
              }
              if ((*(ulonglong *)
                    __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                  0x7fffffffffffffff) == 0) {
                bVar75 = 0;
                bVar76 = bStack_10520;
                uVar117 = uStack_10490;
              }
              else {
                bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                bVar75 = bVar76 ^ 1;
                bVar76 = bStack_10520;
                uVar117 = uStack_10490;
              }
              bStack_10520 = bVar75;
              uStack_10490 = uVar117;
              if (DAT_140699529 == '\0') {
                if (DAT_140699540 != 0) {
                  if ((bStack_104a8 & 1) == 0) {
                    lVar80 = 0;
                    do {
                      if (((*(char *)(DAT_140699538 + lVar80) == '\0') &&
                          (*(ushort *)(DAT_140699538 + 6 + lVar80) == uStack_104a2)) &&
                         (*(int *)(DAT_140699538 + 2 + lVar80) ==
                          CONCAT22(uStack_104a4,uStack_104a6))) goto LAB_14002d6af;
                      lVar80 = lVar80 + 0x20;
                    } while (DAT_140699540 * 0x20 != lVar80);
                  }
                  else {
                    uStack_10490._4_2_ = (ushort)(uVar117 >> 0x20);
                    uStack_10490._0_4_ = (int)uVar117;
                    lVar80 = 0;
                    do {
                      if ((((*(short *)(DAT_140699538 + lVar80) != 0) &&
                           (*(short *)(DAT_140699538 + 0x1c + lVar80) == uStack_10490._4_2_)) &&
                          (*(uint *)(DAT_140699538 + 0x14 + lVar80) == uStack_10494)) &&
                         ((*(int *)(DAT_140699538 + 0x18 + lVar80) == (int)uStack_10490 &&
                          (*(longlong *)(DAT_140699538 + 0xc + lVar80) ==
                           CONCAT26(uStack_10496,CONCAT24(uStack_10498,uStack_1049c)) &&
                           *(longlong *)(DAT_140699538 + 4 + lVar80) ==
                           CONCAT26(uStack_1049e,
                                    CONCAT24(uStack_104a0,CONCAT22(uStack_104a2,uStack_104a4)))))))
                      goto LAB_14002d6af;
                      lVar80 = lVar80 + 0x20;
                    } while (DAT_140699540 * 0x20 != lVar80);
                  }
                }
                bVar129 = bStack_10520 == 0;
                bStack_10520 = bVar76;
                if ((bVar129) &&
                   ((*(ulonglong *)
                      __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                    0x7fffffffffffffff) != 0)) {
                  cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                  if (cVar74 == '\0') {
                    DAT_140699529 = '\x01';
                  }
                }
                cVar74 = INTRODUCED;
                LOCK();
                INTRODUCED = '\0';
                UNLOCK();
                if (cVar74 == '\x02') {
                  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&INTRODUCED);
                }
                LOCK();
                bVar129 = DAT_140699920 == '\0';
                if (bVar129) {
                  DAT_140699920 = '\x01';
                }
                UNLOCK();
                if (!bVar129) {
                  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                            (&DAT_140699920);
                }
                if ((*(ulonglong *)
                      __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                    0x7fffffffffffffff) == 0) {
                  bVar76 = bStack_10520;
                  uVar117 = uStack_10490;
                  bStack_10520 = 0;
                }
                else {
                  bVar75 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                  bVar76 = bStack_10520;
                  uVar117 = uStack_10490;
                  bStack_10520 = bVar75 ^ 1;
                }
                uStack_10490 = uVar117;
                if (DAT_140699921 == '\0') {
                  if (DAT_140699940 != (undefined1 (*) [16])0x0) {
                    pauVar82 = DAT_140699928;
                    if (DAT_140699938 < DAT_140699928) {
                      pauVar82 = (undefined1 (*) [16])0x0;
                    }
                    lVar80 = (longlong)DAT_140699938 - (longlong)pauVar82;
                    pauVar123 = (undefined1 (*) [16])((longlong)DAT_140699928 - lVar80);
                    pauVar79 = (undefined1 (*) [16])(lVar80 + (longlong)DAT_140699940);
                    if (pauVar123 < DAT_140699940) {
                      pauVar79 = DAT_140699928;
                    }
                    lVar120 = (longlong)DAT_140699940 - (longlong)pauVar123;
                    if (DAT_140699940 < pauVar123) {
                      lVar120 = 0;
                    }
                    uStack_10490._4_2_ = (ushort)(uVar117 >> 0x20);
                    uStack_10490._0_4_ = (int)uVar117;
                    unaff_R15 = DAT_140699938;
                    if ((longlong)pauVar79 - lVar80 != 0) {
                      lVar98 = ((longlong)pauVar79 - lVar80) * 0x20;
                      if ((bStack_104a8 & 1) == 0) {
                        lVar128 = lVar80 * 0x20 + DAT_140699930;
                        lVar80 = 0;
                        do {
                          if (((*(char *)(lVar128 + lVar80) == '\0') &&
                              (*(ushort *)(lVar128 + 6 + lVar80) == uStack_104a2)) &&
                             (*(int *)(lVar128 + 2 + lVar80) == CONCAT22(uStack_104a4,uStack_104a6))
                             ) goto LAB_14002d953;
                          lVar80 = lVar80 + 0x20;
                        } while (lVar98 != lVar80);
                      }
                      else {
                        lVar128 = (longlong)DAT_140699938 * 0x20 + (longlong)pauVar82 * -0x20 +
                                  DAT_140699930;
                        lVar80 = 0;
                        do {
                          if (((*(short *)(lVar128 + lVar80) != 0) &&
                              (*(short *)(*(undefined1 (*) [16])(lVar128 + 0x1c) + lVar80) ==
                               uStack_10490._4_2_)) &&
                             ((*(uint *)(lVar128 + 0x14 + lVar80) == uStack_10494 &&
                              ((*(int *)(lVar128 + 0x18 + lVar80) == (int)uStack_10490 &&
                               (*(longlong *)(lVar128 + 0xc + lVar80) ==
                                CONCAT26(uStack_10496,CONCAT24(uStack_10498,uStack_1049c)) &&
                                *(longlong *)(lVar128 + 4 + lVar80) ==
                                CONCAT26(uStack_1049e,
                                         CONCAT24(uStack_104a0,CONCAT22(uStack_104a2,uStack_104a4)))
                               )))))) goto LAB_14002d953;
                          lVar80 = lVar80 + 0x20;
                          unaff_R15 = (undefined1 (*) [16])(lVar128 + 0x1c);
                        } while (lVar98 != lVar80);
                      }
                    }
                    if (pauVar123 < DAT_140699940) {
                      if ((bStack_104a8 & 1) == 0) {
                        lVar80 = 0;
                        do {
                          if (((*(char *)(DAT_140699930 + lVar80) == '\0') &&
                              (*(ushort *)(DAT_140699930 + 6 + lVar80) == uStack_104a2)) &&
                             (*(int *)(DAT_140699930 + 2 + lVar80) ==
                              CONCAT22(uStack_104a4,uStack_104a6))) goto LAB_14002d953;
                          lVar80 = lVar80 + 0x20;
                        } while (lVar120 * 0x20 != lVar80);
                      }
                      else {
                        lVar80 = 0;
                        do {
                          if (((*(short *)(DAT_140699930 + lVar80) != 0) &&
                              (*(short *)(DAT_140699930 + 0x1c + lVar80) == uStack_10490._4_2_)) &&
                             ((*(uint *)(DAT_140699930 + 0x14 + lVar80) == uStack_10494 &&
                              ((*(int *)(DAT_140699930 + 0x18 + lVar80) == (int)uStack_10490 &&
                               (*(longlong *)(DAT_140699930 + 0xc + lVar80) ==
                                CONCAT26(uStack_10496,CONCAT24(uStack_10498,uStack_1049c)) &&
                                *(longlong *)(DAT_140699930 + 4 + lVar80) ==
                                CONCAT26(uStack_1049e,
                                         CONCAT24(uStack_104a0,CONCAT22(uStack_104a2,uStack_104a4)))
                               )))))) goto LAB_14002d953;
                          lVar80 = lVar80 + 0x20;
                        } while (lVar120 * 0x20 != lVar80);
                      }
                    }
                  }
                  bStack_10520 = bVar76;
                  core[505b25137b8ba7f]::ptr::drop_glue::
                  <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<[usize_3usize]>>>
                            (&DAT_140699920);
                  goto LAB_14002dfa3;
                }
                bStack_10528 = 0x20;
                bStack_10527 = 0x99;
                bStack_10526 = 0x69;
                bStack_10525 = 0x40;
                bStack_10524 = 1;
                bStack_10523 = 0;
                bStack_10522 = 0;
                bStack_10521 = 0;
                core[505b25137b8ba7f]::result::unwrap_failed
                          ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                           &
                           PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a10b0
                           ,&
                            PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2a08
                          );
              }
              else {
                bStack_10528 = 0x28;
                bStack_10527 = 0x95;
                bStack_10526 = 0x69;
                bStack_10525 = 0x40;
                bStack_10524 = 1;
                bStack_10523 = 0;
                bStack_10522 = 0;
                bStack_10521 = 0;
                core[505b25137b8ba7f]::result::unwrap_failed
                          ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                           &anon_d5c34e88a06ee720b116585eb143da4b_147_llvm_14435704873730135342,
                           &
                           PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a29f0
                          );
              }
            }
            else {
              bStack_10528 = 0x90;
              bStack_10527 = 0x97;
              bStack_10526 = 0x69;
              bStack_10525 = 0x40;
              bStack_10524 = 1;
              bStack_10523 = 0;
              bStack_10522 = 0;
              bStack_10521 = 0;
              core[505b25137b8ba7f]::result::unwrap_failed
                        ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                         &anon_d5c34e88a06ee720b116585eb143da4b_147_llvm_14435704873730135342,
                         &
                         PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a29d8
                        );
            }
          }
          else {
            bStack_10528 = 0x30;
            bStack_10527 = 0x98;
            bStack_10526 = 0x69;
            bStack_10525 = 0x40;
            bStack_10524 = 1;
            bStack_10523 = 0;
            bStack_10522 = 0;
            bStack_10521 = 0;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                       &
                       PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
                       ,&
                        PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a29a8
                      );
          }
        }
        else {
          bStack_10528 = 0x48;
          bStack_10527 = 0x99;
          bStack_10526 = 0x69;
          bStack_10525 = 0x40;
          bStack_10524 = 1;
          bStack_10523 = 0;
          bStack_10522 = 0;
          bStack_10521 = 0;
          bStack_10520 = (byte)uStack_104c0;
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                     &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                     &
                     PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2990
                    );
        }
      }
      goto LAB_140036cf0;
    }
    uStack_103a8 = CONCAT11(uStack_10278._1_1_,(byte)uStack_10278);
    uVar117 = CONCAT26(uStack_1025a,uStack_10260);
    uStack_103a6 = uStack_10276;
    uStack_103a4 = uStack_10274;
    uStack_103a2 = uStack_10272;
    uStack_103a0 = (ushort)auStack_10270[0];
    uStack_1039e = (ushort)(auStack_10270[0] >> 0x10);
    uStack_1039c = (uint)(CONCAT26(auStack_10270[1]._2_2_,
                                   CONCAT24((undefined2)auStack_10270[1],auStack_10270[0])) >> 0x20)
    ;
    uStack_10398 = (ushort)uStack_10268;
    uStack_10396 = (ushort)(uStack_10268 >> 0x10);
    uStack_10394 = (uint)(CONCAT26(uStack_10262,CONCAT24(uStack_10264,uStack_10268)) >> 0x20);
    uStack_10368 = uStack_10238;
    uStack_10360 = uStack_10230;
    uStack_10378 = auStack_10248._0_4_;
    puStack_10374 = auStack_10248._4_8_;
    uStack_1036c = auStack_10248._12_4_;
    uStack_10388 = auStack_10258._0_8_;
    uStack_10380 = auStack_10258._8_4_;
    uStack_1037c = auStack_10258._12_4_;
    lVar80 = CONCAT26(uStack_10272,CONCAT24(uStack_10274,CONCAT22(uStack_10276,uStack_103a8)));
    uStack_10390 = uVar117;
    if ((uVar117 == 8 && lVar80 == -0x7ffffffffffffffd) &&
       (*(longlong *)CONCAT44(uStack_10394,uStack_10268) == 0x74656572672d7272)) {
      uStack_10516 = uStack_10496;
      uStack_10514 = uStack_10494;
      bStack_10528 = bStack_104a8;
      bStack_10527 = bStack_104a7;
      greet_heard(0,CONCAT44(uStack_10494,CONCAT22(uStack_10496,uStack_10498)),&bStack_10528);
    }
    else {
      LOCK();
      bVar129 = OWN_LEASES == '\0';
      if (bVar129) {
        OWN_LEASES = '\x01';
      }
      UNLOCK();
      bStack_10526 = bVar76;
      bStack_10525 = bVar73;
      bStack_10524 = bVar54;
      bStack_10523 = bVar55;
      bStack_10522 = bVar132;
      bStack_10521 = bVar56;
      bStack_10520 = bVar57;
      bStack_1051f = bVar58;
      bStack_1051e = bVar59;
      bStack_1051d = bVar60;
      bStack_1051c = bVar61;
      bStack_1051b = bVar62;
      bStack_1051a = bVar63;
      bStack_10519 = bVar64;
      bStack_10518 = bVar65;
      bStack_10517 = bVar66;
      uStack_10510 = uVar112;
      uStack_1050e = uVar91;
      uStack_1050c = uVar68;
      uStack_1050a = uVar69;
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&OWN_LEASES);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar76 = 0;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar76 = bVar76 ^ 1;
      }
      iVar127 = iStack_103d0;
      uVar91 = uStack_10482;
      uVar112 = uStack_10484;
      unaff_R15 = (undefined1 (*) [16])(ulonglong)uStack_103cc;
      if (DAT_1406995a9 != '\0') {
        bStack_10528 = 0xa8;
        bStack_10527 = 0x95;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar76;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_146_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a28c8)
        ;
        goto LAB_140036cf0;
      }
      bStack_10518 = (byte)uStack_10498;
      bStack_10517 = (byte)(uStack_10498 >> 8);
      uStack_10516 = uStack_10496;
      uStack_10514 = uStack_10494;
      uStack_10510 = (ushort)uStack_10490;
      uStack_1050e = (ushort)(uStack_10490 >> 0x10);
      uStack_1050c = (ushort)(uStack_10490 >> 0x20);
      uStack_1050a = (ushort)(uStack_10490 >> 0x30);
      bStack_10528 = bStack_104a8;
      bStack_10527 = bStack_104a7;
      bStack_10526 = (byte)uStack_104a6;
      bStack_10525 = (byte)(uStack_104a6 >> 8);
      bStack_10524 = (byte)uStack_104a4;
      bStack_10523 = (byte)(uStack_104a4 >> 8);
      bStack_10522 = (byte)uStack_104a2;
      bStack_10521 = (byte)(uStack_104a2 >> 8);
      bStack_10520 = (byte)uStack_104a0;
      bStack_1051f = (byte)(uStack_104a0 >> 8);
      bStack_1051e = (byte)uStack_1049e;
      bStack_1051d = (byte)(uStack_1049e >> 8);
      bStack_1051c = (byte)uStack_1049c;
      bStack_1051b = (byte)(uStack_1049c >> 8);
      bStack_1051a = (byte)(uStack_1049c >> 0x10);
      bStack_10519 = (byte)(uStack_1049c >> 0x18);
      in_stack_fffffffffffefaa8 = DAT_1406995c0;
      reach_directory[4b72b9694f6c3c08]::rendezvous::lan_hello_answer
                (&uStack_10438,&bStack_10528,&uStack_103a8,DAT_1406995b8,DAT_1406995c0);
      if ((bVar76 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          DAT_1406995a9 = '\x01';
        }
      }
      cVar74 = OWN_LEASES;
      LOCK();
      OWN_LEASES = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&OWN_LEASES);
      }
      if (CONCAT44(uStack_10438._4_4_,
                   CONCAT13(uStack_10438._3_1_,
                            CONCAT12(uStack_10438._2_1_,
                                     CONCAT11(uStack_10438._1_1_,(byte)uStack_10438)))) == -1) {
        LOCK();
        bVar129 = MASTERS == '\0';
        if (bVar129) {
          MASTERS = '\x01';
        }
        UNLOCK();
        if (!bVar129) {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&MASTERS);
        }
        if ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) == 0) {
          bVar76 = 0;
          uVar81 = uStack_10490;
        }
        else {
          bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          bVar76 = bVar76 ^ 1;
          uVar81 = uStack_10490;
        }
        uStack_10490 = uVar81;
        if (DAT_140699791 != '\0') {
          bStack_10528 = 0x90;
          bStack_10527 = 0x97;
          bStack_10526 = 0x69;
          bStack_10525 = 0x40;
          bStack_10524 = 1;
          bStack_10523 = 0;
          bStack_10522 = 0;
          bStack_10521 = 0;
          bStack_10520 = bVar76;
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                     &anon_d5c34e88a06ee720b116585eb143da4b_147_llvm_14435704873730135342,
                     &
                     PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2930
                    );
          goto LAB_140036cf0;
        }
        if (DAT_1406997a8 == 0) {
          sVar116 = 2;
        }
        else {
          if ((bStack_104a8 & 1) != 0) {
            uStack_10490._4_2_ = (ushort)(uVar81 >> 0x20);
            uStack_10490._0_4_ = (int)uVar81;
            lVar120 = 0;
LAB_14002e7ce:
            uVar2 = *(undefined2 *)((longlong)DAT_1406997a0 + lVar120 + 0x12);
            bStack_10518 = (byte)uVar2;
            bStack_10517 = (byte)((ushort)uVar2 >> 8);
            puVar86 = (undefined8 *)((longlong)DAT_1406997a0 + lVar120 + 2);
            uVar85 = *puVar86;
            uVar4 = puVar86[1];
            bStack_10528 = (byte)uVar85;
            bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
            bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
            bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
            bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
            bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
            bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
            bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
            bStack_10520 = (byte)uVar4;
            bStack_1051f = (byte)((ulonglong)uVar4 >> 8);
            bStack_1051e = (byte)((ulonglong)uVar4 >> 0x10);
            bStack_1051d = (byte)((ulonglong)uVar4 >> 0x18);
            bStack_1051c = (byte)((ulonglong)uVar4 >> 0x20);
            bStack_1051b = (byte)((ulonglong)uVar4 >> 0x28);
            bStack_1051a = (byte)((ulonglong)uVar4 >> 0x30);
            bStack_10519 = (byte)((ulonglong)uVar4 >> 0x38);
            if (((*(short *)((longlong)DAT_1406997a0 + lVar120) != 1) ||
                (*(ushort *)((longlong)DAT_1406997a0 + lVar120 + 0x1c) != uStack_10490._4_2_)) ||
               ((*(uint *)((longlong)DAT_1406997a0 + lVar120 + 0x14) != uStack_10494 ||
                ((*(int *)((longlong)DAT_1406997a0 + lVar120 + 0x18) != (int)uStack_10490 ||
                 (CONCAT17(bStack_10517,CONCAT16(bStack_10518,(int6)((ulonglong)uVar4 >> 0x10))) !=
                  CONCAT26(uStack_10496,CONCAT24(uStack_10498,uStack_1049c)) ||
                  CONCAT17(bStack_1051f,CONCAT16(bStack_10520,(int6)((ulonglong)uVar85 >> 0x10))) !=
                  CONCAT26(uStack_1049e,CONCAT24(uStack_104a0,CONCAT22(uStack_104a2,uStack_104a4))))
                 ))))) goto LAB_14002e7c1;
            uVar112 = *(ushort *)((longlong)DAT_1406997a0 + lVar120 + 0x1e);
            sVar116 = 1;
            uVar91 = uStack_10490._4_2_;
            iVar127 = (int)uStack_10490;
            uVar113 = uStack_10494;
LAB_14002fbfb:
            unaff_R15 = (undefined1 (*) [16])(ulonglong)uVar113;
            uStack_102c8 = *(ushort *)((longlong)DAT_1406997a0 + lVar120 + 0x12);
            uVar85 = *(undefined8 *)((longlong)DAT_1406997a0 + lVar120 + 2);
            uStack_102d0 = *(undefined8 *)((longlong)DAT_1406997a0 + lVar120 + 10);
            uStack_102d8 = (undefined2)uVar85;
            uStack_102d6 = (undefined2)((ulonglong)uVar85 >> 0x10);
            uStack_102d4 = (ushort)((ulonglong)uVar85 >> 0x20);
            uStack_102d2 = (undefined2)((ulonglong)uVar85 >> 0x30);
            goto LAB_14002fc44;
          }
          lVar120 = 0;
          do {
            uVar2 = *(undefined2 *)((longlong)DAT_1406997a0 + lVar120 + 0x12);
            bStack_10518 = (byte)uVar2;
            bStack_10517 = (byte)((ushort)uVar2 >> 8);
            puVar86 = (undefined8 *)((longlong)DAT_1406997a0 + lVar120 + 2);
            uVar85 = *puVar86;
            uVar4 = puVar86[1];
            bStack_10528 = (byte)uVar85;
            bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
            bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
            bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
            bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
            bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
            bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
            bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
            bStack_10520 = (byte)uVar4;
            bStack_1051f = (byte)((ulonglong)uVar4 >> 8);
            bStack_1051e = (byte)((ulonglong)uVar4 >> 0x10);
            bStack_1051d = (byte)((ulonglong)uVar4 >> 0x18);
            bStack_1051c = (byte)((ulonglong)uVar4 >> 0x20);
            bStack_1051b = (byte)((ulonglong)uVar4 >> 0x28);
            bStack_1051a = (byte)((ulonglong)uVar4 >> 0x30);
            bStack_10519 = (byte)((ulonglong)uVar4 >> 0x38);
            if (((*(short *)((longlong)DAT_1406997a0 + lVar120) == 0) &&
                ((ushort)((ulonglong)uVar85 >> 0x20) == uStack_104a2)) &&
               ((int)uVar85 == CONCAT22(uStack_104a4,uStack_104a6))) {
              uVar113 = *(uint *)((longlong)DAT_1406997a0 + lVar120 + 0x14);
              iVar127 = *(int *)((longlong)DAT_1406997a0 + lVar120 + 0x18);
              uVar91 = *(ushort *)((longlong)DAT_1406997a0 + lVar120 + 0x1c);
              uVar112 = *(ushort *)((longlong)DAT_1406997a0 + lVar120 + 0x1e);
              sVar116 = 0;
              goto LAB_14002fbfb;
            }
            lVar120 = lVar120 + 0x20;
          } while (DAT_1406997a8 * 0x20 != lVar120);
LAB_14002fc16:
          sVar116 = *DAT_1406997a0;
          uStack_102c8 = DAT_1406997a0[9];
          uVar85 = *(undefined8 *)(DAT_1406997a0 + 1);
          uStack_102d0 = *(undefined8 *)(DAT_1406997a0 + 5);
          uStack_102d8 = (undefined2)uVar85;
          uStack_102d6 = (undefined2)((ulonglong)uVar85 >> 0x10);
          uStack_102d4 = (ushort)((ulonglong)uVar85 >> 0x20);
          uStack_102d2 = (undefined2)((ulonglong)uVar85 >> 0x30);
          unaff_R15 = (undefined1 (*) [16])(ulonglong)*(uint *)(DAT_1406997a0 + 10);
          iVar127 = *(int *)(DAT_1406997a0 + 0xc);
          uVar91 = DAT_1406997a0[0xe];
          uVar112 = DAT_1406997a0[0xf];
        }
LAB_14002fc44:
        uVar113 = (uint)unaff_R15;
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar74 == '\0') {
            DAT_140699791 = '\x01';
          }
        }
        cVar74 = MASTERS;
        LOCK();
        MASTERS = '\0';
        UNLOCK();
        if (cVar74 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&MASTERS);
        }
        uStack_10484 = uVar112;
        uStack_10482 = uVar91;
        iStack_103d0 = iVar127;
        uStack_103cc = uVar113;
        if (lVar80 == -0x8000000000000000) {
          bStack_10528 = (byte)uStack_104a6;
          bStack_10527 = (byte)(uStack_104a6 >> 8);
          bStack_10526 = (byte)uStack_104a4;
          bStack_10525 = (byte)(uStack_104a4 >> 8);
          bStack_10524 = (byte)uStack_104a2;
          bStack_10523 = (byte)(uStack_104a2 >> 8);
          bStack_10522 = (byte)uStack_104a0;
          bStack_10521 = (byte)(uStack_104a0 >> 8);
          bStack_10520 = (byte)uStack_1049e;
          bStack_1051f = (byte)(uStack_1049e >> 8);
          bStack_1051e = (byte)uStack_1049c;
          bStack_1051d = (byte)(uStack_1049c >> 8);
          bStack_1051c = (byte)(uStack_1049c >> 0x10);
          bStack_1051b = (byte)(uStack_1049c >> 0x18);
          bStack_1051a = (byte)uStack_10498;
          bStack_10519 = (byte)(uStack_10498 >> 8);
          bStack_10518 = (byte)uStack_10496;
          bStack_10517 = (byte)(uStack_10496 >> 8);
          if ((sVar116 == 2) || (sVar116 != CONCAT11(bStack_104a7,bStack_104a8)))
          goto LAB_140030cc8;
          if (sVar116 == 1) {
            if ((((uVar91 != uStack_10490._4_2_) || (uVar113 != uStack_10494)) ||
                (iVar127 != (int)uStack_10490)) ||
               (auVar151[0] = -(bStack_10526 == (byte)uStack_102d6),
               auVar151[1] = -(bStack_10525 == (byte)((ushort)uStack_102d6 >> 8)),
               auVar151[2] = -(bStack_10524 == (byte)uStack_102d4),
               auVar151[3] = -(bStack_10523 == (byte)(uStack_102d4 >> 8)),
               auVar151[4] = -(bStack_10522 == (byte)uStack_102d2),
               auVar151[5] = -(bStack_10521 == (byte)((ushort)uStack_102d2 >> 8)),
               auVar151[6] = -(bStack_10520 == (byte)uStack_102d0),
               auVar151[7] = -(bStack_1051f == (byte)((ulonglong)uStack_102d0 >> 8)),
               auVar151[8] = -(bStack_1051e == (byte)((ulonglong)uStack_102d0 >> 0x10)),
               auVar151[9] = -(bStack_1051d == (byte)((ulonglong)uStack_102d0 >> 0x18)),
               auVar151[10] = -(bStack_1051c == (byte)((ulonglong)uStack_102d0 >> 0x20)),
               auVar151[0xb] = -(bStack_1051b == (byte)((ulonglong)uStack_102d0 >> 0x28)),
               auVar151[0xc] = -(bStack_1051a == (byte)((ulonglong)uStack_102d0 >> 0x30)),
               auVar151[0xd] = -(bStack_10519 == (byte)((ulonglong)uStack_102d0 >> 0x38)),
               auVar151[0xe] = -(bStack_10518 == (byte)uStack_102c8),
               auVar151[0xf] = -(bStack_10517 == (byte)(uStack_102c8 >> 8)),
               (ushort)((ushort)(SUB161(auVar151 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar151 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar151 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar151 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar151 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar151 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar151 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar151 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar151 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar151 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar151 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar151 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar151 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar151 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar151 >> 0x77,0) & 1) << 0xe |
                       (ushort)(auVar151[0xf] >> 7) << 0xf) != 0xffff)) goto LAB_140030cc8;
          }
          else if ((uStack_102d4 != uStack_104a2) ||
                  (CONCAT22(uStack_102d6,uStack_102d8) !=
                   CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)))) goto LAB_140030cc8;
          <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::str::traits::FromStr>
          ::from_str(&sStack_1012c,CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398)),
                     uVar117);
          uVar68 = uStack_10126;
          uVar114 = uStack_1012a;
          if (sStack_1012c != 2) {
            bStack_10525 = (byte)(uStack_1012a >> 0x10);
            bStack_10527 = bStack_10525;
            bStack_10524 = (byte)(uStack_1012a >> 0x18);
            bStack_10526 = bStack_10524;
            if (sStack_1012c != 1) {
              bStack_10527 = (byte)uStack_1012a;
              bStack_10526 = (byte)(uStack_1012a >> 8);
              bStack_10528 = 0;
              cVar74 = reach_directory[4b72b9694f6c3c08]::lan::is_local(&bStack_10528);
              uVar91 = uStack_10482;
              iVar127 = iStack_103d0;
              uVar113 = uStack_103cc;
              uVar112 = uStack_10484;
              if (cVar74 == '\0') {
                uVar124 = 0;
                goto LAB_1400334b7;
              }
              goto LAB_140032ed2;
            }
            uVar114 = uStack_1012a >> 0x10;
            bStack_1051b = (byte)uStack_1011c;
            bStack_1051a = (byte)((uint)uStack_1011c >> 8);
            bStack_10519 = (byte)((uint)uStack_1011c >> 0x10);
            bStack_10518 = (byte)((uint)uStack_1011c >> 0x18);
            bStack_10523 = (byte)uStack_10124;
            bStack_10522 = (byte)((ulonglong)uStack_10124 >> 8);
            bStack_10521 = (byte)((ulonglong)uStack_10124 >> 0x10);
            bStack_10520 = (byte)((ulonglong)uStack_10124 >> 0x18);
            bStack_1051f = (byte)((ulonglong)uStack_10124 >> 0x20);
            bStack_1051e = (byte)((ulonglong)uStack_10124 >> 0x28);
            bStack_1051d = (byte)((ulonglong)uStack_10124 >> 0x30);
            bStack_1051c = (byte)((ulonglong)uStack_10124 >> 0x38);
            bStack_10525 = (byte)uStack_10126;
            bStack_10524 = (byte)(uStack_10126 >> 8);
            bStack_10528 = 1;
            cVar74 = reach_directory[4b72b9694f6c3c08]::lan::is_local(&bStack_10528);
            uVar91 = uStack_10482;
            iVar127 = iStack_103d0;
            uVar113 = uStack_103cc;
            uVar112 = uStack_10484;
            if (cVar74 != '\0') goto LAB_140032ed2;
            bStack_10520 = (byte)uStack_1011c;
            bStack_1051f = (byte)((uint)uStack_1011c >> 8);
            bStack_1051e = (byte)((uint)uStack_1011c >> 0x10);
            bStack_1051d = (byte)((uint)uStack_1011c >> 0x18);
            bStack_10528 = (byte)uStack_10124;
            bStack_10527 = (byte)((ulonglong)uStack_10124 >> 8);
            bStack_10526 = (byte)((ulonglong)uStack_10124 >> 0x10);
            bStack_10525 = (byte)((ulonglong)uStack_10124 >> 0x18);
            bStack_10524 = (byte)((ulonglong)uStack_10124 >> 0x20);
            bStack_10523 = (byte)((ulonglong)uStack_10124 >> 0x28);
            bStack_10522 = (byte)((ulonglong)uStack_10124 >> 0x30);
            bStack_10521 = (byte)((ulonglong)uStack_10124 >> 0x38);
            uVar114 = uVar114 | (uint)uVar68 << 0x10;
            uVar124 = 1;
LAB_1400334b7:
            ppuStack_103c0 =
                 (undefined **)
                 CONCAT44(ppuStack_103c0._4_4_,
                          CONCAT13(bStack_1051d,
                                   CONCAT12(bStack_1051e,CONCAT11(bStack_1051f,bStack_10520))));
            uStack_103c8 = (undefined1 (*) [16])
                           CONCAT17(bStack_10521,
                                    CONCAT16(bStack_10522,
                                             CONCAT15(bStack_10523,
                                                      CONCAT14(bStack_10524,
                                                               CONCAT13(bStack_10525,
                                                                        CONCAT12(bStack_10526,
                                                                                 CONCAT11(
                                                  bStack_10527,bStack_10528)))))));
            <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[bool;2usize]>>::lock
                      (&bStack_10528,&PUBLIC_SELF);
            if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) !=
                1) {
              lVar80 = CONCAT17(bStack_10519,
                                CONCAT16(bStack_1051a,
                                         CONCAT15(bStack_1051b,
                                                  CONCAT14(bStack_1051c,
                                                           CONCAT13(bStack_1051d,
                                                                    CONCAT12(bStack_1051e,
                                                                             CONCAT11(bStack_1051f,
                                                                                      bStack_10520))
                                                                   )))));
              *(undefined1 *)(lVar80 + 2) = uVar124;
              *(uint *)(lVar80 + 3) = uVar114;
              *(undefined1 (**) [16])(lVar80 + 7) = uStack_103c8;
              *(undefined4 *)(lVar80 + 0xf) = ppuStack_103c0._0_4_;
              core[505b25137b8ba7f]::ptr::drop_glue::
              <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<[usize_3usize]>>>
                        (lVar80,bStack_10518);
              lVar80 = CONCAT26(uStack_103a2,
                                CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
              goto LAB_140030cd2;
            }
            iStack_10326 = CONCAT13(bStack_1051b,
                                    CONCAT12(bStack_1051c,CONCAT11(bStack_1051d,bStack_1051e)));
            bStack_10328 = bStack_10520;
            bStack_10327 = bStack_1051f;
            uStack_10322 = (ushort)(CONCAT15(bStack_10519,CONCAT14(bStack_1051a,iStack_10326)) >>
                                   0x20);
            bStack_10320 = bStack_10518;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10328,
                       &
                       PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::net::ip_addr::IpAddr>>>>_1406a0f50
                       ,&
                        PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2948
                      );
            goto LAB_140036cf0;
          }
LAB_140032ed2:
          uStack_10338 = uStack_102c8;
          uStack_10340 = uStack_102d0;
          uStack_10348 = (char *)CONCAT26(uStack_102d2,
                                          CONCAT24(uStack_102d4,CONCAT22(uStack_102d6,uStack_102d8))
                                         );
        }
        else {
LAB_140030cc8:
          if (sVar116 == 2) goto LAB_1400331b7;
LAB_140030cd2:
          uVar113 = uStack_103cc;
          iVar127 = iStack_103d0;
          uVar91 = uStack_10482;
          uVar112 = uStack_10484;
          uStack_10338 = uStack_102c8;
          uStack_10348 = (char *)CONCAT26(uStack_102d2,
                                          CONCAT24(uStack_102d4,CONCAT22(uStack_102d6,uStack_102d8))
                                         );
          uStack_10340 = uStack_102d0;
          if (lVar80 == -0x7ffffffffffffffe) {
            if (CONCAT11(bStack_104a7,bStack_104a8) == sVar116) {
              if (sVar116 == 1) {
                if ((uStack_10490._4_2_ == uStack_10482) &&
                   ((uStack_10494 == uStack_103cc && ((int)uStack_10490 == iStack_103d0)))) {
                  uStack_10348._2_1_ = (char)uStack_102d6;
                  uStack_10348._3_1_ = (char)((ushort)uStack_102d6 >> 8);
                  uStack_10348._4_1_ = (char)uStack_102d4;
                  uStack_10348._5_1_ = (char)(uStack_102d4 >> 8);
                  uStack_10348._6_1_ = (char)uStack_102d2;
                  uStack_10348._7_1_ = (char)((ushort)uStack_102d2 >> 8);
                  uStack_10340._0_1_ = (char)uStack_102d0;
                  uStack_10340._1_1_ = (char)((ulonglong)uStack_102d0 >> 8);
                  uStack_10340._2_1_ = (char)((ulonglong)uStack_102d0 >> 0x10);
                  uStack_10340._3_1_ = (char)((ulonglong)uStack_102d0 >> 0x18);
                  uStack_10340._4_1_ = (char)((ulonglong)uStack_102d0 >> 0x20);
                  uStack_10340._5_1_ = (char)((ulonglong)uStack_102d0 >> 0x28);
                  uStack_10340._6_1_ = (char)((ulonglong)uStack_102d0 >> 0x30);
                  uStack_10340._7_1_ = (char)((ulonglong)uStack_102d0 >> 0x38);
                  uStack_10338._0_1_ = (char)uStack_102c8;
                  uStack_10338._1_1_ = (char)(uStack_102c8 >> 8);
                  auVar158[0] = -(uStack_10348._2_1_ == (char)uStack_104a4);
                  auVar158[1] = -(uStack_10348._3_1_ == (char)(uStack_104a4 >> 8));
                  auVar158[2] = -(uStack_10348._4_1_ == (char)uStack_104a2);
                  auVar158[3] = -(uStack_10348._5_1_ == (char)(uStack_104a2 >> 8));
                  auVar158[4] = -(uStack_10348._6_1_ == (char)uStack_104a0);
                  auVar158[5] = -(uStack_10348._7_1_ == (char)(uStack_104a0 >> 8));
                  auVar158[6] = -((char)uStack_10340 == (char)uStack_1049e);
                  auVar158[7] = -(uStack_10340._1_1_ == (char)(uStack_1049e >> 8));
                  auVar158[8] = -(uStack_10340._2_1_ == (char)uStack_1049c);
                  auVar158[9] = -(uStack_10340._3_1_ == (char)(uStack_1049c >> 8));
                  auVar158[10] = -(uStack_10340._4_1_ == (char)(uStack_1049c >> 0x10));
                  auVar158[0xb] = -(uStack_10340._5_1_ == (char)(uStack_1049c >> 0x18));
                  auVar158[0xc] = -(uStack_10340._6_1_ == (char)uStack_10498);
                  auVar158[0xd] = -(uStack_10340._7_1_ == (char)(uStack_10498 >> 8));
                  auVar158[0xe] = -((char)uStack_10338 == (char)uStack_10496);
                  auVar158[0xf] = -(uStack_10338._1_1_ == (char)(uStack_10496 >> 8));
                  if ((ushort)((ushort)(SUB161(auVar158 >> 7,0) & 1) |
                               (ushort)(SUB161(auVar158 >> 0xf,0) & 1) << 1 |
                               (ushort)(SUB161(auVar158 >> 0x17,0) & 1) << 2 |
                               (ushort)(SUB161(auVar158 >> 0x1f,0) & 1) << 3 |
                               (ushort)(SUB161(auVar158 >> 0x27,0) & 1) << 4 |
                               (ushort)(SUB161(auVar158 >> 0x2f,0) & 1) << 5 |
                               (ushort)(SUB161(auVar158 >> 0x37,0) & 1) << 6 |
                               (ushort)(SUB161(auVar158 >> 0x3f,0) & 1) << 7 |
                               (ushort)(SUB161(auVar158 >> 0x47,0) & 1) << 8 |
                               (ushort)(SUB161(auVar158 >> 0x4f,0) & 1) << 9 |
                               (ushort)(SUB161(auVar158 >> 0x57,0) & 1) << 10 |
                               (ushort)(SUB161(auVar158 >> 0x5f,0) & 1) << 0xb |
                               (ushort)(SUB161(auVar158 >> 0x67,0) & 1) << 0xc |
                               (ushort)(SUB161(auVar158 >> 0x6f,0) & 1) << 0xd |
                               (ushort)(SUB161(auVar158 >> 0x77,0) & 1) << 0xe |
                              (ushort)(auVar158[0xf] >> 7) << 0xf) == 0xffff) goto LAB_140030d9a;
                }
              }
              else if ((uStack_104a2 == uStack_102d4) &&
                      (CONCAT22(uStack_104a4,uStack_104a6) == CONCAT22(uStack_102d6,uStack_102d8)))
              {
LAB_140030d9a:
                <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::str::traits::FromStr>
                ::from_str(&sStack_100a8,CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398)),
                           uStack_10390);
                if (sStack_100a8 != 2) {
                  <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
                  ::lock(&bStack_10528,&INTRODUCED);
                  bVar76 = bStack_10518;
                  if (CONCAT13(bStack_10525,
                               CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) != 1) {
                    lVar120 = CONCAT17(bStack_10519,
                                       CONCAT16(bStack_1051a,
                                                CONCAT15(bStack_1051b,
                                                         CONCAT14(bStack_1051c,
                                                                  CONCAT13(bStack_1051d,
                                                                           CONCAT12(bStack_1051e,
                                                                                    CONCAT11(
                                                  bStack_1051f,bStack_10520)))))));
                    lVar80 = *(longlong *)(lVar120 + 0x18);
                    if (lVar80 == *(longlong *)(lVar120 + 8)) {
                      <alloc[246c2e7857c81348]::raw_vec::RawVec<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
                      ::grow_one(lVar120 + 8);
                    }
                    lVar98 = *(longlong *)(lVar120 + 0x10);
                    puVar86 = (undefined8 *)(lVar98 + 0x10 + lVar80 * 0x20);
                    *puVar86 = uStack_10098;
                    puVar86[1] = uStack_10090;
                    puVar86 = (undefined8 *)(lVar98 + lVar80 * 0x20);
                    *puVar86 = CONCAT62(uStack_100a6,sStack_100a8);
                    puVar86[1] = uStack_100a0;
                    *(longlong *)(lVar120 + 0x18) = lVar80 + 1;
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>
                              (lVar120,bVar76);
                    lVar80 = CONCAT26(uStack_103a2,
                                      CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
                    goto LAB_140030e6b;
                  }
                  iStack_10326 = CONCAT13(bStack_1051b,
                                          CONCAT12(bStack_1051c,CONCAT11(bStack_1051d,bStack_1051e))
                                         );
                  bStack_10328 = bStack_10520;
                  bStack_10327 = bStack_1051f;
                  uStack_10322 = (ushort)(CONCAT15(bStack_10519,CONCAT14(bStack_1051a,iStack_10326))
                                         >> 0x20);
                  bStack_10320 = bStack_10518;
                  core[505b25137b8ba7f]::result::unwrap_failed
                            ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10328,
                             &anon_d5c34e88a06ee720b116585eb143da4b_147_llvm_14435704873730135342,
                             &
                             PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2960
                            );
                  goto LAB_140036cf0;
                }
              }
            }
          }
          else {
LAB_140030e6b:
            uVar113 = uStack_103cc;
            iVar127 = iStack_103d0;
            uVar91 = uStack_10482;
            uVar112 = uStack_10484;
            if ((lVar80 == -0x7ffffffffffffff9) && (CONCAT11(bStack_104a7,bStack_104a8) == sVar116))
            {
              if (sVar116 == 1) {
                if ((uStack_10490._4_2_ == uStack_10482) &&
                   ((uStack_10494 == uStack_103cc && ((int)uStack_10490 == iStack_103d0)))) {
                  auVar159[0] = -(uStack_10348._2_1_ == (char)uStack_104a4);
                  auVar159[1] = -(uStack_10348._3_1_ == (char)(uStack_104a4 >> 8));
                  auVar159[2] = -(uStack_10348._4_1_ == (char)uStack_104a2);
                  auVar159[3] = -(uStack_10348._5_1_ == (char)(uStack_104a2 >> 8));
                  auVar159[4] = -(uStack_10348._6_1_ == (char)uStack_104a0);
                  auVar159[5] = -(uStack_10348._7_1_ == (char)(uStack_104a0 >> 8));
                  auVar159[6] = -((char)uStack_10340 == (char)uStack_1049e);
                  auVar159[7] = -(uStack_10340._1_1_ == (char)(uStack_1049e >> 8));
                  auVar159[8] = -(uStack_10340._2_1_ == (char)uStack_1049c);
                  auVar159[9] = -(uStack_10340._3_1_ == (char)(uStack_1049c >> 8));
                  auVar159[10] = -(uStack_10340._4_1_ == (char)(uStack_1049c >> 0x10));
                  auVar159[0xb] = -(uStack_10340._5_1_ == (char)(uStack_1049c >> 0x18));
                  auVar159[0xc] = -(uStack_10340._6_1_ == (char)uStack_10498);
                  auVar159[0xd] = -(uStack_10340._7_1_ == (char)(uStack_10498 >> 8));
                  auVar159[0xe] = -((char)uStack_10338 == (char)uStack_10496);
                  auVar159[0xf] = -(uStack_10338._1_1_ == (char)(uStack_10496 >> 8));
                  if ((ushort)((ushort)(SUB161(auVar159 >> 7,0) & 1) |
                               (ushort)(SUB161(auVar159 >> 0xf,0) & 1) << 1 |
                               (ushort)(SUB161(auVar159 >> 0x17,0) & 1) << 2 |
                               (ushort)(SUB161(auVar159 >> 0x1f,0) & 1) << 3 |
                               (ushort)(SUB161(auVar159 >> 0x27,0) & 1) << 4 |
                               (ushort)(SUB161(auVar159 >> 0x2f,0) & 1) << 5 |
                               (ushort)(SUB161(auVar159 >> 0x37,0) & 1) << 6 |
                               (ushort)(SUB161(auVar159 >> 0x3f,0) & 1) << 7 |
                               (ushort)(SUB161(auVar159 >> 0x47,0) & 1) << 8 |
                               (ushort)(SUB161(auVar159 >> 0x4f,0) & 1) << 9 |
                               (ushort)(SUB161(auVar159 >> 0x57,0) & 1) << 10 |
                               (ushort)(SUB161(auVar159 >> 0x5f,0) & 1) << 0xb |
                               (ushort)(SUB161(auVar159 >> 0x67,0) & 1) << 0xc |
                               (ushort)(SUB161(auVar159 >> 0x6f,0) & 1) << 0xd |
                               (ushort)(SUB161(auVar159 >> 0x77,0) & 1) << 0xe |
                              (ushort)(auVar159[0xf] >> 7) << 0xf) == 0xffff) goto LAB_140032455;
                }
              }
              else {
                bVar129 = uStack_104a2 == uStack_10348._4_2_;
                if ((bVar129) &&
                   (bVar129 = CONCAT22(uStack_104a4,uStack_104a6) == (int)uStack_10348, bVar129)) {
LAB_140032455:
                  reach_directory[4b72b9694f6c3c08]::identity::unhex::<16usize>
                            (&cStack_10109,
                             CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398)),uStack_10390
                            );
                  if (cStack_10109 == '\x01') {
                    <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
                    ::lock(&bStack_10528,&RELAY_SESSIONS);
                    bVar76 = bStack_10518;
                    if (CONCAT13(bStack_10525,
                                 CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
                      iStack_10326 = CONCAT13(bStack_1051b,
                                              CONCAT12(bStack_1051c,
                                                       CONCAT11(bStack_1051d,bStack_1051e)));
                      bStack_10328 = bStack_10520;
                      bStack_10327 = bStack_1051f;
                      uStack_10322 = (ushort)(CONCAT15(bStack_10519,
                                                       CONCAT14(bStack_1051a,iStack_10326)) >> 0x20)
                      ;
                      bStack_10320 = bStack_10518;
                      core[505b25137b8ba7f]::result::unwrap_failed
                                ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10328,
                                 &
                                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0fb0
                                 ,&
                                  PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2978
                                );
                      goto LAB_140036cf0;
                    }
                    lVar120 = CONCAT17(bStack_10519,
                                       CONCAT16(bStack_1051a,
                                                CONCAT15(bStack_1051b,
                                                         CONCAT14(bStack_1051c,
                                                                  CONCAT13(bStack_1051d,
                                                                           CONCAT12(bStack_1051e,
                                                                                    CONCAT11(
                                                  bStack_1051f,bStack_10520)))))));
                    lVar80 = *(longlong *)(lVar120 + 0x18);
                    if (lVar80 == *(longlong *)(lVar120 + 8)) {
                      <alloc[246c2e7857c81348]::raw_vec::RawVec<[u8;16usize]>>::grow_one
                                (lVar120 + 8);
                    }
                    puVar86 = (undefined8 *)(*(longlong *)(lVar120 + 0x10) + lVar80 * 0x10);
                    *puVar86 = uStack_10108;
                    puVar86[1] = uStack_10100;
                    *(longlong *)(lVar120 + 0x18) = lVar80 + 1;
                    core[505b25137b8ba7f]::ptr::drop_glue::
                    <std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<[usize_3usize]>>>
                              (lVar120,bVar76);
                    uVar91 = uStack_10482;
                    iVar127 = iStack_103d0;
                    uVar113 = uStack_103cc;
                    uVar112 = uStack_10484;
                  }
                }
              }
            }
          }
        }
        uStack_1050a = uVar112;
        iStack_10326 = CONCAT22(uStack_104a4,uStack_104a6);
        bStack_10318 = (byte)uStack_10498;
        bStack_10317 = (byte)(uStack_10498 >> 8);
        uStack_10316 = (uint)(CONCAT44(uStack_10494,CONCAT22(uStack_10496,uStack_10498)) >> 0x10);
        uStack_10312 = (ushort)(uStack_10494 >> 0x10);
        uStack_10310 = (undefined6)uStack_10490;
        uStack_1030a = (undefined2)(uStack_10490 >> 0x30);
        bStack_10328 = bStack_104a8;
        bStack_10327 = bStack_104a7;
        uStack_10322 = uStack_104a2;
        bStack_10320 = (byte)uStack_104a0;
        uStack_1031f = (undefined5)(CONCAT44(uStack_1049c,CONCAT22(uStack_1049e,uStack_104a0)) >> 8)
        ;
        uStack_1031a = (ushort)(uStack_1049c >> 0x10);
        bStack_10528 = (byte)sVar116;
        bStack_10527 = (byte)((ushort)sVar116 >> 8);
        uStack_10516 = uStack_102c8;
        bStack_10526 = (byte)uStack_102d8;
        bStack_10525 = (byte)((ushort)uStack_102d8 >> 8);
        bStack_10524 = (byte)uStack_102d6;
        bStack_10523 = (byte)((ushort)uStack_102d6 >> 8);
        bStack_10522 = (byte)uStack_102d4;
        bStack_10521 = (byte)(uStack_102d4 >> 8);
        bStack_10520 = (byte)uStack_102d2;
        bStack_1051f = (byte)((ushort)uStack_102d2 >> 8);
        bStack_1051e = (byte)uStack_102d0;
        bStack_1051d = (byte)((ulonglong)uStack_102d0 >> 8);
        bStack_1051c = (byte)((ulonglong)uStack_102d0 >> 0x10);
        bStack_1051b = (byte)((ulonglong)uStack_102d0 >> 0x18);
        bStack_1051a = (byte)((ulonglong)uStack_102d0 >> 0x20);
        bStack_10519 = (byte)((ulonglong)uStack_102d0 >> 0x28);
        bStack_10518 = (byte)((ulonglong)uStack_102d0 >> 0x30);
        bStack_10517 = (byte)((ulonglong)uStack_102d0 >> 0x38);
        uStack_10510 = (ushort)iVar127;
        uStack_1050e = (ushort)((uint)iVar127 >> 0x10);
        uStack_10514 = uVar113;
        uStack_1050c = uVar91;
        reach_directory[4b72b9694f6c3c08]::rendezvous::host_on_datagram
                  (&uStack_103c8,&bStack_10328,&uStack_103a8,&bStack_10528);
        unaff_R15 = (undefined1 (*) [16])((longlong)pauStack_103b8 * 0x70);
        ppuVar103 = ppuStack_103c0 + (longlong)pauStack_103b8 * 0xe;
        ppuStack_10210 = ppuVar103;
        uStack_10228 = ppuStack_103c0;
        ppuVar6 = ppuStack_103c0;
        uStack_10220 = ppuStack_103c0;
        uStack_10218 = uStack_103c8;
        puVar88 = puStack_104e0;
        ppuVar70 = ppuStack_103c0;
        pauVar82 = pauStack_103b8;
        while (pauVar82 != (undefined1 (*) [16])0x0) {
          puVar5 = ppuVar70[4];
          puStack_104e0 = ppuVar70[0xd];
          puStack_102f8 = ppuVar70[0xb];
          puStack_102f0 = ppuVar70[0xc];
          puStack_10308 = ppuVar70[9];
          puStack_10300 = ppuVar70[10];
          puVar13 = ppuVar70[7];
          puVar14 = ppuVar70[8];
          bStack_10318 = (byte)puVar13;
          bStack_10317 = (byte)((ulonglong)puVar13 >> 8);
          uStack_10316 = (uint)((ulonglong)puVar13 >> 0x10);
          uStack_10312 = (ushort)((ulonglong)puVar13 >> 0x30);
          uStack_10310 = SUB86(puVar14,0);
          uStack_1030a = (undefined2)((ulonglong)puVar14 >> 0x30);
          puVar11 = ppuVar70[5];
          puVar12 = ppuVar70[6];
          bStack_10328 = (byte)puVar11;
          bStack_10327 = (byte)((ulonglong)puVar11 >> 8);
          iStack_10326 = (int)((ulonglong)puVar11 >> 0x10);
          uStack_10322 = (ushort)((ulonglong)puVar11 >> 0x30);
          bStack_10320 = (byte)puVar12;
          uStack_1031f = (undefined5)((ulonglong)puVar12 >> 8);
          uStack_1031a = (ushort)((ulonglong)puVar12 >> 0x30);
          puStack_102e8 = puStack_104e0;
          ppuVar6 = ppuVar70 + 0xe;
          if (puVar5 == (undefined *)0xffffffffffffffff) break;
          sVar116 = *(short *)ppuVar70;
          sStack_10294 = *(short *)((longlong)ppuVar70 + 6);
          uStack_10298 = *(undefined4 *)((longlong)ppuVar70 + 2);
          ppuVar6 = (undefined **)ppuVar70[1];
          pauStack_102a8 = (undefined1 (*) [16])ppuVar70[2];
          puStack_102a0 = ppuVar70[3];
          bStack_10528 = (byte)puVar5;
          bStack_10527 = (byte)((ulonglong)puVar5 >> 8);
          bStack_10526 = (byte)((ulonglong)puVar5 >> 0x10);
          bStack_10525 = (byte)((ulonglong)puVar5 >> 0x18);
          bStack_10524 = (byte)((ulonglong)puVar5 >> 0x20);
          bStack_10523 = (byte)((ulonglong)puVar5 >> 0x28);
          bStack_10522 = (byte)((ulonglong)puVar5 >> 0x30);
          bStack_10521 = (byte)((ulonglong)puVar5 >> 0x38);
          uStack_104f0 = (uint)puStack_102f8;
          uStack_104ec = (uint)((ulonglong)puStack_102f8 >> 0x20);
          uStack_104e8 = (uint)puStack_102f0;
          uStack_104e4 = (uint)((ulonglong)puStack_102f0 >> 0x20);
          uStack_10500._0_4_ = (uint)puStack_10308;
          uStack_10500._4_4_ = (uint)((ulonglong)puStack_10308 >> 0x20);
          uStack_104f8._0_4_ = (uint)puStack_10300;
          uStack_104f8._4_4_ = (uint)((ulonglong)puStack_10300 >> 0x20);
          uStack_10510 = (ushort)puVar13;
          uStack_1050e = (ushort)((ulonglong)puVar13 >> 0x10);
          uStack_1050c = (ushort)((ulonglong)puVar13 >> 0x20);
          uStack_10508._0_4_ = (uint)puVar14;
          uStack_10508._4_4_ = (uint)((ulonglong)puVar14 >> 0x20);
          bStack_1051e = (byte)((ulonglong)puVar11 >> 0x10);
          bStack_1051d = (byte)((ulonglong)puVar11 >> 0x18);
          bStack_1051c = (byte)((ulonglong)puVar11 >> 0x20);
          bStack_1051b = (byte)((ulonglong)puVar11 >> 0x28);
          bStack_1051a = (byte)((ulonglong)puVar11 >> 0x30);
          bStack_10519 = (byte)((ulonglong)puVar11 >> 0x38);
          bStack_10517 = (byte)((ulonglong)puVar12 >> 8);
          uStack_10516 = (ushort)((ulonglong)puVar12 >> 0x10);
          uStack_10514 = (uint)((ulonglong)puVar12 >> 0x20);
          bStack_10520 = bStack_10328;
          bStack_1051f = bStack_10327;
          bStack_10518 = bStack_10320;
          uStack_1050a = uStack_10312;
          reach_directory[4b72b9694f6c3c08]::rendezvous::encode(&ppuStack_101d8,&bStack_10528);
          ppuVar71 = ppuStack_101d0;
          ppuVar105 = &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
          if ((sVar116 == 2) || (ppuVar105 = ppuVar6, sVar116 == -1)) {
LAB_14003312f:
            LOCK();
            DAT_1407f1080 = DAT_1407f1080 + 1;
            UNLOCK();
            if ((1 < ((uint)ppuVar105 & 3) - 2) && (((ulonglong)ppuVar105 & 3) != 0)) {
              ppuStack_103c0 = (undefined **)((longlong)ppuVar105 + -1);
              uStack_103c8 = (undefined1 (*) [16])CONCAT71(uStack_103c8._1_7_,3);
              <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
              ::drop(&ppuStack_103c0);
            }
          }
          else {
            uStack_103c8 = (undefined1 (*) [16])
                           CONCAT26(sStack_10294,CONCAT42(uStack_10298,sVar116));
            pauStack_103b8 = pauStack_102a8;
            puStack_103b0 = puStack_102a0;
            ppuVar105 = ppuStack_101d0;
            ppuStack_103c0 = ppuVar6;
            uVar117 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                                (&DAT_140699980,ppuStack_101d0,CONCAT62(uStack_101c6,uStack_101c8),
                                 &uStack_103c8);
            if ((uVar117 & 1) != 0) goto LAB_14003312f;
            LOCK();
            DAT_1407f1050 = DAT_1407f1050 + (longlong)ppuVar105;
            UNLOCK();
            LOCK();
            DAT_1407f1058 = DAT_1407f1058 + 1;
            UNLOCK();
          }
          if (ppuStack_101d8 != (undefined **)0x0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(ppuVar71,ppuStack_101d8,1);
            return pauVar82;
          }
          core[505b25137b8ba7f]::ptr::drop_glue::
          <reach_directory[4b72b9694f6c3c08]::rendezvous::Message>(&bStack_10528);
          unaff_R15 = unaff_R15 + -7;
          ppuVar6 = ppuVar103;
          puVar88 = puStack_104e0;
          ppuVar70 = ppuVar70 + 0xe;
          pauVar82 = unaff_R15;
        }
        uStack_10220 = ppuVar6;
        puStack_104e0 = puVar88;
        <alloc[246c2e7857c81348]::vec::into_iter::IntoIter<(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,reach_directory[4b72b9694f6c3c08]::rendezvous::Message)>as_core[505b25137b8ba7f]::ops::drop::Drop>
        ::drop(&uStack_10228);
        goto LAB_1400331b7;
      }
      uStack_104e8 = (uint)puStack_103f8;
      uStack_104e4 = (uint)((ulonglong)puStack_103f8 >> 0x20);
      puStack_104e0 = puStack_103f0;
      uStack_104f8._0_4_ = uStack_10408;
      uStack_104f8._4_4_ = uStack_10404;
      uStack_104f0 = uStack_10400;
      uStack_104ec = uStack_103fc;
      uStack_10508._0_4_ = uStack_10418;
      uStack_10508._4_4_ = uStack_10414;
      uStack_10500._0_4_ = uStack_10410;
      uStack_10500._4_4_ = uStack_1040c;
      bStack_10518 = bStack_10428;
      bStack_10517 = bStack_10427;
      uStack_10516 = uStack_10426;
      uStack_10514 = uStack_10424;
      uStack_10510 = (ushort)uStack_10420;
      uStack_1050e = (ushort)(uStack_10420 >> 0x10);
      uStack_1050c = uStack_1041c;
      uStack_1050a = uStack_1041a;
      bStack_10528 = (byte)uStack_10438;
      bStack_10527 = uStack_10438._1_1_;
      bStack_10526 = uStack_10438._2_1_;
      bStack_10525 = uStack_10438._3_1_;
      bStack_10524 = (byte)uStack_10438._4_4_;
      bStack_10523 = (byte)((uint)uStack_10438._4_4_ >> 8);
      bStack_10522 = (byte)((uint)uStack_10438._4_4_ >> 0x10);
      bStack_10521 = (byte)((uint)uStack_10438._4_4_ >> 0x18);
      bStack_10520 = bStack_10430;
      bStack_1051f = bStack_1042f;
      bStack_1051e = (byte)uStack_1042e;
      bStack_1051d = (byte)(uStack_1042e >> 8);
      bStack_1051c = (byte)uStack_1042c;
      bStack_1051b = (byte)(uStack_1042c >> 8);
      bStack_1051a = (byte)(uStack_1042c >> 0x10);
      bStack_10519 = (byte)(uStack_1042c >> 0x18);
      LOCK();
      bVar129 = INTRODUCED == '\0';
      if (bVar129) {
        INTRODUCED = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&INTRODUCED);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar76 = 0;
        lVar80 = DAT_140699540;
        uVar117 = uStack_10490;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar76 = bVar76 ^ 1;
        lVar80 = DAT_140699540;
        uVar117 = uStack_10490;
      }
      DAT_140699540 = lVar80;
      uStack_10490 = uVar117;
      if (DAT_140699529 != '\0') {
        bStack_10328 = 0x28;
        bStack_10327 = 0x95;
        iStack_10326 = 0x14069;
        uStack_10322 = 0;
        bStack_10320 = bVar76;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10328,
                   &anon_d5c34e88a06ee720b116585eb143da4b_147_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a28e0)
        ;
        goto LAB_140036cf0;
      }
      lVar120 = lVar80 * 0x20;
      if (lVar80 != 0) {
        if ((bStack_104a8 & 1) == 0) {
          lVar98 = 0;
          do {
            if (((*(char *)(DAT_140699538 + lVar98) == '\0') &&
                (*(ushort *)(DAT_140699538 + 6 + lVar98) == uStack_104a2)) &&
               (*(int *)(DAT_140699538 + 2 + lVar98) == CONCAT22(uStack_104a4,uStack_104a6)))
            goto LAB_14002f824;
            lVar98 = lVar98 + 0x20;
          } while (lVar120 != lVar98);
        }
        else {
          uStack_10490._4_2_ = (ushort)(uVar117 >> 0x20);
          uStack_10490._0_4_ = (int)uVar117;
          lVar98 = 0;
          do {
            if (((*(short *)(DAT_140699538 + lVar98) != 0) &&
                (*(short *)(DAT_140699538 + 0x1c + lVar98) == uStack_10490._4_2_)) &&
               ((*(uint *)(DAT_140699538 + 0x14 + lVar98) == uStack_10494 &&
                ((*(int *)(DAT_140699538 + 0x18 + lVar98) == (int)uStack_10490 &&
                 (unaff_R15 = (undefined1 (*) [16])
                              (*(ulonglong *)(DAT_140699538 + 0xc + lVar98) ^
                               CONCAT26(uStack_10496,CONCAT24(uStack_10498,uStack_1049c)) |
                              *(ulonglong *)(DAT_140699538 + 4 + lVar98) ^
                              CONCAT26(uStack_1049e,
                                       CONCAT24(uStack_104a0,CONCAT22(uStack_104a2,uStack_104a4)))),
                 unaff_R15 == (undefined1 (*) [16])0x0)))))) goto LAB_14002f824;
            lVar98 = lVar98 + 0x20;
          } while (lVar120 != lVar98);
        }
      }
      iStack_10326 = CONCAT22(uStack_104a4,uStack_104a6);
      bStack_10318 = (byte)uStack_10498;
      bStack_10317 = (byte)(uStack_10498 >> 8);
      uStack_10316 = (uint)(CONCAT44(uStack_10494,CONCAT22(uStack_10496,uStack_10498)) >> 0x10);
      uStack_10312 = (ushort)(uStack_10494 >> 0x10);
      uStack_10310 = (undefined6)uVar117;
      uStack_1030a = (undefined2)(uVar117 >> 0x30);
      bStack_10320 = (byte)uStack_104a0;
      uStack_1031f = (undefined5)(CONCAT44(uStack_1049c,CONCAT22(uStack_1049e,uStack_104a0)) >> 8);
      uStack_1031a = (ushort)(uStack_1049c >> 0x10);
      bStack_10328 = bStack_104a8;
      bStack_10327 = bStack_104a7;
      uStack_10322 = uStack_104a2;
      if (lVar80 == DAT_140699530) {
        <alloc[246c2e7857c81348]::raw_vec::RawVec<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
        ::grow_one(&DAT_140699530);
      }
      lVar98 = DAT_140699538;
      puVar86 = (undefined8 *)(DAT_140699538 + 0x10 + lVar120);
      *puVar86 = CONCAT26(uStack_10312,CONCAT42(uStack_10316,CONCAT11(bStack_10317,bStack_10318)));
      puVar86[1] = CONCAT26(uStack_1030a,uStack_10310);
      *(undefined8 *)(lVar98 + lVar120) =
           CONCAT26(uStack_10322,CONCAT42(iStack_10326,CONCAT11(bStack_10327,bStack_10328)));
      ((undefined8 *)(lVar98 + lVar120))[1] =
           CONCAT26(uStack_1031a,CONCAT51(uStack_1031f,bStack_10320));
      DAT_140699540 = lVar80 + 1;
      uStack_103c8 = (undefined1 (*) [16])&bStack_104a8;
      ppuStack_103c0 =
           (undefined **)
           <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::fmt::Display>
           ::fmt;
      alloc[246c2e7857c81348]::fmt::format::format_inner(&bStack_10328,&DAT_1406a28f8,&uStack_103c8)
      ;
      lVar80 = CONCAT26(uStack_10322,CONCAT42(iStack_10326,CONCAT11(bStack_10327,bStack_10328)));
      uVar85 = CONCAT26(uStack_1031a,CONCAT51(uStack_1031f,bStack_10320));
      host::log(uVar85,CONCAT26(uStack_10312,
                                CONCAT42(uStack_10316,CONCAT11(bStack_10317,bStack_10318))));
      uVar117 = uStack_10490;
      if (lVar80 != 0) {
        pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar80,1);
        return pauVar82;
      }
LAB_14002f824:
      uStack_10490 = uVar117;
      if ((bVar76 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          DAT_140699529 = '\x01';
        }
      }
      cVar74 = INTRODUCED;
      LOCK();
      INTRODUCED = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&INTRODUCED);
      }
      reach_directory[4b72b9694f6c3c08]::rendezvous::encode(&uStack_103c8,&bStack_10528);
      ppuVar6 = ppuStack_103c0;
      ppuVar103 = &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
      if ((CONCAT11(bStack_104a7,bStack_104a8) == 2) ||
         (ppuVar103 = (undefined **)CONCAT44(uStack_1049c,CONCAT22(uStack_1049e,uStack_104a0)),
         CONCAT11(bStack_104a7,bStack_104a8) == -1)) {
LAB_14002f8f3:
        LOCK();
        DAT_1407f1080 = DAT_1407f1080 + 1;
        UNLOCK();
        if ((1 < ((uint)ppuVar103 & 3) - 2) && (((ulonglong)ppuVar103 & 3) != 0)) {
          lVar80 = (longlong)ppuVar103 + -1;
          bStack_10320 = (byte)lVar80;
          uStack_1031f = (undefined5)((ulonglong)lVar80 >> 8);
          uStack_1031a = (ushort)((ulonglong)lVar80 >> 0x30);
          bStack_10328 = 3;
          <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
          ::drop(&bStack_10320);
        }
      }
      else {
        bStack_10328 = bStack_104a8;
        bStack_10327 = bStack_104a7;
        uStack_10322 = uStack_104a2;
        iStack_10326 = CONCAT22(uStack_104a4,uStack_104a6);
        bStack_10320 = (byte)uStack_104a0;
        uStack_1031f = (undefined5)((ulonglong)ppuVar103 >> 8);
        uStack_1031a = (ushort)(uStack_1049c >> 0x10);
        bStack_10318 = (byte)uStack_10498;
        bStack_10317 = (byte)(uStack_10498 >> 8);
        uStack_10316 = (uint)(CONCAT44(uStack_10494,CONCAT22(uStack_10496,uStack_10498)) >> 0x10);
        uStack_10312 = (ushort)(uStack_10494 >> 0x10);
        uStack_10310 = (undefined6)uStack_10490;
        uStack_1030a = (undefined2)(uStack_10490 >> 0x30);
        ppuVar103 = ppuStack_103c0;
        uVar117 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                            (&DAT_140699980,ppuStack_103c0,pauStack_103b8,&bStack_10328);
        if ((uVar117 & 1) != 0) goto LAB_14002f8f3;
        LOCK();
        DAT_1407f1050 = DAT_1407f1050 + (longlong)ppuVar103;
        UNLOCK();
        LOCK();
        DAT_1407f1058 = DAT_1407f1058 + 1;
        UNLOCK();
      }
      if (uStack_103c8 != (undefined1 (*) [16])0x0) {
        pauVar82 = (undefined1 (*) [16])
                   __rustc[9d087a5ab36ea756]::__rust_dealloc(ppuVar6,uStack_103c8,1);
        return pauVar82;
      }
      core[505b25137b8ba7f]::ptr::drop_glue::
      <reach_directory[4b72b9694f6c3c08]::rendezvous::Message>(&bStack_10528);
    }
LAB_1400331b7:
    core[505b25137b8ba7f]::ptr::drop_glue::<reach_directory[4b72b9694f6c3c08]::rendezvous::Message>
              (&uStack_103a8);
    bVar76 = bStack_10526;
    bVar73 = bStack_10525;
    bVar54 = bStack_10524;
    bVar55 = bStack_10523;
    bVar132 = bStack_10522;
    bVar56 = bStack_10521;
    bVar57 = bStack_10520;
    bVar58 = bStack_1051f;
    bVar59 = bStack_1051e;
    bVar60 = bStack_1051d;
    bVar61 = bStack_1051c;
    bVar62 = bStack_1051b;
    bVar63 = bStack_1051a;
    bVar64 = bStack_10519;
    bVar65 = bStack_10518;
    bVar66 = bStack_10517;
    uVar112 = uStack_10510;
    uVar91 = uStack_1050e;
    uVar68 = uStack_1050c;
    uVar69 = uStack_1050a;
    goto LAB_1400331c4;
  }
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_alloc(pauStack_10538,1);
  if (pauVar82 == (undefined1 (*) [16])0x0) {
LAB_140036811:
    uVar85 = 1;
    pauStack_10280 = pauStack_10538;
LAB_1400349a6:
    alloc[246c2e7857c81348]::raw_vec::handle_error(uVar85,pauStack_10280);
    goto LAB_140036cf0;
  }
  uStack_104b0 = pauVar82;
  memcpy(pauVar82,&uStack_10088,(size_t)pauStack_10538);
  if (pauStack_10538 < (undefined1 (*) [16])&DAT_00000008) {
LAB_14002c58e:
    bVar129 = true;
    goto LAB_14002c76e;
  }
LAB_14002c64e:
  bVar76 = bStack_10471;
  if (*(longlong *)*uStack_104b0 == 0x31445254532d5252) {
    if (pauStack_10448 < (undefined1 (*) [16])0x4e5) {
      LOCK();
      bVar129 = DAT_140699948 == '\0';
      if (bVar129) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        unaff_R15 = (undefined1 (*) [16])0x0;
      }
      else {
        uVar113 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        unaff_R15 = (undefined1 (*) [16])((ulonglong)uVar113 ^ 1);
      }
      if (DAT_140699949 == '\0') {
        LOCK();
        bVar129 = TRANSPORT == '\0';
        if (bVar129) {
          TRANSPORT = '\x01';
        }
        UNLOCK();
        if (!bVar129) {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&TRANSPORT);
        }
        if ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) == 0) {
          bVar76 = 0;
        }
        else {
          bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          bVar76 = bVar76 ^ 1;
        }
        if (DAT_140699831 != '\0') {
          bStack_10528 = 0x30;
          bStack_10527 = 0x98;
          bStack_10526 = 0x69;
          bStack_10525 = 0x40;
          bStack_10524 = 1;
          bStack_10523 = 0;
          bStack_10522 = 0;
          bStack_10521 = 0;
          bStack_10520 = bVar76;
          core[505b25137b8ba7f]::result::unwrap_failed
                    ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                     &
                     PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
                     ,&
                      PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2dc8
                    );
          goto LAB_140036cf0;
        }
        pbVar101 = &bStack_104a8;
        uVar117 = route_peer(&DAT_140699950,pbVar101,&bStack_10471);
        if ((uVar117 & 1) == 0) {
LAB_140030378:
          pauVar79 = HOST_ID_0_llvm_14435704873730135342;
          pauVar82 = DAT_1406998e0;
          if (IS_HOST_0_llvm_14435704873730135342 == '\0') {
            bVar129 = HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0;
            cStack_10530 = '\x01';
            if (DAT_140699860 != 2) {
              in_stack_fffffffffffefaa8 =
                   (undefined **)
                   CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),bStack_10471);
              cVar74 = is_host_route(&DAT_140699950,bVar129,HOST_ID_0_llvm_14435704873730135342,
                                     &bStack_104a8,in_stack_fffffffffffefaa8,
                                     CONCAT17(bStack_10469,uStack_10470),
                                     CONCAT17(bStack_10461,uStack_10468));
              if (((((undefined1 (*) [16])&DAT_00000010 < pauStack_10538) && (cVar74 != '\0')) &&
                  (*(longlong *)*uStack_104b0 == 0x31445254532d5252)) &&
                 (pauVar123 = *(undefined1 (**) [16])(*uStack_104b0 + 8),
                 (!bVar129 || pauVar123 != pauVar79) &&
                 (pauVar123 != pauVar82 && pauVar123 != (undefined1 (*) [16])0x0))) {
                bStack_10518 = (byte)uStack_10498;
                bStack_10517 = (byte)(uStack_10498 >> 8);
                uStack_10516 = uStack_10496;
                uStack_10514 = uStack_10494;
                uStack_10510 = (ushort)uStack_10490;
                uStack_1050e = (ushort)(uStack_10490 >> 0x10);
                uStack_1050c = (ushort)(uStack_10490 >> 0x20);
                uStack_1050a = (ushort)(uStack_10490 >> 0x30);
                bStack_10528 = bStack_104a8;
                bStack_10527 = bStack_104a7;
                bStack_10526 = (byte)uStack_104a6;
                bStack_10525 = (byte)(uStack_104a6 >> 8);
                bStack_10524 = (byte)uStack_104a4;
                bStack_10523 = (byte)(uStack_104a4 >> 8);
                bStack_10522 = (byte)uStack_104a2;
                bStack_10521 = (byte)(uStack_104a2 >> 8);
                bStack_10520 = (byte)uStack_104a0;
                bStack_1051f = (byte)(uStack_104a0 >> 8);
                bStack_1051e = (byte)uStack_1049e;
                bStack_1051d = (byte)(uStack_1049e >> 8);
                bStack_1051c = (byte)uStack_1049c;
                bStack_1051b = (byte)(uStack_1049c >> 8);
                bStack_1051a = (byte)(uStack_1049c >> 0x10);
                bStack_10519 = (byte)(uStack_1049c >> 0x18);
                uVar78 = SUB84(&bStack_10528,0);
                cVar74 = is_blocked(pauVar123);
                cStack_10530 = '\x01';
                if (cVar74 == '\0') {
                  uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
                  <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
                  ::lock(&bStack_10528,&HOST_HEARD);
                  if (CONCAT13(bStack_10525,
                               CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
                    uStack_10438._4_4_ =
                         CONCAT13(bStack_10519,
                                  CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
                    uStack_10438._0_1_ = bStack_10520;
                    uStack_10438._1_1_ = bStack_1051f;
                    uStack_10438._2_1_ = bStack_1051e;
                    uStack_10438._3_1_ = bStack_1051d;
                    bStack_10430 = bStack_10518;
                    core[505b25137b8ba7f]::result::unwrap_failed
                              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                               &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
                               &
                               PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2df8
                              );
                    goto LAB_140036cf0;
                  }
                  pcVar109 = (char *)CONCAT17(bStack_10519,
                                              CONCAT16(bStack_1051a,
                                                       CONCAT15(bStack_1051b,
                                                                CONCAT14(bStack_1051c,
                                                                         CONCAT13(bStack_1051d,
                                                                                  CONCAT12(
                                                  bStack_1051e,CONCAT11(bStack_1051f,bStack_10520)))
                                                  ))));
                  *(undefined8 *)(pcVar109 + 8) = uVar85;
                  *(undefined4 *)(pcVar109 + 0x10) = uVar78;
                  if ((bStack_10518 == 0) &&
                     ((*(ulonglong *)
                        __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
                      & 0x7fffffffffffffff) != 0)) {
                    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                    if (cVar74 == '\0') {
                      pcVar109[1] = '\x01';
                    }
                  }
                  LOCK();
                  cVar74 = *pcVar109;
                  *pcVar109 = '\0';
                  UNLOCK();
                  if (cVar74 == '\x02') {
                    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
                  }
                  netstats::engine_arrival(pauVar123);
                  cStack_10530 = '\x02';
                  queue_engine(&DAT_140699730,pauVar123,uStack_104b0 + 1,pauStack_10538 + -1);
                }
              }
            }
          }
          else {
            cStack_10530 = '\x01';
            if (((undefined1 (*) [16])&DAT_00000010 < pauStack_10538) &&
               (*(longlong *)*uStack_104b0 == 0x31445254532d5252)) {
              pauVar82 = *(undefined1 (**) [16])(*uStack_104b0 + 8);
              uStack_10278._0_1_ = (byte)pauVar82;
              uStack_10278._1_1_ = (byte)((ulonglong)pauVar82 >> 8);
              uStack_10276 = (ushort)((ulonglong)pauVar82 >> 0x10);
              uStack_10274 = (ushort)((ulonglong)pauVar82 >> 0x20);
              uStack_10272 = (ushort)((ulonglong)pauVar82 >> 0x30);
              if (DAT_1406998d8 == '\x01') {
                pauVar79 = (undefined1 (*) [16])&bStack_104a8;
                lVar80 = route_peer(&DAT_140699950,pauVar79,&bStack_10471);
                if (lVar80 == 1) {
                  uStack_103a8 = (ushort)pauVar79;
                  uStack_103a6 = (ushort)((ulonglong)pauVar79 >> 0x10);
                  uStack_103a4 = (ushort)((ulonglong)pauVar79 >> 0x20);
                  uStack_103a2 = (ushort)((ulonglong)pauVar79 >> 0x30);
                  if (DAT_140699968 != 0) {
                    uStack_10458 = uStack_104b0 + 1;
                    uStack_104c0 = pauVar79;
                    uVar81 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                             ::hash_one::<&usize>(&DAT_140699970,&uStack_103a8);
                    uVar117 = DAT_140699958;
                    pauVar79 = DAT_140699950;
                    bVar75 = (byte)(uVar81 >> 0x39);
                    auVar133 = ZEXT216(CONCAT11(bVar75,bVar75));
                    auVar133 = pshuflw(auVar133,auVar133,0);
                    lVar80 = 0;
                    while( true ) {
                      uVar81 = uVar81 & DAT_140699958;
                      auVar137 = *(undefined1 (*) [16])(*DAT_140699950 + uVar81);
                      auVar174[0] = -(auVar137[0] == auVar133[0]);
                      auVar174[1] = -(auVar137[1] == auVar133[1]);
                      auVar174[2] = -(auVar137[2] == auVar133[2]);
                      auVar174[3] = -(auVar137[3] == auVar133[3]);
                      auVar174[4] = -(auVar137[4] == auVar133[4]);
                      auVar174[5] = -(auVar137[5] == auVar133[5]);
                      auVar174[6] = -(auVar137[6] == auVar133[6]);
                      auVar174[7] = -(auVar137[7] == auVar133[7]);
                      auVar174[8] = -(auVar137[8] == auVar133[0]);
                      auVar174[9] = -(auVar137[9] == auVar133[1]);
                      auVar174[10] = -(auVar137[10] == auVar133[2]);
                      auVar174[0xb] = -(auVar137[0xb] == auVar133[3]);
                      auVar174[0xc] = -(auVar137[0xc] == auVar133[4]);
                      auVar174[0xd] = -(auVar137[0xd] == auVar133[5]);
                      auVar174[0xe] = -(auVar137[0xe] == auVar133[6]);
                      auVar174[0xf] = -(auVar137[0xf] == auVar133[7]);
                      uVar112 = (ushort)(SUB161(auVar174 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar174 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar174 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar174 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar174 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar174 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar174 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar174 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar174 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar174 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar174 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar174 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar174 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar174 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar174 >> 0x77,0) & 1) << 0xe |
                                (ushort)(auVar174[0xf] >> 7) << 0xf;
                      uVar113 = (uint)uVar112;
                      while (uVar112 != 0) {
                        uVar114 = 0;
                        for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000)
                        {
                          uVar114 = uVar114 + 1;
                        }
                        uVar83 = uVar114 + uVar81 & DAT_140699958;
                        if (uStack_104c0 == *(undefined1 (**) [16])DAT_140699950[uVar83 * -5 + -5])
                        {
                          pauVar123 = DAT_140699950 + uVar83 * -5 + -5;
                          uVar81 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                                   ::hash_one::<&usize>(&DAT_140699970,&uStack_10278);
                          bVar75 = (byte)(uVar81 >> 0x39);
                          auVar133 = ZEXT216(CONCAT11(bVar75,bVar75));
                          auVar133 = pshuflw(auVar133,auVar133,0);
                          lVar80 = 0;
                          goto LAB_140033330;
                        }
                        uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
                        uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
                      }
                      auVar155[0] = -(auVar137[0] == cVar72);
                      auVar155[1] = -(auVar137[1] == cVar181);
                      auVar155[2] = -(auVar137[2] == cVar182);
                      auVar155[3] = -(auVar137[3] == cVar183);
                      auVar155[4] = -(auVar137[4] == cVar184);
                      auVar155[5] = -(auVar137[5] == cVar185);
                      auVar155[6] = -(auVar137[6] == cVar186);
                      auVar155[7] = -(auVar137[7] == cVar187);
                      auVar155[8] = -(auVar137[8] == cVar188);
                      auVar155[9] = -(auVar137[9] == cVar189);
                      auVar155[10] = -(auVar137[10] == cVar190);
                      auVar155[0xb] = -(auVar137[0xb] == cVar191);
                      auVar155[0xc] = -(auVar137[0xc] == cVar192);
                      auVar155[0xd] = -(auVar137[0xd] == cVar193);
                      auVar155[0xe] = -(auVar137[0xe] == cVar194);
                      auVar155[0xf] = -(auVar137[0xf] == cVar195);
                      if ((((((((((((((((SUB161(auVar155 >> 7,0) & 1) != 0 ||
                                       (SUB161(auVar155 >> 0xf,0) & 1) != 0) ||
                                      (SUB161(auVar155 >> 0x17,0) & 1) != 0) ||
                                     (SUB161(auVar155 >> 0x1f,0) & 1) != 0) ||
                                    (SUB161(auVar155 >> 0x27,0) & 1) != 0) ||
                                   (SUB161(auVar155 >> 0x2f,0) & 1) != 0) ||
                                  (SUB161(auVar155 >> 0x37,0) & 1) != 0) ||
                                 (SUB161(auVar155 >> 0x3f,0) & 1) != 0) ||
                                (SUB161(auVar155 >> 0x47,0) & 1) != 0) ||
                               (SUB161(auVar155 >> 0x4f,0) & 1) != 0) ||
                              (SUB161(auVar155 >> 0x57,0) & 1) != 0) ||
                             (SUB161(auVar155 >> 0x5f,0) & 1) != 0) ||
                            (SUB161(auVar155 >> 0x67,0) & 1) != 0) ||
                           (SUB161(auVar155 >> 0x6f,0) & 1) != 0) ||
                          (SUB161(auVar155 >> 0x77,0) & 1) != 0) || auVar155[0xf] < '\0') break;
                      uVar81 = uVar81 + lVar80 + 0x10;
                      lVar80 = lVar80 + 0x10;
                    }
                  }
                }
              }
LAB_140033728:
              cStack_10530 = '\x01';
            }
          }
joined_r0x0001400343ad:
          if ((bVar76 == 0) &&
             ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) != 0)) {
            cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            if (cVar74 == '\0') {
              DAT_140699831 = '\x01';
            }
          }
          cVar74 = TRANSPORT;
          LOCK();
          TRANSPORT = '\0';
          UNLOCK();
          if (cVar74 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
          }
          if (((byte)unaff_R15 == 0) &&
             ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) != 0)) {
            cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            if (cVar74 == '\0') {
              DAT_140699949 = '\x01';
            }
          }
          cVar74 = DAT_140699948;
          LOCK();
          DAT_140699948 = '\0';
          UNLOCK();
          if (cVar74 != '\x02') goto LAB_1400331d0;
          pcVar109 = &DAT_140699948;
          goto LAB_140033f4e;
        }
        bStack_10528 = (byte)pbVar101;
        bStack_10527 = (byte)((ulonglong)pbVar101 >> 8);
        bStack_10526 = (byte)((ulonglong)pbVar101 >> 0x10);
        bStack_10525 = (byte)((ulonglong)pbVar101 >> 0x18);
        bStack_10524 = (byte)((ulonglong)pbVar101 >> 0x20);
        bStack_10523 = (byte)((ulonglong)pbVar101 >> 0x28);
        bStack_10522 = (byte)((ulonglong)pbVar101 >> 0x30);
        bStack_10521 = (byte)((ulonglong)pbVar101 >> 0x38);
        pbVar102 = pbVar101;
        uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
        if (DAT_140699968 != 0) {
          uVar117 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                    ::hash_one::<&usize>(&DAT_140699970,&bStack_10528);
          pauVar82 = DAT_140699950;
          bVar75 = (byte)(uVar117 >> 0x39);
          auVar133 = ZEXT216(CONCAT11(bVar75,bVar75));
          auVar133 = pshuflw(auVar133,auVar133,0);
          lVar80 = 0;
          while( true ) {
            uVar117 = uVar117 & DAT_140699958;
            pcVar109 = *DAT_140699950 + uVar117;
            auVar173[0] = -(*pcVar109 == auVar133[0]);
            auVar173[1] = -(pcVar109[1] == auVar133[1]);
            auVar173[2] = -(pcVar109[2] == auVar133[2]);
            auVar173[3] = -(pcVar109[3] == auVar133[3]);
            auVar173[4] = -(pcVar109[4] == auVar133[4]);
            auVar173[5] = -(pcVar109[5] == auVar133[5]);
            auVar173[6] = -(pcVar109[6] == auVar133[6]);
            auVar173[7] = -(pcVar109[7] == auVar133[7]);
            auVar173[8] = -(pcVar109[8] == auVar133[0]);
            auVar173[9] = -(pcVar109[9] == auVar133[1]);
            auVar173[10] = -(pcVar109[10] == auVar133[2]);
            auVar173[0xb] = -(pcVar109[0xb] == auVar133[3]);
            auVar173[0xc] = -(pcVar109[0xc] == auVar133[4]);
            auVar173[0xd] = -(pcVar109[0xd] == auVar133[5]);
            auVar173[0xe] = -(pcVar109[0xe] == auVar133[6]);
            auVar173[0xf] = -(pcVar109[0xf] == auVar133[7]);
            uVar112 = (ushort)(SUB161(auVar173 >> 7,0) & 1) |
                      (ushort)(SUB161(auVar173 >> 0xf,0) & 1) << 1 |
                      (ushort)(SUB161(auVar173 >> 0x17,0) & 1) << 2 |
                      (ushort)(SUB161(auVar173 >> 0x1f,0) & 1) << 3 |
                      (ushort)(SUB161(auVar173 >> 0x27,0) & 1) << 4 |
                      (ushort)(SUB161(auVar173 >> 0x2f,0) & 1) << 5 |
                      (ushort)(SUB161(auVar173 >> 0x37,0) & 1) << 6 |
                      (ushort)(SUB161(auVar173 >> 0x3f,0) & 1) << 7 |
                      (ushort)(SUB161(auVar173 >> 0x47,0) & 1) << 8 |
                      (ushort)(SUB161(auVar173 >> 0x4f,0) & 1) << 9 |
                      (ushort)(SUB161(auVar173 >> 0x57,0) & 1) << 10 |
                      (ushort)(SUB161(auVar173 >> 0x5f,0) & 1) << 0xb |
                      (ushort)(SUB161(auVar173 >> 0x67,0) & 1) << 0xc |
                      (ushort)(SUB161(auVar173 >> 0x6f,0) & 1) << 0xd |
                      (ushort)(SUB161(auVar173 >> 0x77,0) & 1) << 0xe |
                      (ushort)(auVar173[0xf] >> 7) << 0xf;
            uVar113 = (uint)uVar112;
            while (uVar112 != 0) {
              uVar114 = 0;
              for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
                uVar114 = uVar114 + 1;
              }
              uVar81 = uVar114 + uVar117 & DAT_140699958;
              if (pbVar101 == *(byte **)DAT_140699950[uVar81 * -5 + -5]) {
                *(undefined8 *)(DAT_140699950[uVar81 * -5 + -5] + 8) = uVar85;
                *(int *)pauVar82[uVar81 * -5 + -4] = (int)pbVar102;
                goto LAB_140030378;
              }
              uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
              uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
            }
            auVar150[0] = -(*pcVar109 == cVar72);
            auVar150[1] = -(pcVar109[1] == cVar181);
            auVar150[2] = -(pcVar109[2] == cVar182);
            auVar150[3] = -(pcVar109[3] == cVar183);
            auVar150[4] = -(pcVar109[4] == cVar184);
            auVar150[5] = -(pcVar109[5] == cVar185);
            auVar150[6] = -(pcVar109[6] == cVar186);
            auVar150[7] = -(pcVar109[7] == cVar187);
            auVar150[8] = -(pcVar109[8] == cVar188);
            auVar150[9] = -(pcVar109[9] == cVar189);
            auVar150[10] = -(pcVar109[10] == cVar190);
            auVar150[0xb] = -(pcVar109[0xb] == cVar191);
            auVar150[0xc] = -(pcVar109[0xc] == cVar192);
            auVar150[0xd] = -(pcVar109[0xd] == cVar193);
            auVar150[0xe] = -(pcVar109[0xe] == cVar194);
            auVar150[0xf] = -(pcVar109[0xf] == cVar195);
            if ((((((((((((((((SUB161(auVar150 >> 7,0) & 1) != 0 ||
                             (SUB161(auVar150 >> 0xf,0) & 1) != 0) ||
                            (SUB161(auVar150 >> 0x17,0) & 1) != 0) ||
                           (SUB161(auVar150 >> 0x1f,0) & 1) != 0) ||
                          (SUB161(auVar150 >> 0x27,0) & 1) != 0) ||
                         (SUB161(auVar150 >> 0x2f,0) & 1) != 0) ||
                        (SUB161(auVar150 >> 0x37,0) & 1) != 0) ||
                       (SUB161(auVar150 >> 0x3f,0) & 1) != 0) ||
                      (SUB161(auVar150 >> 0x47,0) & 1) != 0) ||
                     (SUB161(auVar150 >> 0x4f,0) & 1) != 0) || (SUB161(auVar150 >> 0x57,0) & 1) != 0
                    ) || (SUB161(auVar150 >> 0x5f,0) & 1) != 0) ||
                  (SUB161(auVar150 >> 0x67,0) & 1) != 0) || (SUB161(auVar150 >> 0x6f,0) & 1) != 0)
                || (SUB161(auVar150 >> 0x77,0) & 1) != 0) || auVar150[0xf] < '\0') break;
            uVar117 = uVar117 + lVar80 + 0x10;
            lVar80 = lVar80 + 0x10;
          }
        }
        core[505b25137b8ba7f]::option::unwrap_failed
                  (&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2de0)
        ;
      }
      else {
        bStack_10528 = 0x48;
        bStack_10527 = 0x99;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = (byte)unaff_R15;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2db0)
        ;
      }
      goto LAB_140036cf0;
    }
    note_star_oversize();
    goto LAB_1400331d8;
  }
  if (*(longlong *)*uStack_104b0 == 0x32544148432d5252) {
    LOCK();
    bVar129 = DAT_140699948 == '\0';
    if (bVar129) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
      bVar75 = bStack_10528;
      bVar73 = bStack_10527;
      bVar54 = bStack_10526;
      bVar55 = bStack_10525;
      bVar132 = bStack_10524;
      bVar56 = bStack_10523;
      bVar57 = bStack_10522;
      bVar58 = bStack_10521;
      bVar59 = bStack_10520;
      bVar60 = bStack_1051f;
      bVar61 = bStack_1051e;
      bVar62 = bStack_1051d;
      bVar63 = bStack_1051c;
      bVar64 = bStack_1051b;
      bVar65 = bStack_1051a;
      bVar66 = bStack_10519;
      bVar67 = bStack_10518;
      bVar77 = bStack_10517;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
      bVar75 = bStack_10528;
      bVar73 = bStack_10527;
      bVar54 = bStack_10526;
      bVar55 = bStack_10525;
      bVar132 = bStack_10524;
      bVar56 = bStack_10523;
      bVar57 = bStack_10522;
      bVar58 = bStack_10521;
      bVar59 = bStack_10520;
      bVar60 = bStack_1051f;
      bVar61 = bStack_1051e;
      bVar62 = bStack_1051d;
      bVar63 = bStack_1051c;
      bVar64 = bStack_1051b;
      bVar65 = bStack_1051a;
      bVar66 = bStack_10519;
      bVar67 = bStack_10518;
      bVar77 = bStack_10517;
    }
    if (DAT_140699949 == '\0') {
      uVar117 = (ulonglong)uStack_10458 >> 8;
      uStack_10458 = (undefined1 (*) [16])
                     CONCAT71((int7)uVar117,IS_HOST_0_llvm_14435704873730135342 != '\0');
      uStack_104c0 = (undefined1 (*) [16])CONCAT17(bStack_10469,uStack_10470);
      lVar80 = CONCAT17(bStack_10461,uStack_10468);
      sVar116 = CONCAT11(bStack_104a7,bStack_104a8);
      uStack_10490._4_2_ = (ushort)(uStack_10490 >> 0x20);
      auVar133 = *DAT_140699950;
      pauVar82 = DAT_140699950 + 1;
      uVar113 = ~(uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
      bStack_1051a = (byte)uStack_10498;
      bVar50 = bStack_1051a;
      bStack_10519 = (byte)(uStack_10498 >> 8);
      bVar51 = bStack_10519;
      bStack_10518 = (byte)uStack_10496;
      bVar52 = bStack_10518;
      bStack_10517 = (byte)(uStack_10496 >> 8);
      bVar53 = bStack_10517;
      bStack_1051e = (byte)uStack_1049c;
      bVar46 = bStack_1051e;
      bStack_1051d = (byte)(uStack_1049c >> 8);
      bVar47 = bStack_1051d;
      bStack_1051c = (byte)(uStack_1049c >> 0x10);
      bVar48 = bStack_1051c;
      bStack_1051b = (byte)(uStack_1049c >> 0x18);
      bVar49 = bStack_1051b;
      bStack_10520 = (byte)uStack_1049e;
      bVar44 = bStack_10520;
      bStack_1051f = (byte)(uStack_1049e >> 8);
      bVar45 = bStack_1051f;
      bStack_10522 = (byte)uStack_104a0;
      bVar42 = bStack_10522;
      bStack_10521 = (byte)(uStack_104a0 >> 8);
      bVar43 = bStack_10521;
      bStack_10524 = (byte)uStack_104a2;
      bVar40 = bStack_10524;
      bStack_10523 = (byte)(uStack_104a2 >> 8);
      bVar41 = bStack_10523;
      bStack_10528 = (byte)uStack_104a6;
      bVar36 = bStack_10528;
      bStack_10527 = (byte)(uStack_104a6 >> 8);
      bVar37 = bStack_10527;
      bStack_10526 = (byte)uStack_104a4;
      bVar38 = bStack_10526;
      bStack_10525 = (byte)(uStack_104a4 >> 8);
      bVar39 = bStack_10525;
      lVar120 = DAT_140699968;
      pauVar79 = DAT_140699950;
      bStack_10528 = bVar75;
      bStack_10527 = bVar73;
      bStack_10526 = bVar54;
      bStack_10525 = bVar55;
      bStack_10524 = bVar132;
      bStack_10523 = bVar56;
      bStack_10522 = bVar57;
      bStack_10521 = bVar58;
      bStack_10520 = bVar59;
      bStack_1051f = bVar60;
      bStack_1051e = bVar61;
      bStack_1051d = bVar62;
      bStack_1051c = bVar63;
      bStack_1051b = bVar64;
      bStack_1051a = bVar65;
      bStack_10519 = bVar66;
      bStack_10518 = bVar67;
      bStack_10517 = bVar77;
      if ((bStack_104a8 & 1) == 0) {
        if ((bStack_10471 & 1) == 0) {
          do {
            if (lVar120 == 0) goto LAB_14002f33a;
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar113 = uVar113 - 1 & uVar113;
            unaff_R15 = (undefined1 (*) [16])((ulonglong)uVar114 * -0x50);
            lVar120 = lVar120 + -1;
            bStack_10528 = bVar36;
            bStack_10527 = bVar37;
            bStack_10526 = bVar38;
            bStack_10525 = bVar39;
            bStack_10524 = bVar40;
            bStack_10523 = bVar41;
            bStack_10522 = bVar42;
            bStack_10521 = bVar43;
            bStack_10520 = bVar44;
            bStack_1051f = bVar45;
            bStack_1051e = bVar46;
            bStack_1051d = bVar47;
            bStack_1051c = bVar48;
            bStack_1051b = bVar49;
            bStack_1051a = bVar50;
            bStack_10519 = bVar51;
            bStack_10518 = bVar52;
            bStack_10517 = bVar53;
          } while (((*(short *)(pauVar79[-4] + 8 + (longlong)unaff_R15) != sVar116) ||
                   (unaff_R15 = (undefined1 (*) [16])(*pauVar79 + (longlong)*unaff_R15),
                   *(ushort *)(unaff_R15[-4] + 0xe) != uStack_104a2)) ||
                  ((*(int *)(unaff_R15[-4] + 10) != CONCAT13(bVar39,CONCAT12(bVar38,uStack_104a6))
                   || (unaff_R15[-2][8] == '\x01'))));
        }
        else {
          do {
            if (lVar120 == 0) goto LAB_14002f33a;
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar113 = uVar113 - 1 & uVar113;
            unaff_R15 = (undefined1 (*) [16])((ulonglong)uVar114 * -0x50);
            lVar120 = lVar120 + -1;
            bStack_10528 = bVar36;
            bStack_10527 = bVar37;
            bStack_10526 = bVar38;
            bStack_10525 = bVar39;
            bStack_10524 = bVar40;
            bStack_10523 = bVar41;
            bStack_10522 = bVar42;
            bStack_10521 = bVar43;
            bStack_10520 = bVar44;
            bStack_1051f = bVar45;
            bStack_1051e = bVar46;
            bStack_1051d = bVar47;
            bStack_1051c = bVar48;
            bStack_1051b = bVar49;
            bStack_1051a = bVar50;
            bStack_10519 = bVar51;
            bStack_10518 = bVar52;
            bStack_10517 = bVar53;
          } while ((((*(short *)(pauVar79[-4] + 8 + (longlong)unaff_R15) != sVar116) ||
                    (unaff_R15 = (undefined1 (*) [16])(*pauVar79 + (longlong)*unaff_R15),
                    *(ushort *)(unaff_R15[-4] + 0xe) != uStack_104a2)) ||
                   (*(int *)(unaff_R15[-4] + 10) != CONCAT13(bVar39,CONCAT12(bVar38,uStack_104a6))))
                  || ((unaff_R15[-2][8] != '\x01' ||
                      (*(longlong *)(unaff_R15[-1] + 1) != lVar80 ||
                       *(undefined1 (**) [16])(unaff_R15[-2] + 9) != uStack_104c0))));
        }
      }
      else {
        do {
          while( true ) {
            do {
              do {
                if (lVar120 == 0) goto LAB_14002f33a;
                uVar112 = (ushort)uVar113;
                while (uVar112 == 0) {
                  auVar133 = *pauVar82;
                  pauVar79 = pauVar79 + -0x50;
                  pauVar82 = pauVar82 + 1;
                  uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                             (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                             (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                             (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                             (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                             (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                             (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                             (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                             (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                             (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                             (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                             (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                             (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                             (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                             (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                            (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
                  uVar113 = (uint)uVar112;
                }
                uVar114 = 0;
                for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
                  uVar114 = uVar114 + 1;
                }
                uVar113 = uVar113 - 1 & uVar113;
                unaff_R15 = (undefined1 (*) [16])((ulonglong)uVar114 * -0x50);
                lVar120 = lVar120 + -1;
                bStack_10528 = bVar36;
                bStack_10527 = bVar37;
                bStack_10526 = bVar38;
                bStack_10525 = bVar39;
                bStack_10524 = bVar40;
                bStack_10523 = bVar41;
                bStack_10522 = bVar42;
                bStack_10521 = bVar43;
                bStack_10520 = bVar44;
                bStack_1051f = bVar45;
                bStack_1051e = bVar46;
                bStack_1051d = bVar47;
                bStack_1051c = bVar48;
                bStack_1051b = bVar49;
                bStack_1051a = bVar50;
                bStack_10519 = bVar51;
                bStack_10518 = bVar52;
                bStack_10517 = bVar53;
              } while ((((*(short *)(pauVar79[-4] + 8 + (longlong)unaff_R15) != sVar116) ||
                        (unaff_R15 = (undefined1 (*) [16])(*pauVar79 + (longlong)*unaff_R15),
                        *(short *)(unaff_R15[-2] + 4) != uStack_10490._4_2_)) ||
                       (*(uint *)(unaff_R15[-3] + 0xc) != uStack_10494)) ||
                      (*(int *)unaff_R15[-2] != (int)uStack_10490));
              auVar133 = *(undefined1 (*) [16])(unaff_R15[-4] + 0xc);
              auVar149[0] = -(bVar38 == auVar133[0]);
              auVar149[1] = -(bVar39 == auVar133[1]);
              auVar149[2] = -(bVar40 == auVar133[2]);
              auVar149[3] = -(bVar41 == auVar133[3]);
              auVar149[4] = -(bVar42 == auVar133[4]);
              auVar149[5] = -(bVar43 == auVar133[5]);
              auVar149[6] = -(bVar44 == auVar133[6]);
              auVar149[7] = -(bVar45 == auVar133[7]);
              auVar149[8] = -(bVar46 == auVar133[8]);
              auVar149[9] = -(bVar47 == auVar133[9]);
              auVar149[10] = -(bVar48 == auVar133[10]);
              auVar149[0xb] = -(bVar49 == auVar133[0xb]);
              auVar149[0xc] = -(bVar50 == auVar133[0xc]);
              auVar149[0xd] = -(bVar51 == auVar133[0xd]);
              auVar149[0xe] = -(bVar52 == auVar133[0xe]);
              auVar149[0xf] = -(bVar53 == auVar133[0xf]);
            } while ((ushort)((ushort)(SUB161(auVar149 >> 7,0) & 1) |
                              (ushort)(SUB161(auVar149 >> 0xf,0) & 1) << 1 |
                              (ushort)(SUB161(auVar149 >> 0x17,0) & 1) << 2 |
                              (ushort)(SUB161(auVar149 >> 0x1f,0) & 1) << 3 |
                              (ushort)(SUB161(auVar149 >> 0x27,0) & 1) << 4 |
                              (ushort)(SUB161(auVar149 >> 0x2f,0) & 1) << 5 |
                              (ushort)(SUB161(auVar149 >> 0x37,0) & 1) << 6 |
                              (ushort)(SUB161(auVar149 >> 0x3f,0) & 1) << 7 |
                              (ushort)(SUB161(auVar149 >> 0x47,0) & 1) << 8 |
                              (ushort)(SUB161(auVar149 >> 0x4f,0) & 1) << 9 |
                              (ushort)(SUB161(auVar149 >> 0x57,0) & 1) << 10 |
                              (ushort)(SUB161(auVar149 >> 0x5f,0) & 1) << 0xb |
                              (ushort)(SUB161(auVar149 >> 0x67,0) & 1) << 0xc |
                              (ushort)(SUB161(auVar149 >> 0x6f,0) & 1) << 0xd |
                              (ushort)(SUB161(auVar149 >> 0x77,0) & 1) << 0xe |
                             (ushort)(auVar149[0xf] >> 7) << 0xf) != 0xffff);
            if (unaff_R15[-2][8] == '\0') break;
            if (((bStack_10471 & 1) != 0) &&
               (*(longlong *)(unaff_R15[-1] + 1) == lVar80 &&
                *(undefined1 (**) [16])(unaff_R15[-2] + 9) == uStack_104c0)) goto LAB_14002f2f2;
          }
        } while ((bStack_10471 & 1) != 0);
      }
LAB_14002f2f2:
      unaff_R15 = unaff_R15 + -5;
      uStack_10460 = *(undefined1 (**) [16])*unaff_R15;
      uStack_104b8._4_4_ = (uint)((ulonglong)uStack_104b8 >> 0x20);
      uStack_104b8 = (undefined1 (*) [16])
                     CONCAT44(uStack_104b8._4_4_,
                              (int)CONCAT71((int7)((ulonglong)uStack_10460 >> 8),1));
      for (; lVar120 != 0; lVar120 = lVar120 + -1) {
        uVar112 = (ushort)uVar113;
        while (uVar112 == 0) {
          auVar133 = *pauVar82;
          pauVar79 = pauVar79 + -0x50;
          pauVar82 = pauVar82 + 1;
          uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar113 = (uint)uVar112;
        }
        uVar114 = 0;
        for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
          uVar114 = uVar114 + 1;
        }
        uVar117 = (ulonglong)uVar114;
        unaff_R15 = (undefined1 (*) [16])&uStack_104a6;
        if (*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) {
          if ((bStack_104a8 & 1) == 0) {
            if ((*(ushort *)(pauVar79[uVar117 * -5 + -4] + 0xe) == uStack_104a2) &&
               (*(int *)(pauVar79[uVar117 * -5 + -4] + 10) ==
                CONCAT13(bVar39,CONCAT12(bVar38,uStack_104a6)))) {
LAB_140030bbd:
              if (pauVar79[uVar117 * -5 + -2][8] == '\x01') {
                if (((bStack_10471 & 1) != 0) &&
                   (*(longlong *)(pauVar79[uVar117 * -5 + -1] + 1) == lVar80 &&
                    *(undefined1 (**) [16])(pauVar79[uVar117 * -5 + -2] + 9) == uStack_104c0)) {
LAB_140030bed:
                  uStack_104b8 = (undefined1 (*) [16])((ulonglong)uStack_104b8._4_4_ << 0x20);
                  break;
                }
              }
              else if ((bStack_10471 & 1) == 0) goto LAB_140030bed;
            }
          }
          else if ((*(short *)(pauVar79[uVar117 * -5 + -2] + 4) == uStack_10490._4_2_) &&
                  ((*(uint *)(pauVar79[uVar117 * -5 + -3] + 0xc) == uStack_10494 &&
                   (*(int *)pauVar79[uVar117 * -5 + -2] == (int)uStack_10490)))) {
            auVar133 = *(undefined1 (*) [16])(pauVar79[uVar117 * -5 + -4] + 0xc);
            auVar157[0] = -(bVar38 == auVar133[0]);
            auVar157[1] = -(bVar39 == auVar133[1]);
            auVar157[2] = -(bVar40 == auVar133[2]);
            auVar157[3] = -(bVar41 == auVar133[3]);
            auVar157[4] = -(bVar42 == auVar133[4]);
            auVar157[5] = -(bVar43 == auVar133[5]);
            auVar157[6] = -(bVar44 == auVar133[6]);
            auVar157[7] = -(bVar45 == auVar133[7]);
            auVar157[8] = -(bVar46 == auVar133[8]);
            auVar157[9] = -(bVar47 == auVar133[9]);
            auVar157[10] = -(bVar48 == auVar133[10]);
            auVar157[0xb] = -(bVar49 == auVar133[0xb]);
            auVar157[0xc] = -(bVar50 == auVar133[0xc]);
            auVar157[0xd] = -(bVar51 == auVar133[0xd]);
            auVar157[0xe] = -(bVar52 == auVar133[0xe]);
            auVar157[0xf] = -(bVar53 == auVar133[0xf]);
            if ((ushort)((ushort)(SUB161(auVar157 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar157 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar157 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar157 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar157 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar157 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar157 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar157 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar157 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar157 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar157 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar157 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar157 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar157 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar157 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar157[0xf] >> 7) << 0xf) == 0xffff) goto LAB_140030bbd;
          }
        }
        uVar113 = uVar113 - 1 & uVar113;
      }
      bVar75 = (HOST_ID_0_llvm_14435704873730135342 == uStack_10460 ||
               (HOST_ID_0_llvm_14435704873730135342 == (undefined1 (*) [16])0x0 ||
               IS_HOST_0_llvm_14435704873730135342 != '\0')) & (byte)uStack_104b8;
      bStack_10528 = bVar36;
      bStack_10527 = bVar37;
      bStack_10526 = bVar38;
      bStack_10525 = bVar39;
      bStack_10524 = bVar40;
      bStack_10523 = bVar41;
      bStack_10522 = bVar42;
      bStack_10521 = bVar43;
      bStack_10520 = bVar44;
      bStack_1051f = bVar45;
      bStack_1051e = bVar46;
      bStack_1051d = bVar47;
      bStack_1051c = bVar48;
      bStack_1051b = bVar49;
      bStack_1051a = bVar50;
      bStack_10519 = bVar51;
      bStack_10518 = bVar52;
      bStack_10517 = bVar53;
      goto LAB_14002f33c;
    }
    bStack_10528 = 0x48;
    bStack_10527 = 0x99;
    bStack_10526 = 0x69;
    bStack_10525 = 0x40;
    bStack_10524 = 1;
    bStack_10523 = 0;
    bStack_10522 = 0;
    bStack_10521 = 0;
    bStack_10520 = bVar76;
    bStack_1051f = bVar60;
    bStack_1051e = bVar61;
    bStack_1051d = bVar62;
    bStack_1051c = bVar63;
    bStack_1051b = bVar64;
    bStack_1051a = bVar65;
    bStack_10519 = bVar66;
    bStack_10518 = bVar67;
    bStack_10517 = bVar77;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2d98);
    goto LAB_140036cf0;
  }
  if (*(longlong *)*uStack_104b0 == 0x31305249442d5252) {
    if (((DAT_140699989 != '\0') || (pauStack_10538 != (undefined1 (*) [16])&DAT_00000018)) ||
       ((bStack_10471 != 0 ||
        (pauStack_10538 = (undefined1 (*) [16])&DAT_00000018,
        *(undefined1 (**) [16])(*uStack_104b0 + 8) != DAT_1406998e0)))) goto LAB_1400331d8;
    LOCK();
    bVar129 = DAT_140699920 == '\0';
    if (bVar129) {
      DAT_140699920 = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699920);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      uVar114 = 0;
      pauVar82 = DAT_140699928;
      lVar80 = DAT_140699930;
      pauVar79 = DAT_140699938;
      pauVar123 = DAT_140699940;
      uVar113 = uStack_10494;
      uVar117 = uStack_10490;
    }
    else {
      uVar114 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      uVar114 = uVar114 ^ 1;
      pauVar82 = DAT_140699928;
      lVar80 = DAT_140699930;
      pauVar79 = DAT_140699938;
      pauVar123 = DAT_140699940;
      uVar113 = uStack_10494;
      uVar117 = uStack_10490;
    }
    DAT_140699928 = pauVar82;
    DAT_140699930 = lVar80;
    DAT_140699938 = pauVar79;
    DAT_140699940 = pauVar123;
    uStack_10494 = uVar113;
    uStack_10490 = uVar117;
    if (DAT_140699921 != '\0') {
      bStack_10528 = 0x20;
      bStack_10527 = 0x99;
      bStack_10526 = 0x69;
      bStack_10525 = 0x40;
      bStack_10524 = 1;
      bStack_10523 = 0;
      bStack_10522 = 0;
      bStack_10521 = 0;
      bStack_10520 = (byte)uVar114;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                 &
                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a10b0
                 ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2d80);
      goto LAB_140036cf0;
    }
    sVar116 = CONCAT11(bStack_104a7,bStack_104a8);
    bStack_10528 = (byte)uStack_104a6;
    bStack_10527 = (byte)(uStack_104a6 >> 8);
    bStack_10526 = (byte)uStack_104a4;
    bStack_10525 = (byte)(uStack_104a4 >> 8);
    bStack_10524 = (byte)uStack_104a2;
    bStack_10523 = (byte)(uStack_104a2 >> 8);
    bStack_10522 = (byte)uStack_104a0;
    bStack_10521 = (byte)(uStack_104a0 >> 8);
    bStack_10520 = (byte)uStack_1049e;
    bStack_1051f = (byte)(uStack_1049e >> 8);
    bStack_1051e = (byte)uStack_1049c;
    bStack_1051d = (byte)(uStack_1049c >> 8);
    bStack_1051c = (byte)(uStack_1049c >> 0x10);
    bStack_1051b = (byte)(uStack_1049c >> 0x18);
    bStack_1051a = (byte)uStack_10498;
    bStack_10519 = (byte)(uStack_10498 >> 8);
    bStack_10518 = (byte)uStack_10496;
    bStack_10517 = (byte)(uStack_10496 >> 8);
    uStack_10490._0_4_ = (int)uVar117;
    uStack_10490._4_4_ = (undefined4)(uVar117 >> 0x20);
    uVar78 = uStack_10490._4_4_;
    iVar127 = (int)uStack_10490;
    if (pauVar123 == (undefined1 (*) [16])0x0) {
      pauVar123 = (undefined1 (*) [16])0x0;
      goto LAB_14003381d;
    }
    uVar81 = (ulonglong)uStack_10458 >> 0x20;
    uStack_10458 = (undefined1 (*) [16])CONCAT44((int)uVar81,uVar114);
    pauVar89 = pauVar82;
    if (pauVar79 < pauVar82) {
      pauVar89 = (undefined1 (*) [16])0x0;
    }
    pauVar89 = (undefined1 (*) [16])((longlong)pauVar79 - (longlong)pauVar89);
    pauVar92 = (undefined1 (*) [16])((longlong)pauVar82 - (longlong)pauVar89);
    lVar120 = ((longlong)pauVar123 - (longlong)pauVar92) * 0x20;
    if (pauVar123 <= pauVar92) {
      lVar120 = 0;
    }
    pauVar84 = (undefined1 (*) [16])(*pauVar123 + (longlong)*pauVar89);
    if (pauVar92 < pauVar123) {
      pauVar84 = pauVar82;
    }
    uStack_10490._4_2_ = (ushort)(uVar117 >> 0x20);
    pauVar104 = (undefined1 (*) [16])0x0;
    uStack_104c0._4_4_ = (undefined4)((ulonglong)uStack_104c0 >> 0x20);
    uStack_104c0 = (undefined1 (*) [16])CONCAT44(uStack_104c0._4_4_,(int)uStack_10490);
    if (pauVar89 == pauVar84) goto LAB_14002e39b;
    lVar98 = (longlong)pauVar89 * 0x20 + lVar80;
    uStack_10460 = (undefined1 (*) [16])
                   CONCAT17(bStack_10517,
                            CONCAT16(bStack_10518,
                                     CONCAT15(bStack_10519,CONCAT14(bStack_1051a,uStack_1049c))));
    if (pauVar123 < pauVar92) {
      pauVar92 = pauVar123;
    }
    uStack_104b8 = (undefined1 (*) [16])
                   CONCAT17(bStack_1051f,
                            CONCAT16(bStack_10520,
                                     CONCAT15(bStack_10521,
                                              CONCAT14(bStack_10522,
                                                       CONCAT13(bStack_10523,
                                                                CONCAT12(bStack_10524,uStack_104a4))
                                                      ))));
    lVar128 = 0;
    pauVar104 = (undefined1 (*) [16])0x0;
    goto LAB_1400310a2;
  }
  if (*(longlong *)*uStack_104b0 != 0x31524545502d5252) {
    if (*(longlong *)*uStack_104b0 == 0x324b4f4f4c2d5252) {
      LOCK();
      bVar129 = DAT_140699948 == '\0';
      if (bVar129) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar77 = 0;
        bVar76 = bStack_10528;
        bVar75 = bStack_10527;
        bVar73 = bStack_10526;
        bVar54 = bStack_10525;
        bVar55 = bStack_10524;
        bVar132 = bStack_10523;
        bVar56 = bStack_10522;
        bVar57 = bStack_10521;
        bVar58 = bStack_10520;
        bVar59 = bStack_1051f;
        bVar60 = bStack_1051e;
        bVar61 = bStack_1051d;
        bVar62 = bStack_1051c;
        bVar63 = bStack_1051b;
        bVar64 = bStack_1051a;
        bVar65 = bStack_10519;
        bVar66 = bStack_10518;
        bVar67 = bStack_10517;
      }
      else {
        bVar77 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar77 = bVar77 ^ 1;
        bVar76 = bStack_10528;
        bVar75 = bStack_10527;
        bVar73 = bStack_10526;
        bVar54 = bStack_10525;
        bVar55 = bStack_10524;
        bVar132 = bStack_10523;
        bVar56 = bStack_10522;
        bVar57 = bStack_10521;
        bVar58 = bStack_10520;
        bVar59 = bStack_1051f;
        bVar60 = bStack_1051e;
        bVar61 = bStack_1051d;
        bVar62 = bStack_1051c;
        bVar63 = bStack_1051b;
        bVar64 = bStack_1051a;
        bVar65 = bStack_10519;
        bVar66 = bStack_10518;
        bVar67 = bStack_10517;
      }
      if (DAT_140699949 != '\0') {
        bStack_10528 = 0x48;
        bStack_10527 = 0x99;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar77;
        bStack_1051f = bVar59;
        bStack_1051e = bVar60;
        bStack_1051d = bVar61;
        bStack_1051c = bVar62;
        bStack_1051b = bVar63;
        bStack_1051a = bVar64;
        bStack_10519 = bVar65;
        bStack_10518 = bVar66;
        bStack_10517 = bVar67;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2d20)
        ;
        goto LAB_140036cf0;
      }
      auVar133 = *DAT_140699950;
      pauVar82 = DAT_140699950 + 1;
      uVar113 = ~(uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
      sVar116 = CONCAT11(bStack_104a7,bStack_104a8);
      bStack_10522 = (byte)uStack_104a0;
      bStack_10521 = (byte)(uStack_104a0 >> 8);
      bStack_1051a = (byte)uStack_10498;
      bStack_10519 = (byte)(uStack_10498 >> 8);
      bStack_10518 = (byte)uStack_10496;
      bStack_10517 = (byte)(uStack_10496 >> 8);
      bStack_10524 = (byte)uStack_104a2;
      bStack_10523 = (byte)(uStack_104a2 >> 8);
      bStack_10520 = (byte)uStack_1049e;
      bStack_1051f = (byte)(uStack_1049e >> 8);
      bStack_1051e = (byte)uStack_1049c;
      bStack_1051d = (byte)(uStack_1049c >> 8);
      bStack_1051c = (byte)(uStack_1049c >> 0x10);
      bStack_1051b = (byte)(uStack_1049c >> 0x18);
      bStack_10528 = (byte)uStack_104a6;
      bStack_10527 = (byte)(uStack_104a6 >> 8);
      bStack_10526 = (byte)uStack_104a4;
      bStack_10525 = (byte)(uStack_104a4 >> 8);
      if ((bStack_104a8 & 1) == 0) {
        pauVar79 = DAT_140699950;
        lVar80 = DAT_140699968;
        if ((bStack_10471 & 1) == 0) {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if ((((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                 (*(ushort *)(pauVar79[uVar117 * -5 + -4] + 0xe) == uStack_104a2)) &&
                (*(int *)(pauVar79[uVar117 * -5 + -4] + 10) ==
                 CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)))) &&
               (pauVar79[uVar117 * -5 + -2][8] != '\x01')) goto LAB_14002ff09;
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
        else {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if (((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                (*(ushort *)(pauVar79[uVar117 * -5 + -4] + 0xe) == uStack_104a2)) &&
               ((*(int *)(pauVar79[uVar117 * -5 + -4] + 10) ==
                 CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)) &&
                ((pauVar79[uVar117 * -5 + -2][8] == '\x01' &&
                 (*(longlong *)(pauVar79[uVar117 * -5 + -1] + 1) ==
                  CONCAT17(bStack_10461,uStack_10468) &&
                  *(ulonglong *)(pauVar79[uVar117 * -5 + -2] + 9) ==
                  CONCAT17(bStack_10469,uStack_10470))))))) goto LAB_14002ff09;
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
      }
      else {
        uStack_10490._4_2_ = (ushort)(uStack_10490 >> 0x20);
        pauVar79 = DAT_140699950;
        lVar80 = DAT_140699968;
        if ((bStack_10471 & 1) == 0) {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if ((((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                 (*(short *)(pauVar79[uVar117 * -5 + -2] + 4) == uStack_10490._4_2_)) &&
                (*(uint *)(pauVar79[uVar117 * -5 + -3] + 0xc) == uStack_10494)) &&
               (*(int *)pauVar79[uVar117 * -5 + -2] == (int)uStack_10490)) {
              auVar133 = *(undefined1 (*) [16])(pauVar79[uVar117 * -5 + -4] + 0xc);
              auVar152[0] = -(bStack_10526 == auVar133[0]);
              auVar152[1] = -(bStack_10525 == auVar133[1]);
              auVar152[2] = -(bStack_10524 == auVar133[2]);
              auVar152[3] = -(bStack_10523 == auVar133[3]);
              auVar152[4] = -(bStack_10522 == auVar133[4]);
              auVar152[5] = -(bStack_10521 == auVar133[5]);
              auVar152[6] = -(bStack_10520 == auVar133[6]);
              auVar152[7] = -(bStack_1051f == auVar133[7]);
              auVar152[8] = -(bStack_1051e == auVar133[8]);
              auVar152[9] = -(bStack_1051d == auVar133[9]);
              auVar152[10] = -(bStack_1051c == auVar133[10]);
              auVar152[0xb] = -(bStack_1051b == auVar133[0xb]);
              auVar152[0xc] = -(bStack_1051a == auVar133[0xc]);
              auVar152[0xd] = -(bStack_10519 == auVar133[0xd]);
              auVar152[0xe] = -(bStack_10518 == auVar133[0xe]);
              auVar152[0xf] = -(bStack_10517 == auVar133[0xf]);
              if (((ushort)((ushort)(SUB161(auVar152 >> 7,0) & 1) |
                            (ushort)(SUB161(auVar152 >> 0xf,0) & 1) << 1 |
                            (ushort)(SUB161(auVar152 >> 0x17,0) & 1) << 2 |
                            (ushort)(SUB161(auVar152 >> 0x1f,0) & 1) << 3 |
                            (ushort)(SUB161(auVar152 >> 0x27,0) & 1) << 4 |
                            (ushort)(SUB161(auVar152 >> 0x2f,0) & 1) << 5 |
                            (ushort)(SUB161(auVar152 >> 0x37,0) & 1) << 6 |
                            (ushort)(SUB161(auVar152 >> 0x3f,0) & 1) << 7 |
                            (ushort)(SUB161(auVar152 >> 0x47,0) & 1) << 8 |
                            (ushort)(SUB161(auVar152 >> 0x4f,0) & 1) << 9 |
                            (ushort)(SUB161(auVar152 >> 0x57,0) & 1) << 10 |
                            (ushort)(SUB161(auVar152 >> 0x5f,0) & 1) << 0xb |
                            (ushort)(SUB161(auVar152 >> 0x67,0) & 1) << 0xc |
                            (ushort)(SUB161(auVar152 >> 0x6f,0) & 1) << 0xd |
                            (ushort)(SUB161(auVar152 >> 0x77,0) & 1) << 0xe |
                           (ushort)(auVar152[0xf] >> 7) << 0xf) == 0xffff) &&
                 (pauVar79[uVar117 * -5 + -2][8] != '\x01')) goto LAB_14002ff09;
            }
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
        else {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            unaff_R15 = (undefined1 (*) [16])(ulonglong)uStack_10496;
            if (((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                (*(short *)(pauVar79[uVar117 * -5 + -2] + 4) == uStack_10490._4_2_)) &&
               ((*(uint *)(pauVar79[uVar117 * -5 + -3] + 0xc) == uStack_10494 &&
                (*(int *)pauVar79[uVar117 * -5 + -2] == (int)uStack_10490)))) {
              auVar133 = *(undefined1 (*) [16])(pauVar79[uVar117 * -5 + -4] + 0xc);
              auVar146[0] = -(bStack_10526 == auVar133[0]);
              auVar146[1] = -(bStack_10525 == auVar133[1]);
              auVar146[2] = -(bStack_10524 == auVar133[2]);
              auVar146[3] = -(bStack_10523 == auVar133[3]);
              auVar146[4] = -(bStack_10522 == auVar133[4]);
              auVar146[5] = -(bStack_10521 == auVar133[5]);
              auVar146[6] = -(bStack_10520 == auVar133[6]);
              auVar146[7] = -(bStack_1051f == auVar133[7]);
              auVar146[8] = -(bStack_1051e == auVar133[8]);
              auVar146[9] = -(bStack_1051d == auVar133[9]);
              auVar146[10] = -(bStack_1051c == auVar133[10]);
              auVar146[0xb] = -(bStack_1051b == auVar133[0xb]);
              auVar146[0xc] = -(bStack_1051a == auVar133[0xc]);
              auVar146[0xd] = -(bStack_10519 == auVar133[0xd]);
              auVar146[0xe] = -(bStack_10518 == auVar133[0xe]);
              auVar146[0xf] = -(bStack_10517 == auVar133[0xf]);
              uVar112 = (ushort)(SUB161(auVar146 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar146 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar146 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar146 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar146 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar146 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar146 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar146 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar146 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar146 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar146 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar146 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar146 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar146 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar146 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar146[0xf] >> 7) << 0xf;
              unaff_R15 = (undefined1 (*) [16])(ulonglong)uVar112;
              if (((uVar112 == 0xffff) && (pauVar79[uVar117 * -5 + -2][8] == '\x01')) &&
                 (unaff_R15 = (undefined1 (*) [16])
                              (*(ulonglong *)(pauVar79[uVar117 * -5 + -2] + 9) ^
                              CONCAT17(bStack_10469,uStack_10470)),
                 *(longlong *)(pauVar79[uVar117 * -5 + -1] + 1) ==
                 CONCAT17(bStack_10461,uStack_10468) && unaff_R15 == (undefined1 (*) [16])0x0))
              goto LAB_14002ff09;
            }
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
      }
      bStack_10517 = bVar67;
      bStack_10518 = bVar66;
      bStack_10519 = bVar65;
      bStack_1051a = bVar64;
      bStack_1051b = bVar63;
      bStack_1051c = bVar62;
      bStack_1051d = bVar61;
      bStack_1051e = bVar60;
      bStack_1051f = bVar59;
      bStack_10520 = bVar58;
      bStack_10521 = bVar57;
      bStack_10522 = bVar56;
      bStack_10523 = bVar132;
      bStack_10524 = bVar55;
      bStack_10525 = bVar54;
      bStack_10526 = bVar73;
      bStack_10527 = bVar75;
      bStack_10528 = bVar76;
      if ((bVar77 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
LAB_140033f7f:
        if (cVar74 == '\0') {
          DAT_140699949 = '\x01';
        }
      }
    }
    else if (*(longlong *)*uStack_104b0 == 0x334b4f4f4c2d5252) {
      LOCK();
      bVar129 = DAT_140699948 == '\0';
      if (bVar129) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar77 = 0;
        bVar76 = bStack_10528;
        bVar75 = bStack_10527;
        bVar73 = bStack_10526;
        bVar54 = bStack_10525;
        bVar55 = bStack_10524;
        bVar132 = bStack_10523;
        bVar56 = bStack_10522;
        bVar57 = bStack_10521;
        bVar58 = bStack_10520;
        bVar59 = bStack_1051f;
        bVar60 = bStack_1051e;
        bVar61 = bStack_1051d;
        bVar62 = bStack_1051c;
        bVar63 = bStack_1051b;
        bVar64 = bStack_1051a;
        bVar65 = bStack_10519;
        bVar66 = bStack_10518;
        bVar67 = bStack_10517;
      }
      else {
        bVar77 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar77 = bVar77 ^ 1;
        bVar76 = bStack_10528;
        bVar75 = bStack_10527;
        bVar73 = bStack_10526;
        bVar54 = bStack_10525;
        bVar55 = bStack_10524;
        bVar132 = bStack_10523;
        bVar56 = bStack_10522;
        bVar57 = bStack_10521;
        bVar58 = bStack_10520;
        bVar59 = bStack_1051f;
        bVar60 = bStack_1051e;
        bVar61 = bStack_1051d;
        bVar62 = bStack_1051c;
        bVar63 = bStack_1051b;
        bVar64 = bStack_1051a;
        bVar65 = bStack_10519;
        bVar66 = bStack_10518;
        bVar67 = bStack_10517;
      }
      if (DAT_140699949 != '\0') {
        bStack_10528 = 0x48;
        bStack_10527 = 0x99;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar77;
        bStack_1051f = bVar59;
        bStack_1051e = bVar60;
        bStack_1051d = bVar61;
        bStack_1051c = bVar62;
        bStack_1051b = bVar63;
        bStack_1051a = bVar64;
        bStack_10519 = bVar65;
        bStack_10518 = bVar66;
        bStack_10517 = bVar67;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2d08)
        ;
        goto LAB_140036cf0;
      }
      auVar133 = *DAT_140699950;
      pauVar82 = DAT_140699950 + 1;
      uVar113 = ~(uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
      sVar116 = CONCAT11(bStack_104a7,bStack_104a8);
      bStack_10522 = (byte)uStack_104a0;
      bStack_10521 = (byte)(uStack_104a0 >> 8);
      bStack_1051a = (byte)uStack_10498;
      bStack_10519 = (byte)(uStack_10498 >> 8);
      bStack_10518 = (byte)uStack_10496;
      bStack_10517 = (byte)(uStack_10496 >> 8);
      bStack_10524 = (byte)uStack_104a2;
      bStack_10523 = (byte)(uStack_104a2 >> 8);
      bStack_10520 = (byte)uStack_1049e;
      bStack_1051f = (byte)(uStack_1049e >> 8);
      bStack_1051e = (byte)uStack_1049c;
      bStack_1051d = (byte)(uStack_1049c >> 8);
      bStack_1051c = (byte)(uStack_1049c >> 0x10);
      bStack_1051b = (byte)(uStack_1049c >> 0x18);
      bStack_10528 = (byte)uStack_104a6;
      bStack_10527 = (byte)(uStack_104a6 >> 8);
      bStack_10526 = (byte)uStack_104a4;
      bStack_10525 = (byte)(uStack_104a4 >> 8);
      if ((bStack_104a8 & 1) == 0) {
        pauVar79 = DAT_140699950;
        lVar80 = DAT_140699968;
        if ((bStack_10471 & 1) == 0) {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if ((((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                 (*(ushort *)(pauVar79[uVar117 * -5 + -4] + 0xe) == uStack_104a2)) &&
                (*(int *)(pauVar79[uVar117 * -5 + -4] + 10) ==
                 CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)))) &&
               (pauVar79[uVar117 * -5 + -2][8] != '\x01')) goto LAB_1400300f5;
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
        else {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if (((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                (*(ushort *)(pauVar79[uVar117 * -5 + -4] + 0xe) == uStack_104a2)) &&
               ((*(int *)(pauVar79[uVar117 * -5 + -4] + 10) ==
                 CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)) &&
                ((pauVar79[uVar117 * -5 + -2][8] == '\x01' &&
                 (*(longlong *)(pauVar79[uVar117 * -5 + -1] + 1) ==
                  CONCAT17(bStack_10461,uStack_10468) &&
                  *(ulonglong *)(pauVar79[uVar117 * -5 + -2] + 9) ==
                  CONCAT17(bStack_10469,uStack_10470))))))) goto LAB_1400300f5;
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
      }
      else {
        uStack_10490._4_2_ = (ushort)(uStack_10490 >> 0x20);
        pauVar79 = DAT_140699950;
        lVar80 = DAT_140699968;
        if ((bStack_10471 & 1) == 0) {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if ((((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                 (*(short *)(pauVar79[uVar117 * -5 + -2] + 4) == uStack_10490._4_2_)) &&
                (*(uint *)(pauVar79[uVar117 * -5 + -3] + 0xc) == uStack_10494)) &&
               (*(int *)pauVar79[uVar117 * -5 + -2] == (int)uStack_10490)) {
              auVar133 = *(undefined1 (*) [16])(pauVar79[uVar117 * -5 + -4] + 0xc);
              auVar153[0] = -(bStack_10526 == auVar133[0]);
              auVar153[1] = -(bStack_10525 == auVar133[1]);
              auVar153[2] = -(bStack_10524 == auVar133[2]);
              auVar153[3] = -(bStack_10523 == auVar133[3]);
              auVar153[4] = -(bStack_10522 == auVar133[4]);
              auVar153[5] = -(bStack_10521 == auVar133[5]);
              auVar153[6] = -(bStack_10520 == auVar133[6]);
              auVar153[7] = -(bStack_1051f == auVar133[7]);
              auVar153[8] = -(bStack_1051e == auVar133[8]);
              auVar153[9] = -(bStack_1051d == auVar133[9]);
              auVar153[10] = -(bStack_1051c == auVar133[10]);
              auVar153[0xb] = -(bStack_1051b == auVar133[0xb]);
              auVar153[0xc] = -(bStack_1051a == auVar133[0xc]);
              auVar153[0xd] = -(bStack_10519 == auVar133[0xd]);
              auVar153[0xe] = -(bStack_10518 == auVar133[0xe]);
              auVar153[0xf] = -(bStack_10517 == auVar133[0xf]);
              if (((ushort)((ushort)(SUB161(auVar153 >> 7,0) & 1) |
                            (ushort)(SUB161(auVar153 >> 0xf,0) & 1) << 1 |
                            (ushort)(SUB161(auVar153 >> 0x17,0) & 1) << 2 |
                            (ushort)(SUB161(auVar153 >> 0x1f,0) & 1) << 3 |
                            (ushort)(SUB161(auVar153 >> 0x27,0) & 1) << 4 |
                            (ushort)(SUB161(auVar153 >> 0x2f,0) & 1) << 5 |
                            (ushort)(SUB161(auVar153 >> 0x37,0) & 1) << 6 |
                            (ushort)(SUB161(auVar153 >> 0x3f,0) & 1) << 7 |
                            (ushort)(SUB161(auVar153 >> 0x47,0) & 1) << 8 |
                            (ushort)(SUB161(auVar153 >> 0x4f,0) & 1) << 9 |
                            (ushort)(SUB161(auVar153 >> 0x57,0) & 1) << 10 |
                            (ushort)(SUB161(auVar153 >> 0x5f,0) & 1) << 0xb |
                            (ushort)(SUB161(auVar153 >> 0x67,0) & 1) << 0xc |
                            (ushort)(SUB161(auVar153 >> 0x6f,0) & 1) << 0xd |
                            (ushort)(SUB161(auVar153 >> 0x77,0) & 1) << 0xe |
                           (ushort)(auVar153[0xf] >> 7) << 0xf) == 0xffff) &&
                 (pauVar79[uVar117 * -5 + -2][8] != '\x01')) goto LAB_1400300f5;
            }
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
        else {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            unaff_R15 = (undefined1 (*) [16])(ulonglong)uStack_10496;
            if (((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                (*(short *)(pauVar79[uVar117 * -5 + -2] + 4) == uStack_10490._4_2_)) &&
               ((*(uint *)(pauVar79[uVar117 * -5 + -3] + 0xc) == uStack_10494 &&
                (*(int *)pauVar79[uVar117 * -5 + -2] == (int)uStack_10490)))) {
              auVar133 = *(undefined1 (*) [16])(pauVar79[uVar117 * -5 + -4] + 0xc);
              auVar147[0] = -(bStack_10526 == auVar133[0]);
              auVar147[1] = -(bStack_10525 == auVar133[1]);
              auVar147[2] = -(bStack_10524 == auVar133[2]);
              auVar147[3] = -(bStack_10523 == auVar133[3]);
              auVar147[4] = -(bStack_10522 == auVar133[4]);
              auVar147[5] = -(bStack_10521 == auVar133[5]);
              auVar147[6] = -(bStack_10520 == auVar133[6]);
              auVar147[7] = -(bStack_1051f == auVar133[7]);
              auVar147[8] = -(bStack_1051e == auVar133[8]);
              auVar147[9] = -(bStack_1051d == auVar133[9]);
              auVar147[10] = -(bStack_1051c == auVar133[10]);
              auVar147[0xb] = -(bStack_1051b == auVar133[0xb]);
              auVar147[0xc] = -(bStack_1051a == auVar133[0xc]);
              auVar147[0xd] = -(bStack_10519 == auVar133[0xd]);
              auVar147[0xe] = -(bStack_10518 == auVar133[0xe]);
              auVar147[0xf] = -(bStack_10517 == auVar133[0xf]);
              uVar112 = (ushort)(SUB161(auVar147 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar147 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar147 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar147 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar147 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar147 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar147 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar147 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar147 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar147 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar147 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar147 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar147 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar147 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar147 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar147[0xf] >> 7) << 0xf;
              unaff_R15 = (undefined1 (*) [16])(ulonglong)uVar112;
              if (((uVar112 == 0xffff) && (pauVar79[uVar117 * -5 + -2][8] == '\x01')) &&
                 (unaff_R15 = (undefined1 (*) [16])
                              (*(ulonglong *)(pauVar79[uVar117 * -5 + -2] + 9) ^
                              CONCAT17(bStack_10469,uStack_10470)),
                 *(longlong *)(pauVar79[uVar117 * -5 + -1] + 1) ==
                 CONCAT17(bStack_10461,uStack_10468) && unaff_R15 == (undefined1 (*) [16])0x0))
              goto LAB_1400300f5;
            }
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
      }
      bStack_10517 = bVar67;
      bStack_10518 = bVar66;
      bStack_10519 = bVar65;
      bStack_1051a = bVar64;
      bStack_1051b = bVar63;
      bStack_1051c = bVar62;
      bStack_1051d = bVar61;
      bStack_1051e = bVar60;
      bStack_1051f = bVar59;
      bStack_10520 = bVar58;
      bStack_10521 = bVar57;
      bStack_10522 = bVar56;
      bStack_10523 = bVar132;
      bStack_10524 = bVar55;
      bStack_10525 = bVar54;
      bStack_10526 = bVar73;
      bStack_10527 = bVar75;
      bStack_10528 = bVar76;
      if ((bVar77 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        goto LAB_140033f7f;
      }
    }
    else {
      if (*(longlong *)*uStack_104b0 != 0x314c424d452d5252) {
        if (*(longlong *)*uStack_104b0 == 0x31594c52452d5252) {
          LOCK();
          bVar129 = DAT_140699948 == '\0';
          if (bVar129) {
            DAT_140699948 = '\x01';
          }
          UNLOCK();
          if (!bVar129) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
          }
          if ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) == 0) {
            bVar76 = 0;
          }
          else {
            bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar76 = bVar76 ^ 1;
          }
          if (DAT_140699949 != '\0') {
            bStack_10528 = 0x48;
            bStack_10527 = 0x99;
            bStack_10526 = 0x69;
            bStack_10525 = 0x40;
            bStack_10524 = 1;
            bStack_10523 = 0;
            bStack_10522 = 0;
            bStack_10521 = 0;
            bStack_10520 = bVar76;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                       &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                       &
                       PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2ca0
                      );
            goto LAB_140036cf0;
          }
          cVar72 = is_host_route(&DAT_140699950,
                                 HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                                 IS_HOST_0_llvm_14435704873730135342 == '\0',
                                 HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,bStack_10471,
                                 CONCAT17(bStack_10469,uStack_10470),
                                 CONCAT17(bStack_10461,uStack_10468));
          if (cVar72 != '\0') {
            if ((bVar76 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                DAT_140699949 = '\x01';
              }
            }
            cVar72 = DAT_140699948;
            LOCK();
            DAT_140699948 = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            }
            std[3bf9d48a0c3997f0]::sys::fs::metadata(&bStack_10528,"host-ended-early",0x10);
            if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) ==
                2) {
              uVar29 = CONCAT12(bStack_1051e,CONCAT11(bStack_1051f,bStack_10520));
              if ((1 < (uVar29 & 3) - 2) && ((bStack_10520 & 3) != 0)) {
                lVar80 = CONCAT17(bStack_10519,
                                  CONCAT16(bStack_1051a,
                                           CONCAT15(bStack_1051b,
                                                    CONCAT14(bStack_1051c,
                                                             CONCAT13(bStack_1051d,uVar29))))) + -1;
                bStack_10520 = (byte)lVar80;
                bStack_1051f = (byte)((ulonglong)lVar80 >> 8);
                bStack_1051e = (byte)((ulonglong)lVar80 >> 0x10);
                bStack_1051d = (byte)((ulonglong)lVar80 >> 0x18);
                bStack_1051c = (byte)((ulonglong)lVar80 >> 0x20);
                bStack_1051b = (byte)((ulonglong)lVar80 >> 0x28);
                bStack_1051a = (byte)((ulonglong)lVar80 >> 0x30);
                bStack_10519 = (byte)((ulonglong)lVar80 >> 0x38);
                bStack_10528 = 3;
                <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                ::drop(&bStack_10520);
              }
              host::log("net: the host is ending the game early",0x26);
              uVar117 = std[3bf9d48a0c3997f0]::fs::write::inner("host-ended-early",0x10,1,0);
              if (((uVar117 != 0) && (1 < ((uint)uVar117 & 3) - 2)) && ((uVar117 & 3) != 0)) {
                lVar80 = uVar117 - 1;
                bStack_10520 = (byte)lVar80;
                bStack_1051f = (byte)((ulonglong)lVar80 >> 8);
                bStack_1051e = (byte)((ulonglong)lVar80 >> 0x10);
                bStack_1051d = (byte)((ulonglong)lVar80 >> 0x18);
                bStack_1051c = (byte)((ulonglong)lVar80 >> 0x20);
                bStack_1051b = (byte)((ulonglong)lVar80 >> 0x28);
                bStack_1051a = (byte)((ulonglong)lVar80 >> 0x30);
                bStack_10519 = (byte)((ulonglong)lVar80 >> 0x38);
                bStack_10528 = 3;
                <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                ::drop(&bStack_10520);
              }
            }
            goto LAB_1400331d8;
          }
        }
        else if (*(longlong *)*uStack_104b0 == 0x3130444e452d5252) {
          LOCK();
          bVar129 = DAT_140699948 == '\0';
          if (bVar129) {
            DAT_140699948 = '\x01';
          }
          UNLOCK();
          if (!bVar129) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
          }
          if ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) == 0) {
            bVar76 = 0;
          }
          else {
            bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar76 = bVar76 ^ 1;
          }
          if (DAT_140699949 != '\0') {
            bStack_10528 = 0x48;
            bStack_10527 = 0x99;
            bStack_10526 = 0x69;
            bStack_10525 = 0x40;
            bStack_10524 = 1;
            bStack_10523 = 0;
            bStack_10522 = 0;
            bStack_10521 = 0;
            bStack_10520 = bVar76;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                       &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                       &
                       PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2bf8
                      );
            goto LAB_140036cf0;
          }
          cVar72 = is_host_route(&DAT_140699950,
                                 HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                                 IS_HOST_0_llvm_14435704873730135342 == '\0',
                                 HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,bStack_10471,
                                 CONCAT17(bStack_10469,uStack_10470),
                                 CONCAT17(bStack_10461,uStack_10468));
          if (cVar72 != '\0') {
            if ((bVar76 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                DAT_140699949 = '\x01';
              }
            }
            cVar72 = DAT_140699948;
            LOCK();
            DAT_140699948 = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            }
            cVar72 = GAME_ENDED;
            LOCK();
            GAME_ENDED = '\x01';
            UNLOCK();
            if (cVar72 == '\0') {
              uVar85 = 0x3b;
              if ((pauStack_10538 == (undefined1 (*) [16])&DAT_00000008) ||
                 ((*uStack_104b0)[8] != '\x01')) {
                bVar76 = 0;
                pcVar109 = "net: the host\'s game is over and it left; back to the menus";
              }
              else {
                bVar76 = 1;
                uVar85 = 0x2e;
                pcVar109 = "net: the host left the game; back to the menus";
              }
              host::log(pcVar109,uVar85);
              lVar80 = 0xe - (ulonglong)bVar76;
              bVar129 = bVar76 != 0;
              pcVar109 = "host-game-over";
              if (bVar129) {
                pcVar109 = "host-left.txt";
              }
              pcVar115 = (char *)0x1;
              if (bVar129) {
                pcVar115 = "the host left the game";
              }
              uVar85 = 0;
              if (bVar129) {
                uVar85 = 0x16;
              }
LAB_140030f9c:
              uVar117 = std[3bf9d48a0c3997f0]::fs::write::inner(pcVar109,lVar80,pcVar115,uVar85);
              if (((uVar117 != 0) && (1 < ((uint)uVar117 & 3) - 2)) && ((uVar117 & 3) != 0)) {
                lVar80 = uVar117 - 1;
                bStack_10520 = (byte)lVar80;
                bStack_1051f = (byte)((ulonglong)lVar80 >> 8);
                bStack_1051e = (byte)((ulonglong)lVar80 >> 0x10);
                bStack_1051d = (byte)((ulonglong)lVar80 >> 0x18);
                bStack_1051c = (byte)((ulonglong)lVar80 >> 0x20);
                bStack_1051b = (byte)((ulonglong)lVar80 >> 0x28);
                bStack_1051a = (byte)((ulonglong)lVar80 >> 0x30);
                bStack_10519 = (byte)((ulonglong)lVar80 >> 0x38);
                bStack_10528 = 3;
                <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>
                ::drop(&bStack_10520);
              }
              win::LEAVE_REQUESTED = 1;
            }
            goto LAB_1400331d8;
          }
        }
        else if (*(longlong *)*uStack_104b0 == 0x314b43494b2d5252) {
          if ((pauStack_10538 < (undefined1 (*) [16])&DAT_00000010) ||
             (*(undefined1 (**) [16])(*uStack_104b0 + 8) != DAT_1406998e0)) goto LAB_1400331d8;
          LOCK();
          bVar129 = DAT_140699948 == '\0';
          if (bVar129) {
            DAT_140699948 = '\x01';
          }
          UNLOCK();
          if (!bVar129) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
          }
          if ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) == 0) {
            bVar76 = 0;
          }
          else {
            bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar76 = bVar76 ^ 1;
          }
          if (DAT_140699949 != '\0') {
            bStack_10528 = 0x48;
            bStack_10527 = 0x99;
            bStack_10526 = 0x69;
            bStack_10525 = 0x40;
            bStack_10524 = 1;
            bStack_10523 = 0;
            bStack_10522 = 0;
            bStack_10521 = 0;
            bStack_10520 = bVar76;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                       &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                       &
                       PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2b98
                      );
            goto LAB_140036cf0;
          }
          cVar72 = is_host_route(&DAT_140699950,
                                 HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                                 IS_HOST_0_llvm_14435704873730135342 == '\0',
                                 HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,bStack_10471,
                                 CONCAT17(bStack_10469,uStack_10470),
                                 CONCAT17(bStack_10461,uStack_10468));
          if (cVar72 != '\0') {
            if ((bVar76 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                DAT_140699949 = '\x01';
              }
            }
            cVar72 = DAT_140699948;
            LOCK();
            DAT_140699948 = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            }
            if (pauStack_10538 == (undefined1 (*) [16])&DAT_00000010) {
              pcVar115 = &DAT_1406a2bb0;
            }
            else {
              pcVar115 = &DAT_1406a2bb0;
              if (uStack_104b0[1][0] == '\x01') {
                pcVar115 = &DAT_1406a2bb6;
              }
            }
            uStack_103a8 = (ushort)pcVar115;
            uStack_103a6 = (ushort)((ulonglong)pcVar115 >> 0x10);
            uStack_103a4 = (ushort)((ulonglong)pcVar115 >> 0x20);
            uStack_103a2 = 0;
            uStack_103a0 = 6;
            uStack_1039e = 0;
            uStack_1039c = 0;
            uStack_10438._0_1_ = (byte)&uStack_103a8;
            uStack_10438._1_1_ = (byte)((ulonglong)&uStack_103a8 >> 8);
            uStack_10438._2_1_ = (byte)((ulonglong)&uStack_103a8 >> 0x10);
            uStack_10438._3_1_ = (byte)((ulonglong)&uStack_103a8 >> 0x18);
            uStack_10438._4_4_ = (int)((ulonglong)&uStack_103a8 >> 0x20);
            bStack_10430 = 0xd0;
            bStack_1042f = 0x28;
            uStack_1042e = 0x4024;
            uStack_1042c = 1;
            alloc[246c2e7857c81348]::fmt::format::format_inner
                      (&bStack_10528,&DAT_1406a2bbc,&uStack_10438);
            lVar120 = CONCAT17(bStack_10521,
                               CONCAT16(bStack_10522,
                                        CONCAT15(bStack_10523,
                                                 CONCAT14(bStack_10524,
                                                          CONCAT13(bStack_10525,
                                                                   CONCAT12(bStack_10526,
                                                                            CONCAT11(bStack_10527,
                                                                                     bStack_10528)))
                                                         ))));
            uVar4 = CONCAT17(bStack_10519,
                             CONCAT16(bStack_1051a,
                                      CONCAT15(bStack_1051b,
                                               CONCAT14(bStack_1051c,
                                                        CONCAT13(bStack_1051d,
                                                                 CONCAT12(bStack_1051e,
                                                                          CONCAT11(bStack_1051f,
                                                                                   bStack_10520)))))
                                     ));
            host::log(uVar4,CONCAT44(uStack_10514,
                                     CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518))));
            uVar85 = 6;
            lVar80 = 10;
            if (lVar120 != 0) {
              pauVar82 = (undefined1 (*) [16])
                         __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar4,lVar120,1);
              return pauVar82;
            }
            pcVar109 = "kicked.txt";
            goto LAB_140030f9c;
          }
        }
        else if (*(longlong *)*uStack_104b0 == 0x31454c55522d5252) {
          LOCK();
          bVar129 = DAT_140699948 == '\0';
          if (bVar129) {
            DAT_140699948 = '\x01';
          }
          UNLOCK();
          if (!bVar129) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
          }
          if ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) == 0) {
            bVar76 = 0;
          }
          else {
            bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar76 = bVar76 ^ 1;
          }
          if (DAT_140699949 != '\0') {
            bStack_10528 = 0x48;
            bStack_10527 = 0x99;
            bStack_10526 = 0x69;
            bStack_10525 = 0x40;
            bStack_10524 = 1;
            bStack_10523 = 0;
            bStack_10522 = 0;
            bStack_10521 = 0;
            bStack_10520 = bVar76;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                       &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                       &
                       PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2b80
                      );
            goto LAB_140036cf0;
          }
          cVar72 = is_host_route(&DAT_140699950,
                                 HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                                 IS_HOST_0_llvm_14435704873730135342 == '\0',
                                 HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,bStack_10471,
                                 CONCAT17(bStack_10469,uStack_10470),
                                 CONCAT17(bStack_10461,uStack_10468));
          if (cVar72 != '\0') {
            if ((bVar76 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                DAT_140699949 = '\x01';
              }
            }
            cVar72 = DAT_140699948;
            LOCK();
            DAT_140699948 = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            }
            matchrules::received(*uStack_104b0 + 8,pauStack_10538[-1] + 8);
            goto LAB_1400331d8;
          }
        }
        else if (*(longlong *)*uStack_104b0 == 0x31524f43532d5252) {
          LOCK();
          bVar129 = DAT_140699948 == '\0';
          if (bVar129) {
            DAT_140699948 = '\x01';
          }
          UNLOCK();
          if (!bVar129) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
          }
          if ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) == 0) {
            bVar76 = 0;
          }
          else {
            bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar76 = bVar76 ^ 1;
          }
          if (DAT_140699949 != '\0') {
            bStack_10528 = 0x48;
            bStack_10527 = 0x99;
            bStack_10526 = 0x69;
            bStack_10525 = 0x40;
            bStack_10524 = 1;
            bStack_10523 = 0;
            bStack_10522 = 0;
            bStack_10521 = 0;
            bStack_10520 = bVar76;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                       &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                       &
                       PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2b68
                      );
            goto LAB_140036cf0;
          }
          cVar72 = is_host_route(&DAT_140699950,
                                 HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                                 IS_HOST_0_llvm_14435704873730135342 == '\0',
                                 HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,bStack_10471,
                                 CONCAT17(bStack_10469,uStack_10470),
                                 CONCAT17(bStack_10461,uStack_10468));
          if (cVar72 != '\0') {
            if ((bVar76 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                DAT_140699949 = '\x01';
              }
            }
            cVar72 = DAT_140699948;
            LOCK();
            DAT_140699948 = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            }
            scorex::received(*uStack_104b0 + 8,pauStack_10538[-1] + 8);
            goto LAB_1400331d8;
          }
        }
        else {
          if (*(longlong *)*uStack_104b0 != 0x31435346462d5252) {
            bVar129 = false;
            goto LAB_14002c76e;
          }
          LOCK();
          bVar129 = DAT_140699948 == '\0';
          if (bVar129) {
            DAT_140699948 = '\x01';
          }
          UNLOCK();
          if (!bVar129) {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
          }
          if ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) == 0) {
            bVar76 = 0;
          }
          else {
            bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            bVar76 = bVar76 ^ 1;
          }
          if (DAT_140699949 != '\0') {
            bStack_10528 = 0x48;
            bStack_10527 = 0x99;
            bStack_10526 = 0x69;
            bStack_10525 = 0x40;
            bStack_10524 = 1;
            bStack_10523 = 0;
            bStack_10522 = 0;
            bStack_10521 = 0;
            bStack_10520 = bVar76;
            core[505b25137b8ba7f]::result::unwrap_failed
                      ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                       &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                       &
                       PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2b50
                      );
            goto LAB_140036cf0;
          }
          cVar72 = is_host_route(&DAT_140699950,
                                 HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                                 IS_HOST_0_llvm_14435704873730135342 == '\0',
                                 HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,bStack_10471,
                                 CONCAT17(bStack_10469,uStack_10470),
                                 CONCAT17(bStack_10461,uStack_10468));
          if (cVar72 != '\0') {
            if ((bVar76 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                DAT_140699949 = '\x01';
              }
            }
            cVar72 = DAT_140699948;
            LOCK();
            DAT_140699948 = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            }
            coopx::ff_received(*uStack_104b0 + 8,pauStack_10538[-1] + 8);
            goto LAB_1400331d8;
          }
        }
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar72 == '\0') {
            DAT_140699949 = '\x01';
          }
        }
        cVar72 = DAT_140699948;
        LOCK();
        DAT_140699948 = '\0';
        UNLOCK();
        if (cVar72 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
        }
        goto LAB_1400331d8;
      }
      LOCK();
      bVar129 = DAT_140699948 == '\0';
      if (bVar129) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar77 = 0;
        bVar76 = bStack_10528;
        bVar75 = bStack_10527;
        bVar73 = bStack_10526;
        bVar54 = bStack_10525;
        bVar55 = bStack_10524;
        bVar132 = bStack_10523;
        bVar56 = bStack_10522;
        bVar57 = bStack_10521;
        bVar58 = bStack_10520;
        bVar59 = bStack_1051f;
        bVar60 = bStack_1051e;
        bVar61 = bStack_1051d;
        bVar62 = bStack_1051c;
        bVar63 = bStack_1051b;
        bVar64 = bStack_1051a;
        bVar65 = bStack_10519;
        bVar66 = bStack_10518;
        bVar67 = bStack_10517;
      }
      else {
        bVar77 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar77 = bVar77 ^ 1;
        bVar76 = bStack_10528;
        bVar75 = bStack_10527;
        bVar73 = bStack_10526;
        bVar54 = bStack_10525;
        bVar55 = bStack_10524;
        bVar132 = bStack_10523;
        bVar56 = bStack_10522;
        bVar57 = bStack_10521;
        bVar58 = bStack_10520;
        bVar59 = bStack_1051f;
        bVar60 = bStack_1051e;
        bVar61 = bStack_1051d;
        bVar62 = bStack_1051c;
        bVar63 = bStack_1051b;
        bVar64 = bStack_1051a;
        bVar65 = bStack_10519;
        bVar66 = bStack_10518;
        bVar67 = bStack_10517;
      }
      if (DAT_140699949 != '\0') {
        bStack_10528 = 0x48;
        bStack_10527 = 0x99;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar77;
        bStack_1051f = bVar59;
        bStack_1051e = bVar60;
        bStack_1051d = bVar61;
        bStack_1051c = bVar62;
        bStack_1051b = bVar63;
        bStack_1051a = bVar64;
        bStack_10519 = bVar65;
        bStack_10518 = bVar66;
        bStack_10517 = bVar67;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2cf0)
        ;
        goto LAB_140036cf0;
      }
      auVar133 = *DAT_140699950;
      pauVar82 = DAT_140699950 + 1;
      uVar113 = ~(uint)(ushort)((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                                (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                                (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                                (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                                (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                                (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                                (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                                (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                                (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                                (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                                (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                                (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                                (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                                (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                                (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                               (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
      sVar116 = CONCAT11(bStack_104a7,bStack_104a8);
      bStack_10522 = (byte)uStack_104a0;
      bStack_10521 = (byte)(uStack_104a0 >> 8);
      bStack_1051a = (byte)uStack_10498;
      bStack_10519 = (byte)(uStack_10498 >> 8);
      bStack_10518 = (byte)uStack_10496;
      bStack_10517 = (byte)(uStack_10496 >> 8);
      bStack_10524 = (byte)uStack_104a2;
      bStack_10523 = (byte)(uStack_104a2 >> 8);
      bStack_10520 = (byte)uStack_1049e;
      bStack_1051f = (byte)(uStack_1049e >> 8);
      bStack_1051e = (byte)uStack_1049c;
      bStack_1051d = (byte)(uStack_1049c >> 8);
      bStack_1051c = (byte)(uStack_1049c >> 0x10);
      bStack_1051b = (byte)(uStack_1049c >> 0x18);
      bStack_10528 = (byte)uStack_104a6;
      bStack_10527 = (byte)(uStack_104a6 >> 8);
      bStack_10526 = (byte)uStack_104a4;
      bStack_10525 = (byte)(uStack_104a4 >> 8);
      if ((bStack_104a8 & 1) == 0) {
        pauVar79 = DAT_140699950;
        lVar80 = DAT_140699968;
        if ((bStack_10471 & 1) == 0) {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if ((((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                 (*(ushort *)(pauVar79[uVar117 * -5 + -4] + 0xe) == uStack_104a2)) &&
                (*(int *)(pauVar79[uVar117 * -5 + -4] + 10) ==
                 CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)))) &&
               (pauVar79[uVar117 * -5 + -2][8] != '\x01')) goto LAB_1400302f9;
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
        else {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if (((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                (*(ushort *)(pauVar79[uVar117 * -5 + -4] + 0xe) == uStack_104a2)) &&
               ((*(int *)(pauVar79[uVar117 * -5 + -4] + 10) ==
                 CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)) &&
                ((pauVar79[uVar117 * -5 + -2][8] == '\x01' &&
                 (*(longlong *)(pauVar79[uVar117 * -5 + -1] + 1) ==
                  CONCAT17(bStack_10461,uStack_10468) &&
                  *(ulonglong *)(pauVar79[uVar117 * -5 + -2] + 9) ==
                  CONCAT17(bStack_10469,uStack_10470))))))) goto LAB_1400302f9;
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
      }
      else {
        uStack_10490._4_2_ = (ushort)(uStack_10490 >> 0x20);
        pauVar79 = DAT_140699950;
        lVar80 = DAT_140699968;
        if ((bStack_10471 & 1) == 0) {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            if ((((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                 (*(short *)(pauVar79[uVar117 * -5 + -2] + 4) == uStack_10490._4_2_)) &&
                (*(uint *)(pauVar79[uVar117 * -5 + -3] + 0xc) == uStack_10494)) &&
               (*(int *)pauVar79[uVar117 * -5 + -2] == (int)uStack_10490)) {
              auVar133 = *(undefined1 (*) [16])(pauVar79[uVar117 * -5 + -4] + 0xc);
              auVar154[0] = -(bStack_10526 == auVar133[0]);
              auVar154[1] = -(bStack_10525 == auVar133[1]);
              auVar154[2] = -(bStack_10524 == auVar133[2]);
              auVar154[3] = -(bStack_10523 == auVar133[3]);
              auVar154[4] = -(bStack_10522 == auVar133[4]);
              auVar154[5] = -(bStack_10521 == auVar133[5]);
              auVar154[6] = -(bStack_10520 == auVar133[6]);
              auVar154[7] = -(bStack_1051f == auVar133[7]);
              auVar154[8] = -(bStack_1051e == auVar133[8]);
              auVar154[9] = -(bStack_1051d == auVar133[9]);
              auVar154[10] = -(bStack_1051c == auVar133[10]);
              auVar154[0xb] = -(bStack_1051b == auVar133[0xb]);
              auVar154[0xc] = -(bStack_1051a == auVar133[0xc]);
              auVar154[0xd] = -(bStack_10519 == auVar133[0xd]);
              auVar154[0xe] = -(bStack_10518 == auVar133[0xe]);
              auVar154[0xf] = -(bStack_10517 == auVar133[0xf]);
              if (((ushort)((ushort)(SUB161(auVar154 >> 7,0) & 1) |
                            (ushort)(SUB161(auVar154 >> 0xf,0) & 1) << 1 |
                            (ushort)(SUB161(auVar154 >> 0x17,0) & 1) << 2 |
                            (ushort)(SUB161(auVar154 >> 0x1f,0) & 1) << 3 |
                            (ushort)(SUB161(auVar154 >> 0x27,0) & 1) << 4 |
                            (ushort)(SUB161(auVar154 >> 0x2f,0) & 1) << 5 |
                            (ushort)(SUB161(auVar154 >> 0x37,0) & 1) << 6 |
                            (ushort)(SUB161(auVar154 >> 0x3f,0) & 1) << 7 |
                            (ushort)(SUB161(auVar154 >> 0x47,0) & 1) << 8 |
                            (ushort)(SUB161(auVar154 >> 0x4f,0) & 1) << 9 |
                            (ushort)(SUB161(auVar154 >> 0x57,0) & 1) << 10 |
                            (ushort)(SUB161(auVar154 >> 0x5f,0) & 1) << 0xb |
                            (ushort)(SUB161(auVar154 >> 0x67,0) & 1) << 0xc |
                            (ushort)(SUB161(auVar154 >> 0x6f,0) & 1) << 0xd |
                            (ushort)(SUB161(auVar154 >> 0x77,0) & 1) << 0xe |
                           (ushort)(auVar154[0xf] >> 7) << 0xf) == 0xffff) &&
                 (pauVar79[uVar117 * -5 + -2][8] != '\x01')) goto LAB_1400302f9;
            }
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
        else {
          for (; lVar80 != 0; lVar80 = lVar80 + -1) {
            uVar112 = (ushort)uVar113;
            while (uVar112 == 0) {
              auVar133 = *pauVar82;
              pauVar79 = pauVar79 + -0x50;
              pauVar82 = pauVar82 + 1;
              uVar112 = ((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                        (ushort)(byte)(auVar133[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar113 = (uint)uVar112;
            }
            uVar114 = 0;
            for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
              uVar114 = uVar114 + 1;
            }
            uVar117 = (ulonglong)uVar114;
            unaff_R15 = (undefined1 (*) [16])(ulonglong)uStack_10496;
            if (((*(short *)(pauVar79[uVar117 * -5 + -4] + 8) == sVar116) &&
                (*(short *)(pauVar79[uVar117 * -5 + -2] + 4) == uStack_10490._4_2_)) &&
               ((*(uint *)(pauVar79[uVar117 * -5 + -3] + 0xc) == uStack_10494 &&
                (*(int *)pauVar79[uVar117 * -5 + -2] == (int)uStack_10490)))) {
              auVar133 = *(undefined1 (*) [16])(pauVar79[uVar117 * -5 + -4] + 0xc);
              auVar148[0] = -(bStack_10526 == auVar133[0]);
              auVar148[1] = -(bStack_10525 == auVar133[1]);
              auVar148[2] = -(bStack_10524 == auVar133[2]);
              auVar148[3] = -(bStack_10523 == auVar133[3]);
              auVar148[4] = -(bStack_10522 == auVar133[4]);
              auVar148[5] = -(bStack_10521 == auVar133[5]);
              auVar148[6] = -(bStack_10520 == auVar133[6]);
              auVar148[7] = -(bStack_1051f == auVar133[7]);
              auVar148[8] = -(bStack_1051e == auVar133[8]);
              auVar148[9] = -(bStack_1051d == auVar133[9]);
              auVar148[10] = -(bStack_1051c == auVar133[10]);
              auVar148[0xb] = -(bStack_1051b == auVar133[0xb]);
              auVar148[0xc] = -(bStack_1051a == auVar133[0xc]);
              auVar148[0xd] = -(bStack_10519 == auVar133[0xd]);
              auVar148[0xe] = -(bStack_10518 == auVar133[0xe]);
              auVar148[0xf] = -(bStack_10517 == auVar133[0xf]);
              uVar112 = (ushort)(SUB161(auVar148 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar148 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar148 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar148 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar148 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar148 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar148 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar148 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar148 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar148 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar148 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar148 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar148 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar148 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar148 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar148[0xf] >> 7) << 0xf;
              unaff_R15 = (undefined1 (*) [16])(ulonglong)uVar112;
              if (((uVar112 == 0xffff) && (pauVar79[uVar117 * -5 + -2][8] == '\x01')) &&
                 (unaff_R15 = (undefined1 (*) [16])
                              (*(ulonglong *)(pauVar79[uVar117 * -5 + -2] + 9) ^
                              CONCAT17(bStack_10469,uStack_10470)),
                 *(longlong *)(pauVar79[uVar117 * -5 + -1] + 1) ==
                 CONCAT17(bStack_10461,uStack_10468) && unaff_R15 == (undefined1 (*) [16])0x0))
              goto LAB_1400302f9;
            }
            uVar113 = uVar113 - 1 & uVar113;
            bVar76 = bStack_10528;
            bVar75 = bStack_10527;
            bVar73 = bStack_10526;
            bVar54 = bStack_10525;
            bVar55 = bStack_10524;
            bVar132 = bStack_10523;
            bVar56 = bStack_10522;
            bVar57 = bStack_10521;
            bVar58 = bStack_10520;
            bVar59 = bStack_1051f;
            bVar60 = bStack_1051e;
            bVar61 = bStack_1051d;
            bVar62 = bStack_1051c;
            bVar63 = bStack_1051b;
            bVar64 = bStack_1051a;
            bVar65 = bStack_10519;
            bVar66 = bStack_10518;
            bVar67 = bStack_10517;
          }
        }
      }
      bStack_10517 = bVar67;
      bStack_10518 = bVar66;
      bStack_10519 = bVar65;
      bStack_1051a = bVar64;
      bStack_1051b = bVar63;
      bStack_1051c = bVar62;
      bStack_1051d = bVar61;
      bStack_1051e = bVar60;
      bStack_1051f = bVar59;
      bStack_10520 = bVar58;
      bStack_10521 = bVar57;
      bStack_10522 = bVar56;
      bStack_10523 = bVar132;
      bStack_10524 = bVar55;
      bStack_10525 = bVar54;
      bStack_10526 = bVar73;
      bStack_10527 = bVar75;
      bStack_10528 = bVar76;
      if ((bVar77 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        goto LAB_140033f7f;
      }
    }
    cVar74 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    cStack_10530 = '\x01';
    if (cVar74 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
      cStack_10530 = '\x01';
    }
    goto LAB_1400331d0;
  }
  plVar94 = (longlong *)(*uStack_104b0 + 8);
  if (pauStack_10538 < (undefined1 (*) [16])&DAT_00000010) {
LAB_14002e43b:
    uVar4 = CONCAT17(bStack_10461,uStack_10468);
    uVar85 = CONCAT17(bStack_10469,uStack_10470);
    auStack_10270[0] = CONCAT22(uStack_1049e,uStack_104a0);
    uStack_10268 = CONCAT22(uStack_10496,uStack_10498);
    uStack_10264 = (undefined2)uStack_10494;
    uStack_10262 = (undefined2)(uStack_10494 >> 0x10);
    uStack_10260 = (undefined6)uStack_10490;
    uStack_1025a = (undefined2)(uStack_10490 >> 0x30);
    uStack_10278._0_1_ = bStack_104a8;
    uStack_10278._1_1_ = bStack_104a7;
    uStack_10276 = uStack_104a6;
    uStack_10274 = uStack_104a4;
    uStack_10272 = uStack_104a2;
    auStack_10270[1]._0_2_ = (undefined2)uStack_1049c;
    auStack_10270[1]._2_2_ = (undefined2)(uStack_1049c >> 0x10);
    <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
    ::lock(&bStack_10528,&DAT_140699948);
    if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
      uStack_10438._4_4_ =
           CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
      uStack_10438._0_1_ = bStack_10520;
      uStack_10438._1_1_ = bStack_1051f;
      uStack_10438._2_1_ = bStack_1051e;
      uStack_10438._3_1_ = bStack_1051d;
      bStack_10430 = bStack_10518;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2398);
      goto LAB_140036cf0;
    }
    uStack_10348 = (char *)CONCAT17(bStack_10519,
                                    CONCAT16(bStack_1051a,
                                             CONCAT15(bStack_1051b,
                                                      CONCAT14(bStack_1051c,
                                                               CONCAT13(bStack_1051d,
                                                                        CONCAT12(bStack_1051e,
                                                                                 CONCAT11(
                                                  bStack_1051f,bStack_10520)))))));
    uStack_10340 = CONCAT71(uStack_10340._1_7_,bStack_10518);
    if ((bVar76 & 1) == 0) {
      in_stack_fffffffffffefaa8 =
           (undefined **)((ulonglong)in_stack_fffffffffffefaa8 & 0xffffffffffffff00);
      cVar74 = is_host_route(uStack_10348 + 8,
                             HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                             IS_HOST_0_llvm_14435704873730135342 == '\0',
                             HOST_ID_0_llvm_14435704873730135342,&uStack_10278,
                             in_stack_fffffffffffefaa8,uVar85,uVar4);
      if (cVar74 == '\0') goto LAB_14002e558;
      <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
      ::lock(&bStack_10528,&TRANSPORT);
      if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
        uStack_10438._4_4_ =
             CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
        uStack_10438._0_1_ = bStack_10520;
        uStack_10438._1_1_ = bStack_1051f;
        uStack_10438._2_1_ = bStack_1051e;
        uStack_10438._3_1_ = bStack_1051d;
        bStack_10430 = bStack_10518;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                   &
                   PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
                   ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a23b0
                  );
        goto LAB_140036cf0;
      }
      pcVar109 = (char *)CONCAT17(bStack_10519,
                                  CONCAT16(bStack_1051a,
                                           CONCAT15(bStack_1051b,
                                                    CONCAT14(bStack_1051c,
                                                             CONCAT13(bStack_1051d,
                                                                      CONCAT12(bStack_1051e,
                                                                               CONCAT11(bStack_1051f
                                                                                        ,
                                                  bStack_10520)))))));
      if (pcVar109[0x30] == '\x01') {
        if ((bStack_10518 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          if (cVar74 == '\0') {
            pcVar109[1] = '\x01';
          }
        }
        LOCK();
        cVar74 = *pcVar109;
        *pcVar109 = '\0';
        UNLOCK();
        if (cVar74 == '\x02') {
          <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
        }
        goto LAB_14002e558;
      }
      if ((bStack_10518 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          pcVar109[1] = '\x01';
        }
      }
      LOCK();
      cVar74 = *pcVar109;
      *pcVar109 = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
      }
      uStack_103a8 = 0;
      uStack_103a6 = 0;
      uStack_103a4 = 0;
      uStack_103a2 = 0;
      uStack_103a0 = 8;
      uStack_1039e = 0;
      uStack_1039c = 0;
      uStack_10398 = 0;
      uStack_10396 = 0;
      uStack_10394 = 0;
      if ((undefined1 (*) [16])&DAT_00000010 < pauStack_10538) {
        puVar99 = pauStack_10538[-1] + 8;
        do {
          puVar90 = (undefined1 *)((ulonglong)*(byte *)(plVar94 + 1) + 9);
          bVar129 = puVar99 < puVar90;
          puVar99 = puVar99 + -(longlong)puVar90;
          if (bVar129) break;
          lVar80 = *plVar94;
          core[505b25137b8ba7f]::str::converts::from_utf8
                    (&bStack_10528,(undefined1 *)((longlong)plVar94 + 9));
          if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) != 1
             ) {
            <core[505b25137b8ba7f]::net::socket_addr::SocketAddr_as_core[505b25137b8ba7f]::str::traits::FromStr>
            ::from_str(&bStack_10528,
                       CONCAT17(bStack_10519,
                                CONCAT16(bStack_1051a,
                                         CONCAT15(bStack_1051b,
                                                  CONCAT14(bStack_1051c,
                                                           CONCAT13(bStack_1051d,
                                                                    CONCAT12(bStack_1051e,
                                                                             CONCAT11(bStack_1051f,
                                                                                      bStack_10520))
                                                                   ))))),
                       CONCAT44(uStack_10514,
                                CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518))));
            if (CONCAT11(bStack_10527,bStack_10528) != 2) {
              uStack_10438._4_4_ =
                   CONCAT13(bStack_10521,CONCAT12(bStack_10522,CONCAT11(bStack_10523,bStack_10524)))
              ;
              uStack_1042e = CONCAT11(bStack_1051d,bStack_1051e);
              uStack_10420 = CONCAT22(uStack_1050e,uStack_10510);
              bStack_10428 = bStack_10518;
              bStack_10427 = bStack_10517;
              uStack_10426 = uStack_10516;
              uStack_10424 = uStack_10514;
              uStack_1041c = uStack_1050c;
              uStack_1041a = uStack_1050a;
              uStack_10438._0_1_ = bStack_10528;
              uStack_10438._1_1_ = bStack_10527;
              uStack_10438._2_1_ = bStack_10526;
              uStack_10438._3_1_ = bStack_10525;
              bStack_10430 = bStack_10520;
              bStack_1042f = bStack_1051f;
              uStack_1042c = (uint)(CONCAT15(bStack_10519,
                                             CONCAT14(bStack_1051a,
                                                      CONCAT13(bStack_1051b,
                                                               CONCAT12(bStack_1051c,uStack_1042e)))
                                            ) >> 0x10);
              lVar120 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
              if (lVar120 ==
                  CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8))))
              {
                <alloc[246c2e7857c81348]::raw_vec::RawVec<reach_directory[4b72b9694f6c3c08]::chat::Player>>
                ::grow_one(&uStack_103a8);
              }
              lVar98 = CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
              *(longlong *)(lVar98 + lVar120 * 0x28) = lVar80;
              puVar86 = (undefined8 *)(lVar98 + 8 + lVar120 * 0x28);
              *puVar86 = CONCAT44(uStack_10438._4_4_,
                                  CONCAT13(uStack_10438._3_1_,
                                           CONCAT12(uStack_10438._2_1_,
                                                    CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))
                                          ));
              puVar86[1] = CONCAT44(uStack_1042c,
                                    CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
              puVar86 = (undefined8 *)(lVar98 + 0x18 + lVar120 * 0x28);
              *puVar86 = CONCAT44(uStack_10424,
                                  CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428)));
              puVar86[1] = CONCAT26(uStack_1041a,CONCAT24(uStack_1041c,uStack_10420));
              unaff_R15 = (undefined1 (*) [16])(lVar120 + 1);
              uStack_10398 = (ushort)unaff_R15;
              uStack_10396 = (ushort)((ulonglong)unaff_R15 >> 0x10);
              uStack_10394 = (uint)((ulonglong)unaff_R15 >> 0x20);
            }
          }
          plVar94 = (longlong *)((longlong)plVar94 + (longlong)puVar90);
        } while (&DAT_00000008 < puVar99);
        bVar76 = (byte)uStack_10278;
        lStack_101f8 = CONCAT26(uStack_103a2,
                                CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
        pauVar82 = (undefined1 (*) [16])CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
        lVar80 = CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398));
        pauStack_10350 = pauVar82;
        if (lVar80 != 0) {
          uStack_104c0 = (undefined1 (*) [16])((longlong)pauVar82 + lVar80 * 0x28);
          cStack_103d9 = (char)uStack_10276;
          uVar117 = CONCAT26(auStack_10270[1]._2_2_,
                             CONCAT24((undefined2)auStack_10270[1],auStack_10270[0]));
          uStack_10160 = uVar117 << 0x20 | (ulonglong)CONCAT22(uStack_10272,uStack_10274);
          bVar75 = (byte)(uStack_10276 >> 8);
          uStack_10288 = (undefined1 (*) [16])
                         (CONCAT44(uStack_10288._4_4_,CONCAT22(uStack_10274,uStack_10276)) &
                         0xffffffff000000ff);
          cStack_103dc = cStack_103d9 == '\x7f' || bVar75 == 0xfe && cStack_103d9 == -0x57;
          lStack_10168 = CONCAT44(auStack_10270[0],CONCAT22(uStack_10272,uStack_10274));
          cStack_103da = bVar75 == 0xa8 || (bool)cStack_103dc;
          cStack_103db = (bVar75 & 0xf0) == 0x10 || (bool)cStack_103dc;
          uStack_10158 = ((ulonglong)uStack_10268 << 0x20 | uVar117 >> 0x20) ^ 0x100000000000000;
          uStack_10170 = CONCAT44(uStack_10268,
                                  CONCAT22(auStack_10270[1]._2_2_,(undefined2)auStack_10270[1])) ^
                         0x100000000000000;
          do {
            pauVar79 = *(undefined1 (**) [16])*pauVar82;
            uVar112 = *(ushort *)(*pauVar82 + 8);
            uVar85 = *(undefined8 *)(pauVar82[1] + 8);
            uVar117 = *(ulonglong *)pauVar82[2];
            bStack_10318 = (byte)((ulonglong)uVar85 >> 0x10);
            bStack_10317 = (byte)((ulonglong)uVar85 >> 0x18);
            uStack_10316 = (uint)((ulonglong)uVar85 >> 0x20);
            uVar113 = uStack_10316;
            uStack_10312 = (ushort)uVar117;
            uStack_10310 = (undefined6)(uVar117 >> 0x10);
            ppuVar103 = *(undefined ***)(*pauVar82 + 10);
            ppuVar6 = *(undefined ***)(pauVar82[1] + 2);
            bStack_10328 = (byte)ppuVar103;
            bStack_10327 = (byte)((ulonglong)ppuVar103 >> 8);
            iStack_10326 = (int)((ulonglong)ppuVar103 >> 0x10);
            uStack_10322 = (ushort)((ulonglong)ppuVar103 >> 0x30);
            bStack_10320 = (byte)ppuVar6;
            uStack_1031f = (undefined5)((ulonglong)ppuVar6 >> 8);
            uStack_1031a = (ushort)((ulonglong)ppuVar6 >> 0x30);
            if (uVar112 == 2) break;
            uStack_10396 = (ushort)(CONCAT13(bStack_10317,CONCAT12(bStack_10318,uStack_1031a)) >>
                                   0x10);
            uStack_10394 = uStack_10316;
            uStack_103a6 = (ushort)ppuVar103;
            uStack_103a4 = (ushort)((ulonglong)ppuVar103 >> 0x10);
            uStack_103a2 = (ushort)((ulonglong)ppuVar103 >> 0x20);
            uStack_1039e = (ushort)ppuVar6;
            uStack_1039c = (uint)((ulonglong)ppuVar6 >> 0x10);
            uStack_103a8 = uVar112;
            uStack_103a0 = uStack_10322;
            uStack_10398 = uStack_1031a;
            uStack_10390 = uVar117;
            pauStack_102a8 = pauVar79;
            ppuVar70 = uStack_10228;
            ppuVar71 = uStack_10220;
            if (pauVar79 != DAT_1406998e0) {
              uStack_10390._0_4_ = (uint)uVar117;
              uStack_10390._4_2_ = (ushort)(uVar117 >> 0x20);
              uStack_10390._6_2_ = (ushort)(uVar117 >> 0x30);
              uVar91 = uStack_10390._6_2_;
              bStack_10526 = (byte)((ulonglong)ppuVar103 >> 0x10);
              bStack_10525 = (byte)((ulonglong)ppuVar103 >> 0x18);
              bStack_10524 = (byte)((ulonglong)ppuVar103 >> 0x20);
              bStack_10523 = (byte)((ulonglong)ppuVar103 >> 0x28);
              bStack_10522 = (byte)((ulonglong)ppuVar103 >> 0x30);
              bStack_10521 = (byte)((ulonglong)ppuVar103 >> 0x38);
              bStack_1051f = (byte)((ulonglong)ppuVar6 >> 8);
              bStack_1051e = (byte)((ulonglong)ppuVar6 >> 0x10);
              bStack_1051d = (byte)((ulonglong)ppuVar6 >> 0x18);
              bStack_1051c = (byte)((ulonglong)ppuVar6 >> 0x20);
              bStack_1051b = (byte)((ulonglong)ppuVar6 >> 0x28);
              bStack_1051a = (byte)((ulonglong)ppuVar6 >> 0x30);
              bStack_10519 = (byte)((ulonglong)ppuVar6 >> 0x38);
              bStack_10527 = bStack_10327;
              bStack_10528 = bStack_10328;
              bStack_10520 = bStack_10320;
              bStack_10518 = bStack_10318;
              bStack_10517 = bStack_10317;
              if (uVar112 == 1) {
                iVar127 = CONCAT13(bStack_1051f,CONCAT12(bStack_10320,uStack_10322));
                if (((ulonglong)CONCAT13(bStack_10317,CONCAT12(bStack_10318,uStack_1031a)) << 0x20 |
                    CONCAT17(bStack_1051b,
                             CONCAT16(bStack_1051c,
                                      CONCAT15(bStack_1051d,CONCAT14(bStack_1051e,iVar127)))) >>
                    0x20) != 0x100000000000000 || (iVar127 != 0 || iStack_10326 != 0)) {
LAB_1400313a4:
                  auVar134[0] = -(bStack_10526 == 0);
                  auVar134[1] = -(bStack_10525 == 0);
                  auVar134[2] = -(bStack_10524 == 0);
                  auVar134[3] = -(bStack_10523 == 0);
                  auVar134[4] = -(bStack_10522 == 0);
                  auVar134[5] = -(bStack_10521 == 0);
                  auVar134[6] = -(bStack_10320 == 0);
                  auVar134[7] = -(bStack_1051f == 0);
                  auVar134[8] = -(bStack_1051e == 0);
                  auVar134[9] = -(bStack_1051d == 0);
                  auVar134[10] = -(bStack_1051c == 0);
                  auVar134[0xb] = -(bStack_1051b == 0);
                  auVar134[0xc] = -(bStack_1051a == 0);
                  auVar134[0xd] = -(bStack_10519 == 0);
                  auVar134[0xe] = -(bStack_10318 == 0);
                  auVar134[0xf] = -(bStack_10317 == 1);
                  if ((ushort)((ushort)(SUB161(auVar134 >> 7,0) & 1) |
                               (ushort)(SUB161(auVar134 >> 0xf,0) & 1) << 1 |
                               (ushort)(SUB161(auVar134 >> 0x17,0) & 1) << 2 |
                               (ushort)(SUB161(auVar134 >> 0x1f,0) & 1) << 3 |
                               (ushort)(SUB161(auVar134 >> 0x27,0) & 1) << 4 |
                               (ushort)(SUB161(auVar134 >> 0x2f,0) & 1) << 5 |
                               (ushort)(SUB161(auVar134 >> 0x37,0) & 1) << 6 |
                               (ushort)(SUB161(auVar134 >> 0x3f,0) & 1) << 7 |
                               (ushort)(SUB161(auVar134 >> 0x47,0) & 1) << 8 |
                               (ushort)(SUB161(auVar134 >> 0x4f,0) & 1) << 9 |
                               (ushort)(SUB161(auVar134 >> 0x57,0) & 1) << 10 |
                               (ushort)(SUB161(auVar134 >> 0x5f,0) & 1) << 0xb |
                               (ushort)(SUB161(auVar134 >> 0x67,0) & 1) << 0xc |
                               (ushort)(SUB161(auVar134 >> 0x6f,0) & 1) << 0xd |
                               (ushort)(SUB161(auVar134 >> 0x77,0) & 1) << 0xe |
                              (ushort)(auVar134[0xf] >> 7) << 0xf) == 0xffff) goto LAB_140031405;
                  goto LAB_140031463;
                }
LAB_140031372:
                if ((bVar76 & 1) == 0) {
                  if ((int)uStack_10288 == 0x7f) goto LAB_14003139e;
                }
                else if (uStack_10160 == 0 && uStack_10158 == 0) {
LAB_14003139e:
                  if ((uVar112 & 1) == 0) goto LAB_1400313c3;
                  goto LAB_1400313a4;
                }
LAB_14003144d:
                bVar129 = true;
                uVar112 = 2;
              }
              else {
                if (bStack_10328 == 0x7f) goto LAB_140031372;
LAB_1400313c3:
                if (bStack_10328 != 10) {
                  uVar114 = (uint)ppuVar103 & 0xff;
                  if (uVar114 == 0xc0) {
                    if (bStack_10327 != 0xa8) goto LAB_1400313f0;
                  }
                  else if ((uVar114 != 0xac) || ((bStack_10327 & 0xf0) != 0x10)) {
LAB_1400313f0:
                    if ((bStack_10328 != 0x7f) && (bStack_10327 != 0xfe || bStack_10328 != 0xa9))
                    goto LAB_140031463;
                  }
                }
LAB_140031405:
                if ((bVar76 & 1) == 0) {
                  if (cStack_103d9 != '\n') {
                    cVar74 = cStack_103da;
                    if (((int)uStack_10288 != 0xc0) &&
                       (cVar74 = cStack_103dc, (int)uStack_10288 == 0xac)) {
                      cVar74 = cStack_103db;
                    }
                    if (cVar74 == '\0') goto LAB_14003144d;
                  }
                }
                else if (lStack_10168 != 0 || uStack_10170 != 0) goto LAB_14003144d;
LAB_140031463:
                uStack_101c8 = (ushort)((ulonglong)uVar85 >> 0x10);
                ppuStack_101d8 = ppuVar103;
                ppuStack_101d0 = ppuVar6;
                if (((HOST_ID_0_llvm_14435704873730135342 == (undefined1 (*) [16])0x0) ||
                    (IS_HOST_0_llvm_14435704873730135342 != '\0')) ||
                   (HOST_ID_0_llvm_14435704873730135342 != pauVar79)) {
                  uStack_10438._0_1_ = (byte)uVar112;
                  uStack_10438._1_1_ = (byte)(uVar112 >> 8);
                  uStack_10424 = uStack_10316;
                  uStack_10420 = (uint)uStack_10390;
                  uStack_10458 = (undefined1 (*) [16])
                                 CONCAT62(uStack_10458._2_6_,uStack_10390._4_2_);
                  uStack_1041c = uStack_10390._4_2_;
                  uStack_1041a = uStack_10390._6_2_;
                  puVar99 = &LISTED;
                  uStack_10438._2_1_ = bStack_10328;
                  uStack_10438._3_1_ = bStack_10327;
                  uStack_10438._4_4_ = iStack_10326;
                  bStack_10430 = bStack_10522;
                  bStack_1042f = bStack_10521;
                  uStack_1042e = uStack_1039e;
                  uStack_1042c = uStack_1039c;
                  bStack_10428 = bStack_1051a;
                  bStack_10427 = bStack_10519;
                  uStack_10426 = uStack_101c8;
                  <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
                  ::lock(&bStack_10528);
                  if (CONCAT13(bStack_10525,
                               CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
                    uStack_103c8 = (undefined1 (*) [16])
                                   CONCAT17(bStack_10519,
                                            CONCAT16(bStack_1051a,
                                                     CONCAT15(bStack_1051b,
                                                              CONCAT14(bStack_1051c,
                                                                       CONCAT13(bStack_1051d,
                                                                                CONCAT12(
                                                  bStack_1051e,CONCAT11(bStack_1051f,bStack_10520)))
                                                  ))));
                    ppuStack_103c0 = (undefined **)CONCAT71(ppuStack_103c0._1_7_,bStack_10518);
                    core[505b25137b8ba7f]::result::unwrap_failed
                              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_103c8,
                               &
                               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0ef0
                               ,&
                                PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0528
                              );
                    goto LAB_140036cf0;
                  }
                  pcVar109 = (char *)CONCAT17(bStack_10519,
                                              CONCAT16(bStack_1051a,
                                                       CONCAT15(bStack_1051b,
                                                                CONCAT14(bStack_1051c,
                                                                         CONCAT13(bStack_1051d,
                                                                                  CONCAT12(
                                                  bStack_1051e,CONCAT11(bStack_1051f,bStack_10520)))
                                                  ))));
                  uStack_10460 = (undefined1 (*) [16])CONCAT71(uStack_10460._1_7_,bStack_10518);
                  if (*(longlong *)(pcVar109 + 8) == -1) {
                    uVar85 = <std[3bf9d48a0c3997f0]::thread::local::LocalKey<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>>>
                             ::with::
                             <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::_closure_0_,std[3bf9d48a0c3997f0]::hash::random::RandomState>
                                       (&PTR_call_once_1406a06c0);
                    pcVar109[8] = '\0';
                    pcVar109[9] = '\0';
                    pcVar109[10] = '\0';
                    pcVar109[0xb] = '\0';
                    pcVar109[0xc] = '\0';
                    pcVar109[0xd] = '\0';
                    pcVar109[0xe] = '\0';
                    pcVar109[0xf] = '\0';
                    pcVar109[0x10] = '\b';
                    pcVar109[0x11] = '\0';
                    pcVar109[0x12] = '\0';
                    pcVar109[0x13] = '\0';
                    pcVar109[0x14] = '\0';
                    pcVar109[0x15] = '\0';
                    pcVar109[0x16] = '\0';
                    pcVar109[0x17] = '\0';
                    *(undefined1 (*) [16])(pcVar109 + 0x18) = (undefined1  [16])0x0;
                    *(undefined **)(pcVar109 + 0x28) = &DAT_1406a0540;
                    pcVar109[0x30] = '\0';
                    pcVar109[0x31] = '\0';
                    pcVar109[0x32] = '\0';
                    pcVar109[0x33] = '\0';
                    pcVar109[0x34] = '\0';
                    pcVar109[0x35] = '\0';
                    pcVar109[0x36] = '\0';
                    pcVar109[0x37] = '\0';
                    pcVar109[0x38] = '\0';
                    pcVar109[0x39] = '\0';
                    pcVar109[0x3a] = '\0';
                    pcVar109[0x3b] = '\0';
                    pcVar109[0x3c] = '\0';
                    pcVar109[0x3d] = '\0';
                    pcVar109[0x3e] = '\0';
                    pcVar109[0x3f] = '\0';
                    pcVar109[0x40] = '\0';
                    pcVar109[0x41] = '\0';
                    pcVar109[0x42] = '\0';
                    pcVar109[0x43] = '\0';
                    pcVar109[0x44] = '\0';
                    pcVar109[0x45] = '\0';
                    pcVar109[0x46] = '\0';
                    pcVar109[0x47] = '\0';
                    *(undefined8 *)(pcVar109 + 0x48) = uVar85;
                    *(undefined1 **)(pcVar109 + 0x50) = puVar99;
                  }
                  uStack_102d8 = SUB82(pauVar79,0);
                  uStack_102d6 = (undefined2)((ulonglong)pauVar79 >> 0x10);
                  uStack_102d4 = (ushort)((ulonglong)pauVar79 >> 0x20);
                  uStack_102d2 = (undefined2)((ulonglong)pauVar79 >> 0x30);
                  uStack_10228 = (undefined **)&uStack_10348;
                  puVar86 = (undefined8 *)
                            <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                            ::get_mut::<u64>(pcVar109 + 0x28,&uStack_102d8);
                  if (puVar86 == (undefined8 *)0x0) {
                    uVar81 = *(ulonglong *)(pcVar109 + 0x20);
                    if (0xff < uVar81) {
                      uVar83 = *(ulonglong *)(pcVar109 + 8);
                      uVar118 = uVar83;
                      if (*(ulonglong *)(pcVar109 + 0x18) < uVar83) {
                        uVar118 = 0;
                      }
                      lVar80 = *(ulonglong *)(pcVar109 + 0x18) - uVar118;
                      uVar121 = uVar83 - lVar80;
                      uVar118 = lVar80 + uVar81;
                      if (uVar121 < uVar81) {
                        uVar118 = uVar83;
                      }
                      lVar120 = *(longlong *)(pcVar109 + 0x10);
                      lVar98 = uVar81 - uVar121;
                      if (uVar81 < uVar121) {
                        lVar98 = 0;
                      }
                      lVar80 = lVar120 + lVar80 * 8;
                      lVar128 = lVar120 + uVar118 * 8;
                      lVar98 = lVar120 + lVar98 * 8;
                      bStack_10528 = (byte)lVar80;
                      bStack_10527 = (byte)((ulonglong)lVar80 >> 8);
                      bStack_10526 = (byte)((ulonglong)lVar80 >> 0x10);
                      bStack_10525 = (byte)((ulonglong)lVar80 >> 0x18);
                      bStack_10524 = (byte)((ulonglong)lVar80 >> 0x20);
                      bStack_10523 = (byte)((ulonglong)lVar80 >> 0x28);
                      bStack_10522 = (byte)((ulonglong)lVar80 >> 0x30);
                      bStack_10521 = (byte)((ulonglong)lVar80 >> 0x38);
                      bStack_10520 = (byte)lVar128;
                      bStack_1051f = (byte)((ulonglong)lVar128 >> 8);
                      bStack_1051e = (byte)((ulonglong)lVar128 >> 0x10);
                      bStack_1051d = (byte)((ulonglong)lVar128 >> 0x18);
                      bStack_1051c = (byte)((ulonglong)lVar128 >> 0x20);
                      bStack_1051b = (byte)((ulonglong)lVar128 >> 0x28);
                      bStack_1051a = (byte)((ulonglong)lVar128 >> 0x30);
                      bStack_10519 = (byte)((ulonglong)lVar128 >> 0x38);
                      bStack_10518 = (byte)lVar120;
                      bStack_10517 = (byte)((ulonglong)lVar120 >> 8);
                      uStack_10516 = (ushort)((ulonglong)lVar120 >> 0x10);
                      uStack_10514 = (uint)((ulonglong)lVar120 >> 0x20);
                      uStack_10510 = (ushort)lVar98;
                      uStack_1050e = (ushort)((ulonglong)lVar98 >> 0x10);
                      uStack_1050c = (ushort)((ulonglong)lVar98 >> 0x20);
                      uStack_1050a = (ushort)((ulonglong)lVar98 >> 0x30);
                      uStack_103c8 = (undefined1 (*) [16])0x0;
                      pauVar123 = (undefined1 (*) [16])&uStack_10228;
                      uVar81 = <alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<u64>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
                               ::try_fold::
                               <(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::position::check<&u64,<host_probe[b94139f9089eb1d8]::net::Listed>::name<host_probe[b94139f9089eb1d8]::net::learn_peer_table::_closure_2_>::_closure_0_>::_closure_0_,core[505b25137b8ba7f]::ops::control_flow::ControlFlow<usize>>
                                         (&bStack_10528,pauVar123,&uStack_103c8);
                      uStack_104b8 = pauVar123;
                      if ((uVar81 & 1) == 0) goto LAB_140031df7;
                      pauStack_10190 = *(undefined1 (**) [16])(pcVar109 + 0x20);
                      if (pauVar123 < pauStack_10190) {
                        uStack_1032c = uVar91;
                        pauStack_10450 = *(undefined1 (**) [16])(pcVar109 + 0x18);
                        puVar99 = *(undefined1 **)(pcVar109 + 8);
                        pauVar89 = *(undefined1 (**) [16])(pcVar109 + 0x10);
                        puVar90 = (undefined1 *)0x0;
                        if (puVar99 <= *pauVar123 + (longlong)*pauStack_10450) {
                          puVar90 = puVar99;
                        }
                        lVar80 = (longlong)(*pauVar123 + (longlong)*pauStack_10450) -
                                 (longlong)puVar90;
                        pauStack_10180 = *(undefined1 (**) [16])((longlong)pauVar89 + lVar80 * 8);
                        pauVar92 = (undefined1 (*) [16])(*pauStack_10190 + ~(ulonglong)pauVar123);
                        pauStack_10480 = pauVar89;
                        if (pauVar92 < pauVar123) {
                          puVar90 = (undefined1 *)0x0;
                          if (puVar99 <= (undefined1 *)(lVar80 + 1)) {
                            puVar90 = puVar99;
                          }
                          pauStack_10440 = pauVar92;
                          if (pauVar92 != (undefined1 (*) [16])0x0) {
                            uStack_104b8 = (undefined1 (*) [16])
                                           ((undefined1 *)(lVar80 + 1) + -(longlong)puVar90);
                            pauVar123 = (undefined1 (*) [16])(lVar80 - (longlong)uStack_104b8);
                            if (pauVar123 != (undefined1 (*) [16])0x0) {
                              pauStack_10450 =
                                   (undefined1 (*) [16])((longlong)pauVar89 + lVar80 * 8);
                              pauVar84 = (undefined1 (*) [16])(puVar99 + (longlong)*pauVar123);
                              if (!CARRY8((ulonglong)pauVar123,(ulonglong)puVar99)) {
                                pauVar84 = pauVar123;
                              }
                              pauVar123 = (undefined1 (*) [16])(puVar99 + -(longlong)uStack_104b8);
                              pauVar104 = (undefined1 (*) [16])(puVar99 + -lVar80);
                              lStack_103d8 = (longlong)pauVar92 - (longlong)pauVar123;
                              if (pauVar92 < pauVar123 || lStack_103d8 == 0) {
                                lStack_103d8 = (longlong)pauVar92 - (longlong)pauVar104;
                                if (pauVar92 < pauVar104 || lStack_103d8 == 0) {
                                  pauVar123 = (undefined1 (*) [16])
                                              (*pauVar89 + (longlong)uStack_104b8 * 8);
LAB_140031b6d:
                                  sVar119 = (longlong)pauVar92 << 3;
                                  pauVar89 = pauStack_10450;
                                }
                                else {
                                  if (pauVar84 < pauVar92) {
                                    uStack_104b8 = (undefined1 (*) [16])
                                                   (*pauVar89 + (longlong)uStack_104b8 * 8);
                                    memmove(pauVar89,*uStack_104b8 + (longlong)pauVar104 * 8,
                                            lStack_103d8 * 8);
                                    pauVar89 = pauStack_10450;
                                    goto LAB_140031a3e;
                                  }
                                  uStack_104b8 = (undefined1 (*) [16])
                                                 (*pauVar89 + (longlong)uStack_104b8 * 8);
                                  memmove(pauStack_10450,uStack_104b8,(longlong)pauVar104 * 8);
                                  pauVar123 = (undefined1 (*) [16])
                                              (*uStack_104b8 + (longlong)pauVar104 * 8);
                                  sVar119 = lStack_103d8 << 3;
                                  pauVar89 = pauStack_10480;
                                }
                              }
                              else if (pauVar84 < pauVar92) {
                                if (pauVar104 < pauVar92) {
                                  lStack_10200 = (longlong)pauVar123 - (longlong)pauVar104;
                                  pauStack_10440 = (undefined1 (*) [16])(lStack_10200 * 8);
                                  pauStack_102b8 = pauVar104;
                                  memmove((undefined1 *)((longlong)pauVar89 + lStack_10200 * 8),
                                          pauVar89,lStack_103d8 * 8);
                                  pauVar123 = pauStack_10480;
                                  memmove(pauStack_10480,
                                          (undefined1 *)
                                          ((longlong)pauStack_10480 +
                                          ((longlong)puVar99 - lStack_10200) * 8),
                                          (size_t)pauStack_10440);
                                  pauVar123 = (undefined1 (*) [16])
                                              (*pauVar123 + (longlong)uStack_104b8 * 8);
                                  pauVar92 = pauStack_102b8;
                                  goto LAB_140031b6d;
                                }
                                sVar119 = (longlong)pauVar123 * 8;
                                memmove(*pauStack_10450 + (longlong)pauVar123 * 8,pauVar89,
                                        lStack_103d8 * 8);
                                pauVar89 = pauStack_10450;
                                pauVar123 = (undefined1 (*) [16])
                                            (*pauStack_10480 + (longlong)uStack_104b8 * 8);
                              }
                              else {
                                lVar80 = (longlong)uStack_104b8 * 8;
                                uStack_104b8 = (undefined1 (*) [16])
                                               (*pauStack_10450 + (longlong)pauVar123 * 8);
                                pauStack_10440 =
                                     (undefined1 (*) [16])((longlong)pauVar92 - (longlong)pauVar104)
                                ;
                                if (pauVar92 < pauVar104 ||
                                    pauStack_10440 == (undefined1 (*) [16])0x0) {
                                  memmove(pauStack_10450,*pauVar89 + lVar80,(longlong)pauVar123 * 8)
                                  ;
                                  pauVar89 = uStack_104b8;
                                  goto LAB_140031d52;
                                }
                                memmove(pauStack_10450,*pauVar89 + lVar80,(longlong)pauVar123 * 8);
                                memmove(uStack_104b8,pauStack_10480,
                                        ((longlong)pauVar104 - (longlong)pauVar123) * 8);
                                sVar119 = (longlong)pauStack_10440 << 3;
                                pauVar89 = pauStack_10480;
                                pauVar123 = (undefined1 (*) [16])
                                            ((longlong)pauStack_10480 +
                                            ((longlong)pauVar104 - (longlong)pauVar123) * 8);
                              }
                              goto LAB_140031d5a;
                            }
                          }
                        }
                        else {
                          puVar90 = (undefined1 *)0x0;
                          if (puVar99 <= *pauStack_10450 + 1) {
                            puVar90 = puVar99;
                          }
                          pauStack_10440 =
                               (undefined1 (*) [16])(*pauStack_10450 + 1 + -(longlong)puVar90);
                          *(undefined1 (**) [16])(pcVar109 + 0x18) = pauStack_10440;
                          if ((pauVar123 != (undefined1 (*) [16])0x0) &&
                             (pauVar92 = (undefined1 (*) [16])
                                         ((longlong)pauStack_10440 - (longlong)pauStack_10450),
                             pauVar92 != (undefined1 (*) [16])0x0)) {
                            pauVar84 = (undefined1 (*) [16])(puVar99 + (longlong)*pauVar92);
                            if (!CARRY8((ulonglong)pauVar92,(ulonglong)puVar99)) {
                              pauVar84 = pauVar92;
                            }
                            pauVar92 = (undefined1 (*) [16])(puVar99 + -(longlong)pauStack_10450);
                            pauVar104 = (undefined1 (*) [16])(puVar99 + -(longlong)pauStack_10440);
                            lStack_103d8 = (longlong)pauVar123 - (longlong)pauVar92;
                            if (pauVar123 < pauVar92 || lStack_103d8 == 0) {
                              lStack_103d8 = (longlong)pauVar123 - (longlong)pauVar104;
                              if (pauVar123 < pauVar104 || lStack_103d8 == 0) {
                                pauVar123 = (undefined1 (*) [16])
                                            (*pauVar89 + (longlong)pauStack_10450 * 8);
                                pauVar89 = (undefined1 (*) [16])
                                           (*pauVar89 + (longlong)pauStack_10440 * 8);
LAB_140031b9e:
                                sVar119 = (longlong)uStack_104b8 << 3;
                              }
                              else if (pauVar84 < pauVar123) {
                                uStack_104b8 = (undefined1 (*) [16])
                                               (*pauVar89 + (longlong)pauStack_10450 * 8);
                                memmove(pauVar89,*uStack_104b8 + (longlong)pauVar104 * 8,
                                        lStack_103d8 * 8);
                                pauVar89 = (undefined1 (*) [16])
                                           (*pauStack_10480 + (longlong)pauStack_10440 * 8);
LAB_140031a3e:
                                sVar119 = (longlong)pauVar104 << 3;
                                pauVar123 = uStack_104b8;
                              }
                              else {
                                uStack_104b8 = (undefined1 (*) [16])
                                               (*pauVar89 + (longlong)pauStack_10450 * 8);
                                pauStack_102b8 = pauVar104;
                                memmove(*pauVar89 + (longlong)pauStack_10440 * 8,uStack_104b8,
                                        (longlong)pauVar104 * 8);
                                pauVar123 = (undefined1 (*) [16])
                                            (*uStack_104b8 + (longlong)pauStack_102b8 * 8);
                                sVar119 = lStack_103d8 << 3;
                              }
                            }
                            else if (pauVar84 < pauVar123) {
                              if (pauVar104 < pauVar123) {
                                lStack_10200 = (longlong)pauVar92 - (longlong)pauVar104;
                                uStack_104b8 = (undefined1 (*) [16])(lStack_10200 * 8);
                                pauStack_102b8 = pauVar104;
                                memmove((undefined1 *)((longlong)pauVar89 + lStack_10200 * 8),
                                        pauVar89,lStack_103d8 * 8);
                                pauVar89 = pauStack_10480;
                                memmove(pauStack_10480,
                                        (undefined1 *)
                                        ((longlong)pauStack_10480 +
                                        ((longlong)puVar99 - lStack_10200) * 8),(size_t)uStack_104b8
                                       );
                                pauVar123 = (undefined1 (*) [16])
                                            (*pauVar89 + (longlong)pauStack_10450 * 8);
                                pauVar89 = (undefined1 (*) [16])
                                           (*pauVar89 + (longlong)pauStack_10440 * 8);
                                sVar119 = (longlong)pauStack_102b8 << 3;
                              }
                              else {
                                uStack_104b8 = (undefined1 (*) [16])
                                               (*pauVar89 + (longlong)pauStack_10440 * 8);
                                sVar119 = (longlong)pauVar92 * 8;
                                memmove(*uStack_104b8 + (longlong)pauVar92 * 8,pauVar89,
                                        lStack_103d8 * 8);
                                pauVar123 = (undefined1 (*) [16])
                                            (*pauStack_10480 + (longlong)pauStack_10450 * 8);
                                pauVar89 = uStack_104b8;
                              }
                            }
                            else {
                              lVar80 = (longlong)pauStack_10450 * 8;
                              puVar99 = *pauVar89 + (longlong)pauStack_10440 * 8;
                              pauStack_10450 =
                                   (undefined1 (*) [16])(puVar99 + (longlong)pauVar92 * 8);
                              uStack_104b8 = (undefined1 (*) [16])
                                             ((longlong)pauVar123 - (longlong)pauVar104);
                              if (pauVar104 <= pauVar123 && uStack_104b8 != (undefined1 (*) [16])0x0
                                 ) {
                                memmove(puVar99,*pauVar89 + lVar80,(longlong)pauVar92 * 8);
                                memmove(pauStack_10450,pauStack_10480,
                                        ((longlong)pauVar104 - (longlong)pauVar92) * 8);
                                pauVar123 = (undefined1 (*) [16])
                                            ((longlong)pauStack_10480 +
                                            ((longlong)pauVar104 - (longlong)pauVar92) * 8);
                                pauVar89 = pauStack_10480;
                                goto LAB_140031b9e;
                              }
                              memmove(puVar99,*pauVar89 + lVar80,(longlong)pauVar92 * 8);
                              pauVar89 = pauStack_10450;
LAB_140031d52:
                              sVar119 = lStack_103d8 << 3;
                              pauVar123 = pauStack_10480;
                            }
LAB_140031d5a:
                            memmove(pauVar89,pauVar123,sVar119);
                          }
                        }
                        *(undefined1 **)(pcVar109 + 0x20) = pauStack_10190[-1] + 0xf;
                        uStack_103c8 = pauStack_10180;
                        <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                        ::remove::<u64>(&bStack_10528,pcVar109 + 0x28,&uStack_103c8);
                        uVar91 = uStack_1032c;
                      }
                    }
                    <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                    ::insert(&bStack_10528,pcVar109 + 0x28,pauVar79);
                    uVar81 = *(ulonglong *)(pcVar109 + 8);
                    uVar83 = *(ulonglong *)(pcVar109 + 0x20);
                    if (uVar83 == uVar81) {
                      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<u64>>::grow
                                (pcVar109 + 8);
                      uVar81 = *(ulonglong *)(pcVar109 + 8);
                      uVar83 = *(ulonglong *)(pcVar109 + 0x20);
                    }
                    *(ulonglong *)(pcVar109 + 0x20) = uVar83 + 1;
                    uVar118 = 0;
                    if (uVar81 <= uVar83 + *(longlong *)(pcVar109 + 0x18)) {
                      uVar118 = uVar81;
                    }
                    *(undefined1 (**) [16])
                     (*(longlong *)(pcVar109 + 0x10) +
                     ((uVar83 + *(longlong *)(pcVar109 + 0x18)) - uVar118) * 8) = pauVar79;
                  }
                  else {
                    puVar86[2] = CONCAT44(uStack_10424,
                                          CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428))
                                         );
                    puVar86[3] = CONCAT26(uStack_1041a,CONCAT24(uStack_1041c,uStack_10420));
                    *puVar86 = CONCAT44(uStack_10438._4_4_,
                                        CONCAT13(uStack_10438._3_1_,
                                                 CONCAT12(uStack_10438._2_1_,
                                                          CONCAT11(uStack_10438._1_1_,
                                                                   (byte)uStack_10438))));
                    puVar86[1] = CONCAT44(uStack_1042c,
                                          CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430))
                                         );
                  }
LAB_140031df7:
                  if (((char)uStack_10460 == '\0') &&
                     ((*(ulonglong *)
                        __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
                      & 0x7fffffffffffffff) != 0)) {
                    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                    if (cVar74 == '\0') {
                      pcVar109[1] = '\x01';
                    }
                  }
                  LOCK();
                  cVar74 = *pcVar109;
                  *pcVar109 = '\0';
                  UNLOCK();
                  if (cVar74 == '\x02') {
                    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
                  }
                }
                else {
                  uStack_10458 = (undefined1 (*) [16])
                                 CONCAT62(uStack_10458._2_6_,uStack_10390._4_2_);
                }
                uStack_10460 = (undefined1 (*) [16])CONCAT44(uStack_10460._4_4_,uVar113);
                bVar129 = false;
                uStack_104b8 = (undefined1 (*) [16])CONCAT62(uStack_104b8._2_6_,uVar91);
                unaff_R15 = (undefined1 (*) [16])(uVar117 & 0xffffffff);
              }
              pcVar109 = uStack_10348;
              if (*(longlong *)(uStack_10348 + 0x20) != 0) {
                uVar81 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                         ::hash_one::<&usize>(uStack_10348 + 0x28,&pauStack_102a8);
                lVar80 = *(longlong *)(pcVar109 + 8);
                uVar117 = *(ulonglong *)(pcVar109 + 0x10);
                bVar75 = (byte)(uVar81 >> 0x39);
                auVar133 = ZEXT216(CONCAT11(bVar75,bVar75));
                auVar133 = pshuflw(auVar133,auVar133,0);
                lVar120 = 0;
                while( true ) {
                  uVar81 = uVar81 & uVar117;
                  pcVar109 = (char *)(lVar80 + uVar81);
                  auVar176[0] = -(*pcVar109 == auVar133[0]);
                  auVar176[1] = -(pcVar109[1] == auVar133[1]);
                  auVar176[2] = -(pcVar109[2] == auVar133[2]);
                  auVar176[3] = -(pcVar109[3] == auVar133[3]);
                  auVar176[4] = -(pcVar109[4] == auVar133[4]);
                  auVar176[5] = -(pcVar109[5] == auVar133[5]);
                  auVar176[6] = -(pcVar109[6] == auVar133[6]);
                  auVar176[7] = -(pcVar109[7] == auVar133[7]);
                  auVar176[8] = -(pcVar109[8] == auVar133[0]);
                  auVar176[9] = -(pcVar109[9] == auVar133[1]);
                  auVar176[10] = -(pcVar109[10] == auVar133[2]);
                  auVar176[0xb] = -(pcVar109[0xb] == auVar133[3]);
                  auVar176[0xc] = -(pcVar109[0xc] == auVar133[4]);
                  auVar176[0xd] = -(pcVar109[0xd] == auVar133[5]);
                  auVar176[0xe] = -(pcVar109[0xe] == auVar133[6]);
                  auVar176[0xf] = -(pcVar109[0xf] == auVar133[7]);
                  uVar91 = (ushort)(SUB161(auVar176 >> 7,0) & 1) |
                           (ushort)(SUB161(auVar176 >> 0xf,0) & 1) << 1 |
                           (ushort)(SUB161(auVar176 >> 0x17,0) & 1) << 2 |
                           (ushort)(SUB161(auVar176 >> 0x1f,0) & 1) << 3 |
                           (ushort)(SUB161(auVar176 >> 0x27,0) & 1) << 4 |
                           (ushort)(SUB161(auVar176 >> 0x2f,0) & 1) << 5 |
                           (ushort)(SUB161(auVar176 >> 0x37,0) & 1) << 6 |
                           (ushort)(SUB161(auVar176 >> 0x3f,0) & 1) << 7 |
                           (ushort)(SUB161(auVar176 >> 0x47,0) & 1) << 8 |
                           (ushort)(SUB161(auVar176 >> 0x4f,0) & 1) << 9 |
                           (ushort)(SUB161(auVar176 >> 0x57,0) & 1) << 10 |
                           (ushort)(SUB161(auVar176 >> 0x5f,0) & 1) << 0xb |
                           (ushort)(SUB161(auVar176 >> 0x67,0) & 1) << 0xc |
                           (ushort)(SUB161(auVar176 >> 0x6f,0) & 1) << 0xd |
                           (ushort)(SUB161(auVar176 >> 0x77,0) & 1) << 0xe |
                           (ushort)(auVar176[0xf] >> 7) << 0xf;
                  uVar113 = (uint)uVar91;
                  while (uVar91 != 0) {
                    uVar114 = 0;
                    for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
                      uVar114 = uVar114 + 1;
                    }
                    lVar98 = (uVar114 + uVar81 & uVar117) * -0x50;
                    if (pauStack_102a8 == *(undefined1 (**) [16])(lVar80 + -0x50 + lVar98)) {
                      uStack_10218 = (undefined1 (*) [16])CONCAT62(uStack_10218._2_6_,uStack_101c8);
                      uStack_10228 = ppuStack_101d8;
                      ppuVar70 = uStack_10228;
                      uStack_10220 = ppuStack_101d0;
                      ppuVar71 = uStack_10220;
                      if ((bVar129) ||
                         (lVar80 = lVar80 + lVar98, *(char *)(lVar80 + -0x18) == '\x01'))
                      goto LAB_140031282;
                      uStack_10228._6_1_ = (byte)((ulonglong)ppuStack_101d8 >> 0x30);
                      uStack_10228._7_1_ = (byte)((ulonglong)ppuStack_101d8 >> 0x38);
                      uStack_10220._6_1_ = (byte)((ulonglong)ppuStack_101d0 >> 0x30);
                      uStack_10220._7_1_ = (byte)((ulonglong)ppuStack_101d0 >> 0x38);
                      if (*(ushort *)(lVar80 + -0x38) == uVar112) {
                        if (uVar112 == 1) {
                          if ((*(ushort *)(lVar80 + -0x1c) == (ushort)uStack_10458) &&
                             ((*(uint *)(lVar80 + -0x24) == (uint)uStack_10460 &&
                              (*(uint *)(lVar80 + -0x20) == (uint)unaff_R15)))) {
                            auVar133 = *(undefined1 (*) [16])(lVar80 + -0x34);
                            uStack_10228._2_1_ = (char)((ulonglong)ppuStack_101d8 >> 0x10);
                            uStack_10228._3_1_ = (char)((ulonglong)ppuStack_101d8 >> 0x18);
                            uStack_10228._4_1_ = (char)((ulonglong)ppuStack_101d8 >> 0x20);
                            uStack_10228._5_1_ = (char)((ulonglong)ppuStack_101d8 >> 0x28);
                            uStack_10220._0_1_ = (char)ppuStack_101d0;
                            uStack_10220._1_1_ = (char)((ulonglong)ppuStack_101d0 >> 8);
                            uStack_10220._2_1_ = (char)((ulonglong)ppuStack_101d0 >> 0x10);
                            uStack_10220._3_1_ = (char)((ulonglong)ppuStack_101d0 >> 0x18);
                            uStack_10220._4_1_ = (char)((ulonglong)ppuStack_101d0 >> 0x20);
                            uStack_10220._5_1_ = (char)((ulonglong)ppuStack_101d0 >> 0x28);
                            uStack_10218._0_1_ = (char)uStack_101c8;
                            uStack_10218._1_1_ = (char)(uStack_101c8 >> 8);
                            auVar161[0] = -(uStack_10228._2_1_ == auVar133[0]);
                            auVar161[1] = -(uStack_10228._3_1_ == auVar133[1]);
                            auVar161[2] = -(uStack_10228._4_1_ == auVar133[2]);
                            auVar161[3] = -(uStack_10228._5_1_ == auVar133[3]);
                            auVar161[4] = -(uStack_10228._6_1_ == auVar133[4]);
                            auVar161[5] = -(uStack_10228._7_1_ == auVar133[5]);
                            auVar161[6] = -((char)uStack_10220 == auVar133[6]);
                            auVar161[7] = -(uStack_10220._1_1_ == auVar133[7]);
                            auVar161[8] = -(uStack_10220._2_1_ == auVar133[8]);
                            auVar161[9] = -(uStack_10220._3_1_ == auVar133[9]);
                            auVar161[10] = -(uStack_10220._4_1_ == auVar133[10]);
                            auVar161[0xb] = -(uStack_10220._5_1_ == auVar133[0xb]);
                            auVar161[0xc] = -(uStack_10220._6_1_ == auVar133[0xc]);
                            auVar161[0xd] = -(uStack_10220._7_1_ == auVar133[0xd]);
                            auVar161[0xe] = -((char)uStack_10218 == auVar133[0xe]);
                            auVar161[0xf] = -(uStack_10218._1_1_ == auVar133[0xf]);
                            if ((ushort)((ushort)(SUB161(auVar161 >> 7,0) & 1) |
                                         (ushort)(SUB161(auVar161 >> 0xf,0) & 1) << 1 |
                                         (ushort)(SUB161(auVar161 >> 0x17,0) & 1) << 2 |
                                         (ushort)(SUB161(auVar161 >> 0x1f,0) & 1) << 3 |
                                         (ushort)(SUB161(auVar161 >> 0x27,0) & 1) << 4 |
                                         (ushort)(SUB161(auVar161 >> 0x2f,0) & 1) << 5 |
                                         (ushort)(SUB161(auVar161 >> 0x37,0) & 1) << 6 |
                                         (ushort)(SUB161(auVar161 >> 0x3f,0) & 1) << 7 |
                                         (ushort)(SUB161(auVar161 >> 0x47,0) & 1) << 8 |
                                         (ushort)(SUB161(auVar161 >> 0x4f,0) & 1) << 9 |
                                         (ushort)(SUB161(auVar161 >> 0x57,0) & 1) << 10 |
                                         (ushort)(SUB161(auVar161 >> 0x5f,0) & 1) << 0xb |
                                         (ushort)(SUB161(auVar161 >> 0x67,0) & 1) << 0xc |
                                         (ushort)(SUB161(auVar161 >> 0x6f,0) & 1) << 0xd |
                                         (ushort)(SUB161(auVar161 >> 0x77,0) & 1) << 0xe |
                                        (ushort)(auVar161[0xf] >> 7) << 0xf) == 0xffff)
                            goto LAB_140031282;
                          }
                        }
                        else {
                          uStack_10228._4_2_ = (short)((ulonglong)ppuStack_101d8 >> 0x20);
                          if ((*(short *)(lVar80 + -0x32) == uStack_10228._4_2_) &&
                             (uStack_10228._0_4_ = (int)ppuStack_101d8,
                             *(int *)(lVar80 + -0x36) == (int)uStack_10228)) goto LAB_140031282;
                        }
                      }
                      if (((HOST_ID_0_llvm_14435704873730135342 == pauStack_102a8) &&
                          (HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0)) &&
                         (IS_HOST_0_llvm_14435704873730135342 == '\0')) goto LAB_140031282;
                      lVar80 = lVar80 + -0x38;
                      uStack_10438._0_1_ = (byte)uVar112;
                      uStack_10438._1_1_ = (byte)(uVar112 >> 8);
                      uStack_10426 = uStack_101c8;
                      uStack_10438._2_1_ = (byte)ppuStack_101d8;
                      uStack_10438._3_1_ = (byte)((ulonglong)ppuStack_101d8 >> 8);
                      uStack_10438._4_4_ = (int)((ulonglong)ppuStack_101d8 >> 0x10);
                      uStack_1042e = (ushort)ppuStack_101d0;
                      uStack_1042c = (uint)((ulonglong)ppuStack_101d0 >> 0x10);
                      uStack_10424 = (uint)uStack_10460;
                      uStack_1041c = (ushort)uStack_10458;
                      uStack_1041a = (ushort)uStack_104b8;
                      bStack_10528 = (byte)&pauStack_102a8;
                      bStack_10527 = (byte)((ulonglong)&pauStack_102a8 >> 8);
                      bStack_10526 = (byte)((ulonglong)&pauStack_102a8 >> 0x10);
                      bStack_10525 = (byte)((ulonglong)&pauStack_102a8 >> 0x18);
                      bStack_10524 = (byte)((ulonglong)&pauStack_102a8 >> 0x20);
                      bStack_10523 = (byte)((ulonglong)&pauStack_102a8 >> 0x28);
                      bStack_10522 = (byte)((ulonglong)&pauStack_102a8 >> 0x30);
                      bStack_10521 = (byte)((ulonglong)&pauStack_102a8 >> 0x38);
                      bStack_10520 = 0x30;
                      bStack_1051f = 0xf0;
                      bStack_1051e = 0x68;
                      bStack_1051d = 0x40;
                      bStack_1051c = 1;
                      bStack_1051b = 0;
                      bStack_1051a = 0;
                      bStack_10519 = 0;
                      bStack_10518 = (byte)lVar80;
                      bStack_10517 = (byte)((ulonglong)lVar80 >> 8);
                      uStack_10516 = (ushort)((ulonglong)lVar80 >> 0x10);
                      uStack_10514 = (uint)((ulonglong)lVar80 >> 0x20);
                      uStack_10510 = 60000;
                      uStack_1050e = 0x4068;
                      uStack_1050c = 1;
                      uStack_1050a = 0;
                      uStack_10508 = (undefined1 (**) [16])&uStack_10438;
                      uStack_10500._0_4_ = 0x4068ea60;
                      uStack_10500._4_4_ = 1;
                      bStack_10430 = uStack_10228._6_1_;
                      bStack_1042f = uStack_10228._7_1_;
                      bStack_10428 = uStack_10220._6_1_;
                      bStack_10427 = uStack_10220._7_1_;
                      uStack_10420 = (uint)unaff_R15;
                      uStack_10228 = ppuVar70;
                      uStack_10220 = ppuVar71;
                      alloc[246c2e7857c81348]::fmt::format::format_inner
                                (&uStack_103c8,&DAT_1406a23c8,&bStack_10528);
                      ppuVar103 = ppuStack_103c0;
                      pauVar79 = uStack_103c8;
                      host::log(ppuStack_103c0,pauStack_103b8);
                      if (pauVar79 != (undefined1 (*) [16])0x0) {
                        pauVar82 = (undefined1 (*) [16])
                                   __rustc[9d087a5ab36ea756]::__rust_dealloc(ppuVar103,pauVar79,1);
                        return pauVar82;
                      }
                      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                      ::remove::<u64>(&bStack_10528,uStack_10348 + 8,&pauStack_102a8);
                      goto LAB_14003215d;
                    }
                    uVar91 = (ushort)(uVar113 - 1) & (ushort)uVar113;
                    uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar91);
                  }
                  auVar160[0] = -(*pcVar109 == cVar72);
                  auVar160[1] = -(pcVar109[1] == cVar181);
                  auVar160[2] = -(pcVar109[2] == cVar182);
                  auVar160[3] = -(pcVar109[3] == cVar183);
                  auVar160[4] = -(pcVar109[4] == cVar184);
                  auVar160[5] = -(pcVar109[5] == cVar185);
                  auVar160[6] = -(pcVar109[6] == cVar186);
                  auVar160[7] = -(pcVar109[7] == cVar187);
                  auVar160[8] = -(pcVar109[8] == cVar188);
                  auVar160[9] = -(pcVar109[9] == cVar189);
                  auVar160[10] = -(pcVar109[10] == cVar190);
                  auVar160[0xb] = -(pcVar109[0xb] == cVar191);
                  auVar160[0xc] = -(pcVar109[0xc] == cVar192);
                  auVar160[0xd] = -(pcVar109[0xd] == cVar193);
                  auVar160[0xe] = -(pcVar109[0xe] == cVar194);
                  auVar160[0xf] = -(pcVar109[0xf] == cVar195);
                  if ((((((((((((((((SUB161(auVar160 >> 7,0) & 1) != 0 ||
                                   (SUB161(auVar160 >> 0xf,0) & 1) != 0) ||
                                  (SUB161(auVar160 >> 0x17,0) & 1) != 0) ||
                                 (SUB161(auVar160 >> 0x1f,0) & 1) != 0) ||
                                (SUB161(auVar160 >> 0x27,0) & 1) != 0) ||
                               (SUB161(auVar160 >> 0x2f,0) & 1) != 0) ||
                              (SUB161(auVar160 >> 0x37,0) & 1) != 0) ||
                             (SUB161(auVar160 >> 0x3f,0) & 1) != 0) ||
                            (SUB161(auVar160 >> 0x47,0) & 1) != 0) ||
                           (SUB161(auVar160 >> 0x4f,0) & 1) != 0) ||
                          (SUB161(auVar160 >> 0x57,0) & 1) != 0) ||
                         (SUB161(auVar160 >> 0x5f,0) & 1) != 0) ||
                        (SUB161(auVar160 >> 0x67,0) & 1) != 0) ||
                       (SUB161(auVar160 >> 0x6f,0) & 1) != 0) ||
                      (SUB161(auVar160 >> 0x77,0) & 1) != 0) || auVar160[0xf] < '\0') break;
                  uVar81 = uVar81 + lVar120 + 0x10;
                  lVar120 = lVar120 + 0x10;
                }
              }
              if (bVar129) {
                bStack_10528 = (byte)&pauStack_102a8;
                bStack_10527 = (byte)((ulonglong)&pauStack_102a8 >> 8);
                bStack_10526 = (byte)((ulonglong)&pauStack_102a8 >> 0x10);
                bStack_10525 = (byte)((ulonglong)&pauStack_102a8 >> 0x18);
                bStack_10524 = (byte)((ulonglong)&pauStack_102a8 >> 0x20);
                bStack_10523 = (byte)((ulonglong)&pauStack_102a8 >> 0x28);
                bStack_10522 = (byte)((ulonglong)&pauStack_102a8 >> 0x30);
                bStack_10521 = (byte)((ulonglong)&pauStack_102a8 >> 0x38);
                bStack_10520 = 0x30;
                bStack_1051f = 0xf0;
                bStack_1051e = 0x68;
                bStack_1051d = 0x40;
                bStack_1051c = 1;
                bStack_1051b = 0;
                bStack_1051a = 0;
                bStack_10519 = 0;
                bStack_10518 = (byte)&uStack_103a8;
                bStack_10517 = (byte)((ulonglong)&uStack_103a8 >> 8);
                uStack_10516 = (ushort)((ulonglong)&uStack_103a8 >> 0x10);
                uStack_10514 = (uint)((ulonglong)&uStack_103a8 >> 0x20);
                uStack_10510 = 60000;
                uStack_1050e = 0x4068;
                uStack_1050c = 1;
                uStack_1050a = 0;
                alloc[246c2e7857c81348]::fmt::format::format_inner
                          (&uStack_10438,&DAT_1406a2460,&bStack_10528);
                lVar80 = CONCAT44(uStack_10438._4_4_,
                                  CONCAT13(uStack_10438._3_1_,
                                           CONCAT12(uStack_10438._2_1_,
                                                    CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))
                                          ));
                uVar85 = CONCAT44(uStack_1042c,
                                  CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
                host::log(uVar85,CONCAT44(uStack_10424,
                                          CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428))
                                         ));
                ppuVar70 = uStack_10228;
                ppuVar71 = uStack_10220;
                if (lVar80 != 0) {
                  pauVar82 = (undefined1 (*) [16])
                             __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar80,1);
                  return pauVar82;
                }
              }
              else {
LAB_14003215d:
                bStack_10528 = (byte)&pauStack_102a8;
                bStack_10527 = (byte)((ulonglong)&pauStack_102a8 >> 8);
                bStack_10526 = (byte)((ulonglong)&pauStack_102a8 >> 0x10);
                bStack_10525 = (byte)((ulonglong)&pauStack_102a8 >> 0x18);
                bStack_10524 = (byte)((ulonglong)&pauStack_102a8 >> 0x20);
                bStack_10523 = (byte)((ulonglong)&pauStack_102a8 >> 0x28);
                bStack_10522 = (byte)((ulonglong)&pauStack_102a8 >> 0x30);
                bStack_10521 = (byte)((ulonglong)&pauStack_102a8 >> 0x38);
                bStack_10520 = 0x30;
                bStack_1051f = 0xf0;
                bStack_1051e = 0x68;
                bStack_1051d = 0x40;
                bStack_1051c = 1;
                bStack_1051b = 0;
                bStack_1051a = 0;
                bStack_10519 = 0;
                bStack_10518 = (byte)&uStack_103a8;
                bStack_10517 = (byte)((ulonglong)&uStack_103a8 >> 8);
                uStack_10516 = (ushort)((ulonglong)&uStack_103a8 >> 0x10);
                uStack_10514 = (uint)((ulonglong)&uStack_103a8 >> 0x20);
                uStack_10510 = 60000;
                uStack_1050e = 0x4068;
                uStack_1050c = 1;
                uStack_1050a = 0;
                alloc[246c2e7857c81348]::fmt::format::format_inner
                          (&uStack_10438,&DAT_1406a2403,&bStack_10528);
                lVar80 = CONCAT44(uStack_10438._4_4_,
                                  CONCAT13(uStack_10438._3_1_,
                                           CONCAT12(uStack_10438._2_1_,
                                                    CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))
                                          ));
                uVar85 = CONCAT44(uStack_1042c,
                                  CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
                uVar78 = CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428));
                host::log(uVar85);
                pcVar109 = uStack_10348;
                if (lVar80 != 0) {
                  pauVar82 = (undefined1 (*) [16])
                             __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar80,1);
                  return pauVar82;
                }
                uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
                uStack_10514 = CONCAT22(uStack_103a2,uStack_103a4);
                uStack_10508._0_4_ = CONCAT22(uStack_10396,uStack_10398);
                uStack_10508._4_4_ = uStack_10394;
                uStack_10500._0_4_ = (uint)uStack_10390;
                uStack_10500._4_4_ = (uint)(uStack_10390 >> 0x20);
                bStack_10518 = (byte)uStack_103a8;
                bStack_10517 = (byte)(uStack_103a8 >> 8);
                uStack_10516 = uStack_103a6;
                uStack_10510 = uStack_103a0;
                uStack_1050e = uStack_1039e;
                uStack_1050c = (ushort)uStack_1039c;
                uStack_1050a = (ushort)(uStack_1039c >> 0x10);
                uStack_104f8._0_4_ = (uint)uStack_104f8 & 0xffffff00;
                bStack_10528 = (byte)uVar85;
                bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
                bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
                bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
                bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
                bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
                bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
                bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
                bStack_10520 = (byte)uVar78;
                bStack_1051f = (byte)((uint)uVar78 >> 8);
                bStack_1051e = (byte)((uint)uVar78 >> 0x10);
                bStack_1051d = (byte)((uint)uVar78 >> 0x18);
                <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                ::insert(&uStack_10438,pcVar109 + 8,pauStack_102a8,&bStack_10528);
                puVar99 = &GREETING;
                <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
                ::lock(&bStack_10528);
                bVar75 = bStack_10518;
                if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))
                            ) == 1) {
                  uStack_10438._4_4_ =
                       CONCAT13(bStack_10519,
                                CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
                  uStack_10438._0_1_ = bStack_10520;
                  uStack_10438._1_1_ = bStack_1051f;
                  uStack_10438._2_1_ = bStack_1051e;
                  uStack_10438._3_1_ = bStack_1051d;
                  bStack_10430 = bStack_10518;
                  core[505b25137b8ba7f]::result::unwrap_failed
                            ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                             &
                             PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0f10
                             ,&
                              PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2448
                            );
                  goto LAB_140036cf0;
                }
                pcVar109 = (char *)CONCAT17(bStack_10519,
                                            CONCAT16(bStack_1051a,
                                                     CONCAT15(bStack_1051b,
                                                              CONCAT14(bStack_1051c,
                                                                       CONCAT13(bStack_1051d,
                                                                                CONCAT12(
                                                  bStack_1051e,CONCAT11(bStack_1051f,bStack_10520)))
                                                  ))));
                if (*(longlong *)(pcVar109 + 8) == 0) {
                  uVar85 = <std[3bf9d48a0c3997f0]::thread::local::LocalKey<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>>>
                           ::with::
                           <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::_closure_0_,std[3bf9d48a0c3997f0]::hash::random::RandomState>
                                     (&PTR_call_once_1406a06c0);
                  pcVar109[0x18] = '\0';
                  pcVar109[0x19] = '\0';
                  pcVar109[0x1a] = '\0';
                  pcVar109[0x1b] = '\0';
                  pcVar109[0x1c] = '\0';
                  pcVar109[0x1d] = '\0';
                  pcVar109[0x1e] = '\0';
                  pcVar109[0x1f] = '\0';
                  pcVar109[0x20] = '\0';
                  pcVar109[0x21] = '\0';
                  pcVar109[0x22] = '\0';
                  pcVar109[0x23] = '\0';
                  pcVar109[0x24] = '\0';
                  pcVar109[0x25] = '\0';
                  pcVar109[0x26] = '\0';
                  pcVar109[0x27] = '\0';
                  *(undefined **)(pcVar109 + 8) = &DAT_1406a0540;
                  pcVar109[0x10] = '\0';
                  pcVar109[0x11] = '\0';
                  pcVar109[0x12] = '\0';
                  pcVar109[0x13] = '\0';
                  pcVar109[0x14] = '\0';
                  pcVar109[0x15] = '\0';
                  pcVar109[0x16] = '\0';
                  pcVar109[0x17] = '\0';
                  *(undefined8 *)(pcVar109 + 0x28) = uVar85;
                  *(undefined1 **)(pcVar109 + 0x30) = puVar99;
                }
                uVar113 = (uint)puVar99;
                uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
                uStack_10438._4_4_ = CONCAT22(uStack_103a2,uStack_103a4);
                bStack_10428 = (byte)uStack_10398;
                bStack_10427 = (byte)(uStack_10398 >> 8);
                uStack_10426 = uStack_10396;
                uStack_10424 = uStack_10394;
                uStack_10420 = (uint)uStack_10390;
                uStack_1041c = (ushort)(uStack_10390 >> 0x20);
                uStack_1041a = (ushort)(uStack_10390 >> 0x30);
                uStack_10438._0_1_ = (byte)uStack_103a8;
                uStack_10438._1_1_ = (byte)(uStack_103a8 >> 8);
                uStack_10438._2_1_ = (byte)uStack_103a6;
                uStack_10438._3_1_ = (byte)(uStack_103a6 >> 8);
                bStack_10430 = (byte)uStack_103a0;
                bStack_1042f = (byte)(uStack_103a0 >> 8);
                uStack_1042e = uStack_1039e;
                uStack_1042c = uStack_1039c;
                <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,u32,std[3bf9d48a0c3997f0]::time::Instant),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                ::rustc_entry(&bStack_10528,pcVar109 + 8,pauStack_102a8);
                lVar80 = CONCAT17(bStack_10521,
                                  CONCAT16(bStack_10522,
                                           CONCAT15(bStack_10523,
                                                    CONCAT14(bStack_10524,
                                                             CONCAT13(bStack_10525,
                                                                      CONCAT12(bStack_10526,
                                                                               CONCAT11(bStack_10527
                                                                                        ,
                                                  bStack_10528)))))));
                if (lVar80 != 0) {
                  uVar4 = CONCAT17(bStack_10519,
                                   CONCAT16(bStack_1051a,
                                            CONCAT15(bStack_1051b,
                                                     CONCAT14(bStack_1051c,
                                                              CONCAT13(bStack_1051d,
                                                                       CONCAT12(bStack_1051e,
                                                                                CONCAT11(
                                                  bStack_1051f,bStack_10520)))))));
                  bStack_10528 = bStack_10518;
                  bStack_10527 = bStack_10517;
                  bStack_10526 = (byte)uStack_10516;
                  bStack_10525 = (byte)(uStack_10516 >> 8);
                  bStack_10524 = (byte)uStack_10514;
                  bStack_10523 = (byte)(uStack_10514 >> 8);
                  bStack_10522 = (byte)(uStack_10514 >> 0x10);
                  bStack_10521 = (byte)(uStack_10514 >> 0x18);
                  uStack_10510 = CONCAT11(bStack_10427,bStack_10428);
                  uStack_1050e = uStack_10426;
                  uStack_1050c = (ushort)uStack_10424;
                  uStack_1050a = (ushort)(uStack_10424 >> 0x10);
                  uStack_10508._0_4_ = uStack_10420;
                  uStack_10508._4_4_ =
                       (uint)(CONCAT26(uStack_1041a,CONCAT24(uStack_1041c,uStack_10420)) >> 0x20);
                  bStack_10520 = (byte)uStack_10438;
                  bStack_1051f = uStack_10438._1_1_;
                  bStack_1051e = uStack_10438._2_1_;
                  bStack_1051d = uStack_10438._3_1_;
                  bStack_1051c = (byte)uStack_10438._4_4_;
                  bStack_1051b = (byte)((uint)uStack_10438._4_4_ >> 8);
                  bStack_1051a = (byte)((uint)uStack_10438._4_4_ >> 0x10);
                  bStack_10519 = (byte)((uint)uStack_10438._4_4_ >> 0x18);
                  bStack_10518 = bStack_10430;
                  bStack_10517 = bStack_1042f;
                  uStack_10516 = uStack_1042e;
                  uStack_10514 = uStack_1042c;
                  uStack_10500._0_4_ = 0;
                  uStack_104f8._0_4_ = (uint)uVar85;
                  uStack_104f8._4_4_ = (uint)((ulonglong)uVar85 >> 0x20);
                  uStack_104f0 = uVar113;
                  <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,u32,std[3bf9d48a0c3997f0]::time::Instant))>>
                  ::insert_no_grow(lVar80,uVar4,&bStack_10528);
                }
                if ((bVar75 == 0) &&
                   ((*(ulonglong *)
                      __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                    0x7fffffffffffffff) != 0)) {
                  cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
                  if (cVar74 == '\0') {
                    pcVar109[1] = '\x01';
                  }
                }
                LOCK();
                cVar74 = *pcVar109;
                *pcVar109 = '\0';
                UNLOCK();
                ppuVar70 = uStack_10228;
                ppuVar71 = uStack_10220;
                if (cVar74 == '\x02') {
                  <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
                  ppuVar70 = uStack_10228;
                  ppuVar71 = uStack_10220;
                }
              }
            }
LAB_140031282:
            uStack_10220 = ppuVar71;
            uStack_10228 = ppuVar70;
            pauVar82 = (undefined1 (*) [16])(pauVar82[2] + 8);
          } while (pauVar82 != uStack_104c0);
        }
        if (lStack_101f8 != 0) {
          pauVar82 = (undefined1 (*) [16])
                     __rustc[9d087a5ab36ea756]::__rust_dealloc(pauStack_10350,lStack_101f8 * 0x28,8)
          ;
          return pauVar82;
        }
      }
      pcVar109 = uStack_10348;
      if (((char)uStack_10340 == '\0') &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        goto LAB_140034097;
      }
    }
    else {
LAB_14002e558:
      pcVar109 = uStack_10348;
      if (((char)uStack_10340 == '\0') &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
LAB_140034097:
        if (cVar74 == '\0') {
          pcVar109[1] = '\x01';
        }
      }
    }
    LOCK();
    cVar74 = *pcVar109;
    *pcVar109 = '\0';
    UNLOCK();
    bVar76 = bStack_10526;
    bVar73 = bStack_10525;
    bVar54 = bStack_10524;
    bVar55 = bStack_10523;
    bVar132 = bStack_10522;
    bVar56 = bStack_10521;
    bVar57 = bStack_10520;
    bVar58 = bStack_1051f;
    bVar59 = bStack_1051e;
    bVar60 = bStack_1051d;
    bVar61 = bStack_1051c;
    bVar62 = bStack_1051b;
    bVar63 = bStack_1051a;
    bVar64 = bStack_10519;
    bVar65 = bStack_10518;
    bVar66 = bStack_10517;
    uVar112 = uStack_10510;
    uVar91 = uStack_1050e;
    uVar68 = uStack_1050c;
    uVar69 = uStack_1050a;
    if (cVar74 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
      bVar76 = bStack_10526;
      bVar73 = bStack_10525;
      bVar54 = bStack_10524;
      bVar55 = bStack_10523;
      bVar132 = bStack_10522;
      bVar56 = bStack_10521;
      bVar57 = bStack_10520;
      bVar58 = bStack_1051f;
      bVar59 = bStack_1051e;
      bVar60 = bStack_1051d;
      bVar61 = bStack_1051c;
      bVar62 = bStack_1051b;
      bVar63 = bStack_1051a;
      bVar64 = bStack_10519;
      bVar65 = bStack_10518;
      bVar66 = bStack_10517;
      uVar112 = uStack_10510;
      uVar91 = uStack_1050e;
      uVar68 = uStack_1050c;
      uVar69 = uStack_1050a;
    }
    goto LAB_1400331c4;
  }
  if (*plVar94 != 0x31435254532d5252) {
    if (*plVar94 == 0x31454c49462d5252) {
      LOCK();
      bVar129 = DAT_140699948 == '\0';
      if (bVar129) {
        DAT_140699948 = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar76 = 0;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar76 = bVar76 ^ 1;
      }
      if (DAT_140699949 == '\0') {
        in_stack_fffffffffffefaa8 =
             (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),bStack_10471);
        cVar74 = is_host_route(&DAT_140699950,
                               HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0 &&
                               IS_HOST_0_llvm_14435704873730135342 == '\0',
                               HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,
                               in_stack_fffffffffffefaa8,CONCAT17(bStack_10469,uStack_10470),
                               CONCAT17(bStack_10461,uStack_10468));
        pauVar82 = HOST_ID_0_llvm_14435704873730135342;
        if (((cVar74 == '\0') || (HOST_ID_0_llvm_14435704873730135342 == (undefined1 (*) [16])0x0))
           || (IS_HOST_0_llvm_14435704873730135342 != '\0')) {
          if ((bVar76 == 0) &&
             ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) != 0)) {
            cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            if (cVar74 == '\0') {
              DAT_140699949 = '\x01';
            }
          }
          cVar74 = DAT_140699948;
          LOCK();
          DAT_140699948 = '\0';
          UNLOCK();
          bVar76 = bStack_10526;
          bVar73 = bStack_10525;
          bVar54 = bStack_10524;
          bVar55 = bStack_10523;
          bVar132 = bStack_10522;
          bVar56 = bStack_10521;
          bVar57 = bStack_10520;
          bVar58 = bStack_1051f;
          bVar59 = bStack_1051e;
          bVar60 = bStack_1051d;
          bVar61 = bStack_1051c;
          bVar62 = bStack_1051b;
          bVar63 = bStack_1051a;
          bVar64 = bStack_10519;
          bVar65 = bStack_10518;
          bVar66 = bStack_10517;
          uVar112 = uStack_10510;
          uVar91 = uStack_1050e;
          uVar68 = uStack_1050c;
          uVar69 = uStack_1050a;
          if (cVar74 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
            bVar76 = bStack_10526;
            bVar73 = bStack_10525;
            bVar54 = bStack_10524;
            bVar55 = bStack_10523;
            bVar132 = bStack_10522;
            bVar56 = bStack_10521;
            bVar57 = bStack_10520;
            bVar58 = bStack_1051f;
            bVar59 = bStack_1051e;
            bVar60 = bStack_1051d;
            bVar61 = bStack_1051c;
            bVar62 = bStack_1051b;
            bVar63 = bStack_1051a;
            bVar64 = bStack_10519;
            bVar65 = bStack_10518;
            bVar66 = bStack_10517;
            uVar112 = uStack_10510;
            uVar91 = uStack_1050e;
            uVar68 = uStack_1050c;
            uVar69 = uStack_1050a;
          }
        }
        else {
          bStack_10528 = (byte)HOST_ID_0_llvm_14435704873730135342;
          bStack_10527 = (byte)((ulonglong)HOST_ID_0_llvm_14435704873730135342 >> 8);
          bStack_10526 = (byte)((ulonglong)HOST_ID_0_llvm_14435704873730135342 >> 0x10);
          bStack_10525 = (byte)((ulonglong)HOST_ID_0_llvm_14435704873730135342 >> 0x18);
          bStack_10524 = (byte)((ulonglong)HOST_ID_0_llvm_14435704873730135342 >> 0x20);
          bStack_10523 = (byte)((ulonglong)HOST_ID_0_llvm_14435704873730135342 >> 0x28);
          bStack_10522 = (byte)((ulonglong)HOST_ID_0_llvm_14435704873730135342 >> 0x30);
          bStack_10521 = (byte)((ulonglong)HOST_ID_0_llvm_14435704873730135342 >> 0x38);
          iVar127 = -1;
          if (DAT_140699968 != 0) {
            uVar117 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                      ::hash_one::<&usize>(&DAT_140699970,&bStack_10528);
            bVar75 = (byte)(uVar117 >> 0x39);
            auVar133 = ZEXT216(CONCAT11(bVar75,bVar75));
            auVar133 = pshuflw(auVar133,auVar133,0);
            lVar80 = 0;
            while( true ) {
              uVar117 = uVar117 & DAT_140699958;
              pcVar109 = *DAT_140699950 + uVar117;
              auVar175[0] = -(*pcVar109 == auVar133[0]);
              auVar175[1] = -(pcVar109[1] == auVar133[1]);
              auVar175[2] = -(pcVar109[2] == auVar133[2]);
              auVar175[3] = -(pcVar109[3] == auVar133[3]);
              auVar175[4] = -(pcVar109[4] == auVar133[4]);
              auVar175[5] = -(pcVar109[5] == auVar133[5]);
              auVar175[6] = -(pcVar109[6] == auVar133[6]);
              auVar175[7] = -(pcVar109[7] == auVar133[7]);
              auVar175[8] = -(pcVar109[8] == auVar133[0]);
              auVar175[9] = -(pcVar109[9] == auVar133[1]);
              auVar175[10] = -(pcVar109[10] == auVar133[2]);
              auVar175[0xb] = -(pcVar109[0xb] == auVar133[3]);
              auVar175[0xc] = -(pcVar109[0xc] == auVar133[4]);
              auVar175[0xd] = -(pcVar109[0xd] == auVar133[5]);
              auVar175[0xe] = -(pcVar109[0xe] == auVar133[6]);
              auVar175[0xf] = -(pcVar109[0xf] == auVar133[7]);
              uVar112 = (ushort)(SUB161(auVar175 >> 7,0) & 1) |
                        (ushort)(SUB161(auVar175 >> 0xf,0) & 1) << 1 |
                        (ushort)(SUB161(auVar175 >> 0x17,0) & 1) << 2 |
                        (ushort)(SUB161(auVar175 >> 0x1f,0) & 1) << 3 |
                        (ushort)(SUB161(auVar175 >> 0x27,0) & 1) << 4 |
                        (ushort)(SUB161(auVar175 >> 0x2f,0) & 1) << 5 |
                        (ushort)(SUB161(auVar175 >> 0x37,0) & 1) << 6 |
                        (ushort)(SUB161(auVar175 >> 0x3f,0) & 1) << 7 |
                        (ushort)(SUB161(auVar175 >> 0x47,0) & 1) << 8 |
                        (ushort)(SUB161(auVar175 >> 0x4f,0) & 1) << 9 |
                        (ushort)(SUB161(auVar175 >> 0x57,0) & 1) << 10 |
                        (ushort)(SUB161(auVar175 >> 0x5f,0) & 1) << 0xb |
                        (ushort)(SUB161(auVar175 >> 0x67,0) & 1) << 0xc |
                        (ushort)(SUB161(auVar175 >> 0x6f,0) & 1) << 0xd |
                        (ushort)(SUB161(auVar175 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar175[0xf] >> 7) << 0xf;
              uVar113 = (uint)uVar112;
              while (uVar112 != 0) {
                uVar114 = 0;
                for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
                  uVar114 = uVar114 + 1;
                }
                uVar81 = uVar114 + uVar117 & DAT_140699958;
                if (pauVar82 == *(undefined1 (**) [16])DAT_140699950[uVar81 * -5 + -5]) {
                  uStack_10178 = *(undefined8 *)(DAT_140699950[uVar81 * -5 + -5] + 8);
                  iVar127 = *(int *)DAT_140699950[uVar81 * -5 + -4];
                  uStack_10408 = (uint)((ulonglong)*(undefined8 *)DAT_140699950[uVar81 * -5 + -1] >>
                                       0x20);
                  uStack_10404 = (uint)*(undefined8 *)(DAT_140699950[uVar81 * -5 + -1] + 8);
                  uStack_10400 = (uint)((ulonglong)
                                        *(undefined8 *)(DAT_140699950[uVar81 * -5 + -1] + 8) >> 0x20
                                       );
                  uStack_10418 = (uint)*(undefined8 *)(DAT_140699950[uVar81 * -5 + -2] + 4);
                  uStack_10414 = (undefined4)
                                 ((ulonglong)*(undefined8 *)(DAT_140699950[uVar81 * -5 + -2] + 4) >>
                                 0x20);
                  uStack_10410 = (undefined4)*(undefined8 *)(DAT_140699950[uVar81 * -5 + -2] + 0xc);
                  uStack_1040c = (uint)((ulonglong)
                                        *(undefined8 *)(DAT_140699950[uVar81 * -5 + -2] + 0xc) >>
                                       0x20);
                  uVar85 = *(undefined8 *)(DAT_140699950[uVar81 * -5 + -3] + 4);
                  uVar4 = *(undefined8 *)(DAT_140699950[uVar81 * -5 + -3] + 0xc);
                  bStack_10428 = (byte)uVar85;
                  bStack_10427 = (byte)((ulonglong)uVar85 >> 8);
                  uStack_10426 = (ushort)((ulonglong)uVar85 >> 0x10);
                  uStack_10424 = (uint)((ulonglong)uVar85 >> 0x20);
                  uStack_10420 = (uint)uVar4;
                  uStack_1041c = (ushort)((ulonglong)uVar4 >> 0x20);
                  uStack_1041a = (ushort)((ulonglong)uVar4 >> 0x30);
                  uVar85 = *(undefined8 *)(DAT_140699950[uVar81 * -5 + -4] + 4);
                  uVar4 = *(undefined8 *)(DAT_140699950[uVar81 * -5 + -4] + 0xc);
                  uStack_10438._0_1_ = (byte)uVar85;
                  uStack_10438._1_1_ = (byte)((ulonglong)uVar85 >> 8);
                  uStack_10438._2_1_ = (byte)((ulonglong)uVar85 >> 0x10);
                  uStack_10438._3_1_ = (byte)((ulonglong)uVar85 >> 0x18);
                  uStack_10438._4_4_ = (int)((ulonglong)uVar85 >> 0x20);
                  bStack_10430 = (byte)uVar4;
                  bStack_1042f = (byte)((ulonglong)uVar4 >> 8);
                  uStack_1042e = (ushort)((ulonglong)uVar4 >> 0x10);
                  uStack_1042c = (uint)((ulonglong)uVar4 >> 0x20);
                  goto LAB_140032c9e;
                }
                uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
                uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
              }
              auVar156[0] = -(*pcVar109 == cVar72);
              auVar156[1] = -(pcVar109[1] == cVar181);
              auVar156[2] = -(pcVar109[2] == cVar182);
              auVar156[3] = -(pcVar109[3] == cVar183);
              auVar156[4] = -(pcVar109[4] == cVar184);
              auVar156[5] = -(pcVar109[5] == cVar185);
              auVar156[6] = -(pcVar109[6] == cVar186);
              auVar156[7] = -(pcVar109[7] == cVar187);
              auVar156[8] = -(pcVar109[8] == cVar188);
              auVar156[9] = -(pcVar109[9] == cVar189);
              auVar156[10] = -(pcVar109[10] == cVar190);
              auVar156[0xb] = -(pcVar109[0xb] == cVar191);
              auVar156[0xc] = -(pcVar109[0xc] == cVar192);
              auVar156[0xd] = -(pcVar109[0xd] == cVar193);
              auVar156[0xe] = -(pcVar109[0xe] == cVar194);
              auVar156[0xf] = -(pcVar109[0xf] == cVar195);
              if ((((((((((((((((SUB161(auVar156 >> 7,0) & 1) != 0 ||
                               (SUB161(auVar156 >> 0xf,0) & 1) != 0) ||
                              (SUB161(auVar156 >> 0x17,0) & 1) != 0) ||
                             (SUB161(auVar156 >> 0x1f,0) & 1) != 0) ||
                            (SUB161(auVar156 >> 0x27,0) & 1) != 0) ||
                           (SUB161(auVar156 >> 0x2f,0) & 1) != 0) ||
                          (SUB161(auVar156 >> 0x37,0) & 1) != 0) ||
                         (SUB161(auVar156 >> 0x3f,0) & 1) != 0) ||
                        (SUB161(auVar156 >> 0x47,0) & 1) != 0) ||
                       (SUB161(auVar156 >> 0x4f,0) & 1) != 0) ||
                      (SUB161(auVar156 >> 0x57,0) & 1) != 0) ||
                     (SUB161(auVar156 >> 0x5f,0) & 1) != 0) || (SUB161(auVar156 >> 0x67,0) & 1) != 0
                    ) || (SUB161(auVar156 >> 0x6f,0) & 1) != 0) ||
                  (SUB161(auVar156 >> 0x77,0) & 1) != 0) || auVar156[0xf] < '\0') break;
              uVar117 = uVar117 + lVar80 + 0x10;
              lVar80 = lVar80 + 0x10;
            }
          }
LAB_140032c9e:
          if ((bVar76 == 0) &&
             ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) != 0)) {
            cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            if (cVar74 == '\0') {
              DAT_140699949 = '\x01';
            }
          }
          cVar74 = DAT_140699948;
          LOCK();
          DAT_140699948 = '\0';
          UNLOCK();
          if (cVar74 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
          }
          bVar76 = bStack_10526;
          bVar73 = bStack_10525;
          bVar54 = bStack_10524;
          bVar55 = bStack_10523;
          bVar132 = bStack_10522;
          bVar56 = bStack_10521;
          bVar57 = bStack_10520;
          bVar58 = bStack_1051f;
          bVar59 = bStack_1051e;
          bVar60 = bStack_1051d;
          bVar61 = bStack_1051c;
          bVar62 = bStack_1051b;
          bVar63 = bStack_1051a;
          bVar64 = bStack_10519;
          bVar65 = bStack_10518;
          bVar66 = bStack_10517;
          uVar112 = uStack_10510;
          uVar91 = uStack_1050e;
          uVar68 = uStack_1050c;
          uVar69 = uStack_1050a;
          if (iVar127 != -1) {
            bStack_10528 = (byte)uStack_10178;
            bStack_10527 = (byte)((ulonglong)uStack_10178 >> 8);
            bStack_10526 = (byte)((ulonglong)uStack_10178 >> 0x10);
            bStack_10525 = (byte)((ulonglong)uStack_10178 >> 0x18);
            bStack_10524 = (byte)((ulonglong)uStack_10178 >> 0x20);
            bStack_10523 = (byte)((ulonglong)uStack_10178 >> 0x28);
            bStack_10522 = (byte)((ulonglong)uStack_10178 >> 0x30);
            bStack_10521 = (byte)((ulonglong)uStack_10178 >> 0x38);
            bStack_10520 = (byte)iVar127;
            bStack_1051f = (byte)((uint)iVar127 >> 8);
            bStack_1051e = (byte)((uint)iVar127 >> 0x10);
            bStack_1051d = (byte)((uint)iVar127 >> 0x18);
            uStack_104ec = uStack_10408;
            uStack_104e8 = uStack_10404;
            uStack_104e4 = uStack_10400;
            uStack_10514 = CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430));
            uStack_1050c = CONCAT11(bStack_10427,bStack_10428);
            uStack_10500._4_4_ = uStack_10418;
            uStack_104f8._0_4_ = uStack_10414;
            uStack_104f8._4_4_ = uStack_10410;
            uStack_104f0 = uStack_1040c;
            uStack_1050a = uStack_10426;
            uStack_10508._0_4_ = uStack_10424;
            uStack_10508._4_4_ = uStack_10420;
            uStack_10500._0_4_ =
                 (uint)(CONCAT26(uStack_1041a,CONCAT24(uStack_1041c,uStack_10420)) >> 0x20);
            bStack_1051c = (byte)uStack_10438;
            bStack_1051b = uStack_10438._1_1_;
            bStack_1051a = uStack_10438._2_1_;
            bStack_10519 = uStack_10438._3_1_;
            bStack_10518 = (byte)uStack_10438._4_4_;
            bStack_10517 = (byte)((uint)uStack_10438._4_4_ >> 8);
            uStack_10516 = (ushort)((uint)uStack_10438._4_4_ >> 0x10);
            uStack_10510 = (ushort)uStack_1042c;
            uStack_1050e = (ushort)(uStack_1042c >> 0x10);
            fileshare::received(&uStack_103a8,uStack_104b0,pauStack_10538);
            lVar80 = CONCAT26(uStack_103a2,
                              CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
            bVar76 = bStack_10526;
            bVar73 = bStack_10525;
            bVar54 = bStack_10524;
            bVar55 = bStack_10523;
            bVar132 = bStack_10522;
            bVar56 = bStack_10521;
            bVar57 = bStack_10520;
            bVar58 = bStack_1051f;
            bVar59 = bStack_1051e;
            bVar60 = bStack_1051d;
            bVar61 = bStack_1051c;
            bVar62 = bStack_1051b;
            bVar63 = bStack_1051a;
            bVar64 = bStack_10519;
            bVar65 = bStack_10518;
            bVar66 = bStack_10517;
            uVar112 = uStack_10510;
            uVar91 = uStack_1050e;
            uVar68 = uStack_1050c;
            uVar69 = uStack_1050a;
            if (lVar80 != -1) {
              uVar85 = CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
              in_stack_fffffffffffefaa8 =
                   (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),1);
              send_route_kind(&TRANSPORT,&bStack_10528,uVar85,
                              CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398)),
                              in_stack_fffffffffffefaa8);
              bVar76 = bStack_10526;
              bVar73 = bStack_10525;
              bVar54 = bStack_10524;
              bVar55 = bStack_10523;
              bVar132 = bStack_10522;
              bVar56 = bStack_10521;
              bVar57 = bStack_10520;
              bVar58 = bStack_1051f;
              bVar59 = bStack_1051e;
              bVar60 = bStack_1051d;
              bVar61 = bStack_1051c;
              bVar62 = bStack_1051b;
              bVar63 = bStack_1051a;
              bVar64 = bStack_10519;
              bVar65 = bStack_10518;
              bVar66 = bStack_10517;
              uVar112 = uStack_10510;
              uVar91 = uStack_1050e;
              uVar68 = uStack_1050c;
              uVar69 = uStack_1050a;
              if (lVar80 != 0) {
                pauVar82 = (undefined1 (*) [16])
                           __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar80,1);
                return pauVar82;
              }
            }
          }
        }
        goto LAB_1400331c4;
      }
      bStack_10528 = 0x48;
      bStack_10527 = 0x99;
      bStack_10526 = 0x69;
      bStack_10525 = 0x40;
      bStack_10524 = 1;
      bStack_10523 = 0;
      bStack_10522 = 0;
      bStack_10521 = 0;
      bStack_10520 = bVar76;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2d68);
      goto LAB_140036cf0;
    }
    if (*plVar94 != 0x314b4341462d5252) {
      if (*plVar94 != 0x3145544f562d5252) goto LAB_14002e43b;
      <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
      ::lock(&bStack_10528,&DAT_140699948);
      bVar76 = bStack_10518;
      if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
        uStack_10438._4_4_ =
             CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
        uStack_10438._0_1_ = bStack_10520;
        uStack_10438._1_1_ = bStack_1051f;
        uStack_10438._2_1_ = bStack_1051e;
        uStack_10438._3_1_ = bStack_1051d;
        bStack_10430 = bStack_10518;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                   &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2d38)
        ;
        goto LAB_140036cf0;
      }
      pcVar109 = (char *)CONCAT17(bStack_10519,
                                  CONCAT16(bStack_1051a,
                                           CONCAT15(bStack_1051b,
                                                    CONCAT14(bStack_1051c,
                                                             CONCAT13(bStack_1051d,
                                                                      CONCAT12(bStack_1051e,
                                                                               CONCAT11(bStack_1051f
                                                                                        ,
                                                  bStack_10520)))))));
      if (IS_HOST_0_llvm_14435704873730135342 == '\0') {
        in_stack_fffffffffffefaa8 =
             (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),bStack_10471);
        cVar74 = is_host_route(pcVar109 + 8,
                               HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0,
                               HOST_ID_0_llvm_14435704873730135342,&bStack_104a8,
                               in_stack_fffffffffffefaa8,CONCAT17(bStack_10469,uStack_10470),
                               CONCAT17(bStack_10461,uStack_10468));
        if (cVar74 != '\0') {
          if ((bVar76 == 0) &&
             ((*(ulonglong *)
                __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
              0x7fffffffffffffff) != 0)) {
            cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
            if (cVar72 == '\0') {
              pcVar109[1] = '\x01';
            }
          }
          LOCK();
          cVar72 = *pcVar109;
          *pcVar109 = '\0';
          UNLOCK();
          if (cVar72 == '\x02') {
            <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
          }
          vote::from_host(uStack_104b0,pauStack_10538);
          goto LAB_1400331d8;
        }
      }
      else {
        pbVar101 = &bStack_104a8;
        lVar80 = route_peer(pcVar109 + 8,pbVar101,&bStack_10471);
        if (lVar80 == 1) {
          cVar74 = is_blocked(pbVar101,&bStack_104a8);
          if (cVar74 == '\0') {
            if ((bVar76 == 0) &&
               ((*(ulonglong *)
                  __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
                0x7fffffffffffffff) != 0)) {
              cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
              if (cVar72 == '\0') {
                pcVar109[1] = '\x01';
              }
            }
            LOCK();
            cVar72 = *pcVar109;
            *pcVar109 = '\0';
            UNLOCK();
            if (cVar72 == '\x02') {
              <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
            }
            vote::ballot_from(pbVar101,uStack_104b0,pauStack_10538);
            goto LAB_1400331d8;
          }
        }
      }
      if ((bVar76 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          pcVar109[1] = '\x01';
        }
      }
      LOCK();
      cVar74 = *pcVar109;
      *pcVar109 = '\0';
      UNLOCK();
      cStack_10530 = '\x01';
      if (cVar74 == '\x02') goto LAB_140033f4e;
      goto LAB_1400331d8;
    }
    if (IS_HOST_0_llvm_14435704873730135342 == '\0') goto LAB_1400331d8;
    <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
    ::lock(&bStack_10528,&DAT_140699948);
    bVar76 = bStack_10518;
    if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
      uStack_10438._4_4_ =
           CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
      uStack_10438._0_1_ = bStack_10520;
      uStack_10438._1_1_ = bStack_1051f;
      uStack_10438._2_1_ = bStack_1051e;
      uStack_10438._3_1_ = bStack_1051d;
      bStack_10430 = bStack_10518;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2d50);
      goto LAB_140036cf0;
    }
    pcVar109 = (char *)CONCAT17(bStack_10519,
                                CONCAT16(bStack_1051a,
                                         CONCAT15(bStack_1051b,
                                                  CONCAT14(bStack_1051c,
                                                           CONCAT13(bStack_1051d,
                                                                    CONCAT12(bStack_1051e,
                                                                             CONCAT11(bStack_1051f,
                                                                                      bStack_10520))
                                                                   )))));
    pbVar101 = &bStack_104a8;
    lVar80 = route_peer(pcVar109 + 8,pbVar101,&bStack_10471);
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        pcVar109[1] = '\x01';
      }
    }
    LOCK();
    cVar72 = *pcVar109;
    *pcVar109 = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
    }
    if (lVar80 == 1) {
      fileshare::acked(pbVar101,uStack_104b0,pauStack_10538);
    }
    goto LAB_1400331d8;
  }
  if (((*(longlong *)*uStack_104b0 != 0x31524545502d5252) || (*plVar94 != 0x31435254532d5252)) ||
     (pauVar82 = pauStack_10538 + -1, pauVar82 < (undefined1 (*) [16])&DAT_00000009))
  goto LAB_1400331d8;
  pauVar79 = *(undefined1 (**) [16])(uStack_104b0[1] + 1);
  bVar76 = uStack_104b0[1][0];
  if (bVar76 == 1) {
    if ((pauVar82 != (undefined1 (*) [16])&DAT_00000012) || (1 < (byte)uStack_104b0[2][1]))
    goto LAB_1400331d8;
    uStack_102b0 = *(ulonglong *)(uStack_104b0[1] + 9);
    bStack_10485 = uStack_104b0[2][1];
  }
  else if ((bVar76 != 0) || (pauVar82 != (undefined1 (*) [16])&DAT_00000009)) goto LAB_1400331d8;
  uStack_10278._1_1_ = bStack_10485;
  auStack_10270[0] = (uint)pauVar79;
  auStack_10270[1]._0_2_ = (undefined2)((ulonglong)pauVar79 >> 0x20);
  auStack_10270[1]._2_2_ = (undefined2)((ulonglong)pauVar79 >> 0x30);
  uStack_10268 = (uint)uStack_102b0;
  uStack_10264 = (undefined2)(uStack_102b0 >> 0x20);
  uStack_10262 = (undefined2)(uStack_102b0 >> 0x30);
  bStack_10318 = bStack_10461;
  bStack_10328 = bStack_10471;
  bStack_10327 = (byte)uStack_10470;
  iStack_10326 = (int)((uint7)uStack_10470 >> 8);
  uStack_10322 = (ushort)((uint7)uStack_10470 >> 0x28);
  bStack_10320 = bStack_10469;
  uStack_1031f = (undefined5)uStack_10468;
  uStack_1031a = (ushort)((uint7)uStack_10468 >> 0x28);
  uStack_103a8 = CONCAT11(bStack_104a7,bStack_104a8);
  uStack_10398 = uStack_10498;
  uStack_10396 = uStack_10496;
  uStack_10394 = uStack_10494;
  uStack_10390 = uStack_10490;
  uStack_103a6 = uStack_104a6;
  uStack_103a4 = uStack_104a4;
  uStack_103a2 = uStack_104a2;
  uStack_103a0 = uStack_104a0;
  uStack_1039e = uStack_1049e;
  uStack_1039c = uStack_1049c;
  uStack_10278._0_1_ = bVar76;
  <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
  ::lock(&bStack_10528,&DAT_140699948);
  bVar75 = bStack_10518;
  if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
    uStack_10438._4_4_ =
         CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
    uStack_10438._0_1_ = bStack_10520;
    uStack_10438._1_1_ = bStack_1051f;
    uStack_10438._2_1_ = bStack_1051e;
    uStack_10438._3_1_ = bStack_1051d;
    bStack_10430 = bStack_10518;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
               &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2660);
    goto LAB_140036cf0;
  }
  pcVar109 = (char *)CONCAT17(bStack_10519,
                              CONCAT16(bStack_1051a,
                                       CONCAT15(bStack_1051b,
                                                CONCAT14(bStack_1051c,
                                                         CONCAT13(bStack_1051d,
                                                                  CONCAT12(bStack_1051e,
                                                                           CONCAT11(bStack_1051f,
                                                                                    bStack_10520))))
                                               )));
  <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
  ::lock(&bStack_10528,&TRANSPORT);
  bVar73 = bStack_10518;
  if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
    uStack_10438._4_4_ =
         CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
    uStack_10438._0_1_ = bStack_10520;
    uStack_10438._1_1_ = bStack_1051f;
    uStack_10438._2_1_ = bStack_1051e;
    uStack_10438._3_1_ = bStack_1051d;
    bStack_10430 = bStack_10518;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2678);
    goto LAB_140036cf0;
  }
  uStack_104c0 = (undefined1 (*) [16])
                 CONCAT17(bStack_10519,
                          CONCAT16(bStack_1051a,
                                   CONCAT15(bStack_1051b,
                                            CONCAT14(bStack_1051c,
                                                     CONCAT13(bStack_1051d,
                                                              CONCAT12(bStack_1051e,
                                                                       CONCAT11(bStack_1051f,
                                                                                bStack_10520)))))));
  pcVar115 = pcVar109 + 8;
  if (bVar76 == 1) {
    if (pauVar79 != DAT_1406998e0) goto LAB_14003480c;
    in_stack_fffffffffffefaa8 =
         (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),bStack_10328);
    cVar74 = is_host_route(pcVar115,HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0
                                    && IS_HOST_0_llvm_14435704873730135342 == '\0',
                           HOST_ID_0_llvm_14435704873730135342,&uStack_103a8,
                           in_stack_fffffffffffefaa8,
                           CONCAT17(bStack_10320,
                                    CONCAT25(uStack_10322,CONCAT41(iStack_10326,bStack_10327))),
                           CONCAT17(bStack_10318,CONCAT25(uStack_1031a,uStack_1031f)));
    if (((cVar74 == '\0') || (uStack_102b0 == 0)) || (uStack_104c0[10][10] == '\0'))
    goto LAB_14003480c;
    uVar117 = *(ulonglong *)(uStack_104c0[2] + 8);
    bVar76 = uStack_104c0[3][0];
    if ((bVar76 != 2) && (uStack_102b0 < uVar117)) goto LAB_14003480c;
    *(ulonglong *)(uStack_104c0[2] + 8) = uStack_102b0;
    uStack_104c0[3][0] = bStack_10485;
    if ((bVar76 == bStack_10485) && (uVar117 == uStack_102b0)) goto LAB_14003480c;
    uVar85 = 0x3e;
    if (bStack_10485 == 0) {
      uVar85 = 0x44;
    }
    pcVar93 = "net: star acknowledged by host; guest routes through host only";
    if (bStack_10485 == 0) {
      pcVar93 = "net: host acknowledged star but is not routing guests through itself";
    }
    host::log(pcVar93,uVar85);
    if (uStack_104c0[3][0] != '\x01') goto LAB_14003480c;
    <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
    ::retain::<host_probe[b94139f9089eb1d8]::net::receive_star_control::_closure_0_>(pcVar115);
    <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
    ::lock(&bStack_10528,&GREETING);
    bVar76 = bStack_10518;
    if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1) {
      uStack_10438._4_4_ =
           CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
      uStack_10438._0_1_ = bStack_10520;
      uStack_10438._1_1_ = bStack_1051f;
      uStack_10438._2_1_ = bStack_1051e;
      uStack_10438._3_1_ = bStack_1051d;
      bStack_10430 = bStack_10518;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                 &
                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0f10
                 ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2718);
    }
    else {
      pcVar115 = (char *)CONCAT17(bStack_10519,
                                  CONCAT16(bStack_1051a,
                                           CONCAT15(bStack_1051b,
                                                    CONCAT14(bStack_1051c,
                                                             CONCAT13(bStack_1051d,
                                                                      CONCAT12(bStack_1051e,
                                                                               CONCAT11(bStack_1051f
                                                                                        ,
                                                  bStack_10520)))))));
      if (*(longlong *)(pcVar115 + 8) != 0) {
        <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,u32,std[3bf9d48a0c3997f0]::time::Instant))>as_core[505b25137b8ba7f]::ops::drop::Drop>
        ::drop(pcVar115 + 8);
      }
      pcVar115[8] = '\0';
      pcVar115[9] = '\0';
      pcVar115[10] = '\0';
      pcVar115[0xb] = '\0';
      pcVar115[0xc] = '\0';
      pcVar115[0xd] = '\0';
      pcVar115[0xe] = '\0';
      pcVar115[0xf] = '\0';
      if ((bVar76 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          pcVar115[1] = '\x01';
        }
      }
      LOCK();
      cVar74 = *pcVar115;
      *pcVar115 = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar115);
      }
      <std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<[[core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::time::Instant>;64usize];4usize]>>
      ::lock(&bStack_10528,&IMPAIR);
      bVar76 = bStack_10518;
      pauVar82 = HOST_ID_0_llvm_14435704873730135342;
      if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) != 1) {
        uStack_10458 = (undefined1 (*) [16])
                       CONCAT17(bStack_10519,
                                CONCAT16(bStack_1051a,
                                         CONCAT15(bStack_1051b,
                                                  CONCAT14(bStack_1051c,
                                                           CONCAT13(bStack_1051d,
                                                                    CONCAT12(bStack_1051e,
                                                                             CONCAT11(bStack_1051f,
                                                                                      bStack_10520))
                                                                   )))));
        uStack_10460 = (undefined1 (*) [16])CONCAT71(uStack_10460._1_7_,bStack_10518);
        if (*(longlong *)(*uStack_10458 + 8) != -1) {
          bVar129 = IS_HOST_0_llvm_14435704873730135342 == '\0';
          bVar130 = HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0;
          uStack_104b8 = (undefined1 (*) [16])CONCAT71(uStack_104b8._1_7_,bVar130 && bVar129);
          pauVar79 = *(undefined1 (**) [16])(uStack_10458[3] + 8);
          if (pauVar79 == (undefined1 (*) [16])0x0) {
            pauVar89 = (undefined1 (*) [16])0x0;
            pauVar123 = (undefined1 (*) [16])0x0;
            goto LAB_1400343e9;
          }
          lVar80 = *(longlong *)uStack_10458[3];
          puVar99 = *(undefined1 **)uStack_10458[2];
          if (bVar130 && bVar129) {
            lVar120 = lVar80 * 0x58 + *(longlong *)(uStack_10458[2] + 8) + 0x50;
            pauVar89 = (undefined1 (*) [16])0x0;
            do {
              puVar90 = (undefined1 *)0x0;
              if (puVar99 <= *pauVar89 + lVar80) {
                puVar90 = puVar99;
              }
              if ((*(undefined1 (**) [16])(lVar120 + -8 + (longlong)puVar90 * -0x58) !=
                   HOST_ID_0_llvm_14435704873730135342) &&
                 (*(char *)(lVar120 + (longlong)puVar90 * -0x58) != '\x02')) goto LAB_14003404d;
              pauVar89 = (undefined1 (*) [16])(*pauVar89 + 1);
              lVar120 = lVar120 + 0x58;
            } while (pauVar79 != pauVar89);
          }
          else {
            lVar120 = lVar80 * 0x58 + *(longlong *)(uStack_10458[2] + 8) + 0x50;
            pauVar89 = (undefined1 (*) [16])0x0;
            do {
              puVar90 = (undefined1 *)0x0;
              if (puVar99 <= *pauVar89 + lVar80) {
                puVar90 = puVar99;
              }
              if (*(char *)(lVar120 + (longlong)puVar90 * -0x58) != '\x02') goto LAB_14003404d;
              pauVar89 = (undefined1 (*) [16])(*pauVar89 + 1);
              lVar120 = lVar120 + 0x58;
            } while (pauVar79 != pauVar89);
          }
          goto LAB_1400347d1;
        }
        if ((bStack_10518 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          goto LAB_14003498b;
        }
        goto LAB_1400347f8;
      }
      uStack_10438._4_4_ =
           CONCAT13(bStack_10519,CONCAT12(bStack_1051a,CONCAT11(bStack_1051b,bStack_1051c)));
      uStack_10438._0_1_ = bStack_10520;
      uStack_10438._1_1_ = bStack_1051f;
      uStack_10438._2_1_ = bStack_1051e;
      uStack_10438._3_1_ = bStack_1051d;
      bStack_10430 = bStack_10518;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&uStack_10438,
                 &anon_d5c34e88a06ee720b116585eb143da4b_138_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2730);
    }
    goto LAB_140036cf0;
  }
  if ((HOST_ID_0_llvm_14435704873730135342 == (undefined1 (*) [16])0x0 ||
       IS_HOST_0_llvm_14435704873730135342 != '\0') && (uStack_104c0[10][8] != '\0')) {
    pauVar82 = (undefined1 (*) [16])&uStack_103a8;
    lVar80 = route_peer(pcVar115,pauVar82,&bStack_10328);
    if ((lVar80 != 1) || (pauVar82 != pauVar79)) goto LAB_14003480c;
    if (*(longlong *)(pcVar109 + 0x20) != 0) {
      uVar117 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                ::hash_one::<&usize>(pcVar109 + 0x28,auStack_10270);
      lVar80 = *(longlong *)(pcVar109 + 8);
      unaff_R15 = *(undefined1 (**) [16])(pcVar109 + 0x10);
      bVar76 = (byte)(uVar117 >> 0x39);
      auVar133 = ZEXT216(CONCAT11(bVar76,bVar76));
      auVar133 = pshuflw(auVar133,auVar133,0);
      lVar120 = 0;
      while( true ) {
        uVar117 = uVar117 & (ulonglong)unaff_R15;
        auVar137 = *(undefined1 (*) [16])(lVar80 + uVar117);
        auVar178[0] = -(auVar137[0] == auVar133[0]);
        auVar178[1] = -(auVar137[1] == auVar133[1]);
        auVar178[2] = -(auVar137[2] == auVar133[2]);
        auVar178[3] = -(auVar137[3] == auVar133[3]);
        auVar178[4] = -(auVar137[4] == auVar133[4]);
        auVar178[5] = -(auVar137[5] == auVar133[5]);
        auVar178[6] = -(auVar137[6] == auVar133[6]);
        auVar178[7] = -(auVar137[7] == auVar133[7]);
        auVar178[8] = -(auVar137[8] == auVar133[0]);
        auVar178[9] = -(auVar137[9] == auVar133[1]);
        auVar178[10] = -(auVar137[10] == auVar133[2]);
        auVar178[0xb] = -(auVar137[0xb] == auVar133[3]);
        auVar178[0xc] = -(auVar137[0xc] == auVar133[4]);
        auVar178[0xd] = -(auVar137[0xd] == auVar133[5]);
        auVar178[0xe] = -(auVar137[0xe] == auVar133[6]);
        auVar178[0xf] = -(auVar137[0xf] == auVar133[7]);
        uVar112 = (ushort)(SUB161(auVar178 >> 7,0) & 1) |
                  (ushort)(SUB161(auVar178 >> 0xf,0) & 1) << 1 |
                  (ushort)(SUB161(auVar178 >> 0x17,0) & 1) << 2 |
                  (ushort)(SUB161(auVar178 >> 0x1f,0) & 1) << 3 |
                  (ushort)(SUB161(auVar178 >> 0x27,0) & 1) << 4 |
                  (ushort)(SUB161(auVar178 >> 0x2f,0) & 1) << 5 |
                  (ushort)(SUB161(auVar178 >> 0x37,0) & 1) << 6 |
                  (ushort)(SUB161(auVar178 >> 0x3f,0) & 1) << 7 |
                  (ushort)(SUB161(auVar178 >> 0x47,0) & 1) << 8 |
                  (ushort)(SUB161(auVar178 >> 0x4f,0) & 1) << 9 |
                  (ushort)(SUB161(auVar178 >> 0x57,0) & 1) << 10 |
                  (ushort)(SUB161(auVar178 >> 0x5f,0) & 1) << 0xb |
                  (ushort)(SUB161(auVar178 >> 0x67,0) & 1) << 0xc |
                  (ushort)(SUB161(auVar178 >> 0x6f,0) & 1) << 0xd |
                  (ushort)(SUB161(auVar178 >> 0x77,0) & 1) << 0xe |
                  (ushort)(auVar178[0xf] >> 7) << 0xf;
        uVar113 = (uint)uVar112;
        while (uVar112 != 0) {
          uVar114 = 0;
          for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
            uVar114 = uVar114 + 1;
          }
          lVar98 = (uVar114 + uVar117 & (ulonglong)unaff_R15) * -0x50;
          if (pauVar79 == *(undefined1 (**) [16])(lVar80 + -0x50 + lVar98)) {
            cVar74 = is_blocked(pauVar79,lVar98 + lVar80 + -0x38);
            if (cVar74 != '\0') goto LAB_14003480c;
            uStack_103c8 = pauVar79;
            uVar117 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                      ::hash_one::<&usize>(pcVar109 + 0x28,&uStack_103c8);
            bVar76 = (byte)(uVar117 >> 0x39);
            auVar133 = ZEXT216(CONCAT11(bVar76,bVar76));
            auVar133 = pshuflw(auVar133,auVar133,0);
            lVar120 = 0;
            goto LAB_140033b54;
          }
          uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
          uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
        }
        auVar163[0] = -(auVar137[0] == cVar72);
        auVar163[1] = -(auVar137[1] == cVar181);
        auVar163[2] = -(auVar137[2] == cVar182);
        auVar163[3] = -(auVar137[3] == cVar183);
        auVar163[4] = -(auVar137[4] == cVar184);
        auVar163[5] = -(auVar137[5] == cVar185);
        auVar163[6] = -(auVar137[6] == cVar186);
        auVar163[7] = -(auVar137[7] == cVar187);
        auVar163[8] = -(auVar137[8] == cVar188);
        auVar163[9] = -(auVar137[9] == cVar189);
        auVar163[10] = -(auVar137[10] == cVar190);
        auVar163[0xb] = -(auVar137[0xb] == cVar191);
        auVar163[0xc] = -(auVar137[0xc] == cVar192);
        auVar163[0xd] = -(auVar137[0xd] == cVar193);
        auVar163[0xe] = -(auVar137[0xe] == cVar194);
        auVar163[0xf] = -(auVar137[0xf] == cVar195);
        if ((((((((((((((((SUB161(auVar163 >> 7,0) & 1) != 0 || (SUB161(auVar163 >> 0xf,0) & 1) != 0
                         ) || (SUB161(auVar163 >> 0x17,0) & 1) != 0) ||
                       (SUB161(auVar163 >> 0x1f,0) & 1) != 0) ||
                      (SUB161(auVar163 >> 0x27,0) & 1) != 0) ||
                     (SUB161(auVar163 >> 0x2f,0) & 1) != 0) || (SUB161(auVar163 >> 0x37,0) & 1) != 0
                    ) || (SUB161(auVar163 >> 0x3f,0) & 1) != 0) ||
                  (SUB161(auVar163 >> 0x47,0) & 1) != 0) || (SUB161(auVar163 >> 0x4f,0) & 1) != 0)
                || (SUB161(auVar163 >> 0x57,0) & 1) != 0) || (SUB161(auVar163 >> 0x5f,0) & 1) != 0)
              || (SUB161(auVar163 >> 0x67,0) & 1) != 0) || (SUB161(auVar163 >> 0x6f,0) & 1) != 0) ||
            (SUB161(auVar163 >> 0x77,0) & 1) != 0) || auVar163[0xf] < '\0') break;
        uVar117 = uVar117 + lVar120 + 0x10;
        lVar120 = lVar120 + 0x10;
      }
    }
LAB_14003676a:
    core[505b25137b8ba7f]::option::expect_failed("no entry found for key",0x16,ppuStack_10188);
    goto LAB_140036cf0;
  }
  goto LAB_14003480c;
LAB_140033330:
  uVar81 = uVar81 & uVar117;
  auVar137 = *(undefined1 (*) [16])(*pauVar79 + uVar81);
  auVar177[0] = -(auVar137[0] == auVar133[0]);
  auVar177[1] = -(auVar137[1] == auVar133[1]);
  auVar177[2] = -(auVar137[2] == auVar133[2]);
  auVar177[3] = -(auVar137[3] == auVar133[3]);
  auVar177[4] = -(auVar137[4] == auVar133[4]);
  auVar177[5] = -(auVar137[5] == auVar133[5]);
  auVar177[6] = -(auVar137[6] == auVar133[6]);
  auVar177[7] = -(auVar137[7] == auVar133[7]);
  auVar177[8] = -(auVar137[8] == auVar133[0]);
  auVar177[9] = -(auVar137[9] == auVar133[1]);
  auVar177[10] = -(auVar137[10] == auVar133[2]);
  auVar177[0xb] = -(auVar137[0xb] == auVar133[3]);
  auVar177[0xc] = -(auVar137[0xc] == auVar133[4]);
  auVar177[0xd] = -(auVar137[0xd] == auVar133[5]);
  auVar177[0xe] = -(auVar137[0xe] == auVar133[6]);
  auVar177[0xf] = -(auVar137[0xf] == auVar133[7]);
  uVar112 = (ushort)(SUB161(auVar177 >> 7,0) & 1) | (ushort)(SUB161(auVar177 >> 0xf,0) & 1) << 1 |
            (ushort)(SUB161(auVar177 >> 0x17,0) & 1) << 2 |
            (ushort)(SUB161(auVar177 >> 0x1f,0) & 1) << 3 |
            (ushort)(SUB161(auVar177 >> 0x27,0) & 1) << 4 |
            (ushort)(SUB161(auVar177 >> 0x2f,0) & 1) << 5 |
            (ushort)(SUB161(auVar177 >> 0x37,0) & 1) << 6 |
            (ushort)(SUB161(auVar177 >> 0x3f,0) & 1) << 7 |
            (ushort)(SUB161(auVar177 >> 0x47,0) & 1) << 8 |
            (ushort)(SUB161(auVar177 >> 0x4f,0) & 1) << 9 |
            (ushort)(SUB161(auVar177 >> 0x57,0) & 1) << 10 |
            (ushort)(SUB161(auVar177 >> 0x5f,0) & 1) << 0xb |
            (ushort)(SUB161(auVar177 >> 0x67,0) & 1) << 0xc |
            (ushort)(SUB161(auVar177 >> 0x6f,0) & 1) << 0xd |
            (ushort)(SUB161(auVar177 >> 0x77,0) & 1) << 0xe | (ushort)(auVar177[0xf] >> 7) << 0xf;
  uVar113 = (uint)uVar112;
  while (uVar112 != 0) {
    uVar114 = 0;
    for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
      uVar114 = uVar114 + 1;
    }
    uVar83 = uVar114 + uVar81 & uVar117;
    if (pauVar82 == *(undefined1 (**) [16])pauVar79[uVar83 * -5 + -5]) {
      if (uStack_104c0 == pauVar82) goto LAB_140033728;
      cVar74 = receive::_closure_0_(uStack_104c0,*pauVar123 + 8);
      if (cVar74 != '\0') goto LAB_140033728;
      puVar86 = (undefined8 *)(pauVar79[uVar83 * -5 + -5] + 8);
      cVar74 = receive::_closure_0_(pauVar82,puVar86);
      pauVar89 = uStack_104c0;
      if (cVar74 != '\0') goto LAB_140033728;
      cVar74 = <host_probe[b94139f9089eb1d8]::net::Star>::supports
                         (&DAT_140699838,uStack_104c0,*pauVar123 + 8);
      if (cVar74 == '\0') goto LAB_140033728;
      cVar74 = <host_probe[b94139f9089eb1d8]::net::Star>::supports(&DAT_140699838,pauVar82,puVar86);
      if (cVar74 == '\0') goto LAB_140033728;
      uStack_104e8 = (uint)*(undefined8 *)(pauVar79[uVar83 * -5 + -1] + 8);
      uStack_104e4 = (uint)((ulonglong)*(undefined8 *)(pauVar79[uVar83 * -5 + -1] + 8) >> 0x20);
      uVar85 = *puVar86;
      uVar4 = *(undefined8 *)pauVar79[uVar83 * -5 + -4];
      uVar9 = *(undefined8 *)(pauVar79[uVar83 * -5 + -4] + 8);
      uVar10 = *(undefined8 *)pauVar79[uVar83 * -5 + -3];
      uStack_104f8._0_4_ = (uint)*(undefined8 *)(pauVar79[uVar83 * -5 + -2] + 8);
      uStack_104f8._4_4_ =
           (uint)((ulonglong)*(undefined8 *)(pauVar79[uVar83 * -5 + -2] + 8) >> 0x20);
      uStack_104f0 = (uint)*(undefined8 *)pauVar79[uVar83 * -5 + -1];
      uStack_104ec = (uint)((ulonglong)*(undefined8 *)pauVar79[uVar83 * -5 + -1] >> 0x20);
      uStack_10508._0_4_ = (uint)*(undefined8 *)(pauVar79[uVar83 * -5 + -3] + 8);
      uStack_10508._4_4_ =
           (uint)((ulonglong)*(undefined8 *)(pauVar79[uVar83 * -5 + -3] + 8) >> 0x20);
      uStack_10500._0_4_ = (uint)*(undefined8 *)pauVar79[uVar83 * -5 + -2];
      uStack_10500._4_4_ = (uint)((ulonglong)*(undefined8 *)pauVar79[uVar83 * -5 + -2] >> 0x20);
      bStack_10518 = (byte)uVar9;
      bStack_10517 = (byte)((ulonglong)uVar9 >> 8);
      uStack_10516 = (ushort)((ulonglong)uVar9 >> 0x10);
      uStack_10514 = (uint)((ulonglong)uVar9 >> 0x20);
      uStack_10510 = (ushort)uVar10;
      uStack_1050e = (ushort)((ulonglong)uVar10 >> 0x10);
      uStack_1050c = (ushort)((ulonglong)uVar10 >> 0x20);
      uStack_1050a = (ushort)((ulonglong)uVar10 >> 0x30);
      bStack_10528 = (byte)uVar85;
      bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
      bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
      bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
      bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
      bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
      bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
      bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
      bStack_10520 = (byte)uVar4;
      bStack_1051f = (byte)((ulonglong)uVar4 >> 8);
      bStack_1051e = (byte)((ulonglong)uVar4 >> 0x10);
      bStack_1051d = (byte)((ulonglong)uVar4 >> 0x18);
      bStack_1051c = (byte)((ulonglong)uVar4 >> 0x20);
      bStack_1051b = (byte)((ulonglong)uVar4 >> 0x28);
      bStack_1051a = (byte)((ulonglong)uVar4 >> 0x30);
      bStack_10519 = (byte)((ulonglong)uVar4 >> 0x38);
      in_stack_fffffffffffefaa8 =
           (undefined **)
           CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),pauVar79[uVar83 * -5 + -2][8])
      ;
      star_wrap(&puStack_104e0,pauVar89,uStack_10458,pauStack_10538 + -1,in_stack_fffffffffffefaa8);
      uVar85 = uStack_104d8;
      puVar88 = puStack_104e0;
      puStack_103f8 = (undefined *)CONCAT44(uStack_104e4,uStack_104e8);
      uStack_10438._4_4_ =
           CONCAT13(bStack_10521,CONCAT12(bStack_10522,CONCAT11(bStack_10523,bStack_10524)));
      uStack_1042e = CONCAT11(bStack_1051d,bStack_1051e);
      uStack_10420 = CONCAT22(uStack_1050e,uStack_10510);
      uStack_10408 = (uint)uStack_104f8;
      uStack_10404 = uStack_104f8._4_4_;
      uStack_10400 = uStack_104f0;
      uStack_103fc = uStack_104ec;
      uStack_10418 = (uint)uStack_10508;
      uStack_10414 = uStack_10508._4_4_;
      uStack_10410 = (uint)uStack_10500;
      uStack_1040c = uStack_10500._4_4_;
      bStack_10428 = bStack_10518;
      bStack_10427 = bStack_10517;
      uStack_10426 = uStack_10516;
      uStack_10424 = uStack_10514;
      uStack_1041c = uStack_1050c;
      uStack_1041a = uStack_1050a;
      uStack_10438._0_1_ = bStack_10528;
      uStack_10438._1_1_ = bStack_10527;
      uStack_10438._2_1_ = bStack_10526;
      uStack_10438._3_1_ = bStack_10525;
      bStack_10430 = bStack_10520;
      bStack_1042f = bStack_1051f;
      uStack_1042c = (uint)(CONCAT15(bStack_10519,
                                     CONCAT14(bStack_1051a,
                                              CONCAT13(bStack_1051b,
                                                       CONCAT12(bStack_1051c,uStack_1042e)))) >>
                           0x10);
      cStack_10530 = '\x01';
      if (puStack_104e0 != (undefined *)0xfffffffffffffffe) {
        if (puStack_104e0 == (undefined *)0xffffffffffffffff) {
          note_star_oversize(uStack_104d8,
                             CONCAT44(uStack_10514,
                                      CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518))),
                             uStack_10508,uStack_104d0);
        }
        else {
          in_stack_fffffffffffefaa8 =
               (undefined **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffefaa8 >> 8),2);
          send_route_kind(&TRANSPORT,&bStack_10528,uStack_104d8,uStack_104d0,
                          in_stack_fffffffffffefaa8);
          if (puVar88 != (undefined *)0x0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,puVar88,1);
            return pauVar82;
          }
        }
        cStack_10530 = '\x02';
      }
      goto joined_r0x0001400343ad;
    }
    uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
    uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
  }
  auVar162[0] = -(auVar137[0] == cVar72);
  auVar162[1] = -(auVar137[1] == cVar181);
  auVar162[2] = -(auVar137[2] == cVar182);
  auVar162[3] = -(auVar137[3] == cVar183);
  auVar162[4] = -(auVar137[4] == cVar184);
  auVar162[5] = -(auVar137[5] == cVar185);
  auVar162[6] = -(auVar137[6] == cVar186);
  auVar162[7] = -(auVar137[7] == cVar187);
  auVar162[8] = -(auVar137[8] == cVar188);
  auVar162[9] = -(auVar137[9] == cVar189);
  auVar162[10] = -(auVar137[10] == cVar190);
  auVar162[0xb] = -(auVar137[0xb] == cVar191);
  auVar162[0xc] = -(auVar137[0xc] == cVar192);
  auVar162[0xd] = -(auVar137[0xd] == cVar193);
  auVar162[0xe] = -(auVar137[0xe] == cVar194);
  auVar162[0xf] = -(auVar137[0xf] == cVar195);
  if ((((((((((((((((SUB161(auVar162 >> 7,0) & 1) != 0 || (SUB161(auVar162 >> 0xf,0) & 1) != 0) ||
                  (SUB161(auVar162 >> 0x17,0) & 1) != 0) || (SUB161(auVar162 >> 0x1f,0) & 1) != 0)
                || (SUB161(auVar162 >> 0x27,0) & 1) != 0) || (SUB161(auVar162 >> 0x2f,0) & 1) != 0)
              || (SUB161(auVar162 >> 0x37,0) & 1) != 0) || (SUB161(auVar162 >> 0x3f,0) & 1) != 0) ||
            (SUB161(auVar162 >> 0x47,0) & 1) != 0) || (SUB161(auVar162 >> 0x4f,0) & 1) != 0) ||
          (SUB161(auVar162 >> 0x57,0) & 1) != 0) || (SUB161(auVar162 >> 0x5f,0) & 1) != 0) ||
        (SUB161(auVar162 >> 0x67,0) & 1) != 0) || (SUB161(auVar162 >> 0x6f,0) & 1) != 0) ||
      (SUB161(auVar162 >> 0x77,0) & 1) != 0) || auVar162[0xf] < '\0') goto LAB_140033728;
  uVar81 = uVar81 + lVar80 + 0x10;
  lVar80 = lVar80 + 0x10;
  goto LAB_140033330;
LAB_14002f33a:
  bVar75 = 0;
LAB_14002f33c:
  if ((bVar76 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
  cVar74 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
  bVar76 = bStack_10526;
  bVar73 = bStack_10525;
  bVar54 = bStack_10524;
  bVar55 = bStack_10523;
  bVar132 = bStack_10522;
  bVar56 = bStack_10521;
  bVar57 = bStack_10520;
  bVar58 = bStack_1051f;
  bVar59 = bStack_1051e;
  bVar60 = bStack_1051d;
  bVar61 = bStack_1051c;
  bVar62 = bStack_1051b;
  bVar63 = bStack_1051a;
  bVar64 = bStack_10519;
  bVar65 = bStack_10518;
  bVar66 = bStack_10517;
  uVar112 = uStack_10510;
  uVar91 = uStack_1050e;
  uVar68 = uStack_1050c;
  uVar69 = uStack_1050a;
  if (bVar75 != 0) {
    cVar74 = is_blocked(uStack_10460);
    bVar76 = bStack_10526;
    bVar73 = bStack_10525;
    bVar54 = bStack_10524;
    bVar55 = bStack_10523;
    bVar132 = bStack_10522;
    bVar56 = bStack_10521;
    bVar57 = bStack_10520;
    bVar58 = bStack_1051f;
    bVar59 = bStack_1051e;
    bVar60 = bStack_1051d;
    bVar61 = bStack_1051c;
    bVar62 = bStack_1051b;
    bVar63 = bStack_1051a;
    bVar64 = bStack_10519;
    bVar65 = bStack_10518;
    bVar66 = bStack_10517;
    uVar112 = uStack_10510;
    uVar91 = uStack_1050e;
    uVar68 = uStack_1050c;
    uVar69 = uStack_1050a;
    if (((cVar74 == '\0') && (pauStack_10538 < (undefined1 (*) [16])0x579)) &&
       (ingame_chat::ENABLED_0_llvm_14435704873730135342 != '\0')) {
      LOCK();
      bVar129 = DAT_140699000 == '\0';
      if (bVar129) {
        DAT_140699000 = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699000);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar76 = 0;
        pauVar82 = DAT_140699008;
        lVar80 = DAT_140699010;
        pauVar79 = DAT_140699018;
        unaff_R15 = DAT_140699020;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar76 = bVar76 ^ 1;
        pauVar82 = DAT_140699008;
        lVar80 = DAT_140699010;
        pauVar79 = DAT_140699018;
        unaff_R15 = DAT_140699020;
      }
      DAT_140699008 = pauVar82;
      DAT_140699010 = lVar80;
      DAT_140699018 = pauVar79;
      DAT_140699020 = unaff_R15;
      if (DAT_140699001 != '\0') {
        bStack_10528 = 0;
        bStack_10527 = 0x90;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar76;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &
                   PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a10d0
                   ,&DAT_1406a1b00);
        goto LAB_140036cf0;
      }
      uStack_10438._0_1_ = (byte)uStack_10460;
      uStack_10438._1_1_ = (byte)((ulonglong)uStack_10460 >> 8);
      uStack_10438._2_1_ = (byte)((ulonglong)uStack_10460 >> 0x10);
      uStack_10438._3_1_ = (byte)((ulonglong)uStack_10460 >> 0x18);
      uStack_10438._4_4_ = (int)((ulonglong)uStack_10460 >> 0x20);
      if (unaff_R15 < (undefined1 (*) [16])0x200) {
        if (unaff_R15 == (undefined1 (*) [16])0x0) {
          lVar120 = 0;
          pauVar123 = (undefined1 (*) [16])0x0;
LAB_140032549:
          lVar98 = 0;
        }
        else {
          pauVar123 = (undefined1 (*) [16])0x0;
          if (pauVar82 <= pauVar79) {
            pauVar123 = pauVar82;
          }
          lVar120 = (longlong)pauVar79 - (longlong)pauVar123;
          lVar98 = (longlong)unaff_R15 - ((longlong)pauVar82 - lVar120);
          pauVar123 = pauVar82;
          if (unaff_R15 < (undefined1 (*) [16])((longlong)pauVar82 - lVar120) || lVar98 == 0) {
            pauVar123 = (undefined1 (*) [16])(lVar120 + (longlong)unaff_R15);
            goto LAB_140032549;
          }
        }
        lVar120 = lVar120 * 0x20 + lVar80;
        lVar128 = (longlong)pauVar123 * 0x20 + lVar80;
        lVar98 = lVar98 * 0x20 + lVar80;
        bStack_10528 = (byte)lVar120;
        bStack_10527 = (byte)((ulonglong)lVar120 >> 8);
        bStack_10526 = (byte)((ulonglong)lVar120 >> 0x10);
        bStack_10525 = (byte)((ulonglong)lVar120 >> 0x18);
        bStack_10524 = (byte)((ulonglong)lVar120 >> 0x20);
        bStack_10523 = (byte)((ulonglong)lVar120 >> 0x28);
        bStack_10522 = (byte)((ulonglong)lVar120 >> 0x30);
        bStack_10521 = (byte)((ulonglong)lVar120 >> 0x38);
        bStack_10520 = (byte)lVar128;
        bStack_1051f = (byte)((ulonglong)lVar128 >> 8);
        bStack_1051e = (byte)((ulonglong)lVar128 >> 0x10);
        bStack_1051d = (byte)((ulonglong)lVar128 >> 0x18);
        bStack_1051c = (byte)((ulonglong)lVar128 >> 0x20);
        bStack_1051b = (byte)((ulonglong)lVar128 >> 0x28);
        bStack_1051a = (byte)((ulonglong)lVar128 >> 0x30);
        bStack_10519 = (byte)((ulonglong)lVar128 >> 0x38);
        bStack_10518 = (byte)lVar80;
        bStack_10517 = (byte)((ulonglong)lVar80 >> 8);
        uStack_10516 = (ushort)((ulonglong)lVar80 >> 0x10);
        uStack_10514 = (uint)((ulonglong)lVar80 >> 0x20);
        uStack_10510 = (ushort)lVar98;
        uStack_1050e = (ushort)((ulonglong)lVar98 >> 0x10);
        uStack_1050c = (ushort)((ulonglong)lVar98 >> 0x20);
        uStack_1050a = (ushort)((ulonglong)lVar98 >> 0x30);
        uStack_10508 = (undefined1 (**) [16])&uStack_10438;
        uVar117 = <alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
                  ::fold::
                  <usize,core[505b25137b8ba7f]::iter::adapters::map::map_fold<&(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),usize,usize,<core[505b25137b8ba7f]::iter::adapters::filter::Filter<_,_>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::count::to_usize<&(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),host_probe[b94139f9089eb1d8]::ingame_chat::enqueue::_closure_0_>::_closure_0_,<usize_as_core[505b25137b8ba7f]::iter::traits::accum::Sum>::sum<core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>,<core[505b25137b8ba7f]::iter::adapters::filter::Filter<_,_>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>::count::to_usize<&(u64,alloc[246c2e7857c81348]::vec::Vec<u8>),host_probe[b94139f9089eb1d8]::ingame_chat::enqueue::_closure_0_>::_closure_0_>>::_closure_0_>::_closure_0_>
                            (&bStack_10528,0);
        if (uVar117 < 8) {
          in_stack_fffffffffffefaa8 = (undefined **)0x0;
          <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in
                    (&bStack_10528,pauStack_10538,0,1,1);
          uVar85 = CONCAT17(bStack_10519,
                            CONCAT16(bStack_1051a,
                                     CONCAT15(bStack_1051b,
                                              CONCAT14(bStack_1051c,
                                                       CONCAT13(bStack_1051d,
                                                                CONCAT12(bStack_1051e,
                                                                         CONCAT11(bStack_1051f,
                                                                                  bStack_10520))))))
                           );
          if (CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528))) == 1
             ) {
            alloc[246c2e7857c81348]::raw_vec::handle_error
                      (uVar85,CONCAT44(uStack_10514,
                                       CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518))));
            goto LAB_140036cf0;
          }
          pvVar87 = (void *)CONCAT44(uStack_10514,
                                     CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518)));
          memcpy(pvVar87,uStack_104b0,(size_t)pauStack_10538);
          uVar4 = CONCAT44(uStack_10438._4_4_,
                           CONCAT13(uStack_10438._3_1_,
                                    CONCAT12(uStack_10438._2_1_,
                                             CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))));
          if (unaff_R15 == pauVar82) {
            <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::vec::Vec<u8>)>>
            ::grow(&DAT_140699008);
            pauVar82 = DAT_140699008;
            lVar80 = DAT_140699010;
            pauVar79 = DAT_140699018;
            unaff_R15 = DAT_140699020;
          }
          DAT_140699020 = (undefined1 (*) [16])(*unaff_R15 + 1);
          pauVar123 = (undefined1 (*) [16])0x0;
          if (pauVar82 <= (undefined1 (*) [16])(*unaff_R15 + (longlong)*pauVar79)) {
            pauVar123 = pauVar82;
          }
          lVar120 = ((longlong)(*unaff_R15 + (longlong)*pauVar79) - (longlong)pauVar123) * 0x20;
          *(undefined8 *)(lVar80 + lVar120) = uVar4;
          *(undefined8 *)(lVar80 + 8 + lVar120) = uVar85;
          *(void **)(lVar80 + 0x10 + lVar120) = pvVar87;
          *(undefined1 (**) [16])(lVar80 + 0x18 + lVar120) = pauStack_10538;
        }
      }
      if ((bVar76 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          DAT_140699001 = '\x01';
        }
      }
      cVar74 = DAT_140699000;
      LOCK();
      DAT_140699000 = '\0';
      UNLOCK();
      cStack_10530 = '\x01';
      if (cVar74 == '\x02') {
        pcVar109 = &DAT_140699000;
        cStack_10530 = '\x01';
LAB_140033f4e:
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
      }
      goto LAB_1400331d0;
    }
  }
  goto LAB_1400331c4;
LAB_140031101:
  pauVar89 = pauVar79;
  if (pauVar104 < pauVar123) {
    if ((undefined1 (*) [16])(*pauVar123 + ~(ulonglong)pauVar104) < pauVar104) {
      pauVar92 = pauVar82;
      if ((undefined1 (*) [16])(*pauVar79 + (longlong)*pauVar104) < pauVar82) {
        pauVar92 = (undefined1 (*) [16])0x0;
      }
      lVar120 = (longlong)(*pauVar79 + (longlong)*pauVar104) - (longlong)pauVar92;
      pauVar79 = pauVar82;
      if ((undefined1 (*) [16])(lVar120 + 1) < pauVar82) {
        pauVar79 = (undefined1 (*) [16])0x0;
      }
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
      ::wrap_copy(pauVar82,lVar80,(lVar120 - (longlong)pauVar79) + 1,lVar120,
                  (undefined1 (*) [16])(*pauVar123 + ~(ulonglong)pauVar104));
    }
    else {
      pauVar89 = (undefined1 (*) [16])0x0;
      if (pauVar82 <= (undefined1 (*) [16])(*pauVar79 + 1)) {
        pauVar89 = pauVar82;
      }
      pauVar89 = (undefined1 (*) [16])((longlong)pauVar79 + (1 - (longlong)pauVar89));
      DAT_140699938 = pauVar89;
      <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
      ::wrap_copy(pauVar82,lVar80,pauVar79,pauVar89,pauVar104);
    }
    DAT_140699940 = (undefined1 (*) [16])(pauVar123[-1] + 0xf);
  }
  pauVar79 = pauVar89;
  iVar127 = (uint)uStack_104c0;
  uVar117 = uStack_10490;
  goto LAB_1400337e9;
LAB_14002ff09:
  if ((bVar77 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
  cVar74 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
  host::looks::received(*uStack_104b0 + 8,pauStack_10538[-1] + 8);
  cStack_10530 = '\x01';
  goto LAB_1400331d0;
LAB_1400300f5:
  if ((bVar77 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
  cVar74 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
  host::looks::received3(*uStack_104b0 + 8,pauStack_10538[-1] + 8);
  cStack_10530 = '\x01';
  goto LAB_1400331d0;
LAB_14002cdc2:
  uVar117 = uVar117 & DAT_140699958;
  pcVar109 = *DAT_140699950 + uVar117;
  auVar171[0] = -(*pcVar109 == auVar133[0]);
  auVar171[1] = -(pcVar109[1] == auVar133[1]);
  auVar171[2] = -(pcVar109[2] == auVar133[2]);
  auVar171[3] = -(pcVar109[3] == auVar133[3]);
  auVar171[4] = -(pcVar109[4] == auVar133[4]);
  auVar171[5] = -(pcVar109[5] == auVar133[5]);
  auVar171[6] = -(pcVar109[6] == auVar133[6]);
  auVar171[7] = -(pcVar109[7] == auVar133[7]);
  auVar171[8] = -(pcVar109[8] == auVar133[0]);
  auVar171[9] = -(pcVar109[9] == auVar133[1]);
  auVar171[10] = -(pcVar109[10] == auVar133[2]);
  auVar171[0xb] = -(pcVar109[0xb] == auVar133[3]);
  auVar171[0xc] = -(pcVar109[0xc] == auVar133[4]);
  auVar171[0xd] = -(pcVar109[0xd] == auVar133[5]);
  auVar171[0xe] = -(pcVar109[0xe] == auVar133[6]);
  auVar171[0xf] = -(pcVar109[0xf] == auVar133[7]);
  uVar112 = (ushort)(SUB161(auVar171 >> 7,0) & 1) | (ushort)(SUB161(auVar171 >> 0xf,0) & 1) << 1 |
            (ushort)(SUB161(auVar171 >> 0x17,0) & 1) << 2 |
            (ushort)(SUB161(auVar171 >> 0x1f,0) & 1) << 3 |
            (ushort)(SUB161(auVar171 >> 0x27,0) & 1) << 4 |
            (ushort)(SUB161(auVar171 >> 0x2f,0) & 1) << 5 |
            (ushort)(SUB161(auVar171 >> 0x37,0) & 1) << 6 |
            (ushort)(SUB161(auVar171 >> 0x3f,0) & 1) << 7 |
            (ushort)(SUB161(auVar171 >> 0x47,0) & 1) << 8 |
            (ushort)(SUB161(auVar171 >> 0x4f,0) & 1) << 9 |
            (ushort)(SUB161(auVar171 >> 0x57,0) & 1) << 10 |
            (ushort)(SUB161(auVar171 >> 0x5f,0) & 1) << 0xb |
            (ushort)(SUB161(auVar171 >> 0x67,0) & 1) << 0xc |
            (ushort)(SUB161(auVar171 >> 0x6f,0) & 1) << 0xd |
            (ushort)(SUB161(auVar171 >> 0x77,0) & 1) << 0xe | (ushort)(auVar171[0xf] >> 7) << 0xf;
  uVar113 = (uint)uVar112;
  while (uVar112 != 0) {
    uVar114 = 0;
    for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
      uVar114 = uVar114 + 1;
    }
    uVar81 = uVar114 + uVar117 & DAT_140699958;
    if (uStack_103c8 == *(undefined1 (**) [16])DAT_140699950[uVar81 * -5 + -5]) {
      *(undefined8 *)(DAT_140699950[uVar81 * -5 + -5] + 8) = uVar85;
      *(int *)pauVar82[uVar81 * -5 + -4] = (int)lVar98;
      bStack_10518 = (byte)uStack_10498;
      bStack_10517 = (byte)(uStack_10498 >> 8);
      uStack_10516 = uStack_10496;
      uStack_10514 = uStack_10494;
      uStack_10510 = (ushort)uStack_10490;
      uStack_1050e = (ushort)(uStack_10490 >> 0x10);
      uStack_1050c = (ushort)(uStack_10490 >> 0x20);
      uStack_1050a = (ushort)(uStack_10490 >> 0x30);
      bStack_10528 = bStack_104a8;
      bStack_10527 = bStack_104a7;
      bStack_10526 = (byte)uStack_104a6;
      bStack_10525 = (byte)(uStack_104a6 >> 8);
      bStack_10524 = (byte)uStack_104a4;
      bStack_10523 = (byte)(uStack_104a4 >> 8);
      bStack_10522 = (byte)uStack_104a2;
      bStack_10521 = (byte)(uStack_104a2 >> 8);
      bStack_10520 = (byte)uStack_104a0;
      bStack_1051f = (byte)(uStack_104a0 >> 8);
      bStack_1051e = (byte)uStack_1049e;
      bStack_1051d = (byte)(uStack_1049e >> 8);
      bStack_1051c = (byte)uStack_1049c;
      bStack_1051b = (byte)(uStack_1049c >> 8);
      bStack_1051a = (byte)(uStack_1049c >> 0x10);
      bStack_10519 = (byte)(uStack_1049c >> 0x18);
      pauVar82 = uStack_103c8;
      greet_heard(1,uStack_103c8,&bStack_10528);
      uVar78 = SUB84(pauVar82,0);
      goto LAB_14002d357;
    }
    uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
    uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
  }
  auVar143[0] = -(*pcVar109 == cVar72);
  auVar143[1] = -(pcVar109[1] == cVar181);
  auVar143[2] = -(pcVar109[2] == cVar182);
  auVar143[3] = -(pcVar109[3] == cVar183);
  auVar143[4] = -(pcVar109[4] == cVar184);
  auVar143[5] = -(pcVar109[5] == cVar185);
  auVar143[6] = -(pcVar109[6] == cVar186);
  auVar143[7] = -(pcVar109[7] == cVar187);
  auVar143[8] = -(pcVar109[8] == cVar188);
  auVar143[9] = -(pcVar109[9] == cVar189);
  auVar143[10] = -(pcVar109[10] == cVar190);
  auVar143[0xb] = -(pcVar109[0xb] == cVar191);
  auVar143[0xc] = -(pcVar109[0xc] == cVar192);
  auVar143[0xd] = -(pcVar109[0xd] == cVar193);
  auVar143[0xe] = -(pcVar109[0xe] == cVar194);
  auVar143[0xf] = -(pcVar109[0xf] == cVar195);
  if ((((((((((((((((SUB161(auVar143 >> 7,0) & 1) != 0 || (SUB161(auVar143 >> 0xf,0) & 1) != 0) ||
                  (SUB161(auVar143 >> 0x17,0) & 1) != 0) || (SUB161(auVar143 >> 0x1f,0) & 1) != 0)
                || (SUB161(auVar143 >> 0x27,0) & 1) != 0) || (SUB161(auVar143 >> 0x2f,0) & 1) != 0)
              || (SUB161(auVar143 >> 0x37,0) & 1) != 0) || (SUB161(auVar143 >> 0x3f,0) & 1) != 0) ||
            (SUB161(auVar143 >> 0x47,0) & 1) != 0) || (SUB161(auVar143 >> 0x4f,0) & 1) != 0) ||
          (SUB161(auVar143 >> 0x57,0) & 1) != 0) || (SUB161(auVar143 >> 0x5f,0) & 1) != 0) ||
        (SUB161(auVar143 >> 0x67,0) & 1) != 0) || (SUB161(auVar143 >> 0x6f,0) & 1) != 0) ||
      (SUB161(auVar143 >> 0x77,0) & 1) != 0) || auVar143[0xf] < '\0') goto LAB_1400349bb;
  uVar117 = uVar117 + lVar80 + 0x10;
  lVar80 = lVar80 + 0x10;
  goto LAB_14002cdc2;
LAB_1400349bb:
  core[505b25137b8ba7f]::option::unwrap_failed
            (&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a29c0);
  goto LAB_140036cf0;
LAB_14002cce8:
  uVar81 = uVar81 & uVar117;
  pcVar109 = *uStack_104b8 + uVar81;
  auVar170[0] = -(*pcVar109 == auVar133[0]);
  auVar170[1] = -(pcVar109[1] == auVar133[1]);
  auVar170[2] = -(pcVar109[2] == auVar133[2]);
  auVar170[3] = -(pcVar109[3] == auVar133[3]);
  auVar170[4] = -(pcVar109[4] == auVar133[4]);
  auVar170[5] = -(pcVar109[5] == auVar133[5]);
  auVar170[6] = -(pcVar109[6] == auVar133[6]);
  auVar170[7] = -(pcVar109[7] == auVar133[7]);
  auVar170[8] = -(pcVar109[8] == auVar133[0]);
  auVar170[9] = -(pcVar109[9] == auVar133[1]);
  auVar170[10] = -(pcVar109[10] == auVar133[2]);
  auVar170[0xb] = -(pcVar109[0xb] == auVar133[3]);
  auVar170[0xc] = -(pcVar109[0xc] == auVar133[4]);
  auVar170[0xd] = -(pcVar109[0xd] == auVar133[5]);
  auVar170[0xe] = -(pcVar109[0xe] == auVar133[6]);
  auVar170[0xf] = -(pcVar109[0xf] == auVar133[7]);
  uVar112 = (ushort)(SUB161(auVar170 >> 7,0) & 1) | (ushort)(SUB161(auVar170 >> 0xf,0) & 1) << 1 |
            (ushort)(SUB161(auVar170 >> 0x17,0) & 1) << 2 |
            (ushort)(SUB161(auVar170 >> 0x1f,0) & 1) << 3 |
            (ushort)(SUB161(auVar170 >> 0x27,0) & 1) << 4 |
            (ushort)(SUB161(auVar170 >> 0x2f,0) & 1) << 5 |
            (ushort)(SUB161(auVar170 >> 0x37,0) & 1) << 6 |
            (ushort)(SUB161(auVar170 >> 0x3f,0) & 1) << 7 |
            (ushort)(SUB161(auVar170 >> 0x47,0) & 1) << 8 |
            (ushort)(SUB161(auVar170 >> 0x4f,0) & 1) << 9 |
            (ushort)(SUB161(auVar170 >> 0x57,0) & 1) << 10 |
            (ushort)(SUB161(auVar170 >> 0x5f,0) & 1) << 0xb |
            (ushort)(SUB161(auVar170 >> 0x67,0) & 1) << 0xc |
            (ushort)(SUB161(auVar170 >> 0x6f,0) & 1) << 0xd |
            (ushort)(SUB161(auVar170 >> 0x77,0) & 1) << 0xe | (ushort)(auVar170[0xf] >> 7) << 0xf;
  uVar113 = (uint)uVar112;
  while (uVar112 != 0) {
    uVar114 = 0;
    for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
      uVar114 = uVar114 + 1;
    }
    uVar83 = uVar114 + uVar81 & uVar117;
    if (pauVar82 == *(undefined1 (**) [16])uStack_104b8[uVar83 * -5 + -5]) {
      uStack_10438._4_4_ = CONCAT22(uStack_104a2,uStack_104a4);
      bStack_10428 = (byte)uStack_10498;
      bStack_10427 = (byte)(uStack_10498 >> 8);
      uStack_10426 = uStack_10496;
      uStack_10424 = uStack_10494;
      uStack_10420 = (uint)uStack_10490;
      uStack_1041c = (ushort)(uStack_10490 >> 0x20);
      uStack_1041a = (ushort)(uStack_10490 >> 0x30);
      uStack_10438._0_1_ = bStack_104a8;
      uStack_10438._1_1_ = bStack_104a7;
      uStack_10438._2_1_ = (byte)uStack_104a6;
      uStack_10438._3_1_ = (byte)(uStack_104a6 >> 8);
      bStack_10430 = (byte)uStack_104a0;
      bStack_1042f = (byte)(uStack_104a0 >> 8);
      uStack_1042e = uStack_1049e;
      uStack_1042c = uStack_1049c;
      iStack_10326 = (int)((ulonglong)pauVar82 >> 0x10);
      uStack_10322 = (ushort)((ulonglong)pauVar82 >> 0x30);
      LOCK();
      bVar129 = note_dropped::NOTED == '\0';
      if (bVar129) {
        note_dropped::NOTED = '\x01';
      }
      UNLOCK();
      bStack_10328 = bVar75;
      bStack_10327 = bVar73;
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended
                  (&note_dropped::NOTED);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar76 = 0;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar76 = bVar76 ^ 1;
      }
      if (DAT_1407f01a1 != '\0') {
        bStack_10528 = 0xa0;
        bStack_10527 = 1;
        bStack_10526 = 0x7f;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar76;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &
                   PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0e70
                   ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a1ff8
                  );
        goto LAB_140036cf0;
      }
      if (DAT_1407f01a8 == (undefined *)0x0) {
        if (*(longlong *)
             __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
            != 0) {
          std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
        }
        if (*(int *)(
                    __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                    + 0x18) == 0) {
          DVar108 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                              (
                              __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                              );
          plVar94 = TlsGetValue(DVar108);
        }
        else {
          DVar108 = *(int *)(
                            __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                            + 0x18) - 1;
          plVar94 = TlsGetValue(DVar108);
        }
        if (plVar94 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
          plVar94 = (longlong *)
                    <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                    ::try_initialize::
                    <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                              (DVar108,plVar94,0);
        }
        if (plVar94 == (longlong *)0x0) {
          std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                    (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
          goto LAB_140036cf0;
        }
        _DAT_1407f01c8 = *plVar94;
        lRam00000001407f01d0 = plVar94[1];
        *plVar94 = *plVar94 + 1;
        _DAT_1407f01b8 = 0;
        DAT_1407f01c0 = 0;
        DAT_1407f01a8 = &DAT_1406a0540;
        uRam00000001407f01b0 = 0;
LAB_14002de06:
        bStack_10524 = (byte)((ulonglong)pauVar82 >> 0x20);
        bStack_10523 = (byte)((ulonglong)pauVar82 >> 0x28);
        bStack_10522 = (byte)((ulonglong)pauVar82 >> 0x30);
        bStack_10521 = (byte)((ulonglong)pauVar82 >> 0x38);
        uStack_10510 = CONCAT11(bStack_10427,bStack_10428);
        uStack_1050e = uStack_10426;
        uStack_1050c = (ushort)uStack_10424;
        uStack_1050a = (ushort)(uStack_10424 >> 0x10);
        uStack_10508._0_4_ = uStack_10420;
        uStack_10508._4_4_ =
             (uint)(CONCAT26(uStack_1041a,CONCAT24(uStack_1041c,uStack_10420)) >> 0x20);
        bStack_10520 = (byte)uStack_10438;
        bStack_1051f = uStack_10438._1_1_;
        bStack_1051e = uStack_10438._2_1_;
        bStack_1051d = uStack_10438._3_1_;
        bStack_1051c = (byte)uStack_10438._4_4_;
        bStack_1051b = (byte)((uint)uStack_10438._4_4_ >> 8);
        bStack_1051a = (byte)((uint)uStack_10438._4_4_ >> 0x10);
        bStack_10519 = (byte)((uint)uStack_10438._4_4_ >> 0x18);
        bStack_10518 = bStack_10430;
        bStack_10517 = bStack_1042f;
        uStack_10516 = uStack_1042e;
        uStack_10514 = uStack_1042c;
        bStack_10528 = bVar75;
        bStack_10527 = bVar73;
        bStack_10526 = bVar54;
        bStack_10525 = bVar55;
        cVar74 = <hashbrown[ad6d4a1843b2832d]::map::HashMap<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr),(),std[3bf9d48a0c3997f0]::hash::random::RandomState>>
                 ::insert(&DAT_1407f01a8,&bStack_10528);
        if (cVar74 != '\0') goto LAB_14002de40;
        bVar129 = pauVar79[uVar83 * -5 + -2][8] != '\0';
        puVar88 = (undefined *)0x1;
        if (bVar129) {
          puVar88 = &DAT_1406a2010;
        }
        auStack_10270[0] = 0;
        if (bVar129) {
          auStack_10270[0] = 10;
        }
        uStack_10278._0_1_ = (byte)puVar88;
        uStack_10278._1_1_ = (byte)((ulonglong)puVar88 >> 8);
        uStack_10276 = (ushort)((ulonglong)puVar88 >> 0x10);
        uStack_10274 = (ushort)((ulonglong)puVar88 >> 0x20);
        uStack_10272 = 0;
        auStack_10270[1]._0_2_ = 0;
        auStack_10270[1]._2_2_ = 0;
        uStack_10508 = (undefined1 (**) [16])(pauVar79[uVar83 * -5 + -4] + 8);
        bStack_10528 = (byte)&bStack_10328;
        bStack_10527 = (byte)((ulonglong)&bStack_10328 >> 8);
        bStack_10526 = (byte)((ulonglong)&bStack_10328 >> 0x10);
        bStack_10525 = (byte)((ulonglong)&bStack_10328 >> 0x18);
        bStack_10524 = (byte)((ulonglong)&bStack_10328 >> 0x20);
        bStack_10523 = (byte)((ulonglong)&bStack_10328 >> 0x28);
        bStack_10522 = (byte)((ulonglong)&bStack_10328 >> 0x30);
        bStack_10521 = (byte)((ulonglong)&bStack_10328 >> 0x38);
        bStack_10520 = 0x30;
        bStack_1051f = 0xf0;
        bStack_1051e = 0x68;
        bStack_1051d = 0x40;
        bStack_1051c = 1;
        bStack_1051b = 0;
        bStack_1051a = 0;
        bStack_10519 = 0;
        bStack_10518 = (byte)&uStack_10438;
        bStack_10517 = (byte)((ulonglong)&uStack_10438 >> 8);
        uStack_10516 = (ushort)((ulonglong)&uStack_10438 >> 0x10);
        uStack_10514 = (uint)((ulonglong)&uStack_10438 >> 0x20);
        uStack_10510 = 60000;
        uStack_1050e = 0x4068;
        uStack_1050c = 1;
        uStack_1050a = 0;
        uStack_10500._0_4_ = 0x4068ea60;
        uStack_10500._4_4_ = 1;
        uStack_104f8 = &uStack_10278;
        uStack_104f0 = 0x402428d0;
        uStack_104ec = 1;
        alloc[246c2e7857c81348]::fmt::format::format_inner
                  (&uStack_103a8,&DAT_1406a201a,&bStack_10528);
        lVar80 = CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
        uVar85 = CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0));
        host::log(uVar85,CONCAT44(uStack_10394,CONCAT22(uStack_10396,uStack_10398)));
        if (lVar80 != 0) {
          pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar80,1)
          ;
          return pauVar82;
        }
        if (0x100 < DAT_1407f01c0) {
          host::log("net: more dropped datagrams; not logging them",0x2d);
        }
        uStack_10500 = (undefined1 (*) [16])CONCAT44(uStack_10500._4_4_,(uint)uStack_10500);
        if ((bVar76 == 0) &&
           (uStack_10500 = (undefined1 (*) [16])CONCAT44(uStack_10500._4_4_,(uint)uStack_10500),
           (*(ulonglong *)
             __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
           0x7fffffffffffffff) != 0)) {
          cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
          goto LAB_140033e7b;
        }
      }
      else {
        if (DAT_1407f01c0 < 0x101) goto LAB_14002de06;
LAB_14002de40:
        if ((bVar76 == 0) &&
           ((*(ulonglong *)
              __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
            0x7fffffffffffffff) != 0)) {
          cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
LAB_140033e7b:
          if (cVar74 == '\0') {
            DAT_1407f01a1 = '\x01';
          }
        }
      }
      cVar74 = note_dropped::NOTED;
      LOCK();
      note_dropped::NOTED = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&note_dropped::NOTED);
      }
      goto LAB_14002dfa3;
    }
    uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
    uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
  }
  auVar142[0] = -(*pcVar109 == cVar72);
  auVar142[1] = -(pcVar109[1] == cVar181);
  auVar142[2] = -(pcVar109[2] == cVar182);
  auVar142[3] = -(pcVar109[3] == cVar183);
  auVar142[4] = -(pcVar109[4] == cVar184);
  auVar142[5] = -(pcVar109[5] == cVar185);
  auVar142[6] = -(pcVar109[6] == cVar186);
  auVar142[7] = -(pcVar109[7] == cVar187);
  auVar142[8] = -(pcVar109[8] == cVar188);
  auVar142[9] = -(pcVar109[9] == cVar189);
  auVar142[10] = -(pcVar109[10] == cVar190);
  auVar142[0xb] = -(pcVar109[0xb] == cVar191);
  auVar142[0xc] = -(pcVar109[0xc] == cVar192);
  auVar142[0xd] = -(pcVar109[0xd] == cVar193);
  auVar142[0xe] = -(pcVar109[0xe] == cVar194);
  auVar142[0xf] = -(pcVar109[0xf] == cVar195);
  if ((((((((((((((((SUB161(auVar142 >> 7,0) & 1) != 0 || (SUB161(auVar142 >> 0xf,0) & 1) != 0) ||
                  (SUB161(auVar142 >> 0x17,0) & 1) != 0) || (SUB161(auVar142 >> 0x1f,0) & 1) != 0)
                || (SUB161(auVar142 >> 0x27,0) & 1) != 0) || (SUB161(auVar142 >> 0x2f,0) & 1) != 0)
              || (SUB161(auVar142 >> 0x37,0) & 1) != 0) || (SUB161(auVar142 >> 0x3f,0) & 1) != 0) ||
            (SUB161(auVar142 >> 0x47,0) & 1) != 0) || (SUB161(auVar142 >> 0x4f,0) & 1) != 0) ||
          (SUB161(auVar142 >> 0x57,0) & 1) != 0) || (SUB161(auVar142 >> 0x5f,0) & 1) != 0) ||
        (SUB161(auVar142 >> 0x67,0) & 1) != 0) || (SUB161(auVar142 >> 0x6f,0) & 1) != 0) ||
      (SUB161(auVar142 >> 0x77,0) & 1) != 0) || auVar142[0xf] < '\0') {
    core[505b25137b8ba7f]::option::expect_failed
              ("no entry found for key",0x16,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2ab8);
    goto LAB_140036cf0;
  }
  uVar81 = uVar81 + lVar80 + 0x10;
  lVar80 = lVar80 + 0x10;
  goto LAB_14002cce8;
LAB_14002d6af:
  pcVar109 = &INTRODUCED;
  bVar75 = bStack_10520;
joined_r0x00014002ce72:
  bStack_10520 = bVar76;
  if ((bVar75 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      pcVar109[1] = '\x01';
    }
  }
  LOCK();
  cVar74 = *pcVar109;
  *pcVar109 = '\0';
  UNLOCK();
joined_r0x00014002d985:
  if (cVar74 == '\x02') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
  }
LAB_14002ce9d:
  pauVar82 = HOST_ID_0_llvm_14435704873730135342;
  bVar129 = IS_HOST_0_llvm_14435704873730135342 != '\0';
  bVar130 = HOST_ID_0_llvm_14435704873730135342 == (undefined1 (*) [16])0x0;
  LOCK();
  bVar131 = LISTED == '\0';
  if (bVar131) {
    LISTED = '\x01';
  }
  UNLOCK();
  if (!bVar131) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LISTED);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar76 = 0;
  }
  else {
    bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar76 = bVar76 ^ 1;
  }
  if (DAT_1406996d1 != '\0') {
    bStack_10528 = 0xd0;
    bStack_10527 = 0x96;
    bStack_10526 = 0x69;
    bStack_10525 = 0x40;
    bStack_10524 = 1;
    bStack_10523 = 0;
    bStack_10522 = 0;
    bStack_10521 = 0;
    bStack_10520 = bVar76;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
               &
               PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a0ef0
               ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2a20);
    goto LAB_140036cf0;
  }
  if (DAT_1406996d8 == -1) {
    if (*(longlong *)
         __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
        != 0) {
      std[3bf9d48a0c3997f0]::sys::thread_local::guard::windows::enable();
    }
    if (*(int *)(
                __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                + 0x18) == 0) {
      DVar108 = <std[3bf9d48a0c3997f0]::sys::thread_local::key::windows::LazyKey>::init
                          (
                          __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                          );
      plVar94 = TlsGetValue(DVar108);
    }
    else {
      DVar108 = *(int *)(
                        __imp__RNvNCNvNvMNtNtCs59fwaEIuEkC_3std4hash6randomNtB8_11RandomState3new4KEYS023___RUST_STD_INTERNAL_VAL
                        + 0x18) - 1;
      plVar94 = TlsGetValue(DVar108);
    }
    if (plVar94 < (longlong *)0x2) {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      plVar94 = (longlong *)
                <std[3bf9d48a0c3997f0]::sys::thread_local::os::Storage<core[505b25137b8ba7f]::cell::Cell<(u64,u64)>,8usize>>
                ::try_initialize::
                <<std[3bf9d48a0c3997f0]::hash::random::RandomState>::new::KEYS::__rust_std_internal_init_fn>
                          (DVar108,plVar94,0);
    }
    if (plVar94 == (longlong *)0x0) {
      std[3bf9d48a0c3997f0]::thread::local::panic_access_error
                (&anon_34f15a90fcba3ed6a32c120778b34e05_3_llvm_15918893398050881851);
      goto LAB_140036cf0;
    }
    DAT_1406996d8 = 0;
    _DAT_1406996e0 = 8;
    _DAT_1406996e8 = (undefined1  [16])0x0;
    _DAT_140699718 = *plVar94;
    lRam0000000140699720 = plVar94[1];
    *plVar94 = *plVar94 + 1;
    _DAT_140699708 = 0;
    DAT_140699710 = 0;
    DAT_1406996f8 = &DAT_1406a0540;
    DAT_140699700 = 0;
  }
  pauVar79 = uStack_103c8;
  uVar113 = uStack_10494;
  uVar112 = CONCAT11(bStack_104a7,bStack_104a8);
  unaff_R15 = (undefined1 (*) [16])(ulonglong)uVar112;
  bStack_10528 = (byte)uStack_104a6;
  bStack_10527 = (byte)(uStack_104a6 >> 8);
  bStack_10526 = (byte)uStack_104a4;
  bStack_10525 = (byte)(uStack_104a4 >> 8);
  bStack_10524 = (byte)uStack_104a2;
  bStack_10523 = (byte)(uStack_104a2 >> 8);
  bStack_10522 = (byte)uStack_104a0;
  bStack_10521 = (byte)(uStack_104a0 >> 8);
  bStack_10520 = (byte)uStack_1049e;
  bStack_1051f = (byte)(uStack_1049e >> 8);
  bStack_1051e = (byte)uStack_1049c;
  bStack_1051d = (byte)(uStack_1049c >> 8);
  bStack_1051c = (byte)(uStack_1049c >> 0x10);
  bStack_1051b = (byte)(uStack_1049c >> 0x18);
  bStack_1051a = (byte)uStack_10498;
  bStack_10519 = (byte)(uStack_10498 >> 8);
  bStack_10518 = (byte)uStack_10496;
  bStack_10517 = (byte)(uStack_10496 >> 8);
  iVar127 = (int)uStack_10490;
  sVar116 = uStack_10490._4_2_;
  uStack_10438._0_1_ = (byte)uStack_103c8;
  uStack_10438._1_1_ = (byte)((ulonglong)uStack_103c8 >> 8);
  uStack_10438._2_1_ = (byte)((ulonglong)uStack_103c8 >> 0x10);
  uStack_10438._3_1_ = (byte)((ulonglong)uStack_103c8 >> 0x18);
  uStack_10438._4_4_ = (int)((ulonglong)uStack_103c8 >> 0x20);
  if ((bVar130 || bVar129) || uStack_103c8 == pauVar82) {
LAB_14002d108:
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar74 == '\0') {
        DAT_1406996d1 = '\x01';
      }
    }
    cVar74 = LISTED;
    LOCK();
    LISTED = '\0';
    UNLOCK();
    if (cVar74 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LISTED);
    }
    puVar88 = (undefined *)0x1;
    if (bStack_10471 != 0) {
      puVar88 = &DAT_1406a2010;
    }
    uStack_103a0 = 0;
    if (bStack_10471 != 0) {
      uStack_103a0 = 10;
    }
    uStack_103a8 = (ushort)puVar88;
    uStack_103a6 = (ushort)((ulonglong)puVar88 >> 0x10);
    uStack_103a4 = (ushort)((ulonglong)puVar88 >> 0x20);
    uStack_103a2 = 0;
    uStack_1039e = 0;
    uStack_1039c = 0;
    bStack_10528 = (byte)&uStack_103c8;
    bStack_10527 = (byte)((ulonglong)&uStack_103c8 >> 8);
    bStack_10526 = (byte)((ulonglong)&uStack_103c8 >> 0x10);
    bStack_10525 = (byte)((ulonglong)&uStack_103c8 >> 0x18);
    bStack_10524 = (byte)((ulonglong)&uStack_103c8 >> 0x20);
    bStack_10523 = (byte)((ulonglong)&uStack_103c8 >> 0x28);
    bStack_10522 = (byte)((ulonglong)&uStack_103c8 >> 0x30);
    bStack_10521 = (byte)((ulonglong)&uStack_103c8 >> 0x38);
    bStack_10520 = 0x30;
    bStack_1051f = 0xf0;
    bStack_1051e = 0x68;
    bStack_1051d = 0x40;
    bStack_1051c = 1;
    bStack_1051b = 0;
    bStack_1051a = 0;
    bStack_10519 = 0;
    bStack_10518 = (byte)&bStack_104a8;
    bStack_10517 = (byte)((ulonglong)&bStack_104a8 >> 8);
    uStack_10516 = (ushort)((ulonglong)&bStack_104a8 >> 0x10);
    uStack_10514 = (uint)((ulonglong)&bStack_104a8 >> 0x20);
    uStack_10510 = 60000;
    uStack_1050e = 0x4068;
    uStack_1050c = 1;
    uStack_1050a = 0;
    uStack_10508 = (undefined1 (**) [16])&uStack_103a8;
    uStack_10500._0_4_ = 0x402428d0;
    uStack_10500._4_4_ = 1;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&uStack_10438,&DAT_1406a2a38,&bStack_10528);
    lVar80 = CONCAT44(uStack_10438._4_4_,
                      CONCAT13(uStack_10438._3_1_,
                               CONCAT12(uStack_10438._2_1_,
                                        CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))));
    uVar85 = CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
    host::log(uVar85,CONCAT44(uStack_10424,
                              CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428))));
    if (lVar80 != 0) {
      pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar80,1);
      return pauVar82;
    }
    bStack_10528 = (byte)&bStack_104a8;
    bStack_10527 = (byte)((ulonglong)&bStack_104a8 >> 8);
    bStack_10526 = (byte)((ulonglong)&bStack_104a8 >> 0x10);
    bStack_10525 = (byte)((ulonglong)&bStack_104a8 >> 0x18);
    bStack_10524 = (byte)((ulonglong)&bStack_104a8 >> 0x20);
    bStack_10523 = (byte)((ulonglong)&bStack_104a8 >> 0x28);
    bStack_10522 = (byte)((ulonglong)&bStack_104a8 >> 0x30);
    bStack_10521 = (byte)((ulonglong)&bStack_104a8 >> 0x38);
    bStack_10520 = (byte)&bStack_10471;
    bStack_1051f = (byte)((ulonglong)&bStack_10471 >> 8);
    bStack_1051e = (byte)((ulonglong)&bStack_10471 >> 0x10);
    bStack_1051d = (byte)((ulonglong)&bStack_10471 >> 0x18);
    bStack_1051c = (byte)((ulonglong)&bStack_10471 >> 0x20);
    bStack_1051b = (byte)((ulonglong)&bStack_10471 >> 0x28);
    bStack_1051a = (byte)((ulonglong)&bStack_10471 >> 0x30);
    bStack_10519 = (byte)((ulonglong)&bStack_10471 >> 0x38);
    bStack_10518 = (byte)&uStack_103c8;
    bStack_10517 = (byte)((ulonglong)&uStack_103c8 >> 8);
    uStack_10516 = (ushort)((ulonglong)&uStack_103c8 >> 0x10);
    uStack_10514 = (uint)((ulonglong)&uStack_103c8 >> 0x20);
    uStack_10510 = 0x9830;
    uStack_1050e = 0x4069;
    uStack_1050c = 1;
    uStack_1050a = 0;
    uVar78 = SUB84(&bStack_10528,0);
    <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
    ::retain::<host_probe[b94139f9089eb1d8]::net::receive::_closure_12_>(&DAT_140699950);
    bStack_10428 = bStack_10461;
    uStack_10438._0_1_ = bStack_10471;
    uStack_10438._1_1_ = (byte)uStack_10470;
    uStack_10438._2_1_ = (byte)((uint7)uStack_10470 >> 8);
    uStack_10438._3_1_ = (byte)((uint7)uStack_10470 >> 0x10);
    uStack_10438._4_4_ = (int)((uint7)uStack_10470 >> 0x18);
    bStack_10430 = bStack_10469;
    bStack_1042f = (byte)uStack_10468;
    uStack_1042e = (ushort)((uint7)uStack_10468 >> 8);
    uStack_1042c = (uint)((uint7)uStack_10468 >> 0x18);
    uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    uStack_10514 = CONCAT22(uStack_104a2,uStack_104a4);
    uStack_10508._0_4_ = CONCAT22(uStack_10496,uStack_10498);
    uStack_10508._4_4_ = uStack_10494;
    uStack_10500._0_4_ = (uint)uStack_10490;
    uStack_10500._4_4_ = (uint)(uStack_10490 >> 0x20);
    bStack_10518 = bStack_104a8;
    bStack_10517 = bStack_104a7;
    uStack_10516 = uStack_104a6;
    uStack_10510 = uStack_104a0;
    uStack_1050e = uStack_1049e;
    uStack_1050c = (ushort)uStack_1049c;
    uStack_1050a = (ushort)(uStack_1049c >> 0x10);
    uStack_104e8 = CONCAT31(uStack_104e8._1_3_,bStack_10428);
    uStack_104f8._0_4_ =
         CONCAT13(uStack_10438._3_1_,
                  CONCAT12(uStack_10438._2_1_,CONCAT11(uStack_10438._1_1_,(byte)uStack_10438)));
    uStack_104f0 = CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430));
    uStack_104f8._4_4_ = uStack_10438._4_4_;
    uStack_104ec = uStack_1042c;
    bStack_10528 = (byte)uVar85;
    bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
    bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
    bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
    bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
    bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
    bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
    bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
    bStack_10520 = (byte)uVar78;
    bStack_1051f = (byte)((uint)uVar78 >> 8);
    bStack_1051e = (byte)((uint)uVar78 >> 0x10);
    bStack_1051d = (byte)((uint)uVar78 >> 0x18);
    uVar78 = 0x40699950;
    <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
    ::insert(&uStack_10438,&DAT_140699950,uStack_103c8,&bStack_10528);
    LOCK();
    bVar129 = TRANSPORT == '\0';
    if (bVar129) {
      TRANSPORT = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&TRANSPORT);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar75 = 0;
      bVar76 = bStack_10520;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar75 = bVar76 ^ 1;
      bVar76 = bStack_10520;
    }
    bStack_10520 = bVar75;
    if (DAT_140699831 != '\0') {
      bStack_10528 = 0x30;
      bStack_10527 = 0x98;
      bStack_10526 = 0x69;
      bStack_10525 = 0x40;
      bStack_10524 = 1;
      bStack_10523 = 0;
      bStack_10522 = 0;
      bStack_10521 = 0;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                 &
                 PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
                 ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2a58);
      goto LAB_140036cf0;
    }
    DAT_140699840 = 0xffffffff;
    bVar129 = bStack_10520 == 0;
    bStack_10520 = bVar76;
    if ((bVar129) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar74 == '\0') {
        DAT_140699831 = '\x01';
      }
    }
    cVar74 = TRANSPORT;
    LOCK();
    TRANSPORT = '\0';
    UNLOCK();
    if (cVar74 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
    }
LAB_14002d357:
    if (((char)uStack_104c0 == '\0') &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar74 == '\0') {
        DAT_140699949 = '\x01';
      }
    }
    cVar74 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar74 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    if (((HOST_ID_0_llvm_14435704873730135342 != (undefined1 (*) [16])0x0) &&
        (IS_HOST_0_llvm_14435704873730135342 == '\0')) &&
       (HOST_ID_0_llvm_14435704873730135342 == uStack_103c8)) {
      uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
      LOCK();
      bVar129 = HOST_HEARD == '\0';
      if (bVar129) {
        HOST_HEARD = '\x01';
      }
      UNLOCK();
      uVar97 = uVar78;
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&HOST_HEARD);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar75 = 0;
        bVar76 = bStack_10520;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar75 = bVar76 ^ 1;
        bVar76 = bStack_10520;
      }
      bStack_10520 = bVar75;
      if (DAT_140699511 != '\0') {
        bStack_10528 = 0x10;
        bStack_10527 = 0x95;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2a70)
        ;
        goto LAB_140036cf0;
      }
      bVar129 = bStack_10520 == 0;
      DAT_140699518 = uVar85;
      DAT_140699520 = uVar78;
      bStack_10520 = bVar76;
      if ((bVar129) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          DAT_140699511 = '\x01';
        }
      }
      cVar74 = HOST_HEARD;
      LOCK();
      HOST_HEARD = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&HOST_HEARD);
      }
      LOCK();
      bVar129 = TRANSPORT == '\0';
      if (bVar129) {
        TRANSPORT = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&TRANSPORT);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar75 = 0;
        uVar78 = uVar97;
        bVar76 = bStack_10520;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar75 = bVar76 ^ 1;
        uVar78 = uVar97;
        bVar76 = bStack_10520;
      }
      bStack_10520 = bVar75;
      if (DAT_140699831 != '\0') {
        bStack_10528 = 0x30;
        bStack_10527 = 0x98;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &
                   PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<core[505b25137b8ba7f]::option::Option<std[3bf9d48a0c3997f0]::collections::hash::map::HashMap<u64,(u64,usize,u64)>>>>>_1406a1130
                   ,&PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2a88
                  );
        goto LAB_140036cf0;
      }
      DAT_1406998da = '\x01';
      bVar129 = bStack_10520 == 0;
      bStack_10520 = bVar76;
      if ((bVar129) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          DAT_140699831 = '\x01';
        }
      }
      cVar74 = TRANSPORT;
      LOCK();
      TRANSPORT = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&TRANSPORT);
      }
    }
    if (DAT_140699988 != '\0') {
      LOCK();
      bVar129 = DAT_1406998e8 == '\0';
      if (bVar129) {
        DAT_1406998e8 = '\x01';
      }
      UNLOCK();
      if (!bVar129) {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_1406998e8);
      }
      if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) == 0) {
        bVar76 = 0;
      }
      else {
        bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        bVar76 = bVar76 ^ 1;
      }
      if (DAT_1406998e9 != '\0') {
        bStack_10528 = 0xe8;
        bStack_10527 = 0x98;
        bStack_10526 = 0x69;
        bStack_10525 = 0x40;
        bStack_10524 = 1;
        bStack_10523 = 0;
        bStack_10522 = 0;
        bStack_10521 = 0;
        bStack_10520 = bVar76;
        core[505b25137b8ba7f]::result::unwrap_failed
                  ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                   &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2aa0)
        ;
        goto LAB_140036cf0;
      }
      uStack_10438._1_1_ = (byte)uStack_10470;
      uStack_10438._2_1_ = (byte)((uint7)uStack_10470 >> 8);
      uStack_10438._3_1_ = (byte)((uint7)uStack_10470 >> 0x10);
      uStack_10438._4_4_ = (int)((uint7)uStack_10470 >> 0x18);
      bStack_1042f = (byte)uStack_10468;
      uStack_1042e = (ushort)((uint7)uStack_10468 >> 8);
      uStack_1042c = (uint)((uint7)uStack_10468 >> 0x18);
      uStack_10438._0_1_ = bStack_10471;
      bStack_10430 = bStack_10469;
      bStack_10428 = bStack_10461;
      uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
      uStack_10514 = CONCAT22(uStack_104a2,uStack_104a4);
      uStack_10508._0_4_ = CONCAT22(uStack_10496,uStack_10498);
      uStack_10508._4_4_ = uStack_10494;
      uStack_10500._0_4_ = (uint)uStack_10490;
      uStack_10500._4_4_ = (uint)(uStack_10490 >> 0x20);
      bStack_10518 = bStack_104a8;
      bStack_10517 = bStack_104a7;
      uStack_10516 = uStack_104a6;
      uStack_10510 = uStack_104a0;
      uStack_1050e = uStack_1049e;
      uStack_1050c = (ushort)uStack_1049c;
      uStack_1050a = (ushort)(uStack_1049c >> 0x10);
      uStack_104e8 = CONCAT31(uStack_104e8._1_3_,bStack_10428);
      uStack_104f8._0_4_ =
           CONCAT13(uStack_10438._3_1_,
                    CONCAT12(uStack_10438._2_1_,CONCAT11(uStack_10438._1_1_,(byte)uStack_10438)));
      uStack_104f0 = CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430));
      uStack_104f8._4_4_ = uStack_10438._4_4_;
      uStack_104ec = uStack_1042c;
      bStack_10528 = (byte)uVar85;
      bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
      bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
      bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
      bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
      bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
      bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
      bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
      bStack_10520 = (byte)uVar78;
      bStack_1051f = (byte)((uint)uVar78 >> 8);
      bStack_1051e = (byte)((uint)uVar78 >> 0x10);
      bStack_1051d = (byte)((uint)uVar78 >> 0x18);
      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
      ::insert(&uStack_10438,&DAT_1406998f0,uStack_103c8,&bStack_10528);
      if ((bVar76 == 0) &&
         ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT
          & 0x7fffffffffffffff) != 0)) {
        cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
        if (cVar74 == '\0') {
          DAT_1406998e9 = '\x01';
        }
      }
      cVar74 = DAT_1406998e8;
      LOCK();
      DAT_1406998e8 = '\0';
      UNLOCK();
      if (cVar74 == '\x02') {
        <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_1406998e8);
      }
    }
    netstats::engine_arrival(uStack_103c8);
    queue_engine(&DAT_140699730,uStack_103c8,uStack_10460,uStack_10458);
    if (pauStack_10538 != (undefined1 (*) [16])0x0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_104b0,pauStack_10538,1);
      return pauVar82;
    }
    LOCK();
    DAT_1407f1060 = *pauStack_10448 + (longlong)DAT_1407f1060;
    UNLOCK();
    LOCK();
    DAT_1407f1068 = DAT_1407f1068 + 1;
    UNLOCK();
    goto LAB_14002c3ba;
  }
  if (DAT_140699710 != 0) {
    uVar117 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
              ::hash_one::<&usize>(&DAT_140699718,&uStack_10438);
    bVar75 = (byte)(uVar117 >> 0x39);
    auVar133 = ZEXT216(CONCAT11(bVar75,bVar75));
    auVar133 = pshuflw(auVar133,auVar133,0);
    lVar80 = 0;
    while( true ) {
      uVar117 = uVar117 & DAT_140699700;
      pcVar109 = DAT_1406996f8 + uVar117;
      auVar172[0] = -(*pcVar109 == auVar133[0]);
      auVar172[1] = -(pcVar109[1] == auVar133[1]);
      auVar172[2] = -(pcVar109[2] == auVar133[2]);
      auVar172[3] = -(pcVar109[3] == auVar133[3]);
      auVar172[4] = -(pcVar109[4] == auVar133[4]);
      auVar172[5] = -(pcVar109[5] == auVar133[5]);
      auVar172[6] = -(pcVar109[6] == auVar133[6]);
      auVar172[7] = -(pcVar109[7] == auVar133[7]);
      auVar172[8] = -(pcVar109[8] == auVar133[0]);
      auVar172[9] = -(pcVar109[9] == auVar133[1]);
      auVar172[10] = -(pcVar109[10] == auVar133[2]);
      auVar172[0xb] = -(pcVar109[0xb] == auVar133[3]);
      auVar172[0xc] = -(pcVar109[0xc] == auVar133[4]);
      auVar172[0xd] = -(pcVar109[0xd] == auVar133[5]);
      auVar172[0xe] = -(pcVar109[0xe] == auVar133[6]);
      auVar172[0xf] = -(pcVar109[0xf] == auVar133[7]);
      uVar91 = (ushort)(SUB161(auVar172 >> 7,0) & 1) | (ushort)(SUB161(auVar172 >> 0xf,0) & 1) << 1
               | (ushort)(SUB161(auVar172 >> 0x17,0) & 1) << 2 |
               (ushort)(SUB161(auVar172 >> 0x1f,0) & 1) << 3 |
               (ushort)(SUB161(auVar172 >> 0x27,0) & 1) << 4 |
               (ushort)(SUB161(auVar172 >> 0x2f,0) & 1) << 5 |
               (ushort)(SUB161(auVar172 >> 0x37,0) & 1) << 6 |
               (ushort)(SUB161(auVar172 >> 0x3f,0) & 1) << 7 |
               (ushort)(SUB161(auVar172 >> 0x47,0) & 1) << 8 |
               (ushort)(SUB161(auVar172 >> 0x4f,0) & 1) << 9 |
               (ushort)(SUB161(auVar172 >> 0x57,0) & 1) << 10 |
               (ushort)(SUB161(auVar172 >> 0x5f,0) & 1) << 0xb |
               (ushort)(SUB161(auVar172 >> 0x67,0) & 1) << 0xc |
               (ushort)(SUB161(auVar172 >> 0x6f,0) & 1) << 0xd |
               (ushort)(SUB161(auVar172 >> 0x77,0) & 1) << 0xe | (ushort)(auVar172[0xf] >> 7) << 0xf
      ;
      uVar114 = (uint)uVar91;
      while (uVar91 != 0) {
        uVar96 = 0;
        for (uVar95 = uVar114; (uVar95 & 1) == 0; uVar95 = uVar95 >> 1 | 0x80000000) {
          uVar96 = uVar96 + 1;
        }
        uVar81 = uVar96 + uVar117 & DAT_140699700;
        if (pauVar79 == *(undefined1 (**) [16])(DAT_1406996f8 + uVar81 * -0x28 + -0x28)) {
          if (*(ushort *)(DAT_1406996f8 + uVar81 * -0x28 + -0x20) != uVar112) goto LAB_14002d636;
          if (uVar112 == 1) {
            if ((*(short *)(DAT_1406996f8 + uVar81 * -0x28 + -4) != sVar116) ||
               (((*(uint *)(DAT_1406996f8 + uVar81 * -0x28 + -0xc) != uVar113 ||
                 (*(int *)(DAT_1406996f8 + uVar81 * -0x28 + -8) != iVar127)) ||
                (auVar145[0] = -(bStack_10526 == DAT_1406996f8[uVar81 * -0x28 + -0x1c]),
                auVar145[1] = -(bStack_10525 == DAT_1406996f8[uVar81 * -0x28 + -0x1b]),
                auVar145[2] = -(bStack_10524 == DAT_1406996f8[uVar81 * -0x28 + -0x1a]),
                auVar145[3] = -(bStack_10523 == DAT_1406996f8[uVar81 * -0x28 + -0x19]),
                auVar145[4] = -(bStack_10522 == DAT_1406996f8[uVar81 * -0x28 + -0x18]),
                auVar145[5] = -(bStack_10521 == DAT_1406996f8[uVar81 * -0x28 + -0x17]),
                auVar145[6] = -(bStack_10520 == DAT_1406996f8[uVar81 * -0x28 + -0x16]),
                auVar145[7] = -(bStack_1051f == DAT_1406996f8[uVar81 * -0x28 + -0x15]),
                auVar145[8] = -(bStack_1051e == DAT_1406996f8[uVar81 * -0x28 + -0x14]),
                auVar145[9] = -(bStack_1051d == DAT_1406996f8[uVar81 * -0x28 + -0x13]),
                auVar145[10] = -(bStack_1051c == DAT_1406996f8[uVar81 * -0x28 + -0x12]),
                auVar145[0xb] = -(bStack_1051b == DAT_1406996f8[uVar81 * -0x28 + -0x11]),
                auVar145[0xc] = -(bStack_1051a == DAT_1406996f8[uVar81 * -0x28 + -0x10]),
                auVar145[0xd] = -(bStack_10519 == DAT_1406996f8[uVar81 * -0x28 + -0xf]),
                auVar145[0xe] = -(bStack_10518 == DAT_1406996f8[uVar81 * -0x28 + -0xe]),
                auVar145[0xf] = -(bStack_10517 == DAT_1406996f8[uVar81 * -0x28 + -0xd]),
                (ushort)((ushort)(SUB161(auVar145 >> 7,0) & 1) |
                         (ushort)(SUB161(auVar145 >> 0xf,0) & 1) << 1 |
                         (ushort)(SUB161(auVar145 >> 0x17,0) & 1) << 2 |
                         (ushort)(SUB161(auVar145 >> 0x1f,0) & 1) << 3 |
                         (ushort)(SUB161(auVar145 >> 0x27,0) & 1) << 4 |
                         (ushort)(SUB161(auVar145 >> 0x2f,0) & 1) << 5 |
                         (ushort)(SUB161(auVar145 >> 0x37,0) & 1) << 6 |
                         (ushort)(SUB161(auVar145 >> 0x3f,0) & 1) << 7 |
                         (ushort)(SUB161(auVar145 >> 0x47,0) & 1) << 8 |
                         (ushort)(SUB161(auVar145 >> 0x4f,0) & 1) << 9 |
                         (ushort)(SUB161(auVar145 >> 0x57,0) & 1) << 10 |
                         (ushort)(SUB161(auVar145 >> 0x5f,0) & 1) << 0xb |
                         (ushort)(SUB161(auVar145 >> 0x67,0) & 1) << 0xc |
                         (ushort)(SUB161(auVar145 >> 0x6f,0) & 1) << 0xd |
                         (ushort)(SUB161(auVar145 >> 0x77,0) & 1) << 0xe |
                        (ushort)(auVar145[0xf] >> 7) << 0xf) != 0xffff)))) goto LAB_14002d636;
          }
          else if ((*(short *)(DAT_1406996f8 + uVar81 * -0x28 + -0x1a) !=
                    CONCAT11(bStack_10523,bStack_10524)) ||
                  (*(int *)(DAT_1406996f8 + uVar81 * -0x28 + -0x1e) !=
                   CONCAT13(bStack_10525,CONCAT12(bStack_10526,CONCAT11(bStack_10527,bStack_10528)))
                  )) goto LAB_14002d636;
          goto LAB_14002d108;
        }
        uVar91 = (ushort)(uVar114 - 1) & (ushort)uVar114;
        uVar114 = CONCAT22((short)(uVar114 - 1 >> 0x10),uVar91);
      }
      auVar144[0] = -(*pcVar109 == cVar72);
      auVar144[1] = -(pcVar109[1] == cVar181);
      auVar144[2] = -(pcVar109[2] == cVar182);
      auVar144[3] = -(pcVar109[3] == cVar183);
      auVar144[4] = -(pcVar109[4] == cVar184);
      auVar144[5] = -(pcVar109[5] == cVar185);
      auVar144[6] = -(pcVar109[6] == cVar186);
      auVar144[7] = -(pcVar109[7] == cVar187);
      auVar144[8] = -(pcVar109[8] == cVar188);
      auVar144[9] = -(pcVar109[9] == cVar189);
      auVar144[10] = -(pcVar109[10] == cVar190);
      auVar144[0xb] = -(pcVar109[0xb] == cVar191);
      auVar144[0xc] = -(pcVar109[0xc] == cVar192);
      auVar144[0xd] = -(pcVar109[0xd] == cVar193);
      auVar144[0xe] = -(pcVar109[0xe] == cVar194);
      auVar144[0xf] = -(pcVar109[0xf] == cVar195);
      if ((((((((((((((((SUB161(auVar144 >> 7,0) & 1) != 0 || (SUB161(auVar144 >> 0xf,0) & 1) != 0)
                      || (SUB161(auVar144 >> 0x17,0) & 1) != 0) ||
                     (SUB161(auVar144 >> 0x1f,0) & 1) != 0) || (SUB161(auVar144 >> 0x27,0) & 1) != 0
                    ) || (SUB161(auVar144 >> 0x2f,0) & 1) != 0) ||
                  (SUB161(auVar144 >> 0x37,0) & 1) != 0) || (SUB161(auVar144 >> 0x3f,0) & 1) != 0)
                || (SUB161(auVar144 >> 0x47,0) & 1) != 0) || (SUB161(auVar144 >> 0x4f,0) & 1) != 0)
              || (SUB161(auVar144 >> 0x57,0) & 1) != 0) || (SUB161(auVar144 >> 0x5f,0) & 1) != 0) ||
            (SUB161(auVar144 >> 0x67,0) & 1) != 0) || (SUB161(auVar144 >> 0x6f,0) & 1) != 0) ||
          (SUB161(auVar144 >> 0x77,0) & 1) != 0) || auVar144[0xf] < '\0') break;
      uVar117 = uVar117 + lVar80 + 0x10;
      lVar80 = lVar80 + 0x10;
    }
  }
LAB_14002d636:
  if ((bVar76 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      DAT_1406996d1 = '\x01';
    }
  }
  cVar74 = LISTED;
  LOCK();
  LISTED = '\0';
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LISTED);
  }
LAB_14002dfa3:
  if (((char)uStack_104c0 == '\0') &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
  cVar74 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
LAB_1400331d0:
  if (pauStack_10538 != (undefined1 (*) [16])0x0) goto LAB_1400331d8;
  plVar94 = (longlong *)&DAT_1407f1070;
  if (cStack_10530 == '\x02') {
    plVar94 = &DAT_1407f10e0;
  }
  plVar106 = &DAT_1407f1078;
  if (cStack_10530 == '\x02') {
    plVar106 = &DAT_1407f10e8;
  }
  LOCK();
  *plVar94 = (longlong)(*pauStack_10448 + *plVar94);
  UNLOCK();
  LOCK();
  *plVar106 = *plVar106 + 1;
  UNLOCK();
  if (((sStack_101b0 == 2) && (1 < ((uint)pauStack_101b8 & 3) - 2)) &&
     (((ulonglong)pauStack_101b8 & 3) != 0)) {
    puVar99 = pauStack_101b8[-1] + 0xf;
    bStack_10520 = (byte)puVar99;
    bStack_1051f = (byte)((ulonglong)puVar99 >> 8);
    bStack_1051e = (byte)((ulonglong)puVar99 >> 0x10);
    bStack_1051d = (byte)((ulonglong)puVar99 >> 0x18);
    bStack_1051c = (byte)((ulonglong)puVar99 >> 0x20);
    bStack_1051b = (byte)((ulonglong)puVar99 >> 0x28);
    bStack_1051a = (byte)((ulonglong)puVar99 >> 0x30);
    bStack_10519 = (byte)((ulonglong)puVar99 >> 0x38);
    bStack_10528 = 3;
    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&bStack_10520);
  }
  goto LAB_14002c3ba;
LAB_14002d953:
  bVar129 = bStack_10520 == 0;
  bStack_10520 = bVar76;
  if ((bVar129) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      DAT_140699921 = '\x01';
    }
  }
  cVar74 = DAT_140699920;
  LOCK();
  DAT_140699920 = '\0';
  UNLOCK();
  pcVar109 = &DAT_140699920;
  goto joined_r0x00014002d985;
LAB_14002e7c1:
  lVar120 = lVar120 + 0x20;
  if (DAT_1406997a8 * 0x20 == lVar120) goto LAB_14002fc16;
  goto LAB_14002e7ce;
LAB_1400302f9:
  if ((bVar77 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      DAT_140699949 = '\x01';
    }
  }
  cVar74 = DAT_140699948;
  LOCK();
  DAT_140699948 = '\0';
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
  }
  emblem::received(*uStack_104b0 + 8,pauStack_10538[-1] + 8);
  cStack_10530 = '\x01';
  goto LAB_1400331d0;
LAB_14003404d:
  pauVar123 = (undefined1 (*) [16])(*pauVar89 + 1);
LAB_1400343e9:
  unaff_R15 = pauVar123;
  if (pauVar123 < pauVar79) {
    lVar80 = *(longlong *)uStack_10458[3];
    puVar99 = *(undefined1 **)uStack_10458[2];
    lVar120 = *(longlong *)(uStack_10458[2] + 8);
    uStack_10288 = pauVar79;
    if (pauVar79 < pauVar89) {
      uStack_10288 = pauVar89;
    }
    do {
      pauVar92 = pauVar123;
      if (bVar130 && bVar129) {
        lVar98 = (longlong)(*pauVar123 + lVar80) * 0x58 + lVar120 + 0x50;
        while( true ) {
          puVar90 = *pauVar92 + lVar80;
          bVar131 = puVar90 < puVar99;
          puVar107 = (undefined1 *)0x0;
          if (!bVar131) {
            puVar107 = puVar99;
          }
          if ((*(undefined1 (**) [16])(lVar98 + -8 + (longlong)puVar107 * -0x58) == pauVar82) ||
             (*(char *)(lVar98 + (longlong)puVar107 * -0x58) == '\x02')) break;
          pauVar92 = (undefined1 (*) [16])(*pauVar92 + 1);
          lVar98 = lVar98 + 0x58;
          if (pauVar79 <= pauVar92) goto LAB_1400345ef;
        }
      }
      else {
        lVar98 = (longlong)(*pauVar123 + lVar80) * 0x58 + lVar120 + 0x50;
        while( true ) {
          puVar90 = *pauVar92 + lVar80;
          bVar131 = puVar90 < puVar99;
          puVar107 = (undefined1 *)0x0;
          if (!bVar131) {
            puVar107 = puVar99;
          }
          if (*(char *)(lVar98 + (longlong)puVar107 * -0x58) == '\x02') break;
          pauVar92 = (undefined1 (*) [16])(*pauVar92 + 1);
          lVar98 = lVar98 + 0x58;
          if (pauVar79 <= pauVar92) goto LAB_1400345ef;
        }
      }
      if (pauVar89 == uStack_10288) {
        core[505b25137b8ba7f]::panicking::panic
                  (&anon_d5c34e88a06ee720b116585eb143da4b_235_llvm_14435704873730135342,0x20,
                   &anon_d5c34e88a06ee720b116585eb143da4b_236_llvm_14435704873730135342);
        goto LAB_140036cf0;
      }
      puVar107 = puVar99;
      if (*pauVar89 + lVar80 < puVar99) {
        puVar107 = (undefined1 *)0x0;
      }
      puVar110 = puVar99;
      if (bVar131) {
        puVar110 = (undefined1 *)0x0;
      }
      lVar98 = ((longlong)(*pauVar89 + lVar80) - (longlong)puVar107) * 0x58;
      lVar128 = ((longlong)puVar90 - (longlong)puVar110) * 0x58;
      uStack_104d8 = *(undefined8 *)(lVar120 + 0x50 + lVar98);
      puVar86 = (undefined8 *)(lVar120 + 0x40 + lVar98);
      uVar4 = *puVar86;
      puStack_104e0 = (undefined *)puVar86[1];
      uStack_104e8 = (uint)uVar4;
      uStack_104e4 = (uint)((ulonglong)uVar4 >> 0x20);
      uVar9 = *(undefined8 *)(lVar120 + lVar98);
      uVar10 = ((undefined8 *)(lVar120 + lVar98))[1];
      puVar86 = (undefined8 *)(lVar120 + 0x10 + lVar98);
      uVar15 = *puVar86;
      uVar16 = puVar86[1];
      pauVar1 = (undefined1 (*) [12])(lVar120 + 0x20 + lVar98);
      uStack_10508 = *(undefined1 (***) [16])*pauVar1;
      pauVar84 = *(undefined1 (**) [16])(*pauVar1 + 8);
      auVar33 = *pauVar1;
      pauVar1 = (undefined1 (*) [12])(lVar120 + 0x30 + lVar98);
      uStack_104f8 = *(ushort **)*pauVar1;
      auVar34 = *pauVar1;
      uStack_104f0 = (uint)*(undefined8 *)(*pauVar1 + 8);
      uStack_104ec = (uint)((ulonglong)*(undefined8 *)(*pauVar1 + 8) >> 0x20);
      uStack_10500._4_4_ = (uint)((ulonglong)pauVar84 >> 0x20);
      bStack_10518 = (byte)uVar15;
      bStack_10517 = (byte)((ulonglong)uVar15 >> 8);
      uStack_10516 = (ushort)((ulonglong)uVar15 >> 0x10);
      uStack_10514 = (uint)((ulonglong)uVar15 >> 0x20);
      uStack_10510 = (ushort)uVar16;
      uStack_1050e = (ushort)((ulonglong)uVar16 >> 0x10);
      uStack_1050c = (ushort)((ulonglong)uVar16 >> 0x20);
      uStack_1050a = (ushort)((ulonglong)uVar16 >> 0x30);
      bStack_10528 = (byte)uVar9;
      bStack_10527 = (byte)((ulonglong)uVar9 >> 8);
      bStack_10526 = (byte)((ulonglong)uVar9 >> 0x10);
      bStack_10525 = (byte)((ulonglong)uVar9 >> 0x18);
      bStack_10524 = (byte)((ulonglong)uVar9 >> 0x20);
      bStack_10523 = (byte)((ulonglong)uVar9 >> 0x28);
      bStack_10522 = (byte)((ulonglong)uVar9 >> 0x30);
      bStack_10521 = (byte)((ulonglong)uVar9 >> 0x38);
      bStack_10520 = (byte)uVar10;
      bStack_1051f = (byte)((ulonglong)uVar10 >> 8);
      bStack_1051e = (byte)((ulonglong)uVar10 >> 0x10);
      bStack_1051d = (byte)((ulonglong)uVar10 >> 0x18);
      bStack_1051c = (byte)((ulonglong)uVar10 >> 0x20);
      bStack_1051b = (byte)((ulonglong)uVar10 >> 0x28);
      bStack_1051a = (byte)((ulonglong)uVar10 >> 0x30);
      bStack_10519 = (byte)((ulonglong)uVar10 >> 0x38);
      puVar86 = (undefined8 *)(lVar120 + 0x40 + lVar128);
      uVar17 = *puVar86;
      uVar18 = puVar86[1];
      uVar85 = *(undefined8 *)(lVar120 + 0x50 + lVar128);
      uVar19 = ((undefined8 *)(lVar120 + lVar128))[1];
      puVar86 = (undefined8 *)(lVar120 + 0x10 + lVar128);
      uVar20 = *puVar86;
      uVar21 = puVar86[1];
      puVar86 = (undefined8 *)(lVar120 + 0x20 + lVar128);
      uVar22 = *puVar86;
      uVar23 = puVar86[1];
      puVar86 = (undefined8 *)(lVar120 + 0x30 + lVar128);
      uVar24 = *puVar86;
      uVar25 = puVar86[1];
      *(undefined8 *)(lVar120 + lVar98) = *(undefined8 *)(lVar120 + lVar128);
      ((undefined8 *)(lVar120 + lVar98))[1] = uVar19;
      *(undefined8 *)(lVar120 + 0x50 + lVar98) = uVar85;
      puVar86 = (undefined8 *)(lVar120 + 0x40 + lVar98);
      *puVar86 = uVar17;
      puVar86[1] = uVar18;
      puVar86 = (undefined8 *)(lVar120 + 0x30 + lVar98);
      *puVar86 = uVar24;
      puVar86[1] = uVar25;
      puVar86 = (undefined8 *)(lVar120 + 0x20 + lVar98);
      *puVar86 = uVar22;
      puVar86[1] = uVar23;
      puVar86 = (undefined8 *)(lVar120 + 0x10 + lVar98);
      *puVar86 = uVar20;
      puVar86[1] = uVar21;
      *(undefined8 *)(lVar120 + 0x50 + lVar128) = uStack_104d8;
      puVar86 = (undefined8 *)(lVar120 + 0x40 + lVar128);
      *puVar86 = uVar4;
      puVar86[1] = puStack_104e0;
      auVar31._12_4_ = uStack_10500._4_4_;
      auVar31._0_12_ = auVar33;
      auVar32._12_4_ = uStack_104ec;
      auVar32._0_12_ = auVar34;
      *(undefined1 (*) [16])(lVar120 + 0x30 + lVar128) = auVar32;
      *(undefined1 (*) [16])(lVar120 + 0x20 + lVar128) = auVar31;
      puVar86 = (undefined8 *)(lVar120 + 0x10 + lVar128);
      *puVar86 = uVar15;
      puVar86[1] = uVar16;
      *(undefined8 *)(lVar120 + lVar128) = uVar9;
      ((undefined8 *)(lVar120 + lVar128))[1] = uVar10;
      pauVar123 = (undefined1 (*) [16])(*pauVar92 + 1);
      pauVar89 = (undefined1 (*) [16])(*pauVar89 + 1);
      unaff_R15 = pauVar123;
      uStack_10500 = pauVar84;
    } while (pauVar123 < pauVar79);
  }
LAB_1400345fc:
  if ((unaff_R15 != pauVar89) && (pauVar89 < pauVar79)) {
    puVar99 = *(undefined1 **)uStack_10458[3];
    puVar90 = *(undefined1 **)uStack_10458[2];
    lVar80 = *(longlong *)(uStack_10458[2] + 8);
    puVar107 = puVar90;
    if (puVar99 < puVar90) {
      puVar107 = (undefined1 *)0x0;
    }
    lVar98 = (longlong)puVar99 - (longlong)puVar107;
    uStack_104b8 = (undefined1 (*) [16])(puVar90 + -lVar98);
    lVar120 = (longlong)pauVar79 - (longlong)uStack_104b8;
    bVar129 = lVar120 != 0;
    if (pauVar79 < uStack_104b8) {
      lVar120 = 0;
    }
    puVar110 = (undefined1 *)(lVar98 + (longlong)pauVar79);
    if (pauVar79 >= uStack_104b8 && bVar129) {
      puVar110 = puVar90;
    }
    unaff_R15 = (undefined1 (*) [16])(puVar110 + -lVar98);
    *(undefined1 (**) [16])(uStack_10458[3] + 8) = pauVar89;
    if (pauVar89 < unaff_R15 || (longlong)pauVar89 - (longlong)unaff_R15 == 0) {
      lVar98 = (longlong)unaff_R15 - (longlong)pauVar89;
      if (lVar98 != 0) {
        puVar86 = (undefined8 *)
                  (lVar80 + (longlong)puVar99 * 0x58 + (longlong)pauVar89 * 0x58 +
                            (longlong)puVar107 * -0x58 + 8);
        do {
          if (puVar86[-1] != 0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar86,puVar86[-1],1);
            return pauVar82;
          }
          puVar86 = puVar86 + 0xb;
          lVar98 = lVar98 + -1;
        } while (lVar98 != 0);
      }
      unaff_R15 = (undefined1 (*) [16])0x0;
      if (uStack_104b8 < pauVar79) {
        puVar86 = (undefined8 *)(lVar80 + 8);
        do {
          if (puVar86[-1] != 0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar86,puVar86[-1],1);
            return pauVar82;
          }
          puVar86 = puVar86 + 0xb;
          lVar120 = lVar120 + -1;
        } while (lVar120 != 0);
      }
    }
    else {
      lVar120 = lVar120 - ((longlong)pauVar89 - (longlong)unaff_R15);
      if (lVar120 != 0) {
        puVar86 = (undefined8 *)
                  (lVar80 + (longlong)pauVar89 * 0x58 + (longlong)unaff_R15 * -0x58 + 8);
        do {
          if (puVar86[-1] != 0) {
            pauVar82 = (undefined1 (*) [16])
                       __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar86,puVar86[-1],1);
            return pauVar82;
          }
          puVar86 = puVar86 + 0xb;
          lVar120 = lVar120 + -1;
        } while (lVar120 != 0);
      }
    }
  }
LAB_1400347d1:
  if ((bVar76 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
LAB_14003498b:
    if (cVar74 == '\0') {
      (*uStack_10458)[1] = 1;
    }
  }
LAB_1400347f8:
  LOCK();
  cVar74 = (*uStack_10458)[0];
  (*uStack_10458)[0] = 0;
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(uStack_10458);
  }
LAB_14003480c:
  if ((bVar73 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      (*uStack_104c0)[1] = 1;
    }
  }
  LOCK();
  cVar74 = (*uStack_104c0)[0];
  (*uStack_104c0)[0] = 0;
  UNLOCK();
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(uStack_104c0);
  }
  if ((bVar75 == 0) &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar74 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar74 == '\0') {
      pcVar109[1] = '\x01';
    }
  }
  LOCK();
  cVar74 = *pcVar109;
  *pcVar109 = '\0';
  UNLOCK();
  bVar76 = bStack_10526;
  bVar73 = bStack_10525;
  bVar54 = bStack_10524;
  bVar55 = bStack_10523;
  bVar132 = bStack_10522;
  bVar56 = bStack_10521;
  bVar57 = bStack_10520;
  bVar58 = bStack_1051f;
  bVar59 = bStack_1051e;
  bVar60 = bStack_1051d;
  bVar61 = bStack_1051c;
  bVar62 = bStack_1051b;
  bVar63 = bStack_1051a;
  bVar64 = bStack_10519;
  bVar65 = bStack_10518;
  bVar66 = bStack_10517;
  uVar112 = uStack_10510;
  uVar91 = uStack_1050e;
  uVar68 = uStack_1050c;
  uVar69 = uStack_1050a;
  if (cVar74 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(pcVar109);
    bVar76 = bStack_10526;
    bVar73 = bStack_10525;
    bVar54 = bStack_10524;
    bVar55 = bStack_10523;
    bVar132 = bStack_10522;
    bVar56 = bStack_10521;
    bVar57 = bStack_10520;
    bVar58 = bStack_1051f;
    bVar59 = bStack_1051e;
    bVar60 = bStack_1051d;
    bVar61 = bStack_1051c;
    bVar62 = bStack_1051b;
    bVar63 = bStack_1051a;
    bVar64 = bStack_10519;
    bVar65 = bStack_10518;
    bVar66 = bStack_10517;
    uVar112 = uStack_10510;
    uVar91 = uStack_1050e;
    uVar68 = uStack_1050c;
    uVar69 = uStack_1050a;
  }
LAB_1400331c4:
  uStack_1050a = uVar69;
  uStack_1050c = uVar68;
  uStack_1050e = uVar91;
  uStack_10510 = uVar112;
  bStack_10517 = bVar66;
  bStack_10518 = bVar65;
  bStack_10519 = bVar64;
  bStack_1051a = bVar63;
  bStack_1051b = bVar62;
  bStack_1051c = bVar61;
  bStack_1051d = bVar60;
  bStack_1051e = bVar59;
  bStack_1051f = bVar58;
  bStack_10520 = bVar57;
  bStack_10521 = bVar56;
  bStack_10522 = bVar132;
  bStack_10523 = bVar55;
  bStack_10524 = bVar54;
  bStack_10525 = bVar73;
  bStack_10526 = bVar76;
  cStack_10530 = '\x01';
  goto LAB_1400331d0;
LAB_1400345ef:
  unaff_R15 = (undefined1 (*) [16])(*pauVar123 + 1);
  if ((undefined1 (*) [16])(*pauVar123 + 1) < pauVar79) {
    unaff_R15 = pauVar79;
  }
  goto LAB_1400345fc;
LAB_140033b54:
  uVar117 = uVar117 & (ulonglong)unaff_R15;
  pcVar115 = (char *)(lVar80 + uVar117);
  auVar179[0] = -(*pcVar115 == auVar133[0]);
  auVar179[1] = -(pcVar115[1] == auVar133[1]);
  auVar179[2] = -(pcVar115[2] == auVar133[2]);
  auVar179[3] = -(pcVar115[3] == auVar133[3]);
  auVar179[4] = -(pcVar115[4] == auVar133[4]);
  auVar179[5] = -(pcVar115[5] == auVar133[5]);
  auVar179[6] = -(pcVar115[6] == auVar133[6]);
  auVar179[7] = -(pcVar115[7] == auVar133[7]);
  auVar179[8] = -(pcVar115[8] == auVar133[0]);
  auVar179[9] = -(pcVar115[9] == auVar133[1]);
  auVar179[10] = -(pcVar115[10] == auVar133[2]);
  auVar179[0xb] = -(pcVar115[0xb] == auVar133[3]);
  auVar179[0xc] = -(pcVar115[0xc] == auVar133[4]);
  auVar179[0xd] = -(pcVar115[0xd] == auVar133[5]);
  auVar179[0xe] = -(pcVar115[0xe] == auVar133[6]);
  auVar179[0xf] = -(pcVar115[0xf] == auVar133[7]);
  uVar112 = (ushort)(SUB161(auVar179 >> 7,0) & 1) | (ushort)(SUB161(auVar179 >> 0xf,0) & 1) << 1 |
            (ushort)(SUB161(auVar179 >> 0x17,0) & 1) << 2 |
            (ushort)(SUB161(auVar179 >> 0x1f,0) & 1) << 3 |
            (ushort)(SUB161(auVar179 >> 0x27,0) & 1) << 4 |
            (ushort)(SUB161(auVar179 >> 0x2f,0) & 1) << 5 |
            (ushort)(SUB161(auVar179 >> 0x37,0) & 1) << 6 |
            (ushort)(SUB161(auVar179 >> 0x3f,0) & 1) << 7 |
            (ushort)(SUB161(auVar179 >> 0x47,0) & 1) << 8 |
            (ushort)(SUB161(auVar179 >> 0x4f,0) & 1) << 9 |
            (ushort)(SUB161(auVar179 >> 0x57,0) & 1) << 10 |
            (ushort)(SUB161(auVar179 >> 0x5f,0) & 1) << 0xb |
            (ushort)(SUB161(auVar179 >> 0x67,0) & 1) << 0xc |
            (ushort)(SUB161(auVar179 >> 0x6f,0) & 1) << 0xd |
            (ushort)(SUB161(auVar179 >> 0x77,0) & 1) << 0xe | (ushort)(auVar179[0xf] >> 7) << 0xf;
  uVar113 = (uint)uVar112;
  while (uVar112 != 0) {
    uVar114 = 0;
    for (uVar96 = uVar113; (uVar96 & 1) == 0; uVar96 = uVar96 >> 1 | 0x80000000) {
      uVar114 = uVar114 + 1;
    }
    lVar98 = (uVar114 + uVar117 & (ulonglong)unaff_R15) * -0x50;
    if (pauVar79 == *(undefined1 (**) [16])(lVar80 + -0x50 + lVar98)) {
      lVar80 = lVar80 + lVar98;
      uStack_104e8 = (uint)*(undefined8 *)(lVar80 + -8);
      uStack_104e4 = (uint)((ulonglong)*(undefined8 *)(lVar80 + -8) >> 0x20);
      uVar85 = *(undefined8 *)(lVar80 + -0x48);
      uVar4 = *(undefined8 *)(lVar80 + -0x40);
      uVar9 = *(undefined8 *)(lVar80 + -0x38);
      uVar10 = *(undefined8 *)(lVar80 + -0x30);
      auVar133 = *(undefined1 (*) [16])(lVar80 + -0x28);
      auVar137 = *(undefined1 (*) [16])(lVar80 + -0x18);
      uStack_104f8._0_4_ = auVar137._0_4_;
      uStack_104f8._4_4_ = auVar137._4_4_;
      uStack_104f0 = auVar137._8_4_;
      uStack_104ec = auVar137._12_4_;
      uStack_10508._0_4_ = auVar133._0_4_;
      uStack_10508._4_4_ = auVar133._4_4_;
      uStack_10500._0_4_ = auVar133._8_4_;
      uStack_10500._4_4_ = auVar133._12_4_;
      bStack_10518 = (byte)uVar9;
      bStack_10517 = (byte)((ulonglong)uVar9 >> 8);
      uStack_10516 = (ushort)((ulonglong)uVar9 >> 0x10);
      uStack_10514 = (uint)((ulonglong)uVar9 >> 0x20);
      uStack_10510 = (ushort)uVar10;
      uStack_1050e = (ushort)((ulonglong)uVar10 >> 0x10);
      uStack_1050c = (ushort)((ulonglong)uVar10 >> 0x20);
      uStack_1050a = (ushort)((ulonglong)uVar10 >> 0x30);
      bStack_10528 = (byte)uVar85;
      bStack_10527 = (byte)((ulonglong)uVar85 >> 8);
      bStack_10526 = (byte)((ulonglong)uVar85 >> 0x10);
      bStack_10525 = (byte)((ulonglong)uVar85 >> 0x18);
      bStack_10524 = (byte)((ulonglong)uVar85 >> 0x20);
      bStack_10523 = (byte)((ulonglong)uVar85 >> 0x28);
      bStack_10522 = (byte)((ulonglong)uVar85 >> 0x30);
      bStack_10521 = (byte)((ulonglong)uVar85 >> 0x38);
      bStack_10520 = (byte)uVar4;
      bStack_1051f = (byte)((ulonglong)uVar4 >> 8);
      bStack_1051e = (byte)((ulonglong)uVar4 >> 0x10);
      bStack_1051d = (byte)((ulonglong)uVar4 >> 0x18);
      bStack_1051c = (byte)((ulonglong)uVar4 >> 0x20);
      bStack_1051b = (byte)((ulonglong)uVar4 >> 0x28);
      bStack_1051a = (byte)((ulonglong)uVar4 >> 0x30);
      bStack_10519 = (byte)((ulonglong)uVar4 >> 0x38);
      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
      ::insert(&uStack_10438,uStack_104c0[3] + 8,pauVar79,&bStack_10528);
      *(undefined4 *)uStack_104c0[1] = 0xffffffff;
      goto LAB_14003480c;
    }
    uVar112 = (ushort)(uVar113 - 1) & (ushort)uVar113;
    uVar113 = CONCAT22((short)(uVar113 - 1 >> 0x10),uVar112);
  }
  auVar164[0] = -(*pcVar115 == cVar72);
  auVar164[1] = -(pcVar115[1] == cVar181);
  auVar164[2] = -(pcVar115[2] == cVar182);
  auVar164[3] = -(pcVar115[3] == cVar183);
  auVar164[4] = -(pcVar115[4] == cVar184);
  auVar164[5] = -(pcVar115[5] == cVar185);
  auVar164[6] = -(pcVar115[6] == cVar186);
  auVar164[7] = -(pcVar115[7] == cVar187);
  auVar164[8] = -(pcVar115[8] == cVar188);
  auVar164[9] = -(pcVar115[9] == cVar189);
  auVar164[10] = -(pcVar115[10] == cVar190);
  auVar164[0xb] = -(pcVar115[0xb] == cVar191);
  auVar164[0xc] = -(pcVar115[0xc] == cVar192);
  auVar164[0xd] = -(pcVar115[0xd] == cVar193);
  auVar164[0xe] = -(pcVar115[0xe] == cVar194);
  auVar164[0xf] = -(pcVar115[0xf] == cVar195);
  if ((((((((((((((((SUB161(auVar164 >> 7,0) & 1) != 0 || (SUB161(auVar164 >> 0xf,0) & 1) != 0) ||
                  (SUB161(auVar164 >> 0x17,0) & 1) != 0) || (SUB161(auVar164 >> 0x1f,0) & 1) != 0)
                || (SUB161(auVar164 >> 0x27,0) & 1) != 0) || (SUB161(auVar164 >> 0x2f,0) & 1) != 0)
              || (SUB161(auVar164 >> 0x37,0) & 1) != 0) || (SUB161(auVar164 >> 0x3f,0) & 1) != 0) ||
            (SUB161(auVar164 >> 0x47,0) & 1) != 0) || (SUB161(auVar164 >> 0x4f,0) & 1) != 0) ||
          (SUB161(auVar164 >> 0x57,0) & 1) != 0) || (SUB161(auVar164 >> 0x5f,0) & 1) != 0) ||
        (SUB161(auVar164 >> 0x67,0) & 1) != 0) || (SUB161(auVar164 >> 0x6f,0) & 1) != 0) ||
      (SUB161(auVar164 >> 0x77,0) & 1) != 0) || auVar164[0xf] < '\0') {
    ppuStack_10188 =
         &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0418;
    goto LAB_14003676a;
  }
  uVar117 = uVar117 + lVar120 + 0x10;
  lVar120 = lVar120 + 0x10;
  goto LAB_140033b54;
LAB_1400349cc:
  uVar113 = ((uint)pauStack_101b8 & 3) - 2;
  if ((1 < uVar113) && (((ulonglong)pauStack_101b8 & 3) != 0)) {
    puVar99 = pauStack_101b8[-1] + 0xf;
    bStack_10520 = (byte)puVar99;
    bStack_1051f = (byte)((ulonglong)puVar99 >> 8);
    bStack_1051e = (byte)((ulonglong)puVar99 >> 0x10);
    bStack_1051d = (byte)((ulonglong)puVar99 >> 0x18);
    bStack_1051c = (byte)((ulonglong)puVar99 >> 0x20);
    bStack_1051b = (byte)((ulonglong)puVar99 >> 0x28);
    bStack_1051a = (byte)((ulonglong)puVar99 >> 0x30);
    bStack_10519 = (byte)((ulonglong)puVar99 >> 0x38);
    bStack_10528 = 3;
    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&bStack_10520);
  }
  LOCK();
  bVar129 = LAST_PRUNE == '\0';
  if (bVar129) {
    LAST_PRUNE = '\x01';
  }
  UNLOCK();
  if (!bVar129) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&LAST_PRUNE);
  }
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar76 = 0;
  }
  else {
    bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar76 = bVar76 ^ 1;
  }
  if (DAT_140699579 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    bStack_10528 = 0x78;
    bStack_10527 = 0x95;
    bStack_10526 = 0x69;
    bStack_10525 = 0x40;
    bStack_10524 = 1;
    bStack_10523 = 0;
    bStack_10522 = 0;
    bStack_10521 = 0;
    bStack_10520 = bVar76;
    core[505b25137b8ba7f]::result::unwrap_failed
              ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
               &anon_d5c34e88a06ee720b116585eb143da4b_136_llvm_14435704873730135342,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2098);
    goto LAB_140036cf0;
  }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
  if (DAT_140699588 == 0xffffffff) {
LAB_140034a6b:
    DAT_140699580 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    DAT_140699588 = uVar113;
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699579 = '\x01';
      }
    }
    cVar72 = LAST_PRUNE;
    LOCK();
    LAST_PRUNE = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_PRUNE);
    }
    LOCK();
    bVar129 = DAT_140699948 == '\0';
    if (bVar129) {
      DAT_140699948 = '\x01';
    }
    UNLOCK();
    if (!bVar129) {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended(&DAT_140699948);
    }
    if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) == 0) {
      bVar76 = 0;
      pauVar82 = HOST_ID_0_llvm_14435704873730135342;
    }
    else {
      bVar76 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      bVar76 = bVar76 ^ 1;
      pauVar82 = HOST_ID_0_llvm_14435704873730135342;
    }
    HOST_ID_0_llvm_14435704873730135342 = pauVar82;
    if (DAT_140699949 != '\0') {
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      bStack_10528 = 0x48;
      bStack_10527 = 0x99;
      bStack_10526 = 0x69;
      bStack_10525 = 0x40;
      bStack_10524 = 1;
      bStack_10523 = 0;
      bStack_10522 = 0;
      bStack_10521 = 0;
      bStack_10520 = bVar76;
      core[505b25137b8ba7f]::result::unwrap_failed
                ("called `Result::unwrap()` on an `Err` value",0x2b,&bStack_10528,
                 &anon_d5c34e88a06ee720b116585eb143da4b_155_llvm_14435704873730135342,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a20b0);
LAB_140036cf0:
                    /* WARNING: Does not return */
      pcVar7 = (code *)invalidInstructionException();
      (*pcVar7)();
    }
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
    iVar127 = -1;
    if ((pauVar82 != (undefined1 (*) [16])0x0) && (IS_HOST_0_llvm_14435704873730135342 == '\0')) {
      uStack_10438._0_1_ = (byte)pauVar82;
      uStack_10438._1_1_ = (byte)((ulonglong)pauVar82 >> 8);
      uStack_10438._2_1_ = (byte)((ulonglong)pauVar82 >> 0x10);
      uStack_10438._3_1_ = (byte)((ulonglong)pauVar82 >> 0x18);
      uStack_10438._4_4_ = (int)((ulonglong)pauVar82 >> 0x20);
      uVar85 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
               ::hash_one::<&usize>(&DAT_140699970,&uStack_10438);
      uVar113 = 0x40699950;
      <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,host_probe[b94139f9089eb1d8]::net::Route)>>::
      remove_entry::
      <hashbrown[ad6d4a1843b2832d]::map::equivalent_key<u64,u64,host_probe[b94139f9089eb1d8]::net::Route>::_closure_0_>
                (&bStack_10528,&DAT_140699950,uVar85,&uStack_10438);
      iVar127 = CONCAT22(uStack_10516,CONCAT11(bStack_10517,bStack_10518));
      if (iVar127 != -1) {
        uStack_104c0 = (undefined1 (*) [16])
                       CONCAT17(bStack_10519,
                                CONCAT16(bStack_1051a,
                                         CONCAT15(bStack_1051b,
                                                  CONCAT14(bStack_1051c,
                                                           CONCAT13(bStack_1051d,
                                                                    CONCAT12(bStack_1051e,
                                                                             CONCAT11(bStack_1051f,
                                                                                      bStack_10520))
                                                                   )))));
        uStack_103a8 = (ushort)uStack_10514;
        uStack_103a6 = (ushort)(uStack_10514 >> 0x10);
        uStack_103a4 = uStack_10510;
        uStack_103a2 = uStack_1050e;
        uStack_103a0 = uStack_1050c;
        uStack_1039e = uStack_1050a;
        uStack_1039c = (uint)uStack_10508;
        uStack_10390 = CONCAT44((uint)uStack_104f8,uStack_10500._4_4_);
        uStack_10398 = (ushort)((ulonglong)uStack_10508 >> 0x20);
        uStack_10396 = (ushort)((ulonglong)uStack_10508 >> 0x30);
        uStack_10394 = (uint)uStack_10500;
        uStack_10388 = CONCAT44(uStack_104f0,uStack_104f8._4_4_);
        uStack_10380 = uStack_104ec;
        uStack_1037c = uStack_104e8;
        uStack_10378 = uStack_104e4;
        puStack_10374 = puStack_104e0;
      }
    }
    pauStack_10448 = (undefined1 (*) [16])CONCAT44(pauStack_10448._4_4_,iVar127);
    uVar85 = <std[3bf9d48a0c3997f0]::time::Instant>::now();
    uStack_10278._0_1_ = (byte)uVar85;
    uStack_10278._1_1_ = (byte)((ulonglong)uVar85 >> 8);
    uStack_10276 = (ushort)((ulonglong)uVar85 >> 0x10);
    uStack_10274 = (ushort)((ulonglong)uVar85 >> 0x20);
    uStack_10272 = (ushort)((ulonglong)uVar85 >> 0x30);
    puVar99 = *DAT_140699950 + DAT_140699958 + 1;
    auVar133 = *DAT_140699950;
    uStack_10510 = ~((ushort)(SUB161(auVar133 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar133 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar133 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar133 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar133 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar133 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar133 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar133 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar133 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar133 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar133 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar133 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar133 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar133 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar133 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar133[0xf] >> 7) << 0xf);
    bStack_10528 = (byte)DAT_140699950;
    bStack_10527 = (byte)((ulonglong)DAT_140699950 >> 8);
    bStack_10526 = (byte)((ulonglong)DAT_140699950 >> 0x10);
    bStack_10525 = (byte)((ulonglong)DAT_140699950 >> 0x18);
    bStack_10524 = (byte)((ulonglong)DAT_140699950 >> 0x20);
    bStack_10523 = (byte)((ulonglong)DAT_140699950 >> 0x28);
    bStack_10522 = (byte)((ulonglong)DAT_140699950 >> 0x30);
    bStack_10521 = (byte)((ulonglong)DAT_140699950 >> 0x38);
    pauVar79 = DAT_140699950 + 1;
    bStack_10520 = (byte)pauVar79;
    bStack_1051f = (byte)((ulonglong)pauVar79 >> 8);
    bStack_1051e = (byte)((ulonglong)pauVar79 >> 0x10);
    bStack_1051d = (byte)((ulonglong)pauVar79 >> 0x18);
    bStack_1051c = (byte)((ulonglong)pauVar79 >> 0x20);
    bStack_1051b = (byte)((ulonglong)pauVar79 >> 0x28);
    bStack_1051a = (byte)((ulonglong)pauVar79 >> 0x30);
    bStack_10519 = (byte)((ulonglong)pauVar79 >> 0x38);
    bStack_10518 = (byte)puVar99;
    bStack_10517 = (byte)((ulonglong)puVar99 >> 8);
    uStack_10516 = (ushort)((ulonglong)puVar99 >> 0x10);
    uStack_10514 = (uint)((ulonglong)puVar99 >> 0x20);
    uStack_10508._0_4_ = (uint)DAT_140699968;
    uStack_10508._4_4_ = (uint)((ulonglong)DAT_140699968 >> 0x20);
    uStack_10500 = (undefined1 (*) [16])&uStack_10278;
    auStack_10270[0] = uVar113;
    <alloc[246c2e7857c81348]::vec::Vec<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr)>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<(u64,core[505b25137b8ba7f]::net::socket_addr::SocketAddr),core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::iter::adapters::filter::Filter<std[3bf9d48a0c3997f0]::collections::hash::map::Iter<u64,host_probe[b94139f9089eb1d8]::net::Route>,host_probe[b94139f9089eb1d8]::net::drop_silent::{closure#0}>,host_probe[b94139f9089eb1d8]::net::drop_silent::{closure#1}>>>
    ::from_iter(&uStack_10438,&bStack_10528);
    puVar86 = (undefined8 *)
              CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
    lVar80 = CONCAT44(uStack_10424,CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428)));
    uStack_104b0 = pauVar82;
    if (lVar80 != 0) {
      lVar120 = 0;
      do {
        uVar85 = <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>
                 ::hash_one::<&usize>(&DAT_140699970,(longlong)puVar86 + lVar120);
        <hashbrown[ad6d4a1843b2832d]::raw::RawTable<(u64,host_probe[b94139f9089eb1d8]::net::Route)>>
        ::remove_entry::
        <hashbrown[ad6d4a1843b2832d]::map::equivalent_key<u64,u64,host_probe[b94139f9089eb1d8]::net::Route>::_closure_0_>
                  (&bStack_10528,&DAT_140699950,uVar85,(longlong)puVar86 + lVar120);
        lVar120 = lVar120 + 0x28;
      } while (lVar80 * 0x28 != lVar120);
    }
    lVar120 = CONCAT44(uStack_10438._4_4_,
                       CONCAT13(uStack_10438._3_1_,
                                CONCAT12(uStack_10438._2_1_,
                                         CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))));
    if ((int)pauStack_10448 != -1) {
      uStack_10438._0_1_ = (byte)uStack_104c0;
      uStack_10438._1_1_ = (byte)((ulonglong)uStack_104c0 >> 8);
      uStack_10438._2_1_ = (byte)((ulonglong)uStack_104c0 >> 0x10);
      uStack_10438._3_1_ = (byte)((ulonglong)uStack_104c0 >> 0x18);
      uStack_10438._4_4_ = (int)((ulonglong)uStack_104c0 >> 0x20);
      bStack_10430 = (byte)pauStack_10448;
      bStack_1042f = (byte)((ulonglong)pauStack_10448 >> 8);
      uStack_1042e = (ushort)((ulonglong)pauStack_10448 >> 0x10);
      uStack_1042c = CONCAT22(uStack_103a6,uStack_103a8);
      uStack_10424 = CONCAT22(uStack_1039e,uStack_103a0);
      bStack_10428 = (byte)uStack_103a4;
      bStack_10427 = (byte)(uStack_103a4 >> 8);
      uStack_10426 = uStack_103a2;
      uStack_10420 = uStack_1039c;
      uStack_1041c = uStack_10398;
      uStack_1041a = uStack_10396;
      uStack_10418 = uStack_10394;
      uStack_10414 = (undefined4)uStack_10390;
      uStack_10410 = (undefined4)(uStack_10390 >> 0x20);
      uStack_1040c = (uint)uStack_10388;
      uStack_10408 = (uint)((ulonglong)uStack_10388 >> 0x20);
      uStack_10404 = uStack_10380;
      uStack_10400 = uStack_1037c;
      uStack_103fc = uStack_10378;
      puStack_103f8 = puStack_10374;
      <hashbrown[ad6d4a1843b2832d]::map::HashMap<u64,host_probe[b94139f9089eb1d8]::net::Route,std[3bf9d48a0c3997f0]::hash::random::RandomState>>
      ::insert(&bStack_10528,&DAT_140699950,uStack_104b0,&uStack_10438);
    }
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699949 = '\x01';
      }
    }
    cVar72 = DAT_140699948;
    LOCK();
    DAT_140699948 = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699948);
    }
    if (lVar80 != 0) {
      puVar111 = puVar86;
      do {
        sVar116 = *(short *)(puVar111 + 1);
        uVar85 = puVar111[3];
        uVar4 = puVar111[4];
        uStack_10268 = (uint)((ulonglong)uVar85 >> 0x10);
        uStack_10264 = (undefined2)((ulonglong)uVar85 >> 0x30);
        uStack_10262 = (undefined2)uVar4;
        uStack_10260 = (undefined6)((ulonglong)uVar4 >> 0x10);
        uVar9 = *(undefined8 *)((longlong)puVar111 + 10);
        uVar10 = *(undefined8 *)((longlong)puVar111 + 0x12);
        uStack_10278._0_1_ = (byte)uVar9;
        uStack_10278._1_1_ = (byte)((ulonglong)uVar9 >> 8);
        uStack_10276 = (ushort)((ulonglong)uVar9 >> 0x10);
        uStack_10274 = (ushort)((ulonglong)uVar9 >> 0x20);
        uStack_10272 = (ushort)((ulonglong)uVar9 >> 0x30);
        auStack_10270[0] = (uint)uVar10;
        auStack_10270[1]._0_2_ = (undefined2)((ulonglong)uVar10 >> 0x20);
        auStack_10270[1]._2_2_ = (undefined2)((ulonglong)uVar10 >> 0x30);
        if (sVar116 == 2) break;
        uStack_10438._0_1_ = (byte)sVar116;
        uStack_10438._1_1_ = (byte)((ushort)sVar116 >> 8);
        uStack_10426 = (ushort)((ulonglong)uVar85 >> 0x10);
        uStack_10424 = (uint)(CONCAT26(uStack_10264,CONCAT42(uStack_10268,auStack_10270[1]._2_2_))
                             >> 0x20);
        uStack_10420 = (uint)uVar4;
        uStack_1041c = (ushort)((ulonglong)uVar4 >> 0x20);
        uStack_1041a = (ushort)((ulonglong)uVar4 >> 0x30);
        uStack_10438._4_4_ = (int)((ulonglong)uVar9 >> 0x10);
        bStack_10430 = (byte)((ulonglong)uVar9 >> 0x30);
        bStack_1042f = (byte)((ulonglong)uVar9 >> 0x38);
        uStack_1042e = (ushort)uVar10;
        uStack_1042c = (uint)((ulonglong)uVar10 >> 0x10);
        bStack_10428 = (byte)((ulonglong)uVar10 >> 0x30);
        bStack_10427 = (byte)((ulonglong)uVar10 >> 0x38);
        pauStack_101b8 = (undefined1 (*) [16])&DAT_0000003c;
        bStack_10528 = (byte)&uStack_103c8;
        bStack_10527 = (byte)((ulonglong)&uStack_103c8 >> 8);
        bStack_10526 = (byte)((ulonglong)&uStack_103c8 >> 0x10);
        bStack_10525 = (byte)((ulonglong)&uStack_103c8 >> 0x18);
        bStack_10524 = (byte)((ulonglong)&uStack_103c8 >> 0x20);
        bStack_10523 = (byte)((ulonglong)&uStack_103c8 >> 0x28);
        bStack_10522 = (byte)((ulonglong)&uStack_103c8 >> 0x30);
        bStack_10521 = (byte)((ulonglong)&uStack_103c8 >> 0x38);
        bStack_10520 = 0x30;
        bStack_1051f = 0xf0;
        bStack_1051e = 0x68;
        bStack_1051d = 0x40;
        bStack_1051c = 1;
        bStack_1051b = 0;
        bStack_1051a = 0;
        bStack_10519 = 0;
        bStack_10518 = (byte)&uStack_10438;
        bStack_10517 = (byte)((ulonglong)&uStack_10438 >> 8);
        uStack_10516 = (ushort)((ulonglong)&uStack_10438 >> 0x10);
        uStack_10514 = (uint)((ulonglong)&uStack_10438 >> 0x20);
        uStack_10510 = 60000;
        uStack_1050e = 0x4068;
        uStack_1050c = 1;
        uStack_1050a = 0;
        uStack_10508 = &pauStack_101b8;
        uStack_10500._0_4_ = 0x40693280;
        uStack_10500._4_4_ = 1;
        uStack_10438._2_1_ = (byte)uStack_10278;
        uStack_10438._3_1_ = uStack_10278._1_1_;
        uStack_103c8 = (undefined1 (*) [16])*puVar111;
        alloc[246c2e7857c81348]::fmt::format::format_inner
                  (&bStack_10328,&DAT_1406a20c8,&bStack_10528);
        lVar98 = CONCAT26(uStack_10322,CONCAT42(iStack_10326,CONCAT11(bStack_10327,bStack_10328)));
        uVar85 = CONCAT26(uStack_1031a,CONCAT51(uStack_1031f,bStack_10320));
        host::log(uVar85,CONCAT26(uStack_10312,
                                  CONCAT42(uStack_10316,CONCAT11(bStack_10317,bStack_10318))));
        if (lVar98 != 0) {
          pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar98,1)
          ;
          return pauVar82;
        }
        puVar111 = puVar111 + 5;
      } while (puVar111 != puVar86 + lVar80 * 5);
    }
    if (lVar120 != 0) {
      pauVar82 = (undefined1 (*) [16])
                 __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar86,lVar120 * 0x28,8);
      return pauVar82;
    }
  }
  else {
    bStack_10528 = (byte)DAT_140699580;
    bStack_10527 = (byte)((ulonglong)DAT_140699580 >> 8);
    bStack_10526 = (byte)((ulonglong)DAT_140699580 >> 0x10);
    bStack_10525 = (byte)((ulonglong)DAT_140699580 >> 0x18);
    bStack_10524 = (byte)((ulonglong)DAT_140699580 >> 0x20);
    bStack_10523 = (byte)((ulonglong)DAT_140699580 >> 0x28);
    bStack_10522 = (byte)((ulonglong)DAT_140699580 >> 0x30);
    bStack_10521 = (byte)((ulonglong)DAT_140699580 >> 0x38);
    bStack_10520 = (byte)DAT_140699588;
    bStack_1051f = (byte)(DAT_140699588 >> 8);
    bStack_1051e = (byte)(DAT_140699588 >> 0x10);
    bStack_1051d = (byte)(DAT_140699588 >> 0x18);
    lVar80 = <std[3bf9d48a0c3997f0]::time::Instant>::elapsed(&bStack_10528);
    if (lVar80 != 0) goto LAB_140034a6b;
    if ((bVar76 == 0) &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699579 = '\x01';
      }
    }
    cVar72 = LAST_PRUNE;
    LOCK();
    LAST_PRUNE = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&LAST_PRUNE);
    }
  }
  pauVar82 = OOB_SIZE_0;
  lVar80 = (ulonglong)(pauStack_101f0 == OOB_SIZE_0) * 0x20;
  if (*(longlong *)(&DAT_140699748 + lVar80) == 0) {
LAB_140035207:
    if (((char)uStack_10354 == '\0') &&
       ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
        0x7fffffffffffffff) != 0)) {
      cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
      if (cVar72 == '\0') {
        DAT_140699729 = '\x01';
      }
    }
    cVar72 = QUEUES;
    LOCK();
    QUEUES = '\0';
    UNLOCK();
    if (cVar72 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&QUEUES);
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0390) is written */
                    /* WARNING: Read-only address (ram,0x0001406a0550) is written */
      return (undefined1 (*) [16])0x0;
    }
    QUEUES = '\0';
    return (undefined1 (*) [16])0x0;
  }
  lVar120 = *(longlong *)(&DAT_140699740 + lVar80);
  lVar98 = *(longlong *)(&DAT_140699738 + lVar80);
  uVar117 = 0;
  if (*(ulonglong *)(&DAT_140699730 + lVar80) <= lVar120 + 1U) {
    uVar117 = *(ulonglong *)(&DAT_140699730 + lVar80);
  }
  *(ulonglong *)(&DAT_140699740 + lVar80) = (lVar120 - uVar117) + 1;
  *(longlong *)(&DAT_140699748 + lVar80) = *(longlong *)(&DAT_140699748 + lVar80) + -1;
  lVar120 = lVar120 * 0x20;
  lVar80 = *(longlong *)(lVar98 + 8 + lVar120);
  if (lVar80 == -1) goto LAB_140035207;
  pvVar87 = *(void **)(lVar98 + 0x10 + lVar120);
  pauVar79 = *(undefined1 (**) [16])(lVar98 + 0x18 + lVar120);
  pauStack_101b8 = *(undefined1 (**) [16])(lVar98 + lVar120);
  if (((char)uStack_10354 == '\0') &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar72 == '\0') {
      DAT_140699729 = '\x01';
    }
  }
  cVar72 = QUEUES;
  LOCK();
  QUEUES = '\0';
  UNLOCK();
  if (cVar72 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&QUEUES);
  }
  if (pvStack_10148 == (void *)0x0) {
    if (lVar80 == 0) {
      return (undefined1 (*) [16])0x0;
    }
    pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar87,lVar80,1);
    return pauVar82;
  }
  if (pauStack_101f0 < pauVar79) {
    pauVar79 = pauStack_101f0;
  }
  bStack_10328 = (byte)pauVar79;
  bStack_10327 = (byte)((ulonglong)pauVar79 >> 8);
  iStack_10326 = (int)((ulonglong)pauVar79 >> 0x10);
  uStack_10322 = (ushort)((ulonglong)pauVar79 >> 0x30);
  memcpy(pvStack_10148,pvVar87,(size_t)pauVar79);
  if (puStack_10150 != (undefined8 *)0x0) {
    *puStack_10150 = pauStack_101b8;
  }
  cVar72 = record(pauStack_101b8,pauVar79,1);
  if (cVar72 == '\0') goto LAB_140035375;
  pcVar109 = "channel";
  if (pauStack_101f0 == pauVar82) {
    pcVar109 = &DAT_1406a2e28;
  }
  auStack_10270[0] = (uint)(pauStack_101f0 != pauVar82) * 4 + 3;
  uStack_10278._0_1_ = (byte)pcVar109;
  uStack_10278._1_1_ = (byte)((ulonglong)pcVar109 >> 8);
  uStack_10276 = (ushort)((ulonglong)pcVar109 >> 0x10);
  uStack_10274 = (ushort)((ulonglong)pcVar109 >> 0x20);
  uStack_10272 = 0;
  auStack_10270[1]._0_2_ = 0;
  auStack_10270[1]._2_2_ = 0;
  pauVar82 = (undefined1 (*) [16])&DAT_00000018;
  if (pauVar79 < (undefined1 (*) [16])&DAT_00000018) {
    pauVar82 = pauVar79;
  }
  if (pauVar79 == (undefined1 (*) [16])0x0) {
LAB_140035270:
    uStack_103a8 = 0;
    uStack_103a6 = 0;
    uStack_103a4 = 0;
    uStack_103a2 = 0;
    uStack_103a0 = 1;
    uStack_1039e = 0;
    uStack_1039c = 0;
    uStack_10398 = 0;
    uStack_10396 = 0;
    uStack_10394 = 0;
  }
  else {
    uStack_103a8 = (ushort)pvVar87;
    uStack_103a6 = (ushort)((ulonglong)pvVar87 >> 0x10);
    uStack_103a4 = (ushort)((ulonglong)pvVar87 >> 0x20);
    uStack_103a2 = (ushort)((ulonglong)pvVar87 >> 0x30);
    bStack_10528 = (byte)&uStack_103a8;
    bStack_10527 = (byte)((ulonglong)&uStack_103a8 >> 8);
    bStack_10526 = (byte)((ulonglong)&uStack_103a8 >> 0x10);
    bStack_10525 = (byte)((ulonglong)&uStack_103a8 >> 0x18);
    bStack_10524 = (byte)((ulonglong)&uStack_103a8 >> 0x20);
    bStack_10523 = (byte)((ulonglong)&uStack_103a8 >> 0x28);
    bStack_10522 = (byte)((ulonglong)&uStack_103a8 >> 0x30);
    bStack_10521 = (byte)((ulonglong)&uStack_103a8 >> 0x38);
    bStack_10520 = 0x30;
    bStack_1051f = 0x29;
    bStack_1051e = 0x24;
    bStack_1051d = 0x40;
    bStack_1051c = 1;
    bStack_1051b = 0;
    bStack_1051a = 0;
    bStack_10519 = 0;
    alloc[246c2e7857c81348]::fmt::format::format_inner
              (&uStack_10438,&anon_1a1cfe3ac28698fadcb73c62956d839a_28_llvm_3977132774650517797,
               &bStack_10528);
    if (CONCAT44(uStack_10438._4_4_,
                 CONCAT13(uStack_10438._3_1_,
                          CONCAT12(uStack_10438._2_1_,
                                   CONCAT11(uStack_10438._1_1_,(byte)uStack_10438)))) == -1)
    goto LAB_140035270;
    bStack_10518 = bStack_10428;
    bStack_10517 = bStack_10427;
    uStack_10516 = uStack_10426;
    uStack_10514 = uStack_10424;
    bStack_10528 = (byte)uStack_10438;
    bStack_10527 = uStack_10438._1_1_;
    bStack_10526 = uStack_10438._2_1_;
    bStack_10525 = uStack_10438._3_1_;
    bStack_10524 = (byte)uStack_10438._4_4_;
    bStack_10523 = (byte)((uint)uStack_10438._4_4_ >> 8);
    bStack_10522 = (byte)((uint)uStack_10438._4_4_ >> 0x10);
    bStack_10521 = (byte)((uint)uStack_10438._4_4_ >> 0x18);
    bStack_10520 = bStack_10430;
    bStack_1051f = bStack_1042f;
    bStack_1051e = (byte)uStack_1042e;
    bStack_1051d = (byte)(uStack_1042e >> 8);
    bStack_1051c = (byte)uStack_1042c;
    bStack_1051b = (byte)(uStack_1042c >> 8);
    bStack_1051a = (byte)(uStack_1042c >> 0x10);
    bStack_10519 = (byte)(uStack_1042c >> 0x18);
    <core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<u8>,host_probe[b94139f9089eb1d8]::aiwave::place_squad::{closure#1}::{closure#0}>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
    ::fold::
    <(),core[505b25137b8ba7f]::iter::traits::iterator::Iterator::for_each::call<alloc[246c2e7857c81348]::string::String,<alloc[246c2e7857c81348]::string::String_as_core[505b25137b8ba7f]::iter::traits::collect::Extend<alloc[246c2e7857c81348]::string::String>>::extend<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::slice::iter::Iter<u8>,host_probe[b94139f9089eb1d8]::aiwave::place_squad::_closure_1_::_closure_0_>>::_closure_0_>::_closure_0_>
              ((longlong)pvVar87 + 1,*pauVar82 + (longlong)pvVar87,&bStack_10528);
    uStack_10398 = CONCAT11(bStack_10517,bStack_10518);
    uStack_10396 = uStack_10516;
    uStack_10394 = uStack_10514;
    uStack_103a8 = CONCAT11(bStack_10527,bStack_10528);
    uVar78 = CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_103a8));
    uVar27 = CONCAT15(bStack_10523,CONCAT14(bStack_10524,uVar78));
    uStack_103a0 = CONCAT11(bStack_1051f,bStack_10520);
    uVar97 = CONCAT13(bStack_1051d,CONCAT12(bStack_1051e,uStack_103a0));
    uStack_103a6 = (ushort)((uint)uVar78 >> 0x10);
    uStack_103a4 = (ushort)((uint6)uVar27 >> 0x20);
    uStack_103a2 = (ushort)(CONCAT17(bStack_10521,CONCAT16(bStack_10522,uVar27)) >> 0x30);
    uStack_1039e = (ushort)((uint)uVar97 >> 0x10);
    uStack_1039c = (uint)(CONCAT17(bStack_10519,
                                   CONCAT16(bStack_1051a,
                                            CONCAT15(bStack_1051b,CONCAT14(bStack_1051c,uVar97))))
                         >> 0x20);
  }
  bStack_10528 = (byte)&uStack_10278;
  bStack_10527 = (byte)((ulonglong)&uStack_10278 >> 8);
  bStack_10526 = (byte)((ulonglong)&uStack_10278 >> 0x10);
  bStack_10525 = (byte)((ulonglong)&uStack_10278 >> 0x18);
  bStack_10524 = (byte)((ulonglong)&uStack_10278 >> 0x20);
  bStack_10523 = (byte)((ulonglong)&uStack_10278 >> 0x28);
  bStack_10522 = (byte)((ulonglong)&uStack_10278 >> 0x30);
  bStack_10521 = (byte)((ulonglong)&uStack_10278 >> 0x38);
  bStack_10520 = 0xd0;
  bStack_1051f = 0x28;
  bStack_1051e = 0x24;
  bStack_1051d = 0x40;
  bStack_1051c = 1;
  bStack_1051b = 0;
  bStack_1051a = 0;
  bStack_10519 = 0;
  bStack_10518 = (byte)&pauStack_101b8;
  bStack_10517 = (byte)((ulonglong)&pauStack_101b8 >> 8);
  uStack_10516 = (ushort)((ulonglong)&pauStack_101b8 >> 0x10);
  uStack_10514 = (uint)((ulonglong)&pauStack_101b8 >> 0x20);
  uStack_10510 = 0xf030;
  uStack_1050e = 0x4068;
  uStack_1050c = 1;
  uStack_1050a = 0;
  uStack_10508 = (undefined1 (**) [16])&bStack_10328;
  uStack_10500._0_4_ = 0x40693280;
  uStack_10500._4_4_ = 1;
  uStack_104f8 = &uStack_103a8;
  uStack_104f0 = 0x40041f60;
  uStack_104ec = 1;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&uStack_10438,&DAT_1406a2e2b,&bStack_10528);
  lVar120 = CONCAT26(uStack_103a2,CONCAT24(uStack_103a4,CONCAT22(uStack_103a6,uStack_103a8)));
  if (lVar120 != 0) {
    pauVar82 = (undefined1 (*) [16])
               __rustc[9d087a5ab36ea756]::__rust_dealloc
                         (CONCAT44(uStack_1039c,CONCAT22(uStack_1039e,uStack_103a0)),lVar120,1);
    return pauVar82;
  }
  lVar120 = CONCAT44(uStack_10438._4_4_,
                     CONCAT13(uStack_10438._3_1_,
                              CONCAT12(uStack_10438._2_1_,
                                       CONCAT11(uStack_10438._1_1_,(byte)uStack_10438))));
  uVar85 = CONCAT44(uStack_1042c,CONCAT22(uStack_1042e,CONCAT11(bStack_1042f,bStack_10430)));
  host::log(uVar85,CONCAT44(uStack_10424,CONCAT22(uStack_10426,CONCAT11(bStack_10427,bStack_10428)))
           );
  if (lVar120 != 0) {
    pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_dealloc(uVar85,lVar120,1);
    return pauVar82;
  }
  pauVar79 = (undefined1 (*) [16])
             CONCAT26(uStack_10322,CONCAT42(iStack_10326,CONCAT11(bStack_10327,bStack_10328)));
LAB_140035375:
  if (lVar80 != 0) {
    pauVar82 = (undefined1 (*) [16])__rustc[9d087a5ab36ea756]::__rust_dealloc(pvVar87,lVar80,1);
    return pauVar82;
  }
  return pauVar79;
LAB_1400310a2:
  do {
    if (*(short *)(lVar98 + lVar128) == sVar116) {
      if ((bStack_104a8 & 1) == 0) {
        if ((*(ushort *)(lVar98 + 6 + lVar128) == uStack_104a2) &&
           (*(int *)(lVar98 + 2 + lVar128) ==
            CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)))) goto LAB_140031101;
      }
      else if ((*(short *)(lVar98 + 0x1c + lVar128) == uStack_10490._4_2_) &&
              (((*(uint *)(lVar98 + 0x14 + lVar128) == uVar113 &&
                (*(int *)(lVar98 + 0x18 + lVar128) == (int)uStack_10490)) &&
               (*(undefined1 (**) [16])(lVar98 + 0xc + lVar128) == uStack_10460 &&
                *(undefined1 (**) [16])(lVar98 + 4 + lVar128) == uStack_104b8))))
      goto LAB_140031101;
    }
    pauVar104 = (undefined1 (*) [16])(*pauVar104 + 1);
    lVar128 = lVar128 + 0x20;
  } while ((longlong)pauVar92 * 0x20 != lVar128);
LAB_14002e39b:
  if (lVar120 != 0) {
    lVar98 = 0;
    do {
      if (*(short *)(lVar80 + lVar98) == sVar116) {
        if ((bStack_104a8 & 1) == 0) {
          if ((*(ushort *)(lVar80 + 6 + lVar98) == uStack_104a2) &&
             (*(int *)(lVar80 + 2 + lVar98) ==
              CONCAT13(bStack_10525,CONCAT12(bStack_10526,uStack_104a6)))) goto LAB_140031101;
        }
        else if (((*(short *)(lVar80 + 0x1c + lVar98) == uStack_10490._4_2_) &&
                 (*(uint *)(lVar80 + 0x14 + lVar98) == uVar113)) &&
                ((*(int *)(lVar80 + 0x18 + lVar98) == (int)uStack_10490 &&
                 (*(longlong *)(lVar80 + 0xc + lVar98) ==
                  CONCAT17(bStack_10517,
                           CONCAT16(bStack_10518,
                                    CONCAT15(bStack_10519,CONCAT14(bStack_1051a,uStack_1049c)))) &&
                  *(longlong *)(lVar80 + 4 + lVar98) ==
                  CONCAT17(bStack_1051f,
                           CONCAT16(bStack_10520,
                                    CONCAT15(bStack_10521,
                                             CONCAT14(bStack_10522,
                                                      CONCAT13(bStack_10523,
                                                               CONCAT12(bStack_10524,uStack_104a4)))
                                            ))))))) goto LAB_140031101;
      }
      pauVar104 = (undefined1 (*) [16])(*pauVar104 + 1);
      lVar98 = lVar98 + 0x20;
    } while (lVar120 != lVar98);
  }
LAB_1400337e9:
  uStack_10490 = uVar117;
  pauVar123 = DAT_140699940;
  uVar114 = (uint)uStack_10458;
  if ((undefined1 (*) [16])0xff < DAT_140699940) {
    pauVar123 = (undefined1 (*) [16])0x0;
    if (pauVar82 <= (undefined1 (*) [16])(*pauVar79 + 1)) {
      pauVar123 = pauVar82;
    }
    pauVar79 = (undefined1 (*) [16])((longlong)(*pauVar79 + 1) - (longlong)pauVar123);
    pauVar123 = (undefined1 (*) [16])(DAT_140699940[-1] + 0xf);
    DAT_140699938 = pauVar79;
    DAT_140699940 = pauVar123;
  }
LAB_14003381d:
  if (pauVar123 == pauVar82) {
    <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<core[505b25137b8ba7f]::net::socket_addr::SocketAddr>>
    ::grow(&DAT_140699928);
    pauVar79 = DAT_140699938;
    pauVar123 = DAT_140699940;
    pauVar82 = DAT_140699928;
    lVar80 = DAT_140699930;
  }
  DAT_140699940 = (undefined1 (*) [16])(*pauVar123 + 1);
  pauVar89 = (undefined1 (*) [16])0x0;
  if (pauVar82 <= (undefined1 (*) [16])(*pauVar123 + (longlong)*pauVar79)) {
    pauVar89 = pauVar82;
  }
  lVar120 = ((longlong)(*pauVar123 + (longlong)*pauVar79) - (longlong)pauVar89) * 0x20;
  *(short *)(lVar80 + lVar120) = sVar116;
  puVar86 = (undefined8 *)(lVar80 + 2 + lVar120);
  *puVar86 = CONCAT17(bStack_10521,
                      CONCAT16(bStack_10522,
                               CONCAT15(bStack_10523,
                                        CONCAT14(bStack_10524,
                                                 CONCAT13(bStack_10525,
                                                          CONCAT12(bStack_10526,
                                                                   CONCAT11(bStack_10527,
                                                                            bStack_10528)))))));
  puVar86[1] = CONCAT17(bStack_10519,
                        CONCAT16(bStack_1051a,
                                 CONCAT15(bStack_1051b,
                                          CONCAT14(bStack_1051c,
                                                   CONCAT13(bStack_1051d,
                                                            CONCAT12(bStack_1051e,
                                                                     CONCAT11(bStack_1051f,
                                                                              bStack_10520)))))));
  *(ushort *)(lVar80 + 0x12 + lVar120) = CONCAT11(bStack_10517,bStack_10518);
  *(uint *)(lVar80 + 0x14 + lVar120) = uVar113;
  *(int *)(lVar80 + 0x18 + lVar120) = iVar127;
  *(undefined4 *)(lVar80 + 0x1c + lVar120) = uVar78;
  if (((char)uVar114 == '\0') &&
     ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) != 0)) {
    cVar72 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    if (cVar72 == '\0') {
      DAT_140699921 = '\x01';
    }
  }
  cVar72 = DAT_140699920;
  LOCK();
  DAT_140699920 = '\0';
  UNLOCK();
  if (cVar72 == '\x02') {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake(&DAT_140699920);
  }
  ppuVar103 = &anon_abae67b6203ffecafa6256cb9d53fac3_2_llvm_5426317090953290063;
  if ((CONCAT11(bStack_104a7,bStack_104a8) != 2) &&
     (ppuVar103 = (undefined **)CONCAT44(uStack_1049c,CONCAT22(uStack_1049e,uStack_104a0)),
     CONCAT11(bStack_104a7,bStack_104a8) != -1)) {
    bStack_10528 = bStack_104a8;
    bStack_10527 = bStack_104a7;
    bStack_10522 = (byte)uStack_104a2;
    bStack_10521 = (byte)(uStack_104a2 >> 8);
    bStack_10526 = (byte)uStack_104a6;
    bStack_10525 = (byte)(uStack_104a6 >> 8);
    bStack_10524 = (byte)uStack_104a4;
    bStack_10523 = (byte)(uStack_104a4 >> 8);
    bStack_10520 = (byte)uStack_104a0;
    bStack_1051f = (byte)(uStack_104a0 >> 8);
    bStack_1051e = (byte)uStack_1049e;
    bStack_1051d = (byte)(uStack_1049e >> 8);
    bStack_1051c = (byte)uStack_1049c;
    bStack_1051b = (byte)(uStack_1049c >> 8);
    bStack_1051a = (byte)(uStack_1049c >> 0x10);
    bStack_10519 = (byte)(uStack_1049c >> 0x18);
    bStack_10518 = (byte)uStack_10498;
    bStack_10517 = (byte)(uStack_10498 >> 8);
    uStack_10516 = uStack_10496;
    uStack_10514 = uStack_10494;
    uStack_10510 = (ushort)uStack_10490;
    uStack_1050e = (ushort)(uStack_10490 >> 0x10);
    uStack_1050c = (ushort)(uStack_10490 >> 0x20);
    uStack_1050a = (ushort)(uStack_10490 >> 0x30);
    ppuVar103 = (undefined **)uStack_104b0;
    uVar117 = <std[3bf9d48a0c3997f0]::sys::net::connection::socket::UdpSocket>::send_to
                        (&DAT_140699980,uStack_104b0,0x18,&bStack_10528);
    if ((uVar117 & 1) == 0) {
      LOCK();
      DAT_1407f1050 = *(undefined1 (*) [16])ppuVar103 + (longlong)DAT_1407f1050;
      UNLOCK();
      LOCK();
      DAT_1407f1058 = DAT_1407f1058 + 1;
      UNLOCK();
      pauStack_10538 = (undefined1 (*) [16])&DAT_00000018;
      goto LAB_1400331d8;
    }
  }
  LOCK();
  DAT_1407f1080 = DAT_1407f1080 + 1;
  UNLOCK();
  if ((1 < ((uint)ppuVar103 & 3) - 2) && (((ulonglong)ppuVar103 & 3) != 0)) {
    puVar99 = *(undefined1 (*) [16])((longlong)ppuVar103 + -0x10) + 0xf;
    bStack_10520 = (byte)puVar99;
    bStack_1051f = (byte)((ulonglong)puVar99 >> 8);
    bStack_1051e = (byte)((ulonglong)puVar99 >> 0x10);
    bStack_1051d = (byte)((ulonglong)puVar99 >> 0x18);
    bStack_1051c = (byte)((ulonglong)puVar99 >> 0x20);
    bStack_1051b = (byte)((ulonglong)puVar99 >> 0x28);
    bStack_1051a = (byte)((ulonglong)puVar99 >> 0x30);
    bStack_10519 = (byte)((ulonglong)puVar99 >> 0x38);
    bStack_10528 = 3;
    <core[505b25137b8ba7f]::io::error::CustomOwner_as_core[505b25137b8ba7f]::ops::drop::Drop>::drop
              (&bStack_10520);
  }
  pauStack_10538 = (undefined1 (*) [16])&DAT_00000018;
LAB_1400331d8:
  pauVar82 = (undefined1 (*) [16])
             __rustc[9d087a5ab36ea756]::__rust_dealloc(uStack_104b0,pauStack_10538,1);
  return pauVar82;
}

