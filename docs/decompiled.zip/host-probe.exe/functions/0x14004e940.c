// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<serde_json[7404bcab4dc139c7]::value::Value,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>>>::from_iter
// address: 0x14004e940
// body: available
// range: 0x14004e940-0x14004eae8 inclusive
// range: 0x14004eaf0-0x14004eb6c inclusive
// range: 0x14004eb70-0x14004ec76 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<serde_json[7404bcab4dc139c7]::value::Value,
   core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>,
   <host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>>>::from_iter
    */

longlong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<serde_json[7404bcab4dc139c7]::value::Value>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<serde_json[7404bcab4dc139c7]::value::Value,core[505b25137b8ba7f]::iter::adapters::filter_map::FilterMap<alloc[246c2e7857c81348]::collections::vec_deque::iter::Iter<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line>,<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>>>
::from_iter(longlong *param_1,longlong *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  code *pcVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong **pplVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 local_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  longlong local_d8;
  longlong lStack_d0;
  longlong *local_c0;
  undefined8 *puStack_b8;
  longlong *local_b0;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined1 uStack_9c;
  undefined2 uStack_9b;
  undefined1 uStack_99;
  undefined1 uStack_98;
  undefined2 uStack_97;
  undefined4 uStack_95;
  undefined4 uStack_91;
  undefined4 uStack_8d;
  undefined1 uStack_89;
  longlong **local_80;
  longlong **local_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined3 uStack_68;
  undefined4 uStack_65;
  undefined4 uStack_61;
  undefined4 uStack_5d;
  longlong *local_50;
  longlong *local_48;
  
  local_c0 = param_2 + 4;
  lVar2 = param_2[1];
  if (*param_2 != lVar2) {
    lVar8 = *param_2;
    local_78 = &local_c0;
    do {
      lVar9 = lVar8 + 0x80;
      *param_2 = lVar9;
      <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find_map::check<&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line,serde_json[7404bcab4dc139c7]::value::Value,&mut<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line)>>
      ::call_mut(&local_f8,&local_78,lVar8);
      if ((char)local_f8 != -1) goto LAB_14004ea23;
      lVar8 = lVar9;
    } while (lVar9 != lVar2);
  }
  lVar2 = param_2[3];
  if (param_2[2] != lVar2) {
    lVar8 = param_2[2];
    local_78 = &local_c0;
    do {
      lVar9 = lVar8 + 0x80;
      param_2[2] = lVar9;
      <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find_map::check<&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line,serde_json[7404bcab4dc139c7]::value::Value,&mut<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line)>>
      ::call_mut(&local_f8,&local_78,lVar8);
      if ((char)local_f8 != -1) goto LAB_14004ea23;
      lVar8 = lVar9;
    } while (lVar9 != lVar2);
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
LAB_14004ea23:
  uStack_98 = (undefined1)((uint)(undefined4)uStack_e8 >> 8);
  uStack_97 = (undefined2)((uint)(undefined4)uStack_e8 >> 0x10);
  uStack_95 = uStack_e8._4_4_;
  uStack_91 = (undefined4)uStack_e0;
  uStack_8d = uStack_e0._4_4_;
  local_a8 = (undefined4)CONCAT43(local_f8._4_4_,local_f8._1_3_);
  uStack_a4 = (undefined4)
              (CONCAT17((undefined1)uStack_f0,CONCAT43(local_f8._4_4_,local_f8._1_3_)) >> 0x20);
  uStack_a0 = (undefined4)CONCAT43(uStack_ec,uStack_f0._1_3_);
  uStack_9c = (undefined1)((uint)uStack_ec >> 8);
  uStack_9b = (undefined2)((uint)uStack_ec >> 0x10);
  uStack_99 = (undefined1)uStack_e8;
  __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
  puVar7 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(0x80,8);
  if (puVar7 == (undefined8 *)0x0) {
    alloc[246c2e7857c81348]::raw_vec::handle_error(8,0x80);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  puVar7[2] = CONCAT44(uStack_e8._4_4_,(undefined4)uStack_e8);
  puVar7[3] = uStack_e0;
  *puVar7 = CONCAT44(local_f8._4_4_,(undefined4)local_f8);
  puVar7[1] = CONCAT44(uStack_ec,uStack_f0);
  local_c0 = (longlong *)0x4;
  local_b0 = (longlong *)0x1;
  local_f8 = *param_2;
  uStack_f0 = (undefined4)param_2[1];
  uStack_ec = *(undefined4 *)((longlong)param_2 + 0xc);
  uStack_e8 = param_2[2];
  uStack_e0 = param_2[3];
  local_d8 = param_2[4];
  lStack_d0 = param_2[5];
  puStack_b8 = puVar7;
  local_50 = param_1;
LAB_14004eb1b:
  plVar5 = local_b0;
  lVar2 = CONCAT44(uStack_ec,uStack_f0);
  lVar9 = local_f8;
  local_80 = &local_48;
  local_48 = &local_d8;
  lVar8 = uStack_e8;
  do {
    lVar4 = uStack_e0;
    pplVar6 = &local_48;
    if (lVar9 == lVar2) goto LAB_14004eb90;
    local_f8 = lVar9 + 0x80;
    uStack_e8 = lVar8;
    <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find_map::check<&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line,serde_json[7404bcab4dc139c7]::value::Value,&mut<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line)>>
    ::call_mut(&local_a8,&local_80,lVar9);
    lVar9 = lVar9 + 0x80;
    lVar8 = uStack_e8;
  } while ((char)local_a8 == -1);
  goto LAB_14004ebbf;
LAB_14004eb90:
  do {
    local_80 = pplVar6;
    if (lVar8 == lVar4) {
      local_50[2] = (longlong)local_b0;
      *local_50 = (longlong)local_c0;
      local_50[1] = (longlong)puStack_b8;
      return local_50;
    }
    uStack_e8 = lVar8 + 0x80;
    <&mut_core[505b25137b8ba7f]::iter::traits::iterator::Iterator::find_map::check<&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line,serde_json[7404bcab4dc139c7]::value::Value,&mut<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>::snapshot::{closure#0}>::{closure#0}as_core[505b25137b8ba7f]::ops::function::FnMut<((),&host_probe[b94139f9089eb1d8]::ingame_chat::transport::Line)>>
    ::call_mut(&local_a8,&local_80,lVar8);
    lVar8 = lVar8 + 0x80;
    pplVar6 = local_80;
  } while ((char)local_a8 == -1);
LAB_14004ebbf:
  local_78 = (longlong **)CONCAT17((undefined1)uStack_a0,CONCAT43(uStack_a4,local_a8._1_3_));
  uStack_70 = CONCAT13(uStack_9c,uStack_a0._1_3_);
  uStack_65 = CONCAT13((undefined1)uStack_91,uStack_95._1_3_);
  uStack_61 = CONCAT13((undefined1)uStack_8d,uStack_91._1_3_);
  uStack_5d = CONCAT13(uStack_89,uStack_8d._1_3_);
  uStack_68 = (undefined3)(CONCAT13((undefined1)uStack_95,CONCAT21(uStack_97,uStack_98)) >> 8);
  uStack_6c = (undefined4)
              (CONCAT17(uStack_98,CONCAT16(uStack_99,CONCAT24(uStack_9b,uStack_70))) >> 0x20);
  uStack_95 = (undefined4)(CONCAT43(uStack_65,uStack_68) >> 0x10);
  uStack_8d = (undefined4)(CONCAT44(uStack_5d,uStack_61) >> 0x18);
  if (plVar5 == local_c0) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(&local_c0,plVar5,1,8,0x20);
    puVar7 = puStack_b8;
  }
  puVar7[(longlong)plVar5 * 4 + 2] =
       CONCAT17((undefined1)uStack_91,CONCAT43(uStack_95,CONCAT21(uStack_97,uStack_98)));
  (puVar7 + (longlong)plVar5 * 4 + 2)[1] = CONCAT17(uStack_89,CONCAT43(uStack_8d,uStack_91._1_3_));
  puVar1 = puVar7 + (longlong)plVar5 * 4;
  *(undefined4 *)puVar1 = local_a8;
  *(undefined4 *)((longlong)puVar1 + 4) = uStack_a4;
  *(undefined4 *)(puVar1 + 1) = uStack_a0;
  *(uint *)((longlong)puVar1 + 0xc) = CONCAT13(uStack_99,CONCAT21(uStack_9b,uStack_9c));
  local_b0 = (longlong *)((longlong)plVar5 + 1);
  goto LAB_14004eb1b;
}

