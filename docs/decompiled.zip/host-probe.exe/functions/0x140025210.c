// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::parse_endpoint
// address: 0x140025210
// body: available
// range: 0x140025210-0x140025230 inclusive
// range: 0x140025240-0x140025282 inclusive
// range: 0x140025290-0x140025536 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::parse_endpoint */

void __rustcall
host_probe[b94139f9089eb1d8]::net::parse_endpoint
          (ulonglong *param_1,longlong param_2,ulonglong param_3)

{
  void *_Src;
  char cVar1;
  byte bVar2;
  code *pcVar3;
  ulonglong _Size;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  uint uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  char *pcVar14;
  ulonglong local_f0;
  void *local_e8;
  ulonglong local_e0;
  ulonglong local_d8;
  void *local_d0;
  ulonglong local_c8;
  longlong local_c0;
  ulonglong local_b8;
  void **local_a8;
  undefined8 *local_a0;
  void *local_98;
  
  uVar5 = 0;
  while( true ) {
    uVar11 = param_2 + uVar5;
    if (param_3 - uVar5 < 0x10) {
      if (param_3 == uVar5) goto LAB_140025355;
      uVar8 = 0;
      while (*(char *)(uVar11 + uVar8) != '@') {
        uVar8 = uVar8 + 1;
        if (param_3 - uVar5 == uVar8) goto LAB_140025355;
      }
    }
    else {
      uVar10 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned(0x40);
      uVar8 = uVar11;
      if ((uVar10 & 1) == 0) goto LAB_140025355;
    }
    uVar10 = uVar8 + uVar5 + 1;
    uVar11 = uVar8 + uVar5;
    if ((uVar11 < param_3) && (*(char *)(param_2 + uVar11) == '@')) break;
    uVar5 = uVar10;
    if (param_3 < uVar10) goto LAB_140025355;
  }
  local_d8 = param_3 - uVar10;
  _Src = (void *)(param_2 + uVar10);
  local_d0 = _Src;
  local_c8 = local_d8;
  <core[505b25137b8ba7f]::str::pattern::StrSearcher>::new
            (&local_a8,param_2,uVar11,
             &anon_d5c34e88a06ee720b116585eb143da4b_38_llvm_14435704873730135342,2);
  do {
    <core[505b25137b8ba7f]::str::pattern::StrSearcher_as_core[505b25137b8ba7f]::str::pattern::Searcher>
    ::next(&local_c0,&local_a8);
    _Size = local_d8;
  } while (local_c0 == 0);
  uVar6 = uVar11;
  if ((int)local_c0 == 1) {
    uVar6 = local_b8;
  }
  uVar11 = uVar11 - uVar6;
  if (uVar11 == 0) goto LAB_140025355;
  pcVar14 = (char *)(param_2 + uVar6);
  if (uVar11 == 1) {
    cVar1 = *pcVar14;
    if ((cVar1 == '+') || (cVar1 == '-')) goto LAB_140025355;
  }
  else {
    cVar1 = *pcVar14;
  }
  uVar6 = 0;
  uVar9 = (ulonglong)(cVar1 == '+');
  uVar12 = uVar11 - uVar9;
  uVar13 = 0;
  if (uVar12 < 0x11) {
    if (uVar11 != uVar9) {
      uVar6 = 0;
      do {
        bVar2 = pcVar14[uVar6 + uVar9];
        uVar7 = bVar2 - 0x30;
        if (0x39 < bVar2) {
          uVar7 = (bVar2 - 0x41 & 0xffffffdf) + 10;
        }
        if (0xf < uVar7) goto LAB_140025355;
        uVar13 = (ulonglong)uVar7 | uVar13 << 4;
        uVar6 = uVar6 + 1;
      } while (uVar12 != uVar6);
    }
  }
  else {
    uVar6 = 0;
    do {
      if (uVar13 >> 0x3c != 0) {
LAB_140025355:
        param_1[1] = 0xffffffffffffffff;
        return;
      }
      uVar11 = uVar13 * 0x10;
      bVar2 = pcVar14[uVar6 + uVar9];
      uVar7 = bVar2 - 0x30;
      if (0x39 < bVar2) {
        uVar7 = (bVar2 - 0x41 & 0xffffffdf) + 10;
      }
      uVar13 = uVar7 + uVar11;
      if (CARRY8((ulonglong)uVar7,uVar11) || 0xf < uVar7) goto LAB_140025355;
      uVar6 = uVar6 + 1;
    } while (uVar12 != uVar6);
  }
  if (local_d8 < 0x10) {
    if (param_3 != uVar10) {
      lVar4 = 0;
      do {
        if (*(char *)((longlong)_Src + lVar4) == ':') goto LAB_140025472;
        lVar4 = lVar4 + 1;
      } while ((~uVar5 + param_3) - uVar8 != lVar4);
    }
  }
  else {
    uVar5 = core[505b25137b8ba7f]::slice::memchr::memchr_aligned
                      (CONCAT71((int7)(uVar6 >> 8),0x3a),_Src,local_d8);
    if ((uVar5 & 1) != 0) {
LAB_140025472:
      <alloc[246c2e7857c81348]::raw_vec::RawVecInner>::try_allocate_in(&local_a8,_Size,0,1,1);
      if ((char)local_a8 != '\0') {
        alloc[246c2e7857c81348]::raw_vec::handle_error(local_a0,local_98);
                    /* WARNING: Does not return */
        pcVar3 = (code *)invalidInstructionException();
        (*pcVar3)();
      }
      memcpy(local_98,_Src,_Size);
      local_f0 = (ulonglong)local_a0;
      local_e8 = local_98;
      local_e0 = _Size;
      goto LAB_140025502;
    }
  }
  local_a8 = &local_d0;
  local_a0 = &<&str_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_f0,&DAT_1406a22d0,&local_a8);
LAB_140025502:
  *param_1 = uVar13;
  param_1[1] = local_f0;
  param_1[2] = (ulonglong)local_e8;
  param_1[3] = local_e0;
  return;
}

