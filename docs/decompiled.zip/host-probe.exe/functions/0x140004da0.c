// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>
// address: 0x140004da0
// body: available
// range: 0x140004da0-0x140004ecb inclusive
// range: 0x140004ed0-0x140004eef inclusive
// range: 0x140004ef2-0x1400051bb inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140004dc5 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004e66 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004e87 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004eae to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004eeb to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004f0f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140004fe4 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000502a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14000504e to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140005106 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140005133 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140005151 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is
// limitations_truncated: true; decompile-index.json keeps the complete list
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>
    */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Node>
          (longlong *param_1)

{
  undefined1 auVar1 [16];
  ulonglong uVar2;
  uint uVar3;
  uint uVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  ulonglong uVar8;
  ushort uVar9;
  uint uVar10;
  ulonglong uVar11;
  longlong lVar12;
  undefined8 *puVar13;
  undefined1 (*pauVar14) [16];
  ulonglong uVar15;
  undefined1 (*pauVar16) [16];
  
  if (*param_1 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],*param_1,1);
    return;
  }
  uVar5 = param_1[3];
  uVar2 = param_1[6];
  if (uVar2 == 0) {
    lVar6 = param_1[4];
  }
  else {
    lVar6 = param_1[4];
    uVar15 = uVar5;
    if ((ulonglong)param_1[5] < uVar5) {
      uVar15 = 0;
    }
    lVar12 = param_1[5] - uVar15;
    uVar11 = uVar5 - lVar12;
    uVar15 = uVar2 - uVar11;
    if (uVar2 < uVar11) {
      uVar15 = 0;
    }
    uVar8 = lVar12 + uVar2;
    if (uVar2 >= uVar11 && uVar2 - uVar11 != 0) {
      uVar8 = uVar5;
    }
    lVar7 = uVar8 - lVar12;
    if (lVar7 != 0) {
      lVar12 = lVar12 * 0x80 + lVar6;
      do {
        <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(lVar12);
        lVar12 = lVar12 + 0x80;
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
    }
    lVar12 = lVar6;
    if (uVar11 < uVar2) {
      do {
        <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(lVar12);
        uVar15 = uVar15 - 1;
        lVar12 = lVar12 + 0x80;
      } while (uVar15 != 0);
    }
  }
  if (uVar5 != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar6,uVar5 << 7,8);
    return;
  }
  <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<(u64,alloc[246c2e7857c81348]::string::String)>>
            (param_1 + 7);
  if (param_1[0xb] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0xc],param_1[0xb],1);
    return;
  }
  <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<alloc[246c2e7857c81348]::string::String>>
            (param_1 + 0xe);
  if (param_1[0x12] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x13],param_1[0x12],1);
    return;
  }
  lVar6 = param_1[0x17];
  if (lVar6 != 0) {
    puVar13 = (undefined8 *)(param_1[0x16] + 8);
    do {
      if (puVar13[-1] != 0) {
        __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar13,puVar13[-1],1);
        return;
      }
      puVar13 = puVar13 + 5;
      lVar6 = lVar6 + -1;
    } while (lVar6 != 0);
  }
  if (param_1[0x15] != 0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x16],param_1[0x15] * 0x28,8);
    return;
  }
  <reach_directory[4b72b9694f6c3c08]::chat::HostRelay>(param_1 + 0x18);
  lVar6 = param_1[0x6c];
  if (lVar6 != 0) {
    lVar12 = param_1[0x6e];
    if (lVar12 != 0) {
      pauVar14 = (undefined1 (*) [16])param_1[0x6b];
      auVar1 = *pauVar14;
      pauVar16 = pauVar14 + 1;
      uVar10 = ~(uint)(ushort)((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                               (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                               (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                               (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                               (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                               (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                               (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                               (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                               (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                               (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                               (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                               (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                               (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                               (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                               (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                              (ushort)(byte)(auVar1[0xf] >> 7) << 0xf);
      do {
        uVar9 = (ushort)uVar10;
        while (uVar9 == 0) {
          auVar1 = *pauVar16;
          pauVar14 = pauVar14 + -0x50;
          pauVar16 = pauVar16 + 1;
          uVar9 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) | (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1
                   | (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                   (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                   (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                   (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                   (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                   (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                   (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                   (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                   (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                   (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                   (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                   (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                   (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                  (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
          uVar10 = (uint)uVar9;
        }
        uVar3 = 0;
        for (uVar4 = uVar10; (uVar4 & 1) == 0; uVar4 = uVar4 >> 1 | 0x80000000) {
          uVar3 = uVar3 + 1;
        }
        <(u64,host_probe[b94139f9089eb1d8]::ingame_chat::transport::Connection)>
                  (pauVar14 + (ulonglong)uVar3 * -5 + -5);
        uVar10 = uVar10 - 1 & uVar10;
        lVar12 = lVar12 + -1;
      } while (lVar12 != 0);
    }
    lVar12 = lVar6 * 0x51 + 0x61;
    if (lVar12 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x6b] + lVar6 * -0x50 + -0x50,lVar12,0x10);
      return;
    }
  }
  <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::ingame_chat::transport::Probe>>
            (param_1 + 0x3f);
  lVar6 = param_1[0x72];
  if (lVar6 != 0) {
    uVar5 = lVar6 * 8 & 0xfffffffffffffff0;
    lVar6 = lVar6 + uVar5 + 0x21;
    if (lVar6 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc((param_1[0x71] - uVar5) + -0x10,lVar6,0x10);
      return;
    }
  }
  lVar6 = param_1[0x51];
  if (lVar6 != -1) {
    if (lVar6 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x52],lVar6,1);
      return;
    }
    <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(param_1 + 0x58);
  }
  uVar5 = param_1[0x43];
  uVar2 = param_1[0x46];
  if (uVar2 == 0) {
    lVar6 = param_1[0x44];
  }
  else {
    lVar6 = param_1[0x44];
    uVar15 = uVar5;
    if ((ulonglong)param_1[0x45] < uVar5) {
      uVar15 = 0;
    }
    lVar12 = param_1[0x45] - uVar15;
    uVar11 = uVar5 - lVar12;
    uVar15 = uVar2 - uVar11;
    if (uVar2 < uVar11) {
      uVar15 = 0;
    }
    uVar8 = lVar12 + uVar2;
    if (uVar2 >= uVar11 && uVar2 - uVar11 != 0) {
      uVar8 = uVar5;
    }
    lVar7 = uVar8 - lVar12;
    if (lVar7 != 0) {
      lVar12 = lVar12 * 0x80 + lVar6;
      do {
        <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(lVar12);
        lVar12 = lVar12 + 0x80;
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
    }
    lVar12 = lVar6;
    if (uVar11 < uVar2) {
      do {
        <reach_directory[4b72b9694f6c3c08]::chat::MatchMsg>(lVar12);
        uVar15 = uVar15 - 1;
        lVar12 = lVar12 + 0x80;
      } while (uVar15 != 0);
    }
  }
  if (uVar5 == 0) {
    <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<serde_json[7404bcab4dc139c7]::value::Value>as_core[505b25137b8ba7f]::ops::drop::Drop>
    ::drop(param_1 + 0x47);
    lVar6 = param_1[0x47];
    if (lVar6 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x48],lVar6 << 5,8);
      return;
    }
    if (param_1[0x4b] == 0) {
      if (param_1[0x4e] == 0) {
        return;
      }
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x4f],param_1[0x4e],1);
      return;
    }
    __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[0x4c],param_1[0x4b],1);
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar6,uVar5 << 7,8);
  return;
}

