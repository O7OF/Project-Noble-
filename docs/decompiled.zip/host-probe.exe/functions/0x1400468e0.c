// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<usize>>::retain::<host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}>::{closure#0}
// address: 0x1400468e0
// body: available
// range: 0x1400468e0-0x140046973 inclusive
// range: 0x140046979-0x140046c80 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14004696f to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400469d3 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140046ad1 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<usize>>::retain::<host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}>::{closure#0}
    */

undefined8 __rustcall
<alloc[246c2e7857c81348]::vec::Vec<usize>>::retain::
<host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}>::_closure_0_
          (undefined8 *param_1,undefined8 *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  code *pcVar4;
  ulonglong uVar5;
  undefined *puVar6;
  byte bVar7;
  char cVar8;
  undefined8 uVar9;
  undefined **ppuVar10;
  bool bVar11;
  float fVar12;
  float fVar13;
  undefined8 **local_b8;
  code *pcStack_b0;
  code *local_a8;
  code *local_a0;
  undefined8 *local_90;
  longlong local_88;
  float *local_80;
  ulonglong local_78;
  uint local_6c;
  float local_68;
  float local_64;
  undefined8 local_60;
  
  plVar1 = (longlong *)*param_1;
  puVar2 = (undefined8 *)param_1[1];
  local_6c = local_6c & 0xffffff00;
  pcStack_b0 = (code *)0x0;
  local_a8 = (code *)&DAT_00000004;
  local_b8 = &local_90;
  local_a0 = (code *)&local_6c;
  local_90 = param_2;
  <alloc[246c2e7857c81348]::vec::Vec<f32>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<f32,core[505b25137b8ba7f]::iter::adapters::GenericShunt<core[505b25137b8ba7f]::iter::adapters::map::Map<core[505b25137b8ba7f]::ops::range::Range<usize>,host_probe[b94139f9089eb1d8]::host::armory::write_suit::{closure#1}::{closure#0}>,core[505b25137b8ba7f]::option::Option<core[505b25137b8ba7f]::convert::Infallible>>>>
  ::from_iter(&local_88,&local_b8);
  if (local_6c._0_1_ == (code)0x1) {
    if (local_88 != 0) {
      uVar9 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_80,local_88 << 2,4);
      return uVar9;
    }
LAB_140046a6c:
    local_6c = 0;
  }
  else {
    if (local_88 == -1) goto LAB_140046a6c;
    if (local_78 == 0) {
      ppuVar10 = &PTR_s_src_armory_rs_1406a3cf0;
      uVar9 = 0;
LAB_140046c77:
      core[505b25137b8ba7f]::panicking::panic_bounds_check(uVar9,uVar9,ppuVar10);
      goto LAB_140046c7f;
    }
    if (local_78 == 1) {
      ppuVar10 = &PTR_s_src_armory_rs_1406a3d08;
      uVar9 = 1;
      goto LAB_140046c77;
    }
    if (local_78 < 3) {
      ppuVar10 = &PTR_s_src_armory_rs_1406a3d20;
      uVar9 = 2;
      goto LAB_140046c77;
    }
    if (local_78 == 3) {
      ppuVar10 = &PTR_s_src_armory_rs_1406a3d38;
      uVar9 = 3;
      goto LAB_140046c77;
    }
    local_68 = *local_80;
    local_64 = local_80[1];
    local_60 = *(undefined8 *)(local_80 + 2);
    fVar12 = (float)local_60;
    fVar13 = (float)((ulonglong)local_60 >> 0x20);
    if (local_88 != 0) {
      uVar9 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_80,local_88 << 2,4);
      return uVar9;
    }
    local_6c = 1;
    if ((((local_68 == 0.9960785) && (!NAN(local_68))) && (local_64 == 0.9921569)) &&
       (((!NAN(local_64) && (fVar12 == 0.98823535)) &&
        ((!NAN(fVar12) && ((fVar13 == 1.0 && (!NAN(fVar13))))))))) {
LAB_140046a50:
      uVar9 = puVar2[1];
      *local_90 = *puVar2;
      local_90[1] = uVar9;
      return 1;
    }
    lVar3 = *plVar1;
    if ((local_68 == *(float *)(lVar3 + 4)) && (!NAN(local_68) && !NAN(*(float *)(lVar3 + 4)))) {
      if ((local_64 == *(float *)(lVar3 + 8)) && (!NAN(local_64) && !NAN(*(float *)(lVar3 + 8)))) {
        if ((fVar12 == *(float *)(lVar3 + 0xc)) && (!NAN(fVar12) && !NAN(*(float *)(lVar3 + 0xc))))
        {
          if ((fVar13 == *(float *)(lVar3 + 0x10)) &&
             (!NAN(fVar13) && !NAN(*(float *)(lVar3 + 0x10)))) goto LAB_140046a50;
        }
      }
    }
  }
  pcStack_b0 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
  local_a0 = <core[505b25137b8ba7f]::option::Option<[f32;4usize]>as_core[505b25137b8ba7f]::fmt::Debug>
             ::fmt;
  local_b8 = &local_90;
  local_a8 = (code *)&local_6c;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_88,&DAT_1406a3ee0,&local_b8);
  host_probe[b94139f9089eb1d8]::host::log(local_80,local_78);
  if (local_88 != 0) {
    uVar9 = __rustc[9d087a5ab36ea756]::__rust_dealloc(local_80,local_88,1);
    return uVar9;
  }
  LOCK();
  bVar11 = host_probe[b94139f9089eb1d8]::host::armory::SUIT_DROPPED == '\0';
  if (bVar11) {
    host_probe[b94139f9089eb1d8]::host::armory::SUIT_DROPPED = '\x01';
  }
  UNLOCK();
  if (!bVar11) {
    <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::lock_contended();
  }
  puVar6 = __imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT;
  if ((*(ulonglong *)__imp__RNvNtNtCs59fwaEIuEkC_3std9panicking11panic_count18GLOBAL_PANIC_COUNT &
      0x7fffffffffffffff) == 0) {
    bVar7 = 0;
    lVar3 = DAT_14069bbf0;
    puVar2 = local_90;
  }
  else {
    bVar7 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path();
    bVar7 = bVar7 ^ 1;
    lVar3 = DAT_14069bbf0;
    puVar2 = local_90;
  }
  DAT_14069bbf0 = lVar3;
  local_90 = puVar2;
  if (DAT_14069bbd9 == '\0') {
    if (lVar3 == DAT_14069bbe0) {
      <alloc[246c2e7857c81348]::raw_vec::RawVec<alloc[246c2e7857c81348]::sync::Arc<std[3bf9d48a0c3997f0]::sync::poison::mutex::Mutex<reach_directory[4b72b9694f6c3c08]::rendezvous::State>>>>
      ::grow_one();
    }
    *(undefined8 **)(DAT_14069bbe8 + lVar3 * 8) = puVar2;
    DAT_14069bbf0 = lVar3 + 1;
    if (((bVar7 == 0) && ((*(ulonglong *)puVar6 & 0x7fffffffffffffff) != 0)) &&
       (cVar8 = std[3bf9d48a0c3997f0]::panicking::panic_count::is_zero_slow_path(), cVar8 == '\0'))
    {
      DAT_14069bbd9 = '\x01';
    }
    cVar8 = host_probe[b94139f9089eb1d8]::host::armory::SUIT_DROPPED;
    LOCK();
    host_probe[b94139f9089eb1d8]::host::armory::SUIT_DROPPED = 0;
    UNLOCK();
    if (cVar8 == '\x02') {
      <std[3bf9d48a0c3997f0]::sys::sync::mutex::futex::Mutex>::wake
                (&host_probe[b94139f9089eb1d8]::host::armory::SUIT_DROPPED);
    }
    return 0;
  }
  local_b8 = (undefined8 **)&host_probe[b94139f9089eb1d8]::host::armory::SUIT_DROPPED;
  uVar5 = (ulonglong)pcStack_b0 >> 8;
  pcStack_b0 = (code *)CONCAT71((int7)uVar5,bVar7);
  core[505b25137b8ba7f]::result::unwrap_failed
            ("called `Result::unwrap()` on an `Err` value/rustc/b940084d7eb6a299eb4bfeb8e34901bc051e7ac4/library\\core\\src\\slice\\iter.rs"
             ,0x2b,&local_b8,
             &
             PTR_<std[3bf9d48a0c3997f0]::sync::poison::PoisonError<std[3bf9d48a0c3997f0]::sync::poison::mutex::MutexGuard<alloc[246c2e7857c81348]::vec::Vec<usize>>>>_1406a3f78
             ,&PTR_s_src_armory_rs_1406a3f20);
LAB_140046c7f:
                    /* WARNING: Does not return */
  pcVar4 = (code *)invalidInstructionException();
  (*pcVar4)();
}

