// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u64>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<u64,core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u64,host_probe[b94139f9089eb1d8]::fileshare::Peer<(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>)>>>>>::from_iter
// address: 0x140049c70
// body: available
// range: 0x140049c70-0x140049d99 inclusive
// range: 0x140049da0-0x140049e54 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u64> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<u64,
   core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u64,
   host_probe[b94139f9089eb1d8]::fileshare::Peer<(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,
   core[505b25137b8ba7f]::option::Option<[u8; 16usize]>)>>>>>::from_iter */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<u64>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<u64,core[505b25137b8ba7f]::iter::adapters::copied::Copied<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u64,host_probe[b94139f9089eb1d8]::fileshare::Peer<(core[505b25137b8ba7f]::net::socket_addr::SocketAddr,core[505b25137b8ba7f]::option::Option<[u8;16usize]>)>>>>>
::from_iter(ulonglong *param_1,longlong *param_2)

{
  ulonglong uVar1;
  undefined1 auVar2 [16];
  ulonglong uVar3;
  undefined8 uVar4;
  code *pcVar5;
  uint uVar6;
  undefined8 *puVar7;
  ushort uVar8;
  uint uVar9;
  longlong lVar10;
  undefined1 (*pauVar11) [16];
  uint uVar12;
  ulonglong uVar13;
  undefined8 uVar14;
  longlong lVar15;
  ulonglong local_60;
  undefined8 *local_58;
  ulonglong local_50;
  longlong *local_48;
  
  uVar3 = param_2[4];
  if (uVar3 == 0) {
    *param_1 = 0;
    param_1[1] = 8;
    param_1[2] = 0;
    return param_1;
  }
  uVar8 = *(ushort *)(param_2 + 3);
  lVar15 = *param_2;
  if (uVar8 == 0) {
    pauVar11 = (undefined1 (*) [16])param_2[1];
    do {
      auVar2 = *pauVar11;
      lVar15 = lVar15 + -0x700;
      pauVar11 = pauVar11 + 1;
      uVar8 = ((ushort)(SUB161(auVar2 >> 7,0) & 1) | (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
               (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
               (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
               (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
               (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
               (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
               (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
               (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
               (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
               (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
               (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
               (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
               (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
               (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
              (ushort)(byte)(auVar2[0xf] >> 7) << 0xf) ^ 0xffff;
    } while (uVar8 == 0);
    param_2[1] = (longlong)pauVar11;
    *param_2 = lVar15;
  }
  uVar9 = (uint)uVar8;
  uVar12 = uVar8 - 1 & uVar9;
  *(short *)(param_2 + 3) = (short)uVar12;
  lVar10 = uVar3 - 1;
  param_2[4] = lVar10;
  uVar13 = 4;
  if (4 < uVar3) {
    uVar13 = uVar3;
  }
  uVar1 = uVar13 * 8;
  if (uVar1 < 0x7ffffffffffffff9 && uVar3 >> 0x3d == 0) {
    uVar6 = 0;
    for (; (uVar9 & 1) == 0; uVar9 = uVar9 >> 1 | 0x80000000) {
      uVar6 = uVar6 + 1;
    }
    uVar4 = *(undefined8 *)(lVar15 + -0x70 + (ulonglong)uVar6 * -0x70);
    local_48 = param_2;
    __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
    uVar14 = 8;
    puVar7 = (undefined8 *)__rustc[9d087a5ab36ea756]::__rust_alloc(uVar1,8);
    if (puVar7 != (undefined8 *)0x0) {
      *puVar7 = uVar4;
      local_50 = 1;
      local_60 = uVar13;
      local_58 = puVar7;
      if (lVar10 != 0) {
        pauVar11 = (undefined1 (*) [16])local_48[1];
        do {
          uVar3 = local_50;
          uVar8 = (ushort)uVar12;
          while (uVar8 == 0) {
            auVar2 = *pauVar11;
            lVar15 = lVar15 + -0x700;
            pauVar11 = pauVar11 + 1;
            uVar8 = ((ushort)(SUB161(auVar2 >> 7,0) & 1) |
                     (ushort)(SUB161(auVar2 >> 0xf,0) & 1) << 1 |
                     (ushort)(SUB161(auVar2 >> 0x17,0) & 1) << 2 |
                     (ushort)(SUB161(auVar2 >> 0x1f,0) & 1) << 3 |
                     (ushort)(SUB161(auVar2 >> 0x27,0) & 1) << 4 |
                     (ushort)(SUB161(auVar2 >> 0x2f,0) & 1) << 5 |
                     (ushort)(SUB161(auVar2 >> 0x37,0) & 1) << 6 |
                     (ushort)(SUB161(auVar2 >> 0x3f,0) & 1) << 7 |
                     (ushort)(SUB161(auVar2 >> 0x47,0) & 1) << 8 |
                     (ushort)(SUB161(auVar2 >> 0x4f,0) & 1) << 9 |
                     (ushort)(SUB161(auVar2 >> 0x57,0) & 1) << 10 |
                     (ushort)(SUB161(auVar2 >> 0x5f,0) & 1) << 0xb |
                     (ushort)(SUB161(auVar2 >> 0x67,0) & 1) << 0xc |
                     (ushort)(SUB161(auVar2 >> 0x6f,0) & 1) << 0xd |
                     (ushort)(SUB161(auVar2 >> 0x77,0) & 1) << 0xe |
                    (ushort)(byte)(auVar2[0xf] >> 7) << 0xf) ^ 0xffff;
            uVar12 = (uint)uVar8;
          }
          uVar9 = 0;
          for (uVar6 = uVar12; (uVar6 & 1) == 0; uVar6 = uVar6 >> 1 | 0x80000000) {
            uVar9 = uVar9 + 1;
          }
          uVar4 = *(undefined8 *)(lVar15 + -0x70 + (ulonglong)uVar9 * -0x70);
          if (local_50 == local_60) {
            <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
            <alloc[246c2e7857c81348]::alloc::Global>(&local_60,local_50,lVar10,8,8);
            puVar7 = local_58;
          }
          uVar12 = uVar12 - 1 & uVar12;
          lVar10 = lVar10 + -1;
          puVar7[uVar3] = uVar4;
          local_50 = uVar3 + 1;
        } while (lVar10 != 0);
      }
      param_1[2] = local_50;
      *param_1 = local_60;
      param_1[1] = (ulonglong)local_58;
      return param_1;
    }
  }
  else {
    uVar14 = 0;
  }
  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar14,uVar1);
                    /* WARNING: Does not return */
  pcVar5 = (code *)invalidInstructionException();
  (*pcVar5)();
}

