// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>
// address: 0x140045e60
// body: available
// range: 0x140045e60-0x140045f5b inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140045eef to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::<serde_json[7404bcab4dc139c7]::value::Value>(byte *param_1)

{
  byte bVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  ulonglong local_70 [3];
  undefined8 local_58;
  ulonglong local_50;
  undefined8 local_48;
  longlong local_40;
  undefined8 local_38;
  undefined8 local_30;
  
  bVar1 = *param_1;
  if (2 < bVar1) {
    if (bVar1 == 3) {
      lVar3 = *(longlong *)(param_1 + 8);
      if (lVar3 != 0) {
        lVar2 = *(longlong *)(param_1 + 0x10);
        uVar4 = 1;
LAB_140045ee4:
        __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar2,lVar3,uVar4);
        return;
      }
    }
    else if (bVar1 == 4) {
      lVar2 = *(longlong *)(param_1 + 0x10);
      if (*(longlong *)(param_1 + 0x18) != 0) {
        lVar5 = 1 - *(longlong *)(param_1 + 0x18);
        lVar3 = lVar2;
        do {
          <serde_json[7404bcab4dc139c7]::value::Value>(lVar3);
          lVar3 = lVar3 + 0x20;
          lVar5 = lVar5 + 1;
        } while (lVar5 != 1);
      }
      if (*(longlong *)(param_1 + 8) != 0) {
        lVar3 = *(longlong *)(param_1 + 8) << 5;
        uVar4 = 8;
        goto LAB_140045ee4;
      }
    }
    else {
      lVar3 = *(longlong *)(param_1 + 8);
      if (lVar3 == 0) {
        local_30 = 0;
      }
      else {
        local_58 = *(undefined8 *)(param_1 + 0x10);
        local_30 = *(undefined8 *)(param_1 + 0x18);
        local_70[1] = 0;
        local_48 = 0;
        local_70[2] = lVar3;
        local_40 = lVar3;
        local_38 = local_58;
      }
      local_70[0] = (ulonglong)(lVar3 != 0);
      local_50 = local_70[0];
      <alloc[246c2e7857c81348]::collections::btree::map::IntoIter<alloc[246c2e7857c81348]::string::String,serde_json[7404bcab4dc139c7]::value::Value>>
                (local_70);
    }
  }
  return;
}

