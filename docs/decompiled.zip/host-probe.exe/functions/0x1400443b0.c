// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::<core[505b25137b8ba7f]::str::iter::Bytes>
// address: 0x1400443b0
// body: available
// range: 0x1400443b0-0x140044566 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::<core[505b25137b8ba7f]::str::iter::Bytes>
    */

void __rustcall
<alloc[246c2e7857c81348]::vec::Vec<u8>>::extend_trusted::<core[505b25137b8ba7f]::str::iter::Bytes>
          (longlong *param_1,undefined1 *param_2,undefined1 *param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined8 uVar6;
  uint uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  undefined1 *puVar10;
  longlong lVar11;
  undefined1 *puVar12;
  undefined1 *puVar13;
  ulonglong uVar14;
  
  uVar9 = (longlong)param_3 - (longlong)param_2;
  lVar2 = param_1[2];
  if ((ulonglong)(*param_1 - lVar2) < uVar9) {
    <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
    <alloc[246c2e7857c81348]::alloc::Global>(param_1,lVar2,uVar9,1,1);
    lVar2 = param_1[2];
  }
  lVar11 = lVar2;
  if (param_2 == param_3) goto LAB_140044483;
  lVar3 = param_1[1];
  puVar10 = param_2;
  if ((7 < uVar9) && ((ulonglong)((longlong)param_2 - (lVar2 + lVar3)) < 0xffffffffffffffe1)) {
    if (uVar9 < 0x20) {
      uVar8 = 0;
    }
    else {
      uVar8 = uVar9 & 0xffffffffffffffe0;
      lVar11 = lVar2 + uVar8;
      uVar14 = 0;
      do {
        uVar4 = *(undefined8 *)((longlong)(param_2 + uVar14) + 8);
        uVar5 = *(undefined8 *)(param_2 + uVar14 + 0x10);
        uVar6 = *(undefined8 *)((longlong)(param_2 + uVar14 + 0x10) + 8);
        puVar1 = (undefined8 *)(lVar2 + lVar3 + uVar14);
        *puVar1 = *(undefined8 *)(param_2 + uVar14);
        puVar1[1] = uVar4;
        puVar1 = (undefined8 *)(lVar2 + lVar3 + 0x10 + uVar14);
        *puVar1 = uVar5;
        puVar1[1] = uVar6;
        uVar14 = uVar14 + 0x20;
      } while (uVar8 != uVar14);
      if (uVar9 == uVar8) goto LAB_140044483;
      puVar10 = param_2 + uVar8;
      if ((uVar9 & 0x18) == 0) goto LAB_140044404;
    }
    uVar14 = uVar9 & 0xfffffffffffffff8;
    lVar11 = lVar2 + uVar14;
    do {
      *(undefined8 *)(lVar2 + lVar3 + uVar8) = *(undefined8 *)(param_2 + uVar8);
      uVar8 = uVar8 + 8;
    } while (uVar14 != uVar8);
    puVar10 = param_2 + uVar14;
    if (uVar9 == uVar14) goto LAB_140044483;
  }
LAB_140044404:
  uVar7 = (int)param_3 - (int)puVar10 & 3;
  uVar9 = (ulonglong)uVar7;
  puVar13 = puVar10;
  puVar12 = puVar10;
  if (uVar7 != 0) {
    do {
      puVar13 = puVar12 + 1;
      *(undefined1 *)(lVar3 + lVar11) = *puVar12;
      lVar11 = lVar11 + 1;
      uVar9 = uVar9 - 1;
      puVar12 = puVar13;
    } while (uVar9 != 0);
  }
  if ((ulonglong)((longlong)puVar10 - (longlong)param_3) < 0xfffffffffffffffd) {
    do {
      *(undefined1 *)(lVar3 + lVar11) = *puVar13;
      *(undefined1 *)(lVar3 + 1 + lVar11) = puVar13[1];
      *(undefined1 *)(lVar3 + 2 + lVar11) = puVar13[2];
      *(undefined1 *)(lVar3 + 3 + lVar11) = puVar13[3];
      lVar11 = lVar11 + 4;
      puVar13 = puVar13 + 4;
    } while (puVar13 != param_3);
  }
LAB_140044483:
  param_1[2] = lVar11;
  return;
}

