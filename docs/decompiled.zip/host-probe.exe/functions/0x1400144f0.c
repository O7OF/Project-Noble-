// rea decompile_all
// name: <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>::wrap_copy
// address: 0x1400144f0
// body: available
// range: 0x1400144f0-0x140014747 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x140014743 to 0x1406968d8 memmove (external=false, thunk=true, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>::wrap_copy
    */

void __rustcall
<alloc[246c2e7857c81348]::collections::vec_deque::VecDeque<host_probe[b94139f9089eb1d8]::fileshare::Part>>
::wrap_copy(ulonglong param_1,void *param_2,longlong param_3,longlong param_4,ulonglong param_5)

{
  void *_Dst;
  ulonglong uVar1;
  void *pvVar2;
  void *pvVar3;
  size_t sVar4;
  ulonglong uVar5;
  longlong lVar6;
  ulonglong uVar7;
  
  uVar5 = param_4 - param_3;
  if ((uVar5 == 0) || (param_5 == 0)) {
    return;
  }
  uVar1 = uVar5 + param_1;
  if (!CARRY8(uVar5,param_1)) {
    uVar1 = uVar5;
  }
  uVar7 = param_1 - param_3;
  uVar5 = param_1 - param_4;
  lVar6 = param_5 - uVar7;
  pvVar2 = param_2;
  if (param_5 < uVar7 || lVar6 == 0) {
    lVar6 = param_5 - uVar5;
    if (param_5 < uVar5 || lVar6 == 0) {
      pvVar3 = (void *)((longlong)param_2 + param_3 * 0x48);
      pvVar2 = (void *)((longlong)param_2 + param_4 * 0x48);
      sVar4 = param_5 * 0x48;
      goto LAB_140014734;
    }
    if (uVar1 < param_5) {
      pvVar3 = (void *)((longlong)param_2 + param_3 * 0x48);
      sVar4 = uVar5 * 0x48;
      memmove(param_2,(void *)((longlong)pvVar3 + sVar4),lVar6 * 0x48);
      pvVar2 = (void *)((longlong)param_2 + param_4 * 0x48);
      goto LAB_140014734;
    }
    pvVar3 = (void *)((longlong)param_2 + param_3 * 0x48);
    memmove((void *)((longlong)param_2 + param_4 * 0x48),pvVar3,uVar5 * 0x48);
    pvVar3 = (void *)((longlong)pvVar3 + uVar5 * 0x48);
  }
  else {
    if (uVar1 < param_5) {
      if (uVar5 < param_5) {
        sVar4 = (uVar7 - uVar5) * 0x48;
        memmove((void *)((longlong)param_2 + sVar4),param_2,lVar6 * 0x48);
        memmove(param_2,(void *)((longlong)param_2 + (param_1 - (uVar7 - uVar5)) * 0x48),sVar4);
        pvVar3 = (void *)((longlong)param_2 + param_3 * 0x48);
        sVar4 = uVar5 * 0x48;
        pvVar2 = (void *)((longlong)param_2 + param_4 * 0x48);
      }
      else {
        pvVar2 = (void *)((longlong)param_2 + param_4 * 0x48);
        sVar4 = uVar7 * 0x48;
        memmove((void *)((longlong)pvVar2 + sVar4),param_2,lVar6 * 0x48);
        pvVar3 = (void *)((longlong)param_2 + param_3 * 0x48);
      }
      goto LAB_140014734;
    }
    pvVar3 = (void *)((longlong)param_2 + param_3 * 0x48);
    _Dst = (void *)((longlong)param_2 + param_4 * 0x48);
    if (uVar5 <= param_5 && param_5 - uVar5 != 0) {
      memmove(_Dst,pvVar3,uVar7 * 0x48);
      sVar4 = (uVar5 - uVar7) * 0x48;
      memmove((void *)((longlong)_Dst + uVar7 * 0x48),param_2,sVar4);
      pvVar3 = (void *)(sVar4 + (longlong)param_2);
      sVar4 = (param_5 - uVar5) * 0x48;
      goto LAB_140014734;
    }
    memmove(_Dst,pvVar3,uVar7 * 0x48);
    pvVar2 = (void *)((longlong)_Dst + uVar7 * 0x48);
    pvVar3 = param_2;
  }
  sVar4 = lVar6 * 0x48;
LAB_140014734:
  memmove(pvVar2,pvVar3,sVar4);
  return;
}

