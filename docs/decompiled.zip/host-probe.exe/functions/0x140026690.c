// rea decompile_all
// name: host_probe[b94139f9089eb1d8]::net::patch_launch_block
// address: 0x140026690
// body: available
// range: 0x140026690-0x1400266cb inclusive
// range: 0x1400266d0-0x1400267bc inclusive
// range: 0x1400267c0-0x14002684f inclusive
// range: 0x140026856-0x140026873 inclusive
// range: 0x140026880-0x140026a33 inclusive
// range: 0x140026a40-0x140026ac7 inclusive
// range: 0x140026ad0-0x140026c2c inclusive
// range: 0x140026c2e-0x140026df8 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x14002684b to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140026b40 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140026c28 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* host_probe[b94139f9089eb1d8]::net::patch_launch_block */

void __rustcall
host_probe[b94139f9089eb1d8]::net::patch_launch_block
          (byte *param_1,ulonglong param_2,longlong param_3,ulonglong param_4)

{
  byte bVar1;
  longlong *plVar2;
  code *pcVar3;
  longlong lVar4;
  char *pcVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  longlong lVar8;
  char cVar9;
  ulonglong uVar10;
  undefined **ppuVar11;
  longlong lVar12;
  ulonglong uVar13;
  uint uVar14;
  ulonglong uVar15;
  undefined **local_a8;
  undefined8 *local_a0;
  undefined ***local_98;
  code *local_90;
  undefined8 *local_88;
  code *local_80;
  undefined **local_78;
  undefined8 local_70;
  longlong local_68;
  undefined8 local_60;
  undefined8 local_58;
  undefined *local_50;
  undefined8 local_48;
  
  if (param_4 == 0) {
    return;
  }
  lVar4 = param_4 * 0x18;
  lVar12 = 0;
  do {
    if ((*(longlong *)(param_3 + 0x10 + lVar12) == 10) &&
       (plVar2 = *(longlong **)(param_3 + 8 + lVar12),
       (short)plVar2[1] == 0x7473 && *plVar2 == 0x6575672d73612d2d)) {
      if (param_2 == 0) {
        core[505b25137b8ba7f]::panicking::panic_bounds_check
                  (0,0,&
                       PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a24a8
                  );
                    /* WARNING: Does not return */
        pcVar3 = (code *)invalidInstructionException();
        (*pcVar3)();
      }
      *param_1 = *param_1 & 0xf7;
      if (param_2 < 0x68) {
        ppuVar11 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a24c0;
        goto LAB_140026d32;
      }
      param_1[0x60] = 0;
      param_1[0x61] = 0;
      param_1[0x62] = 0;
      param_1[99] = 0;
      param_1[100] = 0;
      param_1[0x65] = 0;
      param_1[0x66] = 0;
      param_1[0x67] = 0;
      if (param_2 < 0x110) {
        core[505b25137b8ba7f]::slice::index::slice_index_fail
                  (0xe8,0x110,param_2,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a24d8)
        ;
                    /* WARNING: Does not return */
        pcVar3 = (code *)invalidInstructionException();
        (*pcVar3)();
      }
      param_1[0xf8] = 0;
      param_1[0xf9] = 0;
      param_1[0xfa] = 0;
      param_1[0xfb] = 0;
      param_1[0xfc] = 0;
      param_1[0xfd] = 0;
      param_1[0xfe] = 0;
      param_1[0xff] = 0;
      param_1[0x100] = 0;
      param_1[0x101] = 0;
      param_1[0x102] = 0;
      param_1[0x103] = 0;
      param_1[0x104] = 0;
      param_1[0x105] = 0;
      param_1[0x106] = 0;
      param_1[0x107] = 0;
      param_1[0xe8] = 0;
      param_1[0xe9] = 0;
      param_1[0xea] = 0;
      param_1[0xeb] = 0;
      param_1[0xec] = 0;
      param_1[0xed] = 0;
      param_1[0xee] = 0;
      param_1[0xef] = 0;
      param_1[0xf0] = 0;
      param_1[0xf1] = 0;
      param_1[0xf2] = 0;
      param_1[0xf3] = 0;
      param_1[0xf4] = 0;
      param_1[0xf5] = 0;
      param_1[0xf6] = 0;
      param_1[0xf7] = 0;
      param_1[0x100] = 0xff;
      param_1[0x101] = 0xff;
      param_1[0x102] = 0xff;
      param_1[0x103] = 0xff;
      param_1[0x108] = 0xff;
      param_1[0x109] = 0xff;
      param_1[0x10a] = 0xff;
      param_1[0x10b] = 0xff;
      param_1[0x10c] = 0xff;
      param_1[0x10d] = 0xff;
      param_1[0x10e] = 0xff;
      param_1[0x10f] = 0xff;
      if (param_2 < 0x300) {
        ppuVar11 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a24f0;
        uVar6 = 0x2f0;
        goto LAB_140026d6d;
      }
      param_1[0x2f0] = 0;
      param_1[0x2f1] = 0;
      param_1[0x2f2] = 0;
      param_1[0x2f3] = 0;
      param_1[0x2f4] = 0;
      param_1[0x2f5] = 0;
      param_1[0x2f6] = 0;
      param_1[0x2f7] = 0;
      param_1[0x2f8] = 0;
      param_1[0x2f9] = 0;
      param_1[0x2fa] = 0;
      param_1[0x2fb] = 0;
      param_1[0x2fc] = 0;
      param_1[0x2fd] = 0;
      param_1[0x2fe] = 0;
      param_1[0x2ff] = 0;
      param_1[0x2f4] = 0xff;
      param_1[0x2f5] = 0xff;
      param_1[0x2f6] = 0xff;
      param_1[0x2f7] = 0xff;
      memset(param_1 + 0x300,0,param_2 - 0x300);
      if (param_2 < 0x2bf16) {
        core[505b25137b8ba7f]::slice::index::slice_index_fail
                  (0x2bf14,0x2bf16,param_2,
                   &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a2508)
        ;
                    /* WARNING: Does not return */
        pcVar3 = (code *)invalidInstructionException();
        (*pcVar3)();
      }
      param_1[0x2bf14] = 0xf3;
      param_1[0x2bf15] = 1;
      IS_GUEST_0_llvm_14435704873730135342 = 1;
      break;
    }
    lVar12 = lVar12 + 0x18;
  } while (lVar4 != lVar12);
  lVar8 = 0;
  lVar12 = 0;
  while ((*(longlong *)(param_3 + 0x10 + lVar12) != 10 ||
         (plVar2 = *(longlong **)(param_3 + 8 + lVar12),
         (short)plVar2[1] != 0x666c || *plVar2 != 0x65732d74656e2d2d))) {
    lVar8 = lVar8 + 1;
    lVar12 = lVar12 + 0x18;
    if (lVar4 == lVar12) {
      return;
    }
  }
  if (param_4 <= lVar8 + 1U) {
    return;
  }
  parse_endpoint(&local_a8,*(undefined8 *)(param_3 + 0x20 + lVar12),
                 *(undefined8 *)(param_3 + 0x28 + lVar12));
  ppuVar11 = local_a8;
  if (local_a0 == (undefined8 *)0xffffffffffffffff) {
    return;
  }
  local_78 = local_a8;
  if (local_a0 != (undefined8 *)0x0) {
    __rustc[9d087a5ab36ea756]::__rust_dealloc(local_98,local_a0,1);
    return;
  }
  if (param_2 < 0x60) {
    core[505b25137b8ba7f]::slice::index::slice_index_fail
              (0x58,0x60,param_2,
               &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0770);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  *(undefined ***)(param_1 + 0x58) = local_a8;
  lVar8 = 0;
  lVar12 = 0;
  do {
    if ((*(longlong *)(param_3 + 0x10 + lVar12) == 0xd) &&
       (plVar2 = *(longlong **)(param_3 + 8 + lVar12),
       *(longlong *)((longlong)plVar2 + 5) == 0x6e6f69737365732d && *plVar2 == 0x65732d74656e2d2d))
    {
      if (param_4 <= lVar8 + 1U) break;
      uVar7 = *(ulonglong *)(param_3 + 0x28 + lVar12);
      pcVar5 = (char *)::<str>::trim_start_matches::<&str>
                                 (*(undefined8 *)(param_3 + 0x20 + lVar12),uVar7,
                                  &
                                  anon_d5c34e88a06ee720b116585eb143da4b_38_llvm_14435704873730135342
                                  ,2);
      if (uVar7 == 0) break;
      if (uVar7 == 1) {
        cVar9 = *pcVar5;
        if ((cVar9 == '+') || (cVar9 == '-')) break;
      }
      else {
        cVar9 = *pcVar5;
      }
      uVar13 = (ulonglong)(cVar9 == '+');
      if (0x10 < uVar7 - uVar13) {
        uVar10 = 0;
        lVar12 = 0;
        goto LAB_140026994;
      }
      if (uVar7 != uVar13) {
        uVar10 = 0;
        lVar12 = 0;
        goto LAB_14002693f;
      }
      uVar10 = 0;
      goto LAB_1400269ea;
    }
    lVar8 = lVar8 + 1;
    lVar12 = lVar12 + 0x18;
  } while (lVar4 != lVar12);
  goto LAB_1400269ee;
  while( true ) {
    uVar15 = uVar10 * 0x10;
    bVar1 = pcVar5[lVar12 + uVar13];
    uVar14 = bVar1 - 0x30;
    if (0x39 < bVar1) {
      uVar14 = (bVar1 - 0x41 & 0xffffffdf) + 10;
    }
    uVar10 = uVar14 + uVar15;
    if (CARRY8((ulonglong)uVar14,uVar15) || 0xf < uVar14) goto LAB_1400269ee;
    lVar12 = lVar12 + 1;
    if (lVar12 == uVar7 + -uVar13) break;
LAB_140026994:
    if (0xfffffffffffffff < uVar10) goto LAB_1400269ee;
  }
  goto LAB_1400269ea;
  while( true ) {
    uVar10 = (ulonglong)uVar14 | uVar10 << 4;
    lVar12 = lVar12 + 1;
    if (lVar12 == uVar7 + -uVar13) break;
LAB_14002693f:
    bVar1 = pcVar5[lVar12 + uVar13];
    uVar14 = bVar1 - 0x30;
    if (0x39 < bVar1) {
      uVar14 = (bVar1 - 0x41 & 0xffffffdf) + 10;
    }
    if (0xf < uVar14) goto LAB_1400269ee;
  }
LAB_1400269ea:
  *(ulonglong *)(param_1 + 0x50) = uVar10;
LAB_1400269ee:
  IS_HOST_0_llvm_14435704873730135342 = (*param_1 & 8) >> 3;
  IS_GUEST_0_llvm_14435704873730135342 = IS_HOST_0_llvm_14435704873730135342 ^ 1;
  HOST_ID_0_llvm_14435704873730135342 = (undefined **)0x0;
  if ((*param_1 & 8) != 0) {
    if (param_2 < 0x68) {
      ppuVar11 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0770;
LAB_140026d32:
      core[505b25137b8ba7f]::slice::index::slice_index_fail(0x60,0x68,param_2,ppuVar11);
                    /* WARNING: Does not return */
      pcVar3 = (code *)invalidInstructionException();
      (*pcVar3)();
    }
    *(undefined ***)(param_1 + 0x60) = ppuVar11;
    if (param_2 < 0x100) {
      core[505b25137b8ba7f]::slice::index::slice_index_fail
                (0xf8,0x100,param_2,
                 &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0770);
                    /* WARNING: Does not return */
      pcVar3 = (code *)invalidInstructionException();
      (*pcVar3)();
    }
    *(undefined ***)(param_1 + 0xf8) = ppuVar11;
    local_48 = 4;
    local_50 = &DAT_1406a0cbe;
    goto LAB_140026b9c;
  }
  lVar8 = 0;
  lVar12 = 0;
  do {
    if ((*(longlong *)(param_3 + 0x10 + lVar12) == 0xd) &&
       (plVar2 = *(longlong **)(param_3 + 8 + lVar12),
       *(longlong *)((longlong)plVar2 + 5) == 0x64692d74736f682d && *plVar2 == 0x6f682d74656e2d2d))
    {
      if (param_4 <= lVar8 + 1U) break;
      uVar7 = *(ulonglong *)(param_3 + 0x28 + lVar12);
      pcVar5 = (char *)::<str>::trim_start_matches::<&str>
                                 (*(undefined8 *)(param_3 + 0x20 + lVar12),uVar7,
                                  &
                                  anon_d5c34e88a06ee720b116585eb143da4b_38_llvm_14435704873730135342
                                  ,2);
      if (uVar7 == 0) break;
      if (uVar7 == 1) {
        cVar9 = *pcVar5;
        if ((cVar9 == '+') || (cVar9 == '-')) break;
      }
      else {
        cVar9 = *pcVar5;
      }
      uVar13 = (ulonglong)(cVar9 == '+');
      if (0x10 < uVar7 - uVar13) {
        ppuVar11 = (undefined **)0x0;
        lVar12 = 0;
        goto LAB_140026cd0;
      }
      if (uVar7 != uVar13) {
        ppuVar11 = (undefined **)0x0;
        lVar12 = 0;
        goto LAB_140026c78;
      }
      ppuVar11 = (undefined **)0x0;
      goto LAB_140026b45;
    }
    lVar8 = lVar8 + 1;
    lVar12 = lVar12 + 0x18;
  } while (lVar4 != lVar12);
LAB_140026ab8:
  lVar8 = 0;
  lVar12 = 0;
  do {
    if ((*(longlong *)(param_3 + 0x10 + lVar12) == 10) &&
       (plVar2 = *(longlong **)(param_3 + 8 + lVar12),
       (short)plVar2[1] == 0x7265 && *plVar2 == 0x65702d74656e2d2d)) {
      if ((lVar8 + 1U < param_4) &&
         (parse_endpoint(&local_a8,*(undefined8 *)(param_3 + 0x20 + lVar12),
                         *(undefined8 *)(param_3 + 0x28 + lVar12)),
         local_a0 != (undefined8 *)0xffffffffffffffff)) {
        ppuVar11 = local_a8;
        if (local_a0 != (undefined8 *)0x0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(local_98,local_a0,1);
          return;
        }
        goto LAB_140026b45;
      }
      break;
    }
    lVar8 = lVar8 + 1;
    lVar12 = lVar12 + 0x18;
  } while (lVar4 != lVar12);
  goto LAB_140026b60;
  while( true ) {
    uVar10 = (longlong)ppuVar11 * 0x10;
    bVar1 = pcVar5[lVar12 + uVar13];
    uVar14 = bVar1 - 0x30;
    if (0x39 < bVar1) {
      uVar14 = (bVar1 - 0x41 & 0xffffffdf) + 10;
    }
    ppuVar11 = (undefined **)(uVar14 + uVar10);
    if (CARRY8((ulonglong)uVar14,uVar10) || 0xf < uVar14) goto LAB_140026ab8;
    lVar12 = lVar12 + 1;
    if (lVar12 == uVar7 + -uVar13) break;
LAB_140026cd0:
    if ((undefined **)0xfffffffffffffff < ppuVar11) goto LAB_140026ab8;
  }
  goto LAB_140026b45;
  while( true ) {
    ppuVar11 = (undefined **)((ulonglong)uVar14 | (longlong)ppuVar11 << 4);
    lVar12 = lVar12 + 1;
    if (lVar12 == uVar7 + -uVar13) break;
LAB_140026c78:
    bVar1 = pcVar5[lVar12 + uVar13];
    uVar14 = bVar1 - 0x30;
    if (0x39 < bVar1) {
      uVar14 = (bVar1 - 0x41 & 0xffffffdf) + 10;
    }
    if (0xf < uVar14) goto LAB_140026ab8;
  }
LAB_140026b45:
  if (param_2 < 0x300) {
    ppuVar11 = &PTR_anon_d5c34e88a06ee720b116585eb143da4b_1_llvm_14435704873730135342_1406a0770;
    uVar6 = 0x2f8;
LAB_140026d6d:
    core[505b25137b8ba7f]::slice::index::slice_index_fail(uVar6,0x300,param_2,ppuVar11);
                    /* WARNING: Does not return */
    pcVar3 = (code *)invalidInstructionException();
    (*pcVar3)();
  }
  *(undefined ***)(param_1 + 0x2f8) = ppuVar11;
  HOST_ID_0_llvm_14435704873730135342 = ppuVar11;
LAB_140026b60:
  local_48 = 5;
  local_50 = &DAT_1406a0cb9;
LAB_140026b9c:
  local_70 = *(undefined8 *)(param_1 + 0x50);
  local_a8 = &local_50;
  local_a0 = &<&str_as_core[505b25137b8ba7f]::fmt::Display>::fmt;
  local_98 = &local_78;
  local_90 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
  local_88 = &local_70;
  local_80 = <usize_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
  alloc[246c2e7857c81348]::fmt::format::format_inner(&local_68,&DAT_1406a260e,&local_a8);
  host::log(local_60,local_58);
  if (local_68 == 0) {
    return;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(local_60,local_68,1);
  return;
}

