// rea decompile_all
// name: core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::result::Result<reach_directory[4b72b9694f6c3c08]::server_admin::playlist::Playlist,alloc[246c2e7857c81348]::string::String>>
// address: 0x1400446d0
// body: available
// range: 0x1400446d0-0x14004477d inclusive
// range: 0x140044780-0x1400447b1 inclusive
// range: 0x1400447c0-0x1400447df inclusive
// range: 0x1400447e2-0x140044828 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Ghidra Listing reports a terminal call at 0x1400446f8 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140044710 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140044728 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004475c to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x140044779 to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004479a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x1400447db to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Ghidra Listing reports a terminal call at 0x14004481a to 0x1402cb1f0 __rustc[9d087a5ab36ea756]::__rust_dealloc (external=false, thunk=false, hasNoReturn=false); fallthrough is excluded by Ghidra's flow model. The reason for the terminal flow is not established by this observation.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* core[505b25137b8ba7f]::ptr::drop_glue::<core[505b25137b8ba7f]::result::Result<reach_directory[4b72b9694f6c3c08]::server_admin::playlist::Playlist,
   alloc[246c2e7857c81348]::string::String>> */

void __rustcall
core[505b25137b8ba7f]::ptr::drop_glue::
<core[505b25137b8ba7f]::result::Result<reach_directory[4b72b9694f6c3c08]::server_admin::playlist::Playlist,alloc[246c2e7857c81348]::string::String>>
          (longlong *param_1)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  
  lVar2 = *param_1;
  if (lVar2 == -1) {
    lVar2 = param_1[1];
    if (lVar2 == 0) {
      return;
    }
    lVar1 = param_1[2];
    uVar3 = 1;
  }
  else {
    if (lVar2 != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[1],lVar2,1);
      return;
    }
    if (param_1[3] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[4],param_1[3],1);
      return;
    }
    if (param_1[6] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[7],param_1[6],1);
      return;
    }
    lVar2 = param_1[0xb];
    if (lVar2 != 0) {
      puVar4 = (undefined8 *)(param_1[10] + 0x30);
      do {
        if (puVar4[-4] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(puVar4[-3],puVar4[-4],1);
          return;
        }
        lVar1 = puVar4[-1];
        if ((lVar1 != -1) && (lVar1 != 0)) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar4,lVar1,1);
          return;
        }
        puVar4 = puVar4 + 9;
        lVar2 = lVar2 + -1;
      } while (lVar2 != 0);
    }
    if (param_1[9] != 0) {
      __rustc[9d087a5ab36ea756]::__rust_dealloc(param_1[10],param_1[9] * 0x48,8);
      return;
    }
    lVar1 = param_1[0xd];
    lVar2 = param_1[0xe];
    if (lVar2 != 0) {
      puVar4 = (undefined8 *)(lVar1 + 8);
      do {
        if (puVar4[-1] != 0) {
          __rustc[9d087a5ab36ea756]::__rust_dealloc(*puVar4,puVar4[-1],1);
          return;
        }
        puVar4 = puVar4 + 3;
        lVar2 = lVar2 + -1;
      } while (lVar2 != 0);
    }
    if (param_1[0xc] == 0) {
      return;
    }
    lVar2 = param_1[0xc] * 0x18;
    uVar3 = 8;
  }
  __rustc[9d087a5ab36ea756]::__rust_dealloc(lVar1,lVar2,uVar3);
  return;
}

