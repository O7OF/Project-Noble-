// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<(u8,serde_json[7404bcab4dc139c7]::value::Value)>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(u8,serde_json[7404bcab4dc139c7]::value::Value),core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::collections::btree::map::IterMut<u8,alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<(u8,u32),f64>>,host_probe[b94139f9089eb1d8]::results::on_game_results::{closure#1}>>>::from_iter
// address: 0x1400493b0
// body: available
// range: 0x1400493b0-0x140049508 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<(u8, serde_json[7404bcab4dc139c7]::value::Value)> as
   alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(u8,
   serde_json[7404bcab4dc139c7]::value::Value),
   core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::collections::btree::map::IterMut<u8,
   alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<(u8, u32), f64>>,
   host_probe[b94139f9089eb1d8]::results::on_game_results::{closure#1}>>>::from_iter */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<(u8,serde_json[7404bcab4dc139c7]::value::Value)>as_alloc[246c2e7857c81348]::vec::spec_from_iter::SpecFromIter<(u8,serde_json[7404bcab4dc139c7]::value::Value),core[505b25137b8ba7f]::iter::adapters::map::Map<alloc[246c2e7857c81348]::collections::btree::map::IterMut<u8,alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<(u8,u32),f64>>,host_probe[b94139f9089eb1d8]::results::on_game_results::{closure#1}>>>
::from_iter(ulonglong *param_1,undefined4 *param_2)

{
  undefined1 uVar1;
  code *pcVar2;
  longlong lVar3;
  undefined1 *puVar4;
  undefined1 *puVar5;
  undefined1 *puVar6;
  ulonglong uVar7;
  undefined8 uVar8;
  ulonglong uVar9;
  undefined8 local_af;
  undefined4 local_a7;
  undefined2 local_a3;
  undefined1 local_a1;
  undefined4 local_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined8 local_90;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  
  uVar9 = *(ulonglong *)(param_2 + 0x10);
  lVar3 = uVar9 * 0x28;
  if (uVar9 < 0x333333333333334) {
    if (lVar3 == 0) {
      puVar4 = &DAT_00000008;
      uVar9 = 0;
    }
    else {
      __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
      uVar8 = 8;
      puVar4 = (undefined1 *)__rustc[9d087a5ab36ea756]::__rust_alloc(lVar3,8);
      if (puVar4 == (undefined1 *)0x0) goto LAB_1400493e3;
    }
    local_48 = *(undefined8 *)(param_2 + 0x10);
    local_88 = *param_2;
    uStack_84 = param_2[1];
    uStack_80 = param_2[2];
    uStack_7c = param_2[3];
    local_78 = *(undefined8 *)(param_2 + 4);
    uStack_70 = *(undefined8 *)(param_2 + 6);
    local_68 = *(undefined8 *)(param_2 + 8);
    uStack_60 = *(undefined8 *)(param_2 + 10);
    local_58 = *(undefined8 *)(param_2 + 0xc);
    uStack_50 = *(undefined8 *)(param_2 + 0xe);
    uVar7 = 0;
    puVar6 = puVar4;
    while (puVar5 = (undefined1 *)
                    <alloc[246c2e7857c81348]::collections::btree::map::IterMut<u8,alloc[246c2e7857c81348]::collections::btree::map::BTreeMap<(u8,u32),f64>>as_core[505b25137b8ba7f]::iter::traits::iterator::Iterator>
                    ::next(&local_88), puVar5 != (undefined1 *)0x0) {
      uVar1 = *puVar5;
      host_probe[b94139f9089eb1d8]::results::fold_ai_kills((longlong)&local_af + 7);
      *(undefined8 *)(puVar6 + 0x20) = local_90;
      *(undefined4 *)(puVar6 + 0x10) = local_a0;
      *(undefined4 *)(puVar6 + 0x14) = uStack_9c;
      *(undefined4 *)(puVar6 + 0x18) = uStack_98;
      *(undefined4 *)(puVar6 + 0x1c) = uStack_94;
      *puVar6 = uVar1;
      *(undefined8 *)(puVar6 + 1) = local_af;
      *(undefined4 *)(puVar6 + 9) = local_a7;
      *(undefined2 *)(puVar6 + 0xd) = local_a3;
      puVar6[0xf] = local_a1;
      uVar7 = uVar7 + 1;
      puVar6 = puVar6 + 0x28;
    }
    param_1[2] = uVar7;
    *param_1 = uVar9;
    param_1[1] = (ulonglong)puVar4;
    return param_1;
  }
  uVar8 = 0;
LAB_1400493e3:
  alloc[246c2e7857c81348]::raw_vec::handle_error(uVar8,lVar3);
                    /* WARNING: Does not return */
  pcVar2 = (code *)invalidInstructionException();
  (*pcVar2)();
}

