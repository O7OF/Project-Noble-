// rea decompile_all
// name: <std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>::hash_one::<&(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>
// address: 0x14000a0a0
// body: available
// range: 0x14000a0a0-0x14000a235 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <std[3bf9d48a0c3997f0]::hash::random::RandomState as
   core[505b25137b8ba7f]::hash::BuildHasher>::hash_one::<&(alloc[246c2e7857c81348]::string::String,
   alloc[246c2e7857c81348]::string::String)> */

ulonglong __rustcall
<std[3bf9d48a0c3997f0]::hash::random::RandomState_as_core[505b25137b8ba7f]::hash::BuildHasher>::
hash_one::<&(alloc[246c2e7857c81348]::string::String,alloc[246c2e7857c81348]::string::String)>
          (undefined1 (*param_1) [16],longlong param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  undefined1 auVar7 [16];
  undefined1 auVar8 [16];
  undefined1 local_59;
  undefined1 local_58 [16];
  undefined1 local_48 [16];
  undefined1 local_38 [16];
  undefined1 local_28 [16];
  undefined8 local_18;
  
  local_38 = *param_1;
  auVar7._0_8_ = local_38._0_8_;
  auVar7._8_4_ = local_38._0_4_;
  auVar7._12_4_ = local_38._4_4_;
  local_58 = auVar7 ^ (undefined1  [16])s_uespemosarenegyl_1406a0170;
  auVar8._0_8_ = local_38._8_8_;
  auVar8._8_4_ = local_38._8_4_;
  auVar8._12_4_ = local_38._12_4_;
  local_48 = auVar8 ^ (undefined1  [16])s_modnarodsetybdet_1406a0180;
  local_28 = (undefined1  [16])0x0;
  local_18 = 0;
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_58,*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_2 + 0x10));
  local_59 = 0xff;
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_58,&local_59,1);
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_58,*(undefined8 *)(param_2 + 0x20),*(undefined8 *)(param_2 + 0x28));
  local_59 = 0xff;
  <core[505b25137b8ba7f]::hash::sip::Hasher<core[505b25137b8ba7f]::hash::sip::Sip13Rounds>as_core[505b25137b8ba7f]::hash::Hasher>
  ::write(local_58,&local_59,1);
  uVar6 = local_28._0_8_ << 0x38 | local_28._8_8_;
  uVar2 = local_48._8_8_ ^ uVar6;
  uVar1 = local_58._0_8_ + local_48._0_8_;
  uVar4 = (local_48._0_8_ << 0xd | (ulonglong)local_48._0_8_ >> 0x33) ^ uVar1;
  uVar3 = (uVar2 << 0x10 | uVar2 >> 0x30) ^ local_58._8_8_ + uVar2;
  uVar5 = local_58._8_8_ + uVar2 + uVar4;
  uVar1 = (uVar1 << 0x20 | uVar1 >> 0x20) + uVar3;
  uVar4 = (uVar4 << 0x11 | uVar4 >> 0x2f) ^ uVar5;
  uVar2 = (uVar3 << 0x15 | uVar3 >> 0x2b) ^ uVar1;
  uVar1 = (uVar1 ^ uVar6) + uVar4;
  uVar5 = ((uVar5 << 0x20 | uVar5 >> 0x20) ^ 0xff) + uVar2;
  uVar3 = (uVar4 << 0xd | uVar4 >> 0x33) ^ uVar1;
  uVar2 = (uVar2 << 0x10 | uVar2 >> 0x30) ^ uVar5;
  uVar5 = uVar5 + uVar3;
  uVar1 = (uVar1 << 0x20 | uVar1 >> 0x20) + uVar2;
  uVar3 = (uVar3 << 0x11 | uVar3 >> 0x2f) ^ uVar5;
  uVar2 = (uVar2 << 0x15 | uVar2 >> 0x2b) ^ uVar1;
  uVar1 = uVar1 + uVar3;
  uVar4 = (uVar5 << 0x20 | uVar5 >> 0x20) + uVar2;
  uVar3 = (uVar3 << 0xd | uVar3 >> 0x33) ^ uVar1;
  uVar2 = (uVar2 << 0x10 | uVar2 >> 0x30) ^ uVar4;
  uVar4 = uVar4 + uVar3;
  uVar1 = (uVar1 << 0x20 | uVar1 >> 0x20) + uVar2;
  uVar3 = (uVar3 << 0x11 | uVar3 >> 0x2f) ^ uVar4;
  uVar2 = (uVar2 << 0x15 | uVar2 >> 0x2b) ^ uVar1;
  uVar4 = (uVar4 << 0x20 | uVar4 >> 0x20) + uVar2;
  uVar3 = (uVar3 << 0xd | uVar3 >> 0x33) ^ uVar1 + uVar3;
  uVar1 = (uVar2 << 0x10 | uVar2 >> 0x30) ^ uVar4;
  uVar4 = uVar4 + uVar3;
  return (uVar4 << 0x20 | uVar4 >> 0x20) ^ (uVar3 << 0x11 | uVar3 >> 0x2f) ^
         (uVar1 << 0x15 | uVar1 >> 0x2b) ^ uVar4;
}

