// rea decompile_all
// name: <[u32;4usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<core[505b25137b8ba7f]::option::Option<u32>>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<core[505b25137b8ba7f]::option::Option<u32>>>::wrap_mut_1<u32,core[505b25137b8ba7f]::option::Option<u32>::Some>::{closure#0}>
// address: 0x140002a70
// body: available
// range: 0x140002a70-0x140002aa9 inclusive
// non_contiguous: false
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <[u32; 
   4usize]>::try_map::<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<core[505b25137b8ba7f]::option::Option<u32>>,
   <core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<core[505b25137b8ba7f]::option::Option<u32>>>::wrap_mut_1<u32,
   core[505b25137b8ba7f]::option::Option<u32>::Some>::{closure#0}> */

void __rustcall
<[u32;4usize]>::try_map::
<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<core[505b25137b8ba7f]::option::Option<u32>>,<core[505b25137b8ba7f]::ops::try_trait::NeverShortCircuit<core[505b25137b8ba7f]::option::Option<u32>>>::wrap_mut_1<u32,core[505b25137b8ba7f]::option::Option<u32>::Some>::_closure_0_>
          (undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar1 = *param_2;
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  *param_1 = 1;
  param_1[1] = uVar1;
  param_1[2] = 1;
  param_1[3] = uVar2;
  param_1[4] = 1;
  param_1[5] = uVar3;
  param_1[6] = 1;
  param_1[7] = uVar4;
  return;
}

