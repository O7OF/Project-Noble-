// rea decompile_all
// name: <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u32,[core[505b25137b8ba7f]::option::Option<[f32;3usize]>;21usize]>,host_probe[b94139f9089eb1d8]::host::looks::frame::{closure#4}>>>::from_iter
// address: 0x14004d950
// body: available
// range: 0x14004d950-0x14004dae7 inclusive
// range: 0x14004daf0-0x14004dc10 inclusive
// non_contiguous: true
// provider: Ghidra 12.1.4 (ghidra)
// analysis_profile: 9b537ee6fdad293e1c8ea50e7b50d0b6b22972a83032bca093d279ab7e770ce4
// limitations: The session serves operations only after Ghidra reports default auto-analysis complete; incomplete analysis does not expose partial results.; The imported Program and temporary project are ephemeral and deleted on close. Annotation operations edit session database metadata; original executable bytes are never written.; Cancelling an active Ghidra request terminates its ephemeral database and discards session annotations. The selected target remains open; the next provider query imports the original artifact again.; Default-space addresses use lowercase 0x-prefixed hexadecimal; other address spaces use <percent-encoded-space>:0x<hex>.; Windows Ghidra P0 accepts native x86, x86-64, ARMNT (Thumb-2) and ARM64 PE applications and DLLs, and explicitly selected raw 6502 images; managed, hostile, sensitive, and mutable-path targets are unsupported.; The Windows bridge uses authenticated IPv4 loopback because Node path-based IPC does not expose Java AF_UNIX sockets; the endpoint file contains no bearer token.; Windows sessions require the matching packaged Windows x64 native addon, local NTFS targets and runtimes, and Windows 10 or later. Native handles enforce path admission, private DACLs, and Job Object ownership automatically.; Pseudocode is Ghidra decompiler output, not original source and not text-equivalent to Hopper output.; External functions and functions without an analyzable body return null; other decompiler failures remain explicit.
// pseudocode: provider-specific; not original source


/* WARNING: Unknown calling convention: __rustcall */
/* <alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String> as
   alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,
   core[505b25137b8ba7f]::iter::adapters::map::Map<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u32,
   [core[505b25137b8ba7f]::option::Option<[f32; 3usize]>; 21usize]>,
   host_probe[b94139f9089eb1d8]::host::looks::frame::{closure#4}>>>::from_iter */

ulonglong * __rustcall
<alloc[246c2e7857c81348]::vec::Vec<alloc[246c2e7857c81348]::string::String>as_alloc[246c2e7857c81348]::vec::spec_from_iter_nested::SpecFromIterNested<alloc[246c2e7857c81348]::string::String,core[505b25137b8ba7f]::iter::adapters::map::Map<std[3bf9d48a0c3997f0]::collections::hash::map::Keys<u32,[core[505b25137b8ba7f]::option::Option<[f32;3usize]>;21usize]>,host_probe[b94139f9089eb1d8]::host::looks::frame::{closure#4}>>>
::from_iter(ulonglong *param_1,longlong *param_2)

{
  undefined1 auVar1 [16];
  ulonglong uVar2;
  code *pcVar3;
  uint uVar4;
  uint uVar5;
  longlong lVar6;
  ushort uVar7;
  longlong *plVar8;
  undefined1 (*pauVar9) [16];
  undefined8 uVar10;
  ulonglong uVar11;
  uint uVar12;
  longlong lVar13;
  longlong lVar14;
  ulonglong local_b0;
  longlong *local_a8;
  ulonglong local_a0;
  ulonglong *local_98;
  code *pcStack_90;
  longlong local_88;
  longlong local_80;
  ulonglong *local_78;
  longlong local_70;
  longlong local_68;
  longlong lStack_60;
  longlong local_58;
  longlong *local_50;
  code *local_48;
  
  uVar2 = param_2[4];
  if (uVar2 != 0) {
    uVar7 = *(ushort *)(param_2 + 3);
    lVar14 = *param_2;
    if (uVar7 == 0) {
      pauVar9 = (undefined1 (*) [16])param_2[1];
      do {
        auVar1 = *pauVar9;
        lVar14 = lVar14 + -0x1540;
        pauVar9 = pauVar9 + 1;
        uVar7 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) | (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                 (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                 (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                 (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                 (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                 (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                 (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                 (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                 (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                 (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                 (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                 (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                 (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                 (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
      } while (uVar7 == 0);
      param_2[1] = (longlong)pauVar9;
      *param_2 = lVar14;
    }
    uVar12 = (uint)uVar7;
    uVar4 = 0;
    for (uVar5 = uVar12; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
      uVar4 = uVar4 + 1;
    }
    uVar12 = uVar12 - 1 & uVar12;
    *(short *)(param_2 + 3) = (short)uVar12;
    lVar13 = uVar2 - 1;
    param_2[4] = lVar13;
    local_b0 = ((ulonglong)uVar4 * -0x154 + lVar14) - 0x154;
    local_98 = &local_b0;
    pcStack_90 = <&u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
    alloc[246c2e7857c81348]::fmt::format::format_inner(&local_68,&DAT_1406a3da0,&local_98);
    if (local_68 != -1) {
      local_80 = lStack_60;
      uVar11 = 4;
      if (4 < uVar2) {
        uVar11 = uVar2;
      }
      lVar6 = uVar11 * 0x18;
      local_78 = param_1;
      if (uVar2 < 0x555555555555556) {
        if (lVar6 == 0) {
          plVar8 = (longlong *)&DAT_00000008;
          uVar11 = 0;
        }
        else {
          __rustc[9d087a5ab36ea756]::__rust_no_alloc_shim_is_unstable_v2();
          plVar8 = (longlong *)__rustc[9d087a5ab36ea756]::__rust_alloc(lVar6,8);
          uVar10 = 8;
          if (plVar8 == (longlong *)0x0) goto LAB_14004da4e;
        }
        plVar8[2] = local_58;
        *plVar8 = local_68;
        plVar8[1] = lStack_60;
        local_a0 = 1;
        local_b0 = uVar11;
        local_a8 = plVar8;
        if (lVar13 != 0) {
          pauVar9 = (undefined1 (*) [16])param_2[1];
          do {
            uVar2 = local_a0;
            uVar7 = (ushort)uVar12;
            while (uVar7 == 0) {
              auVar1 = *pauVar9;
              lVar14 = lVar14 + -0x1540;
              pauVar9 = pauVar9 + 1;
              uVar7 = ((ushort)(SUB161(auVar1 >> 7,0) & 1) |
                       (ushort)(SUB161(auVar1 >> 0xf,0) & 1) << 1 |
                       (ushort)(SUB161(auVar1 >> 0x17,0) & 1) << 2 |
                       (ushort)(SUB161(auVar1 >> 0x1f,0) & 1) << 3 |
                       (ushort)(SUB161(auVar1 >> 0x27,0) & 1) << 4 |
                       (ushort)(SUB161(auVar1 >> 0x2f,0) & 1) << 5 |
                       (ushort)(SUB161(auVar1 >> 0x37,0) & 1) << 6 |
                       (ushort)(SUB161(auVar1 >> 0x3f,0) & 1) << 7 |
                       (ushort)(SUB161(auVar1 >> 0x47,0) & 1) << 8 |
                       (ushort)(SUB161(auVar1 >> 0x4f,0) & 1) << 9 |
                       (ushort)(SUB161(auVar1 >> 0x57,0) & 1) << 10 |
                       (ushort)(SUB161(auVar1 >> 0x5f,0) & 1) << 0xb |
                       (ushort)(SUB161(auVar1 >> 0x67,0) & 1) << 0xc |
                       (ushort)(SUB161(auVar1 >> 0x6f,0) & 1) << 0xd |
                       (ushort)(SUB161(auVar1 >> 0x77,0) & 1) << 0xe |
                      (ushort)(byte)(auVar1[0xf] >> 7) << 0xf) ^ 0xffff;
              uVar12 = (uint)uVar7;
            }
            uVar4 = 0;
            for (uVar5 = uVar12; (uVar5 & 1) == 0; uVar5 = uVar5 >> 1 | 0x80000000) {
              uVar4 = uVar4 + 1;
            }
            local_70 = (ulonglong)uVar4 * -0x154 + lVar14 + -0x154;
            local_50 = &local_70;
            local_48 = <&u32_as_core[505b25137b8ba7f]::fmt::LowerHex>::fmt;
            alloc[246c2e7857c81348]::fmt::format::format_inner(&local_98,&DAT_1406a3da0,&local_50);
            if (local_98 == (ulonglong *)0xffffffffffffffff) break;
            if (uVar2 == local_b0) {
              <alloc[246c2e7857c81348]::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::
              <alloc[246c2e7857c81348]::alloc::Global>(&local_b0,uVar2,lVar13,8,0x18);
              plVar8 = local_a8;
            }
            uVar12 = uVar12 - 1 & uVar12;
            lVar13 = lVar13 + -1;
            plVar8[uVar2 * 3 + 2] = local_88;
            plVar8[uVar2 * 3] = (longlong)local_98;
            (plVar8 + uVar2 * 3)[1] = (longlong)pcStack_90;
            local_a0 = uVar2 + 1;
          } while (lVar13 != 0);
        }
        local_78[2] = local_a0;
        *local_78 = local_b0;
        local_78[1] = (ulonglong)local_a8;
        return local_78;
      }
      uVar10 = 0;
LAB_14004da4e:
      alloc[246c2e7857c81348]::raw_vec::handle_error(uVar10,lVar6);
                    /* WARNING: Does not return */
      pcVar3 = (code *)invalidInstructionException();
      (*pcVar3)();
    }
  }
  *param_1 = 0;
  param_1[1] = 8;
  param_1[2] = 0;
  return param_1;
}

